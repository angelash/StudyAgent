"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DomainDatabase = void 0;
exports.freezeJson = freezeJson;
const common_1 = require("@nestjs/common");
const node_sqlite_1 = require("node:sqlite");
const node_fs_1 = require("node:fs");
const node_path_1 = require("node:path");
const pg_1 = require("pg");
const task_repository_1 = require("./task-repository");
const rate_limit_repository_1 = require("./rate-limit-repository");
const domain_selection_1 = require("./domain-selection");
const sqlite_serialization_1 = require("./sqlite-serialization");
const assistant_whiteboard_integrity_1 = require("../modules/learning/assistant-whiteboard-integrity");
// Each schema version is applied atomically: an invalid old record must stop the
// upgrade before the version is recorded, without silently discarding evidence.
const learningIdentityConstraints = [
    { name: 'learning_access_student', collection: 'studentLearningAccess', fields: ['studentId'] },
    { name: 'learning_access_user', collection: 'studentLearningAccess', fields: ['userId'] },
    { name: 'learning_code_token', collection: 'studentLearningCodes', fields: ['tokenHash'] },
    { name: 'learning_code_request', collection: 'studentLearningCodes', fields: ['studentId', 'createdBy', 'requestKey'] },
    { name: 'learning_access_version', collection: 'studentAccessRevisions', fields: ['studentId', 'version'] },
    { name: 'learning_access_request', collection: 'studentAccessRevisions', fields: ['studentId', 'actorId', 'requestKey'] },
    { name: 'progress_proposal_request', collection: 'studentProgressProposals', fields: ['studentId', 'proposedBy', 'requestKey'] },
    { name: 'progress_proposal_pending', collection: 'studentProgressProposals', fields: ['studentId', 'scope.subject'], pending: true },
];
const assistantConstraints = [
    { name: 'assistant_scope', collection: 'assistantSessions', fields: ['scopeKey'] },
    { name: 'assistant_message_request', collection: 'assistantMessages', fields: ['sessionId', 'requestKey'] },
];
function differences(before, after, reads, writeHints) {
    const changes = [];
    const ordered = reads && new Set(reads.filter(read => !read.where || !Object.keys(read.where).length).map(read => read.collection));
    for (const collection of new Set([...Object.keys(before), ...Object.keys(after)])) {
        // Request workspaces share untouched immutable collections with their baseline.
        if (before[collection] === after[collection])
            continue;
        if (writeHints?.[collection]) {
            const oldRows = before[collection] ?? [], nextRows = after[collection] ?? [], seen = new Set();
            let mutableIndex;
            for (const position of writeHints[collection]) {
                const item = nextRows[position], previous = oldRows[position], id = (0, domain_selection_1.identity)(item);
                if (seen.has(id))
                    throw new common_1.ConflictException(`Duplicate identity in ${collection}`);
                seen.add(id);
                if (previous && (0, domain_selection_1.identity)(previous) !== id)
                    throw new common_1.ConflictException('记录标识不可更改，请使用新增及移除');
                if (item === previous || (0, domain_selection_1.sameRecords)([previous], [item]))
                    continue;
                if (!previous || (0, domain_selection_1.identity)(previous) !== id) {
                    let sameId = (0, domain_selection_1.indexedPositions)(oldRows, { id });
                    if (!sameId) {
                        mutableIndex ??= new Map(oldRows.map((row, index) => [(0, domain_selection_1.identity)(row), [index]]));
                        sameId = mutableIndex.get(id) ?? [];
                    }
                    if (sameId.some(index => index !== position && nextRows[index] && (0, domain_selection_1.identity)(nextRows[index]) === id))
                        throw new common_1.ConflictException(`Duplicate identity in ${collection}`);
                }
                changes.push({ collection, id, body: JSON.stringify(item), position, preservePosition: Boolean(previous && (0, domain_selection_1.identity)(previous) === id) });
            }
            continue;
        }
        const previous = new Map((before[collection] ?? []).map((item) => [(0, domain_selection_1.identity)(item), item]));
        const positions = new Map((before[collection] ?? []).map((item, index) => [(0, domain_selection_1.identity)(item), index]));
        const next = new Map();
        for (const item of after[collection] ?? []) {
            const id = (0, domain_selection_1.identity)(item);
            if (next.has(id))
                throw new common_1.ConflictException(`Duplicate identity in ${collection}`);
            next.set(id, item);
        }
        let position = 0;
        for (const [id, item] of next) {
            const changed = previous.get(id) !== item && !(0, domain_selection_1.sameRecords)([previous.get(id)], [item]);
            if (changed || (!ordered || ordered.has(collection)) && positions.get(id) !== position)
                changes.push({ collection, id, body: JSON.stringify(item),
                    position: positions.get(id) !== undefined && ordered && !ordered.has(collection) ? positions.get(id) : position,
                    preservePosition: Boolean(ordered && !ordered.has(collection) && previous.has(id)) });
            position++;
        }
        for (const id of previous.keys())
            if (!next.has(id))
                changes.push({ collection, id, body: null, position: 0 });
    }
    return changes;
}
function freezeJson(value) {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        for (const child of Object.values(value))
            freezeJson(child);
        Object.freeze(value);
    }
    return value;
}
/** Transactional domain documents. Large external paper/media catalogs use a separate indexed repository. */
class DomainDatabase {
    location;
    now;
    sqlite;
    postgres;
    cached;
    counters = { revisionChecks: 0, snapshotLoads: 0, partialSnapshotLoads: 0, snapshotRowsLoaded: 0, cacheHits: 0, commits: 0, scopedCommits: 0, conflicts: 0 };
    tasks;
    limits;
    driver;
    constructor(location, now = () => Date.now()) {
        this.location = location;
        this.now = now;
        this.driver = /^postgres(ql)?:/.test(location) ? 'postgres' : 'sqlite';
    }
    async open() {
        try {
            const key = this.driver === 'sqlite' && (0, sqlite_serialization_1.sqliteQueueKey)(this.location);
            if (key)
                await (0, sqlite_serialization_1.serializeSqlite)(key, () => this.initialize());
            else
                await this.initialize();
        }
        catch (error) {
            await this.close();
            throw error;
        }
    }
    async initialize() {
        if (this.driver === 'sqlite') {
            (0, node_fs_1.mkdirSync)((0, node_path_1.dirname)(this.location), { recursive: true });
            this.sqlite = new node_sqlite_1.DatabaseSync(this.location);
            await this.assertRestoreReady();
            this.sqlite.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
        CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL);
        INSERT OR IGNORE INTO schema_migrations VALUES(1, strftime('%Y-%m-%dT%H:%M:%fZ','now'));
        CREATE TABLE IF NOT EXISTS store_meta(id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL);
        INSERT OR IGNORE INTO store_meta VALUES(1,0);
        CREATE TABLE IF NOT EXISTS domain_records(collection TEXT NOT NULL, record_id TEXT NOT NULL,
          body TEXT NOT NULL CHECK(json_valid(body)), position INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(collection,record_id));
        CREATE UNIQUE INDEX IF NOT EXISTS users_principal ON domain_records(json_extract(body,'$.principal')) WHERE collection='users';
        CREATE UNIQUE INDEX IF NOT EXISTS session_token ON domain_records(json_extract(body,'$.tokenHash')) WHERE collection='sessions';
        CREATE UNIQUE INDEX IF NOT EXISTS assessment_response ON domain_records(json_extract(body,'$.sessionId'),json_extract(body,'$.questionId')) WHERE collection='assessmentAnswers';
        CREATE UNIQUE INDEX IF NOT EXISTS active_binding ON domain_records(json_extract(body,'$.parentUserId'),json_extract(body,'$.studentId')) WHERE collection='bindings' AND json_extract(body,'$.status')='active';`);
        }
        else {
            this.postgres = new pg_1.Pool({ connectionString: this.location, max: 8, connectionTimeoutMillis: 5000 });
            await this.assertRestoreReady();
            const client = await this.postgres.connect();
            try {
                await client.query('BEGIN');
                await client.query('SELECT pg_advisory_xact_lock(73199402)');
                await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
        INSERT INTO schema_migrations(version) VALUES(1) ON CONFLICT DO NOTHING;
        CREATE TABLE IF NOT EXISTS store_meta(id INTEGER PRIMARY KEY CHECK(id=1), revision BIGINT NOT NULL);
        INSERT INTO store_meta VALUES(1,0) ON CONFLICT DO NOTHING;
        CREATE TABLE IF NOT EXISTS domain_records(collection TEXT NOT NULL, record_id TEXT NOT NULL, body JSONB NOT NULL, position INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(collection,record_id));
        CREATE UNIQUE INDEX IF NOT EXISTS users_principal ON domain_records((body->>'principal')) WHERE collection='users';
        CREATE UNIQUE INDEX IF NOT EXISTS session_token ON domain_records((body->>'tokenHash')) WHERE collection='sessions';
        CREATE UNIQUE INDEX IF NOT EXISTS assessment_response ON domain_records((body->>'sessionId'),(body->>'questionId')) WHERE collection='assessmentAnswers';
        CREATE UNIQUE INDEX IF NOT EXISTS active_binding ON domain_records((body->>'parentUserId'),(body->>'studentId')) WHERE collection='bindings' AND body->>'status'='active';`);
                await client.query('COMMIT');
            }
            catch (error) {
                await client.query('ROLLBACK');
                throw error;
            }
            finally {
                client.release();
            }
        }
        await this.assertRestoreReady();
        await this.migrateConstraints(2, learningIdentityConstraints);
        await this.migrateConstraints(3, assistantConstraints);
        await this.migrateConstraints(4, [], `CREATE TABLE IF NOT EXISTS study_restore_guard(id INTEGER PRIMARY KEY CHECK(id=1),state TEXT NOT NULL,backup_id TEXT,updated_at TEXT NOT NULL);
      INSERT INTO study_restore_guard VALUES(1,'ready',NULL,'${new Date().toISOString()}') ON CONFLICT(id) DO NOTHING;`);
        await this.migrateConstraints(5, [{ name: 'privacy_request', collection: 'privacyRequests', fields: ['actorId', 'requestKey'] }]);
        await this.migrateConstraints(6, [{ name: 'student_media_request', collection: 'studentMedia', fields: ['ownerUserId', 'requestKey'] }]);
        await this.migrateConstraints(7, [], `CREATE TABLE IF NOT EXISTS request_rate_limits(bucket_key TEXT PRIMARY KEY,used INTEGER NOT NULL,expires_at BIGINT NOT NULL);
      CREATE INDEX IF NOT EXISTS request_rate_expiration ON request_rate_limits(expires_at);`);
        const extract = (field) => this.sqlite ? `json_extract(body,'$.${field}')` : `(body#>'{${field}}')`;
        await this.migrateConstraints(8, [], `CREATE TABLE IF NOT EXISTS domain_collection_versions(collection TEXT PRIMARY KEY,revision BIGINT NOT NULL);
      INSERT INTO domain_collection_versions SELECT DISTINCT collection,(SELECT revision FROM store_meta WHERE id=1) FROM domain_records WHERE TRUE ON CONFLICT(collection) DO NOTHING;
      CREATE INDEX IF NOT EXISTS domain_collection_order ON domain_records(collection,position,record_id);
      ${['studentId', 'sessionId', 'questionId', 'parentUserId', 'userId', 'responseId'].map(field => `CREATE INDEX IF NOT EXISTS domain_lookup_${field.toLowerCase()} ON domain_records(collection,${extract(field)}) WHERE ${extract(field)} IS NOT NULL`).join(';')};`);
        await this.migrateConstraints(9, [
            { name: 'gesp_learning_scope_student', collection: 'gespLearningScopes', fields: ['studentId'] },
            { name: 'gesp_learning_scope_request', collection: 'gespLearningScopeRevisions', fields: ['studentId', 'requestKey'] },
            { name: 'gesp_code_submission_request', collection: 'gespCodeSubmissions', fields: ['studentId', 'requestKey'] },
        ]);
        await this.migrateConstraints(10, [{ name: 'gesp_probe_submission_request', collection: 'gespProbeSubmissions',
                fields: ['studentId', 'requestKey'] }]);
        await this.migrateConstraints(11, [
            { name: 'gesp_hint_request', collection: 'gespHintEvents', fields: ['studentId', 'requestKey'] },
            { name: 'gesp_guidance_request', collection: 'gespGuidancePlans', fields: ['studentId', 'requestKey'] },
            { name: 'gesp_guidance_revision', collection: 'gespGuidancePlanRevisions', fields: ['planId', 'version'] },
            { name: 'gesp_review_schedule', collection: 'gespReviewTasks', fields: ['studentId', 'atomId', 'stageDay', 'sourceSubmissionId'] },
        ]);
        await this.migrateConstraints(12, [
            { name: 'gesp_task_review_task', collection: 'gespTaskReviews', fields: ['taskId'] },
            { name: 'gesp_task_review_request', collection: 'gespTaskReviewRevisions', fields: ['taskId', 'requestKey'] },
        ]);
        await this.migrateConstraints(13, [
            { name: 'classroom_visual_request', collection: 'classroomVisuals', fields: ['ownerUserId', 'requestKey'] },
        ]);
        const guidanceField = (field) => this.sqlite ? `json_extract(body,'$.${field}')` : `(body->>'${field}')`;
        await this.migrateConstraints(14, [], `CREATE UNIQUE INDEX IF NOT EXISTS guidance_plan_creation_request ON domain_records(${guidanceField('actorId')},${guidanceField('requestKey')})
      WHERE collection='guidancePlanRevisions' AND ${guidanceField('kind')}='created' AND ${guidanceField('requestKey')} IS NOT NULL;`);
        await this.migrateConstraints(15, [{ name: 'source_check_prepare_request', collection: 'sourceCourseChecks', fields: ['ownerUserId', 'requestKey'] },
            { name: 'source_check_publication_course', collection: 'sourceCourseCheckPublications', fields: ['courseId'] }], `
      CREATE UNIQUE INDEX IF NOT EXISTS source_check_active_generation ON domain_records(${guidanceField('ownerUserId')},${guidanceField('courseId')})
        WHERE collection='sourceCourseChecks' AND ${guidanceField('status')} IN ('queued','generating','cancel_requested');`);
        await this.migrateConstraints(16, [
            { name: 'topic_whiteboard_prepare_request', collection: 'studioTopicWhiteboardDrafts', fields: ['ownerUserId', 'requestKey'] },
            { name: 'topic_whiteboard_publication_draft', collection: 'studioTopicWhiteboards', fields: ['sourceDraftId'] },
        ]);
        await this.migrateConstraints(17, [
            { name: 'topic_visual_prepare_request', collection: 'studioTopicWhiteboardVisuals', fields: ['ownerUserId', 'requestKey'] },
        ]);
        await this.migrateConstraints(18, [
            { name: 'paper_practice_creation_request', collection: 'paperPracticeSessions', fields: ['ownerUserId', 'requestKey'] },
            { name: 'paper_practice_command_request', collection: 'paperPracticeCommands', fields: ['sessionId', 'ownerUserId', 'requestKey'] },
        ]);
        await this.migrateConstraints(19, [
            { name: 'whiteboard_question_request', collection: 'whiteboardQuestionTurns', fields: ['ownerUserId', 'requestKey'] },
        ]);
        await this.migrateConstraints(20, [
            { name: 'question_visual_prepare_request', collection: 'whiteboardQuestionVisuals', fields: ['ownerUserId', 'requestKey'] },
        ]);
        await this.migrateConstraints(21, [
            { name: 'teaching_tool_creation_request', collection: 'teachingToolRuns', fields: ['ownerUserId', 'requestKey'] },
        ]);
        await this.migrateConstraints(22, [
            { name: 'assistant_note_creation_request', collection: 'assistantArtifactDrafts', fields: ['ownerUserId', 'requestKey'] },
        ]);
        // Existing v22 readers only accept `ready`, so the marker also fences an
        // accidental downgrade before any private conversation whiteboard is read.
        await this.migrateConstraints(23, [], `UPDATE study_restore_guard SET state='ready-schema23',updated_at='${new Date().toISOString()}' WHERE id=1 AND state='ready';`);
        const sourceRowsSql = "SELECT collection,record_id,body FROM domain_records WHERE collection IN ('assistantSessions','studioTopicWhiteboardDrafts','studioTopicWhiteboards')";
        const sourceRows = this.sqlite ? this.sqlite.prepare(sourceRowsSql).all() : (await this.postgres.query(sourceRowsSql)).rows;
        (0, assistant_whiteboard_integrity_1.assertAssistantWhiteboardRecords)(sourceRows);
        this.tasks = new task_repository_1.TaskRepository(this.sqlite, this.postgres, this.now, this.sqlite && (0, sqlite_serialization_1.sqliteQueueKey)(this.location));
        await this.tasks.open();
        this.limits = new rate_limit_repository_1.RateLimitRepository(this.tasks, this.sqlite, this.postgres, this.now);
    }
    async assertRestoreReady() {
        let state, version = 0;
        if (this.sqlite) {
            const table = this.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='study_restore_guard'").get();
            if (table)
                state = this.sqlite.prepare('SELECT state FROM study_restore_guard WHERE id=1').get()?.state ?? 'missing';
            if (state !== undefined && !['ready', 'ready-schema23'].includes(state))
                throw new Error('Database restoration is incomplete');
            if (this.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='schema_migrations'").get())
                version = Number(this.sqlite.prepare('SELECT MAX(version) version FROM schema_migrations').get().version ?? 0);
        }
        else {
            if ((await this.postgres.query("SELECT to_regclass('study_restore_guard') AS name")).rows[0].name)
                state = (await this.postgres.query('SELECT state FROM study_restore_guard WHERE id=1')).rows[0]?.state ?? 'missing';
            if (state !== undefined && !['ready', 'ready-schema23'].includes(state))
                throw new Error('Database restoration is incomplete');
            if ((await this.postgres.query("SELECT to_regclass('schema_migrations') AS name")).rows[0].name)
                version = Number((await this.postgres.query('SELECT MAX(version) version FROM schema_migrations')).rows[0]?.version ?? 0);
        }
        if (version > 23)
            throw new Error('unsupported_database_schema');
        if (version === 23 && state !== 'ready-schema23' || version < 23 && state === 'ready-schema23')
            throw new Error('minimum_reader_guard_mismatch');
    }
    async migrateConstraints(version, constraints, extraSql = '') {
        const indexes = (postgres) => constraints.map(index => {
            const extract = (field) => postgres ? `(body#>>'{${field.split('.').join(',')}}')` : `json_extract(body,'$.${field}')`;
            return `CREATE UNIQUE INDEX IF NOT EXISTS ${index.name} ON domain_records(${index.fields.map(extract).join(',')})
        WHERE collection='${index.collection}'${index.pending ? ` AND ${extract('status')}='pending'` : ''}`;
        }).join(';');
        if (this.sqlite) {
            this.sqlite.exec('BEGIN IMMEDIATE');
            try {
                if (!this.sqlite.prepare('SELECT version FROM schema_migrations WHERE version=?').get(version)) {
                    this.sqlite.exec(indexes(false) + ';' + extraSql);
                    this.sqlite.prepare("INSERT INTO schema_migrations VALUES(?, strftime('%Y-%m-%dT%H:%M:%fZ','now'))").run(version);
                }
                this.sqlite.exec('COMMIT');
            }
            catch (error) {
                this.sqlite.exec('ROLLBACK');
                throw error;
            }
            return;
        }
        const client = await this.postgres.connect();
        try {
            await client.query('BEGIN');
            await client.query('SELECT pg_advisory_xact_lock(73199402)');
            if (!(await client.query('SELECT version FROM schema_migrations WHERE version=$1', [version])).rowCount) {
                await client.query(indexes(true) + ';' + extraSql);
                await client.query('INSERT INTO schema_migrations(version) VALUES($1)', [version]);
            }
            await client.query('COMMIT');
        }
        catch (error) {
            await client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    }
    async read() {
        // Public callers retain an independently mutable copy for maintenance/tests.
        return structuredClone(await this.readImmutable());
    }
    async readImmutable() {
        return this.tasks.serial(() => this.readSnapshot());
    }
    snapshotAt(revision) {
        return this.cached?.revision === revision ? this.cached : undefined;
    }
    get diagnostics() { return { ...this.counters }; }
    remember(snapshot, loadedRows, partial = false) {
        if (partial)
            this.counters.partialSnapshotLoads++;
        else
            this.counters.snapshotLoads++;
        this.counters.snapshotRowsLoaded += loadedRows;
        this.cached = freezeJson(snapshot);
        return this.cached;
    }
    rememberCommit(beforeRevision, revision, changes) {
        this.counters.commits++;
        if (this.cached?.revision !== beforeRevision) {
            this.cached = undefined;
            return;
        }
        const state = { ...this.cached.state }, collections = new Map();
        for (const change of changes) {
            const group = collections.get(change.collection) ?? [];
            group.push(change);
            collections.set(change.collection, group);
        }
        for (const [collection, group] of collections) {
            const rows = new Map((state[collection] ?? []).map((item, position) => [(0, domain_selection_1.identity)(item), { item, position }]));
            for (const change of group) {
                if (change.body === null)
                    rows.delete(change.id);
                else
                    rows.set(change.id, { item: JSON.parse(change.body), position: change.position });
            }
            if (!rows.size)
                delete state[collection];
            else
                state[collection] = freezeJson([...rows.values()].sort((a, b) => a.position - b.position).map(row => row.item));
        }
        const collectionRevisions = { ...this.cached.collectionRevisions };
        for (const collection of collections.keys())
            collectionRevisions[collection] = revision;
        this.cached = freezeJson({ revision, state, collectionRevisions });
    }
    async readSnapshot() {
        this.counters.revisionChecks++;
        if (this.sqlite) {
            this.sqlite.exec('BEGIN');
            try {
                const { revision } = this.sqlite.prepare('SELECT revision FROM store_meta WHERE id=1').get();
                if (this.cached?.revision === revision) {
                    this.sqlite.exec('COMMIT');
                    this.counters.cacheHits++;
                    return this.cached;
                }
                const versions = this.sqlite.prepare('SELECT collection,revision FROM domain_collection_versions').all();
                const collectionRevisions = Object.fromEntries(versions.map(row => [row.collection, Number(row.revision)]));
                const state = this.cached ? { ...this.cached.state } : {};
                const changed = this.cached ? versions.filter(row => Number(row.revision) !== this.cached.collectionRevisions?.[row.collection]).map(row => row.collection) : undefined;
                const rows = changed ? changed.flatMap(collection => this.sqlite.prepare('SELECT collection,body FROM domain_records WHERE collection=? ORDER BY position,record_id').all(collection)) :
                    this.sqlite.prepare('SELECT collection,body FROM domain_records ORDER BY collection,position,record_id').all();
                for (const collection of changed ?? [])
                    delete state[collection];
                for (const row of rows)
                    (state[row.collection] ??= []).push(JSON.parse(row.body));
                this.sqlite.exec('COMMIT');
                return this.remember({ revision, state, collectionRevisions }, rows.length, Boolean(changed));
            }
            catch (error) {
                this.sqlite.exec('ROLLBACK');
                throw error;
            }
        }
        const client = await this.postgres.connect();
        try {
            await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
            const meta = await client.query('SELECT revision FROM store_meta WHERE id=1');
            const revision = Number(meta.rows[0].revision);
            if (this.cached?.revision === revision) {
                await client.query('COMMIT');
                this.counters.cacheHits++;
                return this.cached;
            }
            const versions = (await client.query('SELECT collection,revision FROM domain_collection_versions')).rows;
            const collectionRevisions = Object.fromEntries(versions.map(row => [row.collection, Number(row.revision)]));
            const state = this.cached ? { ...this.cached.state } : {};
            const changed = this.cached ? versions.filter(row => Number(row.revision) !== this.cached.collectionRevisions?.[row.collection]).map(row => row.collection) : undefined;
            const records = changed ? await client.query('SELECT collection,body FROM domain_records WHERE collection=ANY($1::text[]) ORDER BY collection,position,record_id', [changed]) :
                await client.query('SELECT collection,body FROM domain_records ORDER BY collection,position,record_id');
            for (const collection of changed ?? [])
                delete state[collection];
            for (const row of records.rows)
                (state[row.collection] ??= []).push(row.body);
            await client.query('COMMIT');
            return this.remember({ revision, state, collectionRevisions }, records.rows.length, Boolean(changed));
        }
        catch (error) {
            await client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    }
    async commit(before, after, options = {}) {
        return this.tasks.serial(() => this.commitSnapshot(before, after, options));
    }
    async commitSnapshot(before, after, options) {
        const changes = differences(before.state, after, options.reads, options.writeHints);
        if (changes.length === 0 && !options.enqueue?.length && !options.fence && !options.taskOperations?.length)
            return before.revision;
        const conflict = () => { this.counters.conflicts++; return new common_1.ConflictException('数据已更新，请重试本次操作'); };
        if (this.sqlite) {
            this.sqlite.exec('BEGIN IMMEDIATE');
            try {
                if (options.fence)
                    await this.tasks.applyFence(options.fence);
                const current = Number(this.sqlite.prepare('SELECT revision FROM store_meta WHERE id=1').get().revision);
                if (options.reads)
                    await this.assertDependencies(before, changes, options.reads, async (collection, where) => {
                        const query = (0, domain_selection_1.selectionSql)(collection, where, false);
                        return this.sqlite.prepare(query.text).all(...query.values).map(row => JSON.parse(row.body));
                    }, conflict, async (collection) => Number(this.sqlite.prepare('SELECT revision FROM domain_collection_versions WHERE collection=?').get(collection)?.revision ?? 0));
                else if (current !== before.revision)
                    throw conflict();
                this.sqlite.prepare('UPDATE store_meta SET revision=revision+1 WHERE id=1').run();
                this.rebaseAppends(before, changes, options, collection => Number(this.sqlite.prepare('SELECT COALESCE(MAX(position),-1) AS position FROM domain_records WHERE collection=?').get(collection).position));
                const upsert = this.sqlite.prepare('INSERT INTO domain_records VALUES(?,?,?,?) ON CONFLICT(collection,record_id) DO UPDATE SET body=excluded.body,position=excluded.position');
                const upsertPreservingPosition = this.sqlite.prepare('INSERT INTO domain_records VALUES(?,?,?,?) ON CONFLICT(collection,record_id) DO UPDATE SET body=excluded.body');
                const remove = this.sqlite.prepare('DELETE FROM domain_records WHERE collection=? AND record_id=?');
                for (const change of changes) {
                    if (change.body === null)
                        remove.run(change.collection, change.id);
                    else
                        (change.preservePosition ? upsertPreservingPosition : upsert).run(change.collection, change.id, change.body, change.position);
                }
                for (const collection of new Set(changes.map(change => change.collection)))
                    this.sqlite.prepare('INSERT INTO domain_collection_versions VALUES(?,?) ON CONFLICT(collection) DO UPDATE SET revision=excluded.revision').run(collection, current + 1);
                await this.tasks.insert(options.enqueue ?? []);
                await this.tasks.applyOperations(options.taskOperations ?? []);
                this.sqlite.exec('COMMIT');
                this.rememberCommit(current, current + 1, changes);
                if (options.reads)
                    this.counters.scopedCommits++;
                return current + 1;
            }
            catch (error) {
                this.sqlite.exec('ROLLBACK');
                throw error;
            }
        }
        const client = await this.postgres.connect();
        try {
            await client.query('BEGIN');
            if (options.fence)
                await this.tasks.applyFence(options.fence, client);
            // The metadata row serializes only validation and SQL writes, not request execution.
            const current = Number((await client.query('SELECT revision FROM store_meta WHERE id=1 FOR UPDATE')).rows[0].revision);
            if (options.reads)
                await this.assertDependencies(before, changes, options.reads, async (collection, where) => {
                    const query = (0, domain_selection_1.selectionSql)(collection, where, true);
                    return (await client.query(query.text, query.values)).rows.map(row => row.body);
                }, conflict, async (collection) => Number((await client.query('SELECT revision FROM domain_collection_versions WHERE collection=$1', [collection])).rows[0]?.revision ?? 0));
            else if (current !== before.revision)
                throw conflict();
            await client.query('UPDATE store_meta SET revision=revision+1 WHERE id=1');
            const positions = new Map();
            if (options.reads)
                for (const collection of new Set(changes.map(change => change.collection)))
                    positions.set(collection, Number((await client.query('SELECT COALESCE(MAX(position),-1) AS position FROM domain_records WHERE collection=$1', [collection])).rows[0].position));
            this.rebaseAppends(before, changes, options, collection => positions.get(collection));
            for (const change of changes) {
                if (change.body === null)
                    await client.query('DELETE FROM domain_records WHERE collection=$1 AND record_id=$2', [change.collection, change.id]);
                else
                    await client.query(`INSERT INTO domain_records VALUES($1,$2,$3::jsonb,$4) ON CONFLICT(collection,record_id) DO UPDATE SET body=excluded.body${change.preservePosition ? '' : ',position=excluded.position'}`, [change.collection, change.id, change.body, change.position]);
            }
            for (const collection of new Set(changes.map(change => change.collection)))
                await client.query('INSERT INTO domain_collection_versions VALUES($1,$2) ON CONFLICT(collection) DO UPDATE SET revision=excluded.revision', [collection, current + 1]);
            await this.tasks.insert(options.enqueue ?? [], client);
            await this.tasks.applyOperations(options.taskOperations ?? [], client);
            await client.query('COMMIT');
            this.rememberCommit(current, current + 1, changes);
            if (options.reads)
                this.counters.scopedCommits++;
            return current + 1;
        }
        catch (error) {
            await client.query('ROLLBACK');
            throw error;
        }
        finally {
            client.release();
        }
    }
    async assertDependencies(before, changes, dependencies, query, conflict, version) {
        const wildcard = new Set();
        for (const { collection, where } of dependencies) {
            if (!where || !Object.keys(where).length) {
                wildcard.add(collection);
                if (before.collectionRevisions && (before.collectionRevisions[collection] ?? 0) === await version(collection))
                    continue;
            }
            const predicate = where && (0, domain_selection_1.compileSelector)(where);
            const baseline = before.state[collection] ?? [], positions = where && (0, domain_selection_1.indexedPositions)(baseline, where);
            const rows = positions ? positions.sort((a, b) => a - b).map(index => baseline[index]) : baseline;
            const expected = rows.filter(row => !predicate || predicate(row));
            if (!(0, domain_selection_1.sameRecords)(expected, await query(collection, where)))
                throw conflict();
        }
        // Writes are checked even if a caller omitted an explicit read. Inserts must
        // still be absent; changes cannot overwrite a concurrent edit or deletion.
        const byCollection = new Map();
        for (const change of changes)
            if (!wildcard.has(change.collection)) {
                const group = byCollection.get(change.collection) ?? [];
                group.push(change);
                byCollection.set(change.collection, group);
            }
        for (const [collection, group] of byCollection) {
            const ids = new Set(group.map(change => change.id));
            const baseline = before.state[collection] ?? [], positions = (0, domain_selection_1.indexedPositions)(baseline, { id: [...ids] });
            const expected = new Map((positions ? positions.map(index => baseline[index]) : baseline.filter(row => ids.has((0, domain_selection_1.identity)(row)))).map(row => [(0, domain_selection_1.identity)(row), row]));
            const actual = new Map(), identityList = [...ids];
            for (let offset = 0; offset < identityList.length; offset += 5000)
                for (const row of await query(collection, { id: identityList.slice(offset, offset + 5000) }))
                    actual.set((0, domain_selection_1.identity)(row), row);
            if (!(0, domain_selection_1.sameRecords)([...expected].sort(), [...actual].sort()))
                throw conflict();
        }
    }
    rebaseAppends(before, changes, options, maximum) {
        if (!options.reads)
            return;
        const positions = new Map();
        const existing = new Map();
        for (const change of changes) {
            if (!existing.has(change.collection))
                existing.set(change.collection, new Set((before.state[change.collection] ?? []).map(domain_selection_1.identity)));
            if (!change.body || existing.get(change.collection).has(change.id))
                continue;
            const position = (positions.get(change.collection) ?? maximum(change.collection)) + 1;
            change.position = position;
            positions.set(change.collection, position);
        }
    }
    async close() {
        const close = async () => { this.cached = undefined; this.sqlite?.close(); this.sqlite = undefined; await this.postgres?.end(); this.postgres = undefined; };
        if (this.tasks)
            await this.tasks.serial(close);
        else
            await close();
    }
}
exports.DomainDatabase = DomainDatabase;
