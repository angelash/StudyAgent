# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: guidance-model.spec.ts >> guidance comparisons and actions fit at 768
- Location: tests\e2e\guidance-model.spec.ts:118:39

# Error details

```
Error: {"width":768,"scrollWidth":807,"overflow":[{"tag":"LABEL","className":"","width":484.796875,"scrollWidth":485},{"tag":"SELECT","className":"","width":459.515625,"scrollWidth":460},{"tag":"P","className":"","width":484.796875,"scrollWidth":485},{"tag":"SPAN","className":"","width":310.796875,"scrollWidth":311}]}

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 769
Received:    807
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - link "学习观察室" [ref=f1e4] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f1e5]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f1e6]:
        - link "学习首页" [ref=f1e7] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_37beee3d-1954-49c1-923f-a34af2960cc7
        - link "学习工作台" [ref=f1e8] [cursor=pointer]:
          - /url: /studio?subject=math&student=student_37beee3d-1954-49c1-923f-a34af2960cc7
        - link "家长空间" [ref=f1e9] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math&studentId=student_37beee3d-1954-49c1-923f-a34af2960cc7
        - link "知识诊断" [ref=f1e10] [cursor=pointer]:
          - /url: /student/assessment?subject=math&studentId=student_37beee3d-1954-49c1-923f-a34af2960cc7
        - link "今日学习" [ref=f1e11] [cursor=pointer]:
          - /url: /student/today?subject=math&studentId=student_37beee3d-1954-49c1-923f-a34af2960cc7
        - link "题卷资料" [ref=f1e12] [cursor=pointer]:
          - /url: /library?subject=math&studentId=student_37beee3d-1954-49c1-923f-a34af2960cc7
      - generic [ref=f1e13]:
        - link "资料管理" [ref=f1e14] [cursor=pointer]:
          - /url: /parent/data
        - button "退出" [ref=f1e15] [cursor=pointer]
    - generic [ref=f1e16]:
      - complementary [ref=f1e17]:
        - text: LEARNING / INSIGHT
        - heading [level=1] [ref=f1e18]:
          - text: 把知识
          - emphasis [ref=f1e19]: 学扎实。
        - paragraph [ref=f1e20]: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
        - list [ref=f1e21]:
          - listitem [ref=f1e22]:
            - generic [ref=f1e23]: "01"
            - text: 确认学习进度
          - listitem [ref=f1e24]:
            - generic [ref=f1e25]: "02"
            - text: 完成一组评测
          - listitem [ref=f1e26]:
            - generic [ref=f1e27]: "03"
            - text: 看懂知识与原因
          - listitem [ref=f1e28]:
            - generic [ref=f1e29]: "04"
            - text: 指导、复测与复盘
        - generic [ref=f1e30]:
          - generic [ref=f1e31]: 匿
          - generic [ref=f1e32]:
            - strong [ref=f1e33]: 匿名指导浏览器
            - generic [ref=f1e34]: 4年级 · 数学
        - button "返回学习进度与历史" [ref=f1e35] [cursor=pointer]
      - generic [ref=f1e36]:
        - generic [ref=f1e37]:
          - text: 04 / 指导 · 验证 · 复盘
          - heading "每天 10 分钟， 把一步走稳。" [level=2] [ref=f1e38]: 每天 10 分钟，把一步走稳。
          - paragraph [ref=f1e39]: 每天 10 分钟，围绕 明确平均对象并把零数据计入份数 先验证再指导；复测后调整。
        - generic [ref=f1e40]:
          - generic [ref=f1e41]: 待家长确认
          - button "确认并开始计划" [ref=f1e42] [cursor=pointer]
        - region "指导计划调整与历史" [ref=f1e43]:
          - generic [ref=f1e44]:
            - generic [ref=f1e45]: 第 1 版
            - generic [ref=f1e46]: 依据评测安排 · 2026/10/25
          - generic [ref=f1e47]:
            - strong [ref=f1e48]: 每次调整，都保留当时的依据。
            - paragraph [ref=f1e49]: 指导依据与当前评测版本一致。
          - region "AI指导说明建议" [ref=f1e50]:
            - generic [ref=f1e52]:
              - text: 说明建议
              - heading "把下一步，写得更具体。" [level=3] [ref=f1e53]
              - paragraph [ref=f1e54]: 对照原计划与建议，再决定是否采用。知识目标、时间、成功标准和复测安排按原计划保留。
            - generic [ref=f1e55]:
              - generic [ref=f1e56]:
                - generic [ref=f1e57]:
                  - generic [ref=f1e58]: 模型
                  - combobox "选择大模型" [ref=f1e59] [cursor=pointer]:
                    - option "Auto · 当前默认模型"
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认" [selected]
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                - paragraph [ref=f1e60]:
                  - generic [ref=f1e61]: DeepSeek V4.1 Flash
                  - generic [ref=f1e62]: 当前渠道：DeepSeek V4 Flash · 快速推理与文档复核
              - button "生成说明建议" [ref=f1e63] [cursor=pointer]
              - button "读取最新状态" [ref=f1e64] [cursor=pointer]
            - status [ref=f1e65]: 原计划保持当前说明；生成完成后可对照，再明确采用。
            - article "当前说明建议" [ref=f1e66]:
              - status [ref=f1e67]:
                - strong [ref=f1e68]: 建议已生成
                - generic [ref=f1e69]: DeepSeek V4.1 Flash · 原计划第1版
              - group [ref=f1e70]:
                - generic "对照原说明与建议，再决定是否采用" [active] [ref=f1e71] [cursor=pointer]
                - generic [ref=f1e72]:
                  - region "原计划说明" [ref=f1e73]:
                    - heading "原说明 · 第1版" [level=4] [ref=f1e74]
                    - paragraph [ref=f1e75]: 每天 10 分钟，围绕 明确平均对象并把零数据计入份数 先验证再指导；复测后调整。
                  - region "模型建议说明" [ref=f1e76]:
                    - heading "建议说明 · DeepSeek V4.1 Flash" [level=4] [ref=f1e77]
                    - paragraph [ref=f1e78]: 合成测试建议：保留未知与观察，按每项行动逐步核查。
                - generic [ref=f1e79]:
                  - heading "先补充证据：明确平均对象并把零数据计入份数" [level=4] [ref=f1e80]
                  - generic [ref=f1e81]:
                    - paragraph [ref=f1e82]:
                      - generic [ref=f1e83]: 原说明
                      - text: 先做两个不同题族的独立小测，观察“按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0”。根据表现决定是否需要讲解。
                    - paragraph [ref=f1e84]:
                      - generic [ref=f1e85]: 建议说明
                      - text: 合成测试建议：先做两个独立小测，记录具体观察，再核查需要哪一步讲解；当前证据与不确定性继续保留。
                  - paragraph [ref=f1e86]: 10分钟 · 成功标准：能从完整记录和参与范围独立选择分母，区分0、未参加与未记录，在对象改变的新题中验证，并经过真实间隔复核。；至少两个新题族独立完成，再安排迁移与延迟验证。 · 原证据 0 条
                - button "采用这份说明" [ref=f1e87] [cursor=pointer]
            - group [ref=f1e88]:
              - generic "这份计划的建议记录" [ref=f1e89] [cursor=pointer]
          - generic [ref=f1e90]:
            - button "调整时间与指导活动" [ref=f1e91] [cursor=pointer]
            - button "查看每次调整 ↗" [ref=f1e92] [cursor=pointer]
        - article [ref=f1e93]:
          - generic [ref=f1e94]: "01"
          - generic [ref=f1e95]:
            - generic [ref=f1e96]: 约 10 分钟 / 0 条依据
            - heading "先补充证据：明确平均对象并把零数据计入份数" [level=3] [ref=f1e97]
            - paragraph [ref=f1e98]: 先做两个不同题族的独立小测，观察“按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0”。根据表现决定是否需要讲解。
            - generic [ref=f1e99]:
              - group [ref=f1e100]:
                - generic "先看讲解和示例" [ref=f1e101] [cursor=pointer]
              - group [ref=f1e102]:
                - generic "家长怎样观察与验证" [ref=f1e103] [cursor=pointer]
            - generic [ref=f1e104]:
              - strong [ref=f1e105]: 怎样算走稳了
              - paragraph [ref=f1e106]: 能从完整记录和参与范围独立选择分母，区分0、未参加与未记录，在对象改变的新题中验证，并经过真实间隔复核。；至少两个新题族独立完成，再安排迁移与延迟验证。
            - button "做新题验证 ↗" [disabled] [ref=f1e107]
        - heading "留出间隔，再看是否保持" [level=3] [ref=f1e108]
        - paragraph [ref=f1e110]: 确认计划后，会安排次日、3日、7日和14日复测。
        - generic [ref=f1e111]:
          - heading "复盘：哪些变化已经得到验证？" [level=3] [ref=f1e112]
          - button "查看前后证据" [ref=f1e113] [cursor=pointer]
    - button "打开学习观察助教" [ref=f1e115] [cursor=pointer]: "?"
  - alert [ref=f1e116]
```

# Test source

```ts
  28  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page)).toContainText('DeepSeek V4.1 Flash');
  29  | });
  30  | 
  31  | test('a dropped plan creation acknowledgement recovers the original request without making another plan',async({page})=>{
  32  |   const f=await setup(page,false);let original:any;
  33  |   await page.route('**/api/diagnostics/students/*/plans',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  34  |   await page.getByRole('button',{name:/制定指导计划/}).click();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  35  |   await page.unroute('**/api/diagnostics/students/*/plans');await page.reload();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  36  |   let created=0;page.on('request',request=>{if(request.method()==='POST'&&/\/students\/[^/]+\/plans$/.test(request.url()))created++;});
  37  |   await page.getByRole('button',{name:'读取原计划创建结果',exact:true}).click();await expect(panel(page)).toBeVisible();expect(created).toBe(0);
  38  |   const plans=await f.call('/diagnostics/students/'+f.studentId+'/plans?subject=math');expect(plans).toHaveLength(1);expect(plans[0].baselineReportVersion).toBe(original.expectedReportVersion);
  39  | });
  40  | 
  41  | test('a dropped suggestion creation acknowledgement survives reload and restores the same saved task',async({page})=>{
  42  |   const f=await setup(page);let original:any;await page.route('**/api/diagnostics/plans/*/model-suggestions',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  43  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  44  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions');await page.reload();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  45  |   await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  46  |   const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].requestKey).toBe(original.requestKey);
  47  | });
  48  | 
  49  | test('a dropped adoption acknowledgement replays its original command and leaves exactly one adopted revision',async({page})=>{
  50  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  51  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  52  |   await page.route('**/api/diagnostics/plans/*/model-suggestions/*/adopt',async route=>{await route.fetch();await route.abort('failed');});
  53  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  54  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions/*/adopt');await page.reload();await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(page.locator('.guidance-version')).toContainText('第 2 版');
  55  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/history')).filter((row:any)=>row.kind==='adjusted')).toHaveLength(1);
  56  | });
  57  | 
  58  | test('cancel and retry preserve the original selected model and plan',async({page})=>{
  59  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');
  60  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  61  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  62  |   await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'valid'});await panel(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');await panel(page).getByRole('button',{name:'重试原模型'}).click();
  63  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].modelId).toBe('deepseek-v4-flash');expect((await f.call('/diagnostics/plans/'+f.plan.id)).source).toBe('rules');
  64  | });
  65  | 
  66  | test('invalid output cannot be adopted and a later explicit retry keeps the original evidence',async({page})=>{
  67  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'invalid-once'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  68  |   await expect(panel(page).getByText('生成未完成',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toHaveCount(0);
  69  |   await panel(page).getByRole('button',{name:'重试原模型'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).actions).toEqual(f.plan.actions);
  70  | });
  71  | 
  72  | test('unavailable browser storage keeps the full original command downloadable',async({page})=>{
  73  |   await page.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.guidance.model.v1.'))throw new DOMException('QA quota','QuotaExceededError');return set.call(this,key,value);};});
  74  |   await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText(/本机暂存不可用/)).toBeVisible();
  75  |   const download=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载原命令副本'}).click();expect((await download).suggestedFilename()).toBe('指导建议原命令副本.json');await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  76  | });
  77  | 
  78  | test('a manually changed plan refuses an older completed suggestion and preserves its original command',async({page})=>{
  79  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  80  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  81  |   await f.call('/diagnostics/plans/'+f.plan.id+'/adjust',{expectedRevision:f.plan.revision,requestKey:crypto.randomUUID(),reason:'合成浏览器中在另一页面明确手工修改活动',minutesPerDay:f.plan.minutesPerDay,acknowledgeReportVersion:f.plan.baselineReportVersion,
  82  |     actions:f.plan.actions.map((action:any)=>({actionId:action.id,minutes:action.minutes,activity:'家长在另一页面确认的观察方案，保留独立小测与验证。'}))});
  83  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByText('采用未获确认，已读取当前建议；原命令保留在副本中。',{exact:true})).toBeVisible();
  84  |   await expect(panel(page).getByRole('button',{name:'采用这份说明',exact:true})).toBeDisabled();const current=await f.call('/diagnostics/plans/'+f.plan.id);expect(current.source).toBe('human');expect(current.revision).toBe(2);
  85  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page).getByRole('button',{name:'下载原命令副本'})).toBeVisible();
  86  | });
  87  | 
  88  | test('a cancelled local wait resumes the server record after navigating away and back',async({page})=>{
  89  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  90  |   await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();let cancellations=0;
  91  |   page.on('request',request=>{if(request.method()==='POST'&&request.url().includes('/model-suggestions/')&&request.url().endsWith('/cancel'))cancellations++;});
  92  |   await panel(page).getByRole('button',{name:'暂停读取状态',exact:true}).click();await expect(panel(page).getByText('已暂停自动读取，可以继续使用原计划，稍后查看建议。',{exact:true})).toBeVisible();
  93  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions[0].status).toBe('running');expect(cancellations).toBe(0);
  94  |   await panel(page).getByRole('button',{name:'继续读取状态',exact:true}).click();await expect(panel(page).getByRole('button',{name:'暂停读取状态',exact:true})).toBeVisible();
  95  |   await page.goto('/learn');await page.goto(f.href);await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  96  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  97  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(1);
  98  | });
  99  | 
  100 | test('forged cross-account cached commands are ignored and never replayed',async({page})=>{
  101 |   const f=await setup(page),key='studyagent.guidance.model.v1.'+encodeURIComponent(f.actor.user.id)+'.'+encodeURIComponent(f.plan.id);
  102 |   await page.evaluate(({key,plan})=>localStorage.setItem(key,JSON.stringify({version:1,ownerId:'another-account',planId:plan.id,studentId:plan.studentId,selectedId:null,rejected:null,
  103 |     pending:{kind:'create',command:{modelId:'deepseek-v4-flash',expectedRevision:1,requestKey:'forged-guidance-request'}}})),{key,plan:f.plan});
  104 |   let sent=0;page.on('request',request=>{if(request.method()==='POST'&&request.url().includes('/model-suggestions'))sent++;});await page.reload();
  105 |   await expect(panel(page).getByText('本机记录与当前账号或计划不匹配，已保留原缓存并忽略恢复。',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toHaveCount(0);expect(sent).toBe(0);
  106 |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(0);
  107 | });
  108 | 
  109 | test('another account cannot open or adopt the prior family guidance',async({page})=>{
  110 |   const first=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  111 |   const second=await setup(page);expect(second.actor.user.id).not.toBe(first.actor.user.id);await expect(panel(page).getByText('建议已生成',{exact:true})).toHaveCount(0);
  112 |   await page.goto('/student/assessment?'+new URLSearchParams({studentId:second.studentId,subject:'math',view:'plan',planId:first.plan.id}));
  113 |   await expect(page.getByRole('alert').filter({hasText:'链接中的指导计划不属于当前孩子'})).toContainText('已返回学习进度。');await expect(panel(page)).toHaveCount(0);
  114 |   await page.goto(first.href);await expect(page.getByRole('alert').filter({hasText:'无法访问链接中的孩子'})).toContainText('已返回当前账号的学习进度。');await expect(panel(page)).toHaveCount(0);
  115 |   expect(new URL(page.url()).searchParams.get('studentId')).toBe(second.studentId);expect(new URL(page.url()).searchParams.has('planId')).toBe(false);
  116 | });
  117 | 
  118 | for(const width of [390,768,1440])test('guidance comparisons and actions fit at '+width,async({page})=>{
  119 |   // CI uses the built-in catalog; a local Xiaojiu catalog may shorten this description.
  120 |   await page.route('**/api/ai/models',async route=>{const response=await route.fetch(),body=await response.json();
  121 |     for(const model of body.data.models)if(model.id==='deepseek-v4-flash')model.description='当前渠道：DeepSeek V4 Flash · 快速推理与文档复核';
  122 |     await route.fulfill({response,json:body});});
  123 |   await page.setViewportSize({width,height:1000});await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  124 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await panel(page).getByRole('button',{name:'采用这份说明'}).scrollIntoViewIfNeeded();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toBeVisible();
  125 |   const layout=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,
  126 |     overflow:[...document.querySelectorAll<HTMLElement>('body *')].filter(element=>element.getBoundingClientRect().right>innerWidth+1)
  127 |       .slice(0,12).map(element=>({tag:element.tagName,className:element.className,width:element.getBoundingClientRect().width,scrollWidth:element.scrollWidth}))}));
> 128 |   expect(layout.scrollWidth,JSON.stringify(layout)).toBeLessThanOrEqual(layout.width+1);if(!process.env.CI)await page.screenshot({path:evidence+'/comparison-'+width+'.png',fullPage:true});
      |                                                     ^ Error: {"width":768,"scrollWidth":807,"overflow":[{"tag":"LABEL","className":"","width":484.796875,"scrollWidth":485},{"tag":"SELECT","className":"","width":459.515625,"scrollWidth":460},{"tag":"P","className":"","width":484.796875,"scrollWidth":485},{"tag":"SPAN","className":"","width":310.796875,"scrollWidth":311}]}
  129 | });
  130 | 
```