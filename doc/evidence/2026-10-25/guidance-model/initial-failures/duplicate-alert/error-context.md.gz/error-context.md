# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: guidance-model.spec.ts >> another account cannot open or adopt the prior family guidance
- Location: tests\e2e\guidance-model.spec.ts:104:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "链接中的指导计划不属于当前孩子，已返回学习进度。"
Error: strict mode violation: getByRole('alert') resolved to 2 elements:
    1) <div role="alert" class="studio-error">…</div> aka getByText('链接中的指导计划不属于当前孩子，已返回学习进度。×')
    2) <div role="alert" aria-live="assertive" id="__next-route-announcer__"></div> aka locator('[id="__next-route-announcer__"]')

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 15000ms
  - waiting for getByRole('alert')
    2 × locator resolved to <div role="alert" aria-live="assertive" id="__next-route-announcer__"></div>
      - unexpected value ""

```

# Page snapshot

```yaml
- generic [active] [ref=f4e1]:
  - main [ref=f4e2]:
    - generic [ref=f4e3]:
      - link "学习观察室" [ref=f4e4] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f4e5]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f4e6]:
        - link "学习首页" [ref=f4e7] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_f9f24450-5c95-4e01-be4e-16305a86d672
        - link "学习工作台" [ref=f4e8] [cursor=pointer]:
          - /url: /studio?subject=math&student=student_f9f24450-5c95-4e01-be4e-16305a86d672
        - link "家长空间" [ref=f4e9] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math&studentId=student_f9f24450-5c95-4e01-be4e-16305a86d672
        - link "知识诊断" [ref=f4e10] [cursor=pointer]:
          - /url: /student/assessment?subject=math&studentId=student_f9f24450-5c95-4e01-be4e-16305a86d672
        - link "今日学习" [ref=f4e11] [cursor=pointer]:
          - /url: /student/today?subject=math&studentId=student_f9f24450-5c95-4e01-be4e-16305a86d672
        - link "题卷资料" [ref=f4e12] [cursor=pointer]:
          - /url: /library?subject=math&studentId=student_f9f24450-5c95-4e01-be4e-16305a86d672
      - generic [ref=f4e13]:
        - link "资料管理" [ref=f4e14] [cursor=pointer]:
          - /url: /parent/data
        - button "退出" [ref=f4e15] [cursor=pointer]
    - generic [ref=f4e16]:
      - complementary [ref=f4e17]:
        - text: LEARNING / INSIGHT
        - heading [level=1] [ref=f4e18]:
          - text: 把知识
          - emphasis [ref=f4e19]: 学扎实。
        - paragraph [ref=f4e20]: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
        - list [ref=f4e21]:
          - listitem [ref=f4e22]:
            - generic [ref=f4e23]: "01"
            - text: 确认学习进度
          - listitem [ref=f4e24]:
            - generic [ref=f4e25]: "02"
            - text: 完成一组评测
          - listitem [ref=f4e26]:
            - generic [ref=f4e27]: "03"
            - text: 看懂知识与原因
          - listitem [ref=f4e28]:
            - generic [ref=f4e29]: "04"
            - text: 指导、复测与复盘
        - generic [ref=f4e30]:
          - generic [ref=f4e31]: 匿
          - generic [ref=f4e32]:
            - strong [ref=f4e33]: 匿名指导浏览器
            - generic [ref=f4e34]: 4年级 · 数学
      - generic [ref=f4e35]:
        - alert [ref=f4e36]:
          - text: 链接中的指导计划不属于当前孩子，已返回学习进度。
          - button "收起提示" [ref=f4e37] [cursor=pointer]: ×
        - generic [ref=f4e38]:
          - text: 01 / 学习起点
          - heading "先告诉我们，学到哪里了。" [level=2] [ref=f4e39]
          - paragraph [ref=f4e40]: 只测已学内容。还没有测到的知识点，会保留为未知。
        - generic [ref=f4e41]:
          - generic [ref=f4e42]:
            - text: 孩子
            - combobox "孩子" [ref=f4e43]:
              - option "匿名指导浏览器" [selected]
          - generic [ref=f4e44]:
            - text: 当前年级
            - combobox "当前年级" [ref=f4e45]:
              - option "1年级"
              - option "2年级"
              - option "3年级"
              - option "4年级" [selected]
              - option "5年级"
              - option "6年级"
          - generic [ref=f4e46]:
            - text: 学期
            - combobox "学期" [ref=f4e47]:
              - option "上学期" [selected]
              - option "下学期"
          - generic [ref=f4e48]:
            - text: 每次时间
            - combobox "每次时间" [ref=f4e49]:
              - option "5分钟"
              - option "10分钟" [selected]
              - option "15分钟"
              - option "20分钟"
              - option "30分钟"
        - group "学科" [ref=f4e50]:
          - button "数学" [pressed] [ref=f4e51] [cursor=pointer]
          - button "语文" [ref=f4e52] [cursor=pointer]
          - button "英语" [ref=f4e53] [cursor=pointer]
        - region [ref=f4e54]:
          - heading "正在学哪一本，学到了哪里" [level=3] [ref=f4e56]
          - button "使用本年级原创能力路径 →" [ref=f4e57] [cursor=pointer]
          - generic [ref=f4e58]:
            - text: 教材或能力路径
            - combobox "教材或能力路径" [ref=f4e59]:
              - option "按已学知识点确认 · 手动填写教材" [selected]
              - option "原创数学能力路径 · 4年级上学期"
              - option "人教版 · 4年级上学期"
              - option "冀教版 · 4年级上学期"
              - option "北京版 · 4年级上学期"
              - option "北师大版 · 4年级上学期"
              - option "苏教版 · 4年级上学期"
              - option "西师版 · 4年级上学期"
              - option "青岛五四制 · 4年级上学期"
              - option "青岛版六三制 · 4年级上学期"
              - option "人教版 · （根据2022年版课程标准修订）义务教育教科书 · 数学四年级上册"
              - option "苏教版 · （根据2022年版课程标准修订）义务教育教科书·数学四年级上册"
              - option "北京版 · （根据2022年版课程标准修订）义务教育教科书·数学四年级上册"
              - option "西南大学版 · （根据2022年版课程标准修订）义务教育教科书·数学四年级上册"
              - option "青岛版 · （根据2022年版课程标准修订）义务教育教科书·数学四年级上册"
              - option "冀教版 · （根据2022年版课程标准修订）义务教育教科书·数学四年级上册"
              - option "北师大版 · （根据2022年版课程标准修订）义务教育教科书·数学四年级上册"
          - generic [ref=f4e60]:
            - text: 教材版本
            - textbox "教材版本" [ref=f4e61]:
              - /placeholder: 填写孩子实际使用的教材版本
              - text: 原创能力路径
        - generic [ref=f4e62]:
          - heading "勾选已经学过的知识点" [level=3] [ref=f4e63]
          - button "选择本年级能力点" [ref=f4e64] [cursor=pointer]
        - generic [ref=f4e65]:
          - group "1年级 · 前期基础" [ref=f4e66]:
            - generic [ref=f4e68] [cursor=pointer]:
              - checkbox "10以内的数分解 把一个整体分成两个部分，确定缺少的部分" [ref=f4e69]
              - generic [ref=f4e70]:
                - strong [ref=f4e71]: 10以内的数分解
                - generic [ref=f4e72]: 把一个整体分成两个部分，确定缺少的部分
            - generic [ref=f4e73] [cursor=pointer]:
              - checkbox "20以内加法合并 将两个部分合并，确定总数" [ref=f4e74]
              - generic [ref=f4e75]:
                - strong [ref=f4e76]: 20以内加法合并
                - generic [ref=f4e77]: 将两个部分合并，确定总数
            - generic [ref=f4e78] [cursor=pointer]:
              - checkbox "20以内减法求剩余 从总数中去掉一部分，求剩余数量" [ref=f4e79]
              - generic [ref=f4e80]:
                - strong [ref=f4e81]: 20以内减法求剩余
                - generic [ref=f4e82]: 从总数中去掉一部分，求剩余数量
            - generic [ref=f4e83] [cursor=pointer]:
              - checkbox "按一一对应计数 将每个对象计入一次，确定集合基数" [ref=f4e84]
              - generic [ref=f4e85]:
                - strong [ref=f4e86]: 按一一对应计数
                - generic [ref=f4e87]: 将每个对象计入一次，确定集合基数
            - generic [ref=f4e88] [cursor=pointer]:
              - checkbox "20以内数量比较 比较两个不相等的数量并确定较大的数" [ref=f4e89]
              - generic [ref=f4e90]:
                - strong [ref=f4e91]: 20以内数量比较
                - generic [ref=f4e92]: 比较两个不相等的数量并确定较大的数
            - generic [ref=f4e93] [cursor=pointer]:
              - checkbox "位置序数与数量区分 根据从左或从右的指定方向确定序位" [ref=f4e94]
              - generic [ref=f4e95]:
                - strong [ref=f4e96]: 位置序数与数量区分
                - generic [ref=f4e97]: 根据从左或从右的指定方向确定序位
            - generic [ref=f4e98] [cursor=pointer]:
              - checkbox "相邻整数关系 确定给定整数前面或后面的一个数" [ref=f4e99]
              - generic [ref=f4e100]:
                - strong [ref=f4e101]: 相邻整数关系
                - generic [ref=f4e102]: 确定给定整数前面或后面的一个数
            - generic [ref=f4e103] [cursor=pointer]:
              - checkbox "十和一的组成 把十个一看作一个十，合成两位数" [ref=f4e104]
              - generic [ref=f4e105]:
                - strong [ref=f4e106]: 十和一的组成
                - generic [ref=f4e107]: 把十个一看作一个十，合成两位数
            - generic [ref=f4e108] [cursor=pointer]:
              - checkbox "凑成十的补数 由已知部分找出合成十的另一部分" [ref=f4e109]
              - generic [ref=f4e110]:
                - strong [ref=f4e111]: 凑成十的补数
                - generic [ref=f4e112]: 由已知部分找出合成十的另一部分
            - generic [ref=f4e113] [cursor=pointer]:
              - checkbox "由和求未知加数 从已知总数与一部分确定另一部分" [ref=f4e114]
              - generic [ref=f4e115]:
                - strong [ref=f4e116]: 由和求未知加数
                - generic [ref=f4e117]: 从已知总数与一部分确定另一部分
            - generic [ref=f4e118] [cursor=pointer]:
              - checkbox "两个数量的相差关系 求一个数量比另一个多或少的数量" [ref=f4e119]
              - generic [ref=f4e120]:
                - strong [ref=f4e121]: 两个数量的相差关系
                - generic [ref=f4e122]: 求一个数量比另一个多或少的数量
            - generic [ref=f4e123] [cursor=pointer]:
              - checkbox "20以内连加连减的顺序 从左到右逐步计算没有括号的加减式" [ref=f4e124]
              - generic [ref=f4e125]:
                - strong [ref=f4e126]: 20以内连加连减的顺序
                - generic [ref=f4e127]: 从左到右逐步计算没有括号的加减式
            - generic [ref=f4e128] [cursor=pointer]:
              - checkbox "按边角特征识别平面图形 根据明确的边角条件识别图形" [ref=f4e129]
              - generic [ref=f4e130]:
                - strong [ref=f4e131]: 按边角特征识别平面图形
                - generic [ref=f4e132]: 根据明确的边角条件识别图形
            - generic [ref=f4e133] [cursor=pointer]:
              - checkbox "按表面特征识别立体 根据面的形状识别常见立体图形" [ref=f4e134]
              - generic [ref=f4e135]:
                - strong [ref=f4e136]: 按表面特征识别立体
                - generic [ref=f4e137]: 根据面的形状识别常见立体图形
            - generic [ref=f4e138] [cursor=pointer]:
              - checkbox "整时的时针与分针 由整点时钟的指针位置确定小时数" [ref=f4e139]
              - generic [ref=f4e140]:
                - strong [ref=f4e141]: 整时的时针与分针
                - generic [ref=f4e142]: 由整点时钟的指针位置确定小时数
            - generic [ref=f4e143] [cursor=pointer]:
              - checkbox "元角十进换算 依据1元等于10角进行单步换算" [ref=f4e144]
              - generic [ref=f4e145]:
                - strong [ref=f4e146]: 元角十进换算
                - generic [ref=f4e147]: 依据1元等于10角进行单步换算
          - group "2年级 · 前期基础" [ref=f4e148]:
            - generic [ref=f4e150] [cursor=pointer]:
              - checkbox "十进制位值换算 说明十位和个位表示的数量，并进行换算" [ref=f4e151]
              - generic [ref=f4e152]:
                - strong [ref=f4e153]: 十进制位值换算
                - generic [ref=f4e154]: 说明十位和个位表示的数量，并进行换算
            - generic [ref=f4e155] [cursor=pointer]:
              - checkbox "判断个位是否需要退位 比较被减数与减数个位，判断是否需要向十位退位" [ref=f4e156]
              - generic [ref=f4e157]:
                - strong [ref=f4e158]: 判断个位是否需要退位
                - generic [ref=f4e159]: 比较被减数与减数个位，判断是否需要向十位退位
            - generic [ref=f4e160] [cursor=pointer]:
              - checkbox "退一作十的换算 十位退去1后，给个位补上10个一" [ref=f4e161]
              - generic [ref=f4e162]:
                - strong [ref=f4e163]: 退一作十的换算
                - generic [ref=f4e164]: 十位退去1后，给个位补上10个一
            - generic [ref=f4e165] [cursor=pointer]:
              - checkbox "乘法等组关系 根据相同组数与每组数量确定总量" [ref=f4e166]
              - generic [ref=f4e167]:
                - strong [ref=f4e168]: 乘法等组关系
                - generic [ref=f4e169]: 根据相同组数与每组数量确定总量
            - generic [ref=f4e170] [cursor=pointer]:
              - checkbox "平均分与除法 将整体平均分成若干份，求每份数量" [ref=f4e171]
              - generic [ref=f4e172]:
                - strong [ref=f4e173]: 平均分与除法
                - generic [ref=f4e174]: 将整体平均分成若干份，求每份数量
            - generic [ref=f4e175] [cursor=pointer]:
              - checkbox "两位数加法满十进一 个位合并满十后向十位进一" [ref=f4e176]
              - generic [ref=f4e177]:
                - strong [ref=f4e178]: 两位数加法满十进一
                - generic [ref=f4e179]: 个位合并满十后向十位进一
            - generic [ref=f4e180] [cursor=pointer]:
              - checkbox "两位数退位减法 个位不够减时退一作十，再完成减法" [ref=f4e181]
              - generic [ref=f4e182]:
                - strong [ref=f4e183]: 两位数退位减法
                - generic [ref=f4e184]: 个位不够减时退一作十，再完成减法
            - generic [ref=f4e185] [cursor=pointer]:
              - checkbox "由积求未知因数 利用等组关系确定缺少的每组数或组数" [ref=f4e186]
              - generic [ref=f4e187]:
                - strong [ref=f4e188]: 由积求未知因数
                - generic [ref=f4e189]: 利用等组关系确定缺少的每组数或组数
            - generic [ref=f4e190] [cursor=pointer]:
              - checkbox "一个量是另一个的几倍 把较小数量作为一份求倍数" [ref=f4e191]
              - generic [ref=f4e192]:
                - strong [ref=f4e193]: 一个量是另一个的几倍
                - generic [ref=f4e194]: 把较小数量作为一份求倍数
            - generic [ref=f4e195] [cursor=pointer]:
              - checkbox "米与厘米换算 依据1米等于100厘米在整米和厘米间换算" [ref=f4e196]
              - generic [ref=f4e197]:
                - strong [ref=f4e198]: 米与厘米换算
                - generic [ref=f4e199]: 依据1米等于100厘米在整米和厘米间换算
            - generic [ref=f4e200] [cursor=pointer]:
              - checkbox "时与分的换算 依据1时等于60分完成整时换算" [ref=f4e201]
              - generic [ref=f4e202]:
                - strong [ref=f4e203]: 时与分的换算
                - generic [ref=f4e204]: 依据1时等于60分完成整时换算
            - generic [ref=f4e205] [cursor=pointer]:
              - checkbox "钟面分针格与分钟 根据分针所在数字换算分钟" [ref=f4e206]
              - generic [ref=f4e207]:
                - strong [ref=f4e208]: 钟面分针格与分钟
                - generic [ref=f4e209]: 根据分针所在数字换算分钟
            - generic [ref=f4e210] [cursor=pointer]:
              - checkbox "分类计数表读数 从含类别和数量的文本表格中取出指定类别数量" [ref=f4e211]
              - generic [ref=f4e212]:
                - strong [ref=f4e213]: 分类计数表读数
                - generic [ref=f4e214]: 从含类别和数量的文本表格中取出指定类别数量
            - generic [ref=f4e215] [cursor=pointer]:
              - checkbox "重复排列的周期 依据完整重复节确定指定位置的对象" [ref=f4e216]
              - generic [ref=f4e217]:
                - strong [ref=f4e218]: 重复排列的周期
                - generic [ref=f4e219]: 依据完整重复节确定指定位置的对象
            - generic [ref=f4e220] [cursor=pointer]:
              - checkbox "东南西北的相对方位 根据面向的方向确定相反方向" [ref=f4e221]
              - generic [ref=f4e222]:
                - strong [ref=f4e223]: 东南西北的相对方位
                - generic [ref=f4e224]: 根据面向的方向确定相反方向
          - group "3年级 · 前期基础" [ref=f4e225]:
            - generic [ref=f4e227] [cursor=pointer]:
              - checkbox "多位数乘一位数 按数位分解并合并部分积" [ref=f4e228]
              - generic [ref=f4e229]:
                - strong [ref=f4e230]: 多位数乘一位数
                - generic [ref=f4e231]: 按数位分解并合并部分积
            - generic [ref=f4e232] [cursor=pointer]:
              - checkbox "多位数除以一位数 按位分配，确定没有余数时的商" [ref=f4e233]
              - generic [ref=f4e234]:
                - strong [ref=f4e235]: 多位数除以一位数
                - generic [ref=f4e236]: 按位分配，确定没有余数时的商
            - generic [ref=f4e237] [cursor=pointer]:
              - checkbox "长方形周长的边界关系 将长方形四条边相加，区别周长与面积" [ref=f4e238]
              - generic [ref=f4e239]:
                - strong [ref=f4e240]: 长方形周长的边界关系
                - generic [ref=f4e241]: 将长方形四条边相加，区别周长与面积
            - generic [ref=f4e242] [cursor=pointer]:
              - checkbox "万以内整数位值比较 先比较最高不同数位以确定较大整数" [ref=f4e243]
              - generic [ref=f4e244]:
                - strong [ref=f4e245]: 万以内整数位值比较
                - generic [ref=f4e246]: 先比较最高不同数位以确定较大整数
            - generic [ref=f4e247] [cursor=pointer]:
              - checkbox "三位数连续进位加法 逐位合并并传递进位" [ref=f4e248]
              - generic [ref=f4e249]:
                - strong [ref=f4e250]: 三位数连续进位加法
                - generic [ref=f4e251]: 逐位合并并传递进位
            - generic [ref=f4e252] [cursor=pointer]:
              - checkbox "三位数连续退位减法 相邻数位借位后求差" [ref=f4e253]
              - generic [ref=f4e254]:
                - strong [ref=f4e255]: 三位数连续退位减法
                - generic [ref=f4e256]: 相邻数位借位后求差
            - generic [ref=f4e257] [cursor=pointer]:
              - checkbox "有余数除法求余数 按每组数量分组，求不足一组的剩余量" [ref=f4e258]
              - generic [ref=f4e259]:
                - strong [ref=f4e260]: 有余数除法求余数
                - generic [ref=f4e261]: 按每组数量分组，求不足一组的剩余量
            - generic [ref=f4e262] [cursor=pointer]:
              - checkbox "乘除先于加减 识别并先计算不带括号式子中的乘除部分" [ref=f4e263]
              - generic [ref=f4e264]:
                - strong [ref=f4e265]: 乘除先于加减
                - generic [ref=f4e266]: 识别并先计算不带括号式子中的乘除部分
            - generic [ref=f4e267] [cursor=pointer]:
              - checkbox "正方形周长 将四条相等的边合计" [ref=f4e268]
              - generic [ref=f4e269]:
                - strong [ref=f4e270]: 正方形周长
                - generic [ref=f4e271]: 将四条相等的边合计
            - generic [ref=f4e272] [cursor=pointer]:
              - checkbox "长方形面积 以单位正方形覆盖行数和列数求面积" [ref=f4e273]
              - generic [ref=f4e274]:
                - strong [ref=f4e275]: 长方形面积
                - generic [ref=f4e276]: 以单位正方形覆盖行数和列数求面积
            - generic [ref=f4e277] [cursor=pointer]:
              - checkbox "同日经过时间 将开始结束时刻转换成分钟再求差" [ref=f4e278]
              - generic [ref=f4e279]:
                - strong [ref=f4e280]: 同日经过时间
                - generic [ref=f4e281]: 将开始结束时刻转换成分钟再求差
            - generic [ref=f4e282] [cursor=pointer]:
              - checkbox "千克与克换算 依据1千克等于1000克转换数量" [ref=f4e283]
              - generic [ref=f4e284]:
                - strong [ref=f4e285]: 千克与克换算
                - generic [ref=f4e286]: 依据1千克等于1000克转换数量
            - generic [ref=f4e287] [cursor=pointer]:
              - checkbox "单位分数与平均分 由平均分的总份数写出一份占整体的分数" [ref=f4e288]
              - generic [ref=f4e289]:
                - strong [ref=f4e290]: 单位分数与平均分
                - generic [ref=f4e291]: 由平均分的总份数写出一份占整体的分数
            - generic [ref=f4e292] [cursor=pointer]:
              - checkbox "同分母分数比较 等分单位相同的情况下比较所取份数" [ref=f4e293]
              - generic [ref=f4e294]:
                - strong [ref=f4e295]: 同分母分数比较
                - generic [ref=f4e296]: 等分单位相同的情况下比较所取份数
            - generic [ref=f4e297] [cursor=pointer]:
              - checkbox "一位两位小数的位值 把十分之一与百分之一的份数对应到小数位置" [ref=f4e298]
              - generic [ref=f4e299]:
                - strong [ref=f4e300]: 一位两位小数的位值
                - generic [ref=f4e301]: 把十分之一与百分之一的份数对应到小数位置
            - generic [ref=f4e302] [cursor=pointer]:
              - checkbox "相邻面积单位换算 区分长度进率与面积进率，按100换算" [ref=f4e303]
              - generic [ref=f4e304]:
                - strong [ref=f4e305]: 相邻面积单位换算
                - generic [ref=f4e306]: 区分长度进率与面积进率，按100换算
            - generic [ref=f4e307] [cursor=pointer]:
              - checkbox "把余下的十换成一并合并个位 在剩余十和原个位已给定时，把全部剩余十换成一并合并原个位，保持未分数量不变" [ref=f4e308]
              - generic [ref=f4e309]:
                - strong [ref=f4e310]: 把余下的十换成一并合并个位
                - generic [ref=f4e311]: 在剩余十和原个位已给定时，把全部剩余十换成一并合并原个位，保持未分数量不变
          - group "4年级" [ref=f4e312]:
            - generic [ref=f4e314] [cursor=pointer]:
              - checkbox "两位数乘两位数 将乘数分解成十位和个位分别求积再合并" [ref=f4e315]
              - generic [ref=f4e316]:
                - strong [ref=f4e317]: 两位数乘两位数
                - generic [ref=f4e318]: 将乘数分解成十位和个位分别求积再合并
            - generic [ref=f4e319] [cursor=pointer]:
              - checkbox "余数与除数的约束 将不能整分的数量分组，确定余数且检验余数小于除数" [ref=f4e320]
              - generic [ref=f4e321]:
                - strong [ref=f4e322]: 余数与除数的约束
                - generic [ref=f4e323]: 将不能整分的数量分组，确定余数且检验余数小于除数
            - generic [ref=f4e324] [cursor=pointer]:
              - checkbox "长方形面积的覆盖关系 用长乘宽确定单位正方形的数量" [ref=f4e325]
              - generic [ref=f4e326]:
                - strong [ref=f4e327]: 长方形面积的覆盖关系
                - generic [ref=f4e328]: 用长乘宽确定单位正方形的数量
            - generic [ref=f4e329] [cursor=pointer]:
              - checkbox "大数的数级与位值 由万级和个级的数量合成整数" [ref=f4e330]
              - generic [ref=f4e331]:
                - strong [ref=f4e332]: 大数的数级与位值
                - generic [ref=f4e333]: 由万级和个级的数量合成整数
            - generic [ref=f4e334] [cursor=pointer]:
              - checkbox "四舍五入到千位 观察百位数字确定保留千位的近似整数" [ref=f4e335]
              - generic [ref=f4e336]:
                - strong [ref=f4e337]: 四舍五入到千位
                - generic [ref=f4e338]: 观察百位数字确定保留千位的近似整数
            - generic [ref=f4e339] [cursor=pointer]:
              - checkbox "三位数乘两位数 按十位和个位分解乘数并合并部分积" [ref=f4e340]
              - generic [ref=f4e341]:
                - strong [ref=f4e342]: 三位数乘两位数
                - generic [ref=f4e343]: 按十位和个位分解乘数并合并部分积
            - generic [ref=f4e344] [cursor=pointer]:
              - checkbox "除数是两位数的整除 试商并用乘法检验商" [ref=f4e345]
              - generic [ref=f4e346]:
                - strong [ref=f4e347]: 除数是两位数的整除
                - generic [ref=f4e348]: 试商并用乘法检验商
            - generic [ref=f4e349] [cursor=pointer]:
              - checkbox "带括号的四则顺序 先求括号中的结果，再进行乘除" [ref=f4e350]
              - generic [ref=f4e351]:
                - strong [ref=f4e352]: 带括号的四则顺序
                - generic [ref=f4e353]: 先求括号中的结果，再进行乘除
            - generic [ref=f4e354] [cursor=pointer]:
              - checkbox "乘法分配律的对应因数 在乘法分配的两种表示中对应相同因数" [ref=f4e355]
              - generic [ref=f4e356]:
                - strong [ref=f4e357]: 乘法分配律的对应因数
                - generic [ref=f4e358]: 在乘法分配的两种表示中对应相同因数
            - generic [ref=f4e359] [cursor=pointer]:
              - checkbox "小数位值比较 按整数部分、十分位、百分位依次比较小数" [ref=f4e360]
              - generic [ref=f4e361]:
                - strong [ref=f4e362]: 小数位值比较
                - generic [ref=f4e363]: 按整数部分、十分位、百分位依次比较小数
            - generic [ref=f4e364] [cursor=pointer]:
              - checkbox "小数减法数位对齐 将相同小数数位对齐再相减" [ref=f4e365]
              - generic [ref=f4e366]:
                - strong [ref=f4e367]: 小数减法数位对齐
                - generic [ref=f4e368]: 将相同小数数位对齐再相减
            - generic [ref=f4e369] [cursor=pointer]:
              - checkbox "锐角直角钝角分类 按与90度和180度的关系判断角的类型" [ref=f4e370]
              - generic [ref=f4e371]:
                - strong [ref=f4e372]: 锐角直角钝角分类
                - generic [ref=f4e373]: 按与90度和180度的关系判断角的类型
            - generic [ref=f4e374] [cursor=pointer]:
              - checkbox "三角形内角和 用180度减去已知两个内角求第三角" [ref=f4e375]
              - generic [ref=f4e376]:
                - strong [ref=f4e377]: 三角形内角和
                - generic [ref=f4e378]: 用180度减去已知两个内角求第三角
            - generic [ref=f4e379] [cursor=pointer]:
              - checkbox "平均数的总量等分 先合计总量再按数据个数平均" [ref=f4e380]
              - generic [ref=f4e381]:
                - strong [ref=f4e382]: 平均数的总量等分
                - generic [ref=f4e383]: 先合计总量再按数据个数平均
            - generic [ref=f4e384] [cursor=pointer]:
              - checkbox "两组统计数量的差 从分类计数中选择正确两类再求差" [ref=f4e385]
              - generic [ref=f4e386]:
                - strong [ref=f4e387]: 两组统计数量的差
                - generic [ref=f4e388]: 从分类计数中选择正确两类再求差
            - generic [ref=f4e389] [cursor=pointer]:
              - checkbox "明确平均对象并把零数据计入份数 按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0" [checked] [ref=f4e390]
              - generic [ref=f4e391]:
                - strong [ref=f4e392]: 明确平均对象并把零数据计入份数
                - generic [ref=f4e393]: 按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0
        - generic [ref=f4e395]:
          - text: 这次想怎样了解孩子
          - combobox "这次想怎样了解孩子" [ref=f4e396]:
            - option "起点评测 · 了解当前基础" [selected]
            - option "单元评测 · 观察本单元知识"
            - option "阶段回顾 · 在已学范围抽样"
            - option "三分钟微测 · 只看当前目标"
        - generic [ref=f4e397]:
          - generic [ref=f4e398] [cursor=pointer]:
            - checkbox "按这次作答逐步选择核查顺序" [checked] [ref=f4e399]
            - text: 按这次作答逐步选择核查顺序
          - generic [ref=f4e400] [cursor=pointer]:
            - checkbox "加入必要的前置基础核查，先在预览中确认" [checked] [ref=f4e401]
            - text: 加入必要的前置基础核查，先在预览中确认
          - paragraph [ref=f4e402]: 基础核查会单独标明。范围与题量确认后保持一致，选题顺序会在结束记录中保留。
        - generic [ref=f4e403]:
          - generic [ref=f4e404]:
            - strong [ref=f4e405]: 已选 1 个点
            - generic [ref=f4e406]:
              - text: 本组最多
              - combobox "本组最多" [ref=f4e407]:
                - option "2题"
                - option "4题"
                - option "6题"
                - option "8题"
                - option "12题" [selected]
                - option "20题"
                - option "30题"
          - button "确认进度，查看题组" [ref=f4e408] [cursor=pointer]:
            - text: 确认进度，查看题组
            - generic [aria-hidden] [ref=f4e409]: ↗
        - paragraph [ref=f4e410]: 题量由时长和可用题目共同决定。基础题为规则估计材料，教材完整覆盖与标准化常模尚需独立验证。
        - generic [ref=f4e411]:
          - heading "继续上一次，或回看报告" [level=3] [ref=f4e412]
          - button "2026/10/25 · 4年级 查看报告 ↗" [ref=f4e413] [cursor=pointer]:
            - generic [ref=f4e414]: 2026/10/25 · 4年级
            - strong [ref=f4e415]: 查看报告 ↗
    - button "打开学习观察助教" [ref=f4e417] [cursor=pointer]: "?"
  - alert [ref=f4e418]
```

# Test source

```ts
  8   |   const studentId=(await call('/students',{nickname:'匿名指导浏览器',grade:4,preferredSessionMinutes:10,defaultVersionMap:{math:'',chinese:'',english:''}})).profile.id,atom='atomic:math:averagecount';
  9   |   await call('/students/'+studentId+'/learning-scope',{subject:'math',grade:4,term:'upper',textbookVolumeId:null,textbookVersion:'原创能力路径',learnedAtomIds:[atom],currentAtomId:atom,minutesPerSession:10},'PUT');
  10  |   const baseline=await call('/diagnostics/sessions',{studentId,subject:'math',intent:'baseline',targetAtomIds:[atom],includePrerequisites:false,maxItems:4});
  11  |   for(const item of baseline.items)await call('/diagnostics/sessions/'+baseline.id+'/responses',{itemId:item.id,disposition:'skip',elapsedMs:100});await call('/diagnostics/sessions/'+baseline.id+'/complete',{});
  12  |   const plan=makePlan?await call('/diagnostics/students/'+studentId+'/plans',{baselineSessionId:baseline.id,minutesPerDay:10,useAi:false,requestKey:crypto.randomUUID(),expectedReportVersion:1}):null;
  13  |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  |   const href='/student/assessment?'+new URLSearchParams({studentId,subject:'math',...(plan?{view:'plan',planId:plan.id}:{session:baseline.id})});await page.goto(href);
  15  |   if(plan)await expect(page.getByRole('region',{name:'AI指导说明建议'})).toBeVisible();else await expect(page.getByRole('heading',{name:'从知识点看清下一步。'})).toBeVisible();
  16  |   return {actor,studentId,baseline,plan,call,href};
  17  | }
  18  | const panel=(page:Page)=>page.getByRole('region',{name:'AI指导说明建议'});
  19  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  20  | 
  21  | test('the original rule plan stays usable and an explicitly reviewed model description changes only its text',async({page})=>{
  22  |   const f=await setup(page);await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  23  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).summary).toBe(f.plan.summary);
  24  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await expect(panel(page).getByRole('region',{name:'原计划说明'})).toContainText(f.plan.summary);
  25  |   await expect(panel(page).getByRole('region',{name:'模型建议说明'})).toContainText('合成测试建议');await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();
  26  |   await expect(page.locator('.guidance-version')).toContainText('第 2 版');const adopted=await f.call('/diagnostics/plans/'+f.plan.id);expect(adopted.source).toBe('ai');
  27  |   expect(adopted.actions.map(({activity:_,...action}:any)=>action)).toEqual(f.plan.actions.map(({activity:_,...action}:any)=>action));
  28  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page)).toContainText('DeepSeek V4.1 Flash');
  29  | });
  30  | 
  31  | test('a dropped plan creation acknowledgement recovers the original request without making another plan',async({page})=>{
  32  |   const f=await setup(page,false);let original:any;
  33  |   await page.route('**/api/diagnostics/students/*/plans',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  34  |   await page.getByRole('button',{name:/制定指导计划/}).click();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  35  |   await page.unroute('**/api/diagnostics/students/*/plans');await page.reload();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  36  |   let created=0;page.on('request',request=>{if(request.method()==='POST'&&/\/students\/[^/]+\/plans$/.test(request.url()))created++;});
  37  |   await page.getByRole('button',{name:'读取原计划创建结果',exact:true}).click();await expect(panel(page)).toBeVisible();expect(created).toBe(0);
  38  |   const plans=await f.call('/diagnostics/students/'+f.studentId+'/plans?subject=math');expect(plans).toHaveLength(1);expect(plans[0].baselineReportVersion).toBe(original.expectedReportVersion);
  39  | });
  40  | 
  41  | test('a dropped suggestion creation acknowledgement survives reload and restores the same saved task',async({page})=>{
  42  |   const f=await setup(page);let original:any;await page.route('**/api/diagnostics/plans/*/model-suggestions',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  43  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  44  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions');await page.reload();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  45  |   await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  46  |   const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].requestKey).toBe(original.requestKey);
  47  | });
  48  | 
  49  | test('a dropped adoption acknowledgement replays its original command and leaves exactly one adopted revision',async({page})=>{
  50  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  51  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  52  |   await page.route('**/api/diagnostics/plans/*/model-suggestions/*/adopt',async route=>{await route.fetch();await route.abort('failed');});
  53  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  54  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions/*/adopt');await page.reload();await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(page.locator('.guidance-version')).toContainText('第 2 版');
  55  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/history')).filter((row:any)=>row.kind==='adjusted')).toHaveLength(1);
  56  | });
  57  | 
  58  | test('cancel and retry preserve the original selected model and plan',async({page})=>{
  59  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');
  60  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  61  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  62  |   await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'valid'});await panel(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');await panel(page).getByRole('button',{name:'重试原模型'}).click();
  63  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].modelId).toBe('deepseek-v4-flash');expect((await f.call('/diagnostics/plans/'+f.plan.id)).source).toBe('rules');
  64  | });
  65  | 
  66  | test('invalid output cannot be adopted and a later explicit retry keeps the original evidence',async({page})=>{
  67  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'invalid-once'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  68  |   await expect(panel(page).getByText('生成未完成',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toHaveCount(0);
  69  |   await panel(page).getByRole('button',{name:'重试原模型'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).actions).toEqual(f.plan.actions);
  70  | });
  71  | 
  72  | test('unavailable browser storage keeps the full original command downloadable',async({page})=>{
  73  |   await page.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.guidance.model.v1.'))throw new DOMException('QA quota','QuotaExceededError');return set.call(this,key,value);};});
  74  |   await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText(/本机暂存不可用/)).toBeVisible();
  75  |   const download=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载原命令副本'}).click();expect((await download).suggestedFilename()).toBe('指导建议原命令副本.json');await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  76  | });
  77  | 
  78  | test('a manually changed plan refuses an older completed suggestion and preserves its original command',async({page})=>{
  79  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  80  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  81  |   await f.call('/diagnostics/plans/'+f.plan.id+'/adjust',{expectedRevision:f.plan.revision,requestKey:crypto.randomUUID(),reason:'合成浏览器中在另一页面明确手工修改活动',minutesPerDay:f.plan.minutesPerDay,acknowledgeReportVersion:f.plan.baselineReportVersion,
  82  |     actions:f.plan.actions.map((action:any)=>({actionId:action.id,minutes:action.minutes,activity:'家长在另一页面确认的观察方案，保留独立小测与验证。'}))});
  83  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByText('采用未获确认，已读取当前建议；原命令保留在副本中。',{exact:true})).toBeVisible();
  84  |   await expect(panel(page).getByRole('button',{name:'采用这份说明',exact:true})).toBeDisabled();const current=await f.call('/diagnostics/plans/'+f.plan.id);expect(current.source).toBe('human');expect(current.revision).toBe(2);
  85  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page).getByRole('button',{name:'下载原命令副本'})).toBeVisible();
  86  | });
  87  | 
  88  | test('a cancelled local wait resumes the server record after navigating away and back',async({page})=>{
  89  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  90  |   await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();await page.goto('/learn');await page.goto(f.href);await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  91  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  92  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(1);
  93  | });
  94  | 
  95  | test('forged cross-account cached commands are ignored and never replayed',async({page})=>{
  96  |   const f=await setup(page),key='studyagent.guidance.model.v1.'+encodeURIComponent(f.actor.user.id)+'.'+encodeURIComponent(f.plan.id);
  97  |   await page.evaluate(({key,plan})=>localStorage.setItem(key,JSON.stringify({version:1,ownerId:'another-account',planId:plan.id,studentId:plan.studentId,selectedId:null,rejected:null,
  98  |     pending:{kind:'create',command:{modelId:'deepseek-v4-flash',expectedRevision:1,requestKey:'forged-guidance-request'}}})),{key,plan:f.plan});
  99  |   let sent=0;page.on('request',request=>{if(request.method()==='POST'&&request.url().includes('/model-suggestions'))sent++;});await page.reload();
  100 |   await expect(panel(page).getByText('本机记录与当前账号或计划不匹配，已保留原缓存并忽略恢复。',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toHaveCount(0);expect(sent).toBe(0);
  101 |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(0);
  102 | });
  103 | 
  104 | test('another account cannot open or adopt the prior family guidance',async({page})=>{
  105 |   const first=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  106 |   const second=await setup(page);expect(second.actor.user.id).not.toBe(first.actor.user.id);await expect(panel(page).getByText('建议已生成',{exact:true})).toHaveCount(0);
  107 |   await page.goto('/student/assessment?'+new URLSearchParams({studentId:second.studentId,subject:'math',view:'plan',planId:first.plan.id}));
> 108 |   await expect(page.getByRole('alert')).toContainText('链接中的指导计划不属于当前孩子，已返回学习进度。');await expect(panel(page)).toHaveCount(0);
      |                                         ^ Error: expect(locator).toContainText(expected) failed
  109 |   await page.goto(first.href);await expect(page.getByRole('alert')).toContainText('无法访问链接中的孩子，已返回当前账号的学习进度。');await expect(panel(page)).toHaveCount(0);
  110 |   expect(new URL(page.url()).searchParams.get('studentId')).toBe(second.studentId);expect(new URL(page.url()).searchParams.has('planId')).toBe(false);
  111 | });
  112 | 
  113 | for(const width of [390,768,1440])test('guidance comparisons and actions fit at '+width,async({page})=>{
  114 |   await page.setViewportSize({width,height:1000});await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  115 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await panel(page).getByRole('button',{name:'采用这份说明'}).scrollIntoViewIfNeeded();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toBeVisible();
  116 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/comparison-'+width+'.png',fullPage:true});
  117 | });
  118 | 
```