# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: guidance-model.spec.ts >> cancel and retry preserve the original selected model and plan
- Location: tests\e2e\guidance-model.spec.ts:58:5

# Error details

```
TimeoutError: locator.selectOption: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('region', { name: 'AI指导说明建议' }).getByLabel('选择大模型')
    - locator resolved to <select aria-label="选择大模型">…</select>
  - attempting select option action
    2 × waiting for element to be visible and enabled
      - did not find some options
    - retrying select option action
    - waiting 20ms
    2 × waiting for element to be visible and enabled
      - did not find some options
    - retrying select option action
      - waiting 100ms
    29 × waiting for element to be visible and enabled
       - did not find some options
     - retrying select option action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - link "学习观察室" [ref=f1e4] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f1e5]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f1e6]:
        - link "学习首页" [ref=f1e7] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_0902b463-7459-442a-a670-79aa1642d34e
        - link "学习工作台" [ref=f1e8] [cursor=pointer]:
          - /url: /studio?subject=math&student=student_0902b463-7459-442a-a670-79aa1642d34e
        - link "家长空间" [ref=f1e9] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math&studentId=student_0902b463-7459-442a-a670-79aa1642d34e
        - link "知识诊断" [ref=f1e10] [cursor=pointer]:
          - /url: /student/assessment?subject=math&studentId=student_0902b463-7459-442a-a670-79aa1642d34e
        - link "今日学习" [ref=f1e11] [cursor=pointer]:
          - /url: /student/today?subject=math&studentId=student_0902b463-7459-442a-a670-79aa1642d34e
        - link "题卷资料" [ref=f1e12] [cursor=pointer]:
          - /url: /library?subject=math&studentId=student_0902b463-7459-442a-a670-79aa1642d34e
      - generic [ref=f1e13]:
        - link "资料管理" [ref=f1e14] [cursor=pointer]:
          - /url: /parent/data
        - button "退出" [ref=f1e15] [cursor=pointer]
    - generic [ref=f1e16]:
      - complementary [ref=f1e17]:
        - text: LEARNING / INSIGHT
        - heading [level=1] [ref=f1e18]:
          - text: 把知识
          - emphasis [ref=f1e19]: 学扎实。
        - paragraph [ref=f1e20]: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
        - list [ref=f1e21]:
          - listitem [ref=f1e22]:
            - generic [ref=f1e23]: "01"
            - text: 确认学习进度
          - listitem [ref=f1e24]:
            - generic [ref=f1e25]: "02"
            - text: 完成一组评测
          - listitem [ref=f1e26]:
            - generic [ref=f1e27]: "03"
            - text: 看懂知识与原因
          - listitem [ref=f1e28]:
            - generic [ref=f1e29]: "04"
            - text: 指导、复测与复盘
        - generic [ref=f1e30]:
          - generic [ref=f1e31]: 匿
          - generic [ref=f1e32]:
            - strong [ref=f1e33]: 匿名指导浏览器
            - generic [ref=f1e34]: 4年级 · 数学
        - button "返回学习进度与历史" [ref=f1e35] [cursor=pointer]
      - generic [ref=f1e36]:
        - generic [ref=f1e37]:
          - text: 04 / 指导 · 验证 · 复盘
          - heading "每天 10 分钟， 把一步走稳。" [level=2] [ref=f1e38]: 每天 10 分钟，把一步走稳。
          - paragraph [ref=f1e39]: 每天 10 分钟，围绕 明确平均对象并把零数据计入份数 先验证再指导；复测后调整。
        - generic [ref=f1e40]:
          - generic [ref=f1e41]: 待家长确认
          - button "确认并开始计划" [ref=f1e42] [cursor=pointer]
        - region "指导计划调整与历史" [ref=f1e43]:
          - generic [ref=f1e44]:
            - generic [ref=f1e45]: 第 1 版
            - generic [ref=f1e46]: 依据评测安排 · 2026/10/25
          - generic [ref=f1e47]:
            - strong [ref=f1e48]: 每次调整，都保留当时的依据。
            - paragraph [ref=f1e49]: 指导依据与当前评测版本一致。
          - region "AI指导说明建议" [ref=f1e50]:
            - generic [ref=f1e52]:
              - text: 说明建议
              - heading "把下一步，写得更具体。" [level=3] [ref=f1e53]
              - paragraph [ref=f1e54]: 对照原计划与建议，再决定是否采用。知识目标、时间、成功标准和复测安排按原计划保留。
            - generic [ref=f1e55]:
              - generic [ref=f1e56]:
                - generic [ref=f1e57]:
                  - generic [ref=f1e58]: 模型
                  - combobox "选择大模型" [ref=f1e59] [cursor=pointer]:
                    - option "Auto · 当前默认模型"
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认" [selected]
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                - paragraph [ref=f1e60]:
                  - generic [ref=f1e61]: DeepSeek V4.1 Flash
                  - generic [ref=f1e62]: DeepSeek V4 Flash
              - button "生成说明建议" [ref=f1e63] [cursor=pointer]
              - button "读取最新状态" [ref=f1e64] [cursor=pointer]
            - article "当前说明建议" [ref=f1e65]:
              - status [ref=f1e66]:
                - strong [ref=f1e67]: 已取消
                - generic [ref=f1e68]: DeepSeek V4.1 Flash · 原计划第1版
              - button "重试原模型" [ref=f1e70] [cursor=pointer]
            - group [ref=f1e71]:
              - generic "这份计划的建议记录" [ref=f1e72] [cursor=pointer]
          - generic [ref=f1e73]:
            - button "调整时间与指导活动" [ref=f1e74] [cursor=pointer]
            - button "查看每次调整 ↗" [ref=f1e75] [cursor=pointer]
        - article [ref=f1e76]:
          - generic [ref=f1e77]: "01"
          - generic [ref=f1e78]:
            - generic [ref=f1e79]: 约 10 分钟 / 0 条依据
            - heading "先补充证据：明确平均对象并把零数据计入份数" [level=3] [ref=f1e80]
            - paragraph [ref=f1e81]: 先做两个不同题族的独立小测，观察“按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0”。根据表现决定是否需要讲解。
            - generic [ref=f1e82]:
              - group [ref=f1e83]:
                - generic "先看讲解和示例" [ref=f1e84] [cursor=pointer]
              - group [ref=f1e85]:
                - generic "家长怎样观察与验证" [ref=f1e86] [cursor=pointer]
            - generic [ref=f1e87]:
              - strong [ref=f1e88]: 怎样算走稳了
              - paragraph [ref=f1e89]: 能从完整记录和参与范围独立选择分母，区分0、未参加与未记录，在对象改变的新题中验证，并经过真实间隔复核。；至少两个新题族独立完成，再安排迁移与延迟验证。
            - button "做新题验证 ↗" [disabled] [ref=f1e90]
        - heading "留出间隔，再看是否保持" [level=3] [ref=f1e91]
        - paragraph [ref=f1e93]: 确认计划后，会安排次日、3日、7日和14日复测。
        - generic [ref=f1e94]:
          - heading "复盘：哪些变化已经得到验证？" [level=3] [ref=f1e95]
          - button "查看前后证据" [ref=f1e96] [cursor=pointer]
    - button "打开学习观察助教" [ref=f1e98] [cursor=pointer]: "?"
  - alert [ref=f1e99]
```

# Test source

```ts
  1  | import { expect,test,type Page } from '@playwright/test';
  2  | import { browserEvidence } from './evidence';
  3  | const api=`http://localhost:${process.env.E2E_API_PORT??'4107'}/api`,evidence=browserEvidence('guidance-model');let address=0;
  4  | async function setup(page:Page,makePlan=true) {
  5  |   const suffix=crypto.randomUUID(),principal='guidance-browser-'+suffix+'@local.test',credential='Guidance-QA-'+suffix;
  6  |   const registered=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json','X-Forwarded-For':'198.18.10.'+(++address)},body:JSON.stringify({principal,credential})});expect(registered.status).toBe(201);const actor=(await registered.json()).data;
  7  |   async function call(path:string,body?:unknown,method=body===undefined?'GET':'POST') {const response=await fetch(api+path,{method,headers:{'content-type':'application/json',authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});const result=await response.json();expect(response.ok,JSON.stringify(result.error)).toBe(true);return result.data;}
  8  |   const studentId=(await call('/students',{nickname:'匿名指导浏览器',grade:4,preferredSessionMinutes:10,defaultVersionMap:{math:'',chinese:'',english:''}})).profile.id,atom='atomic:math:averagecount';
  9  |   await call('/students/'+studentId+'/learning-scope',{subject:'math',grade:4,term:'upper',textbookVolumeId:null,textbookVersion:'原创能力路径',learnedAtomIds:[atom],currentAtomId:atom,minutesPerSession:10},'PUT');
  10 |   const baseline=await call('/diagnostics/sessions',{studentId,subject:'math',intent:'baseline',targetAtomIds:[atom],includePrerequisites:false,maxItems:4});
  11 |   for(const item of baseline.items)await call('/diagnostics/sessions/'+baseline.id+'/responses',{itemId:item.id,disposition:'skip',elapsedMs:100});await call('/diagnostics/sessions/'+baseline.id+'/complete',{});
  12 |   const plan=makePlan?await call('/diagnostics/students/'+studentId+'/plans',{baselineSessionId:baseline.id,minutesPerDay:10,useAi:false,requestKey:crypto.randomUUID(),expectedReportVersion:1}):null;
  13 |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14 |   const href='/student/assessment?'+new URLSearchParams({studentId,subject:'math',...(plan?{view:'plan',planId:plan.id}:{session:baseline.id})});await page.goto(href);
  15 |   if(plan)await expect(page.getByRole('region',{name:'AI指导说明建议'})).toBeVisible();else await expect(page.getByRole('heading',{name:'从知识点看清下一步。'})).toBeVisible();
  16 |   return {actor,studentId,baseline,plan,call,href};
  17 | }
  18 | const panel=(page:Page)=>page.getByRole('region',{name:'AI指导说明建议'});
  19 | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  20 | 
  21 | test('the original rule plan stays usable and an explicitly reviewed model description changes only its text',async({page})=>{
  22 |   const f=await setup(page);await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  23 |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).summary).toBe(f.plan.summary);
  24 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await expect(panel(page).getByRole('region',{name:'原计划说明'})).toContainText(f.plan.summary);
  25 |   await expect(panel(page).getByRole('region',{name:'模型建议说明'})).toContainText('合成测试建议');await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();
  26 |   await expect(page.locator('.guidance-version')).toContainText('第 2 版');const adopted=await f.call('/diagnostics/plans/'+f.plan.id);expect(adopted.source).toBe('ai');
  27 |   expect(adopted.actions.map(({activity:_,...action}:any)=>action)).toEqual(f.plan.actions.map(({activity:_,...action}:any)=>action));
  28 |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page)).toContainText('DeepSeek V4.1 Flash');
  29 | });
  30 | 
  31 | test('a dropped plan creation acknowledgement recovers the original request without making another plan',async({page})=>{
  32 |   const f=await setup(page,false);let original:any;
  33 |   await page.route('**/api/diagnostics/students/*/plans',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  34 |   await page.getByRole('button',{name:/制定指导计划/}).click();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  35 |   await page.unroute('**/api/diagnostics/students/*/plans');await page.reload();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  36 |   let created=0;page.on('request',request=>{if(request.method()==='POST'&&/\/students\/[^/]+\/plans$/.test(request.url()))created++;});
  37 |   await page.getByRole('button',{name:'读取原计划创建结果',exact:true}).click();await expect(panel(page)).toBeVisible();expect(created).toBe(0);
  38 |   const plans=await f.call('/diagnostics/students/'+f.studentId+'/plans?subject=math');expect(plans).toHaveLength(1);expect(plans[0].baselineReportVersion).toBe(original.expectedReportVersion);
  39 | });
  40 | 
  41 | test('a dropped suggestion creation acknowledgement survives reload and restores the same saved task',async({page})=>{
  42 |   const f=await setup(page);let original:any;await page.route('**/api/diagnostics/plans/*/model-suggestions',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  43 |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  44 |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions');await page.reload();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  45 |   await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  46 |   const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].requestKey).toBe(original.requestKey);
  47 | });
  48 | 
  49 | test('a dropped adoption acknowledgement replays its original command and leaves exactly one adopted revision',async({page})=>{
  50 |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  51 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  52 |   await page.route('**/api/diagnostics/plans/*/model-suggestions/*/adopt',async route=>{await route.fetch();await route.abort('failed');});
  53 |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  54 |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions/*/adopt');await page.reload();await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(page.locator('.guidance-version')).toContainText('第 2 版');
  55 |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/history')).filter((row:any)=>row.kind==='adjusted')).toHaveLength(1);
  56 | });
  57 | 
  58 | test('cancel and retry preserve the original selected model and plan',async({page})=>{
  59 |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');
  60 |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  61 |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
> 62 |   await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'valid'});await panel(page).getByLabel('选择大模型').selectOption('claude-sonnet-4-6');await panel(page).getByRole('button',{name:'重试原模型'}).click();
     |                                                                                                                   ^ TimeoutError: locator.selectOption: Timeout 15000ms exceeded.
  63 |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].modelId).toBe('deepseek-v4-flash');expect((await f.call('/diagnostics/plans/'+f.plan.id)).source).toBe('rules');
  64 | });
  65 | 
  66 | test('invalid output cannot be adopted and a later explicit retry keeps the original evidence',async({page})=>{
  67 |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'invalid-once'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  68 |   await expect(panel(page).getByText('生成未完成',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toHaveCount(0);
  69 |   await panel(page).getByRole('button',{name:'重试原模型'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).actions).toEqual(f.plan.actions);
  70 | });
  71 | 
  72 | test('unavailable browser storage keeps the full original command downloadable',async({page})=>{
  73 |   await page.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.guidance.model.v1.'))throw new DOMException('QA quota','QuotaExceededError');return set.call(this,key,value);};});
  74 |   await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText(/本机暂存不可用/)).toBeVisible();
  75 |   const download=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载原命令副本'}).click();expect((await download).suggestedFilename()).toBe('指导建议原命令副本.json');await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  76 | });
  77 | 
  78 | for(const width of [390,768,1440])test('guidance comparisons and actions fit at '+width,async({page})=>{
  79 |   await page.setViewportSize({width,height:1000});await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  80 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await panel(page).getByRole('button',{name:'采用这份说明'}).scrollIntoViewIfNeeded();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toBeVisible();
  81 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/comparison-'+width+'.png',fullPage:true});
  82 | });
  83 | 
```