# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: guidance-model.spec.ts >> another account cannot open or adopt the prior family guidance
- Location: tests\e2e\guidance-model.spec.ts:104:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('无法访问链接中的孩子，已返回当前账号的学习进度。', { exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('无法访问链接中的孩子，已返回当前账号的学习进度。', { exact: true }) with timeout 15000ms
  - waiting for getByText('无法访问链接中的孩子，已返回当前账号的学习进度。', { exact: true })

```

```yaml
- main:
  - link "学习观察室":
    - /url: /
  - navigation "主要导航":
    - link "学习首页":
      - /url: /learn?subject=math&student=student_b91ff75a-1156-44d4-84ef-694aaeb604ea
    - link "学习工作台":
      - /url: /studio?subject=math&student=student_b91ff75a-1156-44d4-84ef-694aaeb604ea
    - link "家长空间":
      - /url: /parent/dashboard?subject=math&studentId=student_b91ff75a-1156-44d4-84ef-694aaeb604ea
    - link "知识诊断":
      - /url: /student/assessment?subject=math&studentId=student_b91ff75a-1156-44d4-84ef-694aaeb604ea
    - link "今日学习":
      - /url: /student/today?subject=math&studentId=student_b91ff75a-1156-44d4-84ef-694aaeb604ea
    - link "题卷资料":
      - /url: /library?subject=math&studentId=student_b91ff75a-1156-44d4-84ef-694aaeb604ea
  - link "资料管理":
    - /url: /parent/data
  - button "退出"
  - complementary:
    - text: LEARNING / INSIGHT
    - heading "把知识 学扎实。" [level=1]:
      - text: 把知识
      - emphasis: 学扎实。
    - paragraph: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
    - list:
      - listitem: 01 确认学习进度
      - listitem: 02 完成一组评测
      - listitem: 03 看懂知识与原因
      - listitem: 04 指导、复测与复盘
    - text: 匿
    - strong: 匿名指导浏览器
    - text: 4年级 · 数学
  - alert:
    - text: 无法访问链接中的孩子，已返回当前账号的学习进度。
    - button "收起提示": ×
  - text: 01 / 学习起点
  - heading "先告诉我们，学到哪里了。" [level=2]
  - paragraph: 只测已学内容。还没有测到的知识点，会保留为未知。
  - text: 孩子
  - combobox "孩子":
    - option "匿名指导浏览器" [selected]
  - text: 当前年级
  - combobox "当前年级":
    - option "1年级"
    - option "2年级"
    - option "3年级"
    - option "4年级" [selected]
    - option "5年级"
    - option "6年级"
  - text: 学期
  - combobox "学期":
    - option "上学期" [selected]
    - option "下学期"
  - text: 每次时间
  - combobox "每次时间":
    - option "5分钟"
    - option "10分钟" [selected]
    - option "15分钟"
    - option "20分钟"
    - option "30分钟"
  - group "学科":
    - button "数学" [pressed]
    - button "语文"
    - button "英语"
  - region "正在学哪一本，学到了哪里":
    - heading "正在学哪一本，学到了哪里" [level=3]
    - button "使用本年级原创能力路径 →"
    - text: 教材或能力路径
    - combobox "教材或能力路径":
      - option "按已学知识点确认 · 手动填写教材" [selected]
    - text: 教材版本
    - textbox "教材版本":
      - /placeholder: 填写孩子实际使用的教材版本
      - text: 原创能力路径
  - heading "勾选已经学过的知识点" [level=3]
  - button "选择本年级能力点"
  - group "1年级 · 前期基础":
    - text: 1年级 · 前期基础
    - checkbox "10以内的数分解 把一个整体分成两个部分，确定缺少的部分"
    - strong: 10以内的数分解
    - text: 把一个整体分成两个部分，确定缺少的部分
    - checkbox "20以内加法合并 将两个部分合并，确定总数"
    - strong: 20以内加法合并
    - text: 将两个部分合并，确定总数
    - checkbox "20以内减法求剩余 从总数中去掉一部分，求剩余数量"
    - strong: 20以内减法求剩余
    - text: 从总数中去掉一部分，求剩余数量
    - checkbox "按一一对应计数 将每个对象计入一次，确定集合基数"
    - strong: 按一一对应计数
    - text: 将每个对象计入一次，确定集合基数
    - checkbox "20以内数量比较 比较两个不相等的数量并确定较大的数"
    - strong: 20以内数量比较
    - text: 比较两个不相等的数量并确定较大的数
    - checkbox "位置序数与数量区分 根据从左或从右的指定方向确定序位"
    - strong: 位置序数与数量区分
    - text: 根据从左或从右的指定方向确定序位
    - checkbox "相邻整数关系 确定给定整数前面或后面的一个数"
    - strong: 相邻整数关系
    - text: 确定给定整数前面或后面的一个数
    - checkbox "十和一的组成 把十个一看作一个十，合成两位数"
    - strong: 十和一的组成
    - text: 把十个一看作一个十，合成两位数
    - checkbox "凑成十的补数 由已知部分找出合成十的另一部分"
    - strong: 凑成十的补数
    - text: 由已知部分找出合成十的另一部分
    - checkbox "由和求未知加数 从已知总数与一部分确定另一部分"
    - strong: 由和求未知加数
    - text: 从已知总数与一部分确定另一部分
    - checkbox "两个数量的相差关系 求一个数量比另一个多或少的数量"
    - strong: 两个数量的相差关系
    - text: 求一个数量比另一个多或少的数量
    - checkbox "20以内连加连减的顺序 从左到右逐步计算没有括号的加减式"
    - strong: 20以内连加连减的顺序
    - text: 从左到右逐步计算没有括号的加减式
    - checkbox "按边角特征识别平面图形 根据明确的边角条件识别图形"
    - strong: 按边角特征识别平面图形
    - text: 根据明确的边角条件识别图形
    - checkbox "按表面特征识别立体 根据面的形状识别常见立体图形"
    - strong: 按表面特征识别立体
    - text: 根据面的形状识别常见立体图形
    - checkbox "整时的时针与分针 由整点时钟的指针位置确定小时数"
    - strong: 整时的时针与分针
    - text: 由整点时钟的指针位置确定小时数
    - checkbox "元角十进换算 依据1元等于10角进行单步换算"
    - strong: 元角十进换算
    - text: 依据1元等于10角进行单步换算
  - group "2年级 · 前期基础":
    - text: 2年级 · 前期基础
    - checkbox "十进制位值换算 说明十位和个位表示的数量，并进行换算"
    - strong: 十进制位值换算
    - text: 说明十位和个位表示的数量，并进行换算
    - checkbox "判断个位是否需要退位 比较被减数与减数个位，判断是否需要向十位退位"
    - strong: 判断个位是否需要退位
    - text: 比较被减数与减数个位，判断是否需要向十位退位
    - checkbox "退一作十的换算 十位退去1后，给个位补上10个一"
    - strong: 退一作十的换算
    - text: 十位退去1后，给个位补上10个一
    - checkbox "乘法等组关系 根据相同组数与每组数量确定总量"
    - strong: 乘法等组关系
    - text: 根据相同组数与每组数量确定总量
    - checkbox "平均分与除法 将整体平均分成若干份，求每份数量"
    - strong: 平均分与除法
    - text: 将整体平均分成若干份，求每份数量
    - checkbox "两位数加法满十进一 个位合并满十后向十位进一"
    - strong: 两位数加法满十进一
    - text: 个位合并满十后向十位进一
    - checkbox "两位数退位减法 个位不够减时退一作十，再完成减法"
    - strong: 两位数退位减法
    - text: 个位不够减时退一作十，再完成减法
    - checkbox "由积求未知因数 利用等组关系确定缺少的每组数或组数"
    - strong: 由积求未知因数
    - text: 利用等组关系确定缺少的每组数或组数
    - checkbox "一个量是另一个的几倍 把较小数量作为一份求倍数"
    - strong: 一个量是另一个的几倍
    - text: 把较小数量作为一份求倍数
    - checkbox "米与厘米换算 依据1米等于100厘米在整米和厘米间换算"
    - strong: 米与厘米换算
    - text: 依据1米等于100厘米在整米和厘米间换算
    - checkbox "时与分的换算 依据1时等于60分完成整时换算"
    - strong: 时与分的换算
    - text: 依据1时等于60分完成整时换算
    - checkbox "钟面分针格与分钟 根据分针所在数字换算分钟"
    - strong: 钟面分针格与分钟
    - text: 根据分针所在数字换算分钟
    - checkbox "分类计数表读数 从含类别和数量的文本表格中取出指定类别数量"
    - strong: 分类计数表读数
    - text: 从含类别和数量的文本表格中取出指定类别数量
    - checkbox "重复排列的周期 依据完整重复节确定指定位置的对象"
    - strong: 重复排列的周期
    - text: 依据完整重复节确定指定位置的对象
    - checkbox "东南西北的相对方位 根据面向的方向确定相反方向"
    - strong: 东南西北的相对方位
    - text: 根据面向的方向确定相反方向
  - group "3年级 · 前期基础":
    - text: 3年级 · 前期基础
    - checkbox "多位数乘一位数 按数位分解并合并部分积"
    - strong: 多位数乘一位数
    - text: 按数位分解并合并部分积
    - checkbox "多位数除以一位数 按位分配，确定没有余数时的商"
    - strong: 多位数除以一位数
    - text: 按位分配，确定没有余数时的商
    - checkbox "长方形周长的边界关系 将长方形四条边相加，区别周长与面积"
    - strong: 长方形周长的边界关系
    - text: 将长方形四条边相加，区别周长与面积
    - checkbox "万以内整数位值比较 先比较最高不同数位以确定较大整数"
    - strong: 万以内整数位值比较
    - text: 先比较最高不同数位以确定较大整数
    - checkbox "三位数连续进位加法 逐位合并并传递进位"
    - strong: 三位数连续进位加法
    - text: 逐位合并并传递进位
    - checkbox "三位数连续退位减法 相邻数位借位后求差"
    - strong: 三位数连续退位减法
    - text: 相邻数位借位后求差
    - checkbox "有余数除法求余数 按每组数量分组，求不足一组的剩余量"
    - strong: 有余数除法求余数
    - text: 按每组数量分组，求不足一组的剩余量
    - checkbox "乘除先于加减 识别并先计算不带括号式子中的乘除部分"
    - strong: 乘除先于加减
    - text: 识别并先计算不带括号式子中的乘除部分
    - checkbox "正方形周长 将四条相等的边合计"
    - strong: 正方形周长
    - text: 将四条相等的边合计
    - checkbox "长方形面积 以单位正方形覆盖行数和列数求面积"
    - strong: 长方形面积
    - text: 以单位正方形覆盖行数和列数求面积
    - checkbox "同日经过时间 将开始结束时刻转换成分钟再求差"
    - strong: 同日经过时间
    - text: 将开始结束时刻转换成分钟再求差
    - checkbox "千克与克换算 依据1千克等于1000克转换数量"
    - strong: 千克与克换算
    - text: 依据1千克等于1000克转换数量
    - checkbox "单位分数与平均分 由平均分的总份数写出一份占整体的分数"
    - strong: 单位分数与平均分
    - text: 由平均分的总份数写出一份占整体的分数
    - checkbox "同分母分数比较 等分单位相同的情况下比较所取份数"
    - strong: 同分母分数比较
    - text: 等分单位相同的情况下比较所取份数
    - checkbox "一位两位小数的位值 把十分之一与百分之一的份数对应到小数位置"
    - strong: 一位两位小数的位值
    - text: 把十分之一与百分之一的份数对应到小数位置
    - checkbox "相邻面积单位换算 区分长度进率与面积进率，按100换算"
    - strong: 相邻面积单位换算
    - text: 区分长度进率与面积进率，按100换算
    - checkbox "把余下的十换成一并合并个位 在剩余十和原个位已给定时，把全部剩余十换成一并合并原个位，保持未分数量不变"
    - strong: 把余下的十换成一并合并个位
    - text: 在剩余十和原个位已给定时，把全部剩余十换成一并合并原个位，保持未分数量不变
  - group "4年级":
    - text: 4年级
    - checkbox "两位数乘两位数 将乘数分解成十位和个位分别求积再合并"
    - strong: 两位数乘两位数
    - text: 将乘数分解成十位和个位分别求积再合并
    - checkbox "余数与除数的约束 将不能整分的数量分组，确定余数且检验余数小于除数"
    - strong: 余数与除数的约束
    - text: 将不能整分的数量分组，确定余数且检验余数小于除数
    - checkbox "长方形面积的覆盖关系 用长乘宽确定单位正方形的数量"
    - strong: 长方形面积的覆盖关系
    - text: 用长乘宽确定单位正方形的数量
    - checkbox "大数的数级与位值 由万级和个级的数量合成整数"
    - strong: 大数的数级与位值
    - text: 由万级和个级的数量合成整数
    - checkbox "四舍五入到千位 观察百位数字确定保留千位的近似整数"
    - strong: 四舍五入到千位
    - text: 观察百位数字确定保留千位的近似整数
    - checkbox "三位数乘两位数 按十位和个位分解乘数并合并部分积"
    - strong: 三位数乘两位数
    - text: 按十位和个位分解乘数并合并部分积
    - checkbox "除数是两位数的整除 试商并用乘法检验商"
    - strong: 除数是两位数的整除
    - text: 试商并用乘法检验商
    - checkbox "带括号的四则顺序 先求括号中的结果，再进行乘除"
    - strong: 带括号的四则顺序
    - text: 先求括号中的结果，再进行乘除
    - checkbox "乘法分配律的对应因数 在乘法分配的两种表示中对应相同因数"
    - strong: 乘法分配律的对应因数
    - text: 在乘法分配的两种表示中对应相同因数
    - checkbox "小数位值比较 按整数部分、十分位、百分位依次比较小数"
    - strong: 小数位值比较
    - text: 按整数部分、十分位、百分位依次比较小数
    - checkbox "小数减法数位对齐 将相同小数数位对齐再相减"
    - strong: 小数减法数位对齐
    - text: 将相同小数数位对齐再相减
    - checkbox "锐角直角钝角分类 按与90度和180度的关系判断角的类型"
    - strong: 锐角直角钝角分类
    - text: 按与90度和180度的关系判断角的类型
    - checkbox "三角形内角和 用180度减去已知两个内角求第三角"
    - strong: 三角形内角和
    - text: 用180度减去已知两个内角求第三角
    - checkbox "平均数的总量等分 先合计总量再按数据个数平均"
    - strong: 平均数的总量等分
    - text: 先合计总量再按数据个数平均
    - checkbox "两组统计数量的差 从分类计数中选择正确两类再求差"
    - strong: 两组统计数量的差
    - text: 从分类计数中选择正确两类再求差
    - checkbox "明确平均对象并把零数据计入份数 按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0" [checked]
    - strong: 明确平均对象并把零数据计入份数
    - text: 按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0
  - text: 这次想怎样了解孩子
  - combobox "这次想怎样了解孩子":
    - option "起点评测 · 了解当前基础" [selected]
    - option "单元评测 · 观察本单元知识"
    - option "阶段回顾 · 在已学范围抽样"
    - option "三分钟微测 · 只看当前目标"
  - checkbox "按这次作答逐步选择核查顺序" [checked]
  - text: 按这次作答逐步选择核查顺序
  - checkbox "加入必要的前置基础核查，先在预览中确认" [checked]
  - text: 加入必要的前置基础核查，先在预览中确认
  - paragraph: 基础核查会单独标明。范围与题量确认后保持一致，选题顺序会在结束记录中保留。
  - strong: 已选 1 个点
  - text: 本组最多
  - combobox "本组最多":
    - option "2题"
    - option "4题"
    - option "6题"
    - option "8题"
    - option "12题" [selected]
    - option "20题"
    - option "30题"
  - button "确认进度，查看题组"
  - paragraph: 题量由时长和可用题目共同决定。基础题为规则估计材料，教材完整覆盖与标准化常模尚需独立验证。
  - heading "继续上一次，或回看报告" [level=3]
  - button "2026/10/25 · 4年级 查看报告 ↗":
    - text: 2026/10/25 · 4年级
    - strong: 查看报告 ↗
  - button "已有指导计划 · 查看与确认 ↗"
  - button "打开学习观察助教"
- alert
```

# Test source

```ts
  7   |   async function call(path:string,body?:unknown,method=body===undefined?'GET':'POST') {const response=await fetch(api+path,{method,headers:{'content-type':'application/json',authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});const result=await response.json();expect(response.ok,JSON.stringify(result.error)).toBe(true);return result.data;}
  8   |   const studentId=(await call('/students',{nickname:'匿名指导浏览器',grade:4,preferredSessionMinutes:10,defaultVersionMap:{math:'',chinese:'',english:''}})).profile.id,atom='atomic:math:averagecount';
  9   |   await call('/students/'+studentId+'/learning-scope',{subject:'math',grade:4,term:'upper',textbookVolumeId:null,textbookVersion:'原创能力路径',learnedAtomIds:[atom],currentAtomId:atom,minutesPerSession:10},'PUT');
  10  |   const baseline=await call('/diagnostics/sessions',{studentId,subject:'math',intent:'baseline',targetAtomIds:[atom],includePrerequisites:false,maxItems:4});
  11  |   for(const item of baseline.items)await call('/diagnostics/sessions/'+baseline.id+'/responses',{itemId:item.id,disposition:'skip',elapsedMs:100});await call('/diagnostics/sessions/'+baseline.id+'/complete',{});
  12  |   const plan=makePlan?await call('/diagnostics/students/'+studentId+'/plans',{baselineSessionId:baseline.id,minutesPerDay:10,useAi:false,requestKey:crypto.randomUUID(),expectedReportVersion:1}):null;
  13  |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  |   const href='/student/assessment?'+new URLSearchParams({studentId,subject:'math',...(plan?{view:'plan',planId:plan.id}:{session:baseline.id})});await page.goto(href);
  15  |   if(plan)await expect(page.getByRole('region',{name:'AI指导说明建议'})).toBeVisible();else await expect(page.getByRole('heading',{name:'从知识点看清下一步。'})).toBeVisible();
  16  |   return {actor,studentId,baseline,plan,call,href};
  17  | }
  18  | const panel=(page:Page)=>page.getByRole('region',{name:'AI指导说明建议'});
  19  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  20  | 
  21  | test('the original rule plan stays usable and an explicitly reviewed model description changes only its text',async({page})=>{
  22  |   const f=await setup(page);await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  23  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).summary).toBe(f.plan.summary);
  24  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await expect(panel(page).getByRole('region',{name:'原计划说明'})).toContainText(f.plan.summary);
  25  |   await expect(panel(page).getByRole('region',{name:'模型建议说明'})).toContainText('合成测试建议');await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();
  26  |   await expect(page.locator('.guidance-version')).toContainText('第 2 版');const adopted=await f.call('/diagnostics/plans/'+f.plan.id);expect(adopted.source).toBe('ai');
  27  |   expect(adopted.actions.map(({activity:_,...action}:any)=>action)).toEqual(f.plan.actions.map(({activity:_,...action}:any)=>action));
  28  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page)).toContainText('DeepSeek V4.1 Flash');
  29  | });
  30  | 
  31  | test('a dropped plan creation acknowledgement recovers the original request without making another plan',async({page})=>{
  32  |   const f=await setup(page,false);let original:any;
  33  |   await page.route('**/api/diagnostics/students/*/plans',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  34  |   await page.getByRole('button',{name:/制定指导计划/}).click();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  35  |   await page.unroute('**/api/diagnostics/students/*/plans');await page.reload();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  36  |   let created=0;page.on('request',request=>{if(request.method()==='POST'&&/\/students\/[^/]+\/plans$/.test(request.url()))created++;});
  37  |   await page.getByRole('button',{name:'读取原计划创建结果',exact:true}).click();await expect(panel(page)).toBeVisible();expect(created).toBe(0);
  38  |   const plans=await f.call('/diagnostics/students/'+f.studentId+'/plans?subject=math');expect(plans).toHaveLength(1);expect(plans[0].baselineReportVersion).toBe(original.expectedReportVersion);
  39  | });
  40  | 
  41  | test('a dropped suggestion creation acknowledgement survives reload and restores the same saved task',async({page})=>{
  42  |   const f=await setup(page);let original:any;await page.route('**/api/diagnostics/plans/*/model-suggestions',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  43  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  44  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions');await page.reload();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  45  |   await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  46  |   const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].requestKey).toBe(original.requestKey);
  47  | });
  48  | 
  49  | test('a dropped adoption acknowledgement replays its original command and leaves exactly one adopted revision',async({page})=>{
  50  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  51  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  52  |   await page.route('**/api/diagnostics/plans/*/model-suggestions/*/adopt',async route=>{await route.fetch();await route.abort('failed');});
  53  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  54  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions/*/adopt');await page.reload();await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(page.locator('.guidance-version')).toContainText('第 2 版');
  55  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/history')).filter((row:any)=>row.kind==='adjusted')).toHaveLength(1);
  56  | });
  57  | 
  58  | test('cancel and retry preserve the original selected model and plan',async({page})=>{
  59  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');
  60  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  61  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  62  |   await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'valid'});await panel(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');await panel(page).getByRole('button',{name:'重试原模型'}).click();
  63  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].modelId).toBe('deepseek-v4-flash');expect((await f.call('/diagnostics/plans/'+f.plan.id)).source).toBe('rules');
  64  | });
  65  | 
  66  | test('invalid output cannot be adopted and a later explicit retry keeps the original evidence',async({page})=>{
  67  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'invalid-once'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  68  |   await expect(panel(page).getByText('生成未完成',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toHaveCount(0);
  69  |   await panel(page).getByRole('button',{name:'重试原模型'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).actions).toEqual(f.plan.actions);
  70  | });
  71  | 
  72  | test('unavailable browser storage keeps the full original command downloadable',async({page})=>{
  73  |   await page.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.guidance.model.v1.'))throw new DOMException('QA quota','QuotaExceededError');return set.call(this,key,value);};});
  74  |   await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText(/本机暂存不可用/)).toBeVisible();
  75  |   const download=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载原命令副本'}).click();expect((await download).suggestedFilename()).toBe('指导建议原命令副本.json');await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  76  | });
  77  | 
  78  | test('a manually changed plan refuses an older completed suggestion and preserves its original command',async({page})=>{
  79  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  80  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  81  |   await f.call('/diagnostics/plans/'+f.plan.id+'/adjust',{expectedRevision:f.plan.revision,requestKey:crypto.randomUUID(),reason:'合成浏览器中在另一页面明确手工修改活动',minutesPerDay:f.plan.minutesPerDay,acknowledgeReportVersion:f.plan.baselineReportVersion,
  82  |     actions:f.plan.actions.map((action:any)=>({actionId:action.id,minutes:action.minutes,activity:'家长在另一页面确认的观察方案，保留独立小测与验证。'}))});
  83  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByText('采用未获确认，已读取当前建议；原命令保留在副本中。',{exact:true})).toBeVisible();
  84  |   await expect(panel(page).getByRole('button',{name:'采用这份说明',exact:true})).toBeDisabled();const current=await f.call('/diagnostics/plans/'+f.plan.id);expect(current.source).toBe('human');expect(current.revision).toBe(2);
  85  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page).getByRole('button',{name:'下载原命令副本'})).toBeVisible();
  86  | });
  87  | 
  88  | test('a cancelled local wait resumes the server record after navigating away and back',async({page})=>{
  89  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  90  |   await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();await page.goto('/learn');await page.goto(f.href);await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  91  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  92  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(1);
  93  | });
  94  | 
  95  | test('forged cross-account cached commands are ignored and never replayed',async({page})=>{
  96  |   const f=await setup(page),key='studyagent.guidance.model.v1.'+encodeURIComponent(f.actor.user.id)+'.'+encodeURIComponent(f.plan.id);
  97  |   await page.evaluate(({key,plan})=>localStorage.setItem(key,JSON.stringify({version:1,ownerId:'another-account',planId:plan.id,studentId:plan.studentId,selectedId:null,rejected:null,
  98  |     pending:{kind:'create',command:{modelId:'deepseek-v4-flash',expectedRevision:1,requestKey:'forged-guidance-request'}}})),{key,plan:f.plan});
  99  |   let sent=0;page.on('request',request=>{if(request.method()==='POST'&&request.url().includes('/model-suggestions'))sent++;});await page.reload();
  100 |   await expect(panel(page).getByText('本机记录与当前账号或计划不匹配，已保留原缓存并忽略恢复。',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toHaveCount(0);expect(sent).toBe(0);
  101 |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(0);
  102 | });
  103 | 
  104 | test('another account cannot open or adopt the prior family guidance',async({page})=>{
  105 |   const first=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  106 |   const second=await setup(page);expect(second.actor.user.id).not.toBe(first.actor.user.id);await expect(panel(page).getByText('建议已生成',{exact:true})).toHaveCount(0);
> 107 |   await page.goto(first.href);await expect(page.getByText('无法访问链接中的孩子，已返回当前账号的学习进度。',{exact:true})).toBeVisible();await expect(panel(page)).toHaveCount(0);
      |                                                                                                     ^ Error: expect(locator).toBeVisible() failed
  108 |   expect(new URL(page.url()).searchParams.get('studentId')).toBe(second.studentId);expect(new URL(page.url()).searchParams.has('planId')).toBe(false);
  109 | });
  110 | 
  111 | for(const width of [390,768,1440])test('guidance comparisons and actions fit at '+width,async({page})=>{
  112 |   await page.setViewportSize({width,height:1000});await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  113 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await panel(page).getByRole('button',{name:'采用这份说明'}).scrollIntoViewIfNeeded();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toBeVisible();
  114 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/comparison-'+width+'.png',fullPage:true});
  115 | });
  116 | 
```