# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: guidance-model.spec.ts >> another account cannot open or adopt the prior family guidance
- Location: tests\e2e\guidance-model.spec.ts:104:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('You cannot access this student', { exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('You cannot access this student', { exact: true }) with timeout 15000ms
  - waiting for getByText('You cannot access this student', { exact: true })

```

```yaml
- main:
  - link "学习观察室":
    - /url: /
  - navigation "主要导航":
    - link "学习首页":
      - /url: /learn?subject=math&student=student_1e21a84c-4a8e-4aed-add4-225b9fc50494
    - link "学习工作台":
      - /url: /studio?subject=math&student=student_1e21a84c-4a8e-4aed-add4-225b9fc50494
    - link "家长空间":
      - /url: /parent/dashboard?subject=math&studentId=student_1e21a84c-4a8e-4aed-add4-225b9fc50494
    - link "知识诊断":
      - /url: /student/assessment?subject=math&studentId=student_1e21a84c-4a8e-4aed-add4-225b9fc50494
    - link "今日学习":
      - /url: /student/today?subject=math&studentId=student_1e21a84c-4a8e-4aed-add4-225b9fc50494
    - link "题卷资料":
      - /url: /library?subject=math&studentId=student_1e21a84c-4a8e-4aed-add4-225b9fc50494
  - link "资料管理":
    - /url: /parent/data
  - button "退出"
  - complementary:
    - text: LEARNING / INSIGHT
    - heading "把知识 学扎实。" [level=1]:
      - text: 把知识
      - emphasis: 学扎实。
    - paragraph: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
    - list:
      - listitem: 01 确认学习进度
      - listitem: 02 完成一组评测
      - listitem: 03 看懂知识与原因
      - listitem: 04 指导、复测与复盘
    - text: 匿
    - strong: 匿名指导浏览器
    - text: 4年级 · 数学
    - button "返回学习进度与历史"
  - text: 04 / 指导 · 验证 · 复盘
  - heading "每天 10 分钟， 把一步走稳。" [level=2]
  - paragraph: 每天 10 分钟，围绕 明确平均对象并把零数据计入份数 先验证再指导；复测后调整。
  - text: 待家长确认
  - button "确认并开始计划"
  - region "指导计划调整与历史":
    - text: 第 1 版 依据评测安排 · 2026/10/25
    - strong: 每次调整，都保留当时的依据。
    - paragraph: 指导依据与当前评测版本一致。
    - region "AI指导说明建议":
      - text: 说明建议
      - heading "把下一步，写得更具体。" [level=3]
      - paragraph: 对照原计划与建议，再决定是否采用。知识目标、时间、成功标准和复测安排按原计划保留。
      - text: 模型
      - combobox "选择大模型":
        - option "Auto · 当前默认模型"
      - paragraph: DeepSeek V4.1 Flash DeepSeek V4 Flash
      - button "生成说明建议"
      - button "读取最新状态"
    - button "调整时间与指导活动"
    - button "查看每次调整 ↗"
  - article:
    - text: 01 约 10 分钟 / 0 条依据
    - heading "先补充证据：明确平均对象并把零数据计入份数" [level=3]
    - paragraph: 先做两个不同题族的独立小测，观察“按问题指定的人、天等平均对象确定份数；参与且为0的记录仍计入，未参加不混入，记录缺失不当成0”。根据表现决定是否需要讲解。
    - group: 先看讲解和示例
    - group: 家长怎样观察与验证
    - strong: 怎样算走稳了
    - paragraph: 能从完整记录和参与范围独立选择分母，区分0、未参加与未记录，在对象改变的新题中验证，并经过真实间隔复核。；至少两个新题族独立完成，再安排迁移与延迟验证。
    - button "做新题验证 ↗" [disabled]
  - heading "留出间隔，再看是否保持" [level=3]
  - paragraph: 确认计划后，会安排次日、3日、7日和14日复测。
  - heading "复盘：哪些变化已经得到验证？" [level=3]
  - button "查看前后证据"
  - button "打开学习观察助教"
- alert
```

# Test source

```ts
  7   |   async function call(path:string,body?:unknown,method=body===undefined?'GET':'POST') {const response=await fetch(api+path,{method,headers:{'content-type':'application/json',authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});const result=await response.json();expect(response.ok,JSON.stringify(result.error)).toBe(true);return result.data;}
  8   |   const studentId=(await call('/students',{nickname:'匿名指导浏览器',grade:4,preferredSessionMinutes:10,defaultVersionMap:{math:'',chinese:'',english:''}})).profile.id,atom='atomic:math:averagecount';
  9   |   await call('/students/'+studentId+'/learning-scope',{subject:'math',grade:4,term:'upper',textbookVolumeId:null,textbookVersion:'原创能力路径',learnedAtomIds:[atom],currentAtomId:atom,minutesPerSession:10},'PUT');
  10  |   const baseline=await call('/diagnostics/sessions',{studentId,subject:'math',intent:'baseline',targetAtomIds:[atom],includePrerequisites:false,maxItems:4});
  11  |   for(const item of baseline.items)await call('/diagnostics/sessions/'+baseline.id+'/responses',{itemId:item.id,disposition:'skip',elapsedMs:100});await call('/diagnostics/sessions/'+baseline.id+'/complete',{});
  12  |   const plan=makePlan?await call('/diagnostics/students/'+studentId+'/plans',{baselineSessionId:baseline.id,minutesPerDay:10,useAi:false,requestKey:crypto.randomUUID(),expectedReportVersion:1}):null;
  13  |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  |   const href='/student/assessment?'+new URLSearchParams({studentId,subject:'math',...(plan?{view:'plan',planId:plan.id}:{session:baseline.id})});await page.goto(href);
  15  |   if(plan)await expect(page.getByRole('region',{name:'AI指导说明建议'})).toBeVisible();else await expect(page.getByRole('heading',{name:'从知识点看清下一步。'})).toBeVisible();
  16  |   return {actor,studentId,baseline,plan,call,href};
  17  | }
  18  | const panel=(page:Page)=>page.getByRole('region',{name:'AI指导说明建议'});
  19  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  20  | 
  21  | test('the original rule plan stays usable and an explicitly reviewed model description changes only its text',async({page})=>{
  22  |   const f=await setup(page);await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  23  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).summary).toBe(f.plan.summary);
  24  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await expect(panel(page).getByRole('region',{name:'原计划说明'})).toContainText(f.plan.summary);
  25  |   await expect(panel(page).getByRole('region',{name:'模型建议说明'})).toContainText('合成测试建议');await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();
  26  |   await expect(page.locator('.guidance-version')).toContainText('第 2 版');const adopted=await f.call('/diagnostics/plans/'+f.plan.id);expect(adopted.source).toBe('ai');
  27  |   expect(adopted.actions.map(({activity:_,...action}:any)=>action)).toEqual(f.plan.actions.map(({activity:_,...action}:any)=>action));
  28  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page)).toContainText('DeepSeek V4.1 Flash');
  29  | });
  30  | 
  31  | test('a dropped plan creation acknowledgement recovers the original request without making another plan',async({page})=>{
  32  |   const f=await setup(page,false);let original:any;
  33  |   await page.route('**/api/diagnostics/students/*/plans',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  34  |   await page.getByRole('button',{name:/制定指导计划/}).click();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  35  |   await page.unroute('**/api/diagnostics/students/*/plans');await page.reload();await expect(page.getByRole('button',{name:'读取原计划创建结果',exact:true})).toBeEnabled();
  36  |   let created=0;page.on('request',request=>{if(request.method()==='POST'&&/\/students\/[^/]+\/plans$/.test(request.url()))created++;});
  37  |   await page.getByRole('button',{name:'读取原计划创建结果',exact:true}).click();await expect(panel(page)).toBeVisible();expect(created).toBe(0);
  38  |   const plans=await f.call('/diagnostics/students/'+f.studentId+'/plans?subject=math');expect(plans).toHaveLength(1);expect(plans[0].baselineReportVersion).toBe(original.expectedReportVersion);
  39  | });
  40  | 
  41  | test('a dropped suggestion creation acknowledgement survives reload and restores the same saved task',async({page})=>{
  42  |   const f=await setup(page);let original:any;await page.route('**/api/diagnostics/plans/*/model-suggestions',async route=>{if(route.request().method()!=='POST')return route.continue();original=route.request().postDataJSON();await route.fetch();await route.abort('failed');});
  43  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  44  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions');await page.reload();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  45  |   await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  46  |   const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].requestKey).toBe(original.requestKey);
  47  | });
  48  | 
  49  | test('a dropped adoption acknowledgement replays its original command and leaves exactly one adopted revision',async({page})=>{
  50  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  51  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  52  |   await page.route('**/api/diagnostics/plans/*/model-suggestions/*/adopt',async route=>{await route.fetch();await route.abort('failed');});
  53  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toBeEnabled();
  54  |   await page.unroute('**/api/diagnostics/plans/*/model-suggestions/*/adopt');await page.reload();await panel(page).getByRole('button',{name:'读取并恢复原操作'}).click();await expect(page.locator('.guidance-version')).toContainText('第 2 版');
  55  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/history')).filter((row:any)=>row.kind==='adjusted')).toHaveLength(1);
  56  | });
  57  | 
  58  | test('cancel and retry preserve the original selected model and plan',async({page})=>{
  59  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByLabel('选择大模型').selectOption('deepseek-v4-flash');
  60  |   await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  61  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  62  |   await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'valid'});await panel(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');await panel(page).getByRole('button',{name:'重试原模型'}).click();
  63  |   await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();const list=await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions');expect(list.suggestions).toHaveLength(1);expect(list.suggestions[0].modelId).toBe('deepseek-v4-flash');expect((await f.call('/diagnostics/plans/'+f.plan.id)).source).toBe('rules');
  64  | });
  65  | 
  66  | test('invalid output cannot be adopted and a later explicit retry keeps the original evidence',async({page})=>{
  67  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'invalid-once'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  68  |   await expect(panel(page).getByText('生成未完成',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toHaveCount(0);
  69  |   await panel(page).getByRole('button',{name:'重试原模型'}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();expect((await f.call('/diagnostics/plans/'+f.plan.id)).actions).toEqual(f.plan.actions);
  70  | });
  71  | 
  72  | test('unavailable browser storage keeps the full original command downloadable',async({page})=>{
  73  |   await page.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.guidance.model.v1.'))throw new DOMException('QA quota','QuotaExceededError');return set.call(this,key,value);};});
  74  |   await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText(/本机暂存不可用/)).toBeVisible();
  75  |   const download=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载原命令副本'}).click();expect((await download).suggestedFilename()).toBe('指导建议原命令副本.json');await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  76  | });
  77  | 
  78  | test('a manually changed plan refuses an older completed suggestion and preserves its original command',async({page})=>{
  79  |   const f=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  80  |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();
  81  |   await f.call('/diagnostics/plans/'+f.plan.id+'/adjust',{expectedRevision:f.plan.revision,requestKey:crypto.randomUUID(),reason:'合成浏览器中在另一页面明确手工修改活动',minutesPerDay:f.plan.minutesPerDay,acknowledgeReportVersion:f.plan.baselineReportVersion,
  82  |     actions:f.plan.actions.map((action:any)=>({actionId:action.id,minutes:action.minutes,activity:'家长在另一页面确认的观察方案，保留独立小测与验证。'}))});
  83  |   await panel(page).getByRole('button',{name:'采用这份说明',exact:true}).click();await expect(panel(page).getByText('采用未获确认，已读取当前建议；原命令保留在副本中。',{exact:true})).toBeVisible();
  84  |   await expect(panel(page).getByRole('button',{name:'采用这份说明',exact:true})).toBeDisabled();const current=await f.call('/diagnostics/plans/'+f.plan.id);expect(current.source).toBe('human');expect(current.revision).toBe(2);
  85  |   await page.reload();await expect(page.locator('.guidance-version')).toContainText('第 2 版');await expect(panel(page).getByRole('button',{name:'下载原命令副本'})).toBeVisible();
  86  | });
  87  | 
  88  | test('a cancelled local wait resumes the server record after navigating away and back',async({page})=>{
  89  |   const f=await setup(page);await f.call('/qa/guidance-models/'+f.plan.id+'/behavior',{mode:'hold'});await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();
  90  |   await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();await page.goto('/learn');await page.goto(f.href);await expect(panel(page).getByText('正在生成说明',{exact:true})).toBeVisible();
  91  |   await panel(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(panel(page).getByText('已取消',{exact:true})).toBeVisible();
  92  |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(1);
  93  | });
  94  | 
  95  | test('forged cross-account cached commands are ignored and never replayed',async({page})=>{
  96  |   const f=await setup(page),key='studyagent.guidance.model.v1.'+encodeURIComponent(f.actor.user.id)+'.'+encodeURIComponent(f.plan.id);
  97  |   await page.evaluate(({key,plan})=>localStorage.setItem(key,JSON.stringify({version:1,ownerId:'another-account',planId:plan.id,studentId:plan.studentId,selectedId:null,rejected:null,
  98  |     pending:{kind:'create',command:{modelId:'deepseek-v4-flash',expectedRevision:1,requestKey:'forged-guidance-request'}}})),{key,plan:f.plan});
  99  |   let sent=0;page.on('request',request=>{if(request.method()==='POST'&&request.url().includes('/model-suggestions'))sent++;});await page.reload();
  100 |   await expect(panel(page).getByText('本机记录与当前账号或计划不匹配，已保留原缓存并忽略恢复。',{exact:true})).toBeVisible();await expect(panel(page).getByRole('button',{name:'读取并恢复原操作'})).toHaveCount(0);expect(sent).toBe(0);
  101 |   expect((await f.call('/diagnostics/plans/'+f.plan.id+'/model-suggestions')).suggestions).toHaveLength(0);
  102 | });
  103 | 
  104 | test('another account cannot open or adopt the prior family guidance',async({page})=>{
  105 |   const first=await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  106 |   const second=await setup(page);expect(second.actor.user.id).not.toBe(first.actor.user.id);await expect(panel(page).getByText('建议已生成',{exact:true})).toHaveCount(0);
> 107 |   await page.goto(first.href);await expect(page.getByText('You cannot access this student',{exact:true})).toBeVisible();await expect(panel(page)).toHaveCount(0);
      |                                                                                                           ^ Error: expect(locator).toBeVisible() failed
  108 | });
  109 | 
  110 | for(const width of [390,768,1440])test('guidance comparisons and actions fit at '+width,async({page})=>{
  111 |   await page.setViewportSize({width,height:1000});await setup(page);await panel(page).getByRole('button',{name:'生成说明建议',exact:true}).click();await expect(panel(page).getByText('建议已生成',{exact:true})).toBeVisible();
  112 |   await panel(page).getByText('对照原说明与建议，再决定是否采用',{exact:true}).click();await panel(page).getByRole('button',{name:'采用这份说明'}).scrollIntoViewIfNeeded();await expect(panel(page).getByRole('button',{name:'采用这份说明'})).toBeVisible();
  113 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/comparison-'+width+'.png',fullPage:true});
  114 | });
  115 | 
```