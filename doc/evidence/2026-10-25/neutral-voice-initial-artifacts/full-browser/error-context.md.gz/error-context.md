# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-boards.spec.ts >> complete notes, cross-page reply navigation, keyboard activation and narrow layouts remain usable
- Location: tests\e2e\classroom-boards.spec.ts:72:5

# Error details

```
Error: expect(locator).toBeInViewport() failed

Locator: locator('.cl-ai-board').last()
Expected: in viewport
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeInViewport" locator('.cl-ai-board').last() with timeout 15000ms
  - waiting for locator('.cl-ai-board').last()

```

```yaml
- alert
- main:
  - region "教学白板":
    - button "离开课堂"
    - button "社会学想象力 断点已同步": 社会学想象力
    - button "缩小白板": −
    - button "重置缩放": 100%
    - button "放大白板": ＋
    - button "上一页白板": ‹
    - text: 2 / 2
    - button "下一页白板" [disabled]: ›
    - button "补一张讲解图": 配图
    - button "导出课堂笔记"
    - button "课堂设置"
    - button "切换对话面板"
    - heading "把概念放进生活" [level=2]
    - list:
      - listitem: ·观察：多家工厂同时关闭
      - listitem: ·问题：岗位变化还是个体差异？
    - heading "行动仍然有位置" [level=2]
    - list:
      - listitem: ·划桨：个人能动性
      - listitem: ·水流与航道：结构条件
      - listitem: ·集体行动：也能改变航道
    - figure "划桨、河流与航道 · 概念示意":
      - button "放大图片：划桨、河流与航道 · 概念示意":
        - img "划船者选择划桨方式，水流限制前进条件，岸边的人合作改善航道"
      - text: 划桨、河流与航道 · 概念示意
    - button "开启讲解声音"
    - paragraph: 把船放在河流中：你能调整划桨方式，也能与他人改善航道；但水流和航道决定行动需要面对什么条件。
  - separator "调整对话面板宽度"
  - complementary:
    - text: Chat history
    - button "隐藏对话面板"
    - tablist "课堂内容":
      - tab "讲解与插问" [selected]
      - tab "课堂练习"
      - tab "单元项目"
    - article:
      - text: 22:23
      - paragraph: 今天一起研究“社会学想象力”。
      - paragraph: 先记住三个问题：这个概念指什么？
      - paragraph: 它怎样解释具体生活？
      - paragraph: 什么证据能帮助我们判断解释是否站得住？
      - button "♧ 本节课导航"
    - article:
      - text: TEACHER
      - paragraph: 米尔斯把个人的生活历程与时代、制度联系起来。
      - paragraph: 分析时同时追问个人处境和处境形成的社会条件。
      - button "♧ 社会学想象力"
    - article:
      - text: TEACHER
      - paragraph: 一个人找不到工作时，可以调查技能和求职过程；同一产业大量岗位一起消失时，
      - paragraph: 还必须检查需求、投资与政策。
      - paragraph: 规模变化提示我们扩大解释范围，但规模本身还不是因果证明。
      - button "♧ 先看问题的规模"
    - article:
      - text: TEACHER
      - paragraph: 同一地区多家工厂关闭，许多有经验的工人同时失业。
      - paragraph: 个人技能可能相关，但岗位整体消失需要结构层面的解释。
      - button "♧ 把概念放进生活"
    - article:
      - text: TEACHER
      - paragraph: 看见结构不是放弃行动。
      - paragraph: 把船放在河流中：你能调整划桨方式，也能与他人改善航道；但水流和航道决定行动需要面对什么条件。
      - button "♧ 行动仍然有位置"
    - article:
      - text: 我 · 22:23
      - paragraph: "[board-table] 请比较两种平均分法。"
    - article:
      - text: 老师 · 22:23
      - paragraph: 先固定总量。第一种分法是十二颗分成三组。第二种分法是十二颗分成四组。平均每份等于总量除以份数。
      - text: Synthetic classroom fixture
      - button "♧ 平均分的两种分法"
      - button "按句阅读这段回答"
      - button "♪ 朗读这段回答"
    - status: ••• Paused
    - status:
      - text: 回答已保存。可以朗读回答，或回到提问时的原句继续。
      - button "关闭提示": ×
    - button "‹ 上一步"
    - text: 5 / 8
    - button "下一步 ›"
    - text: 回答已保存
    - paragraph: "[board-table] 请比较两种平均分法。"
    - text: DeepSeek V4.1 Flash · 社会学想象力 · 第 2 句
    - button "回到原句继续"
    - paragraph: “分析时同时追问个人处境和处境形成的社会条件。”
    - group "调整讲法":
      - button "提问" [pressed]
      - button "换个例子"
      - button "说简单点"
      - button "补先修"
      - button "比较讲法"
    - textbox "向课堂老师提问":
      - /placeholder: Ask a question…
    - button "语音提问": ♩
    - button "继续讲解": ▷
    - button "停止课堂讲解": ■
    - combobox "选择大模型":
      - option "Auto · 当前默认模型"
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { mkdirSync, readFileSync } from 'node:fs';
  3  | import { browserEvidence } from './evidence';
  4  | import { resolve } from 'node:path';
  5  | import { pathToFileURL } from 'node:url';
  6  | 
  7  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`, evidence = browserEvidence('classroom-boards');
  8  | let address = 0;
  9  | // Drain session decorators before Playwright disposes their response/request context.
  10 | test.afterEach(async ({page}) => { await page.unrouteAll({behavior:'wait'}); });
  11 | const board = (page: Page) => page.locator('.cl-ai-board').last();
  12 | async function enter(page: Page) {
  13 |   const id = Date.now() + '-' + Math.floor(Math.random()*100000), principal = 'boards-' + id + '@local.test', credential = 'Boards-only-' + id;
  14 |   const registration = await fetch(api + '/auth/register', {method:'POST', headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.2.'+(++address)},body:JSON.stringify({principal,credential})});
  15 |   expect(registration.status).toBe(201); const actor = (await registration.json()).data;
  16 |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));
  17 |   await page.route(/\/api\/learning\/classroom\/sessions\/[^/?]+$/, async route=>{
  18 |     const response=await route.fetch(),body=await response.json();
  19 |     if(body.data?.lesson)body.data.speech={available:true,provider:'minimax',defaultVoice:'synthetic',voices:[{id:'synthetic',label:'合成测试声线'}]};
  20 |     await route.fulfill({response,json:body});
  21 |   });
  22 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  23 |   await page.getByRole('button',{name:'登录，查看学习记录 →'}).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  24 |   await page.goto('/studio/classroom?lesson=soc-1-1-1'); await expect(page.getByLabel('向课堂老师提问')).toBeVisible();
  25 |   await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  26 |   await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8'); await expect(page.locator('.cl-subtitle')).not.toContainText('准备好后');
  27 |   return actor;
  28 | }
  29 | async function ask(page:Page,message='[board-table] 请比较两种平均分法。') {
  30 |   await page.getByLabel('向课堂老师提问').fill(message); await page.getByRole('button',{name:'发送课堂问题'}).click();
  31 |   await expect(page.locator('.cl-turn-status')).toContainText('回答已保存'); await expect(board(page)).toContainText('平均分的两种分法');
  32 | }
  33 | function wav() { const samples=16000,bytes=Buffer.alloc(44+samples*2); bytes.write('RIFF');bytes.writeUInt32LE(bytes.length-8,4);bytes.write('WAVE',8);bytes.write('fmt ',12);bytes.writeUInt32LE(16,16);bytes.writeUInt16LE(1,20);bytes.writeUInt16LE(1,22);bytes.writeUInt32LE(16000,24);bytes.writeUInt32LE(32000,28);bytes.writeUInt16LE(2,32);bytes.writeUInt16LE(16,34);bytes.write('data',36);bytes.writeUInt32LE(samples*2,40);return bytes; }
  34 | async function screen(page:Page,name:string) {if(!process.env.CI){mkdirSync(evidence,{recursive:true});await page.screenshot({path:evidence+'/'+name+'.png',fullPage:true});}}
  35 | 
  36 | test('text reading reveals whole points, rows and formulas; stop restores the original line and complete notes',async({page})=>{
  37 |   await enter(page); const original=await page.locator('.cl-subtitle').innerText(); let audioCalls=0;
  38 |   await page.route('**/api/learning/classroom/sessions/*/narration/*',route=>{audioCalls++;return route.fulfill({contentType:'audio/wav',body:wav()});});
  39 |   await ask(page); await page.getByRole('button',{name:'按句阅读这段回答',exact:true}).click();
  40 |   await expect(page.locator('.cl-subtitle')).toHaveText('先固定总量。'); await expect(board(page).locator('.cl-board-item')).toHaveCount(1);
  41 |   await expect(board(page).locator('tbody tr')).toHaveCount(0); await expect(board(page).locator('math')).toHaveCount(0);
  42 |   await expect(page.locator('.cl-subtitle')).toHaveText('第一种分法是十二颗分成三组。');
  43 |   await expect(board(page).locator('tbody tr')).toHaveCount(1); await expect(board(page).locator('tbody tr').first()).toHaveText('1234');
  44 |   await expect(page.locator('.cl-subtitle')).toHaveText('第二种分法是十二颗分成四组。'); await expect(board(page).locator('tbody tr')).toHaveCount(2);
  45 |   await expect(board(page).locator('math')).toHaveCount(0);
  46 |   await expect(page.locator('.cl-subtitle')).toHaveText('平均每份等于总量除以份数。'); await expect(board(page).locator('math')).toHaveCount(1);
  47 |   await page.getByRole('button',{name:'■ 停止阅读',exact:true}).click(); await expect(page.locator('.cl-subtitle')).toHaveText(original);
  48 |   await page.waitForTimeout(1600); await expect(page.locator('.cl-subtitle')).toHaveText(original);expect(audioCalls).toBe(0);
  49 |   await page.reload(); await expect(board(page).locator('tbody tr')).toHaveCount(2); await expect(board(page).locator('math')).toHaveCount(1);
  50 | });
  51 | 
  52 | test('audio ended advances frozen units, abort settles a pending reader and a new reply rejects late audio',async({page})=>{
  53 |   await enter(page); await ask(page); const original=await page.locator('.cl-subtitle').innerText();
  54 |   await page.evaluate(()=>{const instances:any[]=[];class ControlledAudio{playbackRate=1;onended:(()=>void)|null=null;onerror:(()=>void)|null=null;paused=false;constructor(public src:string){instances.push(this);}play(){return Promise.resolve();}pause(){this.paused=true;}}Object.assign(window,{Audio:ControlledAudio,__replyAudios:instances});});
  55 |   const requests:any[]=[];await page.route('**/api/learning/classroom/sessions/*/narration/*',async route=>{requests.push(route.request().postDataJSON());await route.fulfill({contentType:'audio/wav',body:wav()});});
  56 |   await page.getByRole('button',{name:'♪ 朗读这段回答',exact:true}).click(); await expect(page.locator('.cl-subtitle')).toHaveText('先固定总量。');
  57 |   await expect(board(page).locator('tbody tr')).toHaveCount(0);
  58 |   await page.evaluate(()=>(window as any).__replyAudios.at(-1).onended());await expect(page.locator('.cl-subtitle')).toHaveText('第一种分法是十二颗分成三组。');await expect(board(page).locator('tbody tr')).toHaveCount(1);
  59 |   expect(requests[0].presentationVersion).toBe('speech-v2');expect(requests[0].unitId).not.toBe(requests[1].unitId);
  60 |   await page.getByRole('button',{name:'■ 停止朗读',exact:true}).click(); await expect(page.locator('.cl-subtitle')).toHaveText(original);
  61 |   expect(await page.evaluate(()=>(window as any).__replyAudios.every((audio:any)=>audio.onended===null&&audio.onerror===null))).toBe(true);
  62 |   await ask(page,'[board-table] 再比较一遍。');
  63 |   let release!:()=>void,arrived!:()=>void;const held=new Promise<void>(resolve=>{release=resolve;}),arrival=new Promise<void>(resolve=>{arrived=resolve;});
  64 |   await page.unroute('**/api/learning/classroom/sessions/*/narration/*');
  65 |   await page.route('**/api/learning/classroom/sessions/*/narration/*',async route=>{arrived();await held;try{await route.fulfill({contentType:'audio/wav',body:wav()});}catch{/* Deliberate request abort. */}});
  66 |   await page.getByRole('button',{name:'♪ 朗读这段回答',exact:true}).first().click();await arrival;
  67 |   await page.getByRole('button',{name:'按句阅读这段回答',exact:true}).last().click();release();
  68 |   await expect(page.locator('.cl-subtitle')).toHaveText('先固定总量。');await expect(page.getByRole('button',{name:'■ 停止阅读',exact:true})).toHaveCount(1);
  69 |   await page.getByRole('button',{name:'■ 停止阅读',exact:true}).click();await page.waitForTimeout(1500);await expect(page.locator('.cl-subtitle')).toHaveText(original);
  70 | });
  71 | 
  72 | test('complete notes, cross-page reply navigation, keyboard activation and narrow layouts remain usable',async({page})=>{
  73 |   await enter(page);await ask(page);
  74 |   for(let index=0;index<3;index++)await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  75 |   await expect(page.locator('.cl-ai-board')).toHaveCount(0);
  76 |   const read=page.getByRole('button',{name:'按句阅读这段回答',exact:true});await read.focus();await page.keyboard.press('Enter');
> 77 |   await expect(board(page)).toBeInViewport({ratio:0.2});await expect(board(page).locator('tbody tr')).toHaveCount(0);
     |                             ^ Error: expect(locator).toBeInViewport() failed
  78 |   await board(page).getByRole('button',{name:'展开完整笔记'}).focus();await page.keyboard.press('Enter');await expect(board(page).locator('tbody tr')).toHaveCount(2);await expect(board(page).locator('math')).toHaveCount(1);
  79 |   await page.getByRole('button',{name:'■ 停止阅读',exact:true}).click();
  80 |   for(const width of [1440,768,390]){await page.setViewportSize({width,height:width===390?844:1000});if(width===390)await page.getByRole('button',{name:'白板',exact:true}).click();
  81 |     expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await expect(board(page).locator('tbody tr')).toHaveCount(2);await board(page).evaluate(element=>element.scrollIntoView({block:'start',behavior:'instant'}));await screen(page,'comparison-'+width);}
  82 | });
  83 | 
  84 | test('untrusted table/formula text stays inert in the board, actual offline HTML, Markdown and print',async({page,context})=>{
  85 |   await enter(page);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await ask(page,'[board-xss] 用表格比较。');
  86 |   await expect(board(page).locator('tbody')).toContainText('<img src=x onerror=');await expect(board(page).locator('img,script,iframe,a')).toHaveCount(0);await expect(board(page).locator('math')).toHaveCount(1);
  87 |   const download=page.waitForEvent('download');await page.getByRole('button',{name:'导出课堂笔记',exact:true}).click();const html=await download,path=await html.path();expect(html.suggestedFilename()).toContain('含图表.html');const content=readFileSync(path!,'utf8');
  88 |   expect(content).toContain('&lt;img');expect(content).not.toContain('<img src=x');expect(content).not.toContain('<script');expect(content).toContain('<math');expect(content).not.toContain('sourceSha256');
  89 |   const localHtml=resolve(evidence,'offline-notes-'+Date.now()+'.html');await html.saveAs(localHtml);const offline=await context.newPage(),network:string[]=[];offline.on('request',request=>{if(/^https?:/.test(request.url()))network.push(request.url());});await offline.goto(pathToFileURL(localHtml).href);await expect(offline.locator('table tbody tr')).toHaveCount(2);await expect(offline.locator('math')).toHaveCount(1);expect(await offline.evaluate(()=>(window as any).__boardXss)).toBeUndefined();expect(network).toEqual([]);await offline.close();
  90 |   await page.getByRole('button',{name:'课堂设置',exact:true}).click();const mdDownload=page.waitForEvent('download');await page.getByRole('button',{name:'导出 Markdown 文字笔记',exact:true}).click();const md=await mdDownload,mdText=readFileSync((await md.path())!,'utf8');expect(md.suggestedFilename()).toMatch(/\.md$/);expect(mdText).toContain('| 总量 | 份数 | 每份 |');expect(mdText).toContain('$$');expect(mdText).toContain('&lt;img');
  91 |   await page.evaluate(()=>Object.assign(window,{__printCalls:0,print:()=>{(window as any).__printCalls++;}}));await page.getByRole('button',{name:'打印 / 保存 PDF 笔记',exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).__printCalls)).toBe(1);
  92 |   await page.emulateMedia({media:'print'});await expect(page.locator('.cl-print-notes tbody tr')).toHaveCount(2);await expect(page.locator('.cl-print-notes math')).toHaveCount(1);await expect(page.locator('.cl-print-notes')).toBeVisible();expect(await page.locator('.cl-print-notes .cl-board-item').first().evaluate(element=>getComputedStyle(element).animationName)).toBe('none');await screen(page,'comparison-print');
  93 |   expect(await page.evaluate(()=>(window as any).__boardXss)).toBeUndefined();expect(errors).toEqual([]);
  94 | });
  95 | 
```