# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-neutral-voices.spec.ts >> a legacy voice can preview only the selected already-revealed frozen sentence
- Location: tests\e2e\classroom-neutral-voices.spec.ts:51:5

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 1
+ Received  + 1

  Object {
    "presentationVersion": "speech-v2",
-   "sentenceIndex": 0,
+   "sentenceIndex": 1,
    "voice": "Chinese (Mandarin)_Soft_Girl",
  }
```

# Page snapshot

```yaml
- generic:
  - alert [ref=f1e1]
  - main [ref=f1e2]:
    - region "教学白板" [ref=f1e3]:
      - generic [ref=f1e4]:
        - button "离开课堂" [ref=f1e5] [cursor=pointer]
        - button [ref=f1e8] [cursor=pointer]:
          - text: 社会学想象力
          - generic "断点已同步" [ref=f1e9]
      - generic [ref=f1e12]:
        - button "缩小白板" [ref=f1e13] [cursor=pointer]: −
        - button "重置缩放" [ref=f1e14] [cursor=pointer]: 100%
        - button "放大白板" [ref=f1e15] [cursor=pointer]: ＋
        - button "上一页白板" [disabled] [ref=f1e17]: ‹
        - generic [ref=f1e18]: 1 / 1
        - button "下一页白板" [disabled] [ref=f1e19]: ›
        - button "补一张讲解图" [ref=f1e21] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e22]: ▧
          - text: 配图
        - button "导出课堂笔记" [ref=f1e23] [cursor=pointer]
        - button "课堂设置" [ref=f1e26] [cursor=pointer]
        - button "切换对话面板" [ref=f1e29] [cursor=pointer]
      - generic [ref=f1e33]:
        - generic [ref=f1e34]:
          - heading "本节课导航" [level=2] [ref=f1e35]
          - list [ref=f1e36]:
            - listitem [ref=f1e37]: ·概念是什么？
            - listitem [ref=f1e38]: ·怎样解释生活？
            - listitem [ref=f1e39]: ·用什么证据核查？
        - generic [ref=f1e40]:
          - heading "社会学想象力" [level=2] [ref=f1e41]
          - list [ref=f1e42]:
            - listitem [ref=f1e43]: ·传记：个人经历与选择
            - listitem [ref=f1e44]: ·历史：时代、制度与社会条件
            - listitem [ref=f1e45]: ·交汇点：把个人处境放回社会背景
          - figure "传记与历史的交汇点 · 社会学想象力" [ref=f1e46]:
            - button "放大图片：传记与历史的交汇点 · 社会学想象力" [ref=f1e47] [cursor=pointer]:
              - img "个人处境与社会条件的交汇" [ref=f1e48]
              - generic [aria-hidden] [ref=f1e49]: ↗
      - generic [ref=f1e51]:
        - button "静音讲解" [ref=f1e52] [cursor=pointer]
        - paragraph [ref=f1e55]: 分析时同时追问个人处境和处境形成的社会条件。
    - separator "调整对话面板宽度" [ref=f1e56]
    - complementary [ref=f1e57]:
      - generic [ref=f1e58]:
        - generic [ref=f1e59]: Chat history
        - button "隐藏对话面板" [ref=f1e62] [cursor=pointer]
      - tablist "课堂内容" [ref=f1e65]:
        - tab "讲解与插问" [selected] [ref=f1e66] [cursor=pointer]
        - tab "课堂练习" [ref=f1e67] [cursor=pointer]
        - tab "单元项目" [ref=f1e68] [cursor=pointer]
      - generic "课堂对话历史" [ref=f1e69]:
        - article [ref=f1e70]:
          - text: 21:52
          - paragraph [ref=f1e71]: 今天一起研究“社会学想象力”。
          - paragraph [ref=f1e72]: 先记住三个问题：这个概念指什么？
          - paragraph [ref=f1e73]: 它怎样解释具体生活？
          - paragraph [ref=f1e74]: 什么证据能帮助我们判断解释是否站得住？
          - button "♧ 本节课导航" [ref=f1e75] [cursor=pointer]
        - article [ref=f1e76]:
          - text: TEACHER
          - paragraph [ref=f1e77]: 米尔斯把个人的生活历程与时代、制度联系起来。
          - paragraph [ref=f1e78]: 分析时同时追问个人处境和处境形成的社会条件。
          - button "♧ 社会学想象力" [ref=f1e79] [cursor=pointer]
        - status [ref=f1e80]: ••• Paused
      - generic [ref=f1e81]:
        - button "‹ 上一步" [ref=f1e82] [cursor=pointer]
        - generic [ref=f1e83]: 2 / 8
        - button "下一步 ›" [ref=f1e84] [cursor=pointer]
      - generic [ref=f1e85]:
        - group "调整讲法" [ref=f1e86]:
          - button "提问" [pressed] [ref=f1e87] [cursor=pointer]
          - button "换个例子" [ref=f1e88] [cursor=pointer]
          - button "说简单点" [ref=f1e89] [cursor=pointer]
          - button "补先修" [ref=f1e90] [cursor=pointer]
          - button "比较讲法" [ref=f1e91] [cursor=pointer]
        - generic [ref=f1e92]:
          - textbox "向课堂老师提问" [ref=f1e93]:
            - /placeholder: Ask a question…
          - button "语音提问" [ref=f1e94] [cursor=pointer]: ♩
          - button "继续讲解" [ref=f1e95] [cursor=pointer]: ▷
          - button "停止课堂讲解" [ref=f1e96] [cursor=pointer]: ■
        - combobox "选择大模型" [ref=f1e99] [cursor=pointer]:
          - option "Auto · 当前默认模型"
          - option "GPT-6.1 Sol"
          - option "GPT-6 Astra"
          - option "GPT-6 Luna"
          - option "Grok-4.7"
          - option "GLM-5.3 Flash"
          - option "DeepSeek V4.1 Flash · 默认" [selected]
          - option "Claude Opus 5.5"
          - option "Claude Sonnet 5"
          - option "GPT-6 Sol"
          - option "GPT-5.6 Sol"
          - option "GPT-5.6 Terra"
          - option "GPT-5.6 Luna"
          - option "GPT-5.5"
          - option "Grok-4.6"
          - option "GLM-5.2"
          - option "GLM-5.3"
          - option "Claude Opus 5"
          - option "Claude Fable 5.1"
          - option "MiMo V2.6 Pro"
          - option "MiMo V2.6 Flash"
          - option "MiMo V2.6 Pro Ultraspeed"
          - option "Qwen3.8 Max"
    - dialog "课堂设置" [ref=f1e102]:
      - generic [ref=f1e103]:
        - heading "Session settings" [level=2] [ref=f1e104]
        - button "关闭课堂设置" [ref=f1e105] [cursor=pointer]: ×
      - heading "VOICE OPTIONS 柔和少女" [level=3] [ref=f1e106]:
        - text: VOICE OPTIONS
        - generic [ref=f1e107]: 柔和少女
      - radiogroup "课堂音色" [ref=f1e108]:
        - generic [ref=f1e109]:
          - radio "Warm 温暖少女 普通话" [ref=f1e110] [cursor=pointer]:
            - generic [ref=f1e117]:
              - text: Warm
              - generic [ref=f1e118]:
                - generic [ref=f1e119]: 温暖少女
                - generic [ref=f1e120]: 普通话
          - button "试听音色：温暖少女" [ref=f1e121] [cursor=pointer]
        - generic [ref=f1e124]:
          - radio "Calm 温润男声 普通话" [ref=f1e125] [cursor=pointer]:
            - generic [ref=f1e132]:
              - text: Calm
              - generic [ref=f1e133]:
                - generic [ref=f1e134]: 温润男声
                - generic [ref=f1e135]: 普通话
          - button "试听音色：温润男声" [ref=f1e136] [cursor=pointer]
        - generic [ref=f1e139]:
          - radio "Bright 清脆少女 普通话" [ref=f1e140] [cursor=pointer]:
            - generic [ref=f1e147]:
              - text: Bright
              - generic [ref=f1e148]:
                - generic [ref=f1e149]: 清脆少女
                - generic [ref=f1e150]: 普通话
          - button "试听音色：清脆少女" [ref=f1e151] [cursor=pointer]
        - generic [ref=f1e154]:
          - radio "Gentle 温柔学姐 普通话" [ref=f1e155] [cursor=pointer]:
            - generic [ref=f1e162]:
              - text: Gentle
              - generic [ref=f1e163]:
                - generic [ref=f1e164]: 温柔学姐
                - generic [ref=f1e165]: 普通话
          - button "试听音色：温柔学姐" [ref=f1e166] [cursor=pointer]
        - generic [ref=f1e169]:
          - radio "Professional 播报男声 普通话" [ref=f1e170] [cursor=pointer]:
            - generic [ref=f1e177]:
              - text: Professional
              - generic [ref=f1e178]:
                - generic [ref=f1e179]: 播报男声
                - generic [ref=f1e180]: 普通话
          - button "试听音色：播报男声" [ref=f1e181] [cursor=pointer]
        - generic [ref=f1e184]:
          - radio "Lively 俏皮萌妹 普通话" [ref=f1e185] [cursor=pointer]:
            - generic [ref=f1e192]:
              - text: Lively
              - generic [ref=f1e193]:
                - generic [ref=f1e194]: 俏皮萌妹
                - generic [ref=f1e195]: 普通话
          - button "试听音色：俏皮萌妹" [ref=f1e196] [cursor=pointer]
      - generic [ref=f1e199]:
        - generic [ref=f1e200]:
          - text: 其他可用音色
          - combobox "其他可用音色" [ref=f1e201]:
            - option "选择其他音色" [disabled]
            - option "柔和少女" [selected]
            - option "妩媚御姐"
        - button "试听所选音色" [active] [ref=f1e202] [cursor=pointer]
      - group "试听内容" [ref=f1e203]:
        - button "音色样本" [ref=f1e204] [cursor=pointer]
        - button "当前句" [pressed] [ref=f1e205] [cursor=pointer]
      - status [ref=f1e206]: 试听已出现的当前句，所选音色与学习进度保持原样。
      - heading "VOICE SPEED 1×" [level=3] [ref=f1e207]:
        - text: VOICE SPEED
        - generic [ref=f1e208]: 1×
      - slider "课堂语速" [ref=f1e209] [cursor=pointer]: "2"
      - generic [ref=f1e210]:
        - button "0.5×" [ref=f1e211] [cursor=pointer]
        - button "0.75×" [ref=f1e212] [cursor=pointer]
        - button "1×" [ref=f1e213] [cursor=pointer]
        - button "1.25×" [ref=f1e214] [cursor=pointer]
        - button "1.5×" [ref=f1e215] [cursor=pointer]
        - button "2×" [ref=f1e216] [cursor=pointer]
      - heading "BOARD FONT" [level=3] [ref=f1e217]
      - generic [ref=f1e218]:
        - button "Aa Bb Handwriting" [ref=f1e219] [cursor=pointer]:
          - generic [ref=f1e220]: Aa Bb
          - generic [ref=f1e221]: Handwriting
        - button "Aa Bb Standard" [ref=f1e222] [cursor=pointer]:
          - generic [ref=f1e223]: Aa Bb
          - generic [ref=f1e224]: Standard
      - heading "DISPLAY" [level=3] [ref=f1e225]
      - switch "Background dots 白板背后的点阵背景" [checked] [ref=f1e226] [cursor=pointer]:
        - generic [ref=f1e227]:
          - text: Background dots
          - generic [ref=f1e228]: 白板背后的点阵背景
      - heading "HELP" [level=3] [ref=f1e230]
      - button "Replay the tour 重新了解课堂里的七个常用控件 ↗" [ref=f1e231] [cursor=pointer]:
        - generic [ref=f1e232]:
          - text: Replay the tour
          - generic [ref=f1e233]: 重新了解课堂里的七个常用控件
        - text: ↗
      - region "字幕节奏" [ref=f1e234]:
        - generic [ref=f1e235]:
          - generic [ref=f1e236]: 字幕与讲解
          - generic [ref=f1e237]: 当前逐句节奏
      - button "导出 Markdown 文字笔记" [ref=f1e238] [cursor=pointer]
      - button "打印 / 保存 PDF 笔记" [ref=f1e239] [cursor=pointer]
      - paragraph [ref=f1e240]: 音色在下一句生效，倍速同步当前音频。暂停后会从当前句开头继续。
    - text: · · · · · ·
```

# Test source

```ts
  1  | import { test,expect,type Page } from '@playwright/test';
  2  | import { readFileSync } from 'node:fs';
  3  | import { resolve } from 'node:path';
  4  | import { browserEvidence } from './evidence';
  5  | const manifest=JSON.parse(readFileSync('apps/web/public/classroom-voice-samples/manifest.json','utf8'));
  6  | const evidence=browserEvidence('neutral-voices');let address=0;
  7  | const api='http://localhost:'+(process.env.E2E_API_PORT??'4107')+'/api';
  8  | async function enter(page:Page){
  9  |   const suffix=crypto.randomUUID(),principal='neutral-browser-'+suffix+'@local.test',credential='Neutral-QA-'+suffix;
  10 |   const registered=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json','X-Forwarded-For':'198.18.12.'+(++address)},body:JSON.stringify({principal,credential})});expect(registered.status).toBe(201);
  11 |   const actor=(await registered.json()).data;
  12 |   await page.addInitScript(()=>{
  13 |     localStorage.setItem('studyagent.classroom.tour','done');const NativeAudio=window.Audio;(window as any).__neutralAudio=[];
  14 |     window.Audio=class extends NativeAudio{constructor(src?:string){super(src);(window as any).__neutralAudio.push(this);}};
  15 |   });
  16 |   await page.route(/\/api\/learning\/classroom\/sessions(?:\/[^/?]+)?$/,async route=>{
  17 |     const response=await route.fetch(),body=await response.json();if(body.data?.lesson)body.data.speech={available:true,provider:'minimax',defaultVoice:manifest.voices[3].voiceId,
  18 |       preview:{version:manifest.version,text:manifest.text,model:manifest.model},voices:[...manifest.voices.map((voice:any)=>({id:voice.voiceId,label:voice.providerName,classroomPreset:voice.preset,description:voice.providerName,language:'普通话'})),
  19 |         {id:'Chinese (Mandarin)_Soft_Girl',label:'柔和少女'},{id:'wumei_yujie',label:'妩媚御姐'}]};
  20 |     await route.fulfill({response,json:body});
  21 |   });
  22 |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  23 |   await page.goto('/studio/classroom?lesson=soc-1-1-1');await expect(page.locator('.cl-room')).toBeVisible();await page.getByRole('button',{name:'课堂设置',exact:true}).click();
  24 |   return {actor,settings:page.getByRole('dialog',{name:'课堂设置'})};
  25 | }
  26 | async function audio(page:Page){return page.evaluate(()=>(window as any).__neutralAudio.some((item:HTMLAudioElement)=>!item.paused));}
  27 | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  28 | 
  29 | test('a neutral sample decodes before the first lecture, changes no selection and sends only its fixed version',async({page})=>{
  30 |   let command:any,progress=0;await page.route('**/api/learning/classroom/sessions/*/voice-preview',async route=>{command=route.request().postDataJSON();const voice=manifest.voices.find((item:any)=>item.voiceId===command.voice);expect(voice).toBeTruthy();await route.fulfill({contentType:'audio/mpeg',path:resolve('apps/web/public/classroom-voice-samples',voice.file)});});
  31 |   const {settings}=await enter(page);page.on('request',request=>{if(request.method()==='PATCH'&&/\/classroom\/sessions\/[^/?]+$/.test(request.url()))progress++;});
  32 |   await expect(settings.getByRole('button',{name:'当前句',exact:true})).toBeDisabled();await expect(settings.getByRole('radio',{name:/Gentle/})).toHaveAttribute('aria-checked','true');
  33 |   await settings.getByRole('button',{name:'试听音色：温暖少女',exact:true}).click();await expect.poll(()=>audio(page)).toBe(true);
  34 |   expect(command).toEqual({voice:manifest.voices[0].voiceId,sampleVersion:manifest.version});expect(progress).toBe(0);await expect(settings.getByRole('radio',{name:/Gentle/})).toHaveAttribute('aria-checked','true');
  35 |   await settings.getByRole('button',{name:'1.5×',exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).__neutralAudio.find((item:HTMLAudioElement)=>!item.paused)?.playbackRate)).toBe(1.5);
  36 |   await settings.getByRole('button',{name:'停止试听：温暖少女',exact:true}).click();await expect.poll(()=>audio(page)).toBe(false);
  37 | });
  38 | 
  39 | test('closing the settings aborts an unfinished sample and its late audio cannot start',async({page})=>{
  40 |   let release!:()=>void,arrive!:()=>void;const hold=new Promise<void>(resolve=>release=resolve),arrival=new Promise<void>(resolve=>arrive=resolve);
  41 |   await page.route('**/api/learning/classroom/sessions/*/voice-preview',async route=>{arrive();await hold;try{await route.fulfill({contentType:'audio/mpeg',path:resolve('apps/web/public/classroom-voice-samples',manifest.voices[1].file)});}catch{/* The exact reader has aborted. */}});
  42 |   try{const {settings}=await enter(page);await settings.getByRole('button',{name:'试听音色：温润男声',exact:true}).click();await arrival;await settings.getByRole('button',{name:'关闭课堂设置',exact:true}).click();release();await expect(settings).toHaveCount(0);await expect.poll(()=>page.evaluate(()=>(window as any).__neutralAudio.length)).toBe(0);}finally{release?.();}
  43 | });
  44 | 
  45 | test('failed neutral playback keeps an explicit retry and cannot advance or reveal the lesson',async({page})=>{
  46 |   let fail=true;await page.route('**/api/learning/classroom/sessions/*/voice-preview',route=>fail?route.fulfill({status:503,json:{data:null,error:{code:'unavailable',message:'Synthetic sample unavailable'}}}):route.fulfill({contentType:'audio/mpeg',path:resolve('apps/web/public/classroom-voice-samples',manifest.voices[0].file)}));
  47 |   const {settings}=await enter(page);await settings.getByRole('button',{name:'试听音色：温暖少女',exact:true}).click();await expect(settings.getByRole('status')).toContainText('试听暂不可用');fail=false;
  48 |   await settings.getByRole('button',{name:'试听音色：温暖少女',exact:true}).click();await expect.poll(()=>audio(page)).toBe(true);await expect(settings.getByRole('button',{name:'当前句',exact:true})).toBeDisabled();
  49 | });
  50 | 
  51 | test('a legacy voice can preview only the selected already-revealed frozen sentence',async({page})=>{
  52 |   let command:any;await page.route('**/api/learning/classroom/sessions/*/narration/*',async route=>{command=route.request().postDataJSON();await route.fulfill({contentType:'audio/mpeg',path:resolve('apps/web/public/classroom-voice-samples',manifest.voices[0].file)});});
  53 |   const {settings}=await enter(page);await settings.getByRole('button',{name:'关闭课堂设置',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  54 |   await page.getByRole('button',{name:'课堂设置',exact:true}).click();await settings.getByLabel('其他可用音色').selectOption('Chinese (Mandarin)_Soft_Girl');await expect(settings.getByRole('radio',{checked:true})).toHaveCount(0);
  55 |   await settings.getByRole('button',{name:'当前句',exact:true}).click();await settings.getByRole('button',{name:'试听所选音色',exact:true}).click();await expect.poll(()=>audio(page)).toBe(true);
> 56 |   expect(command).toMatchObject({voice:'Chinese (Mandarin)_Soft_Girl',sentenceIndex:0,presentationVersion:'speech-v2'});expect(command.unitId).toBeTruthy();expect(command).not.toHaveProperty('sampleVersion');
     |                   ^ Error: expect(received).toMatchObject(expected)
  57 |   await expect(settings.getByLabel('其他可用音色')).toHaveValue('Chinese (Mandarin)_Soft_Girl');await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  58 | });
  59 | 
  60 | for(const width of [390,768,1440])test('six real voice cards and preview controls fit at '+width,async({page})=>{
  61 |   await page.setViewportSize({width,height:1000});const {settings}=await enter(page);await expect(settings.getByRole('radio')).toHaveCount(6);await expect(settings.getByRole('button',{name:'试听音色：播报男声',exact:true})).toBeEnabled();
  62 |   await settings.getByRole('radio',{name:/Warm/}).focus();await page.keyboard.press('ArrowRight');await expect(settings.getByRole('radio',{name:/Calm/})).toBeFocused();expect(await page.evaluate(()=>(window as any).__neutralAudio.length)).toBe(0);
  63 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/settings-'+width+'.png'});
  64 | });
  65 | 
```