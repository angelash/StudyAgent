# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom.spec.ts >> independent practice matches four-option illustrated question flow on desktop and phone
- Location: tests\e2e\classroom.spec.ts:197:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.cl-practice-progress button')
Expected: 5
Received: 6
Timeout:  15000ms

Call log:
  - Expect "toHaveCount" locator('.cl-practice-progress button') with timeout 15000ms
  - waiting for locator('.cl-practice-progress button')
    33 × locator resolved to 6 elements
       - unexpected value "6"

```

# Page snapshot

```yaml
- generic [active]:
  - alert [ref=f1e1]
  - main [ref=f1e2]:
    - region "课堂练习题目" [ref=f1e3]:
      - generic [ref=f1e4]:
        - button "关闭独立练习" [ref=f1e5] [cursor=pointer]: ×
        - navigation "题目进度" [ref=f1e6]:
          - button "第1题" [ref=f1e7] [cursor=pointer]
          - button "第2题" [ref=f1e8] [cursor=pointer]
          - button "第3题" [ref=f1e9] [cursor=pointer]
          - button "第4题" [ref=f1e10] [cursor=pointer]
          - button "第5题" [ref=f1e11] [cursor=pointer]
          - button "第6题" [ref=f1e12] [cursor=pointer]
        - generic [ref=f1e13]: 已答 0/6
        - button "☏ Assistant" [ref=f1e14] [cursor=pointer]
      - generic [ref=f1e15]:
        - generic "题目作答区域，数字键选择，回车提交" [ref=f1e16]:
          - generic [ref=f1e17]:
            - generic [ref=f1e18]: SINGLE CHOICE · 1 / 6 · 社会学想象力
            - heading "根据 C. Wright Mills 的分析，“社会学想象力”帮助我们怎样理解个人经历与社会环境之间的关系？" [level=2] [ref=f1e19]
            - paragraph [ref=f1e20]: 选择一个最合适的选项。
            - status [ref=f1e21]: 当前选择：未选
            - figure "传记与历史" [ref=f1e22]:
              - button "放大图片：传记与历史" [ref=f1e23] [cursor=pointer]:
                - img "个人传记与历史结构相交的韦恩图" [ref=f1e24]
                - generic [aria-hidden] [ref=f1e25]: ↗
          - group "选择一个选项" [ref=f1e27]:
            - generic [ref=f1e29] [cursor=pointer]:
              - radio "把个人经历与时代、制度联系起来" [ref=f1e30]
              - generic [aria-hidden] [ref=f1e31]: ▲
              - generic [ref=f1e32]: 把个人经历与时代、制度联系起来
              - generic [aria-hidden] [ref=f1e33]: "1"
            - generic [ref=f1e34] [cursor=pointer]:
              - radio "只研究人的性格" [ref=f1e35]
              - generic [aria-hidden] [ref=f1e36]: ◆
              - generic [ref=f1e37]: 只研究人的性格
              - generic [aria-hidden] [ref=f1e38]: "2"
            - generic [ref=f1e39] [cursor=pointer]:
              - radio "证明个人没有任何选择" [ref=f1e40]
              - generic [aria-hidden] [ref=f1e41]: ●
              - generic [ref=f1e42]: 证明个人没有任何选择
              - generic [aria-hidden] [ref=f1e43]: "3"
            - generic [ref=f1e44] [cursor=pointer]:
              - radio "用个人成功证明所有制度公平" [ref=f1e45]
              - generic [aria-hidden] [ref=f1e46]: ■
              - generic [ref=f1e47]: 用个人成功证明所有制度公平
              - generic [aria-hidden] [ref=f1e48]: "4"
        - button "先给我一个提示" [ref=f1e50] [cursor=pointer]
        - generic [ref=f1e51]:
          - button "Check →" [disabled] [ref=f1e52]
          - button "Skip" [ref=f1e53] [cursor=pointer]
          - button "这题我不会" [ref=f1e54] [cursor=pointer]
```

# Test source

```ts
  102 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  103 |   await expect(page.getByRole('dialog', { name: '课堂学习里程碑' })).toBeVisible();
  104 | });
  105 | 
  106 | test('question replies add safe board notes with page links, export and restored session rendering', async ({ page }) => {
  107 |   test.setTimeout(90000); await page.setViewportSize({ width: 1552, height: 1199 }); await login(page);
  108 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  109 |   const board = { title: '把困惑拆成可核查的问题', points: ['比较不同条件，再找相同处境中的反例。', '<img src=x onerror="window.boardExecuted=true">'],
  110 |     page: 0, diagram: { kind: 'flow', title: '核查路线', labels: ['观察处境', '比较条件', '寻找反例'] } };
  111 |   let messages: unknown[] | undefined;
  112 |   const withBoardNotes = async (route: import('@playwright/test').Route) => {
  113 |     const response = await route.fetch(), body = await response.json();
  114 |     if (messages) body.data.messages = messages;
  115 |     await route.fulfill({ response, json: body });
  116 |   };
  117 |   await page.route('**/api/learning/classroom/sessions', withBoardNotes);
  118 |   await page.route('**/api/learning/classroom/sessions/*', withBoardNotes);
  119 |   await page.route('**/api/learning/classroom/sessions/*/turns', async route => {
  120 |     if(route.request().method()!=='POST'){await route.fallback();return;}
  121 |     const response = await route.fetch({ method: 'GET', url: route.request().url().replace(/\/turns$/, '') });
  122 |     const body = await response.json(), at = new Date().toISOString();
  123 |     messages = [{ id: 'question-fixture', role: 'user', content: route.request().postDataJSON().message, at },
  124 |       { id: 'answer-fixture', role: 'assistant', content: '先比较情境中的条件，再寻找能否排除其他解释的证据。', at, modelName: '课堂测试模型', board }];
  125 |     const input=route.request().postDataJSON(),session=body.data,step=session.lesson.steps[session.cursor];
  126 |     await route.fulfill({ status: 201, json: {data:{id:'turn-fixture',sessionId:session.id,requestKey:input.requestKey,message:input.message,intent:input.intent,modelId:input.modelId,modelName:'课堂测试模型',status:'completed',revision:1,createdAt:at,updatedAt:at,assistantMessageId:'answer-fixture',position:{...input,cursor:session.cursor,stepTitle:step.title,sentenceText:session.presentation.tracks[step.id].units[session.sentenceCursor??0].text},task:{state:'succeeded',version:2,generation:1,errorCode:null}}} });
  127 |   });
  128 |   await page.goto('/studio/classroom?lesson=soc-1-1-1');
  129 |   await page.getByLabel('向课堂老师提问').fill('如何把解释变成可验证的问题？');
  130 |   await page.getByRole('button', { name: '发送课堂问题' }).click();
  131 |   await expect(page.locator('.cl-ai-board')).toContainText(board.title);
  132 |   await expect(page.locator('.cl-ai-board')).toContainText(board.points[1]);
  133 |   await expect(page.locator('.cl-ai-board img')).toHaveCount(0);
  134 |   await expect(page.locator('.cl-ai-board').getByRole('img', { name: '核查路线' })).toBeVisible();
  135 |   for (let index = 0; index < 3; index++) {
  136 |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  137 |     await expect(page.locator('.cl-session-navigation')).toContainText((index + 2) + ' / 8');
  138 |   }
  139 |   await expect(page.locator('.cl-ai-board')).toHaveCount(0);
  140 |   await page.getByRole('button', { name: '♧ ' + board.title, exact: true }).click();
  141 |   await expect(page.locator('.cl-ai-board')).toBeVisible();
  142 |   await page.reload();
  143 |   await page.getByRole('button', { name: '♧ ' + board.title, exact: true }).click();
  144 |   await expect(page.locator('.cl-ai-board')).toContainText(board.points[0]);
  145 |   await expect(page.locator('.cl-print-notes')).toContainText(board.title);
  146 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '导出课堂笔记' }).click();
  147 |   const stream = await (await download).createReadStream(); let markdown = '';
  148 |   for await (const chunk of stream!) markdown += chunk.toString();
  149 |   expect(markdown).toContain('### ' + board.title); expect(markdown).toContain('核查路线：观察处境 / 比较条件 / 寻找反例');
  150 |   if (!process.env.CI) {
  151 |     board.points[1] = '用新的匿名情境检验解释，保留反例。'; await page.reload();
  152 |     await page.getByRole('button', { name: '♧ ' + board.title, exact: true }).click();
  153 |     await expect(page.locator('.cl-ai-board')).toContainText(board.points[1]);
  154 |     await expect(page.locator('.cl-ai-board')).toHaveCSS('opacity', '1');
  155 |     await page.screenshot({ path: evidenceDirectory + '/classroom-ai-board.png', fullPage: true });
  156 |   }
  157 | });
  158 | 
  159 | test('board notes reveal whole items and subtitle advances only at spoken sentence boundaries', async ({ page }) => {
  160 |   test.setTimeout(60000); await login(page);
  161 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  162 |   const withSpeech = async (route: import('@playwright/test').Route) => {
  163 |     const response = await route.fetch(), body = await response.json();
  164 |     body.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture', voices: [{ id: 'fixture', label: '测试音轨' }] };
  165 |     await route.fulfill({ response, json: body });
  166 |   };
  167 |   await page.route('**/api/learning/classroom/sessions', withSpeech);
  168 |   await page.route('**/api/learning/classroom/sessions/*', withSpeech);
  169 |   const requested: number[] = [];
  170 |   await page.route('**/api/learning/classroom/sessions/*/narration/*', async route => {
  171 |     requested.push(route.request().postDataJSON().sentenceIndex);
  172 |     await route.fulfill({ contentType: 'audio/wav', body: wav(3) });
  173 |   });
  174 |   await page.goto('/studio/classroom?lesson=soc-1-1-1');
  175 |   await page.getByRole('button', { name: '▶ 开始学习' }).click();
  176 |   await expect(page.locator('.cl-subtitle')).toHaveText('今天一起研究“社会学想象力”。');
  177 |   await expect(page.locator('.cl-board-area .cl-board-points li')).toHaveCount(1);
  178 |   await expect(page.locator('.cl-board-area .cl-board-points li')).toHaveText('概念是什么？');
  179 |   await page.waitForTimeout(600);
  180 |   await expect(page.locator('.cl-subtitle')).toHaveText('今天一起研究“社会学想象力”。');
  181 |   await expect(page.locator('.cl-board-area .cl-board-points li')).toHaveCount(1);
  182 |   await expect(page.locator('.cl-subtitle')).toHaveAttribute('data-sentence', '1');
  183 |   await page.getByRole('button', { name: '暂停讲解' }).click();
  184 |   await expect(page.locator('.cl-board-area .cl-board-points li')).toHaveCount(2);
  185 |   await expect(page.locator('.cl-board-area .cl-board-points li').nth(1)).toHaveText('怎样解释生活？');
  186 |   const subtitle = await page.locator('.cl-subtitle').innerText();
  187 |   await page.waitForTimeout(3500); await expect(page.locator('.cl-subtitle')).toHaveText(subtitle);
  188 |   await page.reload(); await expect(page.locator('.cl-subtitle')).toHaveText(subtitle);
  189 |   await expect(page.locator('.cl-board-area .cl-board-points li')).toHaveCount(2);
  190 |   expect(requested.slice(0, 2)).toEqual([0, 1]);
  191 |   await page.getByRole('button', { name: '继续讲解' }).click();
  192 |   await expect.poll(() => requested.filter(index => index === 1).length).toBe(2);
  193 |   await expect(page.locator('.cl-subtitle')).toHaveText(subtitle);
  194 |   await page.getByRole('button', { name: '暂停讲解' }).click();
  195 | });
  196 | 
  197 | test('independent practice matches four-option illustrated question flow on desktop and phone', async ({ page }) => {
  198 |   await page.setViewportSize({ width: 1250, height: 1199 }); await login(page);
  199 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  200 |   await page.goto('/studio/classroom?lesson=soc-1-1-1&tab=practice');
  201 |   await expect(page.getByRole('region', { name: '课堂练习题目' })).toBeVisible();
> 202 |   await expect(page.locator('.cl-practice-progress button')).toHaveCount(5);
      |                                                              ^ Error: expect(locator).toHaveCount(expected) failed
  203 |   await expect(page.locator('.cl-practice-options label')).toHaveCount(4);
  204 |   await expect(page.locator('.cl-practice-image img')).toHaveJSProperty('complete', true);
  205 |   await expect(page.locator('.cl-practice-image img')).toHaveJSProperty('naturalWidth', 1024);
  206 |   await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled();
  207 |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-practice-v2.png', fullPage: true });
  208 |   await page.locator('.cl-practice-prompt h2').click(); await page.keyboard.press('1');
  209 |   await page.getByRole('button', { name: 'Check →' }).click();
  210 |   await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');
  211 |   await page.getByRole('button', { name: '下一题 →' }).click();
  212 |   await page.getByRole('button', { name: 'Skip', exact: true }).click();
  213 |   await expect(page.locator('.cl-answer-feedback')).toContainText('已跳过');
  214 |   await page.getByRole('button', { name: '☏ Assistant' }).click();
  215 |   await expect(page.getByLabel('向课堂老师提问')).toBeVisible();
  216 |   await page.getByRole('button', { name: '隐藏对话面板' }).click();
  217 |   await page.setViewportSize({ width: 390, height: 844 });
  218 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  219 |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-practice-phone-v2.png', fullPage: true });
  220 |   await page.reload(); await page.getByRole('button', { name: '第2题', exact: true }).click();
  221 |   await expect(page.locator('.cl-answer-feedback')).toContainText('已跳过');
  222 | });
  223 | 
  224 | test.describe('reference viewport and display scaling', () => {
  225 |   test.use({ viewport: { width: 1000, height: 959 }, deviceScaleFactor: 1.25 });
  226 |   test('practice geometry, whiteboard image and comparison table use the observed display scale', async ({ page }) => {
  227 |     await login(page); await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  228 |     await page.goto('/studio/classroom?lesson=soc-1-1-1&tab=practice');
  229 |     await expect(page.locator('.cl-practice-options')).toBeVisible();
  230 |     const card = await page.locator('.cl-practice-card').boundingBox();
  231 |     expect(card?.x).toBe(36); expect(card?.y).toBe(52); expect(card?.width).toBe(928);
  232 |     if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-practice-reference-scale-v2.png' });
  233 |     await page.goto('/studio/classroom?lesson=soc-1-1-1');
  234 |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  235 |     await page.getByRole('button', { name: '放大图片：传记与历史的交汇点 · 社会学想象力' }).click();
  236 |     await expect(page.getByRole('dialog', { name: '传记与历史的交汇点 · 社会学想象力' })).toBeVisible();
  237 |     await page.keyboard.press('Escape');
  238 |     await expect(page.getByRole('dialog', { name: '传记与历史的交汇点 · 社会学想象力' })).toHaveCount(0);
  239 |     await expect(page.locator('.cl-board-area .cl-board-step[data-current=true]')).toHaveCSS('opacity', '1');
  240 |     await page.locator('.cl-board-area .cl-lesson-image').scrollIntoViewIfNeeded();
  241 |     await expect(page.locator('.cl-board-area .cl-lesson-image')).toBeInViewport({ ratio: 0.8 });
  242 |     if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-board-reference-scale-v2.png' });
  243 |     for (let index = 0; index < 4; index++) {
  244 |       const before = await page.locator('.cl-session-navigation').innerText();
  245 |       await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  246 |       await expect(page.locator('.cl-session-navigation')).not.toHaveText(before, { useInnerText: true });
  247 |     }
  248 |     await expect(page.locator('.cl-board-area table')).toBeVisible();
  249 |     await expect(page.locator('.cl-board-area table tbody tr')).toHaveCount(2);
  250 |     await expect(page.locator('.cl-board-area .cl-board-step[data-current=true]')).toHaveCSS('opacity', '1');
  251 |     await page.locator('.cl-board-area table').scrollIntoViewIfNeeded();
  252 |     await expect(page.locator('.cl-board-area table')).toBeInViewport({ ratio: 0.8 });
  253 |     if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-table-reference-scale-v2.png' });
  254 |   });
  255 | });
  256 | 
```