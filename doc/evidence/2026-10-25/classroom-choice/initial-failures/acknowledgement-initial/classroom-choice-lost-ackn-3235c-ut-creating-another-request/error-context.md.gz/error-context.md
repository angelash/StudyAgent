# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-choice.spec.ts >> lost acknowledgement is resolved by reading the saved first answer without creating another request
- Location: tests\e2e\classroom-choice.spec.ts:38:5

# Error details

```
Error: route.abort: Route is already handled!
```

```
Error: locator.click: Test ended.
Call log:
  - waiting for getByRole('button', { name: '读取并恢复原提交' })
    - locator resolved to <button disabled>读取并恢复原提交</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is not stable
  - retrying click action
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Page snapshot

```yaml
- generic [active]:
  - alert [ref=f1e1]
  - main [ref=f1e2]:
    - region "课堂练习题目" [ref=f1e3]:
      - generic [ref=f1e4]:
        - button "关闭独立练习" [ref=f1e5] [cursor=pointer]: ×
        - navigation "题目进度" [ref=f1e6]:
          - button "第1题" [ref=f1e7] [cursor=pointer]
          - button "第2题" [ref=f1e8] [cursor=pointer]
          - button "第3题" [ref=f1e9] [cursor=pointer]
          - button "第4题" [ref=f1e10] [cursor=pointer]
        - generic [ref=f1e11]: 已答 1/4
        - button "☏ Assistant" [ref=f1e12] [cursor=pointer]
      - generic [ref=f1e13]:
        - generic "题目作答区域，数字键选择，回车提交" [ref=f1e14]:
          - generic [ref=f1e15]:
            - generic [ref=f1e16]: MULTIPLE CHOICE · 4 / 4 · 结构与能动性
            - heading "夜班员工推动公交延长运营时间。哪些观察能同时体现结构约束与能动性？" [level=2] [ref=f1e17]
            - paragraph [ref=f1e18]: 选择所有符合项。本题须选全且不多选。
            - status [ref=f1e19]: 首次提交已锁定：1
          - group "选择所有符合项，首次作答已锁定" [ref=f1e20]:
            - generic [ref=f1e22]:
              - checkbox "员工协商、组织并提出线路调整建议 ✓ 选对 · 组织与协商是改变条件的行动。 1" [checked] [disabled] [ref=f1e23]
              - generic [aria-hidden] [ref=f1e24]: ▲
              - generic [ref=f1e25]:
                - text: 员工协商、组织并提出线路调整建议
                - generic [ref=f1e26]: ✓ 选对 · 组织与协商是改变条件的行动。
              - generic [ref=f1e27]: "1"
            - generic [ref=f1e28]:
              - checkbox "建议提交后，预算和审批条件就自动消失 不符合 · 表达诉求不会自动消除制度与资源条件。 2" [disabled] [ref=f1e29]
              - generic [aria-hidden] [ref=f1e30]: ◆
              - generic [ref=f1e31]:
                - text: 建议提交后，预算和审批条件就自动消失
                - generic [ref=f1e32]: 不符合 · 表达诉求不会自动消除制度与资源条件。
              - generic [ref=f1e33]: "2"
            - generic [ref=f1e34]:
              - checkbox "方案效果还受到班次、经费和实际需求的影响 ○ 漏选 · 行动效果需要联系具体实施条件。 3" [disabled] [ref=f1e35]
              - generic [aria-hidden] [ref=f1e36]: ●
              - generic [ref=f1e37]:
                - text: 方案效果还受到班次、经费和实际需求的影响
                - generic [ref=f1e38]: ○ 漏选 · 行动效果需要联系具体实施条件。
              - generic [ref=f1e39]: "3"
            - generic [ref=f1e40]:
              - checkbox "现行末班车时间压缩了夜班员工的通勤选择 ○ 漏选 · 规则限制可选范围，是可观察的结构条件。 4" [disabled] [ref=f1e41]
              - generic [aria-hidden] [ref=f1e42]: ■
              - generic [ref=f1e43]:
                - text: 现行末班车时间压缩了夜班员工的通勤选择
                - generic [ref=f1e44]: ○ 漏选 · 规则限制可选范围，是可观察的结构条件。
              - generic [ref=f1e45]: "4"
            - generic [ref=f1e46]:
              - checkbox "员工只能接受现状，任何行动都没有意义 不符合 · 存在约束不能推出行动必定无效。 5" [disabled] [ref=f1e47]
              - generic [aria-hidden] [ref=f1e48]: ▲
              - generic [ref=f1e49]:
                - text: 员工只能接受现状，任何行动都没有意义
                - generic [ref=f1e50]: 不符合 · 存在约束不能推出行动必定无效。
              - generic [ref=f1e51]: "5"
        - status [ref=f1e53]:
          - text: 对照概念，再看一次
          - paragraph [ref=f1e54]: 运营规则塑造选择空间，员工组织体现能动性；行动又在预算、程序与需求中展开。提出建议不等于条件已经改变，也不能由约束推出行动无意义。
          - generic [ref=f1e55]: 已保留首次作答。
        - button "继续未答的第1题 →" [ref=f1e57] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { browserEvidence } from './evidence';
  3   | 
  4   | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`, evidence = browserEvidence('classroom-choice');
  5   | async function login(page: Page) {
  6   |   const suffix = crypto.randomUUID(), principal = 'classroom-choice-' + suffix + '@local.test', credential = 'Choice-QA-' + suffix;
  7   |   const response = await fetch(api + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
  8   |   expect(response.status).toBe(201);
  9   |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  10  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  11  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  12  | }
  13  | async function open(page: Page, lesson = 'soc-1-1-2') {
  14  |   await page.goto('/studio/classroom?lesson=' + lesson + '&tab=practice');
  15  |   await expect(page.getByRole('button', { name: 'Check →' })).toBeVisible();
  16  | }
  17  | async function multiple(page: Page) {
  18  |   await page.getByRole('button', { name: '第4题', exact: true }).click();
  19  |   await expect(page.getByText('选择所有符合项。本题须选全且不多选。', { exact: true })).toBeVisible();
  20  |   await expect(page.locator('.cl-practice-options input[type=checkbox]')).toHaveCount(5);
  21  | }
  22  | 
  23  | test('single and multiple choices retain drafts, lock original feedback and separate submitted option states', async ({ page }) => {
  24  |   await login(page); await open(page); const url = page.url();
  25  |   const single = page.locator('.cl-practice-options input[type=radio]'); await single.nth(1).check(); await single.nth(2).check(); await expect(single.nth(1)).not.toBeChecked();
  26  |   await multiple(page); const boxes = page.locator('.cl-practice-options input[type=checkbox]');
  27  |   await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled(); await boxes.nth(0).check(); await boxes.nth(2).check(); await boxes.nth(0).uncheck();
  28  |   await expect(page.locator('.cl-choice-selection')).toContainText('3'); await page.reload();
  29  |   await multiple(page); await expect(boxes.nth(2)).toBeChecked(); await expect(boxes.nth(0)).not.toBeChecked();
  30  |   await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(single.nth(2)).toBeChecked();
  31  |   await multiple(page); await page.getByRole('button', { name: 'Check →' }).click();
  32  |   await expect(page.locator('.cl-answer-feedback')).toBeVisible(); await expect(boxes.first()).toBeDisabled();
  33  |   await expect(page.locator('.cl-option-feedback')).toHaveCount(5); await expect(page.locator('.cl-option-feedback').filter({ hasText: /选对|误选/ })).toHaveCount(1);
  34  |   const original = await page.locator('.cl-answer-feedback').innerText(); await page.goto(url); await multiple(page);
  35  |   await expect(boxes.nth(2)).toBeChecked(); await expect(page.locator('.cl-answer-feedback')).toHaveText(original, { useInnerText: true });
  36  | });
  37  | 
  38  | test('lost acknowledgement is resolved by reading the saved first answer without creating another request', async ({ page }) => {
  39  |   await login(page); await open(page); await multiple(page);
  40  |   let sent: Record<string, unknown> | undefined;
  41  |   await page.route('**/api/learning/classroom/sessions/*/answers', async route => { sent = route.request().postDataJSON(); await route.fetch(); await route.abort('failed'); });
  42  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  43  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible();
  44  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); let extra = 0; page.on('request', request => { if (request.url().endsWith('/answers') && request.method() === 'POST') extra++; });
> 45  |   await page.getByRole('button', { name: '读取并恢复原提交' }).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
      |                                                        ^ Error: locator.click: Test ended.
  46  |   expect(extra).toBe(0); expect(sent?.protocol).toBe('classroom-choice-v2'); await page.reload(); await multiple(page); await expect(page.locator('.cl-practice-options input').first()).toBeDisabled();
  47  | });
  48  | 
  49  | test('an undelivered command survives refresh and reuses its exact request key and choices', async ({ page }) => {
  50  |   await login(page); await open(page); await multiple(page); const commands: unknown[] = [];
  51  |   await page.route('**/api/learning/classroom/sessions/*/answers', async route => { commands.push(route.request().postDataJSON()); await route.abort('failed'); });
  52  |   const boxes = page.locator('.cl-practice-options input'); await boxes.nth(0).check(); await boxes.nth(3).check(); await page.getByRole('button', { name: 'Check →' }).click();
  53  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible(); await page.reload();
  54  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible(); await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled();
  55  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); await page.route('**/api/learning/classroom/sessions/*/answers', async route => { commands.push(route.request().postDataJSON()); await route.continue(); });
  56  |   await page.getByRole('button', { name: '读取并恢复原提交' }).click(); await multiple(page); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  57  |   expect(commands).toHaveLength(2); expect(commands[1]).toEqual(commands[0]); await expect(boxes.nth(0)).toBeChecked(); await expect(boxes.nth(3)).toBeChecked();
  58  | });
  59  | 
  60  | test('skip, unknown and actual hints remain separate immutable first-answer facts', async ({ page }) => {
  61  |   await login(page); await open(page);
  62  |   await page.getByRole('button', { name: 'Skip', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已跳过');
  63  |   await page.getByRole('button', { name: '第2题', exact: true }).click(); await page.getByRole('button', { name: '这题我不会' }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已记录不会');
  64  |   await multiple(page); await page.getByRole('button', { name: '先给我一个提示' }).click(); await expect(page.locator('.cl-hint')).toHaveCount(1);
  65  |   await expect(page.locator('.cl-option-feedback')).toHaveCount(0); await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  66  |   await expect(page.locator('.cl-answer-feedback')).toContainText('记为辅助作答'); await expect(page.locator('.cl-option-feedback')).toHaveCount(5);
  67  | });
  68  | 
  69  | test('keyboard selection stays in the question area and leaves assistant input isolated', async ({ page }) => {
  70  |   await login(page); await open(page); await multiple(page);
  71  |   const area = page.getByLabel('题目作答区域，数字键选择，回车提交'); await area.focus(); await page.keyboard.press('1'); await page.keyboard.press('3');
  72  |   const boxes = page.locator('.cl-practice-options input'); await expect(boxes.nth(0)).toBeChecked(); await expect(boxes.nth(2)).toBeChecked();
  73  |   await page.getByRole('button', { name: '☏ Assistant' }).click();
  74  |   // Actual assistant field is selected by its accessible textbox role, avoiding document shortcuts.
  75  |   const textbox = page.locator('.cl-chat-panel textarea'); await expect(textbox).toBeVisible(); await textbox.fill('1'); await textbox.press('3');
  76  |   await expect(boxes.nth(2)).toBeChecked(); await expect(page.locator('.cl-answer-feedback')).toHaveCount(0);
  77  |   await area.focus(); await page.keyboard.press('Enter'); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  78  | });
  79  | 
  80  | test('enlarged practice artwork restores focus and preserves the selection without submitting from its dialog', async ({ page }) => {
  81  |   await login(page); await open(page, 'soc-1-1-1'); const radio = page.locator('.cl-practice-options input').first(); await radio.check();
  82  |   const trigger = page.getByRole('button', { name: '放大图片：传记与历史', exact: true }); await trigger.click();
  83  |   await expect(page.getByRole('dialog', { name: '传记与历史' })).toBeVisible(); await page.keyboard.press('2'); await page.keyboard.press('Enter');
  84  |   await expect(page.locator('.cl-answer-feedback')).toHaveCount(0); await page.keyboard.press('Escape'); await expect(trigger).toBeFocused(); await expect(radio).toBeChecked();
  85  | });
  86  | 
  87  | test('unavailable local storage keeps current choices and a downloadable command copy', async ({ page }) => {
  88  |   await login(page); await page.addInitScript(() => { const set = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) { if (key.startsWith('studyagent.classroom.choices.v1.')) throw new DOMException('QA storage denied', 'QuotaExceededError'); return set.call(this, key, value); }; });
  89  |   await open(page); await multiple(page); await page.locator('.cl-practice-options input').nth(1).check(); await page.locator('.cl-practice-options input').nth(4).check();
  90  |   await expect(page.getByText(/本机暂存不可用/)).toBeVisible(); const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载选择与原提交副本' }).click();
  91  |   expect((await download).suggestedFilename()).toBe('课堂选择与原提交副本.json'); await expect(page.locator('.cl-practice-options input').nth(4)).toBeChecked();
  92  |   await page.getByRole('button', { name: 'Check →' }).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  93  | });
  94  | 
  95  | for (const width of [390, 768, 1440]) test('multiple-choice layout and assistant fit at ' + width, async ({ page }) => {
  96  |   await page.setViewportSize({ width, height: 1000 }); await login(page); await open(page); await multiple(page);
  97  |   await page.locator('.cl-practice-options input').first().check();
  98  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  99  |   const labels = page.locator('.cl-practice-options label'), first = await labels.nth(0).boundingBox(), second = await labels.nth(1).boundingBox(), last = await labels.nth(4).boundingBox();
  100 |   expect(first).not.toBeNull(); expect(second).not.toBeNull(); expect(last).not.toBeNull();
  101 |   if (width === 1440) { expect(Math.abs(first!.y - second!.y)).toBeLessThan(2); expect(last!.width).toBeGreaterThan(first!.width * 1.8); }
  102 |   if (width === 390) expect(second!.y).toBeGreaterThan(first!.y + first!.height - 1);
  103 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/multiple-' + width + '.png', fullPage: true });
  104 |   await page.getByRole('button', { name: '☏ Assistant' }).click(); expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  105 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/assistant-' + width + '.png', fullPage: true });
  106 | });
  107 | 
```