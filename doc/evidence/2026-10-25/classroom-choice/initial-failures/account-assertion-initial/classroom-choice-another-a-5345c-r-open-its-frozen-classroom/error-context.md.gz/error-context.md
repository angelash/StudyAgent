# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-choice.spec.ts >> another account cannot restore prior selections or open its frozen classroom
- Location: tests\e2e\classroom-choice.spec.ts:70:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('无法访问其他账号的课堂', { exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('无法访问其他账号的课堂', { exact: true }) with timeout 15000ms
  - waiting for getByText('无法访问其他账号的课堂', { exact: true })

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - link "Home":
        - /url: /studio?view=home
        - text: 首页
      - link "Courses":
        - /url: /studio?view=courses
        - text: 课程
      - link "Calendar":
        - /url: /studio?view=calendar
        - text: 学习动态
      - link "History":
        - /url: /studio?view=history
        - text: 历史
      - link "Materials":
        - /url: /studio?view=materials
        - text: 资料
    - heading "继续学习" [level=2]
    - link "讲座结构与能动性 社会学概论":
      - /url: /studio/classroom?lesson=soc-1-1-2&session=classroom_b2c4f5d3-76ce-446b-b8e8-19583d8bd4a9
    - heading "近期活动" [level=2]
    - link "返回学习首页 →":
      - /url: /learn?subject=math
  - complementary:
    - link "× 退出课程":
      - /url: /studio?view=courses
    - img "由阶梯与拱门构成的课程封面"
    - text: S 策划自 StudyAgent Learning Studio
    - heading "社会学概论" [level=1]
    - paragraph: 从自己的生活出发，看见文化、关系和制度如何共同塑造社会。五个单元串起概念、案例、练习与一个持续推进的社区研究。
    - group: 显示更多
    - text: 面板
    - tablist "课程面板":
      - tab "单元" [selected]
      - tab "资料"
      - tab "练习"
    - button "1 社会学视角"
    - button "2 文化与自我"
    - button "3 不平等"
    - button "4 制度"
    - button "5 越轨与社会变迁"
  - alert:
    - text: 无法访问其他账号的课堂
    - button "重试"
  - text: 第 1 单元，共 5 单元
  - heading "单元 1：社会学视角" [level=2]
  - paragraph: 把个人经验放回社会背景，比较理论解释并设计可检验的研究。
  - link "▤ 把自己的资料带进课堂 PDF、页级阅读、个性化学案与白板 ↗":
    - /url: /studio?view=materials
  - text: ✓ 讲解已读 已接触 未开始 ▣ Project ♙ Exam
  - button "未开始"
  - button "已接触"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - button "未开始"
  - link "▣":
    - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
  - button "♙"
  - button "▶ 下一步：结构与能动性 ›"
  - article:
    - text: ▧
    - button "讲次 1：社会学思考" [expanded]
    - button "获取帮助"
    - paragraph: 围绕社会学思考，通过四段微课完成概念辨析与情境应用。
    - text: 社会学想象力
    - button "查看学习目标：社会学想象力": ⊙
    - button "▶ 学习"
    - button "♧ 练习"
    - text: 结构与能动性
    - button "查看学习目标：结构与能动性": ⊙
    - button "▶ 继续学习"
    - button "♧ 练习"
    - text: 社会事实
    - button "查看学习目标：社会事实": ⊙
    - button "▶ 学习"
    - button "♧ 练习"
    - text: 社会学与日常生活
    - button "查看学习目标：社会学与日常生活": ⊙
    - button "▶ 学习"
    - button "♧ 练习"
  - article:
    - text: ▧
    - button "讲次 2：理论传统"
    - button "获取帮助"
    - paragraph: 围绕理论传统，通过四段微课完成概念辨析与情境应用。
  - article:
    - text: ▧
    - button "讲次 3：研究方法"
    - button "获取帮助"
    - paragraph: 围绕研究方法，通过四段微课完成概念辨析与情境应用。
  - article:
    - text: ▣ PROJECT · 1 / 5
    - heading "研究问题与方法设计" [level=3]
    - paragraph: 选择一个社区现象，写出研究问题、调查对象、方法与保护参与者的办法。
    - link "开始项目 →":
      - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
  - article:
    - text: ♙ UNIT CHECK
    - heading "社会学视角综合核查" [level=3]
    - paragraph: 覆盖本单元的 12 个主题，12 道新情境题保留首次作答、跳过与提示记录。
    - button "Start →"
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { browserEvidence } from './evidence';
  3   | 
  4   | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`, evidence = browserEvidence('classroom-choice');
  5   | let address = 0;
  6   | async function login(page: Page) {
  7   |   const suffix = crypto.randomUUID(), principal = 'classroom-choice-' + suffix + '@local.test', credential = 'Choice-QA-' + suffix;
  8   |   const response = await fetch(api + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': '198.18.9.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  9   |   expect(response.status).toBe(201);
  10  |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  11  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  13  | }
  14  | async function open(page: Page, lesson = 'soc-1-1-2') {
  15  |   await page.goto('/studio/classroom?lesson=' + lesson + '&tab=practice');
  16  |   await expect(page.getByRole('button', { name: 'Check →' })).toBeVisible();
  17  | }
  18  | async function multiple(page: Page) {
  19  |   await page.getByRole('button', { name: '第4题', exact: true }).click();
  20  |   await expect(page.getByText('选择所有符合项。本题须选全且不多选。', { exact: true })).toBeVisible();
  21  |   await expect(page.locator('.cl-practice-options input[type=checkbox]')).toHaveCount(5);
  22  | }
  23  | 
  24  | test('single and multiple choices retain drafts, lock original feedback and separate submitted option states', async ({ page }) => {
  25  |   await login(page); await open(page); const url = page.url();
  26  |   const single = page.locator('.cl-practice-options input[type=radio]'); await single.nth(1).check(); await single.nth(2).check(); await expect(single.nth(1)).not.toBeChecked();
  27  |   await multiple(page); const boxes = page.locator('.cl-practice-options input[type=checkbox]');
  28  |   await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled(); await boxes.nth(0).check(); await boxes.nth(2).check(); await boxes.nth(0).uncheck();
  29  |   await expect(page.locator('.cl-choice-selection')).toContainText('3'); await page.reload();
  30  |   await multiple(page); await expect(boxes.nth(2)).toBeChecked(); await expect(boxes.nth(0)).not.toBeChecked();
  31  |   await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(single.nth(2)).toBeChecked();
  32  |   await multiple(page); await page.getByRole('button', { name: 'Check →' }).click();
  33  |   await expect(page.locator('.cl-answer-feedback')).toBeVisible(); await expect(boxes.first()).toBeDisabled();
  34  |   await expect(page.locator('.cl-option-feedback')).toHaveCount(5); await expect(page.locator('.cl-option-feedback').filter({ hasText: /选对|误选/ })).toHaveCount(1);
  35  |   const original = await page.locator('.cl-answer-feedback').innerText(); await page.goto(url); await multiple(page);
  36  |   await expect(boxes.nth(2)).toBeChecked(); await expect(page.locator('.cl-answer-feedback')).toHaveText(original, { useInnerText: true });
  37  | });
  38  | 
  39  | test('lost acknowledgement is resolved by reading the saved first answer without creating another request', async ({ page }) => {
  40  |   await login(page); await open(page); await multiple(page);
  41  |   let sent: Record<string, unknown> | undefined;
  42  |   await page.route('**/api/learning/classroom/sessions/*/answers', async route => { sent = route.request().postDataJSON(); await route.fetch(); await route.abort('failed'); });
  43  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  44  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeEnabled();
  45  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); let extra = 0; page.on('request', request => { if (request.url().endsWith('/answers') && request.method() === 'POST') extra++; });
  46  |   await page.getByRole('button', { name: '读取并恢复原提交' }).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  47  |   expect(extra).toBe(0); expect(sent?.protocol).toBe('classroom-choice-v2'); await page.reload(); await multiple(page); await expect(page.locator('.cl-practice-options input').first()).toBeDisabled();
  48  | });
  49  | 
  50  | test('an undelivered command survives refresh and reuses its exact request key and choices', async ({ page }) => {
  51  |   await login(page); await open(page); await multiple(page); const commands: unknown[] = [];
  52  |   await page.route('**/api/learning/classroom/sessions/*/answers', async route => { commands.push(route.request().postDataJSON()); await route.abort('failed'); });
  53  |   const boxes = page.locator('.cl-practice-options input'); await boxes.nth(0).check(); await boxes.nth(3).check(); await page.getByRole('button', { name: 'Check →' }).click();
  54  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible(); await page.reload();
  55  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible(); await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled();
  56  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); await page.route('**/api/learning/classroom/sessions/*/answers', async route => { commands.push(route.request().postDataJSON()); await route.continue(); });
  57  |   await page.getByRole('button', { name: '读取并恢复原提交' }).click(); await multiple(page); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  58  |   expect(commands).toHaveLength(2); expect(commands[1]).toEqual(commands[0]); await expect(boxes.nth(0)).toBeChecked(); await expect(boxes.nth(3)).toBeChecked();
  59  | });
  60  | 
  61  | test('a definitive rejected submission retains its command copy and permits a new checked selection', async ({ page }) => {
  62  |   await login(page); await open(page); await multiple(page);
  63  |   await page.route('**/api/learning/classroom/sessions/*/answers', route => route.fulfill({status:400,contentType:'application/json',json:{data:null,error:{code:'bad_request',message:'合成明确拒绝'}}}));
  64  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button',{name:'Check →'}).click();
  65  |   await expect(page.getByText(/服务器已明确拒绝原提交/)).toBeVisible(); await expect(page.getByRole('button',{name:'读取并恢复原提交'})).toHaveCount(0);
  66  |   await expect(page.getByRole('button',{name:'下载选择与原提交副本'})).toBeVisible(); await expect(page.locator('.cl-practice-options input').first()).toBeEnabled();
  67  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); await page.locator('.cl-practice-options input').nth(2).check(); await page.getByRole('button',{name:'Check →'}).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  68  | });
  69  | 
  70  | test('another account cannot restore prior selections or open its frozen classroom', async ({ page }) => {
  71  |   await login(page); await open(page); const originalUrl=page.url(); await multiple(page); await page.locator('.cl-practice-options input').first().check();
  72  |   await login(page); await open(page); await multiple(page); await expect(page.locator('.cl-practice-options input:checked')).toHaveCount(0);
> 73  |   await page.goto(originalUrl); await expect(page.getByText('无法访问其他账号的课堂',{exact:true})).toBeVisible(); await expect(page.locator('.cl-practice-options')).toHaveCount(0);
      |                                                                                          ^ Error: expect(locator).toBeVisible() failed
  74  | });
  75  | 
  76  | test('unit checks expose the new selection mode and retain first feedback after reopening', async ({ page }) => {
  77  |   await login(page); await open(page,'unit-exam:soc-u1'); await expect(page.locator('.cl-practice-options input[type=checkbox]')).toHaveCount(5);
  78  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button',{name:'Check →'}).click(); await expect(page.locator('.cl-option-feedback')).toHaveCount(5);
  79  |   const feedback=await page.locator('.cl-answer-feedback').innerText();await page.reload(); await page.getByRole('button',{name:'第1题',exact:true}).click();await expect(page.locator('.cl-answer-feedback')).toHaveText(feedback,{useInnerText:true});
  80  | });
  81  | 
  82  | test('skip, unknown and actual hints remain separate immutable first-answer facts', async ({ page }) => {
  83  |   await login(page); await open(page);
  84  |   await page.getByRole('button', { name: 'Skip', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已跳过');
  85  |   await page.getByRole('button', { name: '第2题', exact: true }).click(); await page.getByRole('button', { name: '这题我不会' }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已记录不会');
  86  |   await multiple(page); await page.getByRole('button', { name: '先给我一个提示' }).click(); await expect(page.locator('.cl-hint')).toHaveCount(1);
  87  |   await expect(page.locator('.cl-option-feedback')).toHaveCount(0); await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  88  |   await expect(page.locator('.cl-answer-feedback')).toContainText('记为辅助作答'); await expect(page.locator('.cl-option-feedback')).toHaveCount(5);
  89  | });
  90  | 
  91  | test('a complete correct set, assisted wrong answer, skip and unknown produce a usable first-answer review', async ({ page }) => {
  92  |   await login(page); await open(page); await multiple(page);
  93  |   for (const text of ['现行末班车时间压缩','员工协商、组织','方案效果还受到']) await page.locator('.cl-practice-options label').filter({hasText:text}).locator('input').check();
  94  |   await page.getByRole('button', {name:'Check →'}).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');
  95  |   await expect(page.locator('.cl-option-feedback').filter({hasText:'✓ 选对'})).toHaveCount(3); await expect(page.locator('.cl-option-feedback').filter({hasText:'漏选'})).toHaveCount(0);
  96  |   await page.getByRole('button', {name:'第1题',exact:true}).click(); await page.getByRole('button', {name:'Skip',exact:true}).click();
  97  |   await page.getByRole('button', {name:'第2题',exact:true}).click(); await page.getByRole('button', {name:'这题我不会'}).click();
  98  |   await page.getByRole('button', {name:'第3题',exact:true}).click(); await page.getByRole('button', {name:'先给我一个提示'}).click();
  99  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', {name:'Check →'}).click();
  100 |   await expect(page.getByRole('region', {name:'课堂练习复盘'})).toBeVisible(); await expect(page.locator('.cl-review-counts')).toContainText('独立答对');
  101 |   await expect(page.locator('.cl-review-items')).toContainText('跳过'); await expect(page.locator('.cl-review-items')).toContainText('不会');
  102 |   await page.getByRole('button', {name:'回看全部题目'}).click(); await multiple(page); await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');
  103 | });
  104 | 
  105 | test('keyboard selection stays in the question area and leaves assistant input isolated', async ({ page }) => {
  106 |   await login(page); await open(page); await multiple(page);
  107 |   const area = page.getByLabel('题目作答区域，数字键选择，回车提交'); await area.focus(); await page.keyboard.press('1'); await page.keyboard.press('3');
  108 |   const boxes = page.locator('.cl-practice-options input'); await expect(boxes.nth(0)).toBeChecked(); await expect(boxes.nth(2)).toBeChecked();
  109 |   await page.getByRole('button', { name: '☏ Assistant' }).click();
  110 |   // Actual assistant field is selected by its accessible textbox role, avoiding document shortcuts.
  111 |   const textbox = page.locator('.cl-chat-panel textarea'); await expect(textbox).toBeVisible(); await textbox.fill('1'); await textbox.press('3');
  112 |   await expect(boxes.nth(2)).toBeChecked(); await expect(page.locator('.cl-answer-feedback')).toHaveCount(0);
  113 |   await area.focus(); await page.keyboard.press('Enter'); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  114 | });
  115 | 
  116 | test('enlarged practice artwork restores focus and preserves the selection without submitting from its dialog', async ({ page }) => {
  117 |   await login(page); await open(page, 'soc-1-1-1'); const radio = page.locator('.cl-practice-options input').first(); await radio.check();
  118 |   const trigger = page.getByRole('button', { name: '放大图片：传记与历史', exact: true }); await trigger.click();
  119 |   await expect(page.getByRole('dialog', { name: '传记与历史' })).toBeVisible(); await page.keyboard.press('2'); await page.keyboard.press('Enter');
  120 |   await expect(page.locator('.cl-answer-feedback')).toHaveCount(0); await page.keyboard.press('Escape'); await expect(trigger).toBeFocused(); await expect(radio).toBeChecked();
  121 | });
  122 | 
  123 | test('unavailable local storage keeps current choices and a downloadable command copy', async ({ page }) => {
  124 |   await login(page); await page.addInitScript(() => { const set = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) { if (key.startsWith('studyagent.classroom.choices.v1.')) throw new DOMException('QA storage denied', 'QuotaExceededError'); return set.call(this, key, value); }; });
  125 |   await open(page); await multiple(page); await page.locator('.cl-practice-options input').nth(1).check(); await page.locator('.cl-practice-options input').nth(4).check();
  126 |   await expect(page.getByText(/本机暂存不可用/)).toBeVisible(); const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载选择与原提交副本' }).click();
  127 |   expect((await download).suggestedFilename()).toBe('课堂选择与原提交副本.json'); await expect(page.locator('.cl-practice-options input').nth(4)).toBeChecked();
  128 |   await page.getByRole('button', { name: 'Check →' }).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  129 | });
  130 | 
  131 | for (const width of [390, 768, 1440]) test('multiple-choice layout and assistant fit at ' + width, async ({ page }) => {
  132 |   await page.setViewportSize({ width, height: 1000 }); await login(page); await open(page); await multiple(page);
  133 |   await page.locator('.cl-practice-options input').first().check();
  134 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  135 |   const labels = page.locator('.cl-practice-options label'), first = await labels.nth(0).boundingBox(), second = await labels.nth(1).boundingBox(), last = await labels.nth(4).boundingBox();
  136 |   expect(first).not.toBeNull(); expect(second).not.toBeNull(); expect(last).not.toBeNull();
  137 |   if (width === 1440) { expect(Math.abs(first!.y - second!.y)).toBeLessThan(2); expect(last!.width).toBeGreaterThan(first!.width * 1.8); }
  138 |   if (width === 390) expect(second!.y).toBeGreaterThan(first!.y + first!.height - 1);
  139 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/multiple-' + width + '.png', fullPage: true });
  140 |   await page.getByRole('button', { name: '☏ Assistant' }).click(); expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  141 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/assistant-' + width + '.png', fullPage: true });
  142 | });
  143 | 
```