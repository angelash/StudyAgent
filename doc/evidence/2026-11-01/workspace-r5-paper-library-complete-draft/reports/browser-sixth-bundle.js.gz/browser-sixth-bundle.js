(() => {
  var __defProp = Object.defineProperty;
  var __export = (target3, all) => {
    for (var name in all)
      __defProp(target3, name, { get: all[name], enumerable: true });
  };

  // apps/web/lib/paper-library-copy.ts
  var paper_library_copy_exports = {};
  __export(paper_library_copy_exports, {
    assertPaperLibraryJournal: () => assertPaperLibraryJournal,
    completePaperLibraryCopy: () => completePaperLibraryCopy,
    downloadPaperLibraryCopy: () => downloadPaperLibraryCopy,
    emptyPaperLibraryDraft: () => emptyPaperLibraryDraft,
    paperLibraryCopyByteLimit: () => paperLibraryCopyByteLimit,
    paperLibraryJournalEntry: () => paperLibraryJournalEntry,
    paperLibraryRequestFingerprint: () => paperLibraryRequestFingerprint,
    paperLibraryValueHash: () => paperLibraryValueHash,
    readPaperLibraryCopy: () => readPaperLibraryCopy
  });

  // ../../../node_modules/zod/v4/classic/external.js
  var external_exports = {};
  __export(external_exports, {
    $brand: () => $brand,
    $input: () => $input,
    $output: () => $output,
    INVALID: () => INVALID,
    NEVER: () => NEVER,
    TimePrecision: () => TimePrecision,
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBase64: () => ZodBase64,
    ZodBase64URL: () => ZodBase64URL,
    ZodBigInt: () => ZodBigInt,
    ZodBigIntFormat: () => ZodBigIntFormat,
    ZodBoolean: () => ZodBoolean,
    ZodCIDRv4: () => ZodCIDRv4,
    ZodCIDRv6: () => ZodCIDRv6,
    ZodCUID: () => ZodCUID,
    ZodCUID2: () => ZodCUID2,
    ZodCatch: () => ZodCatch,
    ZodCodec: () => ZodCodec,
    ZodCompileAsyncError: () => ZodCompileAsyncError,
    ZodCompileUnsupportedError: () => ZodCompileUnsupportedError,
    ZodCreditCard: () => ZodCreditCard,
    ZodCustom: () => ZodCustom,
    ZodCustomStringFormat: () => ZodCustomStringFormat,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodE164: () => ZodE164,
    ZodEmail: () => ZodEmail,
    ZodEmoji: () => ZodEmoji,
    ZodEnum: () => ZodEnum,
    ZodError: () => ZodError,
    ZodExactOptional: () => ZodExactOptional,
    ZodFile: () => ZodFile,
    ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
    ZodFunction: () => ZodFunction,
    ZodGUID: () => ZodGUID,
    ZodIBAN: () => ZodIBAN,
    ZodIPv4: () => ZodIPv4,
    ZodIPv6: () => ZodIPv6,
    ZodISODate: () => ZodISODate,
    ZodISODateTime: () => ZodISODateTime,
    ZodISODuration: () => ZodISODuration,
    ZodISOTime: () => ZodISOTime,
    ZodInstanceOf: () => ZodInstanceOf,
    ZodIntersection: () => ZodIntersection,
    ZodIssueCode: () => ZodIssueCode,
    ZodJWT: () => ZodJWT,
    ZodKSUID: () => ZodKSUID,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMAC: () => ZodMAC,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNanoID: () => ZodNanoID,
    ZodNever: () => ZodNever,
    ZodNonOptional: () => ZodNonOptional,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodNumberFormat: () => ZodNumberFormat,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodPipe: () => ZodPipe,
    ZodPrefault: () => ZodPrefault,
    ZodPreprocess: () => ZodPreprocess,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRealError: () => ZodRealError,
    ZodRecord: () => ZodRecord,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodStringFormat: () => ZodStringFormat,
    ZodSuccess: () => ZodSuccess,
    ZodSymbol: () => ZodSymbol,
    ZodTemplateLiteral: () => ZodTemplateLiteral,
    ZodTransform: () => ZodTransform,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodULID: () => ZodULID,
    ZodURL: () => ZodURL,
    ZodUUID: () => ZodUUID,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    ZodXID: () => ZodXID,
    ZodXor: () => ZodXor,
    _ZodString: () => _ZodString,
    _default: () => _default2,
    _function: () => _function,
    any: () => any,
    array: () => array,
    base64: () => base642,
    base64url: () => base64url2,
    bigint: () => bigint2,
    boolean: () => boolean2,
    catch: () => _catch2,
    check: () => check,
    cidrv4: () => cidrv42,
    cidrv6: () => cidrv62,
    clone: () => clone,
    codec: () => codec,
    coerce: () => coerce_exports,
    compile: () => compile,
    config: () => config,
    core: () => core_exports2,
    creditCard: () => creditCard2,
    cuid: () => cuid3,
    cuid2: () => cuid22,
    currencyCode: () => currencyCode2,
    custom: () => custom,
    date: () => date2,
    decode: () => decode2,
    decodeAsync: () => decodeAsync2,
    deepPartial: () => deepPartial,
    describe: () => describe2,
    discriminatedUnion: () => discriminatedUnion,
    e164: () => e1642,
    email: () => email2,
    emoji: () => emoji2,
    encode: () => encode2,
    encodeAsync: () => encodeAsync2,
    endsWith: () => _endsWith,
    enum: () => _enum2,
    exactOptional: () => exactOptional,
    file: () => file,
    flattenError: () => flattenError,
    float32: () => float32,
    float64: () => float64,
    formatError: () => formatError,
    fromJSONSchema: () => fromJSONSchema,
    function: () => _function,
    getDiscriminatedOption: () => getDiscriminatedOption,
    getErrorMap: () => getErrorMap,
    globalRegistry: () => globalRegistry,
    gt: () => _gt,
    gte: () => _gte,
    guid: () => guid2,
    hash: () => hash,
    hex: () => hex2,
    hostname: () => hostname2,
    httpUrl: () => httpUrl,
    iban: () => iban2,
    includes: () => _includes,
    input: () => input,
    instanceof: () => _instanceof,
    int: () => int,
    int32: () => int32,
    int64: () => int64,
    intersection: () => intersection,
    invertCodec: () => invertCodec,
    ipv4: () => ipv42,
    ipv6: () => ipv62,
    iso: () => iso_exports,
    json: () => json,
    jwt: () => jwt,
    keyof: () => keyof,
    ksuid: () => ksuid2,
    lazy: () => lazy,
    length: () => _length,
    literal: () => literal,
    locales: () => locales_exports,
    looseObject: () => looseObject,
    looseRecord: () => looseRecord,
    lowercase: () => _lowercase,
    lt: () => _lt,
    lte: () => _lte,
    mac: () => mac2,
    map: () => map,
    maxLength: () => _maxLength,
    maxSize: () => _maxSize,
    memoizer: () => memoizer,
    meta: () => meta2,
    mime: () => _mime,
    minLength: () => _minLength,
    minSize: () => _minSize,
    multipleOf: () => _multipleOf,
    nan: () => nan,
    nanoid: () => nanoid2,
    nativeEnum: () => nativeEnum,
    negative: () => _negative,
    never: () => never,
    nonnegative: () => _nonnegative,
    nonoptional: () => nonoptional,
    nonpositive: () => _nonpositive,
    normalize: () => _normalize,
    null: () => _null3,
    nullable: () => nullable,
    nullish: () => nullish2,
    number: () => number2,
    object: () => object,
    optional: () => optional,
    output: () => output,
    overwrite: () => _overwrite,
    parse: () => parse2,
    parseAsync: () => parseAsync2,
    partialRecord: () => partialRecord,
    pipe: () => pipe,
    positive: () => _positive,
    prefault: () => prefault,
    preprocess: () => preprocess,
    prettifyError: () => prettifyError,
    promise: () => promise,
    properties: () => _properties,
    property: () => _property,
    readonly: () => readonly,
    record: () => record,
    refine: () => refine,
    regex: () => _regex,
    regexes: () => regexes_exports,
    registry: () => registry,
    safeDecode: () => safeDecode2,
    safeDecodeAsync: () => safeDecodeAsync2,
    safeEncode: () => safeEncode2,
    safeEncodeAsync: () => safeEncodeAsync2,
    safeParse: () => safeParse2,
    safeParseAsync: () => safeParseAsync2,
    set: () => set,
    setErrorMap: () => setErrorMap,
    size: () => _size,
    slugify: () => _slugify,
    startsWith: () => _startsWith,
    strictObject: () => strictObject,
    string: () => string2,
    stringFormat: () => stringFormat,
    stringbool: () => stringbool,
    success: () => success,
    superRefine: () => superRefine,
    symbol: () => symbol,
    templateLiteral: () => templateLiteral,
    toJSONSchema: () => toJSONSchema,
    toLowerCase: () => _toLowerCase,
    toUpperCase: () => _toUpperCase,
    toZod: () => toZod,
    transform: () => transform,
    treeifyError: () => treeifyError,
    trim: () => _trim,
    tuple: () => tuple,
    uint32: () => uint32,
    uint64: () => uint64,
    ulid: () => ulid2,
    undefined: () => _undefined3,
    union: () => union,
    unknown: () => unknown,
    uppercase: () => _uppercase,
    url: () => url,
    util: () => util_exports,
    uuid: () => uuid2,
    uuidv4: () => uuidv4,
    uuidv6: () => uuidv6,
    uuidv7: () => uuidv7,
    validate: () => validate,
    validateAsync: () => validateAsync,
    void: () => _void2,
    withParser: () => withParser,
    xid: () => xid2,
    xor: () => xor
  });

  // ../../../node_modules/zod/v4/core/index.js
  var core_exports2 = {};
  __export(core_exports2, {
    $ZodAny: () => $ZodAny,
    $ZodArray: () => $ZodArray,
    $ZodAsyncError: () => $ZodAsyncError,
    $ZodBase64: () => $ZodBase64,
    $ZodBase64URL: () => $ZodBase64URL,
    $ZodBigInt: () => $ZodBigInt,
    $ZodBigIntFormat: () => $ZodBigIntFormat,
    $ZodBoolean: () => $ZodBoolean,
    $ZodCIDRv4: () => $ZodCIDRv4,
    $ZodCIDRv6: () => $ZodCIDRv6,
    $ZodCUID: () => $ZodCUID,
    $ZodCUID2: () => $ZodCUID2,
    $ZodCatch: () => $ZodCatch,
    $ZodCheck: () => $ZodCheck,
    $ZodCheckBigIntFormat: () => $ZodCheckBigIntFormat,
    $ZodCheckEndsWith: () => $ZodCheckEndsWith,
    $ZodCheckGreaterThan: () => $ZodCheckGreaterThan,
    $ZodCheckIncludes: () => $ZodCheckIncludes,
    $ZodCheckLengthEquals: () => $ZodCheckLengthEquals,
    $ZodCheckLessThan: () => $ZodCheckLessThan,
    $ZodCheckLowerCase: () => $ZodCheckLowerCase,
    $ZodCheckMaxLength: () => $ZodCheckMaxLength,
    $ZodCheckMaxSize: () => $ZodCheckMaxSize,
    $ZodCheckMimeType: () => $ZodCheckMimeType,
    $ZodCheckMinLength: () => $ZodCheckMinLength,
    $ZodCheckMinSize: () => $ZodCheckMinSize,
    $ZodCheckMultipleOf: () => $ZodCheckMultipleOf,
    $ZodCheckNumberFormat: () => $ZodCheckNumberFormat,
    $ZodCheckOverwrite: () => $ZodCheckOverwrite,
    $ZodCheckProperties: () => $ZodCheckProperties,
    $ZodCheckProperty: () => $ZodCheckProperty,
    $ZodCheckRegex: () => $ZodCheckRegex,
    $ZodCheckSizeEquals: () => $ZodCheckSizeEquals,
    $ZodCheckStartsWith: () => $ZodCheckStartsWith,
    $ZodCheckStringFormat: () => $ZodCheckStringFormat,
    $ZodCheckUpperCase: () => $ZodCheckUpperCase,
    $ZodCodec: () => $ZodCodec,
    $ZodCreditCard: () => $ZodCreditCard,
    $ZodCustom: () => $ZodCustom,
    $ZodCustomStringFormat: () => $ZodCustomStringFormat,
    $ZodCyclicError: () => $ZodCyclicError,
    $ZodDate: () => $ZodDate,
    $ZodDefault: () => $ZodDefault,
    $ZodDiscriminatedUnion: () => $ZodDiscriminatedUnion,
    $ZodE164: () => $ZodE164,
    $ZodEmail: () => $ZodEmail,
    $ZodEmoji: () => $ZodEmoji,
    $ZodEncodeError: () => $ZodEncodeError,
    $ZodEnum: () => $ZodEnum,
    $ZodError: () => $ZodError,
    $ZodExactOptional: () => $ZodExactOptional,
    $ZodFile: () => $ZodFile,
    $ZodFunction: () => $ZodFunction,
    $ZodGUID: () => $ZodGUID,
    $ZodIBAN: () => $ZodIBAN,
    $ZodIPv4: () => $ZodIPv4,
    $ZodIPv6: () => $ZodIPv6,
    $ZodISODate: () => $ZodISODate,
    $ZodISODateTime: () => $ZodISODateTime,
    $ZodISODuration: () => $ZodISODuration,
    $ZodISOTime: () => $ZodISOTime,
    $ZodIntersection: () => $ZodIntersection,
    $ZodJWT: () => $ZodJWT,
    $ZodKSUID: () => $ZodKSUID,
    $ZodLazy: () => $ZodLazy,
    $ZodLiteral: () => $ZodLiteral,
    $ZodMAC: () => $ZodMAC,
    $ZodMap: () => $ZodMap,
    $ZodNaN: () => $ZodNaN,
    $ZodNanoID: () => $ZodNanoID,
    $ZodNever: () => $ZodNever,
    $ZodNonOptional: () => $ZodNonOptional,
    $ZodNull: () => $ZodNull,
    $ZodNullable: () => $ZodNullable,
    $ZodNumber: () => $ZodNumber,
    $ZodNumberFormat: () => $ZodNumberFormat,
    $ZodObject: () => $ZodObject,
    $ZodObjectJIT: () => $ZodObjectJIT,
    $ZodOptional: () => $ZodOptional,
    $ZodPipe: () => $ZodPipe,
    $ZodPrefault: () => $ZodPrefault,
    $ZodPreprocess: () => $ZodPreprocess,
    $ZodPromise: () => $ZodPromise,
    $ZodReadonly: () => $ZodReadonly,
    $ZodRealError: () => $ZodRealError,
    $ZodRecord: () => $ZodRecord,
    $ZodRegistry: () => $ZodRegistry,
    $ZodSet: () => $ZodSet,
    $ZodString: () => $ZodString,
    $ZodStringFormat: () => $ZodStringFormat,
    $ZodSuccess: () => $ZodSuccess,
    $ZodSymbol: () => $ZodSymbol,
    $ZodTemplateLiteral: () => $ZodTemplateLiteral,
    $ZodTransform: () => $ZodTransform,
    $ZodTuple: () => $ZodTuple,
    $ZodType: () => $ZodType,
    $ZodULID: () => $ZodULID,
    $ZodURL: () => $ZodURL,
    $ZodUUID: () => $ZodUUID,
    $ZodUndefined: () => $ZodUndefined,
    $ZodUnion: () => $ZodUnion,
    $ZodUnknown: () => $ZodUnknown,
    $ZodVoid: () => $ZodVoid,
    $ZodXID: () => $ZodXID,
    $ZodXor: () => $ZodXor,
    $brand: () => $brand,
    $constructor: () => $constructor,
    $input: () => $input,
    $output: () => $output,
    Doc: () => Doc,
    INVALID: () => INVALID,
    JSONSchema: () => json_schema_exports,
    JSONSchemaGenerator: () => JSONSchemaGenerator,
    NEVER: () => NEVER,
    TimePrecision: () => TimePrecision,
    URL_BAD_FORMAT: () => URL_BAD_FORMAT,
    URL_UNPARSEABLE: () => URL_UNPARSEABLE,
    ZodCompileAsyncError: () => ZodCompileAsyncError,
    ZodCompileUnsupportedError: () => ZodCompileUnsupportedError,
    _any: () => _any,
    _array: () => _array,
    _base64: () => _base64,
    _base64url: () => _base64url,
    _bigint: () => _bigint,
    _boolean: () => _boolean,
    _catch: () => _catch,
    _check: () => _check,
    _cidrv4: () => _cidrv4,
    _cidrv6: () => _cidrv6,
    _coercedBigint: () => _coercedBigint,
    _coercedBoolean: () => _coercedBoolean,
    _coercedDate: () => _coercedDate,
    _coercedNumber: () => _coercedNumber,
    _coercedString: () => _coercedString,
    _creditCard: () => _creditCard,
    _cuid: () => _cuid,
    _cuid2: () => _cuid2,
    _custom: () => _custom,
    _date: () => _date,
    _decode: () => _decode,
    _decodeAsync: () => _decodeAsync,
    _default: () => _default,
    _discriminatedUnion: () => _discriminatedUnion,
    _e164: () => _e164,
    _email: () => _email,
    _emoji: () => _emoji2,
    _encode: () => _encode,
    _encodeAsync: () => _encodeAsync,
    _endsWith: () => _endsWith,
    _enum: () => _enum,
    _file: () => _file,
    _float32: () => _float32,
    _float64: () => _float64,
    _gt: () => _gt,
    _gte: () => _gte,
    _guid: () => _guid,
    _iban: () => _iban,
    _includes: () => _includes,
    _int: () => _int,
    _int32: () => _int32,
    _int64: () => _int64,
    _intersection: () => _intersection,
    _ipv4: () => _ipv4,
    _ipv6: () => _ipv6,
    _isoDate: () => _isoDate,
    _isoDateTime: () => _isoDateTime,
    _isoDuration: () => _isoDuration,
    _isoTime: () => _isoTime,
    _jwt: () => _jwt,
    _ksuid: () => _ksuid,
    _lazy: () => _lazy,
    _length: () => _length,
    _literal: () => _literal,
    _lowercase: () => _lowercase,
    _lt: () => _lt,
    _lte: () => _lte,
    _mac: () => _mac,
    _map: () => _map,
    _max: () => _lte,
    _maxLength: () => _maxLength,
    _maxSize: () => _maxSize,
    _mime: () => _mime,
    _min: () => _gte,
    _minLength: () => _minLength,
    _minSize: () => _minSize,
    _multipleOf: () => _multipleOf,
    _nan: () => _nan,
    _nanoid: () => _nanoid,
    _nativeEnum: () => _nativeEnum,
    _negative: () => _negative,
    _never: () => _never,
    _nonnegative: () => _nonnegative,
    _nonoptional: () => _nonoptional,
    _nonpositive: () => _nonpositive,
    _normalize: () => _normalize,
    _null: () => _null2,
    _nullable: () => _nullable,
    _number: () => _number,
    _optional: () => _optional,
    _overwrite: () => _overwrite,
    _parse: () => _parse,
    _parseAsync: () => _parseAsync,
    _pipe: () => _pipe,
    _positive: () => _positive,
    _promise: () => _promise,
    _properties: () => _properties,
    _property: () => _property,
    _readonly: () => _readonly,
    _record: () => _record,
    _refine: () => _refine,
    _regex: () => _regex,
    _safeDecode: () => _safeDecode,
    _safeDecodeAsync: () => _safeDecodeAsync,
    _safeEncode: () => _safeEncode,
    _safeEncodeAsync: () => _safeEncodeAsync,
    _safeParse: () => _safeParse,
    _safeParseAsync: () => _safeParseAsync,
    _set: () => _set,
    _size: () => _size,
    _slugify: () => _slugify,
    _startsWith: () => _startsWith,
    _string: () => _string,
    _stringFormat: () => _stringFormat,
    _stringbool: () => _stringbool,
    _success: () => _success,
    _superRefine: () => _superRefine,
    _symbol: () => _symbol,
    _templateLiteral: () => _templateLiteral,
    _toLowerCase: () => _toLowerCase,
    _toUpperCase: () => _toUpperCase,
    _transform: () => _transform,
    _trim: () => _trim,
    _tuple: () => _tuple,
    _uint32: () => _uint32,
    _uint64: () => _uint64,
    _ulid: () => _ulid,
    _undefined: () => _undefined2,
    _union: () => _union,
    _unknown: () => _unknown,
    _uppercase: () => _uppercase,
    _url: () => _url,
    _uuid: () => _uuid,
    _uuidv4: () => _uuidv4,
    _uuidv6: () => _uuidv6,
    _uuidv7: () => _uuidv7,
    _void: () => _void,
    _xid: () => _xid,
    _xor: () => _xor,
    base64Charset: () => base64Charset,
    base64urlCharset: () => base64urlCharset,
    canParseURL: () => canParseURL,
    clone: () => clone,
    compile: () => compile,
    compileFn: () => compileFn,
    config: () => config,
    createStandardJSONSchemaMethod: () => createStandardJSONSchemaMethod,
    createToJSONSchemaMethod: () => createToJSONSchemaMethod,
    decode: () => decode,
    decodeAsync: () => decodeAsync,
    describe: () => describe,
    encode: () => encode,
    encodeAsync: () => encodeAsync,
    extractDefs: () => extractDefs,
    finalize: () => finalize,
    flattenError: () => flattenError,
    formatError: () => formatError,
    getDiscriminatedOption: () => getDiscriminatedOption,
    globalConfig: () => globalConfig,
    globalRegistry: () => globalRegistry,
    handleUnrepresentable: () => handleUnrepresentable,
    initializeContext: () => initializeContext,
    isBackEdge: () => isBackEdge,
    isRecursiveSchema: () => isRecursiveSchema,
    isValidBase64: () => isValidBase64,
    isValidBase64URL: () => isValidBase64URL,
    isValidCIDRv6: () => isValidCIDRv6,
    isValidCreditCard: () => isValidCreditCard,
    isValidIBAN: () => isValidIBAN,
    isValidIPv6: () => isValidIPv6,
    isValidJWT: () => isValidJWT,
    locales: () => locales_exports,
    memoizer: () => memoizer,
    mergeValues: () => mergeValues,
    meta: () => meta,
    parse: () => parse,
    parseAsync: () => parseAsync,
    parseURLObject: () => parseURLObject,
    prettifyError: () => prettifyError,
    process: () => processSchema,
    processSchema: () => processSchema,
    regexes: () => regexes_exports,
    registry: () => registry,
    safeDecode: () => safeDecode,
    safeDecodeAsync: () => safeDecodeAsync,
    safeEncode: () => safeEncode,
    safeEncodeAsync: () => safeEncodeAsync,
    safeParse: () => safeParse,
    safeParseAsync: () => safeParseAsync,
    standardProps: () => standardProps,
    stripTabAndNewline: () => stripTabAndNewline,
    toDotPath: () => toDotPath,
    toJSONSchema: () => toJSONSchema,
    toZod: () => toZod,
    treeifyError: () => treeifyError,
    urlHostnameOk: () => urlHostnameOk,
    urlProtocolOk: () => urlProtocolOk,
    util: () => util_exports,
    validate: () => validate,
    validateAsync: () => validateAsync,
    validateURL: () => validateURL,
    version: () => version,
    withParser: () => withParser
  });

  // ../../../node_modules/zod/v4/core/util.js
  var util_exports = {};
  __export(util_exports, {
    BIGINT_FORMAT_RANGES: () => BIGINT_FORMAT_RANGES,
    CONSTANT_CATCH: () => CONSTANT_CATCH,
    Class: () => Class,
    NUMBER_FORMAT_RANGES: () => NUMBER_FORMAT_RANGES,
    aborted: () => aborted,
    allowsEval: () => allowsEval,
    assert: () => assert,
    assertEqual: () => assertEqual,
    assertIs: () => assertIs,
    assertNever: () => assertNever,
    assertNotEqual: () => assertNotEqual,
    assignProp: () => assignProp,
    attachSchema: () => attachSchema,
    base64ToUint8Array: () => base64ToUint8Array,
    base64urlToUint8Array: () => base64urlToUint8Array,
    cached: () => cached,
    captureStackTrace: () => captureStackTrace,
    cleanEnum: () => cleanEnum,
    cleanRegex: () => cleanRegex,
    clone: () => clone,
    cloneDef: () => cloneDef,
    codePointLength: () => codePointLength,
    constantCatch: () => constantCatch,
    createTransparentProxy: () => createTransparentProxy,
    defineLazy: () => defineLazy,
    defineLazyInternal: () => defineLazyInternal,
    derived: () => derived,
    esc: () => esc,
    escapeRegex: () => escapeRegex,
    explicitlyAborted: () => explicitlyAborted,
    extend: () => extend,
    finalizeIssue: () => finalizeIssue,
    floatSafeRemainder: () => floatSafeRemainder,
    getElementAtPath: () => getElementAtPath,
    getEnumValues: () => getEnumValues,
    getLengthableOrigin: () => getLengthableOrigin,
    getParsedType: () => getParsedType,
    getSizableOrigin: () => getSizableOrigin,
    hexToUint8Array: () => hexToUint8Array,
    hide: () => hide,
    installLazyProp: () => installLazyProp,
    isObject: () => isObject,
    isPlainObject: () => isPlainObject,
    issue: () => issue,
    joinValues: () => joinValues,
    jsonStringifyReplacer: () => jsonStringifyReplacer,
    members: () => members,
    merge: () => merge,
    mergeDefs: () => mergeDefs,
    normalizeParams: () => normalizeParams,
    nullish: () => nullish,
    numKeys: () => numKeys,
    objectClone: () => objectClone,
    omit: () => omit,
    optionalKeys: () => optionalKeys,
    own: () => own,
    parsedType: () => parsedType,
    partial: () => partial,
    pick: () => pick,
    prefixIssues: () => prefixIssues,
    primitiveTypes: () => primitiveTypes,
    promiseAllObject: () => promiseAllObject,
    propertyKeyTypes: () => propertyKeyTypes,
    randomString: () => randomString,
    rawShape: () => rawShape,
    required: () => required,
    safeExtend: () => safeExtend,
    shallowClone: () => shallowClone,
    sizeCaps: () => sizeCaps,
    slugify: () => slugify,
    stringifyPrimitive: () => stringifyPrimitive,
    toZod: () => toZod,
    uint8ArrayToBase64: () => uint8ArrayToBase64,
    uint8ArrayToBase64url: () => uint8ArrayToBase64url,
    uint8ArrayToHex: () => uint8ArrayToHex,
    unwrapMessage: () => unwrapMessage
  });
  function assertEqual(val) {
    return val;
  }
  function assertNotEqual(val) {
    return val;
  }
  function toZod() {
    return (schema) => schema;
  }
  function assertIs(_arg) {
  }
  function assertNever(_x) {
    throw new Error("Unexpected value in exhaustive check");
  }
  function assert(_) {
  }
  function getEnumValues(entries) {
    const numericValues = Object.values(entries).filter((v) => typeof v === "number");
    const values = Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
    return values;
  }
  function joinValues(array2, separator = "|") {
    return array2.map((val) => stringifyPrimitive(val)).join(separator);
  }
  function jsonStringifyReplacer(_, value) {
    if (typeof value === "bigint")
      return value.toString();
    return value;
  }
  var Cached = class {
    constructor(getter) {
      this._getter = getter;
      this._value = void 0;
    }
    get value() {
      const getter = this._getter;
      if (getter !== void 0) {
        this._value = getter();
        this._getter = void 0;
      }
      return this._value;
    }
  };
  function cached(getter) {
    return new Cached(getter);
  }
  function nullish(input2) {
    return input2 === null || input2 === void 0;
  }
  function cleanRegex(source) {
    const start = source.startsWith("^") ? 1 : 0;
    const end = source.endsWith("$") ? source.length - 1 : source.length;
    return source.slice(start, end);
  }
  function floatSafeRemainder(val, step) {
    const ratio = val / step;
    const roundedRatio = Math.round(ratio);
    const tolerance = 4 * Number.EPSILON * Math.max(Math.abs(ratio), 1);
    if (Math.abs(ratio - roundedRatio) < tolerance)
      return 0;
    return ratio - roundedRatio;
  }
  var EVALUATING = /* @__PURE__ */ Symbol("evaluating");
  function defineLazy(object2, key6, getter) {
    let value = void 0;
    Object.defineProperty(object2, key6, {
      get() {
        if (value === EVALUATING) {
          return void 0;
        }
        if (value === void 0) {
          value = EVALUATING;
          value = getter();
        }
        return value;
      },
      set(v) {
        Object.defineProperty(object2, key6, {
          value: v
          // configurable: true,
        });
      },
      configurable: true
    });
  }
  function objectClone(obj) {
    return Object.create(Object.getPrototypeOf(obj), Object.getOwnPropertyDescriptors(obj));
  }
  function assignProp(target3, prop, value) {
    Object.defineProperty(target3, prop, {
      value,
      writable: true,
      enumerable: true,
      configurable: true
    });
  }
  function rawShape(def) {
    const desc = Object.getOwnPropertyDescriptor(def, "shape");
    return desc?.get ? desc.get.raw : desc?.value;
  }
  function sourceShape(schema) {
    return rawShape(schema._zod.def) ?? schema._zod.def.shape;
  }
  function deferProp(target3, key6, getter) {
    Object.defineProperty(target3, key6, {
      get() {
        const value = getter();
        assignProp(this, key6, value);
        return value;
      },
      enumerable: true,
      configurable: true
    });
  }
  function putProp(target3, key6, value) {
    if (key6 in target3)
      assignProp(target3, key6, value);
    else
      target3[key6] = value;
  }
  function mirrorShape(target3, source, keys, wrap) {
    const raw = sourceShape(source);
    for (const key6 of keys) {
      const desc = Object.getOwnPropertyDescriptor(raw, key6);
      if (!desc.enumerable)
        continue;
      if (desc.get) {
        deferProp(target3, key6, () => {
          const value = source._zod.def.shape[key6];
          return wrap ? wrap(value, key6) : value;
        });
      } else
        putProp(target3, key6, wrap ? wrap(desc.value, key6) : desc.value);
    }
  }
  function mirrorProps(target3, source) {
    for (const key6 of Reflect.ownKeys(source)) {
      const desc = Object.getOwnPropertyDescriptor(source, key6);
      if (!desc.enumerable)
        continue;
      if (desc.get)
        deferProp(target3, key6, () => source[key6]);
      else
        putProp(target3, key6, desc.value);
    }
  }
  function mergeDefs(...defs) {
    const mergedDescriptors = {};
    for (const def of defs) {
      const descriptors = Object.getOwnPropertyDescriptors(def);
      Object.assign(mergedDescriptors, descriptors);
    }
    return Object.defineProperties({}, mergedDescriptors);
  }
  function cloneDef(schema) {
    return mergeDefs(schema._zod.def);
  }
  function getElementAtPath(obj, path) {
    if (!path)
      return obj;
    return path.reduce((acc, key6) => acc?.[key6], obj);
  }
  function promiseAllObject(promisesObj) {
    const keys = Object.keys(promisesObj);
    const promises = keys.map((key6) => promisesObj[key6]);
    return Promise.all(promises).then((results) => {
      const resolvedObj = {};
      for (let i = 0; i < keys.length; i++) {
        resolvedObj[keys[i]] = results[i];
      }
      return resolvedObj;
    });
  }
  function randomString(length = 10) {
    const chars = "abcdefghijklmnopqrstuvwxyz";
    let str = "";
    for (let i = 0; i < length; i++) {
      str += chars[Math.floor(Math.random() * chars.length)];
    }
    return str;
  }
  function esc(str) {
    return JSON.stringify(str);
  }
  function slugify(input2) {
    return input2.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
  }
  var captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {
  };
  function isObject(data) {
    return typeof data === "object" && data !== null && !Array.isArray(data);
  }
  var allowsEval = /* @__PURE__ */ cached(() => {
    if (globalConfig.jitless) {
      return false;
    }
    if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) {
      return false;
    }
    try {
      const F = Function;
      new F("");
      return true;
    } catch (_) {
      return false;
    }
  });
  function isPlainObject(o) {
    if (isObject(o) === false)
      return false;
    const ctor = o.constructor;
    if (ctor === void 0)
      return true;
    if (typeof ctor !== "function")
      return true;
    const prot = ctor.prototype;
    if (isObject(prot) === false)
      return false;
    if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) {
      return false;
    }
    return true;
  }
  function shallowClone(o) {
    if (isPlainObject(o))
      return { ...o };
    if (Array.isArray(o))
      return [...o];
    if (o instanceof Map)
      return new Map(o);
    if (o instanceof Set)
      return new Set(o);
    return o;
  }
  function numKeys(data) {
    let keyCount = 0;
    for (const key6 in data) {
      if (Object.prototype.hasOwnProperty.call(data, key6)) {
        keyCount++;
      }
    }
    return keyCount;
  }
  var getParsedType = (data) => {
    const t = typeof data;
    switch (t) {
      case "undefined":
        return "undefined";
      case "string":
        return "string";
      case "number":
        return Number.isNaN(data) ? "nan" : "number";
      case "boolean":
        return "boolean";
      case "function":
        return "function";
      case "bigint":
        return "bigint";
      case "symbol":
        return "symbol";
      case "object":
        if (Array.isArray(data)) {
          return "array";
        }
        if (data === null) {
          return "null";
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return "promise";
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return "map";
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return "set";
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return "date";
        }
        if (typeof File !== "undefined" && data instanceof File) {
          return "file";
        }
        return "object";
      default:
        throw new Error(`Unknown data type: ${t}`);
    }
  };
  var propertyKeyTypes = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
  var primitiveTypes = /* @__PURE__ */ new Set([
    "string",
    "number",
    "bigint",
    "boolean",
    "symbol",
    "undefined"
  ]);
  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function clone(inst, def, params) {
    const cl = new inst._zod.constr(def ?? inst._zod.def);
    if (!def || params?.parent)
      cl._zod.parent = inst;
    return cl;
  }
  function normalizeParams(_params) {
    const params = _params;
    if (!params)
      return {};
    if (typeof params === "string")
      return { error: () => params };
    if (params?.message !== void 0) {
      if (params?.error !== void 0)
        throw new Error("Cannot specify both `message` and `error` params");
      params.error = params.message;
    }
    delete params.message;
    if (typeof params.error === "string")
      return { ...params, error: () => params.error };
    return params;
  }
  function createTransparentProxy(getter) {
    let target3;
    return new Proxy({}, {
      get(_, prop, receiver) {
        target3 ?? (target3 = getter());
        return Reflect.get(target3, prop, receiver);
      },
      set(_, prop, value, receiver) {
        target3 ?? (target3 = getter());
        return Reflect.set(target3, prop, value, receiver);
      },
      has(_, prop) {
        target3 ?? (target3 = getter());
        return Reflect.has(target3, prop);
      },
      deleteProperty(_, prop) {
        target3 ?? (target3 = getter());
        return Reflect.deleteProperty(target3, prop);
      },
      ownKeys(_) {
        target3 ?? (target3 = getter());
        return Reflect.ownKeys(target3);
      },
      getOwnPropertyDescriptor(_, prop) {
        target3 ?? (target3 = getter());
        return Reflect.getOwnPropertyDescriptor(target3, prop);
      },
      defineProperty(_, prop, descriptor) {
        target3 ?? (target3 = getter());
        return Reflect.defineProperty(target3, prop, descriptor);
      }
    });
  }
  function stringifyPrimitive(value) {
    if (typeof value === "bigint")
      return value.toString() + "n";
    if (typeof value === "string")
      return `"${value}"`;
    return `${value}`;
  }
  function optionalKeys(shape) {
    return Object.keys(shape).filter((k) => {
      return shape[k]._zod.optin !== void 0 && shape[k]._zod.optout === "optional";
    });
  }
  var NUMBER_FORMAT_RANGES = /* @__PURE__ */ (() => ({
    safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
    int32: [-2147483648, 2147483647],
    uint32: [0, 4294967295],
    float32: [-34028234663852886e22, 34028234663852886e22],
    float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
  }))();
  var BIGINT_FORMAT_RANGES = {
    int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
    uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
  };
  function pick(schema, mask) {
    const currDef = schema._zod.def;
    const checks = currDef.checks;
    const hasChecks = checks && checks.length > 0;
    if (hasChecks) {
      throw new Error(".pick() cannot be used on object schemas containing refinements");
    }
    const newShape = {};
    mirrorShape(newShape, schema, maskedKeys(schema, mask));
    return clone(schema, mergeDefs(currDef, { shape: newShape, checks: [] }));
  }
  function maskedKeys(schema, mask) {
    const raw = sourceShape(schema);
    const keys = [];
    for (const key6 of Reflect.ownKeys(mask)) {
      if (!Object.getOwnPropertyDescriptor(raw, key6)?.enumerable) {
        throw new Error(`Unrecognized key: "${String(key6)}"`);
      }
      if (mask[key6])
        keys.push(key6);
    }
    return keys;
  }
  function omit(schema, mask) {
    const currDef = schema._zod.def;
    const checks = currDef.checks;
    const hasChecks = checks && checks.length > 0;
    if (hasChecks) {
      throw new Error(".omit() cannot be used on object schemas containing refinements");
    }
    const omitted = new Set(maskedKeys(schema, mask));
    const newShape = {};
    mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)).filter((key6) => !omitted.has(key6)));
    return clone(schema, mergeDefs(currDef, { shape: newShape, checks: [] }));
  }
  function extend(schema, shape) {
    if (!isPlainObject(shape)) {
      throw new Error("Invalid input to extend: expected a plain object");
    }
    const checks = schema._zod.def.checks;
    const hasChecks = checks && checks.length > 0;
    if (hasChecks) {
      const existingShape = sourceShape(schema);
      for (const key6 of Reflect.ownKeys(shape)) {
        if (Object.getOwnPropertyDescriptor(existingShape, key6) !== void 0) {
          throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
        }
      }
    }
    return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
  }
  function extended(schema, shape) {
    const newShape = {};
    mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)));
    mirrorProps(newShape, shape);
    return newShape;
  }
  function safeExtend(schema, shape) {
    if (!isPlainObject(shape)) {
      throw new Error("Invalid input to safeExtend: expected a plain object");
    }
    return clone(schema, mergeDefs(schema._zod.def, { shape: extended(schema, shape) }));
  }
  function merge(a, b) {
    if (!b?._zod?.def) {
      throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
    }
    if (a._zod.def.checks?.length) {
      throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
    }
    const newShape = {};
    mirrorShape(newShape, a, Reflect.ownKeys(sourceShape(a)));
    mirrorShape(newShape, b, Reflect.ownKeys(sourceShape(b)));
    const def = mergeDefs(a._zod.def, {
      shape: newShape,
      get catchall() {
        return b._zod.def.catchall;
      },
      checks: b._zod.def.checks ?? []
    });
    return clone(a, def);
  }
  function partial(Class2, schema, mask, name = "partial") {
    const currDef = schema._zod.def;
    const checks = currDef.checks;
    const hasChecks = checks && checks.length > 0;
    if (hasChecks) {
      throw new Error(`.${name}() cannot be used on object schemas containing refinements`);
    }
    const selected = mask ? new Set(maskedKeys(schema, mask)) : void 0;
    const newShape = {};
    mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), Class2 && ((value, key6) => selected && !selected.has(key6) ? value : new Class2({ type: "optional", innerType: value })));
    return clone(schema, mergeDefs(schema._zod.def, { shape: newShape, checks: [] }));
  }
  function required(Class2, schema, mask) {
    const selected = mask ? new Set(maskedKeys(schema, mask)) : void 0;
    const newShape = {};
    mirrorShape(newShape, schema, Reflect.ownKeys(sourceShape(schema)), (value, key6) => (
      // overwrite with non-optional
      selected && !selected.has(key6) ? value : new Class2({ type: "nonoptional", innerType: value })
    ));
    return clone(schema, mergeDefs(schema._zod.def, { shape: newShape }));
  }
  function aborted(x, startIndex = 0) {
    if (x.aborted === true)
      return true;
    for (let i = startIndex; i < x.issues.length; i++) {
      if (x.issues[i]?.continue !== true) {
        return true;
      }
    }
    return false;
  }
  function explicitlyAborted(x, startIndex = 0) {
    if (x.aborted === true)
      return true;
    for (let i = startIndex; i < x.issues.length; i++) {
      if (x.issues[i]?.continue === false) {
        return true;
      }
    }
    return false;
  }
  function prefixIssues(path, issues) {
    return issues.map((iss) => {
      var _a3;
      (_a3 = iss).path ?? (_a3.path = []);
      iss.path.unshift(path);
      return iss;
    });
  }
  function unwrapMessage(message2) {
    return typeof message2 === "string" ? message2 : message2?.message;
  }
  function sizeCaps(defChecks) {
    const caps = [];
    for (const ch of defChecks ?? []) {
      const d = ch._zod.def;
      if (!/_(length|size)$|_equals$/.test(d.check))
        break;
      const max = d.maximum ?? d.length ?? d.size;
      if (max >= 0)
        caps.push([max, ch]);
    }
    return caps;
  }
  function attachSchema(issues, start, inst) {
    var _a3;
    for (let i = start; i < issues.length; i++) {
      (_a3 = issues[i]).schema ?? (_a3.schema = inst);
    }
  }
  function finalizeIssue(iss, ctx, config2) {
    var _a3;
    const traits = iss.inst?._zod?.traits;
    if (traits?.has("$ZodType")) {
      if (traits.has("$ZodCheck"))
        (_a3 = iss).schema ?? (_a3.schema = iss.inst);
      else
        iss.schema = iss.inst;
    }
    const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : void 0;
    const message2 = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config2.customError?.(iss)) ?? unwrapMessage(config2.localeError?.(iss)) ?? "Invalid input";
    const full = {};
    for (const k of Object.keys(iss)) {
      if (k === "inst" || k === "schema" || k === "continue" || k === "input" || k === "__proto__")
        continue;
      full[k] = iss[k];
    }
    full.path ?? (full.path = []);
    full.message = message2;
    if (ctx?.reportInput) {
      full.input = iss.input;
    }
    return full;
  }
  function getSizableOrigin(input2) {
    if (input2 instanceof Set)
      return "set";
    if (input2 instanceof Map)
      return "map";
    if (input2 instanceof File)
      return "file";
    return "unknown";
  }
  var highSurrogate = /[\uD800-\uDBFF]/;
  function codePointLength(str) {
    const units = str.length;
    if (!highSurrogate.test(str))
      return units;
    let count = units;
    for (let i = 0; i < units - 1; i++) {
      if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
        count--;
        i++;
      }
    }
    return count;
  }
  function getLengthableOrigin(input2) {
    if (Array.isArray(input2))
      return "array";
    if (typeof input2 === "string")
      return "string";
    return "unknown";
  }
  function parsedType(data) {
    const t = typeof data;
    switch (t) {
      case "number": {
        return Number.isNaN(data) ? "nan" : "number";
      }
      case "object": {
        if (data === null) {
          return "null";
        }
        if (Array.isArray(data)) {
          return "array";
        }
        const obj = data;
        if (obj && Object.getPrototypeOf(obj) !== Object.prototype && "constructor" in obj && obj.constructor) {
          return obj.constructor.name;
        }
      }
    }
    return t;
  }
  function issue(...args) {
    const [iss, input2, inst] = args;
    if (typeof iss === "string") {
      return {
        message: iss,
        code: "custom",
        input: input2,
        inst
      };
    }
    return { ...iss };
  }
  function cleanEnum(obj) {
    return Object.entries(obj).filter(([k, _]) => {
      return Number.isNaN(Number.parseInt(k, 10));
    }).map((el) => el[1]);
  }
  function base64ToUint8Array(base643) {
    const binaryString = atob(base643);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }
  function uint8ArrayToBase64(bytes) {
    let binaryString = "";
    for (let i = 0; i < bytes.length; i++) {
      binaryString += String.fromCharCode(bytes[i]);
    }
    return btoa(binaryString);
  }
  function base64urlToUint8Array(base64url3) {
    const base643 = base64url3.replace(/-/g, "+").replace(/_/g, "/");
    const padding = "=".repeat((4 - base643.length % 4) % 4);
    return base64ToUint8Array(base643 + padding);
  }
  function uint8ArrayToBase64url(bytes) {
    return uint8ArrayToBase64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  }
  function hexToUint8Array(hex3) {
    const cleanHex = hex3.replace(/^0x/, "");
    if (cleanHex.length % 2 !== 0) {
      throw new Error("Invalid hex string length");
    }
    const bytes = new Uint8Array(cleanHex.length / 2);
    for (let i = 0; i < cleanHex.length; i += 2) {
      bytes[i / 2] = Number.parseInt(cleanHex.slice(i, i + 2), 16);
    }
    return bytes;
  }
  function uint8ArrayToHex(bytes) {
    return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var Class = class {
    constructor(..._args) {
    }
  };
  function members(proto, table2) {
    for (const key6 in table2) {
      const desc = Object.getOwnPropertyDescriptor(table2, key6);
      if (desc.get)
        Object.defineProperty(proto, key6, { ...desc, enumerable: false });
      else
        defineBound(proto, key6, desc.value);
    }
  }
  function own(inst, key6, value, enumerable = true) {
    Object.defineProperty(inst, key6, { configurable: true, writable: true, enumerable, value });
    return value;
  }
  function hide(inst, key6, value) {
    return own(inst, key6, value, false);
  }
  // @__NO_SIDE_EFFECTS__
  function derived(computes, table2) {
    for (const key6 in computes) {
      const compute = computes[key6];
      Object.defineProperty(table2, key6, {
        configurable: true,
        enumerable: true,
        get() {
          return own(this, key6, compute(this));
        },
        set(value) {
          own(this, key6, value);
        }
      });
    }
    return table2;
  }
  function defineBound(proto, key6, fn) {
    Object.defineProperty(proto, key6, {
      configurable: true,
      get() {
        return this == null ? fn : own(this, key6, fn.bind(this));
      },
      set(value) {
        own(this, key6, value);
      }
    });
  }
  function claim(inst, sentinel) {
    const proto = Object.getPrototypeOf(inst);
    return sentinel in proto ? void 0 : proto;
  }
  var installing;
  var broke = false;
  var breaker = {
    configurable: true,
    get() {
      broke = true;
      return void 0;
    }
  };
  function defineLazyInternal(inst, key6, compute) {
    const proto = Object.getPrototypeOf(inst._zod);
    if (key6 in proto && installing !== inst._zod) {
      installing = void 0;
      return;
    }
    installing = inst._zod;
    Object.defineProperty(proto, key6, {
      configurable: true,
      get() {
        Object.defineProperty(this, key6, breaker);
        const outer = broke;
        broke = false;
        try {
          const value = compute(this);
          if (broke)
            delete this[key6];
          else
            Object.defineProperty(this, key6, { configurable: true, writable: true, value });
          broke = broke || outer;
          return value;
        } catch (err) {
          delete this[key6];
          broke = broke || outer;
          throw err;
        }
      },
      set(value) {
        Object.defineProperty(this, key6, { configurable: true, writable: true, value });
      }
    });
  }
  function installLazyProp(inst, key6, make, enumerable) {
    const proto = claim(inst, key6);
    if (!proto)
      return;
    Object.defineProperty(proto, key6, {
      configurable: true,
      get() {
        const desc = { configurable: true, writable: true, enumerable, value: void 0 };
        Object.defineProperty(this, key6, desc);
        desc.value = make(this);
        Object.defineProperty(this, key6, desc);
        return desc.value;
      },
      set(value) {
        Object.defineProperty(this, key6, { configurable: true, writable: true, enumerable, value });
      }
    });
  }
  var CONSTANT_CATCH = "~constantCatch";
  function constantCatch(value) {
    const fn = () => value;
    fn[CONSTANT_CATCH] = true;
    return fn;
  }

  // ../../../node_modules/zod/v4/core/core.js
  var _a;
  var NEVER = /* @__PURE__ */ Object.freeze({
    status: "aborted"
  });
  var _zodDesc = { value: void 0, enumerable: false };
  var _E = "captureStackTrace" in Error ? Error : null;
  function newError(Definition) {
    const E = _E;
    if (E) {
      const saved = E.stackTraceLimit;
      if (typeof saved === "number") {
        try {
          E.stackTraceLimit = 0;
        } catch {
          _E = null;
          return new Definition();
        }
        try {
          return new Definition();
        } finally {
          E.stackTraceLimit = saved;
        }
      }
    }
    return new Definition();
  }
  // @__NO_SIDE_EFFECTS__
  function $constructor(name, initializer3, proto, params) {
    const zodProto = {};
    function Internals(def) {
      this.def = def;
      this.constr = _;
      this.traits = /* @__PURE__ */ new Set();
    }
    Internals.prototype = zodProto;
    const protoMembers = proto;
    const initialized = protoMembers && /* @__PURE__ */ new WeakSet();
    function init(inst, def) {
      if (!inst._zod) {
        _zodDesc.value = new Internals(def);
        try {
          Object.defineProperty(inst, "_zod", _zodDesc);
        } finally {
          _zodDesc.value = void 0;
        }
      } else if (inst._zod.traits.has(name)) {
        return;
      }
      inst._zod.traits.add(name);
      initializer3(inst, def);
      if (initialized) {
        const own2 = Object.getPrototypeOf(inst);
        const ctorProto = inst._zod.constr.prototype;
        let up = own2;
        while (up && up !== ctorProto)
          up = Object.getPrototypeOf(up);
        const target3 = up ?? own2;
        if (!initialized.has(target3)) {
          initialized.add(target3);
          members(target3, protoMembers);
        }
      }
      const proto2 = _.prototype;
      for (const k in proto2) {
        if (!Object.prototype.hasOwnProperty.call(proto2, k))
          continue;
        if (!(k in inst)) {
          inst[k] = proto2[k].bind(inst);
        }
      }
    }
    const Parent = params?.Parent ?? Object;
    class Definition extends Parent {
    }
    Object.defineProperty(Definition, "name", { value: name });
    function _(def) {
      const inst = params?.Parent ? newError(Definition) : this;
      init(inst, def);
      const deferred = inst._zod.deferred;
      if (deferred) {
        for (const fn of deferred) {
          fn();
        }
        inst._zod.deferred = void 0;
      }
      const pp = globalThis.__zod_globalConfig?.postProcessor;
      if (pp)
        pp(inst);
      return inst;
    }
    Object.defineProperty(_, "init", { value: init });
    Object.defineProperty(_, Symbol.hasInstance, {
      value: (inst) => {
        if (params?.Parent && inst instanceof params.Parent)
          return true;
        return inst?._zod?.traits?.has(name);
      }
    });
    Object.defineProperty(_, "name", { value: name });
    return _;
  }
  var $brand = /* @__PURE__ */ Symbol("zod_brand");
  var $ZodAsyncError = class extends Error {
    constructor() {
      super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
    }
  };
  var $ZodEncodeError = class extends Error {
    constructor(name) {
      super(`Encountered unidirectional transform during encode: ${name}`);
      this.name = "ZodEncodeError";
    }
  };
  (_a = globalThis).__zod_globalConfig ?? (_a.__zod_globalConfig = {});
  var globalConfig = globalThis.__zod_globalConfig;
  function config(newConfig) {
    if (newConfig)
      Object.assign(globalConfig, newConfig);
    return globalConfig;
  }

  // ../../../node_modules/zod/v4/core/errors.js
  function _getMessage() {
    const internals = this._zod;
    internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
    return internals.message;
  }
  function _setMessage(value) {
    this._zod.message = value;
  }
  var _messageDesc = {
    get: _getMessage,
    set: _setMessage,
    enumerable: true,
    configurable: true
  };
  var _issuesDesc = { value: void 0, enumerable: false };
  var _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
  var initializer = (inst, def) => {
    inst.name = "$ZodError";
    _issuesDesc.value = def;
    Object.defineProperty(inst, "issues", _issuesDesc);
    _issuesDesc.value = void 0;
    Object.defineProperty(inst, "message", _messageDesc);
    const proto = Object.getPrototypeOf(inst);
    if (!_installedToString.has(proto)) {
      _installedToString.add(proto);
      Object.defineProperty(proto, "toString", {
        configurable: true,
        enumerable: false,
        get() {
          const value = () => this.message;
          Object.defineProperty(this, "toString", { value, configurable: true, writable: true });
          return value;
        },
        set(value) {
          Object.defineProperty(this, "toString", { value, configurable: true, writable: true });
        }
      });
    }
  };
  var $ZodError = $constructor("$ZodError", initializer);
  var $ZodRealError = $constructor("$ZodError", initializer, void 0, {
    Parent: Error
  });
  function node(obj, key6, make) {
    if (!Object.prototype.hasOwnProperty.call(obj, key6)) {
      if (key6 === "__proto__") {
        Object.defineProperty(obj, key6, { value: make(), writable: true, enumerable: true, configurable: true });
      } else {
        obj[key6] = make();
      }
    }
    return obj[key6];
  }
  function flattenError(error62, mapper = (issue3) => issue3.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of error62.issues) {
      if (sub.path.length > 0) {
        node(fieldErrors, sub.path[0], () => []).push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  function formatError(error62, mapper = (issue3) => issue3.message) {
    const fieldErrors = { _errors: [] };
    const processError = (error63, path = []) => {
      for (const issue3 of error63.issues) {
        if (issue3.code === "invalid_union" && issue3.errors.length) {
          issue3.errors.map((issues) => processError({ issues }, [...path, ...issue3.path]));
        } else if (issue3.code === "invalid_key") {
          processError({ issues: issue3.issues }, [...path, ...issue3.path]);
        } else if (issue3.code === "invalid_element") {
          processError({ issues: issue3.issues }, [...path, ...issue3.path]);
        } else {
          const fullpath = [...path, ...issue3.path];
          if (fullpath.length === 0) {
            fieldErrors._errors.push(mapper(issue3));
          } else {
            let curr = fieldErrors;
            let i = 0;
            while (i < fullpath.length) {
              const el = fullpath[i];
              const terminal = i === fullpath.length - 1;
              if (el === "_errors") {
                if (terminal)
                  curr._errors.push(mapper(issue3));
                i++;
                continue;
              }
              if (!Object.prototype.hasOwnProperty.call(curr, el)) {
                Object.defineProperty(curr, el, {
                  value: { _errors: [] },
                  enumerable: true,
                  writable: true,
                  configurable: true
                });
              }
              const node2 = curr[el];
              if (terminal) {
                node2._errors.push(mapper(issue3));
              }
              curr = node2;
              i++;
            }
          }
        }
      }
    };
    processError(error62);
    return fieldErrors;
  }
  function treeifyError(error62, mapper = (issue3) => issue3.message) {
    const result = { errors: [] };
    const processError = (error63, path = []) => {
      var _a3;
      for (const issue3 of error63.issues) {
        if (issue3.code === "invalid_union" && issue3.errors.length) {
          issue3.errors.map((issues) => processError({ issues }, [...path, ...issue3.path]));
        } else if (issue3.code === "invalid_key") {
          processError({ issues: issue3.issues }, [...path, ...issue3.path]);
        } else if (issue3.code === "invalid_element") {
          processError({ issues: issue3.issues }, [...path, ...issue3.path]);
        } else {
          const fullpath = [...path, ...issue3.path];
          if (fullpath.length === 0) {
            result.errors.push(mapper(issue3));
            continue;
          }
          let curr = result;
          let i = 0;
          while (i < fullpath.length) {
            const el = fullpath[i];
            const terminal = i === fullpath.length - 1;
            if (typeof el === "string") {
              curr.properties ?? (curr.properties = {});
              if (!Object.prototype.hasOwnProperty.call(curr.properties, el)) {
                Object.defineProperty(curr.properties, el, {
                  value: { errors: [] },
                  enumerable: true,
                  writable: true,
                  configurable: true
                });
              }
              curr = curr.properties[el];
            } else {
              curr.items ?? (curr.items = []);
              (_a3 = curr.items)[el] ?? (_a3[el] = { errors: [] });
              curr = curr.items[el];
            }
            if (terminal) {
              curr.errors.push(mapper(issue3));
            }
            i++;
          }
        }
      }
    };
    processError(error62);
    return result;
  }
  function toDotPath(_path) {
    const segs = [];
    const path = _path.map((seg) => typeof seg === "object" ? seg.key : seg);
    for (const seg of path) {
      if (typeof seg === "number")
        segs.push(`[${seg}]`);
      else if (typeof seg === "symbol")
        segs.push(`[${JSON.stringify(String(seg))}]`);
      else if (/[^\w$]/.test(seg))
        segs.push(`[${JSON.stringify(seg)}]`);
      else {
        if (segs.length)
          segs.push(".");
        segs.push(seg);
      }
    }
    return segs.join("");
  }
  function prettifyError(error62) {
    const lines = [];
    const issues = [...error62.issues].sort((a, b) => (a.path ?? []).length - (b.path ?? []).length);
    for (const issue3 of issues) {
      lines.push(`\u2716 ${issue3.message}`);
      if (issue3.path?.length)
        lines.push(`  \u2192 at ${toDotPath(issue3.path)}`);
    }
    return lines.join("\n");
  }

  // ../../../node_modules/zod/v4/core/parse.js
  function finalizeParams(callee, params) {
    return { callee: params?.callee ?? callee, Err: params?.Err };
  }
  var _parse = (_Err) => {
    const fn = (schema, value, _ctx, _params) => {
      const ctx = _ctx ? { ..._ctx, async: false } : { async: false };
      const result = schema._zod.run({ value, issues: [] }, ctx);
      if (result instanceof Promise) {
        throw new $ZodAsyncError();
      }
      if (result.issues.length) {
        const e = new (_params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
        captureStackTrace(e, _params?.callee ?? fn);
        throw e;
      }
      return result.value;
    };
    return fn;
  };
  var parse = /* @__PURE__ */ _parse($ZodRealError);
  var _parseAsync = (_Err) => {
    const fn = async (schema, value, _ctx, params) => {
      const ctx = _ctx ? { ..._ctx, async: true } : { async: true };
      let result = schema._zod.run({ value, issues: [] }, ctx);
      if (result instanceof Promise)
        result = await result;
      if (result.issues.length) {
        const e = new (params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
        captureStackTrace(e, params?.callee ?? fn);
        throw e;
      }
      return result.value;
    };
    return fn;
  };
  var parseAsync = /* @__PURE__ */ _parseAsync($ZodRealError);
  var _safeParse = (_Err) => (schema, value, _ctx) => {
    const ctx = _ctx ? { ..._ctx, async: false } : { async: false };
    const result = schema._zod.run({ value, issues: [] }, ctx);
    if (result instanceof Promise) {
      throw new $ZodAsyncError();
    }
    return result.issues.length ? failure(_Err, result.issues, ctx) : { success: true, data: result.value };
  };
  var safeParse = /* @__PURE__ */ _safeParse($ZodRealError);
  function failure(Err, issues, ctx) {
    let error62;
    return {
      success: false,
      get error() {
        if (!error62) {
          error62 = new Err(issues.map((iss) => finalizeIssue(iss, ctx, config())));
          issues = void 0;
          ctx = void 0;
        }
        return error62;
      },
      set error(e) {
        error62 = e;
        issues = void 0;
        ctx = void 0;
      }
    };
  }
  var _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
    const ctx = _ctx ? { ..._ctx, async: true } : { async: true };
    let result = schema._zod.run({ value, issues: [] }, ctx);
    if (result instanceof Promise)
      result = await result;
    return result.issues.length ? failure(_Err, result.issues, ctx) : { success: true, data: result.value };
  };
  var safeParseAsync = /* @__PURE__ */ _safeParseAsync($ZodRealError);
  var COMPILE_INVALID = /* @__PURE__ */ Symbol.for("zod.compile.invalid");
  var COMPILE_FALLBACK = /* @__PURE__ */ Symbol.for("zod.compile.fallback");
  var validate = ((schema, value, _ctx) => {
    const validator = schema._zod.bag.validator;
    if (validator !== void 0) {
      if (validator(value) !== COMPILE_INVALID)
        return true;
      if (validator.definite === true && _ctx === void 0)
        return false;
    }
    return validateFallback(schema, value, _ctx);
  });
  function validateFallback(schema, value, _ctx) {
    const ctx = _ctx ? { ..._ctx, async: false, abortEarly: true } : { async: false, abortEarly: true };
    const fallbackRun = schema._zod.bag.fallbackRun;
    let result;
    if (fallbackRun) {
      ctx[COMPILE_FALLBACK] = true;
      result = fallbackRun({ value, issues: [] }, ctx);
    } else {
      result = schema._zod.run({ value, issues: [] }, ctx);
    }
    if (result instanceof Promise) {
      throw new $ZodAsyncError();
    }
    return result.issues.length === 0;
  }
  var validateAsync = async (schema, value, _ctx) => {
    const ctx = _ctx ? { ..._ctx, async: true, abortEarly: true } : { async: true, abortEarly: true };
    let result = schema._zod.run({ value, issues: [] }, ctx);
    if (result instanceof Promise)
      result = await result;
    return result.issues.length === 0;
  };
  var _encode = (_Err) => {
    const parse3 = _parse(_Err);
    const fn = (schema, value, _ctx, _params) => {
      const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
      return parse3(schema, value, ctx, finalizeParams(fn, _params));
    };
    return fn;
  };
  var encode = /* @__PURE__ */ _encode($ZodRealError);
  var _decode = (_Err) => {
    const parse3 = _parse(_Err);
    const fn = (schema, value, _ctx, _params) => {
      return parse3(schema, value, _ctx, finalizeParams(fn, _params));
    };
    return fn;
  };
  var decode = /* @__PURE__ */ _decode($ZodRealError);
  var _encodeAsync = (_Err) => {
    const parseAsync3 = _parseAsync(_Err);
    const fn = async (schema, value, _ctx, _params) => {
      const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
      return await parseAsync3(schema, value, ctx, finalizeParams(fn, _params));
    };
    return fn;
  };
  var encodeAsync = /* @__PURE__ */ _encodeAsync($ZodRealError);
  var _decodeAsync = (_Err) => {
    const parseAsync3 = _parseAsync(_Err);
    const fn = async (schema, value, _ctx, _params) => {
      return await parseAsync3(schema, value, _ctx, finalizeParams(fn, _params));
    };
    return fn;
  };
  var decodeAsync = /* @__PURE__ */ _decodeAsync($ZodRealError);
  var _safeEncode = (_Err) => (schema, value, _ctx) => {
    const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
    return _safeParse(_Err)(schema, value, ctx);
  };
  var safeEncode = /* @__PURE__ */ _safeEncode($ZodRealError);
  var _safeDecode = (_Err) => (schema, value, _ctx) => {
    return _safeParse(_Err)(schema, value, _ctx);
  };
  var safeDecode = /* @__PURE__ */ _safeDecode($ZodRealError);
  var _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
    const ctx = _ctx ? { ..._ctx, direction: "backward" } : { direction: "backward" };
    return _safeParseAsync(_Err)(schema, value, ctx);
  };
  var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync($ZodRealError);
  var _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
    return _safeParseAsync(_Err)(schema, value, _ctx);
  };
  var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync($ZodRealError);

  // ../../../node_modules/zod/v4/core/regexes.js
  var regexes_exports = {};
  __export(regexes_exports, {
    anyString: () => anyString,
    base64: () => base64,
    base64url: () => base64url,
    bigint: () => bigint,
    boolean: () => boolean,
    browserEmail: () => browserEmail,
    cidrv4: () => cidrv4,
    cidrv6: () => cidrv6,
    creditCard: () => creditCard,
    cuid: () => cuid,
    cuid2: () => cuid2,
    currencyCode: () => currencyCode,
    date: () => date,
    datetime: () => datetime,
    domain: () => domain,
    duration: () => duration,
    e164: () => e164,
    email: () => email,
    emoji: () => emoji,
    extendedDuration: () => extendedDuration,
    guid: () => guid,
    hex: () => hex,
    hostname: () => hostname,
    html5Email: () => html5Email,
    httpProtocol: () => httpProtocol,
    iban: () => iban,
    idnEmail: () => idnEmail,
    integer: () => integer,
    ipv4: () => ipv4,
    ipv6: () => ipv6,
    ksuid: () => ksuid,
    lowercase: () => lowercase,
    mac: () => mac,
    md5_base64: () => md5_base64,
    md5_base64url: () => md5_base64url,
    md5_hex: () => md5_hex,
    nanoid: () => nanoid,
    nanoidOfLength: () => nanoidOfLength,
    null: () => _null,
    number: () => number,
    rfc5322Email: () => rfc5322Email,
    sha1_base64: () => sha1_base64,
    sha1_base64url: () => sha1_base64url,
    sha1_hex: () => sha1_hex,
    sha256_base64: () => sha256_base64,
    sha256_base64url: () => sha256_base64url,
    sha256_hex: () => sha256_hex,
    sha384_base64: () => sha384_base64,
    sha384_base64url: () => sha384_base64url,
    sha384_hex: () => sha384_hex,
    sha512_base64: () => sha512_base64,
    sha512_base64url: () => sha512_base64url,
    sha512_hex: () => sha512_hex,
    string: () => string,
    time: () => time,
    ulid: () => ulid,
    undefined: () => _undefined,
    unicodeEmail: () => unicodeEmail,
    uppercase: () => uppercase,
    uuid: () => uuid,
    uuid4: () => uuid4,
    uuid6: () => uuid6,
    uuid7: () => uuid7,
    xid: () => xid
  });
  var cuid = /^[cC][0-9a-z]{6,}$/;
  var cuid2 = /^[0-9a-z]+$/;
  var ulid = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/;
  var xid = /^[0-9a-vA-V]{20}$/;
  var ksuid = /^[A-Za-z0-9]{27}$/;
  var nanoid = /^[a-zA-Z0-9_-]{21}$/;
  function nanoidOfLength(length) {
    return new RegExp(`^[a-zA-Z0-9_-]{${length}}$`);
  }
  var duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
  var extendedDuration = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
  var uuid = (version2) => {
    if (!version2)
      return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
    return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version2}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
  };
  var uuid4 = /* @__PURE__ */ uuid(4);
  var uuid6 = /* @__PURE__ */ uuid(6);
  var uuid7 = /* @__PURE__ */ uuid(7);
  var email = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
  var html5Email = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  var rfc5322Email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  var unicodeEmail = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u;
  var idnEmail = unicodeEmail;
  var browserEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  var _emoji = `^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$`;
  function emoji() {
    return new RegExp(_emoji, "u");
  }
  var ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
  var mac = (delimiter) => {
    const escapedDelim = escapeRegex(delimiter ?? ":");
    return new RegExp(`^(?:[0-9A-F]{2}${escapedDelim}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${escapedDelim}){5}[0-9a-f]{2}$`);
  };
  var cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
  var cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
  var base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
  var base64url = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/;
  var hostname = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/;
  var domain = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/;
  var httpProtocol = /^https?$/;
  var e164 = /^\+[1-9]\d{6,14}$/;
  var creditCard = /^\d(?:[ -]?\d){11,18}$/;
  var currencyCode = /^(?:AED|AFN|ALL|AMD|AOA|ARS|AUD|AWG|AZN|BAM|BBD|BDT|BHD|BIF|BMD|BND|BOB|BOV|BRL|BSD|BTN|BWP|BYN|BZD|CAD|CDF|CHE|CHF|CHW|CLF|CLP|CNY|COP|COU|CRC|CUP|CVE|CZK|DJF|DKK|DOP|DZD|EGP|ERN|ETB|EUR|FJD|FKP|GBP|GEL|GHS|GIP|GMD|GNF|GTQ|GYD|HKD|HNL|HTG|HUF|IDR|ILS|INR|IQD|IRR|ISK|JMD|JOD|JPY|KES|KGS|KHR|KMF|KPW|KRW|KWD|KYD|KZT|LAK|LBP|LKR|LRD|LSL|LYD|MAD|MDL|MGA|MKD|MMK|MNT|MOP|MRU|MUR|MVR|MWK|MXN|MXV|MYR|MZN|NAD|NGN|NIO|NOK|NPR|NZD|OMR|PAB|PEN|PGK|PHP|PKR|PLN|PYG|QAR|RON|RSD|RUB|RWF|SAR|SBD|SCR|SDG|SEK|SGD|SHP|SLE|SOS|SRD|SSP|STN|SVC|SYP|SZL|THB|TJS|TMT|TND|TOP|TRY|TTD|TWD|TZS|UAH|UGX|USD|USN|UYI|UYU|UYW|UZS|VED|VES|VND|VUV|WST|XAD|XAF|XAG|XAU|XBA|XBB|XBC|XBD|XCD|XCG|XDR|XOF|XPD|XPF|XPT|XSU|XTS|XUA|XXX|YER|ZAR|ZMW|ZWG)$/;
  var iban = /^[A-Z]{2}(?!00|01|99)\d{2}[A-Z0-9]{11,30}$/;
  var dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
  function anchor(source) {
    return new RegExp(`^${source}$`);
  }
  var date = /* @__PURE__ */ anchor(dateSource);
  function timeSource(args) {
    const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
    const regex = typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : args.seconds ? `${hhmm}:[0-5]\\d(?:\\.\\d+)?` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
    return regex;
  }
  function time(args) {
    return new RegExp(`^${timeSource(args)}$`);
  }
  function datetime(args) {
    const opts = ["Z"];
    if (args.offset)
      opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
    const qualified = `${timeSource({ precision: args.precision, seconds: true })}(?:${opts.join("|")})`;
    const timeRegex = args.local ? `${qualified}|${timeSource({ precision: args.precision })}` : qualified;
    return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
  }
  var anyString = /^[\s\S]{0,}$/;
  var string = (params) => {
    const regex = params ? `[\\s\\S]{${params?.minimum ?? 0},${params?.maximum ?? ""}}` : `[\\s\\S]*`;
    return new RegExp(`^${regex}$`);
  };
  var bigint = /^-?\d+n?$/;
  var integer = /^-?\d+$/;
  var number = /^-?\d+(?:\.\d+)?$/;
  var boolean = /^(?:true|false)$/i;
  var _null = /^null$/i;
  var _undefined = /^undefined$/i;
  var lowercase = /^[^A-Z]*$/;
  var uppercase = /^[^a-z]*$/;
  var hex = /^[0-9a-fA-F]*$/;
  function fixedBase64(bodyLength, padding) {
    return new RegExp(`^[A-Za-z0-9+/]{${bodyLength}}${padding}$`);
  }
  function fixedBase64url(length) {
    return new RegExp(`^[A-Za-z0-9_-]{${length}}$`);
  }
  var md5_hex = /^[0-9a-fA-F]{32}$/;
  var md5_base64 = /* @__PURE__ */ fixedBase64(22, "==");
  var md5_base64url = /* @__PURE__ */ fixedBase64url(22);
  var sha1_hex = /^[0-9a-fA-F]{40}$/;
  var sha1_base64 = /* @__PURE__ */ fixedBase64(27, "=");
  var sha1_base64url = /* @__PURE__ */ fixedBase64url(27);
  var sha256_hex = /^[0-9a-fA-F]{64}$/;
  var sha256_base64 = /* @__PURE__ */ fixedBase64(43, "=");
  var sha256_base64url = /* @__PURE__ */ fixedBase64url(43);
  var sha384_hex = /^[0-9a-fA-F]{96}$/;
  var sha384_base64 = /* @__PURE__ */ fixedBase64(64, "");
  var sha384_base64url = /* @__PURE__ */ fixedBase64url(64);
  var sha512_hex = /^[0-9a-fA-F]{128}$/;
  var sha512_base64 = /* @__PURE__ */ fixedBase64(86, "==");
  var sha512_base64url = /* @__PURE__ */ fixedBase64url(86);

  // ../../../node_modules/zod/v4/core/checks.js
  var $ZodCheck = /* @__PURE__ */ $constructor("$ZodCheck", (inst, def) => {
    var _a3;
    inst._zod ?? (inst._zod = {});
    inst._zod.def = def;
    (_a3 = inst._zod).onattach ?? (_a3.onattach = []);
  });
  var _whenHasSize = (payload) => {
    const val = payload.value;
    return !nullish(val) && val.size !== void 0;
  };
  var _whenHasLength = (payload) => {
    const val = payload.value;
    return !nullish(val) && val.length !== void 0;
  };
  var numericOriginMap = {
    number: "number",
    bigint: "bigint",
    object: "date"
  };
  var $ZodCheckLessThan = /* @__PURE__ */ $constructor("$ZodCheckLessThan", (inst, def) => {
    $ZodCheck.init(inst, def);
    const origin = numericOriginMap[typeof def.value];
    inst._zod.check = (payload) => {
      if (def.inclusive ? payload.value <= def.value : payload.value < def.value) {
        return;
      }
      payload.issues.push({
        origin: numericOriginMap[typeof payload.value] ?? origin,
        code: "too_big",
        maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
        input: payload.value,
        inclusive: def.inclusive,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckGreaterThan = /* @__PURE__ */ $constructor("$ZodCheckGreaterThan", (inst, def) => {
    $ZodCheck.init(inst, def);
    const origin = numericOriginMap[typeof def.value];
    inst._zod.check = (payload) => {
      if (def.inclusive ? payload.value >= def.value : payload.value > def.value) {
        return;
      }
      payload.issues.push({
        origin: numericOriginMap[typeof payload.value] ?? origin,
        code: "too_small",
        minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
        input: payload.value,
        inclusive: def.inclusive,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckMultipleOf = /* @__PURE__ */ $constructor("$ZodCheckMultipleOf", (inst, def) => {
    $ZodCheck.init(inst, def);
    inst._zod.check = (payload) => {
      if (typeof payload.value !== typeof def.value)
        throw new Error("Cannot mix number and bigint in multiple_of check.");
      const isMultiple = typeof payload.value === "bigint" ? (
        // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
        def.value !== BigInt(0) && payload.value % def.value === BigInt(0)
      ) : floatSafeRemainder(payload.value, def.value) === 0;
      if (isMultiple)
        return;
      payload.issues.push({
        origin: typeof payload.value,
        code: "not_multiple_of",
        divisor: def.value,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckNumberFormat = /* @__PURE__ */ $constructor("$ZodCheckNumberFormat", (inst, def) => {
    $ZodCheck.init(inst, def);
    def.format = def.format || "float64";
    const isInt = def.format?.includes("int");
    const origin = isInt ? "int" : "number";
    const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      if (isInt) {
        if (!Number.isInteger(input2)) {
          payload.issues.push({
            expected: origin,
            format: def.format,
            code: "invalid_type",
            continue: false,
            input: input2,
            inst
          });
          return;
        }
        if (!Number.isSafeInteger(input2)) {
          if (input2 > 0) {
            payload.issues.push({
              input: input2,
              code: "too_big",
              maximum: Number.MAX_SAFE_INTEGER,
              note: "Integers must be within the safe integer range.",
              inst,
              origin,
              inclusive: true,
              continue: !def.abort
            });
          } else {
            payload.issues.push({
              input: input2,
              code: "too_small",
              minimum: Number.MIN_SAFE_INTEGER,
              note: "Integers must be within the safe integer range.",
              inst,
              origin,
              inclusive: true,
              continue: !def.abort
            });
          }
          return;
        }
      }
      if (input2 < minimum) {
        payload.issues.push({
          origin: "number",
          input: input2,
          code: "too_small",
          minimum,
          inclusive: true,
          inst,
          continue: !def.abort
        });
      }
      if (input2 > maximum) {
        payload.issues.push({
          origin: "number",
          input: input2,
          code: "too_big",
          maximum,
          inclusive: true,
          inst,
          continue: !def.abort
        });
      }
    };
  });
  var $ZodCheckBigIntFormat = /* @__PURE__ */ $constructor("$ZodCheckBigIntFormat", (inst, def) => {
    $ZodCheck.init(inst, def);
    const [minimum, maximum] = BIGINT_FORMAT_RANGES[def.format];
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      if (input2 < minimum) {
        payload.issues.push({
          origin: "bigint",
          input: input2,
          code: "too_small",
          minimum,
          inclusive: true,
          inst,
          continue: !def.abort
        });
      }
      if (input2 > maximum) {
        payload.issues.push({
          origin: "bigint",
          input: input2,
          code: "too_big",
          maximum,
          inclusive: true,
          inst,
          continue: !def.abort
        });
      }
    };
  });
  var $ZodCheckMaxSize = /* @__PURE__ */ $constructor("$ZodCheckMaxSize", (inst, def) => {
    var _a3;
    $ZodCheck.init(inst, def);
    (_a3 = inst._zod.def).when ?? (_a3.when = _whenHasSize);
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const size = input2.size;
      if (size <= def.maximum)
        return;
      payload.issues.push({
        origin: getSizableOrigin(input2),
        code: "too_big",
        maximum: def.maximum,
        inclusive: true,
        input: input2,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckMinSize = /* @__PURE__ */ $constructor("$ZodCheckMinSize", (inst, def) => {
    var _a3;
    $ZodCheck.init(inst, def);
    (_a3 = inst._zod.def).when ?? (_a3.when = _whenHasSize);
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const size = input2.size;
      if (size >= def.minimum)
        return;
      payload.issues.push({
        origin: getSizableOrigin(input2),
        code: "too_small",
        minimum: def.minimum,
        inclusive: true,
        input: input2,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckSizeEquals = /* @__PURE__ */ $constructor("$ZodCheckSizeEquals", (inst, def) => {
    var _a3;
    $ZodCheck.init(inst, def);
    (_a3 = inst._zod.def).when ?? (_a3.when = _whenHasSize);
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const size = input2.size;
      if (size === def.size)
        return;
      const tooBig = size > def.size;
      payload.issues.push({
        origin: getSizableOrigin(input2),
        ...tooBig ? { code: "too_big", maximum: def.size } : { code: "too_small", minimum: def.size },
        inclusive: true,
        exact: true,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckMaxLength = /* @__PURE__ */ $constructor("$ZodCheckMaxLength", (inst, def) => {
    var _a3;
    $ZodCheck.init(inst, def);
    (_a3 = inst._zod.def).when ?? (_a3.when = _whenHasLength);
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const units = input2.length;
      const length = typeof input2 === "string" && units > def.maximum ? codePointLength(input2) : units;
      if (length <= def.maximum)
        return;
      const origin = getLengthableOrigin(input2);
      payload.issues.push({
        origin,
        code: "too_big",
        maximum: def.maximum,
        inclusive: true,
        input: input2,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckMinLength = /* @__PURE__ */ $constructor("$ZodCheckMinLength", (inst, def) => {
    var _a3;
    $ZodCheck.init(inst, def);
    (_a3 = inst._zod.def).when ?? (_a3.when = _whenHasLength);
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const units = input2.length;
      const length = typeof input2 === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input2) : units;
      if (length >= def.minimum)
        return;
      const origin = getLengthableOrigin(input2);
      payload.issues.push({
        origin,
        code: "too_small",
        minimum: def.minimum,
        inclusive: true,
        input: input2,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckLengthEquals = /* @__PURE__ */ $constructor("$ZodCheckLengthEquals", (inst, def) => {
    var _a3;
    $ZodCheck.init(inst, def);
    (_a3 = inst._zod.def).when ?? (_a3.when = _whenHasLength);
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const units = input2.length;
      const length = typeof input2 === "string" && units >= def.length && units <= def.length * 2 ? codePointLength(input2) : units;
      if (length === def.length)
        return;
      const origin = getLengthableOrigin(input2);
      const tooBig = length > def.length;
      payload.issues.push({
        origin,
        ...tooBig ? { code: "too_big", maximum: def.length } : { code: "too_small", minimum: def.length },
        inclusive: true,
        exact: true,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckStringFormat = /* @__PURE__ */ $constructor("$ZodCheckStringFormat", (inst, def) => {
    var _a3, _b;
    $ZodCheck.init(inst, def);
    if (def.pattern)
      (_a3 = inst._zod).check ?? (_a3.check = (payload) => {
        def.pattern.lastIndex = 0;
        if (def.pattern.test(payload.value))
          return;
        payload.issues.push({
          origin: "string",
          code: "invalid_format",
          format: def.format,
          input: payload.value,
          ...def.pattern ? { pattern: def.pattern.toString() } : {},
          inst,
          continue: !def.abort
        });
      });
    else
      (_b = inst._zod).check ?? (_b.check = () => {
      });
  });
  var $ZodCheckRegex = /* @__PURE__ */ $constructor("$ZodCheckRegex", (inst, def) => {
    $ZodCheckStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      def.pattern.lastIndex = 0;
      if (def.pattern.test(payload.value))
        return;
      payload.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "regex",
        input: payload.value,
        pattern: def.pattern.toString(),
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckLowerCase = /* @__PURE__ */ $constructor("$ZodCheckLowerCase", (inst, def) => {
    def.pattern ?? (def.pattern = lowercase);
    $ZodCheckStringFormat.init(inst, def);
  });
  var $ZodCheckUpperCase = /* @__PURE__ */ $constructor("$ZodCheckUpperCase", (inst, def) => {
    def.pattern ?? (def.pattern = uppercase);
    $ZodCheckStringFormat.init(inst, def);
  });
  var $ZodCheckIncludes = /* @__PURE__ */ $constructor("$ZodCheckIncludes", (inst, def) => {
    $ZodCheck.init(inst, def);
    const escapedRegex = escapeRegex(def.includes);
    const pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position},}${escapedRegex}` : escapedRegex);
    def.pattern = pattern;
    inst._zod.check = (payload) => {
      if (payload.value.includes(def.includes, def.position))
        return;
      payload.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "includes",
        includes: def.includes,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckStartsWith = /* @__PURE__ */ $constructor("$ZodCheckStartsWith", (inst, def) => {
    $ZodCheck.init(inst, def);
    const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
    def.pattern ?? (def.pattern = pattern);
    inst._zod.check = (payload) => {
      if (payload.value.startsWith(def.prefix))
        return;
      payload.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "starts_with",
        prefix: def.prefix,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckEndsWith = /* @__PURE__ */ $constructor("$ZodCheckEndsWith", (inst, def) => {
    $ZodCheck.init(inst, def);
    const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
    def.pattern ?? (def.pattern = pattern);
    inst._zod.check = (payload) => {
      if (payload.value.endsWith(def.suffix))
        return;
      payload.issues.push({
        origin: "string",
        code: "invalid_format",
        format: "ends_with",
        suffix: def.suffix,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  function handleCheckPropertyResult(result, payload, property) {
    if (result.issues.length) {
      payload.issues.push(...prefixIssues(property, result.issues));
    }
  }
  var $ZodCheckProperty = /* @__PURE__ */ $constructor("$ZodCheckProperty", (inst, def) => {
    $ZodCheck.init(inst, def);
    inst._zod.check = (payload) => {
      const result = def.schema._zod.run({
        value: payload.value[def.property],
        issues: []
      }, {});
      if (result instanceof Promise) {
        return result.then((result2) => handleCheckPropertyResult(result2, payload, def.property));
      }
      handleCheckPropertyResult(result, payload, def.property);
      return;
    };
  });
  var $ZodCheckProperties = /* @__PURE__ */ $constructor("$ZodCheckProperties", (inst, def) => {
    $ZodCheck.init(inst, def);
    hide(inst, Symbol.iterator, function* () {
      yield inst;
    });
    let entries;
    inst._zod.check = (payload) => {
      if (payload.value == null) {
        payload.issues.push({ expected: "object", code: "invalid_type", input: payload.value, inst });
        return void 0;
      }
      entries ?? (entries = Reflect.ownKeys(def.shape).map((key6) => [key6, def.shape[key6]]));
      const input2 = payload.value;
      let proms;
      for (const [key6, schema] of entries) {
        const result = schema._zod.run({ value: input2[key6], issues: [] }, {});
        if (result instanceof Promise) {
          proms ?? (proms = []);
          proms.push(result.then((result2) => handleCheckPropertyResult(result2, payload, key6)));
        } else {
          handleCheckPropertyResult(result, payload, key6);
        }
      }
      if (proms)
        return Promise.all(proms).then(() => void 0);
      return void 0;
    };
  });
  var $ZodCheckMimeType = /* @__PURE__ */ $constructor("$ZodCheckMimeType", (inst, def) => {
    $ZodCheck.init(inst, def);
    const mimeSet = new Set(def.mime);
    inst._zod.check = (payload) => {
      if (mimeSet.has(payload.value.type))
        return;
      payload.issues.push({
        code: "invalid_value",
        values: def.mime,
        input: payload.value.type,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCheckOverwrite = /* @__PURE__ */ $constructor("$ZodCheckOverwrite", (inst, def) => {
    $ZodCheck.init(inst, def);
    inst._zod.check = (payload) => {
      payload.value = def.tx(payload.value);
    };
  });

  // ../../../node_modules/zod/v4/core/doc.js
  var Doc = class {
    constructor(args = [], closed = {}) {
      this.content = [];
      this.indent = 0;
      this.args = args;
      this.closed = closed;
    }
    // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
    indented(fn) {
      this.indent += 1;
      try {
        fn(this);
      } finally {
        this.indent -= 1;
      }
    }
    write(arg) {
      if (typeof arg === "function") {
        arg(this, { execution: "sync" });
        arg(this, { execution: "async" });
        return;
      }
      const content = arg;
      const lines = content.split("\n").filter((x) => x);
      const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
      const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
      for (const line of dedented) {
        this.content.push(line);
      }
    }
    compile() {
      const F = Function;
      const content = this?.content ?? [``];
      const factory = new F(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${content.join("\n")}
};`);
      return factory(...Object.values(this.closed));
    }
  };

  // ../../../node_modules/zod/v4/core/versions.js
  var version = {
    major: 4,
    minor: 6,
    patch: 7
  };

  // ../../../node_modules/zod/v4/core/schemas.js
  var $ZodType = /* @__PURE__ */ $constructor("$ZodType", (inst, def) => {
    var _a3;
    inst ?? (inst = {});
    inst._zod.def = def;
    inst._zod.bag = inst._zod.bag || {};
    inst._zod.version = version;
    const defChecks = inst._zod.def.checks;
    const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
    for (const ch of checks) {
      for (const fn of ch._zod.onattach) {
        fn(inst);
      }
    }
    if (checks.length === 0) {
      (_a3 = inst._zod).deferred ?? (_a3.deferred = []);
      inst._zod.deferred?.push(() => {
        inst._zod.run = inst._zod.parse;
      });
    } else {
      const runChecks = (payload, checks2, ctx) => {
        if (payload.memo)
          return payload;
        let isAborted = aborted(payload);
        let asyncResult;
        for (const ch of checks2) {
          if (ch._zod.def.when) {
            if (explicitlyAborted(payload))
              continue;
            const shouldRun = ch._zod.def.when(payload);
            if (!shouldRun)
              continue;
          } else if (isAborted) {
            continue;
          }
          const currLen = payload.issues.length;
          const _ = ch._zod.check(payload);
          if (_ instanceof Promise && ctx?.async === false) {
            throw new $ZodAsyncError();
          }
          if (asyncResult || _ instanceof Promise) {
            asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
              await _;
              const nextLen = payload.issues.length;
              if (nextLen === currLen)
                return;
              attachSchema(payload.issues, currLen, inst);
              if (!isAborted)
                isAborted = aborted(payload, currLen);
            });
          } else {
            const nextLen = payload.issues.length;
            if (nextLen === currLen)
              continue;
            attachSchema(payload.issues, currLen, inst);
            if (!isAborted)
              isAborted = aborted(payload, currLen);
          }
        }
        if (asyncResult) {
          return asyncResult.then(() => {
            return payload;
          });
        }
        return payload;
      };
      const handleCanaryResult = (canary, payload, ctx) => {
        if (aborted(canary)) {
          canary.aborted = true;
          return canary;
        }
        const checkResult = runChecks(payload, checks, ctx);
        if (checkResult instanceof Promise) {
          if (ctx.async === false)
            throw new $ZodAsyncError();
          return checkResult.then((checkResult2) => inst._zod.parse(checkResult2, ctx));
        }
        return inst._zod.parse(checkResult, ctx);
      };
      inst._zod.run = (payload, ctx) => {
        if (ctx.skipChecks) {
          return inst._zod.parse(payload, ctx);
        }
        if (ctx.direction === "backward") {
          const canary = inst._zod.parse({ value: payload.value, issues: [] }, { ...ctx, skipChecks: true });
          if (canary instanceof Promise) {
            return canary.then((canary2) => {
              return handleCanaryResult(canary2, payload, ctx);
            });
          }
          return handleCanaryResult(canary, payload, ctx);
        }
        const result = inst._zod.parse(payload, ctx);
        if (result instanceof Promise) {
          if (ctx.async === false)
            throw new $ZodAsyncError();
          return result.then((result2) => runChecks(result2, checks, ctx));
        }
        return runChecks(result, checks, ctx);
      };
    }
  }, {
    // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
    get "~standard"() {
      return hide(this, "~standard", standardProps(this));
    },
    set "~standard"(value) {
      own(this, "~standard", value);
    }
  });
  var toStandardResult = (r, ctx) => r.issues.length ? { issues: r.issues.map((iss) => finalizeIssue(iss, ctx, config())) } : { value: r.value };
  async function validateAsync2(inst, value) {
    const ctx = { async: true };
    return toStandardResult(await inst._zod.run({ value, issues: [] }, ctx), ctx);
  }
  function standardProps(inst) {
    return {
      validate: (value) => {
        const ctx = { async: false };
        try {
          const r = inst._zod.run({ value, issues: [] }, ctx);
          if (!(r instanceof Promise))
            return toStandardResult(r, ctx);
        } catch (_) {
        }
        return validateAsync2(inst, value);
      },
      vendor: "zod",
      version: 1
    };
  }
  var $ZodString = /* @__PURE__ */ $constructor("$ZodString", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.pattern = def.pattern ?? anyString;
    inst._zod.parse = (payload, _) => {
      if (def.coerce)
        try {
          payload.value = String(payload.value);
        } catch (_2) {
        }
      if (typeof payload.value === "string")
        return payload;
      payload.issues.push({
        expected: "string",
        code: "invalid_type",
        input: payload.value,
        inst
      });
      return payload;
    };
  });
  var $ZodStringFormat = /* @__PURE__ */ $constructor("$ZodStringFormat", (inst, def) => {
    $ZodCheckStringFormat.init(inst, def);
    $ZodString.init(inst, def);
  });
  var $ZodGUID = /* @__PURE__ */ $constructor("$ZodGUID", (inst, def) => {
    def.pattern ?? (def.pattern = guid);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodUUID = /* @__PURE__ */ $constructor("$ZodUUID", (inst, def) => {
    if (def.version) {
      const versionMap = {
        v1: 1,
        v2: 2,
        v3: 3,
        v4: 4,
        v5: 5,
        v6: 6,
        v7: 7,
        v8: 8
      };
      const v = versionMap[def.version];
      if (v === void 0)
        throw new Error(`Invalid UUID version: "${def.version}"`);
      def.pattern ?? (def.pattern = uuid(v));
    } else
      def.pattern ?? (def.pattern = uuid());
    $ZodStringFormat.init(inst, def);
  });
  var $ZodEmail = /* @__PURE__ */ $constructor("$ZodEmail", (inst, def) => {
    def.pattern ?? (def.pattern = email);
    $ZodStringFormat.init(inst, def);
  });
  var URL_BAD_FORMAT = 1;
  var URL_UNPARSEABLE = 2;
  function canParseURL(input2) {
    try {
      if (typeof URL !== "undefined" && typeof URL.canParse === "function")
        return URL.canParse(input2);
      new URL(input2);
      return true;
    } catch {
      return false;
    }
  }
  function validateURL(trimmed, def) {
    if (!("normalize" in def) && !("hostname" in def) && !("protocol" in def)) {
      return canParseURL(trimmed) || URL_UNPARSEABLE;
    }
    return parseURLObject(trimmed, def);
  }
  function parseURLObject(trimmed, def) {
    if (!def.normalize && def.protocol?.source === httpProtocol.source && !/^https?:\/\//i.test(trimmed)) {
      return URL_BAD_FORMAT;
    }
    try {
      if (typeof URL !== "undefined") {
        const URLStatic = URL;
        if (typeof URLStatic.parse === "function")
          return URLStatic.parse(trimmed) ?? URL_UNPARSEABLE;
      }
      return new URL(trimmed);
    } catch {
      return URL_UNPARSEABLE;
    }
  }
  var asciiTabOrNewline = /[\t\n\r]/g;
  function stripTabAndNewline(value) {
    return value.replace(asciiTabOrNewline, "");
  }
  function urlHostnameOk(url2, hostname3) {
    hostname3.lastIndex = 0;
    return hostname3.test(url2.hostname);
  }
  function urlProtocolOk(url2, protocol) {
    protocol.lastIndex = 0;
    return protocol.test(url2.protocol.endsWith(":") ? url2.protocol.slice(0, -1) : url2.protocol);
  }
  var $ZodURL = /* @__PURE__ */ $constructor("$ZodURL", (inst, def) => {
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      try {
        const trimmed = payload.value.trim();
        const url2 = validateURL(trimmed, def);
        if (url2 === URL_BAD_FORMAT) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid URL format",
            input: payload.value,
            inst,
            continue: !def.abort
          });
          return;
        }
        if (url2 === URL_UNPARSEABLE) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            input: payload.value,
            inst,
            continue: !def.abort
          });
          return;
        }
        if (url2 === true) {
          payload.value = stripTabAndNewline(trimmed);
          return;
        }
        if (def.hostname && !urlHostnameOk(url2, def.hostname)) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid hostname",
            pattern: def.hostname.source,
            input: payload.value,
            inst,
            continue: !def.abort
          });
        }
        if (def.protocol && !urlProtocolOk(url2, def.protocol)) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid protocol",
            pattern: def.protocol.source,
            input: payload.value,
            inst,
            continue: !def.abort
          });
        }
        payload.value = def.normalize ? url2.href : stripTabAndNewline(trimmed);
        return;
      } catch (_) {
        payload.issues.push({
          code: "invalid_format",
          format: "url",
          input: payload.value,
          inst,
          continue: !def.abort
        });
      }
    };
  });
  var $ZodEmoji = /* @__PURE__ */ $constructor("$ZodEmoji", (inst, def) => {
    def.pattern ?? (def.pattern = emoji());
    $ZodStringFormat.init(inst, def);
  });
  var $ZodNanoID = /* @__PURE__ */ $constructor("$ZodNanoID", (inst, def) => {
    if (def.length !== void 0 && (!Number.isInteger(def.length) || def.length < 1))
      throw new Error(`Invalid nanoid length: ${def.length}`);
    def.pattern ?? (def.pattern = def.length === void 0 ? nanoid : nanoidOfLength(def.length));
    $ZodStringFormat.init(inst, def);
  });
  var $ZodCUID = /* @__PURE__ */ $constructor("$ZodCUID", (inst, def) => {
    def.pattern ?? (def.pattern = cuid);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodCUID2 = /* @__PURE__ */ $constructor("$ZodCUID2", (inst, def) => {
    def.pattern ?? (def.pattern = cuid2);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodULID = /* @__PURE__ */ $constructor("$ZodULID", (inst, def) => {
    def.pattern ?? (def.pattern = ulid);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodXID = /* @__PURE__ */ $constructor("$ZodXID", (inst, def) => {
    def.pattern ?? (def.pattern = xid);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodKSUID = /* @__PURE__ */ $constructor("$ZodKSUID", (inst, def) => {
    def.pattern ?? (def.pattern = ksuid);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodISODateTime = /* @__PURE__ */ $constructor("$ZodISODateTime", (inst, def) => {
    def.pattern ?? (def.pattern = datetime(def));
    $ZodStringFormat.init(inst, def);
  });
  var $ZodISODate = /* @__PURE__ */ $constructor("$ZodISODate", (inst, def) => {
    def.pattern ?? (def.pattern = date);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodISOTime = /* @__PURE__ */ $constructor("$ZodISOTime", (inst, def) => {
    def.pattern ?? (def.pattern = time(def));
    $ZodStringFormat.init(inst, def);
  });
  var $ZodISODuration = /* @__PURE__ */ $constructor("$ZodISODuration", (inst, def) => {
    def.pattern ?? (def.pattern = duration);
    $ZodStringFormat.init(inst, def);
  });
  var $ZodIPv4 = /* @__PURE__ */ $constructor("$ZodIPv4", (inst, def) => {
    def.pattern ?? (def.pattern = ipv4);
    $ZodStringFormat.init(inst, def);
  });
  var ipv6Alphabet = /^[0-9a-fA-F:.]+$/;
  function isValidIPv6(value) {
    if (!ipv6Alphabet.test(value))
      return false;
    return canParseURL(`http://[${value}]`);
  }
  var $ZodIPv6 = /* @__PURE__ */ $constructor("$ZodIPv6", (inst, def) => {
    def.pattern ?? (def.pattern = ipv6);
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (!isValidIPv6(payload.value)) {
        payload.issues.push({
          code: "invalid_format",
          format: "ipv6",
          input: payload.value,
          inst,
          continue: !def.abort
        });
      }
    };
  });
  var $ZodMAC = /* @__PURE__ */ $constructor("$ZodMAC", (inst, def) => {
    def.pattern ?? (def.pattern = mac(def.delimiter));
    $ZodStringFormat.init(inst, def);
  });
  var $ZodCIDRv4 = /* @__PURE__ */ $constructor("$ZodCIDRv4", (inst, def) => {
    def.pattern ?? (def.pattern = cidrv4);
    $ZodStringFormat.init(inst, def);
  });
  function isValidCIDRv6(value) {
    const parts = value.split("/");
    if (parts.length !== 2)
      return false;
    const [address, prefix] = parts;
    if (!prefix)
      return false;
    const prefixNum = Number(prefix);
    if (`${prefixNum}` !== prefix)
      return false;
    if (prefixNum < 0 || prefixNum > 128)
      return false;
    return isValidIPv6(address);
  }
  var $ZodCIDRv6 = /* @__PURE__ */ $constructor("$ZodCIDRv6", (inst, def) => {
    def.pattern ?? (def.pattern = cidrv6);
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (!isValidCIDRv6(payload.value)) {
        payload.issues.push({
          code: "invalid_format",
          format: "cidrv6",
          input: payload.value,
          inst,
          continue: !def.abort
        });
      }
    };
  });
  function isValidBase64(data) {
    if (data === "")
      return true;
    if (/\s/.test(data))
      return false;
    if (data.length % 4 !== 0)
      return false;
    try {
      atob(data);
      return true;
    } catch {
      return false;
    }
  }
  var base64Charset = /^[0-9a-zA-Z+/]*={0,2}$/;
  var $ZodBase64 = /* @__PURE__ */ $constructor("$ZodBase64", (inst, def) => {
    def.pattern ?? (def.pattern = base64Charset);
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (isValidBase64(payload.value))
        return;
      payload.issues.push({
        code: "invalid_format",
        format: "base64",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var base64urlCharset = /^[A-Za-z0-9_-]*$/;
  function isValidBase64URL(data) {
    if (!base64urlCharset.test(data))
      return false;
    const base643 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
    const padded = base643.padEnd(Math.ceil(base643.length / 4) * 4, "=");
    return isValidBase64(padded);
  }
  var $ZodBase64URL = /* @__PURE__ */ $constructor("$ZodBase64URL", (inst, def) => {
    def.pattern ?? (def.pattern = base64urlCharset);
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (isValidBase64URL(payload.value))
        return;
      payload.issues.push({
        code: "invalid_format",
        format: "base64url",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodE164 = /* @__PURE__ */ $constructor("$ZodE164", (inst, def) => {
    def.pattern ?? (def.pattern = e164);
    $ZodStringFormat.init(inst, def);
  });
  var CC_SANITIZE = /[- ]/g;
  function isLuhnAlgo(digits) {
    let length = digits.length;
    let bit = 1;
    let sum = 0;
    while (length) {
      const value = digits.charCodeAt(--length) - 48;
      bit ^= 1;
      sum += bit ? [0, 2, 4, 6, 8, 1, 3, 5, 7, 9][value] : value;
    }
    return sum % 10 === 0;
  }
  function isValidCreditCard(input2) {
    if (!creditCard.test(input2))
      return false;
    return isLuhnAlgo(input2.replace(CC_SANITIZE, ""));
  }
  var $ZodCreditCard = /* @__PURE__ */ $constructor("$ZodCreditCard", (inst, def) => {
    def.pattern ?? (def.pattern = creditCard);
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (isValidCreditCard(payload.value))
        return;
      payload.issues.push({
        code: "invalid_format",
        format: "credit_card",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  function isIso7064Mod97(iban3) {
    let remainder = 0;
    const len = iban3.length;
    for (let i = 4; i < len; i++) {
      const code = iban3.charCodeAt(i);
      remainder = (code >= 65 ? remainder * 100 + (code - 55) : remainder * 10 + (code - 48)) % 97;
    }
    for (let i = 0; i < 4; i++) {
      const code = iban3.charCodeAt(i);
      remainder = (code >= 65 ? remainder * 100 + (code - 55) : remainder * 10 + (code - 48)) % 97;
    }
    return remainder === 1;
  }
  function isValidIBAN(input2) {
    if (!iban.test(input2))
      return false;
    return isIso7064Mod97(input2);
  }
  var $ZodIBAN = /* @__PURE__ */ $constructor("$ZodIBAN", (inst, def) => {
    def.pattern ?? (def.pattern = iban);
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (isValidIBAN(payload.value))
        return;
      payload.issues.push({
        code: "invalid_format",
        format: "iban",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  function isValidJWT(token, algorithm = null) {
    try {
      const tokensParts = token.split(".");
      if (tokensParts.length !== 3)
        return false;
      const [header] = tokensParts;
      if (!header)
        return false;
      const parsedHeader = JSON.parse(atob(header));
      if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT")
        return false;
      if (!parsedHeader.alg)
        return false;
      if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm))
        return false;
      return true;
    } catch {
      return false;
    }
  }
  var $ZodJWT = /* @__PURE__ */ $constructor("$ZodJWT", (inst, def) => {
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (isValidJWT(payload.value, def.alg))
        return;
      payload.issues.push({
        code: "invalid_format",
        format: "jwt",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodCustomStringFormat = /* @__PURE__ */ $constructor("$ZodCustomStringFormat", (inst, def) => {
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload) => {
      if (def.fn(payload.value))
        return;
      payload.issues.push({
        code: "invalid_format",
        format: def.format,
        input: payload.value,
        inst,
        continue: !def.abort
      });
    };
  });
  var $ZodNumber = /* @__PURE__ */ $constructor("$ZodNumber", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.pattern = number;
    inst._zod.parse = (payload, _ctx) => {
      if (def.coerce)
        try {
          payload.value = Number(payload.value);
        } catch (_) {
        }
      const input2 = payload.value;
      if (typeof input2 === "number" && !Number.isNaN(input2) && Number.isFinite(input2)) {
        return payload;
      }
      const received = typeof input2 === "number" ? Number.isNaN(input2) ? "NaN" : !Number.isFinite(input2) ? String(input2) : void 0 : void 0;
      payload.issues.push({
        expected: "number",
        code: "invalid_type",
        input: input2,
        inst,
        ...received ? { received } : {}
      });
      return payload;
    };
  });
  var $ZodNumberFormat = /* @__PURE__ */ $constructor("$ZodNumberFormat", (inst, def) => {
    $ZodCheckNumberFormat.init(inst, def);
    $ZodNumber.init(inst, def);
  });
  var $ZodBoolean = /* @__PURE__ */ $constructor("$ZodBoolean", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.pattern = boolean;
    inst._zod.parse = (payload, _ctx) => {
      if (def.coerce)
        try {
          payload.value = Boolean(payload.value);
        } catch (_) {
        }
      const input2 = payload.value;
      if (typeof input2 === "boolean")
        return payload;
      payload.issues.push({
        expected: "boolean",
        code: "invalid_type",
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodBigInt = /* @__PURE__ */ $constructor("$ZodBigInt", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.pattern = bigint;
    inst._zod.parse = (payload, _ctx) => {
      if (def.coerce)
        try {
          payload.value = BigInt(payload.value);
        } catch (_) {
        }
      if (typeof payload.value === "bigint")
        return payload;
      payload.issues.push({
        expected: "bigint",
        code: "invalid_type",
        input: payload.value,
        inst
      });
      return payload;
    };
  });
  var $ZodBigIntFormat = /* @__PURE__ */ $constructor("$ZodBigIntFormat", (inst, def) => {
    $ZodCheckBigIntFormat.init(inst, def);
    $ZodBigInt.init(inst, def);
  });
  var $ZodSymbol = /* @__PURE__ */ $constructor("$ZodSymbol", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (typeof input2 === "symbol")
        return payload;
      payload.issues.push({
        expected: "symbol",
        code: "invalid_type",
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodUndefined = /* @__PURE__ */ $constructor("$ZodUndefined", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.pattern = _undefined;
    inst._zod.values = /* @__PURE__ */ new Set([void 0]);
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (typeof input2 === "undefined")
        return payload;
      payload.issues.push({
        expected: "undefined",
        code: "invalid_type",
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodNull = /* @__PURE__ */ $constructor("$ZodNull", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.pattern = _null;
    inst._zod.values = /* @__PURE__ */ new Set([null]);
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (input2 === null)
        return payload;
      payload.issues.push({
        expected: "null",
        code: "invalid_type",
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodAny = /* @__PURE__ */ $constructor("$ZodAny", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload) => payload;
  });
  var $ZodUnknown = /* @__PURE__ */ $constructor("$ZodUnknown", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload) => payload;
  });
  var $ZodNever = /* @__PURE__ */ $constructor("$ZodNever", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx) => {
      payload.issues.push({
        expected: "never",
        code: "invalid_type",
        input: payload.value,
        inst
      });
      return payload;
    };
  });
  var $ZodVoid = /* @__PURE__ */ $constructor("$ZodVoid", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (typeof input2 === "undefined")
        return payload;
      payload.issues.push({
        expected: "void",
        code: "invalid_type",
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodDate = /* @__PURE__ */ $constructor("$ZodDate", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx) => {
      if (def.coerce) {
        try {
          payload.value = new Date(payload.value);
        } catch (_err) {
        }
      }
      const input2 = payload.value;
      const isDate = input2 instanceof Date;
      const isValidDate = isDate && !Number.isNaN(input2.getTime());
      if (isValidDate)
        return payload;
      payload.issues.push({
        expected: "date",
        code: "invalid_type",
        input: input2,
        ...isDate ? { received: "Invalid Date" } : {},
        inst
      });
      return payload;
    };
  });
  function capSize(inst, size) {
    const caps = sizeCaps(inst._zod.def.checks);
    if (!caps.length)
      return;
    const cap = Math.min(...caps.map((c) => c[0]));
    const parse3 = inst._zod.parse;
    inst._zod.parse = (payload, ctx) => {
      const n = size(payload.value);
      if (n > cap && !ctx?.skipChecks && ctx?.direction !== "backward") {
        for (const [max, ch] of sizeCaps(inst._zod.def.checks)) {
          if (n > max && ch._zod.def.when(payload)) {
            const start = payload.issues.length;
            ch._zod.check(payload);
            payload.issues[start].continue = false;
            attachSchema(payload.issues, start, inst);
            return payload;
          }
        }
      }
      return parse3(payload, ctx);
    };
  }
  var arraySize = (input2) => Array.isArray(input2) ? input2.length : -1;
  var mapSize = (input2) => input2 instanceof Map ? input2.size : -1;
  var setSize = (input2) => input2 instanceof Set ? input2.size : -1;
  function handleArrayResult(result, final, index) {
    if (result.issues.length) {
      final.issues.push(...prefixIssues(index, result.issues));
    }
    final.value[index] = result.value;
  }
  var $ZodArray = /* @__PURE__ */ $constructor("$ZodArray", (inst, def) => {
    $ZodType.init(inst, def);
    const memo2 = globalConfig.memoizer;
    memo2?.attach(inst);
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      if (!Array.isArray(input2)) {
        payload.issues.push({
          expected: "array",
          code: "invalid_type",
          input: input2,
          inst
        });
        return payload;
      }
      payload.value = memo2 ? memo2.alloc(inst, payload, Array(input2.length), ctx) : Array(input2.length);
      const proms = [];
      const abortEarly = ctx?.abortEarly;
      for (let i = 0; i < input2.length; i++) {
        const item = input2[i];
        const result = def.element._zod.run({
          value: item,
          issues: []
        }, ctx);
        if (result instanceof Promise) {
          proms.push(result.then((result2) => handleArrayResult(result2, payload, i)));
        } else {
          handleArrayResult(result, payload, i);
          if (abortEarly && result.issues.length !== 0 && aborted(result))
            break;
        }
      }
      if (proms.length) {
        return Promise.all(proms).then(() => payload);
      }
      return payload;
    };
    capSize(inst, arraySize);
  });
  function handlePropertyResult(result, final, key6, input2, optin, optout) {
    const isPresent = key6 in input2;
    const isOptionalOut = optout === "optional";
    if (!isPresent && isOptionalOut && optin === "optional") {
      return;
    }
    if (result.issues.length) {
      if (optin !== void 0 && isOptionalOut && !isPresent) {
        return;
      }
      final.issues.push(...prefixIssues(key6, result.issues));
    }
    if (!isPresent && optin === void 0) {
      if (!result.issues.length) {
        final.issues.push({
          code: "invalid_type",
          expected: "nonoptional",
          input: void 0,
          path: [key6]
        });
      }
      return;
    }
    if (result.value === void 0) {
      if (isPresent || optin === "defaulted" && !isOptionalOut) {
        final.value[key6] = void 0;
      }
    } else {
      final.value[key6] = result.value;
    }
  }
  var NO_SYMBOL_KEYS = [];
  function normalizeDef(def) {
    const keys = Object.keys(def.shape);
    const ownSymbols = Object.getOwnPropertySymbols(def.shape);
    const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
    const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
    for (const k of allKeys) {
      if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) {
        throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
      }
    }
    const okeys = optionalKeys(def.shape);
    return {
      ...def,
      allKeys,
      symbolKeys,
      // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
      keySet: new Set(keys),
      numKeys: keys.length,
      optionalKeys: new Set(okeys)
    };
  }
  function handleCatchall(proms, input2, payload, ctx, def, inst, abortEarly) {
    const unrecognized = [];
    const keySet = def.keySet;
    const _catchall = def.catchall._zod;
    const t = _catchall.def.type;
    const optin = _catchall.optin;
    const optout = _catchall.optout;
    let seen = 0;
    for (const key6 in input2) {
      if (abortEarly && payload.issues.length !== seen) {
        if (aborted(payload, seen))
          break;
        seen = payload.issues.length;
      }
      if (keySet.has(key6))
        continue;
      if (key6 === "__proto__") {
        if (t === "never")
          unrecognized.push(key6);
        continue;
      }
      if (t === "never") {
        unrecognized.push(key6);
        continue;
      }
      const r = _catchall.run({ value: input2[key6], issues: [] }, ctx);
      if (r instanceof Promise) {
        proms.push(r.then((r2) => handlePropertyResult(r2, payload, key6, input2, optin, optout)));
      } else {
        handlePropertyResult(r, payload, key6, input2, optin, optout);
      }
    }
    if (unrecognized.length) {
      payload.issues.push({
        code: "unrecognized_keys",
        keys: unrecognized,
        input: input2,
        inst,
        // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
        continue: true
      });
    }
    if (!proms.length)
      return payload;
    return Promise.all(proms).then(() => {
      return payload;
    });
  }
  var $ZodObject = /* @__PURE__ */ $constructor("$ZodObject", (inst, def) => {
    $ZodType.init(inst, def);
    const desc = Object.getOwnPropertyDescriptor(def, "shape");
    const sh = desc?.get ? desc.get.raw : def.shape ?? {};
    if (sh) {
      const get = () => {
        const newSh = { ...sh };
        Object.defineProperty(def, "shape", { value: newSh });
        get.raw = newSh;
        return newSh;
      };
      get.raw = sh;
      Object.defineProperty(def, "shape", { get });
    }
    const _normalized = cached(() => normalizeDef(def));
    defineLazyInternal(inst, "propValues", (zod) => {
      const shape = zod.def.shape;
      const propValues = {};
      for (const key6 in shape) {
        const field = shape[key6]._zod;
        if (field.values) {
          if (!Object.prototype.hasOwnProperty.call(propValues, key6)) {
            assignProp(propValues, key6, /* @__PURE__ */ new Set());
          }
          for (const v of field.values)
            propValues[key6].add(v);
          if (field.optin !== void 0)
            propValues[key6].add(void 0);
        }
      }
      return propValues;
    });
    const isObject2 = isObject;
    const catchall = def.catchall;
    let value;
    const memo2 = globalConfig.memoizer;
    memo2?.attach(inst);
    inst._zod.parse = (payload, ctx) => {
      value ?? (value = _normalized.value);
      const input2 = payload.value;
      if (!isObject2(input2)) {
        payload.issues.push({
          expected: "object",
          code: "invalid_type",
          input: input2,
          inst
        });
        return payload;
      }
      payload.value = memo2 ? memo2.alloc(inst, payload, {}, ctx) : {};
      const proms = [];
      const shape = value.shape;
      const abortEarly = ctx?.abortEarly;
      let seen = payload.issues.length;
      for (const key6 of value.allKeys) {
        if (abortEarly && payload.issues.length !== seen) {
          if (aborted(payload, seen))
            break;
          seen = payload.issues.length;
        }
        if (key6 === "__proto__")
          continue;
        const el = shape[key6];
        const optin = el._zod.optin;
        const optout = el._zod.optout;
        const r = el._zod.run({ value: input2[key6], issues: [] }, ctx);
        if (r instanceof Promise) {
          proms.push(r.then((r2) => handlePropertyResult(r2, payload, key6, input2, optin, optout)));
        } else {
          handlePropertyResult(r, payload, key6, input2, optin, optout);
        }
      }
      if (!catchall) {
        return proms.length ? Promise.all(proms).then(() => payload) : payload;
      }
      return handleCatchall(proms, input2, payload, ctx, _normalized.value, inst, abortEarly === true);
    };
  });
  var $ZodObjectJIT = /* @__PURE__ */ $constructor("$ZodObjectJIT", (inst, def) => {
    $ZodObject.init(inst, def);
    const superParse = inst._zod.parse;
    const _normalized = cached(() => normalizeDef(def));
    const memo2 = globalConfig.memoizer;
    const generateFastpass = (shape) => {
      const normalized = _normalized.value;
      const syms = normalized.symbolKeys;
      const doc = new Doc(["payload", "ctx"], { shape, inst, memo: memo2, syms });
      const parseStr = (k) => `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
      const prefixStr = (id18, k) => `
          let ${id18}_ab = false;
          for (let i = 0; i < ${id18}.issues.length; i++) {
            const iss = ${id18}.issues[i];
            iss.path = iss.path ? [${k}, ...iss.path] : [${k}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${id18}_ab = true;
          }
          if (${id18}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
      doc.write(`const input = payload.value;`);
      const ids = /* @__PURE__ */ Object.create(null);
      let counter = 0;
      for (const key6 of normalized.allKeys) {
        ids[key6] = `key_${counter++}`;
      }
      doc.write(memo2 ? `const newResult = memo.alloc(inst, payload, {}, ctx);` : `const newResult = {};`);
      for (const key6 of normalized.allKeys) {
        if (key6 === "__proto__")
          continue;
        const id18 = ids[key6];
        const k = typeof key6 === "symbol" ? `syms[${syms.indexOf(key6)}]` : esc(key6);
        const isPresent = `${k} in input`;
        const schema = shape[key6];
        const optin = schema?._zod?.optin;
        const isOptionalIn = optin !== void 0;
        const isOptionalOut = schema?._zod?.optout === "optional";
        doc.write(`const ${id18} = ${parseStr(k)};`);
        if (isOptionalIn && isOptionalOut) {
          const assign = optin === "optional" ? `${id18}_present` : `${id18}.value !== undefined || ${id18}_present`;
          doc.write(`
        const ${id18}_present = ${isPresent};
        if (!${id18}.issues.length || ${id18}_present) {
          if (${id18}.issues.length) {${prefixStr(id18, k)}
          }

          if (${assign}) {
            newResult[${k}] = ${id18}.value;
          }
        }

      `);
        } else if (!isOptionalIn) {
          doc.write(`
        const ${id18}_present = ${isPresent};
        if (${id18}.issues.length) {${prefixStr(id18, k)}
        }
        if (!${id18}_present && !${id18}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${k}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${id18}_present) {
          newResult[${k}] = ${id18}.value;
        }

      `);
        } else {
          doc.write(`
        if (${id18}.issues.length) {${prefixStr(id18, k)}
        }
      `);
          if (optin === "defaulted") {
            doc.write(`newResult[${k}] = ${id18}.value;`);
          } else {
            doc.write(`
        if (${id18}.value !== undefined || ${isPresent}) {
          newResult[${k}] = ${id18}.value;
        }
      `);
          }
        }
      }
      doc.write(`payload.value = newResult;`);
      doc.write(`return payload;`);
      return doc.compile();
    };
    let fastpass;
    const isObject2 = isObject;
    const jit = !globalConfig.jitless;
    const allowsEval2 = allowsEval;
    const fastEnabled = jit && allowsEval2.value;
    const catchall = def.catchall;
    let value;
    inst._zod.parse = (payload, ctx) => {
      value ?? (value = _normalized.value);
      const input2 = payload.value;
      if (!isObject2(input2)) {
        payload.issues.push({
          expected: "object",
          code: "invalid_type",
          input: input2,
          inst
        });
        return payload;
      }
      if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
        if (!fastpass)
          fastpass = generateFastpass(def.shape);
        payload = fastpass(payload, ctx);
        if (!catchall)
          return payload;
        return handleCatchall([], input2, payload, ctx, value, inst, ctx?.abortEarly === true);
      }
      return superParse(payload, ctx);
    };
  });
  function handleUnionResults(results, final, inst, ctx) {
    for (const result of results) {
      if (result.issues.length === 0) {
        final.value = result.value;
        return final;
      }
    }
    const nonaborted = results.filter((r) => !aborted(r));
    if (nonaborted.length === 1) {
      final.value = nonaborted[0].value;
      return nonaborted[0];
    }
    final.issues.push({
      code: "invalid_union",
      input: final.value,
      inst,
      errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
    });
    return final;
  }
  var $ZodUnion = /* @__PURE__ */ $constructor("$ZodUnion", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0);
    defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
    defineLazyInternal(inst, "values", (zod) => {
      if (zod.def.options.every((o) => o._zod.values)) {
        return new Set(zod.def.options.flatMap((option2) => Array.from(option2._zod.values)));
      }
      return void 0;
    });
    defineLazyInternal(inst, "pattern", (zod) => {
      if (zod.def.options.every((o) => o._zod.pattern)) {
        const patterns = zod.def.options.map((o) => o._zod.pattern);
        return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
      }
      return void 0;
    });
    const first = def.options.length === 1 ? def.options[0]._zod.run : null;
    inst._zod.parse = (payload, ctx) => {
      if (first) {
        return first(payload, ctx);
      }
      let async = false;
      const results = [];
      for (const option2 of def.options) {
        const result = option2._zod.run({
          value: payload.value,
          issues: []
        }, ctx);
        if (result instanceof Promise) {
          results.push(result);
          async = true;
        } else {
          if (result.issues.length === 0)
            return result;
          results.push(result);
        }
      }
      if (!async)
        return handleUnionResults(results, payload, inst, ctx);
      return Promise.all(results).then((results2) => {
        return handleUnionResults(results2, payload, inst, ctx);
      });
    };
  });
  function handleExclusiveUnionResults(results, final, inst, ctx) {
    const matches = [];
    for (let i = 0; i < results.length; i++) {
      if (results[i].issues.length === 0)
        matches.push(i);
    }
    if (matches.length === 1) {
      final.value = results[matches[0]].value;
      return final;
    }
    if (matches.length === 0) {
      final.issues.push({
        code: "invalid_union",
        input: final.value,
        inst,
        errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
      });
    } else {
      final.issues.push({
        code: "invalid_union",
        input: final.value,
        inst,
        errors: [],
        inclusive: false,
        matches
      });
    }
    return final;
  }
  var $ZodXor = /* @__PURE__ */ $constructor("$ZodXor", (inst, def) => {
    $ZodUnion.init(inst, def);
    def.inclusive = false;
    const first = def.options.length === 1 ? def.options[0]._zod.run : null;
    inst._zod.parse = (payload, ctx) => {
      if (first) {
        return first(payload, ctx);
      }
      let async = false;
      const results = [];
      for (const option2 of def.options) {
        const result = option2._zod.run({
          value: payload.value,
          issues: []
        }, ctx);
        if (result instanceof Promise) {
          results.push(result);
          async = true;
        } else {
          results.push(result);
        }
      }
      if (!async)
        return handleExclusiveUnionResults(results, payload, inst, ctx);
      return Promise.all(results).then((results2) => {
        return handleExclusiveUnionResults(results2, payload, inst, ctx);
      });
    };
  });
  function getDiscriminatedOption(union2, value) {
    const internals = union2._zod;
    let map2 = internals.bag.optionsMap;
    if (!map2) {
      map2 = discriminatorMap(internals.def);
      internals.bag.optionsMap = map2;
    }
    const option2 = map2.get(value);
    if (option2 === null)
      throw new Error(`Ambiguous discriminator value "${String(value)}"`);
    return option2;
  }
  function discriminatorMap(def) {
    const map2 = /* @__PURE__ */ new Map();
    for (const option2 of def.options) {
      const values = option2._zod.propValues?.[def.discriminator];
      if (!values || values.size === 0)
        throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(option2)}"`);
      for (const value of values) {
        if (map2.has(value)) {
          if (value !== void 0)
            throw new Error(`Duplicate discriminator value "${String(value)}"`);
          map2.set(value, null);
        } else {
          map2.set(value, option2);
        }
      }
    }
    return map2;
  }
  var $ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("$ZodDiscriminatedUnion", (inst, def) => {
    def.inclusive = false;
    $ZodUnion.init(inst, def);
    const _super = inst._zod.parse;
    defineLazyInternal(inst, "propValues", (zod) => {
      const propValues = {};
      let undefinedCount = 0;
      for (const option2 of zod.def.options) {
        const pv = option2._zod.propValues;
        if (!pv || Object.keys(pv).length === 0)
          throw new Error(`Invalid discriminated union option at index "${zod.def.options.indexOf(option2)}"`);
        if (pv[zod.def.discriminator]?.has(void 0))
          undefinedCount++;
        for (const [k, v] of Object.entries(pv)) {
          if (!Object.prototype.hasOwnProperty.call(propValues, k)) {
            assignProp(propValues, k, /* @__PURE__ */ new Set());
          }
          for (const val of v) {
            propValues[k].add(val);
          }
        }
      }
      if (!zod.def.unionFallback && undefinedCount > 1)
        propValues[zod.def.discriminator]?.delete(void 0);
      return propValues;
    });
    def.options.forEach((option2, i) => {
      const propShape = rawShape(option2._zod.def);
      if (propShape && !Object.prototype.hasOwnProperty.call(propShape, def.discriminator)) {
        throw new Error(`Invalid discriminated union option at index "${i}"`);
      }
    });
    const disc = cached(() => discriminatorMap(def));
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      if (!isObject(input2)) {
        payload.issues.push({
          code: "invalid_type",
          expected: "object",
          input: input2,
          inst
        });
        return payload;
      }
      const value = input2?.[def.discriminator];
      const opt = disc.value.get(value);
      if (opt && (value !== void 0 || ctx.direction !== "backward")) {
        return opt._zod.run(payload, ctx);
      }
      if (def.unionFallback || ctx.direction === "backward") {
        return _super(payload, ctx);
      }
      payload.issues.push({
        code: "invalid_union",
        errors: [],
        note: "No matching discriminator",
        discriminator: def.discriminator,
        options: Array.from(disc.value.keys()).filter((value2) => disc.value.get(value2) !== null),
        input: input2,
        path: [def.discriminator],
        inst
      });
      return payload;
    };
  });
  var $ZodIntersection = /* @__PURE__ */ $constructor("$ZodIntersection", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      const left = def.left._zod.run({ value: input2, issues: [] }, ctx);
      const right = def.right._zod.run({ value: input2, issues: [] }, ctx);
      const async = left instanceof Promise || right instanceof Promise;
      if (async) {
        return Promise.all([left, right]).then(([left2, right2]) => {
          return handleIntersectionResults(payload, left2, right2);
        });
      }
      return handleIntersectionResults(payload, left, right);
    };
  });
  function mergeValues(a, b) {
    if (a === b) {
      return { valid: true, data: a };
    }
    if (a instanceof Date && b instanceof Date && +a === +b) {
      return { valid: true, data: a };
    }
    if (isPlainObject(a) && isPlainObject(b)) {
      const bKeys = Object.keys(b);
      const sharedKeys = Object.keys(a).filter((key6) => bKeys.indexOf(key6) !== -1);
      const newObj = { ...a, ...b };
      if (Object.prototype.hasOwnProperty.call(newObj, "__proto__"))
        delete newObj.__proto__;
      for (const key6 of sharedKeys) {
        if (key6 === "__proto__")
          continue;
        const sharedValue = mergeValues(a[key6], b[key6]);
        if (!sharedValue.valid) {
          return {
            valid: false,
            mergeErrorPath: [key6, ...sharedValue.mergeErrorPath]
          };
        }
        newObj[key6] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    }
    if (Array.isArray(a) && Array.isArray(b)) {
      if (a.length !== b.length) {
        return { valid: false, mergeErrorPath: [] };
      }
      const newArray = [];
      for (let index = 0; index < a.length; index++) {
        const itemA = a[index];
        const itemB = b[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return {
            valid: false,
            mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
          };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    }
    return { valid: false, mergeErrorPath: [] };
  }
  function handleIntersectionResults(result, left, right) {
    const unrecKeys = /* @__PURE__ */ new Map();
    let unrecIssue;
    const keyIssues = /* @__PURE__ */ new Map();
    const collect = (iss, side) => {
      let keys;
      if (iss.code === "unrecognized_keys" && !iss.path?.length) {
        unrecIssue ?? (unrecIssue = iss);
        keys = iss.keys;
      } else if (iss.code === "invalid_key" && iss.origin === "record" && iss.path?.length === 1) {
        const k = String(iss.path[0]);
        if (!keyIssues.has(k))
          keyIssues.set(k, iss);
        keys = [k];
      } else {
        return false;
      }
      for (const k of keys) {
        if (!unrecKeys.has(k))
          unrecKeys.set(k, {});
        unrecKeys.get(k)[side] = true;
      }
      return true;
    };
    for (const iss of left.issues) {
      if (!collect(iss, "l"))
        result.issues.push(iss);
    }
    for (const iss of right.issues) {
      if (!collect(iss, "r"))
        result.issues.push(iss);
    }
    const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
    if (bothKeys.length) {
      const aggregated = unrecIssue ? bothKeys.filter((k) => unrecIssue.keys.includes(k)) : [];
      if (aggregated.length)
        result.issues.push({ ...unrecIssue, keys: aggregated });
      for (const k of bothKeys) {
        if (!aggregated.includes(k) && keyIssues.has(k))
          result.issues.push(keyIssues.get(k));
      }
    }
    const merged = mergeValues(left.value, right.value);
    if (!merged.valid) {
      if (aborted(result))
        return result;
      throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(merged.mergeErrorPath)}`);
    }
    result.value = merged.data;
    return result;
  }
  var $ZodTuple = /* @__PURE__ */ $constructor("$ZodTuple", (inst, def) => {
    $ZodType.init(inst, def);
    const items = def.items;
    const memo2 = globalConfig.memoizer;
    memo2?.attach(inst);
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      if (!Array.isArray(input2)) {
        payload.issues.push({
          input: input2,
          inst,
          expected: "tuple",
          code: "invalid_type"
        });
        return payload;
      }
      payload.value = memo2 ? memo2.alloc(inst, payload, [], ctx) : [];
      const proms = [];
      const optinStart = getTupleOptStart(items, "optin");
      const optoutStart = getTupleOptStart(items, "optout");
      if (!def.rest) {
        if (input2.length < optinStart) {
          payload.issues.push({
            code: "too_small",
            minimum: optinStart,
            inclusive: true,
            input: input2,
            inst,
            origin: "array"
          });
          return payload;
        }
        if (input2.length > items.length) {
          payload.issues.push({
            code: "too_big",
            maximum: items.length,
            inclusive: true,
            input: input2,
            inst,
            origin: "array"
          });
        }
      }
      const itemResults = new Array(items.length);
      const abortEarly = def.rest ? ctx?.abortEarly : void 0;
      let itemAborted = false;
      for (let i = 0; i < items.length; i++) {
        const r = items[i]._zod.run({ value: input2[i], issues: [] }, ctx);
        if (r instanceof Promise) {
          proms.push(r.then((rr) => {
            itemResults[i] = rr;
          }));
        } else {
          itemResults[i] = r;
          if (abortEarly && !itemAborted && r.issues.length)
            itemAborted = aborted(r);
        }
      }
      if (def.rest && !itemAborted) {
        let i = items.length - 1;
        const rest = input2.slice(items.length);
        let seen = payload.issues.length;
        for (const el of rest) {
          if (abortEarly && payload.issues.length !== seen) {
            if (aborted(payload, seen))
              break;
            seen = payload.issues.length;
          }
          i++;
          const result = def.rest._zod.run({ value: el, issues: [] }, ctx);
          if (result instanceof Promise) {
            proms.push(result.then((r) => handleTupleResult(r, payload, i)));
          } else {
            handleTupleResult(result, payload, i);
          }
        }
      }
      if (proms.length) {
        return Promise.all(proms).then(() => handleTupleResults(itemResults, payload, items, input2, optoutStart));
      }
      return handleTupleResults(itemResults, payload, items, input2, optoutStart);
    };
  });
  function getTupleOptStart(items, key6) {
    for (let i = items.length - 1; i >= 0; i--) {
      const omittable = key6 === "optin" ? items[i]._zod.optin !== void 0 : items[i]._zod.optout === "optional";
      if (!omittable)
        return i + 1;
    }
    return 0;
  }
  function handleTupleResult(result, final, index) {
    if (result.issues.length) {
      final.issues.push(...prefixIssues(index, result.issues));
    }
    final.value[index] = result.value;
  }
  function handleTupleResults(itemResults, final, items, input2, optoutStart) {
    for (let i = 0; i < items.length; i++) {
      const r = itemResults[i];
      const isPresent = i < input2.length;
      if (!isPresent && i >= optoutStart && items[i]._zod.optin === "optional") {
        final.value.length = i;
        break;
      }
      if (r.issues.length) {
        if (!isPresent && i >= optoutStart) {
          final.value.length = i;
          break;
        }
        final.issues.push(...prefixIssues(i, r.issues));
      }
      final.value[i] = r.value;
    }
    for (let i = final.value.length - 1; i >= input2.length; i--) {
      if (items[i]._zod.optout === "optional" && final.value[i] === void 0) {
        final.value.length = i;
      } else {
        break;
      }
    }
    return final;
  }
  var $ZodRecord = /* @__PURE__ */ $constructor("$ZodRecord", (inst, def) => {
    $ZodType.init(inst, def);
    const memo2 = globalConfig.memoizer;
    memo2?.attach(inst);
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      if (!isPlainObject(input2)) {
        payload.issues.push({
          expected: "record",
          code: "invalid_type",
          input: input2,
          inst
        });
        return payload;
      }
      const proms = [];
      const values = def.keyType._zod.values;
      if (values && !def.partial) {
        payload.value = memo2 ? memo2.alloc(inst, payload, {}, ctx) : {};
        const recordKeys = /* @__PURE__ */ new Set();
        for (const key6 of values) {
          if (typeof key6 === "string" || typeof key6 === "number" || typeof key6 === "symbol") {
            recordKeys.add(typeof key6 === "number" ? key6.toString() : key6);
            if (key6 === "__proto__")
              continue;
            const keyResult = def.keyType._zod.run({ value: key6, issues: [] }, ctx);
            if (keyResult instanceof Promise) {
              throw new Error("Async schemas not supported in object keys currently");
            }
            if (keyResult.issues.length) {
              payload.issues.push({
                code: "invalid_key",
                origin: "record",
                issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
                input: key6,
                path: [key6],
                inst
              });
              continue;
            }
            const outKey = keyResult.value;
            if (outKey === "__proto__")
              continue;
            const result = def.valueType._zod.run({ value: input2[key6], issues: [] }, ctx);
            if (result instanceof Promise) {
              proms.push(result.then((result2) => {
                if (result2.issues.length) {
                  payload.issues.push(...prefixIssues(key6, result2.issues));
                }
                payload.value[outKey] = result2.value;
              }));
            } else {
              if (result.issues.length) {
                payload.issues.push(...prefixIssues(key6, result.issues));
              }
              payload.value[outKey] = result.value;
            }
          }
        }
        let unrecognized;
        for (const key6 in input2) {
          if (!recordKeys.has(key6)) {
            if (def.mode === "loose") {
              if (key6 === "__proto__")
                continue;
              payload.value[key6] = input2[key6];
            } else {
              unrecognized = unrecognized ?? [];
              unrecognized.push(key6);
            }
          }
        }
        if (unrecognized && unrecognized.length > 0) {
          payload.issues.push({
            code: "unrecognized_keys",
            input: input2,
            inst,
            keys: unrecognized,
            continue: true
          });
        }
      } else {
        payload.value = memo2 ? memo2.alloc(inst, payload, {}, ctx) : {};
        let unrecognized;
        for (const key6 of Reflect.ownKeys(input2)) {
          if (key6 === "__proto__")
            continue;
          if (!Object.prototype.propertyIsEnumerable.call(input2, key6))
            continue;
          let keyResult = def.keyType._zod.run({ value: key6, issues: [] }, ctx);
          if (keyResult instanceof Promise) {
            throw new Error("Async schemas not supported in object keys currently");
          }
          const checkNumericKey = typeof key6 === "string" && number.test(key6) && keyResult.issues.length;
          if (checkNumericKey) {
            const retryResult = def.keyType._zod.run({ value: Number(key6), issues: [] }, ctx);
            if (retryResult instanceof Promise) {
              throw new Error("Async schemas not supported in object keys currently");
            }
            if (retryResult.issues.length === 0) {
              keyResult = retryResult;
            }
          }
          if (keyResult.issues.length) {
            if (def.mode === "loose") {
              payload.value[key6] = input2[key6];
            } else if (values) {
              unrecognized = unrecognized ?? [];
              unrecognized.push(key6);
            } else {
              payload.issues.push({
                code: "invalid_key",
                origin: "record",
                issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
                input: key6,
                path: [key6],
                inst
              });
            }
            continue;
          }
          const outKey = keyResult.value;
          if (outKey === "__proto__")
            continue;
          const result = def.valueType._zod.run({ value: input2[key6], issues: [] }, ctx);
          if (result instanceof Promise) {
            proms.push(result.then((result2) => {
              if (result2.issues.length) {
                payload.issues.push(...prefixIssues(key6, result2.issues));
              }
              payload.value[outKey] = result2.value;
            }));
          } else {
            if (result.issues.length) {
              payload.issues.push(...prefixIssues(key6, result.issues));
            }
            payload.value[outKey] = result.value;
          }
        }
        if (unrecognized && unrecognized.length > 0) {
          payload.issues.push({
            code: "unrecognized_keys",
            input: input2,
            inst,
            keys: unrecognized,
            continue: true
          });
        }
      }
      if (proms.length) {
        return Promise.all(proms).then(() => payload);
      }
      return payload;
    };
  });
  var $ZodMap = /* @__PURE__ */ $constructor("$ZodMap", (inst, def) => {
    $ZodType.init(inst, def);
    const memo2 = globalConfig.memoizer;
    memo2?.attach(inst);
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      if (!(input2 instanceof Map)) {
        payload.issues.push({
          expected: "map",
          code: "invalid_type",
          input: input2,
          inst
        });
        return payload;
      }
      const proms = [];
      payload.value = memo2 ? memo2.alloc(inst, payload, /* @__PURE__ */ new Map(), ctx) : /* @__PURE__ */ new Map();
      const abortEarly = ctx?.abortEarly;
      let seen = payload.issues.length;
      for (const [key6, value] of input2) {
        if (abortEarly && payload.issues.length !== seen) {
          if (aborted(payload, seen))
            break;
          seen = payload.issues.length;
        }
        const keyResult = def.keyType._zod.run({ value: key6, issues: [] }, ctx);
        const valueResult = def.valueType._zod.run({ value, issues: [] }, ctx);
        if (keyResult instanceof Promise || valueResult instanceof Promise) {
          proms.push(Promise.all([keyResult, valueResult]).then(([keyResult2, valueResult2]) => {
            handleMapResult(keyResult2, valueResult2, payload, key6, input2, inst, ctx);
          }));
        } else {
          handleMapResult(keyResult, valueResult, payload, key6, input2, inst, ctx);
        }
      }
      if (proms.length)
        return Promise.all(proms).then(() => payload);
      return payload;
    };
    capSize(inst, mapSize);
  });
  function handleMapResult(keyResult, valueResult, final, key6, input2, inst, ctx) {
    if (keyResult.issues.length) {
      if (propertyKeyTypes.has(typeof key6)) {
        final.issues.push(...prefixIssues(key6, keyResult.issues));
      } else {
        final.issues.push({
          code: "invalid_key",
          origin: "map",
          input: input2,
          inst,
          issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config()))
        });
      }
    }
    if (valueResult.issues.length) {
      if (propertyKeyTypes.has(typeof key6)) {
        final.issues.push(...prefixIssues(key6, valueResult.issues));
      } else {
        final.issues.push({
          origin: "map",
          code: "invalid_element",
          input: input2,
          inst,
          key: key6,
          issues: valueResult.issues.map((iss) => finalizeIssue(iss, ctx, config()))
        });
      }
    }
    final.value.set(keyResult.value, valueResult.value);
  }
  var $ZodSet = /* @__PURE__ */ $constructor("$ZodSet", (inst, def) => {
    $ZodType.init(inst, def);
    const memo2 = globalConfig.memoizer;
    memo2?.attach(inst);
    inst._zod.parse = (payload, ctx) => {
      const input2 = payload.value;
      if (!(input2 instanceof Set)) {
        payload.issues.push({
          input: input2,
          inst,
          expected: "set",
          code: "invalid_type"
        });
        return payload;
      }
      const proms = [];
      payload.value = memo2 ? memo2.alloc(inst, payload, /* @__PURE__ */ new Set(), ctx) : /* @__PURE__ */ new Set();
      const abortEarly = ctx?.abortEarly;
      let seen = payload.issues.length;
      for (const item of input2) {
        if (abortEarly && payload.issues.length !== seen) {
          if (aborted(payload, seen))
            break;
          seen = payload.issues.length;
        }
        const result = def.valueType._zod.run({ value: item, issues: [] }, ctx);
        if (result instanceof Promise) {
          proms.push(result.then((result2) => handleSetResult(result2, payload)));
        } else
          handleSetResult(result, payload);
      }
      if (proms.length)
        return Promise.all(proms).then(() => payload);
      return payload;
    };
    capSize(inst, setSize);
  });
  function handleSetResult(result, final) {
    if (result.issues.length) {
      final.issues.push(...result.issues);
    }
    final.value.add(result.value);
  }
  var $ZodEnum = /* @__PURE__ */ $constructor("$ZodEnum", (inst, def) => {
    $ZodType.init(inst, def);
    const values = getEnumValues(def.entries);
    const valuesSet = new Set(values);
    inst._zod.values = valuesSet;
    defineLazyInternal(inst, "pattern", (zod) => {
      const patternValues = getEnumValues(zod.def.entries).filter((k) => propertyKeyTypes.has(typeof k));
      return new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
    });
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (valuesSet.has(input2)) {
        return payload;
      }
      payload.issues.push({
        code: "invalid_value",
        values,
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodLiteral = /* @__PURE__ */ $constructor("$ZodLiteral", (inst, def) => {
    $ZodType.init(inst, def);
    const values = new Set(def.values);
    inst._zod.values = values;
    defineLazyInternal(inst, "pattern", (zod) => {
      const vals = zod.def.values;
      return new RegExp(vals.length ? `^(${vals.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
    });
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (values.has(input2)) {
        return payload;
      }
      payload.issues.push({
        code: "invalid_value",
        values: def.values,
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodFile = /* @__PURE__ */ $constructor("$ZodFile", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx) => {
      const input2 = payload.value;
      if (input2 instanceof File)
        return payload;
      payload.issues.push({
        expected: "file",
        code: "invalid_type",
        input: input2,
        inst
      });
      return payload;
    };
  });
  var $ZodTransform = /* @__PURE__ */ $constructor("$ZodTransform", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.optin = "optional";
    globalConfig.memoizer?.guard(inst);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        throw new $ZodEncodeError(inst.constructor.name);
      }
      const _out = def.transform(payload.value, payload);
      if (ctx.async) {
        const output2 = _out instanceof Promise ? _out : Promise.resolve(_out);
        return output2.then((output3) => {
          payload.value = output3;
          return payload;
        });
      }
      if (_out instanceof Promise) {
        throw new $ZodAsyncError();
      }
      payload.value = _out;
      return payload;
    };
  });
  function handleOptionalResult(payload, result) {
    payload.value = result.issues.length ? void 0 : result.value;
    return payload;
  }
  var $ZodOptional = /* @__PURE__ */ $constructor("$ZodOptional", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
    inst._zod.optout = "optional";
    defineLazyInternal(inst, "values", (zod) => {
      const values = zod.def.innerType._zod.values;
      return values ? /* @__PURE__ */ new Set([...values, void 0]) : void 0;
    });
    defineLazyInternal(inst, "pattern", (zod) => {
      const pattern = zod.def.innerType._zod.pattern;
      return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
    });
    inst._zod.parse = (payload, ctx) => {
      if (payload.value === void 0) {
        if (def.innerType._zod.optin !== "defaulted")
          return payload;
        const result = def.innerType._zod.run({ value: payload.value, issues: [] }, ctx);
        if (result instanceof Promise)
          return result.then((result2) => handleOptionalResult(payload, result2));
        return handleOptionalResult(payload, result);
      }
      return def.innerType._zod.run(payload, ctx);
    };
  });
  var $ZodExactOptional = /* @__PURE__ */ $constructor("$ZodExactOptional", (inst, def) => {
    $ZodOptional.init(inst, def);
    defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
    defineLazyInternal(inst, "pattern", (zod) => zod.def.innerType._zod.pattern);
    inst._zod.parse = (payload, ctx) => {
      return def.innerType._zod.run(payload, ctx);
    };
  });
  var $ZodNullable = /* @__PURE__ */ $constructor("$ZodNullable", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
    defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
    defineLazyInternal(inst, "pattern", (zod) => {
      const pattern = zod.def.innerType._zod.pattern;
      return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
    });
    defineLazyInternal(inst, "values", (zod) => {
      return zod.def.innerType._zod.values ? /* @__PURE__ */ new Set([...zod.def.innerType._zod.values, null]) : void 0;
    });
    inst._zod.parse = (payload, ctx) => {
      if (payload.value === null)
        return payload;
      return def.innerType._zod.run(payload, ctx);
    };
  });
  var $ZodDefault = /* @__PURE__ */ $constructor("$ZodDefault", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.optin = "defaulted";
    defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        return def.innerType._zod.run(payload, ctx);
      }
      if (payload.value === void 0) {
        payload.value = def.defaultValue;
        return payload;
      }
      const result = def.innerType._zod.run(payload, ctx);
      if (result instanceof Promise) {
        return result.then((result2) => handleDefaultResult(result2, def));
      }
      return handleDefaultResult(result, def);
    };
  });
  function handleDefaultResult(payload, def) {
    if (payload.value === void 0) {
      payload.value = def.defaultValue;
    }
    return payload;
  }
  var $ZodPrefault = /* @__PURE__ */ $constructor("$ZodPrefault", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.optin = "defaulted";
    defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        return def.innerType._zod.run(payload, ctx);
      }
      if (payload.value === void 0) {
        payload.value = def.defaultValue;
      }
      return def.innerType._zod.run(payload, ctx);
    };
  });
  var $ZodNonOptional = /* @__PURE__ */ $constructor("$ZodNonOptional", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "values", (zod) => {
      const v = zod.def.innerType._zod.values;
      return v ? new Set([...v].filter((x) => x !== void 0)) : void 0;
    });
    inst._zod.parse = (payload, ctx) => {
      const result = def.innerType._zod.run(payload, ctx);
      if (result instanceof Promise) {
        return result.then((result2) => handleNonOptionalResult(result2, inst));
      }
      return handleNonOptionalResult(result, inst);
    };
  });
  function handleNonOptionalResult(payload, inst) {
    if (!payload.issues.length && payload.value === void 0) {
      payload.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: payload.value,
        inst
      });
    }
    return payload;
  }
  var $ZodSuccess = /* @__PURE__ */ $constructor("$ZodSuccess", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        throw new $ZodEncodeError("ZodSuccess");
      }
      const result = def.innerType._zod.run(payload, ctx);
      if (result instanceof Promise) {
        return result.then((result2) => {
          payload.value = result2.issues.length === 0;
          return payload;
        });
      }
      payload.value = result.issues.length === 0;
      return payload;
    };
  });
  function handleCatchResult(payload, result, def, ctx) {
    if (!result.issues.length) {
      payload.value = result.value;
      if (result.memo)
        payload.memo = true;
      return payload;
    }
    payload.value = def.catchValue({
      ...result,
      value: payload.value,
      error: {
        issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config()))
      },
      input: payload.value
    });
    return payload;
  }
  var $ZodCatch = /* @__PURE__ */ $constructor("$ZodCatch", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
    defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
    defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        return def.innerType._zod.run(payload, ctx);
      }
      const result = def.innerType._zod.run({ value: payload.value, issues: [] }, ctx);
      if (result instanceof Promise) {
        return result.then((result2) => handleCatchResult(payload, result2, def, ctx));
      }
      return handleCatchResult(payload, result, def, ctx);
    };
  });
  var $ZodNaN = /* @__PURE__ */ $constructor("$ZodNaN", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx) => {
      if (typeof payload.value !== "number" || !Number.isNaN(payload.value)) {
        payload.issues.push({
          input: payload.value,
          inst,
          expected: "nan",
          code: "invalid_type"
        });
        return payload;
      }
      return payload;
    };
  });
  var $ZodPipe = /* @__PURE__ */ $constructor("$ZodPipe", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
    defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
    defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
    defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        const right = def.out._zod.run(payload, ctx);
        if (right instanceof Promise) {
          return right.then((right2) => handlePipeResult(right2, def.in, ctx));
        }
        return handlePipeResult(right, def.in, ctx);
      }
      const left = def.in._zod.run(payload, ctx);
      if (left instanceof Promise) {
        return left.then((left2) => handlePipeResult(left2, def.out, ctx));
      }
      return handlePipeResult(left, def.out, ctx);
    };
  });
  function handlePipeResult(left, next, ctx) {
    if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
      left.aborted = true;
      return left;
    }
    return next._zod.run({ value: left.value, issues: left.issues }, ctx);
  }
  var $ZodCodec = /* @__PURE__ */ $constructor("$ZodCodec", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
    defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
    defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
    defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
    inst._zod.parse = (payload, ctx) => {
      const direction = ctx.direction || "forward";
      if (direction === "forward") {
        const left = def.in._zod.run(payload, ctx);
        if (left instanceof Promise) {
          return left.then((left2) => handleCodecAResult(left2, def, ctx));
        }
        return handleCodecAResult(left, def, ctx);
      } else {
        const right = def.out._zod.run(payload, ctx);
        if (right instanceof Promise) {
          return right.then((right2) => handleCodecAResult(right2, def, ctx));
        }
        return handleCodecAResult(right, def, ctx);
      }
    };
  });
  function handleCodecAResult(result, def, ctx) {
    if (result.issues.length) {
      result.aborted = true;
      return result;
    }
    const direction = ctx.direction || "forward";
    if (direction === "forward") {
      const transformed = def.transform(result.value, result);
      if (transformed instanceof Promise) {
        return transformed.then((value) => handleCodecTxResult(result, value, def.out, ctx));
      }
      return handleCodecTxResult(result, transformed, def.out, ctx);
    } else {
      const transformed = def.reverseTransform(result.value, result);
      if (transformed instanceof Promise) {
        return transformed.then((value) => handleCodecTxResult(result, value, def.in, ctx));
      }
      return handleCodecTxResult(result, transformed, def.in, ctx);
    }
  }
  function handleCodecTxResult(left, value, nextSchema, ctx) {
    if (left.issues.length) {
      left.aborted = true;
      return left;
    }
    return nextSchema._zod.run({ value, issues: left.issues }, ctx);
  }
  var $ZodPreprocess = /* @__PURE__ */ $constructor("$ZodPreprocess", (inst, def) => {
    $ZodPipe.init(inst, def);
  });
  var $ZodReadonly = /* @__PURE__ */ $constructor("$ZodReadonly", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazyInternal(inst, "propValues", (zod) => zod.def.innerType._zod.propValues);
    defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
    defineLazyInternal(inst, "optin", (zod) => zod.def.innerType?._zod?.optin);
    defineLazyInternal(inst, "optout", (zod) => zod.def.innerType?._zod?.optout);
    inst._zod.parse = (payload, ctx) => {
      if (ctx.direction === "backward") {
        return def.innerType._zod.run(payload, ctx);
      }
      const result = def.innerType._zod.run(payload, ctx);
      if (result instanceof Promise) {
        return result.then(handleReadonlyResult);
      }
      return handleReadonlyResult(result);
    };
  });
  function handleReadonlyResult(payload) {
    if (!payload.memo)
      payload.value = Object.freeze(payload.value);
    return payload;
  }
  function leafPattern(schema) {
    const def = schema._zod.def;
    let pattern = def.pattern;
    let isInt = !!def.format?.includes("int");
    let minimum;
    let maximum;
    for (const ch of def.checks ?? []) {
      const d = ch._zod.def;
      if (d.pattern)
        pattern = d.pattern;
      isInt || (isInt = !!d.format?.includes("int"));
      const lo = d.minimum ?? d.length;
      const hi = d.maximum ?? d.length;
      if (lo !== void 0 && (minimum === void 0 || lo > minimum))
        minimum = lo;
      if (hi !== void 0 && (maximum === void 0 || hi < maximum))
        maximum = hi;
    }
    if (pattern)
      return pattern.source;
    if (minimum !== void 0 && maximum !== void 0 && minimum > maximum)
      return "(?!)";
    if (minimum !== void 0 || maximum !== void 0)
      return string({ minimum, maximum }).source;
    const own2 = schema._zod.pattern;
    return (isInt && own2 === number ? integer : own2)?.source;
  }
  function partPattern(schema) {
    const def = schema._zod.def;
    const own2 = schema._zod.pattern?.source;
    const inner = def.innerType ?? schema._zod.innerType;
    if (inner) {
      const before = inner._zod.pattern?.source;
      const after = partPattern(inner);
      if (own2 && before && after && after !== before) {
        return own2.replace(cleanRegex(before), () => cleanRegex(after));
      }
      return own2;
    }
    if (def.options) {
      const sources = def.options.map(partPattern);
      if (sources.every(Boolean))
        return `^(${sources.map((s) => cleanRegex(s)).join("|")})$`;
    }
    return leafPattern(schema);
  }
  var $ZodTemplateLiteral = /* @__PURE__ */ $constructor("$ZodTemplateLiteral", (inst, def) => {
    $ZodType.init(inst, def);
    const regexParts = [];
    for (const part of def.parts) {
      if (typeof part === "object" && part !== null) {
        const source = partPattern(part);
        if (!source) {
          throw new Error(`Invalid template literal part, no pattern found: ${[...part._zod.traits].shift()}`);
        }
        regexParts.push(cleanRegex(source));
      } else if (part === null || primitiveTypes.has(typeof part)) {
        regexParts.push(escapeRegex(`${part}`));
      } else {
        throw new Error(`Invalid template literal part: ${part}`);
      }
    }
    inst._zod.pattern = new RegExp(`^${regexParts.join("")}$`);
    inst._zod.parse = (payload, _ctx) => {
      if (typeof payload.value !== "string") {
        payload.issues.push({
          input: payload.value,
          inst,
          expected: "string",
          code: "invalid_type"
        });
        return payload;
      }
      inst._zod.pattern.lastIndex = 0;
      if (!inst._zod.pattern.test(payload.value)) {
        payload.issues.push({
          input: payload.value,
          inst,
          code: "invalid_format",
          format: def.format ?? "template_literal",
          pattern: inst._zod.pattern.source
        });
        return payload;
      }
      return payload;
    };
  });
  var $ZodFunction = /* @__PURE__ */ $constructor("$ZodFunction", (inst, def) => {
    $ZodType.init(inst, def);
    Object.defineProperty(inst, "_def", { value: def });
    inst._zod.def = def;
    inst.implement = (func) => {
      if (typeof func !== "function") {
        throw new Error("implement() must be called with a function");
      }
      return Object.defineProperty(function(...args) {
        const parsedArgs = inst._def.input ? parse(inst._def.input, args) : args;
        const result = Reflect.apply(func, this, parsedArgs);
        if (inst._def.output) {
          return parse(inst._def.output, result);
        }
        return result;
      }, "_zod", { value: inst._zod, enumerable: false });
    };
    inst.implementAsync = (func) => {
      if (typeof func !== "function") {
        throw new Error("implementAsync() must be called with a function");
      }
      return Object.defineProperty(async function(...args) {
        const parsedArgs = inst._def.input ? await parseAsync(inst._def.input, args) : args;
        const result = await Reflect.apply(func, this, parsedArgs);
        if (inst._def.output) {
          return await parseAsync(inst._def.output, result);
        }
        return result;
      }, "_zod", { value: inst._zod, enumerable: false });
    };
    inst._zod.parse = (payload, _ctx) => {
      if (typeof payload.value !== "function") {
        payload.issues.push({
          code: "invalid_type",
          expected: "function",
          input: payload.value,
          inst
        });
        return payload;
      }
      const hasPromiseOutput = inst._def.output && inst._def.output._zod.def.type === "promise";
      if (hasPromiseOutput) {
        payload.value = inst.implementAsync(payload.value);
      } else {
        payload.value = inst.implement(payload.value);
      }
      return payload;
    };
    inst.input = (...args) => {
      const F = inst.constructor;
      if (Array.isArray(args[0])) {
        return new F({
          type: "function",
          input: new $ZodTuple({
            type: "tuple",
            items: args[0],
            rest: args[1]
          }),
          output: inst._def.output
        });
      }
      return new F({
        type: "function",
        input: args[0],
        output: inst._def.output
      });
    };
    inst.output = (output2) => {
      const F = inst.constructor;
      return new F({
        type: "function",
        input: inst._def.input,
        output: output2
      });
    };
    return inst;
  });
  var $ZodPromise = /* @__PURE__ */ $constructor("$ZodPromise", (inst, def) => {
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx) => {
      return Promise.resolve(payload.value).then((inner) => def.innerType._zod.run({ value: inner, issues: [] }, ctx));
    };
  });
  var $ZodLazy = /* @__PURE__ */ $constructor("$ZodLazy", (inst, def) => {
    $ZodType.init(inst, def);
    defineLazy(inst._zod, "innerType", () => {
      const d = def;
      if (!d._cachedInner)
        d._cachedInner = def.getter();
      return d._cachedInner;
    });
    defineLazyInternal(inst, "pattern", (zod) => zod.innerType?._zod?.pattern);
    defineLazyInternal(inst, "propValues", (zod) => zod.innerType?._zod?.propValues);
    defineLazyInternal(inst, "optin", (zod) => zod.innerType?._zod?.optin ?? void 0);
    defineLazyInternal(inst, "optout", (zod) => zod.innerType?._zod?.optout ?? void 0);
    inst._zod.parse = (payload, ctx) => {
      const inner = inst._zod.innerType;
      return inner._zod.run(payload, ctx);
    };
  });
  var $ZodCustom = /* @__PURE__ */ $constructor("$ZodCustom", (inst, def) => {
    $ZodCheck.init(inst, def);
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _) => {
      return payload;
    };
    inst._zod.check = (payload) => {
      const input2 = payload.value;
      const r = def.fn(input2);
      if (r instanceof Promise) {
        return r.then((r2) => handleRefineResult(r2, payload, input2, inst));
      }
      handleRefineResult(r, payload, input2, inst);
      return;
    };
  });
  function handleRefineResult(result, payload, input2, inst) {
    if (!result) {
      const _iss = {
        code: "custom",
        input: input2,
        inst,
        // incorporates params.error into issue reporting
        path: [...inst._zod.def.path ?? []],
        // incorporates params.error into issue reporting
        continue: !inst._zod.def.abort
        // params: inst._zod.def.params,
      };
      if (inst._zod.def.params)
        _iss.params = inst._zod.def.params;
      payload.issues.push(issue(_iss));
    }
  }

  // ../../../node_modules/zod/v4/core/memoizer.js
  var $ZodCyclicError = class extends Error {
    constructor() {
      super(`Cannot parse a reference cycle that closes through a transform`);
      this.name = "ZodCyclicError";
    }
  };
  var STATE = "~memo";
  var NO_ISSUES = [];
  function isRef(value) {
    return value !== null && typeof value === "object";
  }
  function cloneIssues(issues) {
    return issues.map((iss) => iss.path ? { ...iss, path: iss.path.slice() } : { ...iss });
  }
  var recursive = /* @__PURE__ */ new WeakMap();
  var NONE = 0;
  var ASSUMED = 1;
  var PROVEN = 2;
  function isRecursive(inst, stack, resolve) {
    const cached2 = recursive.get(inst);
    if (cached2 !== void 0)
      return cached2 ? PROVEN : NONE;
    if (stack.has(inst))
      return PROVEN;
    stack.add(inst);
    let result = NONE;
    const check2 = (child) => {
      if (result !== PROVEN && child?._zod) {
        const answer = isRecursive(child, stack, resolve);
        if (answer > result)
          result = answer;
      }
    };
    const shape = (sh, spread) => {
      let answer = NONE;
      for (const key6 of Reflect.ownKeys(sh)) {
        const desc = Object.getOwnPropertyDescriptor(sh, key6);
        if (spread && !desc.enumerable)
          continue;
        const child = desc.get ? ASSUMED : desc.value?._zod ? isRecursive(desc.value, stack, resolve) : NONE;
        if (child > answer)
          answer = child;
      }
      return answer;
    };
    const merge2 = (answer) => {
      if (answer > result)
        result = answer;
    };
    const def = inst._zod.def;
    const kind = def.type;
    switch (kind) {
      case "object": {
        const raw = rawShape(def);
        merge2(raw ? shape(raw, true) : ASSUMED);
        check2(def.catchall);
        break;
      }
      case "array":
        check2(def.element);
        break;
      case "tuple":
        for (const el of def.items)
          check2(el);
        check2(def.rest);
        break;
      case "record":
      case "map":
        check2(def.keyType);
        check2(def.valueType);
        break;
      case "set":
        check2(def.valueType);
        break;
      case "union":
        for (const el of def.options)
          check2(el);
        break;
      case "intersection":
        check2(def.left);
        check2(def.right);
        break;
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success":
        check2(def.innerType);
        break;
      case "pipe":
        check2(def.in);
        check2(def.out);
        break;
      case "function":
        check2(def.input);
        check2(def.output);
        break;
      // `$ZodLazy` caches its inner on the def, so a resolved edge is followed exactly
      case "lazy": {
        const inner = def._cachedInner ?? (resolve ? inst._zod.innerType : void 0);
        merge2(inner ? isRecursive(inner, stack, false) : ASSUMED);
        break;
      }
      // a leaf by choice: `parts` are regex fragments, not data positions
      case "template_literal":
      // leaves
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        break;
      default: {
        kind;
        for (const key6 in def) {
          const desc = Object.getOwnPropertyDescriptor(def, key6);
          if (!desc || desc.get)
            continue;
          const value = desc.value;
          if (!value || typeof value !== "object")
            continue;
          if (value._zod)
            check2(value);
          else if (Array.isArray(value))
            for (const el of value)
              check2(el);
        }
      }
    }
    stack.delete(inst);
    return settle(inst, result);
  }
  function settle(inst, answer) {
    if (answer !== ASSUMED)
      recursive.set(inst, answer === PROVEN);
    return answer;
  }
  function isRecursiveSchema(inst) {
    return isRecursive(inst, /* @__PURE__ */ new Set(), true) !== NONE;
  }
  function bucketFor(state, inst) {
    let bucket = state.buckets.get(inst);
    if (!bucket) {
      bucket = /* @__PURE__ */ new WeakMap();
      state.buckets.set(inst, bucket);
    }
    return bucket;
  }
  var handoff;
  var open = [];
  var memo = {
    alloc(_inst, payload, empty) {
      const bucket = handoff;
      if (!bucket)
        return empty;
      handoff = void 0;
      const entry = { value: empty, issues: null };
      bucket.set(payload.value, entry);
      open.push(entry);
      return empty;
    },
    guard(inst) {
      var _a3;
      (_a3 = inst._zod).deferred ?? (_a3.deferred = []);
      inst._zod.deferred.push(() => {
        const base = inst._zod.parse;
        const wrapped = (payload, ctx) => {
          if (ctx.direction !== "backward" && isBackEdge(ctx, payload.value))
            throw new $ZodCyclicError();
          return base(payload, ctx);
        };
        inst._zod.parse = wrapped;
        if (inst._zod.run === base)
          inst._zod.run = wrapped;
      });
    },
    attach(inst) {
      var _a3;
      let isRecursiveInst;
      let rechecked = false;
      let lastCtx;
      let lastBucket;
      (_a3 = inst._zod).deferred ?? (_a3.deferred = []);
      inst._zod.deferred.push(() => {
        const base = inst._zod.parse;
        const wrapped = (payload, ctx) => {
          if (isRecursiveInst === void 0) {
            const walked = isRecursive(inst, /* @__PURE__ */ new Set(), false);
            if (walked === NONE) {
              inst._zod.parse = base;
              if (inst._zod.run === wrapped)
                inst._zod.run = base;
              return base(payload, ctx);
            }
            if (walked === PROVEN || rechecked)
              isRecursiveInst = true;
            else
              rechecked = true;
          }
          const input2 = payload.value;
          if (!isRef(input2))
            return base(payload, ctx);
          let state = ctx[STATE];
          if (!state) {
            state = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 };
            ctx[STATE] = state;
          }
          let bucket;
          if (lastCtx === ctx) {
            bucket = lastBucket;
          } else {
            bucket = bucketFor(state, inst);
            lastCtx = ctx;
            lastBucket = bucket;
          }
          const hit = bucket.get(input2);
          if (hit) {
            payload.value = hit.value;
            if (hit.issues) {
              if (hit.issues.length)
                payload.issues.push(...cloneIssues(hit.issues));
            } else {
              payload.memo = true;
              state.backEdges ?? (state.backEdges = /* @__PURE__ */ new WeakSet());
              state.backEdges.add(hit.value);
            }
            return payload;
          }
          handoff = bucket;
          const depth = open.length;
          const result = base(payload, ctx);
          handoff = void 0;
          const entry = open.length > depth ? open.pop() : void 0;
          if (result instanceof Promise) {
            return result.then((r) => {
              if (entry)
                entry.issues = r.issues.length ? cloneIssues(r.issues) : NO_ISSUES;
              return r;
            });
          }
          if (entry)
            entry.issues = result.issues.length ? cloneIssues(result.issues) : NO_ISSUES;
          return result;
        };
        inst._zod.parse = wrapped;
        if (inst._zod.run === base)
          inst._zod.run = wrapped;
      });
    }
  };
  function memoizer() {
    return memo;
  }
  function isBackEdge(ctx, value) {
    const backEdges = ctx[STATE]?.backEdges;
    return backEdges !== void 0 && isRef(value) && backEdges.has(value);
  }

  // ../../../node_modules/zod/v4/locales/index.js
  var locales_exports = {};
  __export(locales_exports, {
    ar: () => ar_default,
    az: () => az_default,
    be: () => be_default,
    bg: () => bg_default,
    bn: () => bn_default,
    ca: () => ca_default,
    ckb: () => ckb_default,
    cs: () => cs_default,
    da: () => da_default,
    de: () => de_default,
    el: () => el_default,
    en: () => en_default,
    eo: () => eo_default,
    es: () => es_default,
    fa: () => fa_default,
    fi: () => fi_default,
    fr: () => fr_default,
    frCA: () => fr_CA_default,
    gu: () => gu_default,
    he: () => he_default,
    hi: () => hi_default,
    hr: () => hr_default,
    hu: () => hu_default,
    hy: () => hy_default,
    id: () => id_default,
    is: () => is_default,
    it: () => it_default,
    ja: () => ja_default,
    ka: () => ka_default,
    kh: () => kh_default,
    km: () => km_default,
    kn: () => kn_default,
    ko: () => ko_default,
    lt: () => lt_default,
    mk: () => mk_default,
    ms: () => ms_default,
    ne: () => ne_default,
    nl: () => nl_default,
    nn: () => nn_default,
    no: () => no_default,
    ota: () => ota_default,
    pl: () => pl_default,
    ps: () => ps_default,
    pt: () => pt_default,
    ptBR: () => pt_BR_default,
    ro: () => ro_default,
    ru: () => ru_default,
    sk: () => sk_default,
    sl: () => sl_default,
    sv: () => sv_default,
    ta: () => ta_default,
    tg: () => tg_default,
    th: () => th_default,
    tk: () => tk_default,
    tr: () => tr_default,
    ua: () => ua_default,
    uk: () => uk_default,
    ur: () => ur_default,
    uz: () => uz_default,
    vi: () => vi_default,
    yo: () => yo_default,
    zhCN: () => zh_CN_default,
    zhTW: () => zh_TW_default
  });

  // ../../../node_modules/zod/v4/locales/ar.js
  var error = () => {
    const Sizable = {
      string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
      file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
      array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
      set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
      map: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0645\u062F\u062E\u0644",
      email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
      url: "\u0631\u0627\u0628\u0637",
      emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
      date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
      time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
      duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
      ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
      ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
      mac: "\u0639\u0646\u0648\u0627\u0646 MAC",
      cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
      cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
      base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
      base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
      json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
      e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
      credit_card: "\u0631\u0642\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646",
      currency_code: "\u0631\u0645\u0632 \u0627\u0644\u0639\u0645\u0644\u0629",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0645\u062F\u062E\u0644"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${issue3.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${received}`;
          }
          return `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${expected2}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${issue3.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "\u0639\u0646\u0635\u0631"}`;
          return `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${issue3.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${issue3.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${adj} ${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${issue3.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${issue3.prefix}"`;
          if (_issue.format === "ends_with")
            return `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${_issue.pattern}`;
          return `${FormatDictionary[_issue.format] ?? issue3.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
        }
        case "not_multiple_of":
          return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u0645\u0639\u0631\u0641${issue3.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${issue3.keys.length > 1 ? "\u0629" : ""}: ${joinValues(issue3.keys, "\u060C ")}`;
        case "invalid_key":
          return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${issue3.origin}`;
        case "invalid_union":
          return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
        case "invalid_element":
          return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${issue3.origin}`;
        default:
          return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      }
    };
  };
  function ar_default() {
    return {
      localeError: error()
    };
  }

  // ../../../node_modules/zod/v4/locales/az.js
  var error2 = () => {
    const Sizable = {
      string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
      file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
      array: { unit: "element", verb: "olmal\u0131d\u0131r" },
      set: { unit: "element", verb: "olmal\u0131d\u0131r" },
      map: { unit: "element", verb: "olmal\u0131d\u0131r" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "email address",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datetime",
      date: "ISO date",
      time: "ISO time",
      duration: "ISO duration",
      ipv4: "IPv4 address",
      ipv6: "IPv6 address",
      mac: "MAC address",
      cidrv4: "IPv4 range",
      cidrv6: "IPv6 range",
      base64: "base64-encoded string",
      base64url: "base64url-encoded string",
      json_string: "JSON string",
      e164: "E.164 number",
      credit_card: "kredit kart\u0131 n\xF6mr\u0259si",
      currency_code: "valyuta kodu",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${issue3.expected}, daxil olan ${received}`;
          }
          return `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${expected2}, daxil olan ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${stringifyPrimitive(issue3.values[0])}`;
          return `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${issue3.origin ?? "d\u0259y\u0259r"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "element"}`;
          return `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${issue3.origin ?? "d\u0259y\u0259r"} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          return `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${issue3.origin} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Yanl\u0131\u015F m\u0259tn: "${_issue.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r`;
          if (_issue.format === "ends_with")
            return `Yanl\u0131\u015F m\u0259tn: "${_issue.suffix}" il\u0259 bitm\u0259lidir`;
          if (_issue.format === "includes")
            return `Yanl\u0131\u015F m\u0259tn: "${_issue.includes}" daxil olmal\u0131d\u0131r`;
          if (_issue.format === "regex")
            return `Yanl\u0131\u015F m\u0259tn: ${_issue.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r`;
          return `Yanl\u0131\u015F ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Yanl\u0131\u015F \u0259d\u0259d: ${issue3.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
        case "unrecognized_keys":
          return `Tan\u0131nmayan a\xE7ar${issue3.keys.length > 1 ? "lar" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
        case "invalid_union":
          return "Yanl\u0131\u015F d\u0259y\u0259r";
        case "invalid_element":
          return `${issue3.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
        default:
          return `Yanl\u0131\u015F d\u0259y\u0259r`;
      }
    };
  };
  function az_default() {
    return {
      localeError: error2()
    };
  }

  // ../../../node_modules/zod/v4/locales/be.js
  function getBelarusianPlural(count, one, few, many) {
    const absCount = Math.abs(count);
    const lastDigit = absCount % 10;
    const lastTwoDigits = absCount % 100;
    if (lastTwoDigits >= 11 && lastTwoDigits <= 19) {
      return many;
    }
    if (lastDigit === 1) {
      return one;
    }
    if (lastDigit >= 2 && lastDigit <= 4) {
      return few;
    }
    return many;
  }
  var error3 = () => {
    const Sizable = {
      string: {
        unit: {
          one: "\u0441\u0456\u043C\u0432\u0430\u043B",
          few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
          many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
        },
        verb: "\u043C\u0435\u0446\u044C"
      },
      array: {
        unit: {
          one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
          few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
          many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
        },
        verb: "\u043C\u0435\u0446\u044C"
      },
      set: {
        unit: {
          one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
          few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
          many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
        },
        verb: "\u043C\u0435\u0446\u044C"
      },
      map: {
        unit: {
          one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
          few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
          many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
        },
        verb: "\u043C\u0435\u0446\u044C"
      },
      file: {
        unit: {
          one: "\u0431\u0430\u0439\u0442",
          few: "\u0431\u0430\u0439\u0442\u044B",
          many: "\u0431\u0430\u0439\u0442\u0430\u045E"
        },
        verb: "\u043C\u0435\u0446\u044C"
      }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0443\u0432\u043E\u0434",
      email: "email \u0430\u0434\u0440\u0430\u0441",
      url: "URL",
      emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
      date: "ISO \u0434\u0430\u0442\u0430",
      time: "ISO \u0447\u0430\u0441",
      duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
      ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
      ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
      mac: "MAC \u0430\u0434\u0440\u0430\u0441",
      cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
      cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
      base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
      base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
      json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
      e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
      credit_card: "\u043D\u0443\u043C\u0430\u0440 \u043A\u0440\u044D\u0434\u044B\u0442\u043D\u0430\u0439 \u043A\u0430\u0440\u0442\u044B",
      currency_code: "\u043A\u043E\u0434 \u0432\u0430\u043B\u044E\u0442\u044B",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0443\u0432\u043E\u0434"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u043B\u0456\u043A",
      array: "\u043C\u0430\u0441\u0456\u045E"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${issue3.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${received}`;
          }
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${expected2}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${stringifyPrimitive(issue3.values[0])}`;
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            const maxValue = Number(issue3.maximum);
            const unit = getBelarusianPlural(maxValue, sizing.unit.one, sizing.unit.few, sizing.unit.many);
            return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${issue3.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${sizing.verb} ${adj}${issue3.maximum.toString()} ${unit}`;
          }
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${issue3.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            const minValue = Number(issue3.minimum);
            const unit = getBelarusianPlural(minValue, sizing.unit.one, sizing.unit.few, sizing.unit.many);
            return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${issue3.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${sizing.verb} ${adj}${issue3.minimum.toString()} ${unit}`;
          }
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${issue3.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${_issue.pattern}`;
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${issue3.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${issue3.origin}`;
        case "invalid_union":
          return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
        case "invalid_element":
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${issue3.origin}`;
        default:
          return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434`;
      }
    };
  };
  function be_default() {
    return {
      localeError: error3()
    };
  }

  // ../../../node_modules/zod/v4/locales/bg.js
  var error4 = () => {
    const Sizable = {
      string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
      file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
      array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
      set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
      map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0432\u0445\u043E\u0434",
      email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
      url: "URL",
      emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
      date: "ISO \u0434\u0430\u0442\u0430",
      time: "ISO \u0432\u0440\u0435\u043C\u0435",
      duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
      ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
      ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
      mac: "MAC \u0430\u0434\u0440\u0435\u0441",
      cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
      cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
      base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
      base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
      json_string: "JSON \u043D\u0438\u0437",
      e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
      credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0430",
      currency_code: "\u043A\u043E\u0434 \u043D\u0430 \u0432\u0430\u043B\u0443\u0442\u0430",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0432\u0445\u043E\u0434"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0447\u0438\u0441\u043B\u043E",
      array: "\u043C\u0430\u0441\u0438\u0432"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${issue3.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${received}`;
          }
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${expected2}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${stringifyPrimitive(issue3.values[0])}`;
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${issue3.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}`;
          return `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${issue3.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${issue3.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${issue3.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${_issue.pattern}`;
          let invalid_adj = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
          if (_issue.format === "emoji")
            invalid_adj = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E";
          if (_issue.format === "datetime")
            invalid_adj = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E";
          if (_issue.format === "date")
            invalid_adj = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430";
          if (_issue.format === "time")
            invalid_adj = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E";
          if (_issue.format === "duration")
            invalid_adj = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430";
          return `${invalid_adj} ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${issue3.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${issue3.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${issue3.origin}`;
        case "invalid_union":
          return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
        case "invalid_element":
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${issue3.origin}`;
        default:
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434`;
      }
    };
  };
  function bg_default() {
    return {
      localeError: error4()
    };
  }

  // ../../../node_modules/zod/v4/locales/bn.js
  var error5 = () => {
    const Sizable = {
      string: { unit: "\u0985\u0995\u09CD\u09B7\u09B0", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
      file: { unit: "\u09AC\u09BE\u0987\u099F", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
      array: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
      set: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
      map: { unit: "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0987\u09A8\u09AA\u09C1\u099F",
      email: "\u0987\u09AE\u09C7\u0987\u09B2 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
      url: "URL",
      emoji: "\u0987\u09AE\u09CB\u099C\u09BF",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u09A4\u09BE\u09B0\u09BF\u0996 \u0993 \u09B8\u09AE\u09AF\u09BC",
      date: "ISO \u09A4\u09BE\u09B0\u09BF\u0996",
      time: "ISO \u09B8\u09AE\u09AF\u09BC",
      duration: "ISO \u09B8\u09AE\u09AF\u09BC\u0995\u09BE\u09B2",
      ipv4: "IPv4 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
      ipv6: "IPv6 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
      mac: "MAC \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
      cidrv4: "IPv4 \u09B0\u09C7\u099E\u09CD\u099C",
      cidrv6: "IPv6 \u09B0\u09C7\u099E\u09CD\u099C",
      base64: "base64-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
      base64url: "base64url-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
      json_string: "JSON \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
      e164: "E.164 \u09A8\u09AE\u09CD\u09AC\u09B0",
      credit_card: "\u0995\u09CD\u09B0\u09C7\u09A1\u09BF\u099F \u0995\u09BE\u09B0\u09CD\u09A1 \u09A8\u09AE\u09CD\u09AC\u09B0",
      currency_code: "\u09AE\u09C1\u09A6\u09CD\u09B0\u09BE \u0995\u09CB\u09A1",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0987\u09A8\u09AA\u09C1\u099F"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${expected2}, \u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0985\u09AC\u09C8\u09A7 \u0985\u09AA\u09B6\u09A8: ${joinValues(issue3.values, " | ")} \u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${issue3.origin ?? "\u09AE\u09BE\u09A8"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u098F\u09B2\u09BF\u09AE\u09C7\u09A8\u09CD\u099F"} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
          return `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${issue3.origin ?? "\u09AE\u09BE\u09A8"} ${adj}${issue3.maximum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
          }
          return `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${issue3.origin} ${adj}${issue3.minimum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${_issue.prefix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
          }
          if (_issue.format === "ends_with")
            return `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${_issue.suffix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C7\u09B7 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
          if (_issue.format === "includes")
            return `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${_issue.includes}" \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7`;
          if (_issue.format === "regex")
            return `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: ${_issue.pattern} \u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8 \u09AE\u09BF\u09B2\u09A4\u09C7 \u09B9\u09AC\u09C7`;
          return `\u0985\u09AC\u09C8\u09A7 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0985\u09AC\u09C8\u09A7 \u09A8\u09AE\u09CD\u09AC\u09B0: ${issue3.divisor} \u098F\u09B0 \u0997\u09C1\u09A3\u09BF\u09A4\u0995 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
        case "unrecognized_keys":
          return `\u0985\u099A\u09C7\u09A8\u09BE \u0995\u09C0${issue3.keys.length > 1 ? "\u0997\u09C1\u09B2\u09CB" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u0995\u09C0`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u0985\u09AC\u09C8\u09A7 \u09A1\u09BF\u09B8\u0995\u09CD\u09B0\u09BF\u09AE\u09BF\u09A8\u09C7\u099F\u09B0 \u09AE\u09BE\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${opts}`;
          }
          return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
        case "invalid_element":
          return `${issue3.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u09AE\u09BE\u09A8`;
        default:
          return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
      }
    };
  };
  function bn_default() {
    return {
      localeError: error5()
    };
  }

  // ../../../node_modules/zod/v4/locales/ca.js
  var error6 = () => {
    const Sizable = {
      string: { unit: "car\xE0cters", verb: "contenir" },
      file: { unit: "bytes", verb: "contenir" },
      array: { unit: "elements", verb: "contenir" },
      set: { unit: "elements", verb: "contenir" },
      map: { unit: "elements", verb: "contenir" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "entrada",
      email: "adre\xE7a electr\xF2nica",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data i hora ISO",
      date: "data ISO",
      time: "hora ISO",
      duration: "durada ISO",
      ipv4: "adre\xE7a IPv4",
      ipv6: "adre\xE7a IPv6",
      mac: "adre\xE7a MAC",
      cidrv4: "rang IPv4",
      cidrv6: "rang IPv6",
      base64: "cadena codificada en base64",
      base64url: "cadena codificada en base64url",
      json_string: "cadena JSON",
      e164: "n\xFAmero E.164",
      credit_card: "n\xFAmero de targeta de cr\xE8dit",
      currency_code: "codi de moneda",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "entrada"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Tipus inv\xE0lid: s'esperava instanceof ${issue3.expected}, s'ha rebut ${received}`;
          }
          return `Tipus inv\xE0lid: s'esperava ${expected2}, s'ha rebut ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Valor inv\xE0lid: s'esperava ${stringifyPrimitive(issue3.values[0])}`;
          return `Opci\xF3 inv\xE0lida: s'esperava una de ${joinValues(issue3.values, " o ")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "com a m\xE0xim" : "menys de";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Massa gran: s'esperava que ${issue3.origin ?? "el valor"} contingu\xE9s ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "elements"}`;
          return `Massa gran: s'esperava que ${issue3.origin ?? "el valor"} fos ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? "com a m\xEDnim" : "m\xE9s de";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Massa petit: s'esperava que ${issue3.origin} contingu\xE9s ${adj} ${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Massa petit: s'esperava que ${issue3.origin} fos ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Format inv\xE0lid: ha de comen\xE7ar amb "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Format inv\xE0lid: ha d'acabar amb "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Format inv\xE0lid: ha d'incloure "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${_issue.pattern}`;
          return `Format inv\xE0lid per a ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Clau${issue3.keys.length > 1 ? "s" : ""} no reconeguda${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Clau inv\xE0lida a ${issue3.origin}`;
        case "invalid_union":
          return "Entrada inv\xE0lida";
        // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
        case "invalid_element":
          return `Element inv\xE0lid a ${issue3.origin}`;
        default:
          return `Entrada inv\xE0lida`;
      }
    };
  };
  function ca_default() {
    return {
      localeError: error6()
    };
  }

  // ../../../node_modules/zod/v4/locales/ckb.js
  var error7 = () => {
    const Sizable = {
      string: { unit: "\u067E\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
      file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
      array: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
      set: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
      map: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "regex",
      email: "\u0626\u06CC\u0645\u06D5\u06CC\u06B5",
      url: "\u0628\u06D5\u0633\u062A\u06D5\u0631 (URL)",
      emoji: "\u0626\u06CC\u0645\u06C6\u062C\u06CC",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u0695\u06CE\u06A9\u06D5\u0648\u062A \u0648 \u06A9\u0627\u062A",
      date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
      time: "\u06A9\u0627\u062A",
      duration: "\u0645\u0627\u0648\u06D5",
      ipv4: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv4",
      ipv6: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv6",
      mac: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC MAC",
      cidrv4: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv4",
      cidrv6: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv6",
      base64: "\u062F\u06D5\u0642\u06CC base64",
      base64url: "\u062F\u06D5\u0642\u06CC base64url",
      json_string: "\u062F\u06D5\u0642\u06CC JSON",
      e164: "\u0698\u0645\u0627\u0631\u06D5\u06CC E.164",
      credit_card: "\u0698\u0645\u0627\u0631\u06D5\u06CC \u06A9\u0627\u0631\u062A\u06CC \u06A9\u0631\u06CE\u062F\u06CC\u062A",
      currency_code: "\u06A9\u06C6\u062F\u06CC \u062F\u0631\u0627\u0648",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u062A\u06CE\u06A9\u0631\u062F\u06D5"
    };
    const TypeDictionary = {
      nan: "NaN",
      string: "\u0646\u0648\u0648\u0633\u06CC\u0646",
      number: "\u0698\u0645\u0627\u0631\u06D5",
      boolean: "boolean",
      array: "array",
      object: "object",
      date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
      integer: "\u0698\u0645\u0627\u0631\u06D5",
      float: "\u0698\u0645\u0627\u0631\u06D5",
      null: "null",
      undefined: "undefined",
      function: "function",
      symbol: "symbol",
      unknown: "unknown",
      promise: "promise",
      void: "void",
      never: "never",
      map: "map",
      set: "set"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          const postfix = ["\u0627", "\u0648", "\u06C6", "\u0648\u0648", "\u06D5", "\u06CC", "\u06CE"].some((p) => received.endsWith(p)) ? "\u06CC\u06D5" : "\u06D5";
          const isEnglish = /^[a-zA-Z]+$/.test(received);
          if (receivedType === "null" || receivedType === "undefined")
            return `\u062F\u0627\u0648\u0627\u06A9\u0631\u0627\u0648\u06D5`;
          return `\u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${expected2} \u0628\u06CE\u062A\u060C \u0628\u06D5\u06B5\u0627\u0645 ${received}${isEnglish ? "" : postfix}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0648\u0633\u062A\u06D5: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${stringifyPrimitive(issue3.values[0])} \u0628\u06CE\u062A`;
          return `\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 \u06CC\u06D5\u06A9\u06CE\u06A9 \u0628\u06CE\u062A \u0644\u06D5 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${issue3.maximum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${issue3.maximum.toString()} \u0628\u06CE\u062A`;
        }
        case "too_small": {
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${issue3.minimum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${issue3.minimum.toString()} \u0628\u06CE\u062A`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u062F\u06D5\u0633\u062A\u067E\u06CE\u0628\u06A9\u0627\u062A \u0628\u06D5 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u06A9\u06C6\u062A\u0627\u06CC\u06CC\u0628\u06CE\u062A \u0628\u06D5 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 "${_issue.includes}" \u0644\u06D5\u062E\u06C6\u0628\u06AF\u0631\u06CE\u062A`;
          if (_issue.format === "regex")
            return `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0644\u06D5\u06AF\u06D5\u06B5 \u067E\u0627\u062A\u06CE\u0631\u0646\u06CC ${_issue.pattern} \u0628\u06AF\u0648\u0646\u062C\u06CE\u062A`;
          return `\u0628\u06D5\u0647\u0627\u06CC ${FormatDictionary[_issue.format] ?? issue3.format} \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
        }
        case "not_multiple_of":
          return `\u0698\u0645\u0627\u0631\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u062F\u06D5\u0628\u06CE\u062A \u0686\u06D5\u0646\u062F \u0647\u06CE\u0646\u062F\u06D5 \u0628\u06CE\u062A \u0628\u06C6 ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A \u0644\u06D5 ${issue3.origin}`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u0628\u06D5\u0647\u0627\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648 \u0647\u06D5\u06CC\u06D5. \u0628\u06D5\u0647\u0627\u06CC \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648: ${opts}`;
          }
          return "\u06CC\u06D5\u06A9\u06AF\u0631\u062A\u0646\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
        case "invalid_element":
          return `${issue3.origin} \u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
        default:
          return `\u062A\u06CE\u06A9\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A`;
      }
    };
  };
  function ckb_default() {
    return {
      localeError: error7()
    };
  }

  // ../../../node_modules/zod/v4/locales/cs.js
  var error8 = () => {
    const Sizable = {
      string: { unit: "znak\u016F", verb: "m\xEDt" },
      file: { unit: "bajt\u016F", verb: "m\xEDt" },
      array: { unit: "prvk\u016F", verb: "m\xEDt" },
      set: { unit: "prvk\u016F", verb: "m\xEDt" },
      map: { unit: "prvk\u016F", verb: "m\xEDt" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "regul\xE1rn\xED v\xFDraz",
      email: "e-mailov\xE1 adresa",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "datum a \u010Das ve form\xE1tu ISO",
      date: "datum ve form\xE1tu ISO",
      time: "\u010Das ve form\xE1tu ISO",
      duration: "doba trv\xE1n\xED ISO",
      ipv4: "IPv4 adresa",
      ipv6: "IPv6 adresa",
      mac: "MAC adresa",
      cidrv4: "rozsah IPv4",
      cidrv6: "rozsah IPv6",
      base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
      base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
      json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
      e164: "\u010D\xEDslo E.164",
      credit_card: "\u010D\xEDslo kreditn\xED karty",
      currency_code: "k\xF3d m\u011Bny",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "vstup"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u010D\xEDslo",
      string: "\u0159et\u011Bzec",
      function: "funkce",
      array: "pole"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${issue3.expected}, obdr\u017Eeno ${received}`;
          }
          return `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${expected2}, obdr\u017Eeno ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${stringifyPrimitive(issue3.values[0])}`;
          return `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${issue3.origin ?? "hodnota"} mus\xED m\xEDt ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "prvk\u016F"}`;
          }
          return `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${issue3.origin ?? "hodnota"} mus\xED b\xFDt ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${issue3.origin ?? "hodnota"} mus\xED m\xEDt ${adj}${issue3.minimum.toString()} ${sizing.unit ?? "prvk\u016F"}`;
          }
          return `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${issue3.origin ?? "hodnota"} mus\xED b\xFDt ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${_issue.pattern}`;
          return `Neplatn\xFD form\xE1t ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Nezn\xE1m\xE9 kl\xED\u010De: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Neplatn\xFD kl\xED\u010D v ${issue3.origin}`;
        case "invalid_union":
          return "Neplatn\xFD vstup";
        case "invalid_element":
          return `Neplatn\xE1 hodnota v ${issue3.origin}`;
        default:
          return `Neplatn\xFD vstup`;
      }
    };
  };
  function cs_default() {
    return {
      localeError: error8()
    };
  }

  // ../../../node_modules/zod/v4/locales/da.js
  var error9 = () => {
    const Sizable = {
      string: { unit: "tegn", verb: "havde" },
      file: { unit: "bytes", verb: "havde" },
      array: { unit: "elementer", verb: "indeholdt" },
      set: { unit: "elementer", verb: "indeholdt" },
      map: { unit: "elementer", verb: "indeholdt" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "e-mailadresse",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dato- og klokkesl\xE6t",
      date: "ISO-dato",
      time: "ISO-klokkesl\xE6t",
      duration: "ISO-varighed",
      ipv4: "IPv4-adresse",
      ipv6: "IPv6-adresse",
      mac: "MAC-adresse",
      cidrv4: "IPv4-spektrum",
      cidrv6: "IPv6-spektrum",
      base64: "base64-kodet streng",
      base64url: "base64url-kodet streng",
      json_string: "JSON-streng",
      e164: "E.164-nummer",
      credit_card: "kreditkortnummer",
      currency_code: "valutakode",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN",
      string: "streng",
      number: "tal",
      boolean: "boolean",
      array: "liste",
      object: "objekt",
      set: "s\xE6t",
      file: "fil"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ugyldigt input: forventede instanceof ${issue3.expected}, fik ${received}`;
          }
          return `Ugyldigt input: forventede ${expected2}, fik ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ugyldig v\xE6rdi: forventede ${stringifyPrimitive(issue3.values[0])}`;
          return `Ugyldigt valg: forventede en af f\xF8lgende ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          if (sizing)
            return `For stor: forventede ${origin ?? "value"} ${sizing.verb} ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "elementer"}`;
          return `For stor: forventede ${origin ?? "value"} havde ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          if (sizing) {
            return `For lille: forventede ${origin} ${sizing.verb} ${adj} ${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `For lille: forventede ${origin} havde ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Ugyldig streng: skal starte med "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Ugyldig streng: skal ende med "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Ugyldig streng: skal indeholde "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Ugyldig streng: skal matche m\xF8nsteret ${_issue.pattern}`;
          return `Ugyldig ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ugyldigt tal: skal v\xE6re deleligt med ${issue3.divisor}`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Ugyldig n\xF8gle i ${issue3.origin}`;
        case "invalid_union":
          return "Ugyldigt input: matcher ingen af de tilladte typer";
        case "invalid_element":
          return `Ugyldig v\xE6rdi i ${issue3.origin}`;
        default:
          return `Ugyldigt input`;
      }
    };
  };
  function da_default() {
    return {
      localeError: error9()
    };
  }

  // ../../../node_modules/zod/v4/locales/de.js
  var error10 = () => {
    const Sizable = {
      string: { unit: "Zeichen", verb: "zu haben" },
      file: { unit: "Bytes", verb: "zu haben" },
      array: { unit: "Elemente", verb: "zu haben" },
      set: { unit: "Elemente", verb: "zu haben" },
      map: { unit: "Elemente", verb: "zu haben" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "Eingabe",
      email: "E-Mail-Adresse",
      url: "URL",
      emoji: "Emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-Datum und -Uhrzeit",
      date: "ISO-Datum",
      time: "ISO-Uhrzeit",
      duration: "ISO-Dauer",
      ipv4: "IPv4-Adresse",
      ipv6: "IPv6-Adresse",
      mac: "MAC-Adresse",
      cidrv4: "IPv4-Bereich",
      cidrv6: "IPv6-Bereich",
      base64: "Base64-codierter String",
      base64url: "Base64-URL-codierter String",
      json_string: "JSON-String",
      e164: "E.164-Nummer",
      credit_card: "Kreditkartennummer",
      currency_code: "W\xE4hrungscode",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "Eingabe"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "Zahl",
      array: "Array"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ung\xFCltige Eingabe: erwartet instanceof ${issue3.expected}, erhalten ${received}`;
          }
          return `Ung\xFCltige Eingabe: erwartet ${expected2}, erhalten ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ung\xFCltige Eingabe: erwartet ${stringifyPrimitive(issue3.values[0])}`;
          return `Ung\xFCltige Option: erwartet eine von ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Zu gro\xDF: erwartet, dass ${issue3.origin ?? "Wert"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "Elemente"} hat`;
          return `Zu gro\xDF: erwartet, dass ${issue3.origin ?? "Wert"} ${adj}${issue3.maximum.toString()} ist`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Zu klein: erwartet, dass ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit} hat`;
          }
          return `Zu klein: erwartet, dass ${issue3.origin} ${adj}${issue3.minimum.toString()} ist`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Ung\xFCltiger String: muss mit "${_issue.prefix}" beginnen`;
          if (_issue.format === "ends_with")
            return `Ung\xFCltiger String: muss mit "${_issue.suffix}" enden`;
          if (_issue.format === "includes")
            return `Ung\xFCltiger String: muss "${_issue.includes}" enthalten`;
          if (_issue.format === "regex")
            return `Ung\xFCltiger String: muss dem Muster ${_issue.pattern} entsprechen`;
          return `Ung\xFCltig: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ung\xFCltige Zahl: muss ein Vielfaches von ${issue3.divisor} sein`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Ung\xFCltiger Schl\xFCssel in ${issue3.origin}`;
        case "invalid_union":
          return "Ung\xFCltige Eingabe";
        case "invalid_element":
          return `Ung\xFCltiger Wert in ${issue3.origin}`;
        default:
          return `Ung\xFCltige Eingabe`;
      }
    };
  };
  function de_default() {
    return {
      localeError: error10()
    };
  }

  // ../../../node_modules/zod/v4/locales/el.js
  var error11 = () => {
    const Sizable = {
      string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
      file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
      array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
      set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
      map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
      email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
      date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
      time: "ISO \u03CE\u03C1\u03B1",
      duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
      ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
      ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
      mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
      cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
      cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
      base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
      base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
      json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
      e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
      credit_card: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 \u03C0\u03B9\u03C3\u03C4\u03C9\u03C4\u03B9\u03BA\u03AE\u03C2 \u03BA\u03AC\u03C1\u03C4\u03B1\u03C2",
      currency_code: "\u03BA\u03C9\u03B4\u03B9\u03BA\u03CC\u03C2 \u03BD\u03BF\u03BC\u03AF\u03C3\u03BC\u03B1\u03C4\u03BF\u03C2",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (typeof issue3.expected === "string" && /^[A-Z]/.test(issue3.expected)) {
            return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${issue3.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${received}`;
          }
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${expected2}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${stringifyPrimitive(issue3.values[0])}`;
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${issue3.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}`;
          return `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${issue3.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${issue3.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${issue3.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${_issue.pattern}`;
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${issue3.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${issue3.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${issue3.origin}`;
        case "invalid_union":
          return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
        case "invalid_element":
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${issue3.origin}`;
        default:
          return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2`;
      }
    };
  };
  function el_default() {
    return {
      localeError: error11()
    };
  }

  // ../../../node_modules/zod/v4/locales/en.js
  var error12 = () => {
    const Sizable = {
      string: { unit: "characters", verb: "to have" },
      file: { unit: "bytes", verb: "to have" },
      array: { unit: "items", verb: "to have" },
      set: { unit: "items", verb: "to have" },
      map: { unit: "entries", verb: "to have" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "email address",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datetime",
      date: "ISO date",
      time: "ISO time",
      duration: "ISO duration",
      ipv4: "IPv4 address",
      ipv6: "IPv6 address",
      mac: "MAC address",
      cidrv4: "IPv4 range",
      cidrv6: "IPv6 range",
      base64: "base64-encoded string",
      base64url: "base64url-encoded string",
      json_string: "JSON string",
      e164: "E.164 number",
      currency_code: "currency code",
      credit_card: "credit card number",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      // Compatibility: "nan" -> "NaN" for display
      nan: "NaN"
      // All other type names omitted - they fall back to raw values via ?? operator
    };
    function getTypeName(type, input2) {
      if (type === "number" && typeof input2 === "number" && !Number.isFinite(input2)) {
        return String(input2);
      }
      return TypeDictionary[type] ?? type;
    }
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = getTypeName(issue3.expected);
          const receivedType = parsedType(issue3.input);
          const received = getTypeName(receivedType, issue3.input);
          return `Invalid input: expected ${expected2}, received ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Invalid input: expected ${stringifyPrimitive(issue3.values[0])}`;
          return `Invalid option: expected one of ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.exact ? "exactly " : issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Too big: expected ${issue3.origin ?? "value"} to have ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elements"}`;
          return `Too big: expected ${issue3.origin ?? "value"} to be ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.exact ? "exactly " : issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Too small: expected ${issue3.origin} to have ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Too small: expected ${issue3.origin} to be ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Invalid string: must start with "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Invalid string: must end with "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Invalid string: must include "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Invalid string: must match pattern ${_issue.pattern}`;
          return `Invalid ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Invalid number: must be a multiple of ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Unrecognized key${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Invalid key in ${issue3.origin}`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `Invalid discriminator value. Expected ${opts}`;
          }
          if (issue3.inclusive === false) {
            return "Invalid input: more than one option matched";
          }
          return "Invalid input";
        case "invalid_element":
          return `Invalid value in ${issue3.origin}`;
        default:
          return `Invalid input`;
      }
    };
  };
  function en_default() {
    return {
      localeError: error12()
    };
  }

  // ../../../node_modules/zod/v4/locales/eo.js
  var error13 = () => {
    const Sizable = {
      string: { unit: "karaktrojn", verb: "havi" },
      file: { unit: "bajtojn", verb: "havi" },
      array: { unit: "elementojn", verb: "havi" },
      set: { unit: "elementojn", verb: "havi" },
      map: { unit: "elementojn", verb: "havi" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "enigo",
      email: "retadreso",
      url: "URL",
      emoji: "emo\u011Dio",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-datotempo",
      date: "ISO-dato",
      time: "ISO-tempo",
      duration: "ISO-da\u016Dro",
      ipv4: "IPv4-adreso",
      ipv6: "IPv6-adreso",
      mac: "MAC-adreso",
      cidrv4: "IPv4-rango",
      cidrv6: "IPv6-rango",
      base64: "64-ume kodita karaktraro",
      base64url: "URL-64-ume kodita karaktraro",
      json_string: "JSON-karaktraro",
      e164: "E.164-nombro",
      credit_card: "kreditkarta numero",
      currency_code: "valuta kodo",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "enigo"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "nombro",
      array: "tabelo",
      null: "senvalora"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Nevalida enigo: atendi\u011Dis instanceof ${issue3.expected}, ricevi\u011Dis ${received}`;
          }
          return `Nevalida enigo: atendi\u011Dis ${expected2}, ricevi\u011Dis ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Nevalida enigo: atendi\u011Dis ${stringifyPrimitive(issue3.values[0])}`;
          return `Nevalida opcio: atendi\u011Dis unu el ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Tro granda: atendi\u011Dis ke ${issue3.origin ?? "valoro"} havu ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elementojn"}`;
          return `Tro granda: atendi\u011Dis ke ${issue3.origin ?? "valoro"} havu ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Tro malgranda: atendi\u011Dis ke ${issue3.origin} havu ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Tro malgranda: atendi\u011Dis ke ${issue3.origin} estu ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Nevalida karaktraro: devas komenci\u011Di per "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Nevalida karaktraro: devas fini\u011Di per "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Nevalida karaktraro: devas inkluzivi "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Nevalida karaktraro: devas kongrui kun la modelo ${_issue.pattern}`;
          return `Nevalida ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Nevalida nombro: devas esti oblo de ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Nekonata${issue3.keys.length > 1 ? "j" : ""} \u015Dlosilo${issue3.keys.length > 1 ? "j" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Nevalida \u015Dlosilo en ${issue3.origin}`;
        case "invalid_union":
          return "Nevalida enigo";
        case "invalid_element":
          return `Nevalida valoro en ${issue3.origin}`;
        default:
          return `Nevalida enigo`;
      }
    };
  };
  function eo_default() {
    return {
      localeError: error13()
    };
  }

  // ../../../node_modules/zod/v4/locales/es.js
  var error14 = () => {
    const Sizable = {
      string: { unit: "caracteres", verb: "tener" },
      file: { unit: "bytes", verb: "tener" },
      array: { unit: "elementos", verb: "tener" },
      set: { unit: "elementos", verb: "tener" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "entrada",
      email: "direcci\xF3n de correo electr\xF3nico",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "fecha y hora ISO",
      date: "fecha ISO",
      time: "hora ISO",
      duration: "duraci\xF3n ISO",
      ipv4: "direcci\xF3n IPv4",
      ipv6: "direcci\xF3n IPv6",
      mac: "direcci\xF3n MAC",
      cidrv4: "rango IPv4",
      cidrv6: "rango IPv6",
      base64: "cadena codificada en base64",
      base64url: "URL codificada en base64",
      json_string: "cadena JSON",
      e164: "n\xFAmero E.164",
      credit_card: "n\xFAmero de tarjeta de cr\xE9dito",
      currency_code: "c\xF3digo de moneda",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "entrada"
    };
    const TypeDictionary = {
      nan: "NaN",
      string: "texto",
      number: "n\xFAmero",
      boolean: "booleano",
      array: "arreglo",
      object: "objeto",
      set: "conjunto",
      file: "archivo",
      date: "fecha",
      bigint: "n\xFAmero grande",
      symbol: "s\xEDmbolo",
      undefined: "indefinido",
      null: "nulo",
      function: "funci\xF3n",
      map: "mapa",
      record: "registro",
      tuple: "tupla",
      enum: "enumeraci\xF3n",
      union: "uni\xF3n",
      literal: "literal",
      promise: "promesa",
      void: "vac\xEDo",
      never: "nunca",
      unknown: "desconocido",
      any: "cualquiera"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Entrada inv\xE1lida: se esperaba instanceof ${issue3.expected}, recibido ${received}`;
          }
          return `Entrada inv\xE1lida: se esperaba ${expected2}, recibido ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Entrada inv\xE1lida: se esperaba ${stringifyPrimitive(issue3.values[0])}`;
          return `Opci\xF3n inv\xE1lida: se esperaba una de ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          if (sizing)
            return `Demasiado grande: se esperaba que ${origin ?? "valor"} tuviera ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elementos"}`;
          return `Demasiado grande: se esperaba que ${origin ?? "valor"} fuera ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          if (sizing) {
            return `Demasiado peque\xF1o: se esperaba que ${origin} tuviera ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Demasiado peque\xF1o: se esperaba que ${origin} fuera ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Cadena inv\xE1lida: debe comenzar con "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Cadena inv\xE1lida: debe terminar en "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Cadena inv\xE1lida: debe incluir "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${_issue.pattern}`;
          return `Inv\xE1lido ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Llave${issue3.keys.length > 1 ? "s" : ""} desconocida${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Llave inv\xE1lida en ${TypeDictionary[issue3.origin] ?? issue3.origin}`;
        case "invalid_union":
          return "Entrada inv\xE1lida";
        case "invalid_element":
          return `Valor inv\xE1lido en ${TypeDictionary[issue3.origin] ?? issue3.origin}`;
        default:
          return `Entrada inv\xE1lida`;
      }
    };
  };
  function es_default() {
    return {
      localeError: error14()
    };
  }

  // ../../../node_modules/zod/v4/locales/fa.js
  var error15 = () => {
    const Sizable = {
      string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
      file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
      array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
      set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
      map: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0648\u0631\u0648\u062F\u06CC",
      email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
      url: "URL",
      emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
      date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
      time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
      duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
      ipv4: "IPv4 \u0622\u062F\u0631\u0633",
      ipv6: "IPv6 \u0622\u062F\u0631\u0633",
      mac: "MAC \u0622\u062F\u0631\u0633",
      cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
      cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
      base64: "base64-encoded \u0631\u0634\u062A\u0647",
      base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
      json_string: "JSON \u0631\u0634\u062A\u0647",
      e164: "E.164 \u0639\u062F\u062F",
      credit_card: "\u0634\u0645\u0627\u0631\u0647 \u06A9\u0627\u0631\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u06CC",
      currency_code: "\u06A9\u062F \u0627\u0631\u0632",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0648\u0631\u0648\u062F\u06CC"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0639\u062F\u062F",
      array: "\u0622\u0631\u0627\u06CC\u0647"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${issue3.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${received} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
          }
          return `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${expected2} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${received} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
        }
        case "invalid_value":
          if (issue3.values.length === 1) {
            return `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${stringifyPrimitive(issue3.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F`;
          }
          return `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${joinValues(issue3.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${issue3.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F`;
          }
          return `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${issue3.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${adj}${issue3.maximum.toString()} \u0628\u0627\u0634\u062F`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${issue3.origin} \u0628\u0627\u06CC\u062F ${adj}${issue3.minimum.toString()} ${sizing.unit} \u0628\u0627\u0634\u062F`;
          }
          return `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${issue3.origin} \u0628\u0627\u06CC\u062F ${adj}${issue3.minimum.toString()} \u0628\u0627\u0634\u062F`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${_issue.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F`;
          }
          if (_issue.format === "ends_with") {
            return `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${_issue.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F`;
          }
          if (_issue.format === "includes") {
            return `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${_issue.includes}" \u0628\u0627\u0634\u062F`;
          }
          if (_issue.format === "regex") {
            return `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${_issue.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F`;
          }
          return `${FormatDictionary[_issue.format] ?? issue3.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
        }
        case "not_multiple_of":
          return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${issue3.divisor} \u0628\u0627\u0634\u062F`;
        case "unrecognized_keys":
          return `\u06A9\u0644\u06CC\u062F${issue3.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${issue3.origin}`;
        case "invalid_union":
          return `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
        case "invalid_element":
          return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${issue3.origin}`;
        default:
          return `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
    };
  };
  function fa_default() {
    return {
      localeError: error15()
    };
  }

  // ../../../node_modules/zod/v4/locales/fi.js
  var error16 = () => {
    const Sizable = {
      string: { unit: "merkki\xE4", subject: "merkkijonon" },
      file: { unit: "tavua", subject: "tiedoston" },
      array: { unit: "alkiota", subject: "listan" },
      set: { unit: "alkiota", subject: "joukon" },
      map: { unit: "alkiota", subject: "kuvauksen" },
      number: { unit: "", subject: "luvun" },
      bigint: { unit: "", subject: "suuren kokonaisluvun" },
      int: { unit: "", subject: "kokonaisluvun" },
      date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "s\xE4\xE4nn\xF6llinen lauseke",
      email: "s\xE4hk\xF6postiosoite",
      url: "URL-osoite",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-aikaleima",
      date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
      time: "ISO-aika",
      duration: "ISO-kesto",
      ipv4: "IPv4-osoite",
      ipv6: "IPv6-osoite",
      mac: "MAC-osoite",
      cidrv4: "IPv4-alue",
      cidrv6: "IPv6-alue",
      base64: "base64-koodattu merkkijono",
      base64url: "base64url-koodattu merkkijono",
      json_string: "JSON-merkkijono",
      e164: "E.164-luku",
      credit_card: "luottokortin numero",
      currency_code: "valuuttakoodi",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "templaattimerkkijono"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Virheellinen tyyppi: odotettiin instanceof ${issue3.expected}, oli ${received}`;
          }
          return `Virheellinen tyyppi: odotettiin ${expected2}, oli ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Virheellinen sy\xF6te: t\xE4ytyy olla ${stringifyPrimitive(issue3.values[0])}`;
          return `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Liian suuri: ${sizing.subject} t\xE4ytyy olla ${adj}${issue3.maximum.toString()} ${sizing.unit}`.trim();
          }
          return `Liian suuri: arvon t\xE4ytyy olla ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Liian pieni: ${sizing.subject} t\xE4ytyy olla ${adj}${issue3.minimum.toString()} ${sizing.unit}`.trim();
          }
          return `Liian pieni: arvon t\xE4ytyy olla ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Virheellinen sy\xF6te: t\xE4ytyy loppua "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${_issue.includes}"`;
          if (_issue.format === "regex") {
            return `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${_issue.pattern}`;
          }
          return `Virheellinen ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Virheellinen luku: t\xE4ytyy olla luvun ${issue3.divisor} monikerta`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return "Virheellinen avain tietueessa";
        case "invalid_union":
          return "Virheellinen unioni";
        case "invalid_element":
          return "Virheellinen arvo joukossa";
        default:
          return `Virheellinen sy\xF6te`;
      }
    };
  };
  function fi_default() {
    return {
      localeError: error16()
    };
  }

  // ../../../node_modules/zod/v4/locales/fr.js
  var error17 = () => {
    const Sizable = {
      string: { unit: "caract\xE8res", verb: "avoir" },
      file: { unit: "octets", verb: "avoir" },
      array: { unit: "\xE9l\xE9ments", verb: "avoir" },
      set: { unit: "\xE9l\xE9ments", verb: "avoir" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "expression r\xE9guli\xE8re",
      email: "adresse e-mail",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "date et heure ISO",
      date: "date ISO",
      time: "heure ISO",
      duration: "dur\xE9e ISO",
      ipv4: "adresse IPv4",
      ipv6: "adresse IPv6",
      mac: "adresse MAC",
      cidrv4: "plage IPv4",
      cidrv6: "plage IPv6",
      base64: "cha\xEEne de caract\xE8res encod\xE9e en base64",
      base64url: "cha\xEEne de caract\xE8res encod\xE9e en base64url",
      json_string: "cha\xEEne de caract\xE8res JSON",
      e164: "num\xE9ro au format E.164",
      credit_card: "num\xE9ro de carte de cr\xE9dit",
      currency_code: "code de devise",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "entr\xE9e"
    };
    const TypeDictionary = {
      string: "cha\xEEne de caract\xE8res",
      number: "nombre",
      int: "entier",
      boolean: "bool\xE9en",
      bigint: "grand entier",
      symbol: "symbole",
      undefined: "ind\xE9fini",
      null: "null",
      never: "jamais",
      void: "vide",
      date: "date",
      array: "tableau",
      object: "objet",
      tuple: "tuple",
      record: "record",
      map: "map",
      set: "ensemble",
      file: "fichier",
      nonoptional: "non optionnel",
      nan: "NaN",
      function: "fonction"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Entr\xE9e invalide : instance de ${issue3.expected} attendu, ${received} re\xE7u`;
          }
          return `Entr\xE9e invalide : ${expected2} attendu, ${received} re\xE7u`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Entr\xE9e invalide : ${stringifyPrimitive(issue3.values[0])} attendu`;
          return `Option invalide : une valeur parmi ${joinValues(issue3.values, "|")} attendue`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Trop grand : ${TypeDictionary[issue3.origin] ?? "valeur"} doit ${sizing.verb} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\xE9l\xE9ment(s)"}`;
          return `Trop grand : ${TypeDictionary[issue3.origin] ?? "valeur"} doit \xEAtre ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Trop petit : ${TypeDictionary[issue3.origin] ?? "valeur"} doit ${sizing.verb} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          return `Trop petit : ${TypeDictionary[issue3.origin] ?? "valeur"} doit \xEAtre ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Cha\xEEne de caract\xE8res invalide : doit commencer par "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Cha\xEEne de caract\xE8res invalide : doit se terminer par "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Cha\xEEne de caract\xE8res invalide : doit inclure "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Cha\xEEne de caract\xE8res invalide : doit correspondre au motif ${_issue.pattern}`;
          return `${FormatDictionary[_issue.format] ?? issue3.format} invalide`;
        }
        case "not_multiple_of":
          return `Nombre invalide : doit \xEAtre un multiple de ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Cl\xE9${issue3.keys.length > 1 ? "s" : ""} non reconnue${issue3.keys.length > 1 ? "s" : ""} : ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Cl\xE9 invalide dans ${issue3.origin}`;
        case "invalid_union":
          return "Entr\xE9e invalide";
        case "invalid_element":
          return `Valeur invalide dans ${issue3.origin}`;
        default:
          return `Entr\xE9e invalide`;
      }
    };
  };
  function fr_default() {
    return {
      localeError: error17()
    };
  }

  // ../../../node_modules/zod/v4/locales/fr-CA.js
  var error18 = () => {
    const Sizable = {
      string: { unit: "caract\xE8res", verb: "avoir" },
      file: { unit: "octets", verb: "avoir" },
      array: { unit: "\xE9l\xE9ments", verb: "avoir" },
      set: { unit: "\xE9l\xE9ments", verb: "avoir" },
      map: { unit: "\xE9l\xE9ments", verb: "avoir" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "entr\xE9e",
      email: "adresse courriel",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "date-heure ISO",
      date: "date ISO",
      time: "heure ISO",
      duration: "dur\xE9e ISO",
      ipv4: "adresse IPv4",
      ipv6: "adresse IPv6",
      mac: "adresse MAC",
      cidrv4: "plage IPv4",
      cidrv6: "plage IPv6",
      base64: "cha\xEEne encod\xE9e en base64",
      base64url: "cha\xEEne encod\xE9e en base64url",
      json_string: "cha\xEEne JSON",
      e164: "num\xE9ro E.164",
      credit_card: "num\xE9ro de carte de cr\xE9dit",
      currency_code: "code de devise",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "entr\xE9e"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Entr\xE9e invalide : attendu instanceof ${issue3.expected}, re\xE7u ${received}`;
          }
          return `Entr\xE9e invalide : attendu ${expected2}, re\xE7u ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Entr\xE9e invalide : attendu ${stringifyPrimitive(issue3.values[0])}`;
          return `Option invalide : attendu l'une des valeurs suivantes ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "\u2264" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Trop grand : attendu que ${issue3.origin ?? "la valeur"} ait ${adj}${issue3.maximum.toString()} ${sizing.unit}`;
          return `Trop grand : attendu que ${issue3.origin ?? "la valeur"} soit ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? "\u2265" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Trop petit : attendu que ${issue3.origin} ait ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Trop petit : attendu que ${issue3.origin} soit ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Cha\xEEne invalide : doit commencer par "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Cha\xEEne invalide : doit se terminer par "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Cha\xEEne invalide : doit inclure "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Cha\xEEne invalide : doit correspondre au motif ${_issue.pattern}`;
          return `${FormatDictionary[_issue.format] ?? issue3.format} invalide`;
        }
        case "not_multiple_of":
          return `Nombre invalide : doit \xEAtre un multiple de ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Cl\xE9${issue3.keys.length > 1 ? "s" : ""} non reconnue${issue3.keys.length > 1 ? "s" : ""} : ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Cl\xE9 invalide dans ${issue3.origin}`;
        case "invalid_union":
          return "Entr\xE9e invalide";
        case "invalid_element":
          return `Valeur invalide dans ${issue3.origin}`;
        default:
          return `Entr\xE9e invalide`;
      }
    };
  };
  function fr_CA_default() {
    return {
      localeError: error18()
    };
  }

  // ../../../node_modules/zod/v4/locales/gu.js
  var error19 = () => {
    const Sizable = {
      string: { unit: "\u0A85\u0A95\u0ACD\u0AB7\u0AB0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
      file: { unit: "\u0AAC\u0ABE\u0AAF\u0A9F", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
      array: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
      set: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
      map: { unit: "\u0A8F\u0AA8\u0ACD\u0A9F\u0ACD\u0AB0\u0AC0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F",
      email: "\u0A88\u0AAE\u0AC7\u0A87\u0AB2 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
      url: "URL",
      emoji: "\u0A87\u0AAE\u0ACB\u0A9C\u0AC0",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96 \u0A85\u0AA8\u0AC7 \u0AB8\u0AAE\u0AAF",
      date: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96",
      time: "ISO \u0AB8\u0AAE\u0AAF",
      duration: "ISO \u0A85\u0AB5\u0AA7\u0ABF",
      ipv4: "IPv4 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
      ipv6: "IPv6 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
      mac: "MAC \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
      cidrv4: "IPv4 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
      cidrv6: "IPv6 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
      base64: "base64-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
      base64url: "base64url-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
      json_string: "JSON \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
      e164: "E.164 \u0AA8\u0A82\u0AAC\u0AB0",
      credit_card: "\u0A95\u0ACD\u0AB0\u0AC7\u0AA1\u0ABF\u0A9F \u0A95\u0ABE\u0AB0\u0ACD\u0AA1 \u0AA8\u0A82\u0AAC\u0AB0",
      currency_code: "\u0A9A\u0AB2\u0AA3 \u0A95\u0ACB\u0AA1",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${expected2}, \u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AA4 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB5\u0ABF\u0A95\u0AB2\u0ACD\u0AAA: ${joinValues(issue3.values, " | ")} \u0AAE\u0ABE\u0AA7\u0ACD\u0AAF\u0AAE\u0AA5\u0AC0 \u0A8F\u0A95 \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${issue3.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0A8F\u0AB2\u0ABF\u0AAE\u0AC7\u0AA8\u0ACD\u0A9F"} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F`;
          return `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${issue3.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${adj}${issue3.maximum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F`;
          }
          return `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${issue3.origin} ${adj}${issue3.minimum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${_issue.prefix}" \u0AA5\u0AC0 \u0AB6\u0AB0\u0AC2 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
          }
          if (_issue.format === "ends_with")
            return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${_issue.suffix}" \u0AAA\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
          if (_issue.format === "includes")
            return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${_issue.includes}" \u0AB6\u0ABE\u0AAE\u0AC7\u0AB2 \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
          if (_issue.format === "regex")
            return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: \u0AAA\u0AC7\u0A9F\u0AB0\u0ACD\u0AA8 ${_issue.pattern} \u0AB8\u0ABE\u0AA5\u0AC7 \u0AAE\u0AC7\u0AB3 \u0A96\u0ABE\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
          return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA8\u0A82\u0AAC\u0AB0: ${issue3.divisor} \u0AA8\u0ACB \u0A97\u0AC1\u0AA3\u0ABE\u0A82\u0A95 \u0AB9\u0ACB\u0AB5\u0ACB \u0A9C\u0ACB\u0A88\u0A8F`;
        case "unrecognized_keys":
          return `\u0A93\u0AB3\u0A96\u0AC0 \u0AB6\u0A95\u0ABE\u0AA4\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0A95\u0AC0${issue3.keys.length > 1 ? "\u0A93" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A95\u0AC0`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA1\u0ABF\u0AB8\u0ACD\u0A95\u0ACD\u0AB0\u0ABF\u0AAE\u0ABF\u0AA8\u0AC7\u0A9F\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF. \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${opts}`;
          }
          return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
        case "invalid_element":
          return `${issue3.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF`;
        default:
          return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
      }
    };
  };
  function gu_default() {
    return {
      localeError: error19()
    };
  }

  // ../../../node_modules/zod/v4/locales/he.js
  var error20 = () => {
    const TypeNames = {
      string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
      number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
      boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
      bigint: { label: "BigInt", gender: "m" },
      date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
      array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
      object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
      null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
      undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
      symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
      function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
      map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
      set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
      file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
      promise: { label: "Promise", gender: "m" },
      NaN: { label: "NaN", gender: "m" },
      unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
      value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
    };
    const Sizable = {
      string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
      file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
      array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
      set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
      number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
      // no unit
    };
    const typeEntry = (t) => t ? TypeNames[t] : void 0;
    const typeLabel = (t) => {
      const e = typeEntry(t);
      if (e)
        return e.label;
      return t ?? TypeNames.unknown.label;
    };
    const withDefinite = (t) => `\u05D4${typeLabel(t)}`;
    const verbFor = (t) => {
      const e = typeEntry(t);
      const gender = e?.gender ?? "m";
      return gender === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA";
    };
    const getSizing = (origin) => {
      if (!origin)
        return null;
      return Sizable[origin] ?? null;
    };
    const FormatDictionary = {
      regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
      email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
      url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
      emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
      uuid: { label: "UUID", gender: "m" },
      uuidv4: { label: "UUIDv4", gender: "m" },
      uuidv6: { label: "UUIDv6", gender: "m" },
      nanoid: { label: "nanoid", gender: "m" },
      guid: { label: "GUID", gender: "m" },
      cuid: { label: "cuid", gender: "m" },
      cuid2: { label: "cuid2", gender: "m" },
      ulid: { label: "ULID", gender: "m" },
      xid: { label: "XID", gender: "m" },
      ksuid: { label: "KSUID", gender: "m" },
      datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
      date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
      time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
      duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
      ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
      ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
      mac: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA MAC", gender: "f" },
      cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
      cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
      base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
      base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
      json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
      e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
      credit_card: { label: "\u05DE\u05E1\u05E4\u05E8 \u05DB\u05E8\u05D8\u05D9\u05E1 \u05D0\u05E9\u05E8\u05D0\u05D9", gender: "m" },
      currency_code: { label: "\u05E7\u05D5\u05D3 \u05DE\u05D8\u05D1\u05E2", gender: "m" },
      iban: { label: "IBAN", gender: "m" },
      jwt: { label: "JWT", gender: "m" },
      template_literal: { label: "\u05E7\u05DC\u05D8", gender: "m" },
      ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
      includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
      lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
      starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
      uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expectedKey = issue3.expected;
          const expected2 = TypeDictionary[expectedKey ?? ""] ?? typeLabel(expectedKey);
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? TypeNames[receivedType]?.label ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${issue3.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${received}`;
          }
          return `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${expected2}, \u05D4\u05EA\u05E7\u05D1\u05DC ${received}`;
        }
        case "invalid_value": {
          if (issue3.values.length === 1) {
            return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${stringifyPrimitive(issue3.values[0])}`;
          }
          const stringified = issue3.values.map((v) => stringifyPrimitive(v));
          if (issue3.values.length === 2) {
            return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${stringified[0]} \u05D0\u05D5 ${stringified[1]}`;
          }
          const lastValue = stringified[stringified.length - 1];
          const restValues = stringified.slice(0, -1).join(", ");
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${restValues} \u05D0\u05D5 ${lastValue}`;
        }
        case "too_big": {
          const sizing = getSizing(issue3.origin);
          const subject2 = withDefinite(issue3.origin ?? "value");
          if (issue3.origin === "string") {
            return `${sizing?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${subject2} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${issue3.maximum.toString()} ${sizing?.unit ?? ""} ${issue3.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
          }
          if (issue3.origin === "number") {
            const comparison = issue3.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${issue3.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${issue3.maximum}`;
            return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${subject2} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${comparison}`;
          }
          if (issue3.origin === "array" || issue3.origin === "set") {
            const verb = issue3.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
            const comparison = issue3.inclusive ? `${issue3.maximum} ${sizing?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${issue3.maximum} ${sizing?.unit ?? ""}`;
            return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${subject2} ${verb} \u05DC\u05D4\u05DB\u05D9\u05DC ${comparison}`.trim();
          }
          const adj = issue3.inclusive ? "<=" : "<";
          const be = verbFor(issue3.origin ?? "value");
          if (sizing?.unit) {
            return `${sizing.longLabel} \u05DE\u05D3\u05D9: ${subject2} ${be} ${adj}${issue3.maximum.toString()} ${sizing.unit}`;
          }
          return `${sizing?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${subject2} ${be} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const sizing = getSizing(issue3.origin);
          const subject2 = withDefinite(issue3.origin ?? "value");
          if (issue3.origin === "string") {
            return `${sizing?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${subject2} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${issue3.minimum.toString()} ${sizing?.unit ?? ""} ${issue3.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
          }
          if (issue3.origin === "number") {
            const comparison = issue3.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${issue3.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${issue3.minimum}`;
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${subject2} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${comparison}`;
          }
          if (issue3.origin === "array" || issue3.origin === "set") {
            const verb = issue3.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
            if (issue3.minimum === 1 && issue3.inclusive) {
              const singularPhrase = issue3.origin === "set" ? "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3" : "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3";
              return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${subject2} ${verb} \u05DC\u05D4\u05DB\u05D9\u05DC ${singularPhrase}`;
            }
            const comparison = issue3.inclusive ? `${issue3.minimum} ${sizing?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${issue3.minimum} ${sizing?.unit ?? ""}`;
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${subject2} ${verb} \u05DC\u05D4\u05DB\u05D9\u05DC ${comparison}`.trim();
          }
          const adj = issue3.inclusive ? ">=" : ">";
          const be = verbFor(issue3.origin ?? "value");
          if (sizing?.unit) {
            return `${sizing.shortLabel} \u05DE\u05D3\u05D9: ${subject2} ${be} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `${sizing?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${subject2} ${be} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${_issue.pattern}`;
          const nounEntry = FormatDictionary[_issue.format];
          const noun = nounEntry?.label ?? _issue.format;
          const gender = nounEntry?.gender ?? "m";
          const adjective = gender === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
          return `${noun} \u05DC\u05D0 ${adjective}`;
        }
        case "not_multiple_of":
          return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u05DE\u05E4\u05EA\u05D7${issue3.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${issue3.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key": {
          return `\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8`;
        }
        case "invalid_union":
          return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
        case "invalid_element": {
          const place = withDefinite(issue3.origin ?? "array");
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${place}`;
        }
        default:
          return `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF`;
      }
    };
  };
  function he_default() {
    return {
      localeError: error20()
    };
  }

  // ../../../node_modules/zod/v4/locales/hi.js
  var error21 = () => {
    const Sizable = {
      string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
      file: { unit: "\u092C\u093E\u0907\u091F\u094D\u0938", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
      array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
      set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
      map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0907\u0928\u092A\u0941\u091F",
      email: "\u0908\u092E\u0947\u0932 \u092A\u0924\u093E",
      url: "URL",
      emoji: "\u0907\u092E\u094B\u091C\u0940",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0924\u093F\u0925\u093F \u0914\u0930 \u0938\u092E\u092F",
      date: "ISO \u0924\u093F\u0925\u093F",
      time: "ISO \u0938\u092E\u092F",
      duration: "ISO \u0905\u0935\u0927\u093F",
      ipv4: "IPv4 \u092A\u0924\u093E",
      ipv6: "IPv6 \u092A\u0924\u093E",
      mac: "MAC \u092A\u0924\u093E",
      cidrv4: "IPv4 \u0936\u094D\u0930\u0947\u0923\u0940",
      cidrv6: "IPv6 \u0936\u094D\u0930\u0947\u0923\u0940",
      base64: "Base64-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
      base64url: "Base64URL-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
      json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
      e164: "E.164 \u0938\u0902\u0916\u094D\u092F\u093E",
      credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0938\u0902\u0916\u094D\u092F\u093E",
      currency_code: "\u092E\u0941\u0926\u094D\u0930\u093E \u0915\u094B\u0921",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0907\u0928\u092A\u0941\u091F"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${expected2}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u094B\u0902 \u092E\u0947\u0902 \u0938\u0947 \u090F\u0915 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${issue3.origin ?? "\u092E\u093E\u0928"} \u092E\u0947\u0902 ${adj}${issue3.maximum} ${sizing.unit} \u0939\u094B\u0902`;
          return `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${issue3.origin ?? "\u092E\u093E\u0928"} ${adj}${issue3.maximum} \u0939\u094B`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${issue3.origin} \u092E\u0947\u0902 ${adj}${issue3.minimum} ${sizing.unit} \u0939\u094B\u0902`;
          return `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${issue3.origin} ${adj}${issue3.minimum} \u0939\u094B`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${_issue.prefix}" \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
          if (_issue.format === "ends_with")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${_issue.suffix}" \u092A\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
          if (_issue.format === "includes")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u0907\u0938\u092E\u0947\u0902 "${_issue.includes}" \u0936\u093E\u092E\u093F\u0932 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
          if (_issue.format === "regex")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u092A\u0948\u091F\u0930\u094D\u0928 ${_issue.pattern} \u0938\u0947 \u092E\u0947\u0932 \u0916\u093E\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
          return `\u0905\u092E\u093E\u0928\u094D\u092F ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: \u092F\u0939 ${issue3.divisor} \u0915\u093E \u0917\u0941\u0923\u091C \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
        case "unrecognized_keys":
          return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u0902\u091C\u0940${issue3.keys.length > 1 ? "\u092F\u093E\u0901" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u0902\u091C\u0940: ${issue3.origin} \u092E\u0947\u0902`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${opts}`;
          }
          return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
        case "invalid_element":
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${issue3.origin} \u092E\u0947\u0902`;
        default:
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F`;
      }
    };
  };
  function hi_default() {
    return {
      localeError: error21()
    };
  }

  // ../../../node_modules/zod/v4/locales/hr.js
  var error22 = () => {
    const Sizable = {
      string: { unit: "znakova", verb: "imati" },
      file: { unit: "bajtova", verb: "imati" },
      array: { unit: "stavki", verb: "imati" },
      set: { unit: "stavki", verb: "imati" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "unos",
      email: "email adresa",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datum i vrijeme",
      date: "ISO datum",
      time: "ISO vrijeme",
      duration: "ISO trajanje",
      ipv4: "IPv4 adresa",
      ipv6: "IPv6 adresa",
      mac: "MAC adresa",
      cidrv4: "IPv4 raspon",
      cidrv6: "IPv6 raspon",
      base64: "base64 kodirani tekst",
      base64url: "base64url kodirani tekst",
      json_string: "JSON tekst",
      e164: "E.164 broj",
      credit_card: "broj kreditne kartice",
      currency_code: "kod valute",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "unos"
    };
    const TypeDictionary = {
      nan: "NaN",
      string: "tekst",
      number: "broj",
      boolean: "boolean",
      array: "niz",
      object: "objekt",
      set: "skup",
      file: "datoteka",
      date: "datum",
      bigint: "bigint",
      symbol: "simbol",
      undefined: "undefined",
      null: "null",
      function: "funkcija",
      map: "mapa"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Neispravan unos: o\u010Dekuje se instanceof ${issue3.expected}, a primljeno je ${received}`;
          }
          return `Neispravan unos: o\u010Dekuje se ${expected2}, a primljeno je ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Neispravna vrijednost: o\u010Dekivano ${stringifyPrimitive(issue3.values[0])}`;
          return `Neispravna opcija: o\u010Dekivano jedno od ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          if (sizing)
            return `Preveliko: o\u010Dekivano da ${origin ?? "vrijednost"} ima ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elemenata"}`;
          return `Preveliko: o\u010Dekivano da ${origin ?? "vrijednost"} bude ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          if (sizing) {
            return `Premalo: o\u010Dekivano da ${origin} ima ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Premalo: o\u010Dekivano da ${origin} bude ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Neispravan tekst: mora zapo\u010Dinjati s "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Neispravan tekst: mora zavr\u0161avati s "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Neispravan tekst: mora sadr\u017Eavati "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Neispravan tekst: mora odgovarati uzorku ${_issue.pattern}`;
          return `Neispravna ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Neispravan broj: mora biti vi\u0161ekratnik od ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Neprepoznat${issue3.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Neispravan klju\u010D u ${TypeDictionary[issue3.origin] ?? issue3.origin}`;
        case "invalid_union":
          return "Neispravan unos";
        case "invalid_element":
          return `Neispravna vrijednost u ${TypeDictionary[issue3.origin] ?? issue3.origin}`;
        default:
          return `Neispravan unos`;
      }
    };
  };
  function hr_default() {
    return {
      localeError: error22()
    };
  }

  // ../../../node_modules/zod/v4/locales/hu.js
  var error23 = () => {
    const Sizable = {
      string: { unit: "karakter", verb: "legyen" },
      file: { unit: "byte", verb: "legyen" },
      array: { unit: "elem", verb: "legyen" },
      set: { unit: "elem", verb: "legyen" },
      map: { unit: "elem", verb: "legyen" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "bemenet",
      email: "email c\xEDm",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO id\u0151b\xE9lyeg",
      date: "ISO d\xE1tum",
      time: "ISO id\u0151",
      duration: "ISO id\u0151intervallum",
      ipv4: "IPv4 c\xEDm",
      ipv6: "IPv6 c\xEDm",
      mac: "MAC c\xEDm",
      cidrv4: "IPv4 tartom\xE1ny",
      cidrv6: "IPv6 tartom\xE1ny",
      base64: "base64-k\xF3dolt string",
      base64url: "base64url-k\xF3dolt string",
      json_string: "JSON string",
      e164: "E.164 sz\xE1m",
      credit_card: "hitelk\xE1rtyasz\xE1m",
      currency_code: "p\xE9nznemk\xF3d",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "bemenet"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "sz\xE1m",
      array: "t\xF6mb"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${issue3.expected}, a kapott \xE9rt\xE9k ${received}`;
          }
          return `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${expected2}, a kapott \xE9rt\xE9k ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${stringifyPrimitive(issue3.values[0])}`;
          return `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `T\xFAl nagy: ${issue3.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elem"}`;
          return `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${issue3.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${issue3.origin} m\xE9rete t\xFAl kicsi ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${issue3.origin} t\xFAl kicsi ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\xC9rv\xE9nytelen string: "${_issue.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie`;
          if (_issue.format === "ends_with")
            return `\xC9rv\xE9nytelen string: "${_issue.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie`;
          if (_issue.format === "includes")
            return `\xC9rv\xE9nytelen string: "${_issue.includes}" \xE9rt\xE9ket kell tartalmaznia`;
          if (_issue.format === "regex")
            return `\xC9rv\xE9nytelen string: ${_issue.pattern} mint\xE1nak kell megfelelnie`;
          return `\xC9rv\xE9nytelen ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\xC9rv\xE9nytelen sz\xE1m: ${issue3.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
        case "unrecognized_keys":
          return `Ismeretlen kulcs${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\xC9rv\xE9nytelen kulcs ${issue3.origin}`;
        case "invalid_union":
          return "\xC9rv\xE9nytelen bemenet";
        case "invalid_element":
          return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${issue3.origin}`;
        default:
          return `\xC9rv\xE9nytelen bemenet`;
      }
    };
  };
  function hu_default() {
    return {
      localeError: error23()
    };
  }

  // ../../../node_modules/zod/v4/locales/hy.js
  function getArmenianPlural(count, one, many) {
    return Math.abs(count) === 1 ? one : many;
  }
  function withDefiniteArticle(word) {
    if (!word)
      return "";
    const vowels = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"];
    const lastChar = word[word.length - 1];
    return word + (vowels.includes(lastChar) ? "\u0576" : "\u0568");
  }
  var error24 = () => {
    const Sizable = {
      string: {
        unit: {
          one: "\u0576\u0577\u0561\u0576",
          many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
        },
        verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
      },
      file: {
        unit: {
          one: "\u0562\u0561\u0575\u0569",
          many: "\u0562\u0561\u0575\u0569\u0565\u0580"
        },
        verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
      },
      array: {
        unit: {
          one: "\u057F\u0561\u0580\u0580",
          many: "\u057F\u0561\u0580\u0580\u0565\u0580"
        },
        verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
      },
      set: {
        unit: {
          one: "\u057F\u0561\u0580\u0580",
          many: "\u057F\u0561\u0580\u0580\u0565\u0580"
        },
        verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
      },
      map: {
        unit: {
          one: "\u057F\u0561\u0580\u0580",
          many: "\u057F\u0561\u0580\u0580\u0565\u0580"
        },
        verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
      }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0574\u0578\u0582\u057F\u0584",
      email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
      url: "URL",
      emoji: "\u0567\u0574\u0578\u057B\u056B",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
      date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
      time: "ISO \u056A\u0561\u0574",
      duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
      ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
      ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
      mac: "MAC \u0570\u0561\u057D\u0581\u0565",
      cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
      cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
      base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
      base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
      json_string: "JSON \u057F\u0578\u0572",
      e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
      credit_card: "\u056F\u0580\u0565\u0564\u056B\u057F \u0584\u0561\u0580\u057F\u056B \u0570\u0561\u0574\u0561\u0580",
      currency_code: "\u0561\u0580\u056A\u0578\u0582\u0575\u0569\u056B \u056F\u0578\u0564",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0574\u0578\u0582\u057F\u0584"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0569\u056B\u057E",
      array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${issue3.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${received}`;
          }
          return `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${expected2}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${stringifyPrimitive(issue3.values[1])}`;
          return `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            const maxValue = Number(issue3.maximum);
            const unit = getArmenianPlural(maxValue, sizing.unit.one, sizing.unit.many);
            return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${withDefiniteArticle(issue3.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${adj}${issue3.maximum.toString()} ${unit}`;
          }
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${withDefiniteArticle(issue3.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            const minValue = Number(issue3.minimum);
            const unit = getArmenianPlural(minValue, sizing.unit.one, sizing.unit.many);
            return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${withDefiniteArticle(issue3.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${adj}${issue3.minimum.toString()} ${unit}`;
          }
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${withDefiniteArticle(issue3.origin)} \u056C\u056B\u0576\u056B ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${_issue.prefix}"-\u0578\u057E`;
          if (_issue.format === "ends_with")
            return `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${_issue.suffix}"-\u0578\u057E`;
          if (_issue.format === "includes")
            return `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${_issue.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576`;
          return `\u054D\u056D\u0561\u056C ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${issue3.divisor}-\u056B`;
        case "unrecognized_keys":
          return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${issue3.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${withDefiniteArticle(issue3.origin)}-\u0578\u0582\u0574`;
        case "invalid_union":
          return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
        case "invalid_element":
          return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${withDefiniteArticle(issue3.origin)}-\u0578\u0582\u0574`;
        default:
          return `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574`;
      }
    };
  };
  function hy_default() {
    return {
      localeError: error24()
    };
  }

  // ../../../node_modules/zod/v4/locales/id.js
  var error25 = () => {
    const Sizable = {
      string: { unit: "karakter", verb: "memiliki" },
      file: { unit: "byte", verb: "memiliki" },
      array: { unit: "item", verb: "memiliki" },
      set: { unit: "item", verb: "memiliki" },
      map: { unit: "item", verb: "memiliki" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "alamat email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "tanggal dan waktu format ISO",
      date: "tanggal format ISO",
      time: "jam format ISO",
      duration: "durasi format ISO",
      ipv4: "alamat IPv4",
      ipv6: "alamat IPv6",
      mac: "alamat MAC",
      cidrv4: "rentang alamat IPv4",
      cidrv6: "rentang alamat IPv6",
      base64: "string dengan enkode base64",
      base64url: "string dengan enkode base64url",
      json_string: "string JSON",
      e164: "angka E.164",
      credit_card: "nomor kartu kredit",
      currency_code: "kode mata uang",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Input tidak valid: diharapkan instanceof ${issue3.expected}, diterima ${received}`;
          }
          return `Input tidak valid: diharapkan ${expected2}, diterima ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Input tidak valid: diharapkan ${stringifyPrimitive(issue3.values[0])}`;
          return `Pilihan tidak valid: diharapkan salah satu dari ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Terlalu besar: diharapkan ${issue3.origin ?? "value"} memiliki ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elemen"}`;
          return `Terlalu besar: diharapkan ${issue3.origin ?? "value"} menjadi ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Terlalu kecil: diharapkan ${issue3.origin} memiliki ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Terlalu kecil: diharapkan ${issue3.origin} menjadi ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `String tidak valid: harus dimulai dengan "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `String tidak valid: harus berakhir dengan "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `String tidak valid: harus menyertakan "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `String tidak valid: harus sesuai pola ${_issue.pattern}`;
          return `${FormatDictionary[_issue.format] ?? issue3.format} tidak valid`;
        }
        case "not_multiple_of":
          return `Angka tidak valid: harus kelipatan dari ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Kunci tidak dikenali ${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Kunci tidak valid di ${issue3.origin}`;
        case "invalid_union":
          return "Input tidak valid";
        case "invalid_element":
          return `Nilai tidak valid di ${issue3.origin}`;
        default:
          return `Input tidak valid`;
      }
    };
  };
  function id_default() {
    return {
      localeError: error25()
    };
  }

  // ../../../node_modules/zod/v4/locales/is.js
  var error26 = () => {
    const Sizable = {
      string: { unit: "stafi", verb: "a\xF0 hafa" },
      file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
      array: { unit: "hluti", verb: "a\xF0 hafa" },
      set: { unit: "hluti", verb: "a\xF0 hafa" },
      map: { unit: "hluti", verb: "a\xF0 hafa" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "gildi",
      email: "netfang",
      url: "vefsl\xF3\xF0",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dagsetning og t\xEDmi",
      date: "ISO dagsetning",
      time: "ISO t\xEDmi",
      duration: "ISO t\xEDmalengd",
      ipv4: "IPv4 address",
      ipv6: "IPv6 address",
      mac: "MAC address",
      cidrv4: "IPv4 range",
      cidrv6: "IPv6 range",
      base64: "base64-encoded strengur",
      base64url: "base64url-encoded strengur",
      json_string: "JSON strengur",
      e164: "E.164 t\xF6lugildi",
      credit_card: "kreditkortan\xFAmer",
      currency_code: "gjaldmi\xF0ilsk\xF3\xF0i",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "gildi"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "n\xFAmer",
      array: "fylki"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Rangt gildi: \xDE\xFA sl\xF3st inn ${received} \xFEar sem \xE1 a\xF0 vera instanceof ${issue3.expected}`;
          }
          return `Rangt gildi: \xDE\xFA sl\xF3st inn ${received} \xFEar sem \xE1 a\xF0 vera ${expected2}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Rangt gildi: gert r\xE1\xF0 fyrir ${stringifyPrimitive(issue3.values[0])}`;
          return `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${issue3.origin ?? "gildi"} hafi ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "hluti"}`;
          return `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${issue3.origin ?? "gildi"} s\xE9 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${issue3.origin} hafi ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${issue3.origin} s\xE9 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${_issue.pattern}`;
          return `Rangt ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\xD3\xFEekkt ${issue3.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Rangur lykill \xED ${issue3.origin}`;
        case "invalid_union":
          return "Rangt gildi";
        case "invalid_element":
          return `Rangt gildi \xED ${issue3.origin}`;
        default:
          return `Rangt gildi`;
      }
    };
  };
  function is_default() {
    return {
      localeError: error26()
    };
  }

  // ../../../node_modules/zod/v4/locales/it.js
  var error27 = () => {
    const Sizable = {
      string: { unit: "caratteri", verb: "avere" },
      file: { unit: "byte", verb: "avere" },
      array: { unit: "elementi", verb: "avere" },
      set: { unit: "elementi", verb: "avere" },
      map: { unit: "elementi", verb: "avere" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "indirizzo email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data e ora ISO",
      date: "data ISO",
      time: "ora ISO",
      duration: "durata ISO",
      ipv4: "indirizzo IPv4",
      ipv6: "indirizzo IPv6",
      mac: "indirizzo MAC",
      cidrv4: "intervallo IPv4",
      cidrv6: "intervallo IPv6",
      base64: "stringa codificata in base64",
      base64url: "URL codificata in base64",
      json_string: "stringa JSON",
      e164: "numero E.164",
      credit_card: "numero di carta di credito",
      currency_code: "codice valuta",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "numero",
      array: "vettore"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Input non valido: atteso instanceof ${issue3.expected}, ricevuto ${received}`;
          }
          return `Input non valido: atteso ${expected2}, ricevuto ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Input non valido: atteso ${stringifyPrimitive(issue3.values[0])}`;
          return `Opzione non valida: atteso uno tra ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Troppo grande: ${issue3.origin ?? "valore"} deve avere ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elementi"}`;
          return `Troppo grande: ${issue3.origin ?? "valore"} deve essere ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Troppo piccolo: ${issue3.origin} deve avere ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Troppo piccolo: ${issue3.origin} deve essere ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Stringa non valida: deve iniziare con "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Stringa non valida: deve terminare con "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Stringa non valida: deve includere "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Stringa non valida: deve corrispondere al pattern ${_issue.pattern}`;
          return `Input non valido: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Numero non valido: deve essere un multiplo di ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Chiav${issue3.keys.length > 1 ? "i" : "e"} non riconosciut${issue3.keys.length > 1 ? "e" : "a"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Chiave non valida in ${issue3.origin}`;
        case "invalid_union":
          return "Input non valido";
        case "invalid_element":
          return `Valore non valido in ${issue3.origin}`;
        default:
          return `Input non valido`;
      }
    };
  };
  function it_default() {
    return {
      localeError: error27()
    };
  }

  // ../../../node_modules/zod/v4/locales/ja.js
  var error28 = () => {
    const Sizable = {
      string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
      file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
      array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
      set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
      map: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u5165\u529B\u5024",
      email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
      url: "URL",
      emoji: "\u7D75\u6587\u5B57",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO\u65E5\u6642",
      date: "ISO\u65E5\u4ED8",
      time: "ISO\u6642\u523B",
      duration: "ISO\u671F\u9593",
      ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
      ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
      mac: "MAC\u30A2\u30C9\u30EC\u30B9",
      cidrv4: "IPv4\u7BC4\u56F2",
      cidrv6: "IPv6\u7BC4\u56F2",
      base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
      base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
      json_string: "JSON\u6587\u5B57\u5217",
      e164: "E.164\u756A\u53F7",
      credit_card: "\u30AF\u30EC\u30B8\u30C3\u30C8\u30AB\u30FC\u30C9\u756A\u53F7",
      currency_code: "\u901A\u8CA8\u30B3\u30FC\u30C9",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u5165\u529B\u5024"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u6570\u5024",
      array: "\u914D\u5217"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u7121\u52B9\u306A\u5165\u529B: instanceof ${issue3.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${received}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
          }
          return `\u7121\u52B9\u306A\u5165\u529B: ${expected2}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${received}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u7121\u52B9\u306A\u5165\u529B: ${stringifyPrimitive(issue3.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F`;
          return `\u7121\u52B9\u306A\u9078\u629E: ${joinValues(issue3.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
        case "too_big": {
          const adj = issue3.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u5927\u304D\u3059\u304E\u308B\u5024: ${issue3.origin ?? "\u5024"}\u306F${issue3.maximum.toString()}${sizing.unit ?? "\u8981\u7D20"}${adj}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
          return `\u5927\u304D\u3059\u304E\u308B\u5024: ${issue3.origin ?? "\u5024"}\u306F${issue3.maximum.toString()}${adj}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${issue3.origin}\u306F${issue3.minimum.toString()}${sizing.unit}${adj}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
          return `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${issue3.origin}\u306F${issue3.minimum.toString()}${adj}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${_issue.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
          if (_issue.format === "ends_with")
            return `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${_issue.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
          if (_issue.format === "includes")
            return `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${_issue.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
          if (_issue.format === "regex")
            return `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${_issue.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
          return `\u7121\u52B9\u306A${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u7121\u52B9\u306A\u6570\u5024: ${issue3.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
        case "unrecognized_keys":
          return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${issue3.keys.length > 1 ? "\u7FA4" : ""}: ${joinValues(issue3.keys, "\u3001")}`;
        case "invalid_key":
          return `${issue3.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
        case "invalid_union":
          return "\u7121\u52B9\u306A\u5165\u529B";
        case "invalid_element":
          return `${issue3.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
        default:
          return `\u7121\u52B9\u306A\u5165\u529B`;
      }
    };
  };
  function ja_default() {
    return {
      localeError: error28()
    };
  }

  // ../../../node_modules/zod/v4/locales/ka.js
  var error29 = () => {
    const Sizable = {
      string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
      file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
      array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
      set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
      map: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
      email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
      url: "URL",
      emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
      date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
      time: "\u10D3\u10E0\u10DD",
      duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
      ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
      ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
      mac: "MAC \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
      cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
      cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
      base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
      base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
      json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
      e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
      credit_card: "\u10E1\u10D0\u10D9\u10E0\u10D4\u10D3\u10D8\u10E2\u10DD \u10D1\u10D0\u10E0\u10D0\u10D7\u10D8\u10E1 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
      currency_code: "\u10D5\u10D0\u10DA\u10E3\u10E2\u10D8\u10E1 \u10D9\u10DD\u10D3\u10D8",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
      string: "\u10D5\u10D4\u10DA\u10D8",
      boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
      function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
      array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${issue3.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${received}`;
          }
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${expected2}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${joinValues(issue3.values, "|")}-\u10D3\u10D0\u10DC`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${issue3.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${sizing.verb} ${adj}${issue3.maximum.toString()} ${sizing.unit}`;
          return `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${issue3.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${issue3.origin} ${sizing.verb} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${issue3.origin} \u10D8\u10E7\u10DD\u10E1 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${_issue.prefix}"-\u10D8\u10D7`;
          }
          if (_issue.format === "ends_with")
            return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${_issue.suffix}"-\u10D8\u10D7`;
          if (_issue.format === "includes")
            return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${_issue.includes}"-\u10E1`;
          if (_issue.format === "regex")
            return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${_issue.pattern}`;
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${issue3.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
        case "unrecognized_keys":
          return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${issue3.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${issue3.origin}-\u10E8\u10D8`;
        case "invalid_union":
          return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
        case "invalid_element":
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${issue3.origin}-\u10E8\u10D8`;
        default:
          return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0`;
      }
    };
  };
  function ka_default() {
    return {
      localeError: error29()
    };
  }

  // ../../../node_modules/zod/v4/locales/km.js
  var error30 = () => {
    const Sizable = {
      string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
      file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
      array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
      set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
      map: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
      email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
      url: "URL",
      emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
      date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
      time: "\u1798\u17C9\u17C4\u1784 ISO",
      duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
      ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
      ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
      mac: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 MAC",
      cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
      cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
      base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
      base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
      json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
      e164: "\u179B\u17C1\u1781 E.164",
      credit_card: "\u179B\u17C1\u1781\u1794\u17D0\u178E\u17D2\u178E\u17A5\u178E\u1791\u17B6\u1793",
      currency_code: "\u1780\u17BC\u178A\u179A\u17BC\u1794\u17B7\u1799\u1794\u17D0\u178E\u17D2\u178E",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u179B\u17C1\u1781",
      array: "\u17A2\u17B6\u179A\u17C1 (Array)",
      null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${issue3.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${received}`;
          }
          return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${expected2} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${stringifyPrimitive(issue3.values[0])}`;
          return `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${issue3.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "\u1792\u17B6\u178F\u17BB"}`;
          return `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${issue3.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${issue3.origin} ${adj} ${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${issue3.origin} ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${_issue.pattern}`;
          return `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${issue3.origin}`;
        case "invalid_union":
          return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C`;
        case "invalid_element":
          return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${issue3.origin}`;
        default:
          return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C`;
      }
    };
  };
  function km_default() {
    return {
      localeError: error30()
    };
  }

  // ../../../node_modules/zod/v4/locales/kh.js
  function kh_default() {
    return km_default();
  }

  // ../../../node_modules/zod/v4/locales/kn.js
  var error31 = () => {
    const Sizable = {
      string: { unit: "\u0C85\u0C95\u0CCD\u0CB7\u0CB0\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
      file: { unit: "\u0CAC\u0CC8\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
      array: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
      set: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
      map: { unit: "entries", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD",
      email: "email \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95\u0CA6 \u0CB8\u0CAE\u0CAF",
      date: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95",
      time: "ISO \u0CB8\u0CAE\u0CAF",
      duration: "ISO \u0C85\u0CB5\u0CA7\u0CBF",
      ipv4: "IPv4 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
      ipv6: "IPv6 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
      mac: "MAC \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
      cidrv4: "IPv4 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
      cidrv6: "IPv6 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
      base64: "base64-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
      base64url: "base64url-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
      json_string: "JSON\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
      e164: "E.164 \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
      credit_card: "\u0C95\u0CCD\u0CB0\u0CC6\u0CA1\u0CBF\u0C9F\u0CCD \u0C95\u0CBE\u0CB0\u0CCD\u0CA1\u0CCD \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
      currency_code: "\u0C95\u0CB0\u0CC6\u0CA8\u0CCD\u0CB8\u0CBF \u0C95\u0CCB\u0CA1\u0CCD",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD"
    };
    const TypeDictionary = {
      // Compatibility: "nan" -> "NaN" for display
      nan: "NaN"
      // All other type names omitted - they fall back to raw values via ?? operator
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${expected2}, \u0CB8\u0CCD\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CA8\u0CC1 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C86\u0CAF\u0CCD\u0C95\u0CC6: \u0C87\u0CB5\u0CC1\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C92\u0C82\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${issue3.origin ?? "value"} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1"}`;
          return `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${issue3.origin ?? "value"} \u0C8E\u0C82\u0CA6\u0CC1 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${issue3.origin} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${issue3.origin} \u0C8E\u0C82\u0CA6\u0CC1 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CAC\u0CC7\u0C95\u0CC1 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0C95\u0CCA\u0CA8\u0CC6\u0C97\u0CCA\u0CB3\u0CCD\u0CB3\u0CAC\u0CC7\u0C95\u0CC1 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0CAE\u0CBE\u0CA6\u0CB0\u0CBF\u0C97\u0CC6 \u0CB9\u0CCA\u0C82\u0CA6\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CAC\u0CC7\u0C95\u0CC1 ${_issue.pattern}`;
          return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6: \u0CAC\u0CB9\u0CC1\u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u0C97\u0CC1\u0CB0\u0CC1\u0CA4\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CA6 \u0C95\u0CC0 ${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0C95\u0CC0 \u0C87\u0CA8\u0CCD ${issue3.origin}`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CA4\u0CBE\u0CB0\u0CA4\u0CAE\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF. \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${opts}`;
          }
          return "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
        case "invalid_element":
          return `\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF ${issue3.origin}`;
        default:
          return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD`;
      }
    };
  };
  function kn_default() {
    return {
      localeError: error31()
    };
  }

  // ../../../node_modules/zod/v4/locales/ko.js
  var error32 = () => {
    const Sizable = {
      string: { unit: "\uBB38\uC790", verb: "to have" },
      file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
      array: { unit: "\uAC1C", verb: "to have" },
      set: { unit: "\uAC1C", verb: "to have" },
      map: { unit: "\uAC1C", verb: "to have" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\uC785\uB825",
      email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
      url: "URL",
      emoji: "\uC774\uBAA8\uC9C0",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
      date: "ISO \uB0A0\uC9DC",
      time: "ISO \uC2DC\uAC04",
      duration: "ISO \uAE30\uAC04",
      ipv4: "IPv4 \uC8FC\uC18C",
      ipv6: "IPv6 \uC8FC\uC18C",
      mac: "MAC \uC8FC\uC18C",
      cidrv4: "IPv4 \uBC94\uC704",
      cidrv6: "IPv6 \uBC94\uC704",
      base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
      base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
      json_string: "JSON \uBB38\uC790\uC5F4",
      e164: "E.164 \uBC88\uD638",
      credit_card: "\uC2E0\uC6A9\uCE74\uB4DC \uBC88\uD638",
      currency_code: "\uD1B5\uD654 \uCF54\uB4DC",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\uC785\uB825"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${issue3.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${received}\uC785\uB2C8\uB2E4`;
          }
          return `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${expected2}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${received}\uC785\uB2C8\uB2E4`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${stringifyPrimitive(issue3.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4`;
          return `\uC798\uBABB\uB41C \uC635\uC158: ${joinValues(issue3.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
        case "too_big": {
          const adj = issue3.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC";
          const suffix = adj === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4";
          const sizing = getSizing(issue3.origin);
          const unit = sizing?.unit ?? "\uC694\uC18C";
          if (sizing)
            return `${issue3.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${issue3.maximum.toString()}${unit} ${adj}${suffix}`;
          return `${issue3.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${issue3.maximum.toString()} ${adj}${suffix}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC";
          const suffix = adj === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4";
          const sizing = getSizing(issue3.origin);
          const unit = sizing?.unit ?? "\uC694\uC18C";
          if (sizing) {
            return `${issue3.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${issue3.minimum.toString()}${unit} ${adj}${suffix}`;
          }
          return `${issue3.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${issue3.minimum.toString()} ${adj}${suffix}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${_issue.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4`;
          }
          if (_issue.format === "ends_with")
            return `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${_issue.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4`;
          if (_issue.format === "includes")
            return `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${_issue.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4`;
          if (_issue.format === "regex")
            return `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${_issue.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4`;
          return `\uC798\uBABB\uB41C ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\uC798\uBABB\uB41C \uC22B\uC790: ${issue3.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
        case "unrecognized_keys":
          return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\uC798\uBABB\uB41C \uD0A4: ${issue3.origin}`;
        case "invalid_union":
          return `\uC798\uBABB\uB41C \uC785\uB825`;
        case "invalid_element":
          return `\uC798\uBABB\uB41C \uAC12: ${issue3.origin}`;
        default:
          return `\uC798\uBABB\uB41C \uC785\uB825`;
      }
    };
  };
  function ko_default() {
    return {
      localeError: error32()
    };
  }

  // ../../../node_modules/zod/v4/locales/lt.js
  var capitalizeFirstCharacter = (text6) => {
    return text6.charAt(0).toUpperCase() + text6.slice(1);
  };
  function getUnitTypeFromNumber(number4) {
    const abs = Math.abs(number4);
    const last = abs % 10;
    const last2 = abs % 100;
    if (last2 >= 11 && last2 <= 19 || last === 0)
      return "many";
    if (last === 1)
      return "one";
    return "few";
  }
  var error33 = () => {
    const Sizable = {
      string: {
        unit: {
          one: "simbolis",
          few: "simboliai",
          many: "simboli\u0173"
        },
        verb: {
          smaller: {
            inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
            notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
          },
          bigger: {
            inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
            notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
          }
        }
      },
      file: {
        unit: {
          one: "baitas",
          few: "baitai",
          many: "bait\u0173"
        },
        verb: {
          smaller: {
            inclusive: "turi b\u016Bti ne didesnis kaip",
            notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
          },
          bigger: {
            inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
            notInclusive: "turi b\u016Bti didesnis kaip"
          }
        }
      },
      array: {
        unit: {
          one: "element\u0105",
          few: "elementus",
          many: "element\u0173"
        },
        verb: {
          smaller: {
            inclusive: "turi tur\u0117ti ne daugiau kaip",
            notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
          },
          bigger: {
            inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
            notInclusive: "turi tur\u0117ti daugiau kaip"
          }
        }
      },
      set: {
        unit: {
          one: "element\u0105",
          few: "elementus",
          many: "element\u0173"
        },
        verb: {
          smaller: {
            inclusive: "turi tur\u0117ti ne daugiau kaip",
            notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
          },
          bigger: {
            inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
            notInclusive: "turi tur\u0117ti daugiau kaip"
          }
        }
      }
    };
    function getSizing(origin, unitType, inclusive, targetShouldBe) {
      const result = Sizable[origin] ?? null;
      if (result === null)
        return result;
      return {
        unit: result.unit[unitType],
        verb: result.verb[targetShouldBe][inclusive ? "inclusive" : "notInclusive"]
      };
    }
    const FormatDictionary = {
      regex: "\u012Fvestis",
      email: "el. pa\u0161to adresas",
      url: "URL",
      emoji: "jaustukas",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO data ir laikas",
      date: "ISO data",
      time: "ISO laikas",
      duration: "ISO trukm\u0117",
      ipv4: "IPv4 adresas",
      ipv6: "IPv6 adresas",
      mac: "MAC adresas",
      cidrv4: "IPv4 tinklo prefiksas (CIDR)",
      cidrv6: "IPv6 tinklo prefiksas (CIDR)",
      base64: "base64 u\u017Ekoduota eilut\u0117",
      base64url: "base64url u\u017Ekoduota eilut\u0117",
      json_string: "JSON eilut\u0117",
      e164: "E.164 numeris",
      credit_card: "kredito kortel\u0117s numeris",
      currency_code: "valiutos kodas",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u012Fvestis"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "skai\u010Dius",
      bigint: "sveikasis skai\u010Dius",
      string: "eilut\u0117",
      boolean: "login\u0117 reik\u0161m\u0117",
      undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
      function: "funkcija",
      symbol: "simbolis",
      array: "masyvas",
      object: "objektas",
      null: "nulin\u0117 reik\u0161m\u0117"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Gautas tipas ${received}, o tik\u0117tasi - instanceof ${issue3.expected}`;
          }
          return `Gautas tipas ${received}, o tik\u0117tasi - ${expected2}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Privalo b\u016Bti ${stringifyPrimitive(issue3.values[0])}`;
          return `Privalo b\u016Bti vienas i\u0161 ${joinValues(issue3.values, "|")} pasirinkim\u0173`;
        case "too_big": {
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          const sizing = getSizing(issue3.origin, getUnitTypeFromNumber(Number(issue3.maximum)), issue3.inclusive ?? false, "smaller");
          if (sizing?.verb)
            return `${capitalizeFirstCharacter(origin ?? issue3.origin ?? "reik\u0161m\u0117")} ${sizing.verb} ${issue3.maximum.toString()} ${sizing.unit ?? "element\u0173"}`;
          const adj = issue3.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
          return `${capitalizeFirstCharacter(origin ?? issue3.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${adj} ${issue3.maximum.toString()} ${sizing?.unit}`;
        }
        case "too_small": {
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          const sizing = getSizing(issue3.origin, getUnitTypeFromNumber(Number(issue3.minimum)), issue3.inclusive ?? false, "bigger");
          if (sizing?.verb)
            return `${capitalizeFirstCharacter(origin ?? issue3.origin ?? "reik\u0161m\u0117")} ${sizing.verb} ${issue3.minimum.toString()} ${sizing.unit ?? "element\u0173"}`;
          const adj = issue3.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
          return `${capitalizeFirstCharacter(origin ?? issue3.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${adj} ${issue3.minimum.toString()} ${sizing?.unit}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Eilut\u0117 privalo prasid\u0117ti "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Eilut\u0117 privalo pasibaigti "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Eilut\u0117 privalo \u012Ftraukti "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Eilut\u0117 privalo atitikti ${_issue.pattern}`;
          return `Neteisingas ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Skai\u010Dius privalo b\u016Bti ${issue3.divisor} kartotinis.`;
        case "unrecognized_keys":
          return `Neatpa\u017Eint${issue3.keys.length > 1 ? "i" : "as"} rakt${issue3.keys.length > 1 ? "ai" : "as"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return "Rastas klaidingas raktas";
        case "invalid_union":
          return "Klaidinga \u012Fvestis";
        case "invalid_element": {
          const origin = TypeDictionary[issue3.origin] ?? issue3.origin;
          return `${capitalizeFirstCharacter(origin ?? issue3.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
        }
        default:
          return "Klaidinga \u012Fvestis";
      }
    };
  };
  function lt_default() {
    return {
      localeError: error33()
    };
  }

  // ../../../node_modules/zod/v4/locales/mk.js
  var error34 = () => {
    const Sizable = {
      string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
      file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
      array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
      set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
      map: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0432\u043D\u0435\u0441",
      email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
      url: "URL",
      emoji: "\u0435\u043C\u043E\u045F\u0438",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
      date: "ISO \u0434\u0430\u0442\u0443\u043C",
      time: "ISO \u0432\u0440\u0435\u043C\u0435",
      duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
      ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
      ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
      mac: "MAC \u0430\u0434\u0440\u0435\u0441\u0430",
      cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
      cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
      base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
      base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
      json_string: "JSON \u043D\u0438\u0437\u0430",
      e164: "E.164 \u0431\u0440\u043E\u0458",
      credit_card: "\u0431\u0440\u043E\u0458 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u0447\u043A\u0430",
      currency_code: "\u043A\u043E\u0434 \u043D\u0430 \u0432\u0430\u043B\u0443\u0442\u0430",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0432\u043D\u0435\u0441"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0431\u0440\u043E\u0458",
      array: "\u043D\u0438\u0437\u0430"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${issue3.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${received}`;
          }
          return `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${expected2}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Invalid input: expected ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${issue3.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}`;
          return `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${issue3.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${issue3.origin} \u0434\u0430 \u0438\u043C\u0430 ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${issue3.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${_issue.pattern}`;
          return `Invalid ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${issue3.divisor}`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${issue3.origin}`;
        case "invalid_union":
          return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
        case "invalid_element":
          return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${issue3.origin}`;
        default:
          return `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441`;
      }
    };
  };
  function mk_default() {
    return {
      localeError: error34()
    };
  }

  // ../../../node_modules/zod/v4/locales/ms.js
  var error35 = () => {
    const Sizable = {
      string: { unit: "aksara", verb: "mempunyai" },
      file: { unit: "bait", verb: "mempunyai" },
      array: { unit: "elemen", verb: "mempunyai" },
      set: { unit: "elemen", verb: "mempunyai" },
      map: { unit: "elemen", verb: "mempunyai" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "alamat e-mel",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "tarikh masa ISO",
      date: "tarikh ISO",
      time: "masa ISO",
      duration: "tempoh ISO",
      ipv4: "alamat IPv4",
      ipv6: "alamat IPv6",
      mac: "alamat MAC",
      cidrv4: "julat IPv4",
      cidrv6: "julat IPv6",
      base64: "string dikodkan base64",
      base64url: "string dikodkan base64url",
      json_string: "string JSON",
      e164: "nombor E.164",
      credit_card: "nombor kad kredit",
      currency_code: "kod mata wang",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "nombor"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Input tidak sah: dijangka instanceof ${issue3.expected}, diterima ${received}`;
          }
          return `Input tidak sah: dijangka ${expected2}, diterima ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Input tidak sah: dijangka ${stringifyPrimitive(issue3.values[0])}`;
          return `Pilihan tidak sah: dijangka salah satu daripada ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Terlalu besar: dijangka ${issue3.origin ?? "nilai"} ${sizing.verb} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elemen"}`;
          return `Terlalu besar: dijangka ${issue3.origin ?? "nilai"} adalah ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Terlalu kecil: dijangka ${issue3.origin} ${sizing.verb} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Terlalu kecil: dijangka ${issue3.origin} adalah ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `String tidak sah: mesti bermula dengan "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `String tidak sah: mesti berakhir dengan "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `String tidak sah: mesti mengandungi "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `String tidak sah: mesti sepadan dengan corak ${_issue.pattern}`;
          return `${FormatDictionary[_issue.format] ?? issue3.format} tidak sah`;
        }
        case "not_multiple_of":
          return `Nombor tidak sah: perlu gandaan ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Kunci tidak dikenali: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Kunci tidak sah dalam ${issue3.origin}`;
        case "invalid_union":
          return "Input tidak sah";
        case "invalid_element":
          return `Nilai tidak sah dalam ${issue3.origin}`;
        default:
          return `Input tidak sah`;
      }
    };
  };
  function ms_default() {
    return {
      localeError: error35()
    };
  }

  // ../../../node_modules/zod/v4/locales/ne.js
  var error36 = () => {
    const Sizable = {
      string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
      file: { unit: "\u092C\u093E\u0907\u091F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
      array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
      set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
      map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0907\u0928\u092A\u0941\u091F",
      email: "\u0907\u092E\u0947\u0932 \u0920\u0947\u0917\u093E\u0928\u093E",
      url: "URL",
      emoji: "\u0907\u092E\u094B\u091C\u0940",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u092E\u093F\u0924\u093F \u0930 \u0938\u092E\u092F",
      date: "ISO \u092E\u093F\u0924\u093F",
      time: "ISO \u0938\u092E\u092F",
      duration: "ISO \u0905\u0935\u0927\u093F",
      ipv4: "IPv4 \u0920\u0947\u0917\u093E\u0928\u093E",
      ipv6: "IPv6 \u0920\u0947\u0917\u093E\u0928\u093E",
      mac: "MAC \u0920\u0947\u0917\u093E\u0928\u093E",
      cidrv4: "IPv4 \u0926\u093E\u092F\u0930\u093E",
      cidrv6: "IPv6 \u0926\u093E\u092F\u0930\u093E",
      base64: "base64-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
      base64url: "base64url-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
      json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
      e164: "E.164 \u0928\u092E\u094D\u092C\u0930",
      credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0928\u092E\u094D\u092C\u0930",
      currency_code: "\u092E\u0941\u0926\u094D\u0930\u093E \u0915\u094B\u0921",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0907\u0928\u092A\u0941\u091F"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${expected2}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u0939\u0930\u0942 \u092E\u0927\u094D\u092F\u0947 \u090F\u0915 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${issue3.origin ?? "\u092E\u093E\u0928"} \u092E\u093E ${adj}${issue3.maximum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${issue3.origin ?? "\u092E\u093E\u0928"} ${adj}${issue3.maximum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${issue3.origin} \u092E\u093E ${adj}${issue3.minimum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${issue3.origin} ${adj}${issue3.minimum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${_issue.prefix}" \u092C\u093E\u091F \u0938\u0941\u0930\u0941 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
          if (_issue.format === "ends_with")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${_issue.suffix}" \u092E\u093E \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
          if (_issue.format === "includes")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${_issue.includes}" \u0938\u092E\u093E\u0935\u0947\u0936 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
          if (_issue.format === "regex")
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: \u0922\u093E\u0901\u091A\u093E ${_issue.pattern} \u0938\u0901\u0917 \u092E\u0947\u0932 \u0916\u093E\u0928\u0941\u092A\u0930\u094D\u091B`;
          return `\u0905\u092E\u093E\u0928\u094D\u092F ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: ${issue3.divisor} \u0915\u094B \u0917\u0941\u0923\u091C \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
        case "unrecognized_keys":
          return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u091E\u094D\u091C\u0940${issue3.keys.length > 1 ? "\u0939\u0930\u0942" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u091E\u094D\u091C\u0940: ${issue3.origin} \u092E\u093E`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${opts}`;
          }
          return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
        case "invalid_element":
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${issue3.origin} \u092E\u093E`;
        default:
          return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F`;
      }
    };
  };
  function ne_default() {
    return {
      localeError: error36()
    };
  }

  // ../../../node_modules/zod/v4/locales/nl.js
  var error37 = () => {
    const Sizable = {
      string: { unit: "tekens", verb: "heeft" },
      file: { unit: "bytes", verb: "heeft" },
      array: { unit: "elementen", verb: "heeft" },
      set: { unit: "elementen", verb: "heeft" },
      map: { unit: "elementen", verb: "heeft" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "invoer",
      email: "emailadres",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datum en tijd",
      date: "ISO datum",
      time: "ISO tijd",
      duration: "ISO duur",
      ipv4: "IPv4-adres",
      ipv6: "IPv6-adres",
      mac: "MAC-adres",
      cidrv4: "IPv4-bereik",
      cidrv6: "IPv6-bereik",
      base64: "base64-gecodeerde tekst",
      base64url: "base64 URL-gecodeerde tekst",
      json_string: "JSON string",
      e164: "E.164-nummer",
      credit_card: "creditcardnummer",
      currency_code: "valutacode",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "invoer"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "getal"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ongeldige invoer: verwacht instanceof ${issue3.expected}, ontving ${received}`;
          }
          return `Ongeldige invoer: verwacht ${expected2}, ontving ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ongeldige invoer: verwacht ${stringifyPrimitive(issue3.values[0])}`;
          return `Ongeldige optie: verwacht \xE9\xE9n van ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          const longName = issue3.origin === "date" ? "laat" : issue3.origin === "string" ? "lang" : "groot";
          if (sizing)
            return `Te ${longName}: verwacht dat ${issue3.origin ?? "waarde"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elementen"} ${sizing.verb}`;
          return `Te ${longName}: verwacht dat ${issue3.origin ?? "waarde"} ${adj}${issue3.maximum.toString()} is`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          const shortName = issue3.origin === "date" ? "vroeg" : issue3.origin === "string" ? "kort" : "klein";
          if (sizing) {
            return `Te ${shortName}: verwacht dat ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit} ${sizing.verb}`;
          }
          return `Te ${shortName}: verwacht dat ${issue3.origin} ${adj}${issue3.minimum.toString()} is`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Ongeldige tekst: moet met "${_issue.prefix}" beginnen`;
          }
          if (_issue.format === "ends_with")
            return `Ongeldige tekst: moet op "${_issue.suffix}" eindigen`;
          if (_issue.format === "includes")
            return `Ongeldige tekst: moet "${_issue.includes}" bevatten`;
          if (_issue.format === "regex")
            return `Ongeldige tekst: moet overeenkomen met patroon ${_issue.pattern}`;
          return `Ongeldig: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ongeldig getal: moet een veelvoud van ${issue3.divisor} zijn`;
        case "unrecognized_keys":
          return `Onbekende key${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Ongeldige key in ${issue3.origin}`;
        case "invalid_union":
          return "Ongeldige invoer";
        case "invalid_element":
          return `Ongeldige waarde in ${issue3.origin}`;
        default:
          return `Ongeldige invoer`;
      }
    };
  };
  function nl_default() {
    return {
      localeError: error37()
    };
  }

  // ../../../node_modules/zod/v4/locales/nn.js
  var error38 = () => {
    const Sizable = {
      string: { unit: "teikn", verb: "\xE5 ha" },
      file: { unit: "bytes", verb: "\xE5 ha" },
      array: { unit: "element", verb: "\xE5 innehalde" },
      set: { unit: "element", verb: "\xE5 innehalde" },
      map: { unit: "element", verb: "\xE5 innehalde" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "e-postadresse",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dato- og klokkeslett",
      date: "ISO-dato",
      time: "ISO-klokkeslett",
      duration: "ISO-varigheit",
      ipv4: "IPv4-adresse",
      ipv6: "IPv6-adresse",
      mac: "MAC-adresse",
      cidrv4: "IPv4-spekter",
      cidrv6: "IPv6-spekter",
      base64: "base64-enkoda streng",
      base64url: "base64url-enkoda streng",
      json_string: "JSON-streng",
      e164: "E.164-nummer",
      credit_card: "kredittkortnummer",
      currency_code: "valutakode",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "tal",
      array: "liste"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ugyldig input: forventa instanceof ${issue3.expected}, fekk ${received}`;
          }
          return `Ugyldig input: forventa ${expected2}, fekk ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ugyldig verdi: forventa ${stringifyPrimitive(issue3.values[0])}`;
          return `Ugyldig val: forventa eitt av ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `For stor(t): forventa ${issue3.origin ?? "value"} til \xE5 ha ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "element"}`;
          return `For stor(t): forventa ${issue3.origin ?? "value"} til \xE5 ha ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `For lite(n): forventa ${issue3.origin} til \xE5 ha ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `For lite(n): forventa ${issue3.origin} til \xE5 ha ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Ugyldig streng: m\xE5 starte med "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Ugyldig streng: m\xE5 slutte med "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Ugyldig streng: m\xE5 innehalde "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Ugyldig streng: m\xE5 matche m\xF8nsteret ${_issue.pattern}`;
          return `Ugyldig ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ugyldig tal: m\xE5 vere eit multiplum av ${issue3.divisor}`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "Ukjende n\xF8klar" : "Ukjend n\xF8kkel"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Ugyldig n\xF8kkel i ${issue3.origin}`;
        case "invalid_union":
          return "Ugyldig input";
        case "invalid_element":
          return `Ugyldig verdi i ${issue3.origin}`;
        default:
          return `Ugyldig input`;
      }
    };
  };
  function nn_default() {
    return {
      localeError: error38()
    };
  }

  // ../../../node_modules/zod/v4/locales/no.js
  var error39 = () => {
    const Sizable = {
      string: { unit: "tegn", verb: "\xE5 ha" },
      file: { unit: "bytes", verb: "\xE5 ha" },
      array: { unit: "elementer", verb: "\xE5 inneholde" },
      set: { unit: "elementer", verb: "\xE5 inneholde" },
      map: { unit: "elementer", verb: "\xE5 inneholde" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "input",
      email: "e-postadresse",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO dato- og klokkeslett",
      date: "ISO-dato",
      time: "ISO-klokkeslett",
      duration: "ISO-varighet",
      ipv4: "IPv4-adresse",
      ipv6: "IPv6-adresse",
      mac: "MAC-adresse",
      cidrv4: "IPv4-spekter",
      cidrv6: "IPv6-spekter",
      base64: "base64-enkodet streng",
      base64url: "base64url-enkodet streng",
      json_string: "JSON-streng",
      e164: "E.164-nummer",
      credit_card: "kredittkortnummer",
      currency_code: "valutakode",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "tall",
      array: "liste"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ugyldig input: forventet instanceof ${issue3.expected}, fikk ${received}`;
          }
          return `Ugyldig input: forventet ${expected2}, fikk ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ugyldig verdi: forventet ${stringifyPrimitive(issue3.values[0])}`;
          return `Ugyldig valg: forventet en av ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `For stor(t): forventet ${issue3.origin ?? "value"} til \xE5 ha ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elementer"}`;
          return `For stor(t): forventet ${issue3.origin ?? "value"} til \xE5 ha ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `For lite(n): forventet ${issue3.origin} til \xE5 ha ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `For lite(n): forventet ${issue3.origin} til \xE5 ha ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Ugyldig streng: m\xE5 starte med "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Ugyldig streng: m\xE5 ende med "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Ugyldig streng: m\xE5 inneholde "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Ugyldig streng: m\xE5 matche m\xF8nsteret ${_issue.pattern}`;
          return `Ugyldig ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${issue3.divisor}`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Ugyldig n\xF8kkel i ${issue3.origin}`;
        case "invalid_union":
          return "Ugyldig input";
        case "invalid_element":
          return `Ugyldig verdi i ${issue3.origin}`;
        default:
          return `Ugyldig input`;
      }
    };
  };
  function no_default() {
    return {
      localeError: error39()
    };
  }

  // ../../../node_modules/zod/v4/locales/ota.js
  var error40 = () => {
    const Sizable = {
      string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
      file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
      array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
      set: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
      map: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "giren",
      email: "epostag\xE2h",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO heng\xE2m\u0131",
      date: "ISO tarihi",
      time: "ISO zaman\u0131",
      duration: "ISO m\xFCddeti",
      ipv4: "IPv4 ni\u015F\xE2n\u0131",
      ipv6: "IPv6 ni\u015F\xE2n\u0131",
      mac: "MAC ni\u015F\xE2n\u0131",
      cidrv4: "IPv4 menzili",
      cidrv6: "IPv6 menzili",
      base64: "base64-\u015Fifreli metin",
      base64url: "base64url-\u015Fifreli metin",
      json_string: "JSON metin",
      e164: "E.164 say\u0131s\u0131",
      credit_card: "i'tib\xE2r kart\u0131 numaras\u0131",
      currency_code: "para birimi kodu",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "giren"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "numara",
      array: "saf",
      null: "gayb"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `F\xE2sit giren: umulan instanceof ${issue3.expected}, al\u0131nan ${received}`;
          }
          return `F\xE2sit giren: umulan ${expected2}, al\u0131nan ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `F\xE2sit giren: umulan ${stringifyPrimitive(issue3.values[0])}`;
          return `F\xE2sit tercih: m\xFBteberler ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Fazla b\xFCy\xFCk: ${issue3.origin ?? "value"}, ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elements"} sahip olmal\u0131yd\u0131.`;
          return `Fazla b\xFCy\xFCk: ${issue3.origin ?? "value"}, ${adj}${issue3.maximum.toString()} olmal\u0131yd\u0131.`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Fazla k\xFC\xE7\xFCk: ${issue3.origin}, ${adj}${issue3.minimum.toString()} ${sizing.unit} sahip olmal\u0131yd\u0131.`;
          }
          return `Fazla k\xFC\xE7\xFCk: ${issue3.origin}, ${adj}${issue3.minimum.toString()} olmal\u0131yd\u0131.`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `F\xE2sit metin: "${_issue.prefix}" ile ba\u015Flamal\u0131.`;
          if (_issue.format === "ends_with")
            return `F\xE2sit metin: "${_issue.suffix}" ile bitmeli.`;
          if (_issue.format === "includes")
            return `F\xE2sit metin: "${_issue.includes}" ihtiv\xE2 etmeli.`;
          if (_issue.format === "regex")
            return `F\xE2sit metin: ${_issue.pattern} nak\u015F\u0131na uymal\u0131.`;
          return `F\xE2sit ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `F\xE2sit say\u0131: ${issue3.divisor} kat\u0131 olmal\u0131yd\u0131.`;
        case "unrecognized_keys":
          return `Tan\u0131nmayan anahtar ${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} i\xE7in tan\u0131nmayan anahtar var.`;
        case "invalid_union":
          return "Giren tan\u0131namad\u0131.";
        case "invalid_element":
          return `${issue3.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
        default:
          return `K\u0131ymet tan\u0131namad\u0131.`;
      }
    };
  };
  function ota_default() {
    return {
      localeError: error40()
    };
  }

  // ../../../node_modules/zod/v4/locales/ps.js
  var error41 = () => {
    const Sizable = {
      string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
      file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
      array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
      set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
      map: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0648\u0631\u0648\u062F\u064A",
      email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
      url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
      emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
      date: "\u0646\u06D0\u067C\u0647",
      time: "\u0648\u062E\u062A",
      duration: "\u0645\u0648\u062F\u0647",
      ipv4: "\u062F IPv4 \u067E\u062A\u0647",
      ipv6: "\u062F IPv6 \u067E\u062A\u0647",
      mac: "\u062F MAC \u067E\u062A\u0647",
      cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
      cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
      base64: "base64-encoded \u0645\u062A\u0646",
      base64url: "base64url-encoded \u0645\u062A\u0646",
      json_string: "JSON \u0645\u062A\u0646",
      e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
      credit_card: "\u062F \u06A9\u0631\u06CC\u0689\u06CC\u067C \u06A9\u0627\u0631\u062A \u0634\u0645\u06CC\u0631\u0647",
      currency_code: "\u062F \u0627\u0633\u0639\u0627\u0631\u0648 \u06A9\u0648\u0689",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0648\u0631\u0648\u062F\u064A"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0639\u062F\u062F",
      array: "\u0627\u0631\u06D0"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${issue3.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${received} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
          }
          return `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${expected2} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${received} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
        }
        case "invalid_value":
          if (issue3.values.length === 1) {
            return `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${stringifyPrimitive(issue3.values[0])} \u0648\u0627\u06CC`;
          }
          return `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${joinValues(issue3.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${issue3.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A`;
          }
          return `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${issue3.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${adj}${issue3.maximum.toString()} \u0648\u064A`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${issue3.origin} \u0628\u0627\u06CC\u062F ${adj}${issue3.minimum.toString()} ${sizing.unit} \u0648\u0644\u0631\u064A`;
          }
          return `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${issue3.origin} \u0628\u0627\u06CC\u062F ${adj}${issue3.minimum.toString()} \u0648\u064A`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${_issue.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A`;
          }
          if (_issue.format === "ends_with") {
            return `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${_issue.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A`;
          }
          if (_issue.format === "includes") {
            return `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${_issue.includes}" \u0648\u0644\u0631\u064A`;
          }
          if (_issue.format === "regex") {
            return `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${_issue.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A`;
          }
          return `${FormatDictionary[_issue.format] ?? issue3.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
        }
        case "not_multiple_of":
          return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${issue3.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
        case "unrecognized_keys":
          return `\u0646\u0627\u0633\u0645 ${issue3.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${issue3.origin} \u06A9\u06D0`;
        case "invalid_union":
          return `\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A`;
        case "invalid_element":
          return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${issue3.origin} \u06A9\u06D0`;
        default:
          return `\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A`;
      }
    };
  };
  function ps_default() {
    return {
      localeError: error41()
    };
  }

  // ../../../node_modules/zod/v4/locales/pl.js
  var error42 = () => {
    const Sizable = {
      string: { unit: "znak\xF3w", verb: "mie\u0107" },
      file: { unit: "bajt\xF3w", verb: "mie\u0107" },
      array: { unit: "element\xF3w", verb: "mie\u0107" },
      set: { unit: "element\xF3w", verb: "mie\u0107" },
      map: { unit: "element\xF3w", verb: "mie\u0107" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "wyra\u017Cenie",
      email: "adres email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "data i godzina w formacie ISO",
      date: "data w formacie ISO",
      time: "godzina w formacie ISO",
      duration: "czas trwania ISO",
      ipv4: "adres IPv4",
      ipv6: "adres IPv6",
      mac: "adres MAC",
      cidrv4: "zakres IPv4",
      cidrv6: "zakres IPv6",
      base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
      base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
      json_string: "ci\u0105g znak\xF3w w formacie JSON",
      e164: "liczba E.164",
      credit_card: "numer karty kredytowej",
      currency_code: "kod waluty",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "wej\u015Bcie"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "liczba",
      array: "tablica"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${issue3.expected}, otrzymano ${received}`;
          }
          return `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${expected2}, otrzymano ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${stringifyPrimitive(issue3.values[0])}`;
          return `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${issue3.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "element\xF3w"}`;
          }
          return `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${issue3.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${issue3.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${adj}${issue3.minimum.toString()} ${sizing.unit ?? "element\xF3w"}`;
          }
          return `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${issue3.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${_issue.pattern}`;
          return `Nieprawid\u0142ow(y/a/e) ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Nierozpoznane klucze${issue3.keys.length > 1 ? "s" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Nieprawid\u0142owy klucz w ${issue3.origin}`;
        case "invalid_union":
          return "Nieprawid\u0142owe dane wej\u015Bciowe";
        case "invalid_element":
          return `Nieprawid\u0142owa warto\u015B\u0107 w ${issue3.origin}`;
        default:
          return `Nieprawid\u0142owe dane wej\u015Bciowe`;
      }
    };
  };
  function pl_default() {
    return {
      localeError: error42()
    };
  }

  // ../../../node_modules/zod/v4/locales/pt.js
  var error43 = () => {
    const Sizable = {
      string: { unit: "caracteres" },
      file: { unit: "bytes" },
      array: { unit: "elementos" },
      set: { unit: "elementos" },
      map: { unit: "entradas" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "a entrada",
      email: "o endere\xE7o de e-mail",
      url: "o URL",
      emoji: "o emoji",
      uuid: "o UUID",
      uuidv4: "o UUIDv4",
      uuidv6: "o UUIDv6",
      nanoid: "o nanoid",
      guid: "o GUID",
      cuid: "o cuid",
      cuid2: "o cuid2",
      ulid: "o ULID",
      xid: "o XID",
      ksuid: "o KSUID",
      datetime: "a data e hora ISO",
      date: "a data ISO",
      time: "a hora ISO",
      duration: "a dura\xE7\xE3o ISO",
      ipv4: "o endere\xE7o IPv4",
      ipv6: "o endere\xE7o IPv6",
      mac: "o endere\xE7o MAC",
      cidrv4: "o intervalo de endere\xE7os IPv4",
      cidrv6: "o intervalo de endere\xE7os IPv6",
      base64: "o texto codificado em base64",
      base64url: "o texto codificado em base64url",
      json_string: "o texto JSON",
      e164: "o n\xFAmero E.164",
      credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
      currency_code: "o c\xF3digo de moeda",
      iban: "o IBAN",
      jwt: "o JWT",
      template_literal: "a entrada"
    };
    const Gender = {
      masculine: { definite: "o", indefinite: "um" },
      feminine: { definite: "a", indefinite: "uma" }
    };
    const TypeDictionary = {
      string: { name: "texto", articles: Gender.masculine },
      number: { name: "n\xFAmero", articles: Gender.masculine },
      int: { name: "n\xFAmero inteiro", articles: Gender.masculine },
      boolean: { name: "valor booleano", articles: Gender.masculine },
      bigint: { name: "n\xFAmero bigint", articles: Gender.masculine },
      symbol: { name: "s\xEDmbolo", articles: Gender.masculine },
      undefined: { name: 'valor "undefined"', articles: Gender.masculine },
      null: { name: 'valor "nulo"', articles: Gender.masculine },
      never: { name: 'valor "never"', articles: Gender.masculine },
      void: { name: 'valor "void"', articles: Gender.masculine },
      date: { name: "data", articles: Gender.feminine },
      array: { name: "vetor", articles: Gender.masculine },
      object: { name: "objeto", articles: Gender.masculine },
      tuple: { name: "tuplo", articles: Gender.masculine },
      record: { name: "registo", articles: Gender.masculine },
      map: { name: "mapa", articles: Gender.masculine },
      set: { name: "conjunto", articles: Gender.masculine },
      file: { name: "ficheiro", articles: Gender.masculine },
      nonoptional: { name: "valor n\xE3o opcional", articles: Gender.masculine },
      nan: { name: 'valor "NaN"', articles: Gender.masculine },
      // Compatibility: "nan" -> "NaN" for display
      function: { name: "fun\xE7\xE3o", articles: Gender.feminine }
    };
    function translateOriginWithArticle(type, articleType) {
      const translatedValue = TypeDictionary[type] ?? { name: `valor "${type}"`, articles: Gender.masculine };
      return `${translatedValue.articles[articleType]} ${translatedValue.name}`;
    }
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = translateOriginWithArticle(issue3.expected, "indefinite");
          const receivedType = parsedType(issue3.input);
          const received = translateOriginWithArticle(receivedType, "indefinite");
          return `Entrada inv\xE1lida: esperava ${expected2}, recebeu ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Entrada inv\xE1lida: esperava ${stringifyPrimitive(issue3.values[0])}`;
          return `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Demasiado grande: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} tivesse ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "elementos"}`;
          return `Demasiado grande: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} fosse ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Demasiado pequeno: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} tivesse ${adj} ${issue3.minimum.toString()} ${sizing.unit ?? "elementos"}`;
          }
          return `Demasiado pequeno: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} fosse ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Texto inv\xE1lido: deve come\xE7ar por "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Texto inv\xE1lido: deve terminar em "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Texto inv\xE1lido: deve incluir "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${_issue.pattern}`;
          return `Formato d${FormatDictionary[_issue.format] ?? issue3.format} inv\xE1lido`;
        }
        case "not_multiple_of":
          return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${issue3.divisor}`;
        case "unrecognized_keys": {
          const plural2 = issue3.keys.length > 1 ? "s" : "";
          return `Chave${plural2} inv\xE1lida${plural2}: ${joinValues(issue3.keys, ", ")}`;
        }
        case "invalid_key":
          return `Entrada inv\xE1lida n${translateOriginWithArticle(issue3.origin, "definite")}`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${opts}`;
          }
          return "Entrada inv\xE1lida";
        case "invalid_element":
          return `Entrada inv\xE1lida n${translateOriginWithArticle(issue3.origin, "definite")}`;
        default:
          return `Entrada inv\xE1lida`;
      }
    };
  };
  function pt_default() {
    return {
      localeError: error43()
    };
  }

  // ../../../node_modules/zod/v4/locales/pt-BR.js
  var error44 = () => {
    const Sizable = {
      string: { unit: "caracteres" },
      file: { unit: "bytes" },
      array: { unit: "elementos" },
      set: { unit: "elementos" },
      map: { unit: "entradas" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "a entrada",
      email: "o endere\xE7o de e-mail",
      url: "o URL",
      emoji: "o emoji",
      uuid: "o UUID",
      uuidv4: "o UUIDv4",
      uuidv6: "o UUIDv6",
      nanoid: "o nanoid",
      guid: "o GUID",
      cuid: "o cuid",
      cuid2: "o cuid2",
      ulid: "o ULID",
      xid: "o XID",
      ksuid: "o KSUID",
      datetime: "a data e hora ISO",
      date: "a data ISO",
      time: "a hora ISO",
      duration: "a dura\xE7\xE3o ISO",
      ipv4: "o endere\xE7o IPv4",
      ipv6: "o endere\xE7o IPv6",
      mac: "o endere\xE7o MAC",
      cidrv4: "a faixa de endere\xE7os IPv4",
      cidrv6: "a faixa de endere\xE7os IPv6",
      base64: "o texto codificado em base64",
      base64url: "o texto codificado em base64url",
      json_string: "o texto JSON",
      e164: "o n\xFAmero E.164",
      credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
      currency_code: "o c\xF3digo de moeda",
      iban: "o IBAN",
      jwt: "o JWT",
      template_literal: "a entrada"
    };
    const Gender = {
      masculine: { definite: "o", indefinite: "um" },
      feminine: { definite: "a", indefinite: "uma" }
    };
    const TypeDictionary = {
      string: { name: "texto", articles: Gender.masculine },
      number: { name: "n\xFAmero", articles: Gender.masculine },
      int: { name: "n\xFAmero inteiro", articles: Gender.masculine },
      boolean: { name: "valor booleano", articles: Gender.masculine },
      bigint: { name: "n\xFAmero bigint", articles: Gender.masculine },
      symbol: { name: "s\xEDmbolo", articles: Gender.masculine },
      undefined: { name: 'valor "undefined"', articles: Gender.masculine },
      null: { name: 'valor "nulo"', articles: Gender.masculine },
      never: { name: 'valor "never"', articles: Gender.masculine },
      void: { name: 'valor "void"', articles: Gender.masculine },
      date: { name: "data", articles: Gender.feminine },
      array: { name: "vetor", articles: Gender.masculine },
      object: { name: "objeto", articles: Gender.masculine },
      tuple: { name: "tupla", articles: Gender.feminine },
      record: { name: "registro", articles: Gender.masculine },
      map: { name: "mapa", articles: Gender.masculine },
      set: { name: "conjunto", articles: Gender.masculine },
      file: { name: "arquivo", articles: Gender.masculine },
      nonoptional: { name: "valor n\xE3o opcional", articles: Gender.masculine },
      nan: { name: 'valor "NaN"', articles: Gender.masculine },
      // Compatibility: "nan" -> "NaN" for display
      function: { name: "fun\xE7\xE3o", articles: Gender.feminine }
    };
    function translateOriginWithArticle(type, articleType) {
      const translatedValue = TypeDictionary[type] ?? { name: `valor "${type}"`, articles: Gender.masculine };
      return `${translatedValue.articles[articleType]} ${translatedValue.name}`;
    }
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = translateOriginWithArticle(issue3.expected, "indefinite");
          const receivedType = parsedType(issue3.input);
          const received = translateOriginWithArticle(receivedType, "indefinite");
          return `Entrada inv\xE1lida: esperava ${expected2}, recebeu ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Entrada inv\xE1lida: esperava ${stringifyPrimitive(issue3.values[0])}`;
          return `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Grande demais: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} tivesse ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "elementos"}`;
          return `Grande demais: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} fosse ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Pequeno demais: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} tivesse ${adj} ${issue3.minimum.toString()} ${sizing.unit ?? "elementos"}`;
          }
          return `Pequeno demais: esperava que ${translateOriginWithArticle(issue3.origin, "definite")} fosse ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Texto inv\xE1lido: deve come\xE7ar com "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Texto inv\xE1lido: deve terminar com "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Texto inv\xE1lido: deve incluir "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${_issue.pattern}`;
          return `Formato d${FormatDictionary[_issue.format] ?? issue3.format} inv\xE1lido`;
        }
        case "not_multiple_of":
          return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${issue3.divisor}`;
        case "unrecognized_keys": {
          const plural2 = issue3.keys.length > 1 ? "s" : "";
          return `Chave${plural2} inv\xE1lida${plural2}: ${joinValues(issue3.keys, ", ")}`;
        }
        case "invalid_key":
          return `Entrada inv\xE1lida n${translateOriginWithArticle(issue3.origin, "definite")}`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${opts}`;
          }
          return "Entrada inv\xE1lida";
        case "invalid_element":
          return `Entrada inv\xE1lida n${translateOriginWithArticle(issue3.origin, "definite")}`;
        default:
          return `Entrada inv\xE1lida`;
      }
    };
  };
  function pt_BR_default() {
    return {
      localeError: error44()
    };
  }

  // ../../../node_modules/zod/v4/locales/ro.js
  var error45 = () => {
    const Sizable = {
      string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
      file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
      array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
      set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
      map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "intrare",
      email: "adres\u0103 de email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "dat\u0103 \u0219i or\u0103 ISO",
      date: "dat\u0103 ISO",
      time: "or\u0103 ISO",
      duration: "durat\u0103 ISO",
      ipv4: "adres\u0103 IPv4",
      ipv6: "adres\u0103 IPv6",
      mac: "adres\u0103 MAC",
      cidrv4: "interval IPv4",
      cidrv6: "interval IPv6",
      base64: "\u0219ir codat base64",
      base64url: "\u0219ir codat base64url",
      json_string: "\u0219ir JSON",
      e164: "num\u0103r E.164",
      credit_card: "num\u0103r de card de credit",
      currency_code: "cod valutar",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "intrare"
    };
    const TypeDictionary = {
      nan: "NaN",
      string: "\u0219ir",
      number: "num\u0103r",
      boolean: "boolean",
      function: "func\u021Bie",
      array: "matrice",
      object: "obiect",
      undefined: "nedefinit",
      symbol: "simbol",
      bigint: "num\u0103r mare",
      void: "void",
      never: "never",
      map: "hart\u0103",
      set: "set"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `Intrare invalid\u0103: a\u0219teptat ${expected2}, primit ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Intrare invalid\u0103: a\u0219teptat ${stringifyPrimitive(issue3.values[0])}`;
          return `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Prea mare: a\u0219teptat ca ${issue3.origin ?? "valoarea"} ${sizing.verb} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elemente"}`;
          return `Prea mare: a\u0219teptat ca ${issue3.origin ?? "valoarea"} s\u0103 fie ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Prea mic: a\u0219teptat ca ${issue3.origin} ${sizing.verb} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Prea mic: a\u0219teptat ca ${issue3.origin} s\u0103 fie ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u0218ir invalid: trebuie s\u0103 se termine cu "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${_issue.pattern}`;
          return `Format invalid: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Chei nerecunoscute: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Cheie invalid\u0103 \xEEn ${issue3.origin}`;
        case "invalid_union":
          return "Intrare invalid\u0103";
        case "invalid_element":
          return `Valoare invalid\u0103 \xEEn ${issue3.origin}`;
        default:
          return `Intrare invalid\u0103`;
      }
    };
  };
  function ro_default() {
    return {
      localeError: error45()
    };
  }

  // ../../../node_modules/zod/v4/locales/ru.js
  function getRussianPlural(count, one, few, many) {
    const absCount = Math.abs(count);
    const lastDigit = absCount % 10;
    const lastTwoDigits = absCount % 100;
    if (lastTwoDigits >= 11 && lastTwoDigits <= 19) {
      return many;
    }
    if (lastDigit === 1) {
      return one;
    }
    if (lastDigit >= 2 && lastDigit <= 4) {
      return few;
    }
    return many;
  }
  var error46 = () => {
    const Sizable = {
      string: {
        unit: {
          one: "\u0441\u0438\u043C\u0432\u043E\u043B",
          few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
          many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
        },
        verb: "\u0438\u043C\u0435\u0442\u044C"
      },
      file: {
        unit: {
          one: "\u0431\u0430\u0439\u0442",
          few: "\u0431\u0430\u0439\u0442\u0430",
          many: "\u0431\u0430\u0439\u0442"
        },
        verb: "\u0438\u043C\u0435\u0442\u044C"
      },
      array: {
        unit: {
          one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
          few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
          many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
        },
        verb: "\u0438\u043C\u0435\u0442\u044C"
      },
      set: {
        unit: {
          one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
          few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
          many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
        },
        verb: "\u0438\u043C\u0435\u0442\u044C"
      },
      map: {
        unit: {
          one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
          few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
          many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
        },
        verb: "\u0438\u043C\u0435\u0442\u044C"
      }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0432\u0432\u043E\u0434",
      email: "email \u0430\u0434\u0440\u0435\u0441",
      url: "URL",
      emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
      date: "ISO \u0434\u0430\u0442\u0430",
      time: "ISO \u0432\u0440\u0435\u043C\u044F",
      duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
      ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
      ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
      mac: "MAC \u0430\u0434\u0440\u0435\u0441",
      cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
      cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
      base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
      base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
      json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
      e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
      credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
      currency_code: "\u043A\u043E\u0434 \u0432\u0430\u043B\u044E\u0442\u044B",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0432\u0432\u043E\u0434"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0447\u0438\u0441\u043B\u043E",
      array: "\u043C\u0430\u0441\u0441\u0438\u0432"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${issue3.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${received}`;
          }
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${expected2}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${stringifyPrimitive(issue3.values[0])}`;
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            const maxValue = Number(issue3.maximum);
            const unit = getRussianPlural(maxValue, sizing.unit.one, sizing.unit.few, sizing.unit.many);
            return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${issue3.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${adj}${issue3.maximum.toString()} ${unit}`;
          }
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${issue3.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            const minValue = Number(issue3.minimum);
            const unit = getRussianPlural(minValue, sizing.unit.one, sizing.unit.few, sizing.unit.many);
            return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${issue3.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${adj}${issue3.minimum.toString()} ${unit}`;
          }
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${issue3.origin} \u0431\u0443\u0434\u0435\u0442 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${_issue.pattern}`;
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${issue3.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${issue3.keys.length > 1 ? "\u0438" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${issue3.origin}`;
        case "invalid_union":
          return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
        case "invalid_element":
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${issue3.origin}`;
        default:
          return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435`;
      }
    };
  };
  function ru_default() {
    return {
      localeError: error46()
    };
  }

  // ../../../node_modules/zod/v4/locales/sk.js
  var error47 = () => {
    const Sizable = {
      string: { unit: "znakov", verb: "ma\u0165" },
      file: { unit: "bajtov", verb: "ma\u0165" },
      array: { unit: "prvkov", verb: "ma\u0165" },
      set: { unit: "prvkov", verb: "ma\u0165" },
      map: { unit: "polo\u017Eiek", verb: "ma\u0165" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "regul\xE1rny v\xFDraz",
      email: "e-mailov\xE1 adresa",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "d\xE1tum a \u010Das vo form\xE1te ISO",
      date: "d\xE1tum vo form\xE1te ISO",
      time: "\u010Das vo form\xE1te ISO",
      duration: "doba trvania ISO",
      ipv4: "IPv4 adresa",
      ipv6: "IPv6 adresa",
      mac: "MAC adresa",
      cidrv4: "rozsah IPv4",
      cidrv6: "rozsah IPv6",
      base64: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64",
      base64url: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64url",
      json_string: "re\u0165azec vo form\xE1te JSON",
      e164: "\u010D\xEDslo E.164",
      credit_card: "\u010D\xEDslo kreditnej karty",
      currency_code: "k\xF3d meny",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "vstup"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u010D\xEDslo",
      string: "re\u0165azec",
      function: "funkcia",
      array: "pole"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 instanceof ${issue3.expected}, obdr\u017Ean\xE9 ${received}`;
          }
          return `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${expected2}, obdr\u017Ean\xE9 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${stringifyPrimitive(issue3.values[0])}`;
          return `Neplatn\xFD vstup: o\u010Dak\xE1van\xE1 jedna z hodn\xF4t ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${issue3.origin ?? "hodnota"} mus\xED ma\u0165 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "prvkov"}`;
          }
          return `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${issue3.origin ?? "hodnota"} mus\xED by\u0165 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Hodnota je pr\xEDli\u0161 mal\xE1: ${issue3.origin ?? "hodnota"} mus\xED ma\u0165 ${adj}${issue3.minimum.toString()} ${sizing.unit ?? "prvkov"}`;
          }
          return `Hodnota je pr\xEDli\u0161 mal\xE1: ${issue3.origin ?? "hodnota"} mus\xED by\u0165 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Neplatn\xFD re\u0165azec: mus\xED za\u010D\xEDna\u0165 na "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Neplatn\xFD re\u0165azec: mus\xED kon\u010Di\u0165 na "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Neplatn\xFD re\u0165azec: mus\xED obsahova\u0165 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Neplatn\xFD re\u0165azec: mus\xED zodpoveda\u0165 vzoru ${_issue.pattern}`;
          return `Neplatn\xFD form\xE1t ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Neplatn\xE9 \u010D\xEDslo: mus\xED by\u0165 n\xE1sobkom ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Nezn\xE1me kl\xFA\u010De: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Neplatn\xFD kl\xFA\u010D v ${issue3.origin}`;
        case "invalid_union":
          return "Neplatn\xFD vstup";
        case "invalid_element":
          return `Neplatn\xE1 hodnota v ${issue3.origin}`;
        default:
          return `Neplatn\xFD vstup`;
      }
    };
  };
  function sk_default() {
    return {
      localeError: error47()
    };
  }

  // ../../../node_modules/zod/v4/locales/sl.js
  var error48 = () => {
    const Sizable = {
      string: { unit: "znakov", verb: "imeti" },
      file: { unit: "bajtov", verb: "imeti" },
      array: { unit: "elementov", verb: "imeti" },
      set: { unit: "elementov", verb: "imeti" },
      map: { unit: "elementov", verb: "imeti" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "vnos",
      email: "e-po\u0161tni naslov",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO datum in \u010Das",
      date: "ISO datum",
      time: "ISO \u010Das",
      duration: "ISO trajanje",
      ipv4: "IPv4 naslov",
      ipv6: "IPv6 naslov",
      mac: "MAC naslov",
      cidrv4: "obseg IPv4",
      cidrv6: "obseg IPv6",
      base64: "base64 kodiran niz",
      base64url: "base64url kodiran niz",
      json_string: "JSON niz",
      e164: "E.164 \u0161tevilka",
      credit_card: "\u0161tevilka kreditne kartice",
      currency_code: "koda valute",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "vnos"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0161tevilo",
      array: "tabela"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Neveljaven vnos: pri\u010Dakovano instanceof ${issue3.expected}, prejeto ${received}`;
          }
          return `Neveljaven vnos: pri\u010Dakovano ${expected2}, prejeto ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Neveljaven vnos: pri\u010Dakovano ${stringifyPrimitive(issue3.values[0])}`;
          return `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Preveliko: pri\u010Dakovano, da bo ${issue3.origin ?? "vrednost"} imelo ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "elementov"}`;
          return `Preveliko: pri\u010Dakovano, da bo ${issue3.origin ?? "vrednost"} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Premajhno: pri\u010Dakovano, da bo ${issue3.origin} imelo ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Premajhno: pri\u010Dakovano, da bo ${issue3.origin} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Neveljaven niz: mora se za\u010Deti z "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Neveljaven niz: mora se kon\u010Dati z "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Neveljaven niz: mora vsebovati "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Neveljaven niz: mora ustrezati vzorcu ${_issue.pattern}`;
          return `Neveljaven ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Neprepoznan${issue3.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Neveljaven klju\u010D v ${issue3.origin}`;
        case "invalid_union":
          return "Neveljaven vnos";
        case "invalid_element":
          return `Neveljavna vrednost v ${issue3.origin}`;
        default:
          return "Neveljaven vnos";
      }
    };
  };
  function sl_default() {
    return {
      localeError: error48()
    };
  }

  // ../../../node_modules/zod/v4/locales/sv.js
  var error49 = () => {
    const Sizable = {
      string: { unit: "tecken", verb: "att ha" },
      file: { unit: "bytes", verb: "att ha" },
      array: { unit: "objekt", verb: "att inneh\xE5lla" },
      set: { unit: "objekt", verb: "att inneh\xE5lla" },
      map: { unit: "objekt", verb: "att inneh\xE5lla" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "regulj\xE4rt uttryck",
      email: "e-postadress",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO-datum och tid",
      date: "ISO-datum",
      time: "ISO-tid",
      duration: "ISO-varaktighet",
      ipv4: "IPv4-adress",
      ipv6: "IPv6-adress",
      mac: "MAC-adress",
      cidrv4: "IPv4-spektrum",
      cidrv6: "IPv6-spektrum",
      base64: "base64-kodad str\xE4ng",
      base64url: "base64url-kodad str\xE4ng",
      json_string: "JSON-str\xE4ng",
      e164: "E.164-nummer",
      credit_card: "kreditkortsnummer",
      currency_code: "valutakod",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "mall-literal"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "antal",
      array: "lista"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${issue3.expected}, fick ${received}`;
          }
          return `Ogiltig inmatning: f\xF6rv\xE4ntat ${expected2}, fick ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ogiltig inmatning: f\xF6rv\xE4ntat ${stringifyPrimitive(issue3.values[0])}`;
          return `Ogiltigt val: f\xF6rv\xE4ntade en av ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `F\xF6r stor(t): f\xF6rv\xE4ntade ${issue3.origin ?? "v\xE4rdet"} att ha ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "element"}`;
          }
          return `F\xF6r stor(t): f\xF6rv\xE4ntat ${issue3.origin ?? "v\xE4rdet"} att ha ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `F\xF6r lite(t): f\xF6rv\xE4ntade ${issue3.origin ?? "v\xE4rdet"} att ha ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `F\xF6r lite(t): f\xF6rv\xE4ntade ${issue3.origin ?? "v\xE4rdet"} att ha ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `Ogiltig str\xE4ng: m\xE5ste sluta med "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${_issue.pattern}"`;
          return `Ogiltig(t) ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ogiltigt tal: m\xE5ste vara en multipel av ${issue3.divisor}`;
        case "unrecognized_keys":
          return `${issue3.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Ogiltig nyckel i ${issue3.origin ?? "v\xE4rdet"}`;
        case "invalid_union":
          return "Ogiltig input";
        case "invalid_element":
          return `Ogiltigt v\xE4rde i ${issue3.origin ?? "v\xE4rdet"}`;
        default:
          return `Ogiltig input`;
      }
    };
  };
  function sv_default() {
    return {
      localeError: error49()
    };
  }

  // ../../../node_modules/zod/v4/locales/ta.js
  var error50 = () => {
    const Sizable = {
      string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
      file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
      array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
      set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
      map: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
      email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
      date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
      time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
      duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
      ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
      ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
      mac: "MAC \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
      cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
      cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
      base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
      base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
      json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
      e164: "E.164 \u0B8E\u0BA3\u0BCD",
      credit_card: "\u0B95\u0B9F\u0BA9\u0BCD \u0B85\u0B9F\u0BCD\u0B9F\u0BC8 \u0B8E\u0BA3\u0BCD",
      currency_code: "\u0BA8\u0BBE\u0BA3\u0BAF\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "input"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0B8E\u0BA3\u0BCD",
      array: "\u0B85\u0BA3\u0BBF",
      null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${issue3.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${received}`;
          }
          return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${expected2}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${joinValues(issue3.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${issue3.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
          }
          return `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${issue3.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${adj}${issue3.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
          }
          return `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${issue3.origin} ${adj}${issue3.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${_issue.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
          if (_issue.format === "ends_with")
            return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${_issue.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
          if (_issue.format === "includes")
            return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${_issue.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
          if (_issue.format === "regex")
            return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${_issue.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
          return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${issue3.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
        case "unrecognized_keys":
          return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${issue3.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
        case "invalid_union":
          return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
        case "invalid_element":
          return `${issue3.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
        default:
          return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1`;
      }
    };
  };
  function ta_default() {
    return {
      localeError: error50()
    };
  }

  // ../../../node_modules/zod/v4/locales/tg.js
  var error51 = () => {
    const Sizable = {
      string: { unit: "\u0430\u043B\u043E\u043C\u0430\u0442", verb: "\u0434\u043E\u0448\u0442\u0430 \u0431\u043E\u0448\u0430\u0434" },
      file: { unit: "\u0431\u0430\u0439\u0442", verb: "\u0434\u043E\u0448\u0442\u0430 \u0431\u043E\u0448\u0430\u0434" },
      array: { unit: "\u0443\u043D\u0441\u0443\u0440", verb: "\u0434\u043E\u0448\u0442\u0430 \u0431\u043E\u0448\u0430\u0434" },
      set: { unit: "\u0443\u043D\u0441\u0443\u0440", verb: "\u0434\u043E\u0448\u0442\u0430 \u0431\u043E\u0448\u0430\u0434" },
      map: { unit: "\u0441\u0430\u0431\u0442", verb: "\u0434\u043E\u0448\u0442\u0430 \u0431\u043E\u0448\u0430\u0434" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0432\u0443\u0440\u0443\u0434",
      email: "\u0441\u0443\u0440\u043E\u0493\u0430\u0438 email",
      url: "URL",
      emoji: "\u044D\u043C\u043E\u04B7\u0438",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u0441\u0430\u043D\u0430\u0432\u0443 \u0432\u0430\u049B\u0442\u0438 ISO",
      date: "\u0441\u0430\u043D\u0430\u0438 ISO",
      time: "\u0432\u0430\u049B\u0442\u0438 ISO",
      duration: "\u0434\u0430\u0432\u043E\u043C\u043D\u043E\u043A\u0438\u0438 ISO",
      ipv4: "\u0441\u0443\u0440\u043E\u0493\u0430\u0438 IPv4",
      ipv6: "\u0441\u0443\u0440\u043E\u0493\u0430\u0438 IPv6",
      mac: "\u0441\u0443\u0440\u043E\u0493\u0430\u0438 MAC",
      cidrv4: "\u043C\u0430\u04B3\u0434\u0443\u0434\u0430\u0438 IPv4",
      cidrv6: "\u043C\u0430\u04B3\u0434\u0443\u0434\u0430\u0438 IPv6",
      base64: "\u0441\u0430\u0442\u0440\u0438 \u0434\u0430\u0440 \u0444\u043E\u0440\u043C\u0430\u0442\u0438 base64",
      base64url: "\u0441\u0430\u0442\u0440\u0438 \u0434\u0430\u0440 \u0444\u043E\u0440\u043C\u0430\u0442\u0438 base64url",
      json_string: "\u0441\u0430\u0442\u0440\u0438 JSON",
      e164: "\u0440\u0430\u049B\u0430\u043C\u0438 E.164",
      credit_card: "\u0440\u0430\u049B\u0430\u043C\u0438 \u043A\u043E\u0440\u0442\u0438 \u043A\u0440\u0435\u0434\u0438\u0442\u04E3",
      currency_code: "\u0440\u0430\u043C\u0437\u0438 \u0430\u0441\u044A\u043E\u0440",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0432\u0443\u0440\u0443\u0434"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0440\u0430\u049B\u0430\u043C",
      string: "\u0441\u0430\u0442\u0440",
      array: "\u043C\u0430\u0441\u0441\u0438\u0432",
      object: "\u043E\u0431\u044A\u0435\u043A\u0442",
      date: "\u0441\u0430\u043D\u0430"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `\u0412\u0443\u0440\u0443\u0434\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: ${expected2} \u0438\u043D\u0442\u0438\u0437\u043E\u0440 \u043C\u0435\u0440\u0430\u0444\u0442, ${received} \u0433\u0438\u0440\u0438\u0444\u0442\u0430 \u0448\u0443\u0434`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0412\u0443\u0440\u0443\u0434\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: ${stringifyPrimitive(issue3.values[0])} \u0438\u043D\u0442\u0438\u0437\u043E\u0440 \u043C\u0435\u0440\u0430\u0444\u0442`;
          return `\u0418\u043D\u0442\u0438\u0445\u043E\u0431\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: \u044F\u043A\u0435 \u0430\u0437 ${joinValues(issue3.values, "|")} \u0438\u043D\u0442\u0438\u0437\u043E\u0440 \u043C\u0435\u0440\u0430\u0444\u0442`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0425\u0435\u043B\u0435 \u043A\u0430\u043B\u043E\u043D: ${issue3.origin ?? "\u049B\u0438\u043C\u0430\u0442"} \u0431\u043E\u044F\u0434 ${adj}${issue3.maximum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `\u0425\u0435\u043B\u0435 \u043A\u0430\u043B\u043E\u043D: ${issue3.origin ?? "\u049B\u0438\u043C\u0430\u0442"} \u0431\u043E\u044F\u0434 ${adj}${issue3.maximum.toString()} \u0431\u043E\u0448\u0430\u0434`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0425\u0435\u043B\u0435 \u0445\u0443\u0440\u0434: ${issue3.origin} \u0431\u043E\u044F\u0434 ${adj}${issue3.minimum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `\u0425\u0435\u043B\u0435 \u0445\u0443\u0440\u0434: ${issue3.origin} \u0431\u043E\u044F\u0434 ${adj}${issue3.minimum.toString()} \u0431\u043E\u0448\u0430\u0434`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u0421\u0430\u0442\u0440\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: \u0431\u043E\u044F\u0434 \u0431\u043E "${_issue.prefix}" \u043E\u0493\u043E\u0437 \u0448\u0430\u0432\u0430\u0434`;
          if (_issue.format === "ends_with")
            return `\u0421\u0430\u0442\u0440\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: \u0431\u043E\u044F\u0434 \u0431\u043E "${_issue.suffix}" \u0430\u043D\u04B7\u043E\u043C \u0451\u0431\u0430\u0434`;
          if (_issue.format === "includes")
            return `\u0421\u0430\u0442\u0440\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: \u0431\u043E\u044F\u0434 "${_issue.includes}"-\u0440\u043E \u0434\u0430\u0440 \u0431\u0430\u0440 \u0433\u0438\u0440\u0430\u0434`;
          if (_issue.format === "regex")
            return `\u0421\u0430\u0442\u0440\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: \u0431\u043E\u044F\u0434 \u0431\u0430 \u043D\u0430\u043C\u0443\u043D\u0430\u0438 ${_issue.pattern} \u043C\u0443\u0432\u043E\u0444\u0438\u049B\u0430\u0442 \u043A\u0443\u043D\u0430\u0434`;
          return `${FormatDictionary[_issue.format] ?? issue3.format}-\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442`;
        }
        case "not_multiple_of":
          return `\u0420\u0430\u049B\u0430\u043C\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442: \u0431\u043E\u044F\u0434 \u0431\u0430 ${issue3.divisor} \u0431\u0435 \u0431\u0430\u049B\u0438\u044F \u0442\u0430\u049B\u0441\u0438\u043C \u0448\u0430\u0432\u0430\u0434`;
        case "unrecognized_keys":
          return `\u041A\u0430\u043B\u0438\u0434${issue3.keys.length > 1 ? "\u04B3\u043E\u0438" : "\u0438"} \u043D\u043E\u043C\u0430\u044A\u043B\u0443\u043C: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u041A\u0430\u043B\u0438\u0434\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442 \u0434\u0430\u0440 ${issue3.origin}`;
        case "invalid_union":
          if (issue3.options && Array.isArray(issue3.options) && issue3.options.length > 0) {
            const opts = issue3.options.map((o) => `'${o}'`).join(" | ");
            return `\u049A\u0438\u043C\u0430\u0442\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442\u0438 \u0434\u0438\u0441\u043A\u0440\u0438\u043C\u0438\u043D\u0430\u0442\u043E\u0440: ${opts} \u0438\u043D\u0442\u0438\u0437\u043E\u0440 \u043C\u0435\u0440\u0430\u0444\u0442`;
          }
          return "\u0412\u0443\u0440\u0443\u0434\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442";
        case "invalid_element":
          return `\u049A\u0438\u043C\u0430\u0442\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442 \u0434\u0430\u0440 ${issue3.origin}`;
        default:
          return `\u0412\u0443\u0440\u0443\u0434\u0438 \u043D\u043E\u0434\u0443\u0440\u0443\u0441\u0442`;
      }
    };
  };
  function tg_default() {
    return {
      localeError: error51()
    };
  }

  // ../../../node_modules/zod/v4/locales/th.js
  var error52 = () => {
    const Sizable = {
      string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
      file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
      array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
      set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
      map: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
      email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
      url: "URL",
      emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
      date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
      time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
      duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
      ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
      ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
      mac: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 MAC",
      cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
      cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
      base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
      base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
      json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
      e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
      credit_card: "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15",
      currency_code: "\u0E23\u0E2B\u0E31\u0E2A\u0E2A\u0E01\u0E38\u0E25\u0E40\u0E07\u0E34\u0E19",
      iban: "IBAN",
      jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
      template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
      array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
      null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${issue3.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${received}`;
          }
          return `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${expected2} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${stringifyPrimitive(issue3.values[0])}`;
          return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${issue3.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}`;
          return `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${issue3.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${issue3.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${adj} ${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${issue3.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${_issue.prefix}"`;
          }
          if (_issue.format === "ends_with")
            return `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${_issue.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21`;
          if (_issue.format === "regex")
            return `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${_issue.pattern}`;
          return `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${issue3.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
        case "unrecognized_keys":
          return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${issue3.origin}`;
        case "invalid_union":
          return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
        case "invalid_element":
          return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${issue3.origin}`;
        default:
          return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07`;
      }
    };
  };
  function th_default() {
    return {
      localeError: error52()
    };
  }

  // ../../../node_modules/zod/v4/locales/tk.js
  var error53 = () => {
    const Sizable = {
      string: { unit: "simwol", verb: "bolmaly" },
      file: { unit: "ba\xFDt", verb: "bolmaly" },
      array: { unit: "elementler", verb: "bolmaly" },
      set: { unit: "elementler", verb: "bolmaly" },
      map: { unit: "elementler", verb: "bolmaly" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "giri\u015F",
      email: "e-po\xE7ta salgysy",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO sene we wagt",
      date: "ISO sene",
      time: "ISO wagt",
      duration: "ISO wagt aralygy",
      ipv4: "IPv4 salgysy",
      ipv6: "IPv6 salgysy",
      mac: "MAC salgysy",
      cidrv4: "IPv4 aralygy",
      cidrv6: "IPv6 aralygy",
      base64: "base64 bilen \u015Fifrlenen setir",
      base64url: "base64url bilen \u015Fifrlenen setir",
      json_string: "JSON setiri",
      e164: "E.164 nomeri",
      credit_card: "kredit kartyny\u0148 nomeri",
      currency_code: "wal\xFDuta kody",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u015Fablon"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          return `N\xE4dogry baha: gara\u015Fylan ${expected2} \xFDerine ${received} alyndy`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `N\xE4dogry baha: ${stringifyPrimitive(issue3.values[0])} bolmaly`;
          return `N\xE4dogry sa\xFDlaw: a\u015Fakdakylardan biri bolmaly: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Has uly: gara\u015Fyl\xFDan ${issue3.origin ?? "baha"} ${adj} ${issue3.maximum.toString()} ${sizing.unit ?? "element"}`;
          return `Has uly: gara\u015Fyl\xFDan ${issue3.origin ?? "baha"} ${adj} ${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Has ki\xE7i: gara\u015Fyl\xFDan ${issue3.origin} ${adj} ${issue3.minimum.toString()} ${sizing.unit}`;
          return `Has ki\xE7i: gara\u015Fyl\xFDan ${issue3.origin} ${adj} ${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `N\xE4dogry setir: "${_issue.prefix}" bilen ba\u015Flamaly`;
          if (_issue.format === "ends_with")
            return `N\xE4dogry setir: "${_issue.suffix}" bilen gutarmaly`;
          if (_issue.format === "includes")
            return `N\xE4dogry setir: "${_issue.includes}" saklamaly`;
          if (_issue.format === "regex")
            return `N\xE4dogry setir: ${_issue.pattern} nusga la\xFDyk bolmaly`;
          return `N\xE4dogry ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `N\xE4dogry san: ${issue3.divisor} bilen galyndysyz b\xF6l\xFCnmeli`;
        case "unrecognized_keys":
          return `Tanalma\xFDan a\xE7ar${issue3.keys.length > 1 ? "lar" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} i\xE7inde n\xE4dogry a\xE7ar`;
        case "invalid_union":
          return "N\xE4dogry baha";
        case "invalid_element":
          return `${issue3.origin} i\xE7inde n\xE4dogry baha`;
        default:
          return `N\xE4dogry baha`;
      }
    };
  };
  function tk_default() {
    return {
      localeError: error53()
    };
  }

  // ../../../node_modules/zod/v4/locales/tr.js
  var error54 = () => {
    const Sizable = {
      string: { unit: "karakter", verb: "olmal\u0131" },
      file: { unit: "bayt", verb: "olmal\u0131" },
      array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
      set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
      map: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "girdi",
      email: "e-posta adresi",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO tarih ve saat",
      date: "ISO tarih",
      time: "ISO saat",
      duration: "ISO s\xFCre",
      ipv4: "IPv4 adresi",
      ipv6: "IPv6 adresi",
      mac: "MAC adresi",
      cidrv4: "IPv4 aral\u0131\u011F\u0131",
      cidrv6: "IPv6 aral\u0131\u011F\u0131",
      base64: "base64 ile \u015Fifrelenmi\u015F metin",
      base64url: "base64url ile \u015Fifrelenmi\u015F metin",
      json_string: "JSON dizesi",
      e164: "E.164 say\u0131s\u0131",
      credit_card: "kredi kart\u0131 numaras\u0131",
      currency_code: "para birimi kodu",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u015Eablon dizesi"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${issue3.expected}, al\u0131nan ${received}`;
          }
          return `Ge\xE7ersiz de\u011Fer: beklenen ${expected2}, al\u0131nan ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Ge\xE7ersiz de\u011Fer: beklenen ${stringifyPrimitive(issue3.values[0])}`;
          return `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\xC7ok b\xFCy\xFCk: beklenen ${issue3.origin ?? "de\u011Fer"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\xF6\u011Fe"}`;
          return `\xC7ok b\xFCy\xFCk: beklenen ${issue3.origin ?? "de\u011Fer"} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\xC7ok k\xFC\xE7\xFCk: beklenen ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          return `\xC7ok k\xFC\xE7\xFCk: beklenen ${issue3.origin} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Ge\xE7ersiz metin: "${_issue.prefix}" ile ba\u015Flamal\u0131`;
          if (_issue.format === "ends_with")
            return `Ge\xE7ersiz metin: "${_issue.suffix}" ile bitmeli`;
          if (_issue.format === "includes")
            return `Ge\xE7ersiz metin: "${_issue.includes}" i\xE7ermeli`;
          if (_issue.format === "regex")
            return `Ge\xE7ersiz metin: ${_issue.pattern} desenine uymal\u0131`;
          return `Ge\xE7ersiz ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Ge\xE7ersiz say\u0131: ${issue3.divisor} ile tam b\xF6l\xFCnebilmeli`;
        case "unrecognized_keys":
          return `Tan\u0131nmayan anahtar${issue3.keys.length > 1 ? "lar" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} i\xE7inde ge\xE7ersiz anahtar`;
        case "invalid_union":
          return "Ge\xE7ersiz de\u011Fer";
        case "invalid_element":
          return `${issue3.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
        default:
          return `Ge\xE7ersiz de\u011Fer`;
      }
    };
  };
  function tr_default() {
    return {
      localeError: error54()
    };
  }

  // ../../../node_modules/zod/v4/locales/uk.js
  var error55 = () => {
    const Sizable = {
      string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
      file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
      array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
      set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
      map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
      email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
      url: "URL",
      emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
      date: "\u0434\u0430\u0442\u0430 ISO",
      time: "\u0447\u0430\u0441 ISO",
      duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
      ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
      ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
      mac: "\u0430\u0434\u0440\u0435\u0441\u0430 MAC",
      cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
      cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
      base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
      base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
      json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
      e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
      credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0457 \u043A\u0430\u0440\u0442\u043A\u0438",
      currency_code: "\u043A\u043E\u0434 \u0432\u0430\u043B\u044E\u0442\u0438",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0447\u0438\u0441\u043B\u043E",
      array: "\u043C\u0430\u0441\u0438\u0432"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${issue3.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${received}`;
          }
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${expected2}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${stringifyPrimitive(issue3.values[0])}`;
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${issue3.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${sizing.verb} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}`;
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${issue3.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${issue3.origin} ${sizing.verb} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${issue3.origin} \u0431\u0443\u0434\u0435 ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${_issue.pattern}`;
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${issue3.divisor}`;
        case "unrecognized_keys":
          return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${issue3.keys.length > 1 ? "\u0456" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${issue3.origin}`;
        case "invalid_union":
          return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
        case "invalid_element":
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${issue3.origin}`;
        default:
          return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456`;
      }
    };
  };
  function uk_default() {
    return {
      localeError: error55()
    };
  }

  // ../../../node_modules/zod/v4/locales/ua.js
  function ua_default() {
    return uk_default();
  }

  // ../../../node_modules/zod/v4/locales/ur.js
  var error56 = () => {
    const Sizable = {
      string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
      file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
      array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
      set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
      map: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0627\u0646 \u067E\u0679",
      email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
      url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
      emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
      uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
      uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
      uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
      nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
      guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
      cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
      cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
      ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
      xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
      ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
      datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
      date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
      time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
      duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
      ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
      ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
      mac: "\u0627\u06CC\u0645 \u0627\u06D2 \u0633\u06CC \u0627\u06CC\u0688\u0631\u06CC\u0633",
      cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
      cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
      base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
      base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
      json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
      e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
      credit_card: "\u06A9\u0631\u06CC\u0688\u0679 \u06A9\u0627\u0631\u0688 \u0646\u0645\u0628\u0631",
      currency_code: "\u06A9\u0631\u0646\u0633\u06CC \u06A9\u0648\u0688",
      iban: "IBAN",
      jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
      template_literal: "\u0627\u0646 \u067E\u0679"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u0646\u0645\u0628\u0631",
      array: "\u0622\u0631\u06D2",
      null: "\u0646\u0644"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${issue3.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${received} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
          }
          return `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${expected2} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${received} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${stringifyPrimitive(issue3.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
          return `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${joinValues(issue3.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u0628\u06C1\u062A \u0628\u0691\u0627: ${issue3.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2`;
          return `\u0628\u06C1\u062A \u0628\u0691\u0627: ${issue3.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${adj}${issue3.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${issue3.origin} \u06A9\u06D2 ${adj}${issue3.minimum.toString()} ${sizing.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2`;
          }
          return `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${issue3.origin} \u06A9\u0627 ${adj}${issue3.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${_issue.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
          }
          if (_issue.format === "ends_with")
            return `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${_issue.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
          if (_issue.format === "includes")
            return `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${_issue.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
          if (_issue.format === "regex")
            return `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${_issue.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
          return `\u063A\u0644\u0637 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${issue3.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
        case "unrecognized_keys":
          return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${issue3.keys.length > 1 ? "\u0632" : ""}: ${joinValues(issue3.keys, "\u060C ")}`;
        case "invalid_key":
          return `${issue3.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
        case "invalid_union":
          return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
        case "invalid_element":
          return `${issue3.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
        default:
          return `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679`;
      }
    };
  };
  function ur_default() {
    return {
      localeError: error56()
    };
  }

  // ../../../node_modules/zod/v4/locales/uz.js
  var error57 = () => {
    const Sizable = {
      string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
      file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
      array: { unit: "element", verb: "bo\u2018lishi kerak" },
      set: { unit: "element", verb: "bo\u2018lishi kerak" },
      map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "kirish",
      email: "elektron pochta manzili",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO sana va vaqti",
      date: "ISO sana",
      time: "ISO vaqt",
      duration: "ISO davomiylik",
      ipv4: "IPv4 manzil",
      ipv6: "IPv6 manzil",
      mac: "MAC manzil",
      cidrv4: "IPv4 diapazon",
      cidrv6: "IPv6 diapazon",
      base64: "base64 kodlangan satr",
      base64url: "base64url kodlangan satr",
      json_string: "JSON satr",
      e164: "E.164 raqam",
      credit_card: "kredit karta raqami",
      currency_code: "valyuta kodi",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "kirish"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "raqam",
      array: "massiv"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${issue3.expected}, qabul qilingan ${received}`;
          }
          return `Noto\u2018g\u2018ri kirish: kutilgan ${expected2}, qabul qilingan ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `Noto\u2018g\u2018ri kirish: kutilgan ${stringifyPrimitive(issue3.values[0])}`;
          return `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Juda katta: kutilgan ${issue3.origin ?? "qiymat"} ${adj}${issue3.maximum.toString()} ${sizing.unit} ${sizing.verb}`;
          return `Juda katta: kutilgan ${issue3.origin ?? "qiymat"} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Juda kichik: kutilgan ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit} ${sizing.verb}`;
          }
          return `Juda kichik: kutilgan ${issue3.origin} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Noto\u2018g\u2018ri satr: "${_issue.prefix}" bilan boshlanishi kerak`;
          if (_issue.format === "ends_with")
            return `Noto\u2018g\u2018ri satr: "${_issue.suffix}" bilan tugashi kerak`;
          if (_issue.format === "includes")
            return `Noto\u2018g\u2018ri satr: "${_issue.includes}" ni o\u2018z ichiga olishi kerak`;
          if (_issue.format === "regex")
            return `Noto\u2018g\u2018ri satr: ${_issue.pattern} shabloniga mos kelishi kerak`;
          return `Noto\u2018g\u2018ri ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `Noto\u2018g\u2018ri raqam: ${issue3.divisor} ning karralisi bo\u2018lishi kerak`;
        case "unrecognized_keys":
          return `Noma\u2019lum kalit${issue3.keys.length > 1 ? "lar" : ""}: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} dagi kalit noto\u2018g\u2018ri`;
        case "invalid_union":
          return "Noto\u2018g\u2018ri kirish";
        case "invalid_element":
          return `${issue3.origin} da noto\u2018g\u2018ri qiymat`;
        default:
          return `Noto\u2018g\u2018ri kirish`;
      }
    };
  };
  function uz_default() {
    return {
      localeError: error57()
    };
  }

  // ../../../node_modules/zod/v4/locales/vi.js
  var error58 = () => {
    const Sizable = {
      string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
      file: { unit: "byte", verb: "c\xF3" },
      array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
      set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
      map: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u0111\u1EA7u v\xE0o",
      email: "\u0111\u1ECBa ch\u1EC9 email",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ng\xE0y gi\u1EDD ISO",
      date: "ng\xE0y ISO",
      time: "gi\u1EDD ISO",
      duration: "kho\u1EA3ng th\u1EDDi gian ISO",
      ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
      ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
      mac: "\u0111\u1ECBa ch\u1EC9 MAC",
      cidrv4: "d\u1EA3i IPv4",
      cidrv6: "d\u1EA3i IPv6",
      base64: "chu\u1ED7i m\xE3 h\xF3a base64",
      base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
      json_string: "chu\u1ED7i JSON",
      e164: "s\u1ED1 E.164",
      credit_card: "s\u1ED1 th\u1EBB t\xEDn d\u1EE5ng",
      currency_code: "m\xE3 ti\u1EC1n t\u1EC7",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u0111\u1EA7u v\xE0o"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "s\u1ED1",
      array: "m\u1EA3ng"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${issue3.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${received}`;
          }
          return `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${expected2}, nh\u1EADn \u0111\u01B0\u1EE3c ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${stringifyPrimitive(issue3.values[0])}`;
          return `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${issue3.origin ?? "gi\xE1 tr\u1ECB"} ${sizing.verb} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "ph\u1EA7n t\u1EED"}`;
          return `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${issue3.origin ?? "gi\xE1 tr\u1ECB"} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${issue3.origin} ${sizing.verb} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${issue3.origin} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${_issue.pattern}`;
          return `${FormatDictionary[_issue.format] ?? issue3.format} kh\xF4ng h\u1EE3p l\u1EC7`;
        }
        case "not_multiple_of":
          return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${issue3.divisor}`;
        case "unrecognized_keys":
          return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${issue3.origin}`;
        case "invalid_union":
          return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
        case "invalid_element":
          return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${issue3.origin}`;
        default:
          return `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7`;
      }
    };
  };
  function vi_default() {
    return {
      localeError: error58()
    };
  }

  // ../../../node_modules/zod/v4/locales/zh-CN.js
  var error59 = () => {
    const Sizable = {
      string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
      file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
      array: { unit: "\u9879", verb: "\u5305\u542B" },
      set: { unit: "\u9879", verb: "\u5305\u542B" },
      map: { unit: "\u9879", verb: "\u5305\u542B" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u8F93\u5165",
      email: "\u7535\u5B50\u90AE\u4EF6",
      url: "URL",
      emoji: "\u8868\u60C5\u7B26\u53F7",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO\u65E5\u671F\u65F6\u95F4",
      date: "ISO\u65E5\u671F",
      time: "ISO\u65F6\u95F4",
      duration: "ISO\u65F6\u957F",
      ipv4: "IPv4\u5730\u5740",
      ipv6: "IPv6\u5730\u5740",
      mac: "MAC\u5730\u5740",
      cidrv4: "IPv4\u7F51\u6BB5",
      cidrv6: "IPv6\u7F51\u6BB5",
      base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
      base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
      json_string: "JSON\u5B57\u7B26\u4E32",
      e164: "E.164\u53F7\u7801",
      credit_card: "\u4FE1\u7528\u5361\u53F7",
      currency_code: "\u8D27\u5E01\u4EE3\u7801",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u8F93\u5165"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "\u6570\u5B57",
      array: "\u6570\u7EC4",
      null: "\u7A7A\u503C(null)"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${issue3.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${received}`;
          }
          return `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${expected2}\uFF0C\u5B9E\u9645\u63A5\u6536 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${stringifyPrimitive(issue3.values[0])}`;
          return `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${issue3.origin ?? "\u503C"} ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u4E2A\u5143\u7D20"}`;
          return `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${issue3.origin ?? "\u503C"} ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${issue3.origin} ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${issue3.origin} ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${_issue.prefix}" \u5F00\u5934`;
          if (_issue.format === "ends_with")
            return `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${_issue.suffix}" \u7ED3\u5C3E`;
          if (_issue.format === "includes")
            return `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${_issue.pattern}`;
          return `\u65E0\u6548${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${issue3.divisor} \u7684\u500D\u6570`;
        case "unrecognized_keys":
          return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `${issue3.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
        case "invalid_union":
          return "\u65E0\u6548\u8F93\u5165";
        case "invalid_element":
          return `${issue3.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
        default:
          return `\u65E0\u6548\u8F93\u5165`;
      }
    };
  };
  function zh_CN_default() {
    return {
      localeError: error59()
    };
  }

  // ../../../node_modules/zod/v4/locales/zh-TW.js
  var error60 = () => {
    const Sizable = {
      string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
      file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
      array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
      set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
      map: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u8F38\u5165",
      email: "\u90F5\u4EF6\u5730\u5740",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "ISO \u65E5\u671F\u6642\u9593",
      date: "ISO \u65E5\u671F",
      time: "ISO \u6642\u9593",
      duration: "ISO \u671F\u9593",
      ipv4: "IPv4 \u4F4D\u5740",
      ipv6: "IPv6 \u4F4D\u5740",
      mac: "MAC \u4F4D\u5740",
      cidrv4: "IPv4 \u7BC4\u570D",
      cidrv6: "IPv6 \u7BC4\u570D",
      base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
      base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
      json_string: "JSON \u5B57\u4E32",
      e164: "E.164 \u6578\u503C",
      credit_card: "\u4FE1\u7528\u5361\u865F",
      currency_code: "\u8CA8\u5E63\u4EE3\u78BC",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u8F38\u5165"
    };
    const TypeDictionary = {
      nan: "NaN"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${issue3.expected}\uFF0C\u4F46\u6536\u5230 ${received}`;
          }
          return `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${expected2}\uFF0C\u4F46\u6536\u5230 ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${stringifyPrimitive(issue3.values[0])}`;
          return `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${issue3.origin ?? "\u503C"} \u61C9\u70BA ${adj}${issue3.maximum.toString()} ${sizing.unit ?? "\u500B\u5143\u7D20"}`;
          return `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${issue3.origin ?? "\u503C"} \u61C9\u70BA ${adj}${issue3.maximum.toString()}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing) {
            return `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${issue3.origin} \u61C9\u70BA ${adj}${issue3.minimum.toString()} ${sizing.unit}`;
          }
          return `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${issue3.origin} \u61C9\u70BA ${adj}${issue3.minimum.toString()}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with") {
            return `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${_issue.prefix}" \u958B\u982D`;
          }
          if (_issue.format === "ends_with")
            return `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${_issue.suffix}" \u7D50\u5C3E`;
          if (_issue.format === "includes")
            return `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${_issue.pattern}`;
          return `\u7121\u6548\u7684 ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${issue3.divisor} \u7684\u500D\u6578`;
        case "unrecognized_keys":
          return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${issue3.keys.length > 1 ? "\u5011" : ""}\uFF1A${joinValues(issue3.keys, "\u3001")}`;
        case "invalid_key":
          return `${issue3.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
        case "invalid_union":
          return "\u7121\u6548\u7684\u8F38\u5165\u503C";
        case "invalid_element":
          return `${issue3.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
        default:
          return `\u7121\u6548\u7684\u8F38\u5165\u503C`;
      }
    };
  };
  function zh_TW_default() {
    return {
      localeError: error60()
    };
  }

  // ../../../node_modules/zod/v4/locales/yo.js
  var error61 = () => {
    const Sizable = {
      string: { unit: "\xE0mi", verb: "n\xED" },
      file: { unit: "bytes", verb: "n\xED" },
      array: { unit: "nkan", verb: "n\xED" },
      set: { unit: "nkan", verb: "n\xED" },
      map: { unit: "nkan", verb: "n\xED" }
    };
    function getSizing(origin) {
      return Sizable[origin] ?? null;
    }
    const FormatDictionary = {
      regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
      email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
      url: "URL",
      emoji: "emoji",
      uuid: "UUID",
      uuidv4: "UUIDv4",
      uuidv6: "UUIDv6",
      nanoid: "nanoid",
      guid: "GUID",
      cuid: "cuid",
      cuid2: "cuid2",
      ulid: "ULID",
      xid: "XID",
      ksuid: "KSUID",
      datetime: "\xE0k\xF3k\xF2 ISO",
      date: "\u1ECDj\u1ECD\u0301 ISO",
      time: "\xE0k\xF3k\xF2 ISO",
      duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
      ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
      ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
      mac: "\xE0d\xEDr\u1EB9\u0301s\xEC MAC",
      cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
      cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
      base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
      base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
      json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
      e164: "n\u1ECD\u0301mb\xE0 E.164",
      credit_card: "n\u1ECDmba kaadi gbese",
      currency_code: "koodu ow\xF3",
      iban: "IBAN",
      jwt: "JWT",
      template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
    };
    const TypeDictionary = {
      nan: "NaN",
      number: "n\u1ECD\u0301mb\xE0",
      array: "akop\u1ECD"
    };
    return (issue3) => {
      switch (issue3.code) {
        case "invalid_type": {
          const expected2 = TypeDictionary[issue3.expected] ?? issue3.expected;
          const receivedType = parsedType(issue3.input);
          const received = TypeDictionary[receivedType] ?? receivedType;
          if (/^[A-Z]/.test(issue3.expected)) {
            return `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${issue3.expected}, \xE0m\u1ECD\u0300 a r\xED ${received}`;
          }
          return `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${expected2}, \xE0m\u1ECD\u0300 a r\xED ${received}`;
        }
        case "invalid_value":
          if (issue3.values.length === 1)
            return `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${stringifyPrimitive(issue3.values[0])}`;
          return `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${joinValues(issue3.values, "|")}`;
        case "too_big": {
          const adj = issue3.inclusive ? "<=" : "<";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${issue3.origin ?? "iye"} ${sizing.verb} ${adj}${issue3.maximum} ${sizing.unit}`;
          return `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${adj}${issue3.maximum}`;
        }
        case "too_small": {
          const adj = issue3.inclusive ? ">=" : ">";
          const sizing = getSizing(issue3.origin);
          if (sizing)
            return `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${issue3.origin} ${sizing.verb} ${adj}${issue3.minimum} ${sizing.unit}`;
          return `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${adj}${issue3.minimum}`;
        }
        case "invalid_format": {
          const _issue = issue3;
          if (_issue.format === "starts_with")
            return `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${_issue.prefix}"`;
          if (_issue.format === "ends_with")
            return `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${_issue.suffix}"`;
          if (_issue.format === "includes")
            return `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${_issue.includes}"`;
          if (_issue.format === "regex")
            return `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${_issue.pattern}`;
          return `A\u1E63\xEC\u1E63e: ${FormatDictionary[_issue.format] ?? issue3.format}`;
        }
        case "not_multiple_of":
          return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${issue3.divisor}`;
        case "unrecognized_keys":
          return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${joinValues(issue3.keys, ", ")}`;
        case "invalid_key":
          return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${issue3.origin}`;
        case "invalid_union":
          return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
        case "invalid_element":
          return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${issue3.origin}`;
        default:
          return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      }
    };
  };
  function yo_default() {
    return {
      localeError: error61()
    };
  }

  // ../../../node_modules/zod/v4/core/registries.js
  var _a2;
  var $output = /* @__PURE__ */ Symbol("ZodOutput");
  var $input = /* @__PURE__ */ Symbol("ZodInput");
  var $ZodRegistry = class {
    constructor() {
      this._map = /* @__PURE__ */ new WeakMap();
      this._idmap = /* @__PURE__ */ new Map();
    }
    add(schema, ..._meta) {
      const meta3 = _meta[0];
      this._map.set(schema, meta3);
      if (meta3 && typeof meta3 === "object" && "id" in meta3) {
        this._idmap.set(meta3.id, schema);
      }
      return this;
    }
    clear() {
      this._map = /* @__PURE__ */ new WeakMap();
      this._idmap = /* @__PURE__ */ new Map();
      return this;
    }
    remove(schema) {
      const meta3 = this._map.get(schema);
      if (meta3 && typeof meta3 === "object" && "id" in meta3) {
        this._idmap.delete(meta3.id);
      }
      this._map.delete(schema);
      return this;
    }
    get(schema) {
      const p = schema._zod.parent;
      if (p) {
        const pm = { ...this.get(p) ?? {} };
        delete pm.id;
        const f = { ...pm, ...this._map.get(schema) };
        return Object.keys(f).length ? f : void 0;
      }
      return this._map.get(schema);
    }
    has(schema) {
      return this._map.has(schema);
    }
  };
  function registry() {
    return new $ZodRegistry();
  }
  (_a2 = globalThis).__zod_globalRegistry ?? (_a2.__zod_globalRegistry = registry());
  var globalRegistry = globalThis.__zod_globalRegistry;

  // ../../../node_modules/zod/v4/core/compile.js
  var INVALID = /* @__PURE__ */ Symbol.for("zod.compile.invalid");
  var FALLBACK_FLAG = /* @__PURE__ */ Symbol.for("zod.compile.fallback");
  var ZodCompileAsyncError = class extends Error {
    constructor(message2 = "z.compile does not support async refinements, transforms, or checks") {
      super(message2);
      this.name = "ZodCompileAsyncError";
    }
  };
  var ZodCompileUnsupportedError = class extends Error {
    constructor(feature, islandable = true) {
      super(`z.compile does not support ${feature}; this schema must use the runtime parser`);
      this.name = "ZodCompileUnsupportedError";
      this.islandable = islandable;
    }
  };
  function compileValidator(schema, parser) {
    try {
      return compileFn(schema, { assertOnly: true });
    } catch {
      return parser;
    }
  }
  function compile(schema, options) {
    try {
      const parser = compileFn(schema);
      const clone2 = withParser(schema, parser);
      clone2._zod.bag.validator = compileValidator(schema, parser);
      return clone2;
    } catch (err) {
      if (options?.strict)
        throw err;
      return schema;
    }
  }
  function withParser(schema, parser) {
    if (isRecursiveSchema(schema)) {
      throw new ZodCompileUnsupportedError("a schema whose subtree contains a reference cycle");
    }
    const clone2 = clone(schema);
    const liveRun = schema._zod.run;
    const originalRun = liveRun.__originalRun ?? liveRun;
    const wrapped = (payload, ctx) => {
      if (ctx?.async || ctx?.direction === "backward" || ctx?.skipChecks || ctx?.[FALLBACK_FLAG]) {
        return originalRun(payload, ctx);
      }
      if (ctx && isBackEdge(ctx, payload.value)) {
        return originalRun(payload, ctx);
      }
      const out = parser(payload.value);
      if (out !== INVALID) {
        payload.value = out;
        return payload;
      }
      if (ctx)
        ctx[FALLBACK_FLAG] = true;
      return originalRun(payload, ctx);
    };
    wrapped.__originalRun = originalRun;
    clone2._zod.bag.fallbackRun = originalRun;
    clone2._zod.bag.validator = parser;
    clone2._zod.run = wrapped;
    if (!liveRun.__originalRun)
      installCompiledUserMethods(clone2, schema, parser);
    return clone2;
  }
  function installCompiledUserMethods(target3, source, parser) {
    const targetAny = target3;
    const sourceAny = source;
    if (typeof sourceAny.safeParse === "function") {
      const originalSafeParse = sourceAny.safeParse;
      targetAny.safeParse = (data, params) => {
        const out = parser(data);
        if (out !== INVALID) {
          return { success: true, data: out };
        }
        return originalSafeParse(data, params);
      };
    }
    if (typeof sourceAny.parse === "function") {
      const originalParse = sourceAny.parse;
      targetAny.parse = (data, params) => {
        const out = parser(data);
        if (out !== INVALID) {
          return out;
        }
        return originalParse(data, params);
      };
    }
  }
  function compileFn(schema, options) {
    let recursive2 = true;
    try {
      recursive2 = isRecursiveSchema(schema);
    } catch {
    }
    if (recursive2) {
      throw new ZodCompileUnsupportedError("a schema whose subtree contains a reference cycle");
    }
    const ctx = {
      constants: /* @__PURE__ */ new Map(),
      constantCounter: 0,
      varCounter: 0,
      definite: true
    };
    const doc = new Doc(["input"]);
    const outputAccessor = generateCheck(doc, ctx, schema, "input", !options?.assertOnly);
    doc.write(outputAccessor === null ? `return true;` : `return ${outputAccessor};`);
    const constantNames = ["INVALID", ...ctx.constants.keys()];
    const constantValues = [INVALID, ...ctx.constants.values()];
    const code = doc.content.join("\n");
    const fullCode = options?.debug ? constantNames.length > 0 ? `// Constants: ${constantNames.join(", ")}
${code}` : code : "";
    const F = Function;
    const factoryCode = `return (input) => {
${code}
}`;
    let fn;
    try {
      const factory = new F(...constantNames, factoryCode);
      fn = factory(...constantValues);
    } catch (err) {
      throw new ZodCompileUnsupportedError(`this schema (generated code failed to evaluate: ${err.message})`);
    }
    if (options?.debug) {
      fn.code = fullCode;
    }
    fn.definite = ctx.definite;
    return fn;
  }
  function addConstant(ctx, value) {
    for (const [name2, v] of ctx.constants) {
      if (v === value)
        return name2;
    }
    const name = `c${ctx.constantCounter++}`;
    ctx.constants.set(name, value);
    return name;
  }
  function addUserConstant(ctx, fn) {
    ctx.definite = false;
    return addConstant(ctx, fn);
  }
  function newVar(ctx) {
    return `v${ctx.varCounter++}`;
  }
  function runtimeRun(schema, value) {
    const result = schema._zod.run({ value, issues: [] }, {});
    if (result && typeof result.then === "function")
      return INVALID;
    const r = result;
    return r.issues.length === 0 ? r.value : INVALID;
  }
  function compileChild(doc, ctx, schema, accessor, needsValue = true) {
    const contentLen = doc.content.length;
    const constantCount = ctx.constants.size;
    const constantCounter = ctx.constantCounter;
    const varCounter = ctx.varCounter;
    try {
      return generateCheck(doc, ctx, schema, accessor, needsValue);
    } catch (err) {
      if (!(err instanceof ZodCompileUnsupportedError) || !err.islandable)
        throw err;
      doc.content.length = contentLen;
      if (ctx.constants.size > constantCount) {
        const trailing = Array.from(ctx.constants.keys()).slice(constantCount);
        for (const k of trailing)
          ctx.constants.delete(k);
      }
      ctx.constantCounter = constantCounter;
      ctx.varCounter = varCounter;
      return emitRuntimeIsland(doc, ctx, schema, accessor);
    }
  }
  function emitRuntimeIsland(doc, ctx, schema, accessor) {
    ctx.definite = false;
    const schemaConst = addConstant(ctx, schema);
    const runConst = addConstant(ctx, runtimeRun);
    const outVar = newVar(ctx);
    doc.write(`const ${outVar} = ${runConst}(${schemaConst}, ${accessor});`);
    doc.write(`if (${outVar} === INVALID) return INVALID;`);
    return outVar;
  }
  var WHEN_DEFAULTED_CHECKS = /* @__PURE__ */ new Set([
    "max_size",
    "min_size",
    "size_equals",
    "max_length",
    "min_length",
    "length_equals"
  ]);
  function generateChecks(doc, ctx, schema, accessor) {
    const schemaChecks = schema._zod.def.checks;
    if (!schemaChecks || schemaChecks.length === 0)
      return accessor;
    let currentAccessor = accessor;
    for (const check2 of schemaChecks) {
      const def = check2._zod.def;
      if (def.when && !WHEN_DEFAULTED_CHECKS.has(def.check)) {
        throw new ZodCompileUnsupportedError(`check with a custom "when" condition`);
      }
      switch (def.check) {
        case "greater_than":
          generateGreaterThanCheck(doc, ctx, def, currentAccessor);
          break;
        case "less_than":
          generateLessThanCheck(doc, ctx, def, currentAccessor);
          break;
        case "multiple_of":
          generateMultipleOfCheck(doc, ctx, def, currentAccessor);
          break;
        case "number_format":
          generateNumberFormatCheck(doc, def, currentAccessor);
          break;
        case "min_length": {
          const min = numericOperand(def.minimum, "min_length");
          const len = codePointLengthVar(doc, ctx, currentAccessor, `${currentAccessor}.length >= ${min} && ${currentAccessor}.length < ${def.minimum * 2}`);
          doc.write(`if (${len} < ${min}) return INVALID;`);
          break;
        }
        case "max_length": {
          const max = numericOperand(def.maximum, "max_length");
          const len = codePointLengthVar(doc, ctx, currentAccessor, `${currentAccessor}.length > ${max}`);
          doc.write(`if (${len} > ${max}) return INVALID;`);
          break;
        }
        case "length_equals": {
          const exact = numericOperand(def.length, "length_equals");
          const len = codePointLengthVar(doc, ctx, currentAccessor, `${currentAccessor}.length >= ${exact} && ${currentAccessor}.length <= ${def.length * 2}`);
          doc.write(`if (${len} !== ${exact}) return INVALID;`);
          break;
        }
        case "min_size":
          doc.write(`if (${currentAccessor}.size < ${numericOperand(def.minimum, "min_size")}) return INVALID;`);
          break;
        case "max_size":
          doc.write(`if (${currentAccessor}.size > ${numericOperand(def.maximum, "max_size")}) return INVALID;`);
          break;
        case "size_equals":
          doc.write(`if (${currentAccessor}.size !== ${numericOperand(def.size, "size_equals")}) return INVALID;`);
          break;
        case "string_format":
          currentAccessor = generateStringFormatCheck(doc, ctx, def, currentAccessor);
          break;
        case "custom":
          currentAccessor = generateCustomRefineCheck(doc, ctx, check2, currentAccessor);
          break;
        case "bigint_format":
          generateBigIntFormatCheck(doc, def, currentAccessor);
          break;
        case "mime_type":
          generateMimeTypeCheck(doc, ctx, def, currentAccessor);
          break;
        case "property":
          generatePropertyCheck(doc, ctx, def, currentAccessor);
          break;
        case "properties":
          generatePropertiesChecks(doc, ctx, def, currentAccessor);
          break;
        case "overwrite": {
          const newAccessor = newVar(ctx);
          generateOverwriteCheck(doc, ctx, check2, currentAccessor, newAccessor);
          currentAccessor = newAccessor;
          break;
        }
        default: {
          void def;
          throw new ZodCompileUnsupportedError(`check type ${def.check}`);
        }
      }
    }
    return currentAccessor;
  }
  function codePointLengthVar(doc, ctx, accessor, inDoubt) {
    const cpLen = addConstant(ctx, codePointLength);
    const v = newVar(ctx);
    doc.write(`const ${v} = typeof ${accessor} === "string" && ${inDoubt} ? ${cpLen}(${accessor}) : ${accessor}.length;`);
    return v;
  }
  function numericOperand(value, label) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      throw new ZodCompileUnsupportedError(`${label} bound of type ${typeof value}`);
    }
    return `${value}`;
  }
  function comparisonOperand(ctx, value) {
    if (typeof value === "bigint")
      return `${value}n`;
    if (typeof value === "number") {
      if (Number.isNaN(value))
        throw new ZodCompileUnsupportedError("comparison check with NaN bound");
      return `${value}`;
    }
    if (value instanceof Date) {
      if (Number.isNaN(value.getTime())) {
        throw new ZodCompileUnsupportedError("comparison check with Invalid Date bound");
      }
      return addConstant(ctx, value);
    }
    throw new ZodCompileUnsupportedError(`comparison check bound of type ${typeof value}`);
  }
  function generateGreaterThanCheck(doc, ctx, def, accessor) {
    const op = def.inclusive ? "<" : "<=";
    doc.write(`if (${accessor} ${op} ${comparisonOperand(ctx, def.value)}) return INVALID;`);
  }
  function generateLessThanCheck(doc, ctx, def, accessor) {
    const op = def.inclusive ? ">" : ">=";
    doc.write(`if (${accessor} ${op} ${comparisonOperand(ctx, def.value)}) return INVALID;`);
  }
  function generateMultipleOfCheck(doc, ctx, def, accessor) {
    if (typeof def.value === "bigint") {
      if (def.value === BigInt(0))
        throw new ZodCompileUnsupportedError("multiple_of check with a zero divisor");
      doc.write(`if (${accessor} % ${def.value}n !== 0n) return INVALID;`);
    } else {
      const remainder = addConstant(ctx, floatSafeRemainder);
      doc.write(`if (${remainder}(${accessor}, ${numericOperand(def.value, "multiple_of")}) !== 0) return INVALID;`);
    }
  }
  function generateNumberFormatCheck(doc, def, accessor) {
    const format = def.format;
    switch (format) {
      case "safeint":
        doc.write(`if (!Number.isSafeInteger(${accessor})) return INVALID;`);
        break;
      case "int32":
        doc.write(`if (!Number.isInteger(${accessor}) || ${accessor} < -2147483648 || ${accessor} > 2147483647) return INVALID;`);
        break;
      case "uint32":
        doc.write(`if (!Number.isInteger(${accessor}) || ${accessor} < 0 || ${accessor} > 4294967295) return INVALID;`);
        break;
      case "float32":
        doc.write(`if (!Number.isFinite(${accessor}) || ${accessor} < -3.4028234663852886e38 || ${accessor} > 3.4028234663852886e38) return INVALID;`);
        break;
      case "float64":
        doc.write(`if (!Number.isFinite(${accessor})) return INVALID;`);
        break;
      default: {
        void format;
        throw new ZodCompileUnsupportedError(`number format ${format}`);
      }
    }
  }
  function generateBigIntFormatCheck(doc, def, accessor) {
    const format = def.format;
    if (!format)
      return;
    switch (format) {
      case "int64":
        doc.write(`if (${accessor} < -9223372036854775808n || ${accessor} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        doc.write(`if (${accessor} < 0n || ${accessor} > 18446744073709551615n) return INVALID;`);
        break;
      default: {
        void format;
        throw new ZodCompileUnsupportedError(`bigint format ${format}`);
      }
    }
  }
  function generateMimeTypeCheck(doc, ctx, def, accessor) {
    const mimeTypes = def.mime;
    if (mimeTypes && mimeTypes.length > 0) {
      const mimeSet = addConstant(ctx, new Set(mimeTypes));
      doc.write(`if (!${mimeSet}.has(${accessor}.type)) return INVALID;`);
    }
  }
  function generatePropertiesChecks(doc, ctx, def, accessor) {
    if (def.when) {
      throw new ZodCompileUnsupportedError(`check with a custom "when" condition`);
    }
    doc.write(`if (${accessor} == null) return INVALID;`);
    const shape = def.shape;
    for (const key6 of Reflect.ownKeys(shape)) {
      const keyExpr = typeof key6 === "symbol" ? addConstant(ctx, key6) : esc(key6);
      const inputVar = newVar(ctx);
      doc.write(`const ${inputVar} = ${accessor}[${keyExpr}];`);
      compileChild(doc, ctx, shape[key6], inputVar, false);
    }
  }
  function generatePropertyCheck(doc, ctx, def, accessor) {
    const propAccessor = `${accessor}[${JSON.stringify(def.property)}]`;
    generateCheck(doc, ctx, def.schema, propAccessor);
  }
  function generateOverwriteCheck(doc, ctx, check2, currentAccessor, newAccessor) {
    const tx = check2._zod.def.tx;
    if (!tx) {
      throw new ZodCompileUnsupportedError("overwrite check without a transform function");
    }
    if (isAsyncFunction(tx)) {
      throw new ZodCompileAsyncError("z.compile: async overwrite transforms are not supported");
    }
    const txConst = addConstant(ctx, tx);
    doc.write(`const ${newAccessor} = ${txConst}(${currentAccessor});`);
  }
  function throwAsync() {
    throw new $ZodAsyncError();
  }
  function pushIssue(issue3) {
    this.issues.push(issue3);
  }
  function generateCustomRefineCheck(doc, ctx, check2, accessor) {
    const def = check2._zod.def;
    if (def.fn) {
      if (isAsyncFunction(def.fn)) {
        throw new ZodCompileAsyncError("z.compile: async .refine() predicates are not supported");
      }
      const fnConst = addUserConstant(ctx, def.fn);
      const throwAsyncConst = addConstant(ctx, throwAsync);
      const resVar = newVar(ctx);
      doc.write(`const ${resVar} = ${fnConst}(${accessor});`);
      doc.write(`if (${resVar} instanceof Promise) ${throwAsyncConst}();`);
      doc.write(`if (!${resVar}) return INVALID;`);
      return accessor;
    }
    if (check2._zod.check) {
      if (isAsyncFunction(check2._zod.check)) {
        throw new ZodCompileAsyncError("z.compile: async .superRefine() / check functions are not supported");
      }
      const checkFn = check2._zod.check;
      const helperFn = (value) => {
        const fakePayload = { value, issues: [], addIssue: pushIssue };
        const result = checkFn(fakePayload);
        if (result instanceof Promise)
          throwAsync();
        return fakePayload.issues.length === 0 ? fakePayload.value : INVALID;
      };
      const helperConst = addUserConstant(ctx, helperFn);
      const outVar = newVar(ctx);
      doc.write(`const ${outVar} = ${helperConst}(${accessor});`);
      doc.write(`if (${outVar} === INVALID) return INVALID;`);
      return outVar;
    }
    throw new ZodCompileUnsupportedError("custom check without a predicate or check function");
  }
  var PATTERN_IS_COMPLETE = /* @__PURE__ */ new Set([
    "cidrv4",
    "cuid",
    "cuid2",
    "date",
    "datetime",
    "duration",
    "e164",
    "email",
    "emoji",
    "ends_with",
    "guid",
    "includes",
    "ipv4",
    "ksuid",
    "lowercase",
    "mac",
    "nanoid",
    "regex",
    "starts_with",
    "time",
    "ulid",
    "uppercase",
    "uuid",
    "xid"
  ]);
  function generateStringFormatCheck(doc, ctx, def, accessor, needsValue = true) {
    const fmt = def.format;
    if (fmt === "base64") {
      const validator = addConstant(ctx, isValidBase64);
      doc.write(`if (!${validator}(${accessor})) return INVALID;`);
      return accessor;
    }
    if (fmt === "base64url") {
      const validator = addConstant(ctx, isValidBase64URL);
      doc.write(`if (!${validator}(${accessor})) return INVALID;`);
      return accessor;
    }
    if (fmt === "jwt") {
      const validator = addConstant(ctx, isValidJWT);
      const alg = addConstant(ctx, def.alg ?? null);
      doc.write(`if (!${validator}(${accessor}, ${alg})) return INVALID;`);
      return accessor;
    }
    if (fmt === "ipv6") {
      const validator = addConstant(ctx, isValidIPv6);
      doc.write(`if (!${validator}(${accessor})) return INVALID;`);
      return accessor;
    }
    if (fmt === "cidrv6") {
      const validator = addConstant(ctx, isValidCIDRv6);
      doc.write(`if (!${validator}(${accessor})) return INVALID;`);
      return accessor;
    }
    if (fmt === "credit_card") {
      const validator = addConstant(ctx, isValidCreditCard);
      doc.write(`if (!${validator}(${accessor})) return INVALID;`);
      return accessor;
    }
    if (fmt === "iban") {
      const validator = addConstant(ctx, isValidIBAN);
      doc.write(`if (!${validator}(${accessor})) return INVALID;`);
      return accessor;
    }
    const formatDef = def;
    if (fmt === "url" || fmt === "httpurl" || formatDef.normalize || formatDef.hostname !== void 0 || formatDef.protocol !== void 0) {
      const parseConst = addConstant(ctx, validateURL);
      const defConst = addConstant(ctx, def);
      const trimVar = newVar(ctx);
      const urlVar = newVar(ctx);
      doc.write(`const ${trimVar} = ${accessor}.trim();`);
      doc.write(`const ${urlVar} = ${parseConst}(${trimVar}, ${defConst});`);
      doc.write(`if (typeof ${urlVar} === "number") return INVALID;`);
      if (formatDef.hostname !== void 0) {
        const hostnameConst = addConstant(ctx, urlHostnameOk);
        doc.write(`if (!${hostnameConst}(${urlVar}, ${defConst}.hostname)) return INVALID;`);
      }
      if (formatDef.protocol !== void 0) {
        const protocolConst = addConstant(ctx, urlProtocolOk);
        doc.write(`if (!${protocolConst}(${urlVar}, ${defConst}.protocol)) return INVALID;`);
      }
      if (!needsValue)
        return null;
      const outputVar = newVar(ctx);
      const outputExpr = formatDef.normalize ? `${urlVar}.href` : `${addConstant(ctx, stripTabAndNewline)}(${trimVar})`;
      doc.write(`const ${outputVar} = ${outputExpr};`);
      return outputVar;
    }
    const customFn = def.fn;
    if (customFn) {
      if (isAsyncFunction(customFn))
        throw new ZodCompileUnsupportedError(`async string format ${fmt}`);
      const fnConst = addConstant(ctx, customFn);
      doc.write(`if (!${fnConst}(${accessor})) return INVALID;`);
      return accessor;
    }
    if (PATTERN_IS_COMPLETE.has(fmt) && def.pattern) {
      const patternConst = addConstant(ctx, def.pattern);
      doc.write(`${patternConst}.lastIndex = 0;`);
      doc.write(`if (!${patternConst}.test(${accessor})) return INVALID;`);
      return accessor;
    }
    const format = def.format;
    switch (format) {
      case "regex":
        throw new ZodCompileUnsupportedError("regex format without a pattern");
      case "lowercase":
        doc.write(`if (${accessor} !== ${accessor}.toLowerCase()) return INVALID;`);
        break;
      case "uppercase":
        doc.write(`if (${accessor} !== ${accessor}.toUpperCase()) return INVALID;`);
        break;
      case "includes":
        doc.write(`if (!${accessor}.includes(${esc(def.includes)})) return INVALID;`);
        break;
      case "starts_with": {
        const prefix = def.prefix;
        doc.write(`if (${accessor}.slice(0, ${prefix.length}) !== ${esc(prefix)}) return INVALID;`);
        break;
      }
      case "ends_with": {
        const suffix = def.suffix;
        doc.write(`if (${accessor}.slice(-${suffix.length}) !== ${esc(suffix)}) return INVALID;`);
        break;
      }
      default: {
        void format;
        throw new ZodCompileUnsupportedError(`string format ${format}`);
      }
    }
    return accessor;
  }
  function generateCheck(doc, ctx, schema, accessor, needsValue = true) {
    const def = schema._zod.def;
    const type = def.type;
    if (def.coerce) {
      throw new ZodCompileUnsupportedError(`coercion (z.coerce.${type}())`);
    }
    const buildsValue = needsValue || !!def.checks?.length;
    let typeAccessor;
    switch (type) {
      case "string":
        typeAccessor = generateStringCheck(doc, ctx, schema, accessor, buildsValue);
        break;
      case "number":
        typeAccessor = generateNumberCheck(doc, schema, accessor);
        break;
      case "boolean":
        typeAccessor = generateBooleanCheck(doc, accessor);
        break;
      case "bigint":
        typeAccessor = generateBigIntCheck(doc, schema, accessor);
        break;
      case "symbol":
        typeAccessor = generateSymbolCheck(doc, accessor);
        break;
      case "undefined":
        typeAccessor = generateUndefinedCheck(doc, accessor);
        break;
      case "null":
        typeAccessor = generateNullCheck(doc, accessor);
        break;
      case "any":
      case "unknown":
        typeAccessor = accessor;
        break;
      case "never":
        doc.write("return INVALID;");
        typeAccessor = accessor;
        break;
      case "void":
        typeAccessor = generateVoidCheck(doc, accessor);
        break;
      case "nan":
        typeAccessor = generateNaNCheck(doc, accessor);
        break;
      case "date":
        typeAccessor = generateDateCheck(doc, accessor);
        break;
      case "object":
        typeAccessor = generateObjectCheck(doc, ctx, schema, accessor, buildsValue);
        break;
      case "optional":
        typeAccessor = generateOptionalCheck(doc, ctx, schema, accessor, buildsValue);
        break;
      case "nullable":
        typeAccessor = generateNullableCheck(doc, ctx, schema, accessor, buildsValue);
        break;
      case "array":
        typeAccessor = generateArrayCheck(doc, ctx, schema, accessor, buildsValue);
        break;
      case "literal":
        typeAccessor = generateLiteralCheck(doc, ctx, schema, accessor);
        break;
      case "enum":
        typeAccessor = generateEnumCheck(doc, ctx, schema, accessor);
        break;
      case "readonly": {
        const innerOut = generateWrapperCheck(doc, ctx, schema, accessor);
        const frozenVar = newVar(ctx);
        doc.write(`const ${frozenVar} = Object.freeze(${innerOut});`);
        typeAccessor = frozenVar;
        break;
      }
      case "success":
        generateWrapperCheck(doc, ctx, schema, accessor);
        typeAccessor = "true";
        break;
      case "default":
      case "prefault":
        typeAccessor = generateDefaultCheck(doc, ctx, schema, accessor);
        break;
      case "nonoptional":
        typeAccessor = generateNonOptionalCheck(doc, ctx, schema, accessor);
        break;
      case "tuple":
        typeAccessor = generateTupleCheck(doc, ctx, schema, accessor);
        break;
      case "union":
        typeAccessor = generateUnionCheck(doc, ctx, schema, accessor);
        break;
      case "intersection":
        typeAccessor = generateIntersectionCheck(doc, ctx, schema, accessor);
        break;
      case "record":
        typeAccessor = generateRecordCheck(doc, ctx, schema, accessor);
        break;
      case "map":
        typeAccessor = generateMapCheck(doc, ctx, schema, accessor);
        break;
      case "set":
        typeAccessor = generateSetCheck(doc, ctx, schema, accessor);
        break;
      case "file":
        typeAccessor = generateFileCheck(doc, accessor);
        break;
      case "template_literal":
        typeAccessor = generateTemplateLiteralCheck(doc, ctx, schema, accessor);
        break;
      case "lazy":
        typeAccessor = generateLazyCheck(doc, ctx, schema, accessor);
        break;
      case "pipe":
        typeAccessor = generatePipeCheck(doc, ctx, schema, accessor);
        break;
      case "custom":
        typeAccessor = generateCustomCheck(doc, ctx, schema, accessor);
        break;
      case "transform":
        typeAccessor = generateTransformCheck(doc, ctx, schema, accessor);
        break;
      case "catch":
        typeAccessor = generateCatchCheck(doc, ctx, schema, accessor);
        break;
      default: {
        void type;
        throw new ZodCompileUnsupportedError(`schema type ${type}`);
      }
    }
    if (typeAccessor === null)
      return null;
    return generateChecks(doc, ctx, schema, typeAccessor);
  }
  function generateStringCheck(doc, ctx, schema, accessor, needsValue = true) {
    doc.write(`if (typeof ${accessor} !== "string") return INVALID;`);
    const def = schema._zod.def;
    if (def.format === void 0)
      return accessor;
    return generateStringFormatCheck(doc, ctx, def, accessor, needsValue);
  }
  function generateNumberCheck(doc, schema, accessor) {
    doc.write(`if (typeof ${accessor} !== "number" || !Number.isFinite(${accessor})) return INVALID;`);
    const def = schema._zod.def;
    if (def.check === "number_format" && def.format) {
      generateNumberFormatCheck(doc, { format: def.format }, accessor);
    }
    return accessor;
  }
  function generateBooleanCheck(doc, accessor) {
    doc.write(`if (typeof ${accessor} !== "boolean") return INVALID;`);
    return accessor;
  }
  function generateBigIntCheck(doc, schema, accessor) {
    doc.write(`if (typeof ${accessor} !== "bigint") return INVALID;`);
    const def = schema._zod.def;
    if (def.format) {
      switch (def.format) {
        case "int64":
          doc.write(`if (${accessor} < -9223372036854775808n || ${accessor} > 9223372036854775807n) return INVALID;`);
          break;
        case "uint64":
          doc.write(`if (${accessor} < 0n || ${accessor} > 18446744073709551615n) return INVALID;`);
          break;
      }
    }
    return accessor;
  }
  function generateSymbolCheck(doc, accessor) {
    doc.write(`if (typeof ${accessor} !== "symbol") return INVALID;`);
    return accessor;
  }
  function generateUndefinedCheck(doc, accessor) {
    doc.write(`if (${accessor} !== undefined) return INVALID;`);
    return accessor;
  }
  function generateNullCheck(doc, accessor) {
    doc.write(`if (${accessor} !== null) return INVALID;`);
    return accessor;
  }
  function generateVoidCheck(doc, accessor) {
    doc.write(`if (${accessor} !== undefined) return INVALID;`);
    return accessor;
  }
  function generateNaNCheck(doc, accessor) {
    doc.write(`if (typeof ${accessor} !== "number" || !Number.isNaN(${accessor})) return INVALID;`);
    return accessor;
  }
  function generateDateCheck(doc, accessor) {
    doc.write(`if (!(${accessor} instanceof Date) || Number.isNaN(${accessor}.getTime())) return INVALID;`);
    return accessor;
  }
  function generateObjectCheck(doc, ctx, schema, accessor, buildsValue = true) {
    const def = schema._zod.def;
    doc.write(`if (typeof ${accessor} !== "object" || ${accessor} === null || Array.isArray(${accessor})) return INVALID;`);
    const shape = def.shape;
    const keys = Object.keys(shape);
    const symbolKeys = Object.getOwnPropertySymbols(shape);
    const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
    const keyExpr = (k) => typeof k === "symbol" ? addConstant(ctx, k) : esc(k);
    const propKey = (k) => typeof k === "symbol" ? `[${keyExpr(k)}]` : esc(k);
    const propShape = shape;
    if (keys.includes("__proto__")) {
      throw new ZodCompileUnsupportedError('object shape key "__proto__"');
    }
    const propOutputs = /* @__PURE__ */ new Map();
    for (const key6 of allKeys) {
      const propSchema = propShape[key6];
      const kx = keyExpr(key6);
      const inputVar = newVar(ctx);
      doc.write(`const ${inputVar} = ${accessor}[${kx}];`);
      if (propSchema._zod.optin !== void 0) {
        const outputVar2 = newVar(ctx);
        doc.write(`let ${outputVar2} = (() => {`);
        doc.indented((d) => {
          const outputAccessor = compileChild(d, ctx, propSchema, inputVar);
          d.write(`return ${outputAccessor};`);
        });
        doc.write(`})();`);
        if (propSchema._zod.optout === "optional") {
          doc.write(`if (${outputVar2} === INVALID) {`);
          doc.indented((d) => {
            d.write(`if (${kx} in ${accessor}) return INVALID;`);
            d.write(`${outputVar2} = undefined;`);
          });
          doc.write(`}`);
        } else {
          doc.write(`if (${outputVar2} === INVALID) return INVALID;`);
        }
        propOutputs.set(key6, outputVar2);
      } else {
        if (requiresPresenceCheck(propSchema)) {
          doc.write(`if (!(${kx} in ${accessor})) return INVALID;`);
        }
        const outputAccessor = compileChild(doc, ctx, propSchema, inputVar, buildsValue);
        if (outputAccessor !== null)
          propOutputs.set(key6, outputAccessor);
      }
    }
    const catchall = def.catchall;
    let unknownKeysMode = "none";
    if (catchall) {
      const catchallType = catchall._zod.def.type;
      if (catchallType === "never") {
        const condition = keys.map((k) => `k !== ${esc(k)}`).join(" && ") || "true";
        doc.write(`for (const k in ${accessor}) {`);
        doc.indented((d) => {
          d.write(`if (${condition}) return INVALID;`);
        });
        doc.write(`}`);
      } else if ((catchallType === "unknown" || catchallType === "any") && !catchall._zod.def.checks?.length) {
        unknownKeysMode = "passthrough";
      } else {
        unknownKeysMode = "schema";
      }
    }
    const outputVar = newVar(ctx);
    const hasConditionalKeys = allKeys.some((k) => mayOmitUndefined(propShape[k]) || dropsWhenAbsent(propShape[k]));
    if (!buildsValue) {
      if (unknownKeysMode === "schema") {
        const knownSet = keys.length > 0 ? addConstant(ctx, new Set(keys)) : null;
        doc.write(`for (const k in ${accessor}) {`);
        doc.indented((d) => {
          d.write(`if (k === "__proto__") continue;`);
          if (knownSet)
            d.write(`if (${knownSet}.has(k)) continue;`);
          const valVar = newVar(ctx);
          d.write(`const ${valVar} = ${accessor}[k];`);
          compileChild(d, ctx, catchall, valVar, false);
        });
        doc.write(`}`);
      }
      return null;
    }
    if (!hasConditionalKeys) {
      const propLiterals = allKeys.map((k) => `${propKey(k)}: ${propOutputs.get(k)}`).join(", ");
      doc.write(`const ${outputVar} = { ${propLiterals} };`);
    } else {
      doc.write(`const ${outputVar} = {};`);
      for (const k of allKeys) {
        const kx = keyExpr(k);
        const out = propOutputs.get(k);
        if (dropsWhenAbsent(propShape[k])) {
          doc.write(`if (${kx} in ${accessor}) ${outputVar}[${kx}] = ${out};`);
        } else if (mayOmitUndefined(propShape[k])) {
          doc.write(`if (${out} !== undefined || ${kx} in ${accessor}) ${outputVar}[${kx}] = ${out};`);
        } else {
          doc.write(`${outputVar}[${kx}] = ${out};`);
        }
      }
    }
    if (unknownKeysMode !== "none") {
      const knownSet = keys.length > 0 ? addConstant(ctx, new Set(keys)) : null;
      doc.write(`for (const k in ${accessor}) {`);
      doc.indented((d) => {
        d.write(`if (k === "__proto__") continue;`);
        if (knownSet)
          d.write(`if (${knownSet}.has(k)) continue;`);
        if (unknownKeysMode === "passthrough") {
          d.write(`${outputVar}[k] = ${accessor}[k];`);
        } else {
          const valVar = newVar(ctx);
          d.write(`const ${valVar} = ${accessor}[k];`);
          const catchallOut = compileChild(d, ctx, catchall, valVar);
          d.write(`${outputVar}[k] = ${catchallOut};`);
        }
      });
      doc.write(`}`);
    }
    return outputVar;
  }
  function generateOptionalCheck(doc, ctx, schema, accessor, buildsValue = true) {
    const def = schema._zod.def;
    if (isExactOptional(schema)) {
      return generateCheck(doc, ctx, def.innerType, accessor, buildsValue);
    }
    if (def.innerType._zod.optin === "defaulted") {
      const outputVar2 = newVar(ctx);
      const branchVar = newVar(ctx);
      doc.write(`let ${outputVar2};`);
      doc.write(`if (${accessor} === undefined) {`);
      doc.indented((d) => {
        d.write(`const ${branchVar} = (() => {`);
        d.indented((d2) => {
          const innerOutput = generateCheck(d2, ctx, def.innerType, accessor);
          d2.write(`return ${innerOutput};`);
        });
        d.write(`})();`);
        d.write(`if (${branchVar} !== INVALID) ${outputVar2} = ${branchVar};`);
      });
      doc.write(`} else {`);
      doc.indented((d) => {
        const innerOutput = generateCheck(d, ctx, def.innerType, accessor);
        d.write(`${outputVar2} = ${innerOutput};`);
      });
      doc.write(`}`);
      return outputVar2;
    }
    const outputVar = buildsValue ? newVar(ctx) : null;
    if (outputVar)
      doc.write(`let ${outputVar};`);
    doc.write(`if (${accessor} !== undefined) {`);
    doc.indented((d) => {
      const innerOutput = generateCheck(d, ctx, def.innerType, accessor, buildsValue);
      if (outputVar && innerOutput !== null)
        d.write(`${outputVar} = ${innerOutput};`);
    });
    doc.write(`}`);
    return outputVar;
  }
  function isExactOptional(schema) {
    return schema._zod.traits?.has("$ZodExactOptional") === true;
  }
  function requiresPresenceCheck(schema) {
    return schema._zod.optin === void 0 && fastPathAcceptsAbsence(schema);
  }
  function fastPathAcceptsAbsence(schema) {
    if (schema._zod.def.coerce)
      return true;
    const def = schema._zod.def;
    switch (def.type) {
      case "any":
      case "unknown":
      case "undefined":
      case "void":
      case "default":
      case "prefault":
      case "transform":
      case "custom":
      case "lazy":
        return true;
      case "string":
      case "number":
      case "boolean":
      case "bigint":
      case "symbol":
      case "null":
      case "never":
      case "nan":
      case "date":
      case "object":
      case "array":
      case "tuple":
      case "record":
      case "map":
      case "set":
      case "file":
      case "template_literal":
        return false;
      case "nonoptional":
        return def.innerType ? fastPathAcceptsAbsence(def.innerType) : false;
      case "literal":
        return !!def.values?.includes(void 0);
      case "enum":
        return !!schema._zod.values?.has(void 0);
      case "optional":
      case "nullable":
      case "readonly":
      case "success":
        return def.innerType ? fastPathAcceptsAbsence(def.innerType) : true;
      case "catch":
        return true;
      case "union":
        return def.options ? def.options.some(fastPathAcceptsAbsence) : true;
      case "intersection":
        if (!def.left || !def.right)
          return true;
        return fastPathAcceptsAbsence(def.left) && fastPathAcceptsAbsence(def.right);
      case "pipe":
        return def.in ? fastPathAcceptsAbsence(def.in) : true;
      default:
        return true;
    }
  }
  function dropsWhenAbsent(schema) {
    return schema._zod.optin === "optional" && schema._zod.optout === "optional";
  }
  function mayOmitUndefined(schema) {
    return (schema._zod.optin !== "defaulted" || schema._zod.optout === "optional") && mayOutputUndefined(schema);
  }
  function mayOutputUndefined(schema) {
    const def = schema._zod.def;
    switch (def.type) {
      case "string":
      case "number":
      case "boolean":
      case "bigint":
      case "symbol":
      case "null":
      case "nan":
      case "date":
      case "object":
      case "array":
      case "tuple":
      case "record":
      case "map":
      case "set":
      case "file":
      case "template_literal":
      case "never":
      case "success":
        return false;
      case "literal":
        return !!def.values?.includes(void 0);
      case "enum":
        return !!schema._zod.values?.has(void 0);
      case "optional":
        return true;
      case "nullable":
      case "readonly":
      case "nonoptional":
        return def.innerType ? mayOutputUndefined(def.innerType) : true;
      case "union":
        return def.options ? def.options.some(mayOutputUndefined) : true;
      case "intersection":
        return !def.left || !def.right || mayOutputUndefined(def.left) || mayOutputUndefined(def.right);
      case "pipe":
        return def.out ? mayOutputUndefined(def.out) : true;
      default:
        return true;
    }
  }
  function generateNullableCheck(doc, ctx, schema, accessor, buildsValue = true) {
    const def = schema._zod.def;
    const outputVar = buildsValue ? newVar(ctx) : null;
    if (outputVar)
      doc.write(`let ${outputVar} = null;`);
    doc.write(`if (${accessor} !== null) {`);
    doc.indented((d) => {
      const innerOutput = generateCheck(d, ctx, def.innerType, accessor, buildsValue);
      if (outputVar && innerOutput !== null)
        d.write(`${outputVar} = ${innerOutput};`);
    });
    doc.write(`}`);
    return outputVar;
  }
  function generateSizeGate(doc, schema, size) {
    for (const [max, check2] of sizeCaps(schema._zod.def.checks)) {
      doc.write(`if (${size} > ${numericOperand(max, check2._zod.def.check)}) return INVALID;`);
    }
  }
  function generateArrayCheck(doc, ctx, schema, accessor, buildsValue = true) {
    const def = schema._zod.def;
    doc.write(`if (!Array.isArray(${accessor})) return INVALID;`);
    generateSizeGate(doc, schema, `${accessor}.length`);
    const outputVar = buildsValue ? newVar(ctx) : null;
    const iVar = newVar(ctx);
    const elemVar = newVar(ctx);
    if (outputVar)
      doc.write(`const ${outputVar} = new Array(${accessor}.length);`);
    doc.write(`for (let ${iVar} = 0; ${iVar} < ${accessor}.length; ${iVar}++) {`);
    doc.indented((d) => {
      d.write(`const ${elemVar} = ${accessor}[${iVar}];`);
      const elemOutput = compileChild(d, ctx, def.element, elemVar, buildsValue);
      if (outputVar && elemOutput !== null)
        d.write(`${outputVar}[${iVar}] = ${elemOutput};`);
    });
    doc.write(`}`);
    return outputVar;
  }
  function generateLiteralCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const values = def.values;
    if (values.length !== 1) {
      const literalSet = addConstant(ctx, new Set(values));
      doc.write(`if (!${literalSet}.has(${accessor})) return INVALID;`);
      return accessor;
    }
    const value = values[0];
    if (typeof value === "number" && Number.isNaN(value)) {
      const literalSet = addConstant(ctx, new Set(values));
      doc.write(`if (!${literalSet}.has(${accessor})) return INVALID;`);
      return accessor;
    }
    if (typeof value === "string") {
      doc.write(`if (${accessor} !== ${esc(value)}) return INVALID;`);
    } else if (typeof value === "number" || typeof value === "boolean") {
      doc.write(`if (${accessor} !== ${value}) return INVALID;`);
    } else if (value === null) {
      doc.write(`if (${accessor} !== null) return INVALID;`);
    } else if (value === void 0) {
      doc.write(`if (${accessor} !== undefined) return INVALID;`);
    } else if (typeof value === "bigint") {
      doc.write(`if (${accessor} !== ${value}n) return INVALID;`);
    } else {
      throw new ZodCompileUnsupportedError(`literal type ${typeof value}`);
    }
    return accessor;
  }
  function generateEnumCheck(doc, ctx, schema, accessor) {
    const values = schema._zod.values;
    if (!values) {
      throw new ZodCompileUnsupportedError("enum schema without enumerated values");
    }
    const enumSet = addConstant(ctx, values);
    doc.write(`if (!${enumSet}.has(${accessor})) return INVALID;`);
    return accessor;
  }
  function generateWrapperCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    return generateCheck(doc, ctx, def.innerType, accessor);
  }
  function generateDefaultCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const descriptor = Object.getOwnPropertyDescriptor(schema._zod.def, "defaultValue");
    const defaultGetter = descriptor ? () => schema._zod.def.defaultValue : void 0;
    if (schema._zod.def.type === "prefault") {
      if (!defaultGetter) {
        return generateCheck(doc, ctx, def.innerType, accessor);
      }
      const defaultFn = addConstant(ctx, defaultGetter);
      const inputVar = newVar(ctx);
      doc.write(`let ${inputVar} = ${accessor};`);
      doc.write(`if (${accessor} === undefined) ${inputVar} = ${defaultFn}();`);
      return generateCheck(doc, ctx, def.innerType, inputVar);
    }
    const outputVar = newVar(ctx);
    if (defaultGetter) {
      const defaultFn = addConstant(ctx, defaultGetter);
      const cloneFn = addConstant(ctx, shallowClone);
      doc.write(`let ${outputVar};`);
      doc.write(`if (${accessor} === undefined) {`);
      doc.indented((d) => {
        d.write(`${outputVar} = ${cloneFn}(${defaultFn}());`);
      });
      doc.write(`} else {`);
      doc.indented((d) => {
        const innerOutput = generateCheck(d, ctx, def.innerType, accessor);
        d.write(`${outputVar} = ${innerOutput} === undefined ? ${cloneFn}(${defaultFn}()) : ${innerOutput};`);
      });
      doc.write(`}`);
    } else {
      doc.write(`let ${outputVar};`);
      doc.write(`if (${accessor} !== undefined) {`);
      doc.indented((d) => {
        const innerOutput = generateCheck(d, ctx, def.innerType, accessor);
        d.write(`${outputVar} = ${innerOutput};`);
      });
      doc.write(`}`);
    }
    return outputVar;
  }
  function generateNonOptionalCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const innerOutput = generateCheck(doc, ctx, def.innerType, accessor);
    const outputVar = newVar(ctx);
    doc.write(`const ${outputVar} = ${innerOutput};`);
    doc.write(`if (${outputVar} === undefined) return INVALID;`);
    return outputVar;
  }
  function generateTupleCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const items = def.items;
    const rest = def.rest;
    doc.write(`if (!Array.isArray(${accessor})) return INVALID;`);
    const optinStart = getTupleOptStart2(items, "optin");
    const optoutStart = getTupleOptStart2(items, "optout");
    if (rest) {
      doc.write(`if (${accessor}.length < ${optinStart}) return INVALID;`);
    } else {
      doc.write(`if (${accessor}.length < ${optinStart} || ${accessor}.length > ${items.length}) return INVALID;`);
    }
    const outputVar = newVar(ctx);
    doc.write(`const ${outputVar} = [];`);
    for (let i = 0; i < items.length; i++) {
      const itemSchema = items[i];
      if (i >= optoutStart) {
        doc.write(`if (${outputVar}.length === ${i}) {`);
        doc.indented((d) => {
          d.write(`if (${i} < ${accessor}.length) {`);
          d.indented((d2) => {
            const elemVar = newVar(ctx);
            d2.write(`const ${elemVar} = ${accessor}[${i}];`);
            const elemOutput = compileChild(d2, ctx, itemSchema, elemVar);
            d2.write(`${outputVar}[${i}] = ${elemOutput};`);
          });
          d.write(`} else {`);
          d.indented((d2) => {
            if (dropsWhenAbsent(itemSchema)) {
              d2.write(`${outputVar}.length = ${i};`);
              return;
            }
            const elemVar = newVar(ctx);
            const branchVar = newVar(ctx);
            d2.write(`const ${elemVar} = undefined;`);
            d2.write(`const ${branchVar} = (() => {`);
            d2.indented((d3) => {
              const elemOutput = compileChild(d3, ctx, itemSchema, elemVar);
              d3.write(`return ${elemOutput};`);
            });
            d2.write(`})();`);
            d2.write(`if (${branchVar} === INVALID || ${branchVar} === undefined) ${outputVar}.length = ${i};`);
            d2.write(`else ${outputVar}[${i}] = ${branchVar};`);
          });
          d.write(`}`);
        });
        doc.write(`}`);
      } else {
        const elemVar = newVar(ctx);
        doc.write(`const ${elemVar} = ${accessor}[${i}];`);
        const elemOutput = compileChild(doc, ctx, itemSchema, elemVar);
        doc.write(`${outputVar}[${i}] = ${elemOutput};`);
      }
    }
    if (rest) {
      const iVar = newVar(ctx);
      const elemVar = newVar(ctx);
      doc.write(`for (let ${iVar} = ${items.length}; ${iVar} < ${accessor}.length; ${iVar}++) {`);
      doc.indented((d) => {
        d.write(`const ${elemVar} = ${accessor}[${iVar}];`);
        const elemOutput = compileChild(d, ctx, rest, elemVar);
        d.write(`${outputVar}[${iVar}] = ${elemOutput};`);
      });
      doc.write(`}`);
    }
    return outputVar;
  }
  function getTupleOptStart2(items, key6) {
    for (let i = items.length - 1; i >= 0; i--) {
      const omittable = key6 === "optin" ? items[i]._zod.optin !== void 0 : items[i]._zod.optout === "optional";
      if (!omittable)
        return i + 1;
    }
    return 0;
  }
  function generateUnionCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const options = def.options;
    if (def.discriminator) {
      return generateDiscriminatedUnionCheck(doc, ctx, def, accessor);
    }
    if (def.inclusive === false) {
      throw new ZodCompileUnsupportedError("exclusive unions (z.xor)");
    }
    if (options.length === 0) {
      doc.write("return INVALID;");
      return accessor;
    }
    if (options.length === 1) {
      return generateCheck(doc, ctx, options[0], accessor);
    }
    const allLiterals = options.every((opt) => opt._zod.def.type === "literal" && !opt._zod.def.checks?.length);
    if (allLiterals) {
      const values = new Set(options.flatMap((opt) => opt._zod.def.values));
      const valuesConst = addConstant(ctx, values);
      doc.write(`if (!${valuesConst}.has(${accessor})) return INVALID;`);
      return accessor;
    }
    const outputVar = newVar(ctx);
    doc.write(`let ${outputVar};`);
    for (let i = 0; i < options.length; i++) {
      const opt = options[i];
      if (i === 0) {
        doc.write(`${outputVar} = (() => {`);
      } else {
        doc.write(`if (${outputVar} === INVALID) ${outputVar} = (() => {`);
      }
      doc.indented((d) => {
        const branchOutput = generateCheck(d, ctx, opt, accessor);
        d.write(`return ${branchOutput};`);
      });
      doc.write(`})();`);
    }
    doc.write(`if (${outputVar} === INVALID) return INVALID;`);
    return outputVar;
  }
  function generateDiscriminatedUnionCheck(doc, ctx, def, accessor) {
    if (def.unionFallback) {
      throw new ZodCompileUnsupportedError("discriminated union with unionFallback");
    }
    if (def.options.length === 0) {
      doc.write("return INVALID;");
      return accessor;
    }
    const discVar = newVar(ctx);
    const outputVar = newVar(ctx);
    doc.write(`const ${discVar} = ${accessor}?.[${esc(def.discriminator)}];`);
    doc.write(`let ${outputVar};`);
    let firstBranch = true;
    const claimed = /* @__PURE__ */ new Set();
    for (const option2 of def.options) {
      const values = option2._zod.propValues?.[def.discriminator];
      if (!values || values.size === 0) {
        throw new ZodCompileUnsupportedError("discriminated union option without static discriminator values");
      }
      for (const value of values) {
        if (claimed.has(value)) {
          throw new ZodCompileUnsupportedError(`duplicate discriminator value ${String(value)}`);
        }
        claimed.add(value);
      }
      const conditions = Array.from(values, (value) => literalEquality(ctx, discVar, value));
      const prefix = firstBranch ? "if" : "else if";
      doc.write(`${prefix} (${conditions.join(" || ")}) {`);
      doc.indented((d) => {
        const branchOutput = generateCheck(d, ctx, option2, accessor);
        d.write(`${outputVar} = ${branchOutput};`);
      });
      doc.write(`}`);
      firstBranch = false;
    }
    doc.write(`else { return INVALID; }`);
    return outputVar;
  }
  function literalEquality(ctx, accessor, value) {
    if (typeof value === "string")
      return `${accessor} === ${esc(value)}`;
    if (typeof value === "number") {
      if (Number.isNaN(value))
        return `Number.isNaN(${accessor})`;
      return `${accessor} === ${value}`;
    }
    if (typeof value === "boolean")
      return `${accessor} === ${value}`;
    if (value === null)
      return `${accessor} === null`;
    if (value === void 0)
      return `${accessor} === undefined`;
    if (typeof value === "bigint")
      return `${accessor} === ${value}n`;
    if (typeof value === "symbol") {
      const symbolConst = addConstant(ctx, value);
      return `${accessor} === ${symbolConst}`;
    }
    throw new ZodCompileUnsupportedError(`literal discriminator value ${String(value)}`);
  }
  function generateIntersectionCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    ctx.definite = false;
    const leftOutput = compileChild(doc, ctx, def.left, accessor);
    const rightOutput = compileChild(doc, ctx, def.right, accessor);
    const mergeConst = addConstant(ctx, mergeValues);
    const mergedVar = newVar(ctx);
    doc.write(`const ${mergedVar} = ${mergeConst}(${leftOutput}, ${rightOutput});`);
    doc.write(`if (!${mergedVar}.valid) return INVALID;`);
    return `${mergedVar}.data`;
  }
  function generateRecordCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const isPlainObjectConst = addConstant(ctx, isPlainObject);
    doc.write(`if (!${isPlainObjectConst}(${accessor})) return INVALID;`);
    const outputVar = newVar(ctx);
    const kVar = newVar(ctx);
    const valVar = newVar(ctx);
    doc.write(`const ${outputVar} = {};`);
    const recordDef = def;
    const keyValues = recordDef.partial ? void 0 : def.keyType._zod.values;
    if (keyValues) {
      const inputKeys = [];
      for (const key6 of keyValues) {
        if (!(typeof key6 === "string" || typeof key6 === "number" || typeof key6 === "symbol")) {
          throw new ZodCompileUnsupportedError(`record key value ${String(key6)}`);
        }
        const inputKey = typeof key6 === "number" ? key6.toString() : key6;
        if (inputKey === "__proto__") {
          throw new ZodCompileUnsupportedError('record key "__proto__"');
        }
        inputKeys.push(inputKey);
        const keyConst = addConstant(ctx, key6);
        const outKey = generateCheck(doc, ctx, def.keyType, keyConst);
        const valueVar = newVar(ctx);
        doc.write(`const ${valueVar} = ${accessor}[${literalPropertyKey(ctx, inputKey)}];`);
        const valOutput = compileChild(doc, ctx, def.valueType, valueVar);
        doc.write(`${outputVar}[${outKey}] = ${valOutput};`);
      }
      const knownKeysConst = addConstant(ctx, new Set(inputKeys));
      doc.write(`for (const ${kVar} in ${accessor}) {`);
      doc.indented((d) => {
        d.write(`if (${knownKeysConst}.has(${kVar})) continue;`);
        if (recordDef.mode === "loose") {
          d.write(`if (${kVar} !== "__proto__") ${outputVar}[${kVar}] = ${accessor}[${kVar}];`);
        } else {
          d.write(`return INVALID;`);
        }
      });
      doc.write(`}`);
      return outputVar;
    }
    const keyDef = def.keyType._zod.def;
    const keyIsBareString = keyDef.type === "string" && keyDef.format === void 0 && !keyDef.coerce && (keyDef.checks?.length ?? 0) === 0;
    if (!keyIsBareString) {
      const isLoose = def.mode === "loose";
      const keyFn = compileFn(def.keyType);
      if (keyFn.definite === false)
        ctx.definite = false;
      const keyFast = addConstant(ctx, keyFn);
      const numericConst = addConstant(ctx, number);
      const outKeyVar = newVar(ctx);
      emitOwnKeys(doc, ctx, accessor, kVar, (d) => {
        d.write(`let ${outKeyVar} = ${keyFast}(${kVar});`);
        d.write(`if (${outKeyVar} === INVALID && typeof ${kVar} === "string" && ${numericConst}.test(${kVar})) ${outKeyVar} = ${keyFast}(Number(${kVar}));`);
        if (isLoose) {
          d.write(`if (${outKeyVar} === INVALID) { ${outputVar}[${kVar}] = ${accessor}[${kVar}]; continue; }`);
        } else {
          d.write(`if (${outKeyVar} === INVALID) return INVALID;`);
        }
        d.write(`if (${outKeyVar} === "__proto__") continue;`);
        const valueVar = newVar(ctx);
        d.write(`const ${valueVar} = ${accessor}[${kVar}];`);
        const valOutput = compileChild(d, ctx, def.valueType, valueVar);
        d.write(`${outputVar}[${outKeyVar}] = ${valOutput};`);
      });
      return outputVar;
    }
    emitOwnKeys(doc, ctx, accessor, kVar, (d) => {
      d.write(`const ${valVar} = ${accessor}[${kVar}];`);
      const valOutput = compileChild(d, ctx, def.valueType, valVar);
      d.write(`${outputVar}[${kVar}] = ${valOutput};`);
    }, `return INVALID;`);
    return outputVar;
  }
  function emitOwnKeys(doc, ctx, accessor, kVar, body, onSymbol) {
    const propIsEnumerableConst = addConstant(ctx, Object.prototype.propertyIsEnumerable);
    const symsVar = newVar(ctx);
    const keysVar = newVar(ctx);
    const iVar = newVar(ctx);
    doc.write(`const ${symsVar} = Object.getOwnPropertySymbols(${accessor});`);
    doc.write(`const ${keysVar} = Object.getOwnPropertyNames(${accessor});`);
    doc.write(`for (let ${iVar} = 0; ${iVar} < ${keysVar}.length; ${iVar}++) {`);
    doc.indented((d) => {
      d.write(`const ${kVar} = ${keysVar}[${iVar}];`);
      d.write(`if (${kVar} === "__proto__" || !${propIsEnumerableConst}.call(${accessor}, ${kVar})) continue;`);
      body(d);
    });
    doc.write(`}`);
    doc.write(`for (let ${iVar} = 0; ${iVar} < ${symsVar}.length; ${iVar}++) {`);
    doc.indented((d) => {
      d.write(`const ${kVar} = ${symsVar}[${iVar}];`);
      d.write(`if (!${propIsEnumerableConst}.call(${accessor}, ${kVar})) continue;`);
      if (onSymbol)
        d.write(onSymbol);
      else
        body(d);
    });
    doc.write(`}`);
  }
  function literalPropertyKey(ctx, key6) {
    if (typeof key6 === "string")
      return esc(key6);
    return addConstant(ctx, key6);
  }
  function generateMapCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    doc.write(`if (!(${accessor} instanceof Map)) return INVALID;`);
    generateSizeGate(doc, schema, `${accessor}.size`);
    const outputVar = newVar(ctx);
    const kVar = newVar(ctx);
    const valVar = newVar(ctx);
    doc.write(`const ${outputVar} = new Map();`);
    doc.write(`for (const [${kVar}, ${valVar}] of ${accessor}) {`);
    doc.indented((d) => {
      const keyOutput = generateCheck(d, ctx, def.keyType, kVar);
      const valOutput = generateCheck(d, ctx, def.valueType, valVar);
      d.write(`${outputVar}.set(${keyOutput}, ${valOutput});`);
    });
    doc.write(`}`);
    return outputVar;
  }
  function generateSetCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    doc.write(`if (!(${accessor} instanceof Set)) return INVALID;`);
    generateSizeGate(doc, schema, `${accessor}.size`);
    const outputVar = newVar(ctx);
    const valVar = newVar(ctx);
    doc.write(`const ${outputVar} = new Set();`);
    doc.write(`for (const ${valVar} of ${accessor}) {`);
    doc.indented((d) => {
      const valOutput = generateCheck(d, ctx, def.valueType, valVar);
      d.write(`${outputVar}.add(${valOutput});`);
    });
    doc.write(`}`);
    return outputVar;
  }
  function generateFileCheck(doc, accessor) {
    doc.write(`if (!(${accessor} instanceof File)) return INVALID;`);
    return accessor;
  }
  function generateTemplateLiteralCheck(doc, ctx, schema, accessor) {
    doc.write(`if (typeof ${accessor} !== "string") return INVALID;`);
    const pattern = schema._zod.pattern;
    if (pattern) {
      const patternConst = addConstant(ctx, pattern);
      doc.write(`${patternConst}.lastIndex = 0;`);
      doc.write(`if (!${patternConst}.test(${accessor})) return INVALID;`);
    }
    return accessor;
  }
  function generateLazyCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const getterConst = addUserConstant(ctx, def.getter);
    const cacheConst = addConstant(ctx, { parser: null });
    doc.write(`if (!${cacheConst}.parser) {`);
    doc.indented((d) => {
      d.write(`const inner = ${getterConst}();`);
      d.write(`${cacheConst}.parser = function(input) {`);
      d.indented((d2) => {
        d2.write(`const result = inner._zod.run({ value: input, issues: [] }, {});`);
        d2.write(`return result.issues.length === 0 ? result.value : INVALID;`);
      });
      d.write(`};`);
    });
    doc.write(`}`);
    const outputVar = newVar(ctx);
    doc.write(`const ${outputVar} = ${cacheConst}.parser(${accessor});`);
    doc.write(`if (${outputVar} === INVALID) return INVALID;`);
    return outputVar;
  }
  function generatePipeCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    const inputOutput = generateCheck(doc, ctx, def.in, accessor);
    if (def.transform) {
      if (isAsyncFunction(def.transform)) {
        throw new ZodCompileAsyncError("z.compile: async transforms in pipes are not supported");
      }
      const transformFn = def.transform;
      const helperFn = (value) => {
        const fakePayload = { value, issues: [], addIssue: pushIssue };
        const result = transformFn(value, fakePayload);
        if (result instanceof Promise)
          return INVALID;
        return fakePayload.issues.length === 0 ? result : INVALID;
      };
      const helperConst = addUserConstant(ctx, helperFn);
      const transformedVar = newVar(ctx);
      doc.write(`const ${transformedVar} = ${helperConst}(${inputOutput});`);
      doc.write(`if (${transformedVar} === INVALID) return INVALID;`);
      return generateCheck(doc, ctx, def.out, transformedVar);
    } else {
      return generateCheck(doc, ctx, def.out, inputOutput);
    }
  }
  function isAsyncFunction(fn) {
    return typeof fn === "function" && (fn.constructor.name === "AsyncFunction" || fn[Symbol.toStringTag] === "AsyncFunction");
  }
  function generateCustomCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    if (def.fn) {
      if (isAsyncFunction(def.fn)) {
        throw new ZodCompileAsyncError("z.compile: async custom predicates are not supported");
      }
      const fnConst = addUserConstant(ctx, def.fn);
      const throwAsyncConst = addConstant(ctx, throwAsync);
      const resVar = newVar(ctx);
      doc.write(`const ${resVar} = ${fnConst}(${accessor});`);
      doc.write(`if (${resVar} instanceof Promise) ${throwAsyncConst}();`);
      doc.write(`if (!${resVar}) return INVALID;`);
    } else {
      throw new ZodCompileUnsupportedError("custom schema without a predicate function");
    }
    return accessor;
  }
  function runtimeCatch(innerSchema, catchValue, value) {
    const result = innerSchema._zod.run({ value, issues: [] }, {});
    if (result && typeof result.then === "function")
      return INVALID;
    const r = result;
    if (r.issues.length === 0)
      return r.value;
    return catchValue();
  }
  function generateCatchCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    if (!def.catchValue[CONSTANT_CATCH]) {
      throw new ZodCompileUnsupportedError("catch with a callback (only a constant catch value compiles)", false);
    }
    const outputVar = newVar(ctx);
    doc.write(`let ${outputVar} = (() => {`);
    doc.indented((d) => {
      const innerOut = compileChild(d, ctx, def.innerType, accessor);
      d.write(`return ${innerOut};`);
    });
    doc.write(`})();`);
    const innerConst = addConstant(ctx, def.innerType);
    const catchConst = addUserConstant(ctx, def.catchValue);
    const catchHelperConst = addConstant(ctx, runtimeCatch);
    doc.write(`if (${outputVar} === INVALID) {`);
    doc.indented((d) => {
      d.write(`${outputVar} = ${catchHelperConst}(${innerConst}, ${catchConst}, ${accessor});`);
      d.write(`if (${outputVar} === INVALID) return INVALID;`);
    });
    doc.write(`}`);
    return outputVar;
  }
  function generateTransformCheck(doc, ctx, schema, accessor) {
    const def = schema._zod.def;
    if (def.transform) {
      if (isAsyncFunction(def.transform)) {
        throw new ZodCompileAsyncError("z.compile: async transforms are not supported");
      }
      const transformFn = def.transform;
      const helperFn = (value) => {
        const fakePayload = { value, issues: [], addIssue: pushIssue };
        const result = transformFn(value, fakePayload);
        if (result instanceof Promise)
          return INVALID;
        return fakePayload.issues.length === 0 ? result : INVALID;
      };
      const helperConst = addUserConstant(ctx, helperFn);
      const outputVar = newVar(ctx);
      doc.write(`const ${outputVar} = ${helperConst}(${accessor});`);
      doc.write(`if (${outputVar} === INVALID) return INVALID;`);
      return outputVar;
    }
    return accessor;
  }

  // ../../../node_modules/zod/v4/core/api.js
  function snapshotChecks(def) {
    if (def.checks)
      def.checks = [...def.checks];
    return def;
  }
  // @__NO_SIDE_EFFECTS__
  function _string(Class2, params) {
    return new Class2(snapshotChecks({ type: "string", ...normalizeParams(params) }));
  }
  // @__NO_SIDE_EFFECTS__
  function _coercedString(Class2, params) {
    return new Class2(snapshotChecks({ type: "string", coerce: true, ...normalizeParams(params) }));
  }
  // @__NO_SIDE_EFFECTS__
  function _email(Class2, params) {
    return new Class2({
      type: "string",
      format: "email",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _guid(Class2, params) {
    return new Class2({
      type: "string",
      format: "guid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uuid(Class2, params) {
    return new Class2({
      type: "string",
      format: "uuid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uuidv4(Class2, params) {
    return new Class2({
      type: "string",
      format: "uuid",
      check: "string_format",
      abort: false,
      version: "v4",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uuidv6(Class2, params) {
    return new Class2({
      type: "string",
      format: "uuid",
      check: "string_format",
      abort: false,
      version: "v6",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uuidv7(Class2, params) {
    return new Class2({
      type: "string",
      format: "uuid",
      check: "string_format",
      abort: false,
      version: "v7",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _url(Class2, params) {
    return new Class2({
      type: "string",
      format: "url",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _emoji2(Class2, params) {
    return new Class2({
      type: "string",
      format: "emoji",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _nanoid(Class2, params) {
    return new Class2({
      type: "string",
      format: "nanoid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _cuid(Class2, params) {
    return new Class2({
      type: "string",
      format: "cuid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _cuid2(Class2, params) {
    return new Class2({
      type: "string",
      format: "cuid2",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _ulid(Class2, params) {
    return new Class2({
      type: "string",
      format: "ulid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _xid(Class2, params) {
    return new Class2({
      type: "string",
      format: "xid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _ksuid(Class2, params) {
    return new Class2({
      type: "string",
      format: "ksuid",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _ipv4(Class2, params) {
    return new Class2({
      type: "string",
      format: "ipv4",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _ipv6(Class2, params) {
    return new Class2({
      type: "string",
      format: "ipv6",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _mac(Class2, params) {
    return new Class2({
      type: "string",
      format: "mac",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _cidrv4(Class2, params) {
    return new Class2({
      type: "string",
      format: "cidrv4",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _cidrv6(Class2, params) {
    return new Class2({
      type: "string",
      format: "cidrv6",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _base64(Class2, params) {
    return new Class2({
      type: "string",
      format: "base64",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _base64url(Class2, params) {
    return new Class2({
      type: "string",
      format: "base64url",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _e164(Class2, params) {
    return new Class2({
      type: "string",
      format: "e164",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _creditCard(Class2, params) {
    return new Class2({
      type: "string",
      format: "credit_card",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _iban(Class2, params) {
    return new Class2({
      type: "string",
      format: "iban",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _jwt(Class2, params) {
    return new Class2({
      type: "string",
      format: "jwt",
      check: "string_format",
      abort: false,
      ...normalizeParams(params)
    });
  }
  var TimePrecision = {
    Any: null,
    Minute: -1,
    Second: 0,
    Millisecond: 3,
    Microsecond: 6
  };
  // @__NO_SIDE_EFFECTS__
  function _isoDateTime(Class2, params) {
    return new Class2({
      type: "string",
      format: "datetime",
      check: "string_format",
      offset: false,
      local: false,
      precision: null,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _isoDate(Class2, params) {
    return new Class2({
      type: "string",
      format: "date",
      check: "string_format",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _isoTime(Class2, params) {
    return new Class2({
      type: "string",
      format: "time",
      check: "string_format",
      precision: null,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _isoDuration(Class2, params) {
    return new Class2({
      type: "string",
      format: "duration",
      check: "string_format",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _number(Class2, params) {
    return new Class2(snapshotChecks({ type: "number", checks: [], ...normalizeParams(params) }));
  }
  // @__NO_SIDE_EFFECTS__
  function _coercedNumber(Class2, params) {
    return new Class2(snapshotChecks({ type: "number", coerce: true, checks: [], ...normalizeParams(params) }));
  }
  // @__NO_SIDE_EFFECTS__
  function _int(Class2, params) {
    return new Class2({
      type: "number",
      check: "number_format",
      abort: false,
      format: "safeint",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _float32(Class2, params) {
    return new Class2({
      type: "number",
      check: "number_format",
      abort: false,
      format: "float32",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _float64(Class2, params) {
    return new Class2({
      type: "number",
      check: "number_format",
      abort: false,
      format: "float64",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _int32(Class2, params) {
    return new Class2({
      type: "number",
      check: "number_format",
      abort: false,
      format: "int32",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uint32(Class2, params) {
    return new Class2({
      type: "number",
      check: "number_format",
      abort: false,
      format: "uint32",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _boolean(Class2, params) {
    return new Class2({
      type: "boolean",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _coercedBoolean(Class2, params) {
    return new Class2({
      type: "boolean",
      coerce: true,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _bigint(Class2, params) {
    return new Class2({
      type: "bigint",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _coercedBigint(Class2, params) {
    return new Class2({
      type: "bigint",
      coerce: true,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _int64(Class2, params) {
    return new Class2({
      type: "bigint",
      check: "bigint_format",
      abort: false,
      format: "int64",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uint64(Class2, params) {
    return new Class2({
      type: "bigint",
      check: "bigint_format",
      abort: false,
      format: "uint64",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _symbol(Class2, params) {
    return new Class2({
      type: "symbol",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _undefined2(Class2, params) {
    return new Class2({
      type: "undefined",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _null2(Class2, params) {
    return new Class2({
      type: "null",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _any(Class2) {
    return new Class2({
      type: "any"
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _unknown(Class2) {
    return new Class2({
      type: "unknown"
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _never(Class2, params) {
    return new Class2({
      type: "never",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _void(Class2, params) {
    return new Class2({
      type: "void",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _date(Class2, params) {
    return new Class2({
      type: "date",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _coercedDate(Class2, params) {
    return new Class2({
      type: "date",
      coerce: true,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _nan(Class2, params) {
    return new Class2({
      type: "nan",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _lt(value, params) {
    return new $ZodCheckLessThan({
      check: "less_than",
      ...normalizeParams(params),
      value,
      inclusive: false
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _lte(value, params) {
    return new $ZodCheckLessThan({
      check: "less_than",
      ...normalizeParams(params),
      value,
      inclusive: true
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _gt(value, params) {
    return new $ZodCheckGreaterThan({
      check: "greater_than",
      ...normalizeParams(params),
      value,
      inclusive: false
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _gte(value, params) {
    return new $ZodCheckGreaterThan({
      check: "greater_than",
      ...normalizeParams(params),
      value,
      inclusive: true
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _positive(params) {
    return /* @__PURE__ */ _gt(0, params);
  }
  // @__NO_SIDE_EFFECTS__
  function _negative(params) {
    return /* @__PURE__ */ _lt(0, params);
  }
  // @__NO_SIDE_EFFECTS__
  function _nonpositive(params) {
    return /* @__PURE__ */ _lte(0, params);
  }
  // @__NO_SIDE_EFFECTS__
  function _nonnegative(params) {
    return /* @__PURE__ */ _gte(0, params);
  }
  // @__NO_SIDE_EFFECTS__
  function _multipleOf(value, params) {
    return new $ZodCheckMultipleOf({
      check: "multiple_of",
      ...normalizeParams(params),
      value
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _maxSize(maximum, params) {
    return new $ZodCheckMaxSize({
      check: "max_size",
      ...normalizeParams(params),
      maximum
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _minSize(minimum, params) {
    return new $ZodCheckMinSize({
      check: "min_size",
      ...normalizeParams(params),
      minimum
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _size(size, params) {
    return new $ZodCheckSizeEquals({
      check: "size_equals",
      ...normalizeParams(params),
      size
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _maxLength(maximum, params) {
    const ch = new $ZodCheckMaxLength({
      check: "max_length",
      ...normalizeParams(params),
      maximum
    });
    return ch;
  }
  // @__NO_SIDE_EFFECTS__
  function _minLength(minimum, params) {
    return new $ZodCheckMinLength({
      check: "min_length",
      ...normalizeParams(params),
      minimum
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _length(length, params) {
    return new $ZodCheckLengthEquals({
      check: "length_equals",
      ...normalizeParams(params),
      length
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _regex(pattern, params) {
    return new $ZodCheckRegex({
      check: "string_format",
      format: "regex",
      ...normalizeParams(params),
      pattern
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _lowercase(params) {
    return new $ZodCheckLowerCase({
      check: "string_format",
      format: "lowercase",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _uppercase(params) {
    return new $ZodCheckUpperCase({
      check: "string_format",
      format: "uppercase",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _includes(includes, params) {
    return new $ZodCheckIncludes({
      check: "string_format",
      format: "includes",
      ...normalizeParams(params),
      includes
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _startsWith(prefix, params) {
    return new $ZodCheckStartsWith({
      check: "string_format",
      format: "starts_with",
      ...normalizeParams(params),
      prefix
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _endsWith(suffix, params) {
    return new $ZodCheckEndsWith({
      check: "string_format",
      format: "ends_with",
      ...normalizeParams(params),
      suffix
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _property(property, schema, params) {
    return new $ZodCheckProperty({
      check: "property",
      property,
      schema,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _properties(shape, params) {
    return new $ZodCheckProperties({
      check: "properties",
      shape,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _mime(types, params) {
    return new $ZodCheckMimeType({
      check: "mime_type",
      mime: types,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _overwrite(tx) {
    return new $ZodCheckOverwrite({
      check: "overwrite",
      tx
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _normalize(form) {
    return /* @__PURE__ */ _overwrite((input2) => input2.normalize(form));
  }
  // @__NO_SIDE_EFFECTS__
  function _trim() {
    return /* @__PURE__ */ _overwrite((input2) => input2.trim());
  }
  // @__NO_SIDE_EFFECTS__
  function _toLowerCase() {
    return /* @__PURE__ */ _overwrite((input2) => input2.toLowerCase());
  }
  // @__NO_SIDE_EFFECTS__
  function _toUpperCase() {
    return /* @__PURE__ */ _overwrite((input2) => input2.toUpperCase());
  }
  // @__NO_SIDE_EFFECTS__
  function _slugify() {
    return /* @__PURE__ */ _overwrite((input2) => slugify(input2));
  }
  // @__NO_SIDE_EFFECTS__
  function _array(Class2, element, params) {
    return new Class2({
      type: "array",
      element,
      // get element() {
      //   return element;
      // },
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _union(Class2, options, params) {
    return new Class2({
      type: "union",
      options,
      ...normalizeParams(params)
    });
  }
  function _xor(Class2, options, params) {
    return new Class2({
      type: "union",
      options,
      inclusive: false,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _discriminatedUnion(Class2, discriminator, options, params) {
    return new Class2({
      type: "union",
      options,
      discriminator,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _intersection(Class2, left, right) {
    return new Class2({
      type: "intersection",
      left,
      right
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _tuple(Class2, items, _paramsOrRest, _params) {
    const hasRest = _paramsOrRest instanceof $ZodType;
    const params = hasRest ? _params : _paramsOrRest;
    const rest = hasRest ? _paramsOrRest : null;
    return new Class2({
      type: "tuple",
      items,
      rest,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _record(Class2, keyType, valueType, params) {
    return new Class2({
      type: "record",
      keyType,
      valueType,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _map(Class2, keyType, valueType, params) {
    return new Class2({
      type: "map",
      keyType,
      valueType,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _set(Class2, valueType, params) {
    return new Class2({
      type: "set",
      valueType,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _enum(Class2, values, params) {
    const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
    return new Class2({
      type: "enum",
      entries,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _nativeEnum(Class2, entries, params) {
    return new Class2({
      type: "enum",
      entries,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _literal(Class2, value, params) {
    return new Class2({
      type: "literal",
      values: Array.isArray(value) ? value : [value],
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _file(Class2, params) {
    return new Class2({
      type: "file",
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _transform(Class2, fn) {
    return new Class2({
      type: "transform",
      transform: fn
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _optional(Class2, innerType) {
    return new Class2({
      type: "optional",
      innerType
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _nullable(Class2, innerType) {
    return new Class2({
      type: "nullable",
      innerType
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _default(Class2, innerType, defaultValue) {
    return new Class2({
      type: "default",
      innerType,
      get defaultValue() {
        return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
      }
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _nonoptional(Class2, innerType, params) {
    return new Class2({
      type: "nonoptional",
      innerType,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _success(Class2, innerType) {
    return new Class2({
      type: "success",
      innerType
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _catch(Class2, innerType, catchValue) {
    return new Class2({
      type: "catch",
      innerType,
      catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _pipe(Class2, in_, out) {
    return new Class2({
      type: "pipe",
      in: in_,
      out
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _readonly(Class2, innerType) {
    return new Class2({
      type: "readonly",
      innerType
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _templateLiteral(Class2, parts, params) {
    return new Class2({
      type: "template_literal",
      parts,
      ...normalizeParams(params)
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _lazy(Class2, getter) {
    return new Class2({
      type: "lazy",
      getter
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _promise(Class2, innerType) {
    return new Class2({
      type: "promise",
      innerType
    });
  }
  // @__NO_SIDE_EFFECTS__
  function _custom(Class2, fn, _params) {
    const norm = normalizeParams(_params);
    norm.abort ?? (norm.abort = true);
    const schema = new Class2({
      type: "custom",
      check: "custom",
      fn,
      ...norm
    });
    return schema;
  }
  // @__NO_SIDE_EFFECTS__
  function _refine(Class2, fn, _params) {
    const schema = new Class2({
      type: "custom",
      check: "custom",
      fn,
      ...normalizeParams(_params)
    });
    return schema;
  }
  // @__NO_SIDE_EFFECTS__
  function _superRefine(fn, params) {
    const ch = /* @__PURE__ */ _check((payload) => {
      payload.addIssue = (issue3) => {
        if (typeof issue3 === "string") {
          payload.issues.push(issue(issue3, payload.value, ch._zod.def));
        } else {
          const _issue = issue3;
          if (_issue.fatal)
            _issue.continue = false;
          _issue.code ?? (_issue.code = "custom");
          if (!("input" in _issue))
            _issue.input = payload.value;
          _issue.inst ?? (_issue.inst = ch);
          _issue.continue ?? (_issue.continue = !ch._zod.def.abort);
          payload.issues.push(issue(_issue));
        }
      };
      return fn(payload.value, payload);
    }, params);
    return ch;
  }
  // @__NO_SIDE_EFFECTS__
  function _check(fn, params) {
    const ch = new $ZodCheck({
      check: "custom",
      ...normalizeParams(params)
    });
    ch._zod.check = fn;
    return ch;
  }
  // @__NO_SIDE_EFFECTS__
  function describe(description) {
    const ch = new $ZodCheck({ check: "describe" });
    ch._zod.onattach = [
      (inst) => {
        const existing = globalRegistry.get(inst) ?? {};
        globalRegistry.add(inst, { ...existing, description });
      }
    ];
    ch._zod.check = () => {
    };
    return ch;
  }
  // @__NO_SIDE_EFFECTS__
  function meta(metadata) {
    const ch = new $ZodCheck({ check: "meta" });
    ch._zod.onattach = [
      (inst) => {
        const existing = globalRegistry.get(inst) ?? {};
        globalRegistry.add(inst, { ...existing, ...metadata });
      }
    ];
    ch._zod.check = () => {
    };
    return ch;
  }
  // @__NO_SIDE_EFFECTS__
  function _stringbool(Classes, _params) {
    const params = normalizeParams(_params);
    let truthyArray = params.truthy ?? ["true", "1", "yes", "on", "y", "enabled"];
    let falsyArray = params.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
    if (params.case !== "sensitive") {
      truthyArray = truthyArray.map((v) => typeof v === "string" ? v.toLowerCase() : v);
      falsyArray = falsyArray.map((v) => typeof v === "string" ? v.toLowerCase() : v);
    }
    const truthySet = new Set(truthyArray);
    const falsySet = new Set(falsyArray);
    const _Codec = Classes.Codec ?? $ZodCodec;
    const _Boolean = Classes.Boolean ?? $ZodBoolean;
    const _String = Classes.String ?? $ZodString;
    const stringSchema = new _String({ type: "string", error: params.error });
    const booleanSchema = new _Boolean({ type: "boolean", error: params.error });
    const codec2 = new _Codec({
      type: "pipe",
      in: stringSchema,
      out: booleanSchema,
      transform: ((input2, payload) => {
        let data = input2;
        if (params.case !== "sensitive")
          data = data.toLowerCase();
        if (truthySet.has(data)) {
          return true;
        } else if (falsySet.has(data)) {
          return false;
        } else {
          payload.issues.push({
            code: "invalid_value",
            expected: "stringbool",
            values: [...truthySet, ...falsySet],
            input: payload.value,
            inst: codec2,
            continue: false
          });
          return {};
        }
      }),
      reverseTransform: ((input2, _payload) => {
        if (input2 === true) {
          return truthyArray[0] || "true";
        } else {
          return falsyArray[0] || "false";
        }
      }),
      error: params.error
    });
    codec2._zod.bag.truthy = truthyArray;
    codec2._zod.bag.falsy = falsyArray;
    codec2._zod.bag.case = params.case ?? "insensitive";
    return codec2;
  }
  // @__NO_SIDE_EFFECTS__
  function _stringFormat(Class2, format, fnOrRegex, _params = {}) {
    const params = normalizeParams(_params);
    const def = {
      check: "string_format",
      type: "string",
      format,
      fn: typeof fnOrRegex === "function" ? fnOrRegex : (val) => fnOrRegex.test(val),
      ...params
    };
    if (fnOrRegex instanceof RegExp) {
      def.pattern = fnOrRegex;
    }
    const inst = new Class2(def);
    return inst;
  }

  // ../../../node_modules/zod/v4/core/to-json-schema.js
  function assignProps(target3, ...sources) {
    for (const source of sources) {
      for (const key6 of Reflect.ownKeys(source)) {
        if (Object.prototype.propertyIsEnumerable.call(source, key6)) {
          assignProp(target3, key6, source[key6]);
        }
      }
    }
    return target3;
  }
  function initializeContext(params) {
    let target3 = params?.target ?? "draft-2020-12";
    if (target3 === "draft-4")
      target3 = "draft-04";
    if (target3 === "draft-7")
      target3 = "draft-07";
    return {
      processors: params.processors ?? {},
      metadataRegistry: params?.metadata ?? globalRegistry,
      target: target3,
      unrepresentable: params?.unrepresentable ?? "throw",
      override: params?.override ?? (() => {
      }),
      io: params?.io ?? "output",
      counter: 0,
      seen: /* @__PURE__ */ new Map(),
      sharedDefsExtractedFor: void 0,
      sharedEmitDoneFor: void 0,
      cycles: params?.cycles ?? "ref",
      reused: params?.reused ?? "inline",
      intersections: [],
      deferred: [],
      external: params?.external ?? void 0
    };
  }
  function handleUnrepresentable(schema, ctx, json2, params, message2) {
    const result = typeof ctx.unrepresentable === "function" ? ctx.unrepresentable({ zodSchema: schema, path: params.path, message: message2 }) : ctx.unrepresentable;
    if (result === "any")
      return false;
    if (result === void 0 || result === "throw")
      throw new Error(message2);
    Object.assign(json2, result);
    return true;
  }
  function processSchema(schema, ctx, _params = { path: [], schemaPath: [] }) {
    var _a3;
    const def = schema._zod.def;
    const seen = ctx.seen.get(schema);
    if (seen) {
      seen.count++;
      const isCycle = _params.schemaPath.includes(schema);
      if (isCycle) {
        seen.cycle = _params.path;
      }
      return seen.schema;
    }
    const result = { schema: {}, count: 1, cycle: void 0, path: _params.path };
    ctx.seen.set(schema, result);
    ctx.sharedDefsExtractedFor = void 0;
    ctx.sharedEmitDoneFor = void 0;
    const overrideSchema = schema._zod.toJSONSchema?.();
    if (overrideSchema) {
      result.schema = overrideSchema;
    } else {
      const params = {
        ..._params,
        schemaPath: [..._params.schemaPath, schema],
        path: _params.path
      };
      if (schema._zod.processJSONSchema) {
        schema._zod.processJSONSchema(ctx, result.schema, params);
      } else {
        const _json = result.schema;
        const processor = ctx.processors[def.type];
        if (!processor) {
          throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
        }
        processor(schema, ctx, _json, params);
      }
      const parent = schema._zod.parent;
      if (parent) {
        if (!result.ref)
          result.ref = parent;
        processSchema(parent, ctx, params);
        ctx.seen.get(parent).isParent = true;
      }
    }
    const meta3 = ctx.metadataRegistry.get(schema);
    if (meta3)
      assignProps(result.schema, meta3);
    if (ctx.io === "input" && isTransforming(schema)) {
      delete result.schema.examples;
      delete result.schema.default;
    }
    if (ctx.io === "input" && "_prefault" in result.schema)
      (_a3 = result.schema).default ?? (_a3.default = result.schema._prefault);
    delete result.schema._prefault;
    const _result = ctx.seen.get(schema);
    return _result.schema;
  }
  function encodeJSONPointerSegment(segment) {
    return segment.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  function extractDefs(ctx, schema) {
    const root = ctx.seen.get(schema);
    if (!root)
      throw new Error("Unprocessed schema. This is a bug in Zod.");
    if (ctx.external && ctx.sharedDefsExtractedFor === ctx.external)
      return;
    const idToSchema = /* @__PURE__ */ new Map();
    for (const entry of ctx.seen.entries()) {
      const id18 = ctx.metadataRegistry.get(entry[0])?.id;
      if (id18) {
        const existing = idToSchema.get(id18);
        if (existing && existing !== entry[0]) {
          throw new Error(`Duplicate schema id "${id18}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
        }
        idToSchema.set(id18, entry[0]);
      }
    }
    const makeURI = (entry) => {
      const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
      if (ctx.external) {
        const externalId = ctx.external.registry.get(entry[0])?.id;
        const uriGenerator = ctx.external.uri ?? ((id19) => id19);
        if (externalId) {
          return { ref: uriGenerator(externalId) };
        }
        const id18 = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
        entry[1].defId = id18;
        return { defId: id18, ref: `${uriGenerator("__shared")}#/${defsSegment}/${encodeJSONPointerSegment(id18)}` };
      }
      const uriPrefix = `#`;
      const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
      if (entry[1] === root && !entry[1].schema.id) {
        return { ref: uriPrefix };
      }
      const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
      return { defId, ref: defUriPrefix + encodeJSONPointerSegment(defId) };
    };
    const extractToDef = (entry) => {
      if (entry[1].schema.$ref) {
        return;
      }
      const seen = entry[1];
      const { ref, defId } = makeURI(entry);
      seen.def = { ...seen.schema };
      if (defId)
        seen.defId = defId;
      const schema2 = seen.schema;
      for (const key6 in schema2) {
        delete schema2[key6];
      }
      schema2.$ref = ref;
    };
    if (ctx.cycles === "throw") {
      for (const entry of ctx.seen.entries()) {
        const seen = entry[1];
        if (seen.cycle) {
          throw new Error(`Cycle detected: #/${seen.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
        }
      }
    }
    for (const entry of ctx.seen.entries()) {
      const seen = entry[1];
      if (schema === entry[0]) {
        extractToDef(entry);
        continue;
      }
      if (ctx.external) {
        const ext = ctx.external.registry.get(entry[0])?.id;
        if (schema !== entry[0] && ext) {
          extractToDef(entry);
          continue;
        }
      }
      const id18 = ctx.metadataRegistry.get(entry[0])?.id;
      if (id18) {
        extractToDef(entry);
        continue;
      }
      if (seen.cycle) {
        extractToDef(entry);
        continue;
      }
      if (seen.count > 1) {
        if (ctx.reused === "ref") {
          extractToDef(entry);
        }
      }
    }
    if (ctx.external)
      ctx.sharedDefsExtractedFor = ctx.external;
  }
  function compactTypeUnion(schema) {
    const options = schema.anyOf;
    if (!Array.isArray(options) || options.length === 0 || schema.type !== void 0)
      return;
    const types = [];
    for (const option2 of options) {
      if (!option2 || typeof option2 !== "object")
        return;
      compactTypeUnion(option2);
      const keys = Object.keys(option2);
      if (keys.length !== 1 || keys[0] !== "type")
        return;
      const type = option2.type;
      for (const member of Array.isArray(type) ? type : [type]) {
        if (typeof member !== "string")
          return;
        if (!types.includes(member))
          types.push(member);
      }
    }
    delete schema.anyOf;
    schema.type = types.length === 1 ? types[0] : types;
  }
  var FOLDABLE_KEYS = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]);
  var UNION_KEYS = ["oneOf", "anyOf"];
  function undeclaredConstraint(member) {
    const extra = member.additionalProperties;
    if (extra === void 0 || extra === false || typeof extra !== "object" || extra === null)
      return null;
    return Object.keys(extra).length ? extra : null;
  }
  function foldObjects(members2) {
    const objects = [];
    for (const member of members2) {
      if (typeof member !== "object" || member.type !== "object")
        return null;
      for (const key6 in member) {
        if (!FOLDABLE_KEYS.has(key6))
          return null;
      }
      objects.push(member);
    }
    const properties = {};
    const required2 = /* @__PURE__ */ new Set();
    for (const object2 of objects) {
      for (const key6 in object2.properties) {
        if (Object.prototype.hasOwnProperty.call(properties, key6))
          continue;
        const parts = [];
        for (const other of objects) {
          const part = other.properties?.[key6] ?? undeclaredConstraint(other);
          if (part === null || part === void 0)
            continue;
          if (!parts.some((seen) => JSON.stringify(seen) === JSON.stringify(part)))
            parts.push(part);
        }
        const merged = parts.length === 1 ? parts[0] : foldObjects(parts) ?? { allOf: parts };
        assignProp(properties, key6, merged);
      }
      for (const key6 of object2.required ?? [])
        required2.add(key6);
    }
    const folded = { type: "object", properties };
    if (required2.size)
      folded.required = [...required2];
    if (objects.every((object2) => object2.additionalProperties === false)) {
      folded.additionalProperties = false;
    } else {
      const constraints = [];
      for (const object2 of objects) {
        const constraint = undeclaredConstraint(object2);
        if (constraint && !constraints.some((seen) => JSON.stringify(seen) === JSON.stringify(constraint)))
          constraints.push(constraint);
      }
      if (constraints.length === 1)
        folded.additionalProperties = constraints[0];
      else if (constraints.length > 1)
        folded.additionalProperties = { allOf: constraints };
    }
    return folded;
  }
  function foldIntersection(json2) {
    const allOf = json2.allOf;
    if (!Array.isArray(allOf) || allOf.length < 2)
      return;
    for (const key6 of FOLDABLE_KEYS)
      if (key6 in json2)
        return;
    const unions = allOf.filter((m) => UNION_KEYS.some((k) => Array.isArray(m[k])));
    let folded = null;
    if (!unions.length) {
      folded = foldObjects(allOf);
    } else {
      const union2 = unions[0];
      const keyword = UNION_KEYS.find((k) => Array.isArray(union2[k]));
      if (Object.keys(union2).length !== 1)
        return;
      const rest = allOf.filter((m) => m !== union2);
      const branches = union2[keyword].map((branch) => foldObjects([...rest, branch]));
      if (branches.some((b) => !b))
        return;
      folded = { [keyword]: branches };
    }
    if (!folded)
      return;
    delete json2.allOf;
    assignProps(json2, folded);
  }
  function finalize(ctx, schema) {
    const root = ctx.seen.get(schema);
    if (!root)
      throw new Error("Unprocessed schema. This is a bug in Zod.");
    const flattenRef = (zodSchema) => {
      const seen = ctx.seen.get(zodSchema);
      if (seen.ref === null)
        return;
      const schema2 = seen.def ?? seen.schema;
      const _cached = { ...schema2 };
      const ref = seen.ref;
      seen.ref = null;
      if (ref) {
        flattenRef(ref);
        const refSeen = ctx.seen.get(ref);
        const refSchema = refSeen.schema;
        if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
          schema2.allOf = schema2.allOf ?? [];
          schema2.allOf.push(refSchema);
        } else {
          assignProps(schema2, refSchema);
        }
        assignProps(schema2, _cached);
        const isParentRef = zodSchema._zod.parent === ref;
        if (isParentRef) {
          for (const key6 in schema2) {
            if (key6 === "$ref" || key6 === "allOf")
              continue;
            if (!(key6 in _cached)) {
              delete schema2[key6];
            }
          }
        }
        if (refSchema.$ref && refSeen.def) {
          for (const key6 in schema2) {
            if (key6 === "$ref" || key6 === "allOf")
              continue;
            if (key6 in refSeen.def && JSON.stringify(schema2[key6]) === JSON.stringify(refSeen.def[key6])) {
              delete schema2[key6];
            }
          }
        }
      }
      const parent = zodSchema._zod.parent;
      if (parent && parent !== ref) {
        flattenRef(parent);
        const parentSeen = ctx.seen.get(parent);
        if (parentSeen?.schema.$ref) {
          schema2.$ref = parentSeen.schema.$ref;
          if (parentSeen.def) {
            for (const key6 in schema2) {
              if (key6 === "$ref" || key6 === "allOf")
                continue;
              if (key6 in parentSeen.def && JSON.stringify(schema2[key6]) === JSON.stringify(parentSeen.def[key6])) {
                delete schema2[key6];
              }
            }
          }
        }
      }
      ctx.override({
        zodSchema,
        jsonSchema: schema2,
        path: seen.path ?? []
      });
    };
    if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
      for (const entry of [...ctx.seen.entries()].reverse()) {
        flattenRef(entry[0]);
      }
      if (ctx.target !== "openapi-3.0") {
        for (const entry of ctx.seen.entries()) {
          compactTypeUnion(entry[1].def ?? entry[1].schema);
        }
      }
      for (const rewrite of ctx.deferred)
        rewrite();
      if (ctx.intersections.length) {
        const carriers = /* @__PURE__ */ new Map();
        for (const seen of ctx.seen.values()) {
          for (const json2 of [seen.schema, seen.def]) {
            const allOf = json2?.allOf;
            if (!Array.isArray(allOf))
              continue;
            const existing = carriers.get(allOf);
            if (existing)
              existing.push(json2);
            else
              carriers.set(allOf, [json2]);
          }
        }
        for (const allOf of ctx.intersections) {
          for (const json2 of carriers.get(allOf) ?? [])
            foldIntersection(json2);
        }
      }
    }
    const result = {};
    if (ctx.target === "draft-2020-12") {
      result.$schema = "https://json-schema.org/draft/2020-12/schema";
    } else if (ctx.target === "draft-07") {
      result.$schema = "http://json-schema.org/draft-07/schema#";
    } else if (ctx.target === "draft-04") {
      result.$schema = "http://json-schema.org/draft-04/schema#";
    } else if (ctx.target === "openapi-3.0") {
    } else {
    }
    if (ctx.external?.uri) {
      const id18 = ctx.external.registry.get(schema)?.id;
      if (!id18)
        throw new Error("Schema is missing an `id` property");
      result.$id = ctx.external.uri(id18);
    }
    assignProps(result, root.defId ? root.schema : root.def ?? root.schema);
    const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
    if (rootMetaId !== void 0 && result.id === rootMetaId)
      delete result.id;
    const defs = ctx.external?.defs ?? {};
    if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
      for (const entry of ctx.seen.entries()) {
        const seen = entry[1];
        if (seen.def && seen.defId) {
          if (seen.def.id === seen.defId)
            delete seen.def.id;
          assignProp(defs, seen.defId, seen.def);
        }
      }
    }
    if (ctx.external)
      ctx.sharedEmitDoneFor = ctx.external;
    if (ctx.external) {
    } else {
      if (Object.keys(defs).length > 0) {
        if (ctx.target === "draft-2020-12") {
          result.$defs = defs;
        } else {
          result.definitions = defs;
        }
      }
    }
    try {
      const finalized = JSON.parse(JSON.stringify(result));
      Object.defineProperty(finalized, "~standard", {
        value: {
          ...schema["~standard"],
          jsonSchema: {
            input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
            output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
          }
        },
        enumerable: false,
        writable: false
      });
      return finalized;
    } catch (_err) {
      throw new Error("Error converting schema to JSON.");
    }
  }
  function isTransforming(_schema, _ctx) {
    const ctx = _ctx ?? { seen: /* @__PURE__ */ new Set() };
    if (ctx.seen.has(_schema))
      return false;
    ctx.seen.add(_schema);
    const def = _schema._zod.def;
    if (def.type === "transform")
      return true;
    if (def.type === "array")
      return isTransforming(def.element, ctx);
    if (def.type === "set")
      return isTransforming(def.valueType, ctx);
    if (def.type === "lazy")
      return isTransforming(def.getter(), ctx);
    if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault" || def.type === "catch") {
      return isTransforming(def.innerType, ctx);
    }
    if (def.type === "intersection") {
      return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
    }
    if (def.type === "record" || def.type === "map") {
      return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
    }
    if (def.type === "pipe") {
      if (_schema._zod.traits.has("$ZodCodec"))
        return true;
      return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
    }
    if (def.type === "object") {
      for (const key6 in def.shape) {
        if (isTransforming(def.shape[key6], ctx))
          return true;
      }
      return false;
    }
    if (def.type === "union") {
      for (const option2 of def.options) {
        if (isTransforming(option2, ctx))
          return true;
      }
      return false;
    }
    if (def.type === "tuple") {
      for (const item of def.items) {
        if (isTransforming(item, ctx))
          return true;
      }
      if (def.rest && isTransforming(def.rest, ctx))
        return true;
      return false;
    }
    return false;
  }
  var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
    const ctx = initializeContext({ ...params, processors });
    processSchema(schema, ctx);
    extractDefs(ctx, schema);
    return finalize(ctx, schema);
  };
  var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
    const { libraryOptions, target: target3 } = params ?? {};
    const ctx = initializeContext({ ...libraryOptions ?? {}, target: target3, io, processors });
    processSchema(schema, ctx);
    extractDefs(ctx, schema);
    return finalize(ctx, schema);
  };

  // ../../../node_modules/zod/v4/core/json-schema-processors.js
  var narrowMin = (agg, key6, value) => {
    if (agg[key6] === void 0 || value > agg[key6])
      agg[key6] = value;
  };
  var narrowMax = (agg, key6, value) => {
    if (agg[key6] === void 0 || value < agg[key6])
      agg[key6] = value;
  };
  var narrowBoth = (agg, value) => {
    narrowMin(agg, "minimum", value);
    narrowMax(agg, "maximum", value);
  };
  var addDivisor = (agg, value) => {
    agg.multipleOf ?? (agg.multipleOf = []);
    if (!agg.multipleOf.includes(value))
      agg.multipleOf.push(value);
  };
  var addPattern = (agg, pattern) => {
    agg.patterns ?? (agg.patterns = /* @__PURE__ */ new Set());
    agg.patterns.add(pattern);
  };
  var intersectMime = (agg, mime) => {
    agg.mime = agg.mime ? agg.mime.filter((m) => mime.includes(m)) : [...mime];
  };
  var setFormat = (agg, format) => {
    agg.format = format;
    if (format.includes("int"))
      agg.isInt = true;
  };
  var minContributor = (agg, def) => narrowMin(agg, "minimum", def.minimum);
  var maxContributor = (agg, def) => narrowMax(agg, "maximum", def.maximum);
  var formatContributor = (ranges) => (agg, def) => {
    setFormat(agg, def.format);
    const [minimum, maximum] = ranges[def.format];
    narrowMin(agg, "minimum", minimum);
    narrowMax(agg, "maximum", maximum);
  };
  var contributors = {
    greater_than: (agg, def) => narrowMin(agg, def.inclusive ? "minimum" : "exclusiveMinimum", def.value),
    less_than: (agg, def) => narrowMax(agg, def.inclusive ? "maximum" : "exclusiveMaximum", def.value),
    multiple_of: (agg, def) => addDivisor(agg, def.value),
    number_format: formatContributor(NUMBER_FORMAT_RANGES),
    bigint_format: formatContributor(BIGINT_FORMAT_RANGES),
    min_length: minContributor,
    max_length: maxContributor,
    length_equals: (agg, def) => narrowBoth(agg, def.length),
    min_size: minContributor,
    max_size: maxContributor,
    size_equals: (agg, def) => narrowBoth(agg, def.size),
    string_format: (agg, def) => {
      setFormat(agg, def.format);
      if (def.pattern)
        addPattern(agg, def.pattern);
      if (def.format === "base64" || def.format === "base64url")
        agg.contentEncoding = def.format;
      if (def.local || def.precision === -1)
        agg.laxFormat = true;
    },
    mime_type: (agg, def) => intersectMime(agg, def.mime)
  };
  function aggregateChecks(schema) {
    const agg = {};
    const def = schema._zod.def;
    const list2 = schema._zod.traits.has("$ZodCheck") ? [schema, ...def.checks ?? []] : def.checks ?? [];
    for (const ch of list2)
      contributors[ch._zod.def.check]?.(agg, ch._zod.def);
    const bag = schema._zod.bag;
    if (bag.minimum !== void 0)
      narrowMin(agg, "minimum", bag.minimum);
    if (bag.exclusiveMinimum !== void 0)
      narrowMin(agg, "exclusiveMinimum", bag.exclusiveMinimum);
    if (bag.maximum !== void 0)
      narrowMax(agg, "maximum", bag.maximum);
    if (bag.exclusiveMaximum !== void 0)
      narrowMax(agg, "exclusiveMaximum", bag.exclusiveMaximum);
    if (bag.multipleOf !== void 0)
      addDivisor(agg, bag.multipleOf);
    if (bag.format !== void 0) {
      agg.format ?? (agg.format = bag.format);
      if (bag.format.includes("int"))
        agg.isInt = true;
    }
    if (bag.mime)
      intersectMime(agg, bag.mime);
    for (const pattern of bag.patterns ?? [])
      addPattern(agg, pattern);
    return agg;
  }
  var formatMap = {
    guid: "uuid",
    url: "uri",
    datetime: "date-time",
    json_string: "json-string",
    regex: ""
    // do not set
  };
  var exactPatterns = /* @__PURE__ */ new Map([
    [base64Charset, base64],
    [base64urlCharset, base64url]
  ]);
  var exactPattern = (p) => exactPatterns.get(p) ?? p;
  var stringProcessor = (schema, ctx, _json, _params) => {
    const json2 = _json;
    json2.type = "string";
    const { minimum, maximum, format, patterns, contentEncoding, laxFormat } = aggregateChecks(schema);
    if (typeof minimum === "number")
      json2.minLength = minimum;
    if (typeof maximum === "number")
      json2.maxLength = maximum;
    if (format) {
      json2.format = formatMap[format] ?? format;
      if (json2.format === "")
        delete json2.format;
      if (format === "time" || laxFormat) {
        delete json2.format;
      }
    }
    if (contentEncoding)
      json2.contentEncoding = contentEncoding;
    if (patterns && patterns.size > 0) {
      const patternList = [...patterns].map(exactPattern);
      if (patternList.length === 1)
        json2.pattern = patternList[0].source;
      else if (patternList.length > 1) {
        json2.allOf = [
          ...patternList.map((regex) => ({
            ...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
            pattern: regex.source
          }))
        ];
      }
    }
  };
  var numberProcessor = (schema, ctx, _json, params) => {
    const json2 = _json;
    const { minimum, maximum, multipleOf, exclusiveMaximum, exclusiveMinimum, isInt } = aggregateChecks(schema);
    json2.type = isInt ? "integer" : "number";
    const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
    const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
    const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
    if (exMin) {
      if (legacy) {
        json2.minimum = exclusiveMinimum;
        json2.exclusiveMinimum = true;
      } else {
        json2.exclusiveMinimum = exclusiveMinimum;
      }
    } else if (typeof minimum === "number") {
      json2.minimum = minimum;
    }
    if (exMax) {
      if (legacy) {
        json2.maximum = exclusiveMaximum;
        json2.exclusiveMaximum = true;
      } else {
        json2.exclusiveMaximum = exclusiveMaximum;
      }
    } else if (typeof maximum === "number") {
      json2.maximum = maximum;
    }
    if (multipleOf) {
      const divisors = /* @__PURE__ */ new Set();
      for (const divisor of multipleOf) {
        if (Number.isFinite(divisor) && divisor !== 0)
          divisors.add(Math.abs(divisor));
        else
          handleUnrepresentable(schema, ctx, json2, params, `A multipleOf divisor of ${divisor} cannot be represented in JSON Schema`);
      }
      const [first, ...rest] = divisors;
      if (first !== void 0)
        json2.multipleOf = first;
      if (rest.length)
        json2.allOf = [...json2.allOf ?? [], ...rest.map((m) => ({ multipleOf: m }))];
    }
  };
  var booleanProcessor = (_schema, _ctx, json2, _params) => {
    json2.type = "boolean";
  };
  var bigintProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "BigInt cannot be represented in JSON Schema");
  };
  var symbolProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Symbols cannot be represented in JSON Schema");
  };
  var nullProcessor = (_schema, ctx, json2, _params) => {
    if (ctx.target === "openapi-3.0") {
      json2.type = "string";
      json2.nullable = true;
      json2.enum = [null];
    } else {
      json2.type = "null";
    }
  };
  var undefinedProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Undefined cannot be represented in JSON Schema");
  };
  var voidProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Void cannot be represented in JSON Schema");
  };
  var neverProcessor = (_schema, _ctx, json2, _params) => {
    json2.not = {};
  };
  var anyProcessor = (_schema, _ctx, _json, _params) => {
  };
  var unknownProcessor = (_schema, _ctx, _json, _params) => {
  };
  var dateProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Date cannot be represented in JSON Schema");
  };
  var enumProcessor = (schema, _ctx, json2, _params) => {
    const def = schema._zod.def;
    const values = getEnumValues(def.entries);
    if (values.length === 0) {
      json2.not = {};
      return;
    }
    if (values.every((v) => typeof v === "number"))
      json2.type = "number";
    if (values.every((v) => typeof v === "string"))
      json2.type = "string";
    json2.enum = values;
  };
  var literalProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    if (def.values.length === 0) {
      json2.not = {};
      return;
    }
    const vals = [];
    for (const val of def.values) {
      if (val === void 0) {
        if (handleUnrepresentable(schema, ctx, json2, params, "Literal `undefined` cannot be represented in JSON Schema"))
          return;
      } else if (typeof val === "bigint") {
        if (handleUnrepresentable(schema, ctx, json2, params, "BigInt literals cannot be represented in JSON Schema"))
          return;
        vals.push(Number(val));
      } else {
        vals.push(val);
      }
    }
    if (vals.length === 0) {
    } else if (vals.length === 1) {
      const val = vals[0];
      json2.type = val === null ? "null" : typeof val;
      if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") {
        json2.enum = [val];
      } else {
        json2.const = val;
      }
    } else {
      if (vals.every((v) => typeof v === "number"))
        json2.type = "number";
      if (vals.every((v) => typeof v === "string"))
        json2.type = "string";
      if (vals.every((v) => typeof v === "boolean"))
        json2.type = "boolean";
      if (vals.every((v) => v === null))
        json2.type = "null";
      json2.enum = vals;
    }
  };
  var nanProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "NaN cannot be represented in JSON Schema");
  };
  var templateLiteralProcessor = (schema, _ctx, json2, _params) => {
    const _json = json2;
    const pattern = schema._zod.pattern;
    if (!pattern)
      throw new Error("Pattern not found in template literal");
    _json.type = "string";
    _json.pattern = pattern.source;
  };
  var fileProcessor = (schema, _ctx, json2, _params) => {
    const _json = json2;
    _json.type = "string";
    _json.format = "binary";
    _json.contentEncoding = "binary";
    const { minimum, maximum, mime } = aggregateChecks(schema);
    if (minimum !== void 0)
      _json.minLength = minimum;
    if (maximum !== void 0)
      _json.maxLength = maximum;
    if (!mime)
      return;
    if (mime.length === 0)
      _json.not = {};
    else if (mime.length === 1)
      _json.contentMediaType = mime[0];
    else
      _json.anyOf = mime.map((m) => ({ contentMediaType: m }));
  };
  var successProcessor = (_schema, _ctx, json2, _params) => {
    json2.type = "boolean";
  };
  var customProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Custom types cannot be represented in JSON Schema");
  };
  var functionProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Function types cannot be represented in JSON Schema");
  };
  var transformProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Transforms cannot be represented in JSON Schema");
  };
  var mapProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Map cannot be represented in JSON Schema");
  };
  var setProcessor = (schema, ctx, json2, params) => {
    handleUnrepresentable(schema, ctx, json2, params, "Set cannot be represented in JSON Schema");
  };
  var arrayProcessor = (schema, ctx, _json, params) => {
    const json2 = _json;
    const def = schema._zod.def;
    const { minimum, maximum } = aggregateChecks(schema);
    if (typeof minimum === "number")
      json2.minItems = minimum;
    if (typeof maximum === "number")
      json2.maxItems = maximum;
    json2.type = "array";
    json2.items = processSchema(def.element, ctx, {
      ...params,
      path: [...params.path, "items"]
    });
  };
  function inputOptin(schema) {
    const def = schema._zod.def;
    if (def.type === "pipe" && def.in._zod.traits.has("$ZodTransform")) {
      return inputOptin(def.out);
    }
    if (def.type === "catch") {
      return inputOptin(def.innerType);
    }
    return schema._zod.optin;
  }
  var objectProcessor = (schema, ctx, _json, params) => {
    const json2 = _json;
    const def = schema._zod.def;
    const shape = def.shape;
    const symbolKeys = Object.getOwnPropertySymbols(shape);
    if (symbolKeys.length && handleUnrepresentable(schema, ctx, json2, params, "Symbol keys cannot be represented in JSON Schema")) {
      return;
    }
    json2.type = "object";
    json2.properties = {};
    for (const key6 in shape) {
      assignProp(json2.properties, key6, processSchema(shape[key6], ctx, {
        ...params,
        path: [...params.path, "properties", key6]
      }));
    }
    const requiredKeys = [];
    for (const key6 of Object.keys(shape)) {
      const field = def.shape[key6];
      if (ctx.io === "input" ? inputOptin(field) === void 0 : field._zod.optout === void 0) {
        requiredKeys.push(key6);
      }
    }
    if (requiredKeys.length > 0) {
      json2.required = requiredKeys;
    }
    if (def.catchall?._zod.def.type === "never") {
      json2.additionalProperties = false;
    } else if (!def.catchall) {
      if (ctx.io === "output")
        json2.additionalProperties = false;
    } else if (def.catchall) {
      json2.additionalProperties = processSchema(def.catchall, ctx, {
        ...params,
        path: [...params.path, "additionalProperties"]
      });
    }
  };
  var unionProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    const isExclusive = def.inclusive === false;
    const options = def.options.map((x, i) => processSchema(x, ctx, {
      ...params,
      path: [...params.path, isExclusive ? "oneOf" : "anyOf", i]
    }));
    if (isExclusive) {
      json2.oneOf = options;
    } else {
      json2.anyOf = options;
    }
  };
  var intersectionProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    const a = processSchema(def.left, ctx, {
      ...params,
      path: [...params.path, "allOf", 0]
    });
    const b = processSchema(def.right, ctx, {
      ...params,
      path: [...params.path, "allOf", 1]
    });
    const isSimpleIntersection = (val) => "allOf" in val && Object.keys(val).length === 1;
    const allOf = [
      ...isSimpleIntersection(a) ? a.allOf : [a],
      ...isSimpleIntersection(b) ? b.allOf : [b]
    ];
    json2.allOf = allOf;
    ctx.intersections.push(allOf);
  };
  var tupleProcessor = (schema, ctx, _json, params) => {
    const json2 = _json;
    const def = schema._zod.def;
    json2.type = "array";
    const prefixPath = ctx.target === "draft-2020-12" ? "prefixItems" : "items";
    const restPath = ctx.target === "draft-2020-12" ? "items" : ctx.target === "openapi-3.0" ? "items" : "additionalItems";
    const prefixItems = def.items.map((x, i) => processSchema(x, ctx, {
      ...params,
      path: [...params.path, prefixPath, i]
    }));
    const rest = def.rest ? processSchema(def.rest, ctx, {
      ...params,
      path: [...params.path, restPath, ...ctx.target === "openapi-3.0" ? [def.items.length] : []]
    }) : null;
    let minItems = def.items.length;
    while (minItems > 0) {
      const item = def.items[minItems - 1];
      const optional2 = ctx.io === "input" ? inputOptin(item) !== void 0 : item._zod.optout === "optional";
      if (!optional2)
        break;
      minItems--;
    }
    const maxItems = def.items.length;
    const isClosed = !def.rest;
    if (ctx.target === "draft-2020-12") {
      json2.prefixItems = prefixItems;
      if (isClosed) {
        json2.items = false;
      } else if (rest) {
        json2.items = rest;
      }
      if (minItems > 0)
        json2.minItems = minItems;
      if (isClosed)
        json2.maxItems = maxItems;
    } else if (ctx.target === "openapi-3.0") {
      json2.items = {
        anyOf: prefixItems
      };
      if (rest) {
        json2.items.anyOf.push(rest);
      }
      if (minItems > 0)
        json2.minItems = minItems;
      if (isClosed)
        json2.maxItems = maxItems;
    } else {
      json2.items = prefixItems;
      if (isClosed) {
        json2.additionalItems = false;
      } else if (rest) {
        json2.additionalItems = rest;
      }
      if (minItems > 0)
        json2.minItems = minItems;
      if (isClosed)
        json2.maxItems = maxItems;
    }
    const { minimum, maximum } = aggregateChecks(schema);
    if (typeof minimum === "number")
      json2.minItems = minimum;
    if (typeof maximum === "number")
      json2.maxItems = maximum;
  };
  function stringifyKeyNames(bySchema, json2, visited) {
    if (json2.$ref) {
      if (visited.has(json2))
        return json2;
      visited.add(json2);
      const def = bySchema.get(json2)?.def;
      if (!def)
        return json2;
      const inlined = stringifyKeyNames(bySchema, def, visited);
      return inlined === def ? json2 : inlined;
    }
    for (const keyword of ["anyOf", "oneOf"]) {
      const branches = json2[keyword];
      if (!Array.isArray(branches))
        continue;
      const mapped = branches.map((branch) => stringifyKeyNames(bySchema, branch, visited));
      if (mapped.some((branch, i) => branch !== branches[i]))
        json2 = { ...json2, [keyword]: mapped };
    }
    const types = Array.isArray(json2.type) ? json2.type : [json2.type];
    const numericType = !types.includes("string") && types.some((t) => t === "number" || t === "integer");
    const values = json2.enum ?? (json2.const !== void 0 ? [json2.const] : void 0);
    if (!numericType && !values?.some((v) => typeof v === "number"))
      return json2;
    const { minimum, maximum, exclusiveMinimum, exclusiveMaximum, multipleOf, format, id: id18, ...rest } = json2;
    if (rest.enum)
      rest.enum = rest.enum.map((v) => typeof v === "number" ? String(v) : v);
    else if (typeof rest.const === "number")
      rest.const = String(rest.const);
    if (!numericType)
      return rest;
    rest.type = "string";
    if (!values)
      rest.pattern = (types.includes("number") ? number : integer).source;
    return rest;
  }
  var pendingRecords = /* @__PURE__ */ new WeakMap();
  function rewriteKeyNames(ctx) {
    const bySchema = /* @__PURE__ */ new Map();
    for (const entry of ctx.seen.values()) {
      if (entry.def && !bySchema.has(entry.schema))
        bySchema.set(entry.schema, entry);
    }
    const rewrites = /* @__PURE__ */ new Map();
    for (const record2 of pendingRecords.get(ctx) ?? []) {
      const seen = ctx.seen.get(record2);
      const names = (seen?.def ?? seen?.schema)?.propertyNames;
      if (!names || names === true || rewrites.has(names))
        continue;
      const rewritten = stringifyKeyNames(bySchema, names, /* @__PURE__ */ new Set());
      if (rewritten !== names)
        rewrites.set(names, rewritten);
    }
    if (!rewrites.size)
      return;
    for (const entry of ctx.seen.values()) {
      for (const carrier of [entry.schema, entry.def]) {
        const rewritten = carrier && rewrites.get(carrier.propertyNames);
        if (rewritten)
          carrier.propertyNames = rewritten;
      }
    }
  }
  var recordProcessor = (schema, ctx, _json, params) => {
    const json2 = _json;
    const def = schema._zod.def;
    json2.type = "object";
    const keyType = def.keyType;
    const patterns = aggregateChecks(keyType).patterns;
    if (def.mode === "loose" && patterns && patterns.size > 0) {
      const valueSchema = processSchema(def.valueType, ctx, {
        ...params,
        path: [...params.path, "patternProperties", "*"]
      });
      json2.patternProperties = {};
      for (const pattern of patterns) {
        assignProp(json2.patternProperties, exactPattern(pattern).source, valueSchema);
      }
    } else {
      if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") {
        json2.propertyNames = processSchema(def.keyType, ctx, {
          ...params,
          path: [...params.path, "propertyNames"]
        });
        let pending = pendingRecords.get(ctx);
        if (!pending) {
          pending = [];
          pendingRecords.set(ctx, pending);
          ctx.deferred.push(() => rewriteKeyNames(ctx));
        }
        pending.push(schema);
      }
      json2.additionalProperties = processSchema(def.valueType, ctx, {
        ...params,
        path: [...params.path, "additionalProperties"]
      });
    }
    const keyValues = keyType._zod.values;
    const omittableOnInput = ctx.io === "input" && inputOptin(def.valueType) !== void 0;
    if (keyValues && !def.partial && !omittableOnInput) {
      const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
      if (validKeyValues.length > 0) {
        json2.required = validKeyValues.map(String);
      }
    }
  };
  var nullableProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    const inner = processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    if (ctx.target === "openapi-3.0") {
      seen.ref = def.innerType;
      json2.nullable = true;
    } else {
      json2.anyOf = [inner, { type: "null" }];
    }
  };
  var nonoptionalProcessor = (schema, ctx, _json, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
  };
  var UNREPRESENTABLE_DEFAULT = /* @__PURE__ */ Symbol();
  function serializeDefaultValue(value, schema, ctx, json2, params) {
    let unrepresentable = false;
    const serialized = JSON.stringify(value, (_, val) => {
      if (typeof val !== "bigint")
        return val;
      unrepresentable = true;
      return null;
    });
    if (!unrepresentable)
      return JSON.parse(serialized);
    handleUnrepresentable(schema, ctx, json2, params, "BigInt defaults cannot be represented in JSON Schema");
    return UNREPRESENTABLE_DEFAULT;
  }
  var defaultProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
    const value = serializeDefaultValue(def.defaultValue, schema, ctx, json2, params);
    if (value !== UNREPRESENTABLE_DEFAULT)
      json2.default = value;
  };
  var prefaultProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
    if (ctx.io !== "input")
      return;
    const value = serializeDefaultValue(def.defaultValue, schema, ctx, json2, params);
    if (value !== UNREPRESENTABLE_DEFAULT)
      json2._prefault = value;
  };
  var catchProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
    let catchValue;
    try {
      catchValue = def.catchValue(void 0);
    } catch {
      handleUnrepresentable(schema, ctx, json2, params, "Dynamic catch values are not supported in JSON Schema");
      return;
    }
    json2.default = catchValue;
  };
  var pipeProcessor = (schema, ctx, _json, params) => {
    const def = schema._zod.def;
    const inIsTransform = def.in._zod.traits.has("$ZodTransform");
    const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
    processSchema(innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = innerType;
  };
  var readonlyProcessor = (schema, ctx, json2, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
    json2.readOnly = true;
  };
  var promiseProcessor = (schema, ctx, _json, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
  };
  var optionalProcessor = (schema, ctx, _json, params) => {
    const def = schema._zod.def;
    processSchema(def.innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = def.innerType;
  };
  var lazyProcessor = (schema, ctx, _json, params) => {
    const innerType = schema._zod.innerType;
    processSchema(innerType, ctx, params);
    const seen = ctx.seen.get(schema);
    seen.ref = innerType;
  };
  var allProcessors = {
    string: stringProcessor,
    number: numberProcessor,
    boolean: booleanProcessor,
    bigint: bigintProcessor,
    symbol: symbolProcessor,
    null: nullProcessor,
    undefined: undefinedProcessor,
    void: voidProcessor,
    never: neverProcessor,
    any: anyProcessor,
    unknown: unknownProcessor,
    date: dateProcessor,
    enum: enumProcessor,
    literal: literalProcessor,
    nan: nanProcessor,
    template_literal: templateLiteralProcessor,
    file: fileProcessor,
    success: successProcessor,
    custom: customProcessor,
    function: functionProcessor,
    transform: transformProcessor,
    map: mapProcessor,
    set: setProcessor,
    array: arrayProcessor,
    object: objectProcessor,
    union: unionProcessor,
    intersection: intersectionProcessor,
    tuple: tupleProcessor,
    record: recordProcessor,
    nullable: nullableProcessor,
    nonoptional: nonoptionalProcessor,
    default: defaultProcessor,
    prefault: prefaultProcessor,
    catch: catchProcessor,
    pipe: pipeProcessor,
    readonly: readonlyProcessor,
    promise: promiseProcessor,
    optional: optionalProcessor,
    lazy: lazyProcessor
  };
  function toJSONSchema(input2, params) {
    if ("_idmap" in input2) {
      const registry2 = input2;
      const ctx2 = initializeContext({ ...params, processors: allProcessors });
      const defs = {};
      for (const entry of registry2._idmap.entries()) {
        const [_, schema] = entry;
        processSchema(schema, ctx2);
      }
      const schemas = {};
      const external = {
        registry: registry2,
        uri: params?.uri,
        defs
      };
      ctx2.external = external;
      for (const entry of registry2._idmap.entries()) {
        const [key6, schema] = entry;
        extractDefs(ctx2, schema);
        assignProp(schemas, key6, finalize(ctx2, schema));
      }
      if (Object.keys(defs).length > 0) {
        const defsSegment = ctx2.target === "draft-2020-12" ? "$defs" : "definitions";
        schemas.__shared = {
          [defsSegment]: defs
        };
      }
      return { schemas };
    }
    const ctx = initializeContext({ ...params, processors: allProcessors });
    processSchema(input2, ctx);
    extractDefs(ctx, input2);
    return finalize(ctx, input2);
  }

  // ../../../node_modules/zod/v4/core/json-schema-generator.js
  var JSONSchemaGenerator = class {
    /** @deprecated Access via ctx instead */
    get metadataRegistry() {
      return this.ctx.metadataRegistry;
    }
    /** @deprecated Access via ctx instead */
    get target() {
      return this.ctx.target;
    }
    // annotated so the .d.cts emits an indexed access rather than an inline `import()` of an ESM path
    /** @deprecated Access via ctx instead */
    get unrepresentable() {
      return this.ctx.unrepresentable;
    }
    /** @deprecated Access via ctx instead */
    get override() {
      return this.ctx.override;
    }
    /** @deprecated Access via ctx instead */
    get io() {
      return this.ctx.io;
    }
    /** @deprecated Access via ctx instead */
    get counter() {
      return this.ctx.counter;
    }
    set counter(value) {
      this.ctx.counter = value;
    }
    /** @deprecated Access via ctx instead */
    get seen() {
      return this.ctx.seen;
    }
    constructor(params) {
      let normalizedTarget = params?.target ?? "draft-2020-12";
      if (normalizedTarget === "draft-4")
        normalizedTarget = "draft-04";
      if (normalizedTarget === "draft-7")
        normalizedTarget = "draft-07";
      this.ctx = initializeContext({
        processors: allProcessors,
        target: normalizedTarget,
        ...params?.metadata && { metadata: params.metadata },
        ...params?.unrepresentable && { unrepresentable: params.unrepresentable },
        ...params?.override && { override: params.override },
        ...params?.io && { io: params.io }
      });
    }
    /**
     * Process a schema to prepare it for JSON Schema generation.
     * This must be called before emit().
     */
    process(schema, _params = { path: [], schemaPath: [] }) {
      return processSchema(schema, this.ctx, _params);
    }
    /**
     * Emit the final JSON Schema after processing.
     * Must call process() first.
     */
    emit(schema, _params) {
      if (_params) {
        if (_params.cycles)
          this.ctx.cycles = _params.cycles;
        if (_params.reused)
          this.ctx.reused = _params.reused;
        if (_params.external)
          this.ctx.external = _params.external;
      }
      this.ctx.sharedDefsExtractedFor = void 0;
      this.ctx.sharedEmitDoneFor = void 0;
      extractDefs(this.ctx, schema);
      const result = finalize(this.ctx, schema);
      const { "~standard": _, ...plainResult } = result;
      return plainResult;
    }
  };

  // ../../../node_modules/zod/v4/core/json-schema.js
  var json_schema_exports = {};

  // ../../../node_modules/zod/v4/classic/schemas.js
  var schemas_exports2 = {};
  __export(schemas_exports2, {
    ZodAny: () => ZodAny,
    ZodArray: () => ZodArray,
    ZodBase64: () => ZodBase64,
    ZodBase64URL: () => ZodBase64URL,
    ZodBigInt: () => ZodBigInt,
    ZodBigIntFormat: () => ZodBigIntFormat,
    ZodBoolean: () => ZodBoolean,
    ZodCIDRv4: () => ZodCIDRv4,
    ZodCIDRv6: () => ZodCIDRv6,
    ZodCUID: () => ZodCUID,
    ZodCUID2: () => ZodCUID2,
    ZodCatch: () => ZodCatch,
    ZodCodec: () => ZodCodec,
    ZodCreditCard: () => ZodCreditCard,
    ZodCustom: () => ZodCustom,
    ZodCustomStringFormat: () => ZodCustomStringFormat,
    ZodDate: () => ZodDate,
    ZodDefault: () => ZodDefault,
    ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
    ZodE164: () => ZodE164,
    ZodEmail: () => ZodEmail,
    ZodEmoji: () => ZodEmoji,
    ZodEnum: () => ZodEnum,
    ZodExactOptional: () => ZodExactOptional,
    ZodFile: () => ZodFile,
    ZodFunction: () => ZodFunction,
    ZodGUID: () => ZodGUID,
    ZodIBAN: () => ZodIBAN,
    ZodIPv4: () => ZodIPv4,
    ZodIPv6: () => ZodIPv6,
    ZodISODate: () => ZodISODate,
    ZodISODateTime: () => ZodISODateTime,
    ZodISODuration: () => ZodISODuration,
    ZodISOTime: () => ZodISOTime,
    ZodInstanceOf: () => ZodInstanceOf,
    ZodIntersection: () => ZodIntersection,
    ZodJWT: () => ZodJWT,
    ZodKSUID: () => ZodKSUID,
    ZodLazy: () => ZodLazy,
    ZodLiteral: () => ZodLiteral,
    ZodMAC: () => ZodMAC,
    ZodMap: () => ZodMap,
    ZodNaN: () => ZodNaN,
    ZodNanoID: () => ZodNanoID,
    ZodNever: () => ZodNever,
    ZodNonOptional: () => ZodNonOptional,
    ZodNull: () => ZodNull,
    ZodNullable: () => ZodNullable,
    ZodNumber: () => ZodNumber,
    ZodNumberFormat: () => ZodNumberFormat,
    ZodObject: () => ZodObject,
    ZodOptional: () => ZodOptional,
    ZodPipe: () => ZodPipe,
    ZodPrefault: () => ZodPrefault,
    ZodPreprocess: () => ZodPreprocess,
    ZodPromise: () => ZodPromise,
    ZodReadonly: () => ZodReadonly,
    ZodRecord: () => ZodRecord,
    ZodSet: () => ZodSet,
    ZodString: () => ZodString,
    ZodStringFormat: () => ZodStringFormat,
    ZodSuccess: () => ZodSuccess,
    ZodSymbol: () => ZodSymbol,
    ZodTemplateLiteral: () => ZodTemplateLiteral,
    ZodTransform: () => ZodTransform,
    ZodTuple: () => ZodTuple,
    ZodType: () => ZodType,
    ZodULID: () => ZodULID,
    ZodURL: () => ZodURL,
    ZodUUID: () => ZodUUID,
    ZodUndefined: () => ZodUndefined,
    ZodUnion: () => ZodUnion,
    ZodUnknown: () => ZodUnknown,
    ZodVoid: () => ZodVoid,
    ZodXID: () => ZodXID,
    ZodXor: () => ZodXor,
    _ZodString: () => _ZodString,
    _default: () => _default2,
    _function: () => _function,
    any: () => any,
    array: () => array,
    base64: () => base642,
    base64url: () => base64url2,
    bigint: () => bigint2,
    boolean: () => boolean2,
    catch: () => _catch2,
    check: () => check,
    cidrv4: () => cidrv42,
    cidrv6: () => cidrv62,
    codec: () => codec,
    creditCard: () => creditCard2,
    cuid: () => cuid3,
    cuid2: () => cuid22,
    currencyCode: () => currencyCode2,
    custom: () => custom,
    date: () => date2,
    describe: () => describe2,
    discriminatedUnion: () => discriminatedUnion,
    e164: () => e1642,
    email: () => email2,
    emoji: () => emoji2,
    enum: () => _enum2,
    exactOptional: () => exactOptional,
    file: () => file,
    float32: () => float32,
    float64: () => float64,
    function: () => _function,
    guid: () => guid2,
    hash: () => hash,
    hex: () => hex2,
    hostname: () => hostname2,
    httpUrl: () => httpUrl,
    iban: () => iban2,
    instanceof: () => _instanceof,
    int: () => int,
    int32: () => int32,
    int64: () => int64,
    intersection: () => intersection,
    invertCodec: () => invertCodec,
    ipv4: () => ipv42,
    ipv6: () => ipv62,
    json: () => json,
    jwt: () => jwt,
    keyof: () => keyof,
    ksuid: () => ksuid2,
    lazy: () => lazy,
    literal: () => literal,
    looseObject: () => looseObject,
    looseRecord: () => looseRecord,
    mac: () => mac2,
    map: () => map,
    meta: () => meta2,
    nan: () => nan,
    nanoid: () => nanoid2,
    nativeEnum: () => nativeEnum,
    never: () => never,
    nonoptional: () => nonoptional,
    null: () => _null3,
    nullable: () => nullable,
    nullish: () => nullish2,
    number: () => number2,
    object: () => object,
    optional: () => optional,
    partialRecord: () => partialRecord,
    pipe: () => pipe,
    prefault: () => prefault,
    preprocess: () => preprocess,
    promise: () => promise,
    readonly: () => readonly,
    record: () => record,
    refine: () => refine,
    set: () => set,
    strictObject: () => strictObject,
    string: () => string2,
    stringFormat: () => stringFormat,
    stringbool: () => stringbool,
    success: () => success,
    superRefine: () => superRefine,
    symbol: () => symbol,
    templateLiteral: () => templateLiteral,
    transform: () => transform,
    tuple: () => tuple,
    uint32: () => uint32,
    uint64: () => uint64,
    ulid: () => ulid2,
    undefined: () => _undefined3,
    union: () => union,
    unknown: () => unknown,
    url: () => url,
    uuid: () => uuid2,
    uuidv4: () => uuidv4,
    uuidv6: () => uuidv6,
    uuidv7: () => uuidv7,
    void: () => _void2,
    xid: () => xid2,
    xor: () => xor
  });

  // ../../../node_modules/zod/v4/classic/checks.js
  var checks_exports2 = {};
  __export(checks_exports2, {
    endsWith: () => _endsWith,
    gt: () => _gt,
    gte: () => _gte,
    includes: () => _includes,
    length: () => _length,
    lowercase: () => _lowercase,
    lt: () => _lt,
    lte: () => _lte,
    maxLength: () => _maxLength,
    maxSize: () => _maxSize,
    mime: () => _mime,
    minLength: () => _minLength,
    minSize: () => _minSize,
    multipleOf: () => _multipleOf,
    negative: () => _negative,
    nonnegative: () => _nonnegative,
    nonpositive: () => _nonpositive,
    normalize: () => _normalize,
    overwrite: () => _overwrite,
    positive: () => _positive,
    properties: () => _properties,
    property: () => _property,
    regex: () => _regex,
    size: () => _size,
    slugify: () => _slugify,
    startsWith: () => _startsWith,
    toLowerCase: () => _toLowerCase,
    toUpperCase: () => _toUpperCase,
    trim: () => _trim,
    uppercase: () => _uppercase
  });

  // ../../../node_modules/zod/v4/classic/errors.js
  var _installedErrorProtos = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
  function _lazyMethod(proto, key6, make) {
    Object.defineProperty(proto, key6, {
      configurable: true,
      enumerable: false,
      get() {
        const value = make(this);
        Object.defineProperty(this, key6, { value, configurable: true, writable: true });
        return value;
      },
      set(value) {
        Object.defineProperty(this, key6, { value, configurable: true, writable: true });
      }
    });
  }
  var initializer2 = (inst, issues) => {
    $ZodError.init(inst, issues);
    inst.name = "ZodError";
    const proto = Object.getPrototypeOf(inst);
    if (_installedErrorProtos.has(proto))
      return;
    _installedErrorProtos.add(proto);
    _lazyMethod(proto, "format", (self) => (mapper) => formatError(self, mapper));
    _lazyMethod(proto, "flatten", (self) => (mapper) => flattenError(self, mapper));
    _lazyMethod(proto, "addIssue", (self) => (issue3) => {
      self.issues.push(issue3);
      self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
    });
    _lazyMethod(proto, "addIssues", (self) => (issues2) => {
      self.issues.push(...issues2);
      self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
    });
    Object.defineProperty(proto, "isEmpty", {
      configurable: true,
      enumerable: false,
      get() {
        return this.issues.length === 0;
      }
    });
  };
  var ZodError = /* @__PURE__ */ $constructor("ZodError", initializer2);
  var ZodRealError = /* @__PURE__ */ $constructor("ZodError", initializer2, void 0, {
    Parent: Error
  });

  // ../../../node_modules/zod/v4/classic/parse.js
  var parse2 = /* @__PURE__ */ _parse(ZodRealError);
  var parseAsync2 = /* @__PURE__ */ _parseAsync(ZodRealError);
  var safeParse2 = /* @__PURE__ */ _safeParse(ZodRealError);
  var safeParseAsync2 = /* @__PURE__ */ _safeParseAsync(ZodRealError);
  var encode2 = /* @__PURE__ */ _encode(ZodRealError);
  var decode2 = /* @__PURE__ */ _decode(ZodRealError);
  var encodeAsync2 = /* @__PURE__ */ _encodeAsync(ZodRealError);
  var decodeAsync2 = /* @__PURE__ */ _decodeAsync(ZodRealError);
  var safeEncode2 = /* @__PURE__ */ _safeEncode(ZodRealError);
  var safeDecode2 = /* @__PURE__ */ _safeDecode(ZodRealError);
  var safeEncodeAsync2 = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
  var safeDecodeAsync2 = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);

  // ../../../node_modules/zod/v4/classic/schemas.js
  function _ensureDefaultLocale() {
    if (!globalConfig.localeError)
      config(en_default());
  }
  function _ensureDefaultMemoizer() {
    if (!globalConfig.memoizer)
      config({ memoizer: memoizer() });
  }
  var ZodType = /* @__PURE__ */ $constructor("ZodType", (inst, def) => {
    _ensureDefaultLocale();
    $ZodType.init(inst, def);
    inst.def = def;
    inst.type = def.type;
    return inst;
  }, {
    check(...chks) {
      const def = this.def;
      return this.clone(util_exports.mergeDefs(def, {
        checks: [
          ...def.checks ?? [],
          ...chks.map((ch) => typeof ch === "function" ? { _zod: { check: ch, def: { check: "custom" }, onattach: [] } } : ch)
        ]
      }), { parent: true });
    },
    with(...chks) {
      return this.check(...chks);
    },
    clone(def, params) {
      return clone(this, def, params);
    },
    brand() {
      return this;
    },
    register(reg, meta3) {
      reg.add(this, meta3);
      return this;
    },
    refine(check2, params) {
      return this.check(refine(check2, params));
    },
    superRefine(refinement, params) {
      return this.check(superRefine(refinement, params));
    },
    overwrite(fn) {
      return this.check(_overwrite(fn));
    },
    optional() {
      return optional(this);
    },
    exactOptional() {
      return exactOptional(this);
    },
    nullable() {
      return nullable(this);
    },
    nullish() {
      return optional(nullable(this));
    },
    nonoptional(params) {
      return nonoptional(this, params);
    },
    array() {
      return array(this);
    },
    or(arg) {
      return union([this, arg]);
    },
    and(arg) {
      return intersection(this, arg);
    },
    transform(tx) {
      return pipe(this, transform(tx));
    },
    default(d) {
      return _default2(this, d);
    },
    prefault(d) {
      return prefault(this, d);
    },
    catch(params) {
      return _catch2(this, params);
    },
    pipe(target3) {
      return pipe(this, target3);
    },
    readonly() {
      return readonly(this);
    },
    describe(description) {
      const cl = this.clone();
      globalRegistry.add(cl, { description });
      return cl;
    },
    meta(...args) {
      if (args.length === 0)
        return globalRegistry.get(this);
      const cl = this.clone();
      globalRegistry.add(cl, args[0]);
      return cl;
    },
    isOptional() {
      return this.safeParse(void 0).success;
    },
    isNullable() {
      return this.safeParse(null).success;
    },
    apply(fn, ...args) {
      return args.length === 0 ? fn(this) : fn(this, ...args);
    },
    // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
    get "~standard"() {
      return util_exports.hide(this, "~standard", {
        ...standardProps(this),
        jsonSchema: {
          input: createStandardJSONSchemaMethod(this, "input"),
          output: createStandardJSONSchemaMethod(this, "output")
        }
      });
    },
    set "~standard"(value) {
      util_exports.own(this, "~standard", value);
    },
    parse: function _parse2(data, params) {
      return parse2(this, data, params, { callee: _parse2 });
    },
    parseAsync: async function _parseAsync2(data, params) {
      return await parseAsync2(this, data, params, { callee: _parseAsync2 });
    },
    safeParse(data, params) {
      return safeParse2(this, data, params);
    },
    async safeParseAsync(data, params) {
      return safeParseAsync2(this, data, params);
    },
    // `spa` is an alias: same function object as `safeParseAsync`, as before.
    get spa() {
      return this?.safeParseAsync;
    },
    set spa(value) {
      util_exports.own(this, "spa", value);
    },
    validate(data, params) {
      return validate(this, data, params);
    },
    validateAsync(data, params) {
      return validateAsync(this, data, params);
    },
    encode: function _encode2(data, params) {
      return encode2(this, data, params, { callee: _encode2 });
    },
    decode: function _decode2(data, params) {
      return decode2(this, data, params, { callee: _decode2 });
    },
    encodeAsync: async function _encodeAsync2(data, params) {
      return await encodeAsync2(this, data, params, { callee: _encodeAsync2 });
    },
    decodeAsync: async function _decodeAsync2(data, params) {
      return await decodeAsync2(this, data, params, { callee: _decodeAsync2 });
    },
    safeEncode(data, params) {
      return safeEncode2(this, data, params);
    },
    safeDecode(data, params) {
      return safeDecode2(this, data, params);
    },
    async safeEncodeAsync(data, params) {
      return safeEncodeAsync2(this, data, params);
    },
    async safeDecodeAsync(data, params) {
      return safeDecodeAsync2(this, data, params);
    },
    toJSONSchema(params) {
      return createToJSONSchemaMethod(this, {})(params);
    },
    // Reads through to the registry on every access, so it must not cache.
    get description() {
      return globalRegistry.get(this)?.description;
    },
    // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
    get _def() {
      return this._zod.def;
    }
  });
  var _ZodString = /* @__PURE__ */ $constructor(
    "_ZodString",
    (inst, def) => {
      $ZodString.init(inst, def);
      ZodType.init(inst, def);
      inst._zod.processJSONSchema = (ctx, json2, params) => stringProcessor(inst, ctx, json2, params);
    },
    /* @__PURE__ */ util_exports.derived({
      format: (inst) => aggregateChecks(inst).format ?? null,
      minLength: (inst) => aggregateChecks(inst).minimum ?? null,
      maxLength: (inst) => aggregateChecks(inst).maximum ?? null
    }, {
      regex(...args) {
        return this.check(_regex(...args));
      },
      includes(...args) {
        return this.check(_includes(...args));
      },
      startsWith(...args) {
        return this.check(_startsWith(...args));
      },
      endsWith(...args) {
        return this.check(_endsWith(...args));
      },
      min(...args) {
        return this.check(_minLength(...args));
      },
      max(...args) {
        return this.check(_maxLength(...args));
      },
      length(...args) {
        return this.check(_length(...args));
      },
      nonempty(...args) {
        return this.check(_minLength(1, ...args));
      },
      lowercase(params) {
        return this.check(_lowercase(params));
      },
      uppercase(params) {
        return this.check(_uppercase(params));
      },
      trim() {
        return this.check(_trim());
      },
      normalize(...args) {
        return this.check(_normalize(...args));
      },
      toLowerCase() {
        return this.check(_toLowerCase());
      },
      toUpperCase() {
        return this.check(_toUpperCase());
      },
      slugify() {
        return this.check(_slugify());
      }
    })
  );
  var ZodString = /* @__PURE__ */ $constructor("ZodString", (inst, def) => {
    $ZodString.init(inst, def);
    _ZodString.init(inst, def);
  }, {
    email(params) {
      return this.check(_email(ZodEmail, params));
    },
    url(params) {
      return this.check(_url(ZodURL, params));
    },
    jwt(params) {
      return this.check(_jwt(ZodJWT, params));
    },
    emoji(params) {
      return this.check(_emoji2(ZodEmoji, params));
    },
    guid(params) {
      return this.check(_guid(ZodGUID, params));
    },
    uuid(params) {
      return this.check(_uuid(ZodUUID, params));
    },
    uuidv4(params) {
      return this.check(_uuidv4(ZodUUID, params));
    },
    uuidv6(params) {
      return this.check(_uuidv6(ZodUUID, params));
    },
    uuidv7(params) {
      return this.check(_uuidv7(ZodUUID, params));
    },
    nanoid(params) {
      return this.check(_nanoid(ZodNanoID, params));
    },
    cuid(params) {
      return this.check(_cuid(ZodCUID, params));
    },
    cuid2(params) {
      return this.check(_cuid2(ZodCUID2, params));
    },
    ulid(params) {
      return this.check(_ulid(ZodULID, params));
    },
    base64(params) {
      return this.check(_base64(ZodBase64, params));
    },
    base64url(params) {
      return this.check(_base64url(ZodBase64URL, params));
    },
    xid(params) {
      return this.check(_xid(ZodXID, params));
    },
    ksuid(params) {
      return this.check(_ksuid(ZodKSUID, params));
    },
    ipv4(params) {
      return this.check(_ipv4(ZodIPv4, params));
    },
    ipv6(params) {
      return this.check(_ipv6(ZodIPv6, params));
    },
    cidrv4(params) {
      return this.check(_cidrv4(ZodCIDRv4, params));
    },
    cidrv6(params) {
      return this.check(_cidrv6(ZodCIDRv6, params));
    },
    e164(params) {
      return this.check(_e164(ZodE164, params));
    },
    datetime(params) {
      return this.check(_isoDateTime(ZodISODateTime, params));
    },
    date(params) {
      return this.check(_isoDate(ZodISODate, params));
    },
    time(params) {
      return this.check(_isoTime(ZodISOTime, params));
    },
    duration(params) {
      return this.check(_isoDuration(ZodISODuration, params));
    }
  });
  function string2(params) {
    return _string(ZodString, params);
  }
  var ZodStringFormat = /* @__PURE__ */ $constructor("ZodStringFormat", (inst, def) => {
    $ZodStringFormat.init(inst, def);
    _ZodString.init(inst, def);
  });
  var ZodISODateTime = /* @__PURE__ */ $constructor("ZodISODateTime", (inst, def) => {
    $ZodISODateTime.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  var ZodISODate = /* @__PURE__ */ $constructor("ZodISODate", (inst, def) => {
    $ZodISODate.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  var ZodISOTime = /* @__PURE__ */ $constructor("ZodISOTime", (inst, def) => {
    $ZodISOTime.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  var ZodISODuration = /* @__PURE__ */ $constructor("ZodISODuration", (inst, def) => {
    $ZodISODuration.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  var ZodEmail = /* @__PURE__ */ $constructor("ZodEmail", (inst, def) => {
    $ZodEmail.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function email2(params) {
    return _email(ZodEmail, params);
  }
  var ZodGUID = /* @__PURE__ */ $constructor("ZodGUID", (inst, def) => {
    $ZodGUID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function guid2(params) {
    return _guid(ZodGUID, params);
  }
  var ZodUUID = /* @__PURE__ */ $constructor("ZodUUID", (inst, def) => {
    $ZodUUID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function uuid2(params) {
    return _uuid(ZodUUID, params);
  }
  function uuidv4(params) {
    return _uuidv4(ZodUUID, params);
  }
  function uuidv6(params) {
    return _uuidv6(ZodUUID, params);
  }
  function uuidv7(params) {
    return _uuidv7(ZodUUID, params);
  }
  var ZodURL = /* @__PURE__ */ $constructor("ZodURL", (inst, def) => {
    $ZodURL.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function url(params) {
    return _url(ZodURL, params);
  }
  function httpUrl(params) {
    return _url(ZodURL, {
      protocol: httpProtocol,
      hostname: domain,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodEmoji = /* @__PURE__ */ $constructor("ZodEmoji", (inst, def) => {
    $ZodEmoji.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function emoji2(params) {
    return _emoji2(ZodEmoji, params);
  }
  var ZodNanoID = /* @__PURE__ */ $constructor("ZodNanoID", (inst, def) => {
    $ZodNanoID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function nanoid2(params) {
    return _nanoid(ZodNanoID, params);
  }
  var ZodCUID = /* @__PURE__ */ $constructor("ZodCUID", (inst, def) => {
    $ZodCUID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function cuid3(params) {
    return _cuid(ZodCUID, params);
  }
  var ZodCUID2 = /* @__PURE__ */ $constructor("ZodCUID2", (inst, def) => {
    $ZodCUID2.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function cuid22(params) {
    return _cuid2(ZodCUID2, params);
  }
  var ZodULID = /* @__PURE__ */ $constructor("ZodULID", (inst, def) => {
    $ZodULID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function ulid2(params) {
    return _ulid(ZodULID, params);
  }
  var ZodXID = /* @__PURE__ */ $constructor("ZodXID", (inst, def) => {
    $ZodXID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function xid2(params) {
    return _xid(ZodXID, params);
  }
  var ZodKSUID = /* @__PURE__ */ $constructor("ZodKSUID", (inst, def) => {
    $ZodKSUID.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function ksuid2(params) {
    return _ksuid(ZodKSUID, params);
  }
  var ZodIPv4 = /* @__PURE__ */ $constructor("ZodIPv4", (inst, def) => {
    $ZodIPv4.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function ipv42(params) {
    return _ipv4(ZodIPv4, params);
  }
  var ZodMAC = /* @__PURE__ */ $constructor("ZodMAC", (inst, def) => {
    $ZodMAC.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function mac2(params) {
    return _mac(ZodMAC, params);
  }
  var ZodIPv6 = /* @__PURE__ */ $constructor("ZodIPv6", (inst, def) => {
    $ZodIPv6.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function ipv62(params) {
    return _ipv6(ZodIPv6, params);
  }
  var ZodCIDRv4 = /* @__PURE__ */ $constructor("ZodCIDRv4", (inst, def) => {
    $ZodCIDRv4.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function cidrv42(params) {
    return _cidrv4(ZodCIDRv4, params);
  }
  var ZodCIDRv6 = /* @__PURE__ */ $constructor("ZodCIDRv6", (inst, def) => {
    $ZodCIDRv6.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function cidrv62(params) {
    return _cidrv6(ZodCIDRv6, params);
  }
  var ZodBase64 = /* @__PURE__ */ $constructor("ZodBase64", (inst, def) => {
    $ZodBase64.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function base642(params) {
    return _base64(ZodBase64, params);
  }
  var ZodBase64URL = /* @__PURE__ */ $constructor("ZodBase64URL", (inst, def) => {
    $ZodBase64URL.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function base64url2(params) {
    return _base64url(ZodBase64URL, params);
  }
  var ZodE164 = /* @__PURE__ */ $constructor("ZodE164", (inst, def) => {
    $ZodE164.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function e1642(params) {
    return _e164(ZodE164, params);
  }
  var ZodCreditCard = /* @__PURE__ */ $constructor("ZodCreditCard", (inst, def) => {
    $ZodCreditCard.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function creditCard2(params) {
    return _creditCard(ZodCreditCard, params);
  }
  var ZodIBAN = /* @__PURE__ */ $constructor("ZodIBAN", (inst, def) => {
    $ZodIBAN.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function iban2(params) {
    return _iban(ZodIBAN, params);
  }
  var ZodJWT = /* @__PURE__ */ $constructor("ZodJWT", (inst, def) => {
    $ZodJWT.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function jwt(params) {
    return _jwt(ZodJWT, params);
  }
  var ZodCustomStringFormat = /* @__PURE__ */ $constructor("ZodCustomStringFormat", (inst, def) => {
    $ZodCustomStringFormat.init(inst, def);
    ZodStringFormat.init(inst, def);
  });
  function stringFormat(format, fnOrRegex, _params = {}) {
    return _stringFormat(ZodCustomStringFormat, format, fnOrRegex, _params);
  }
  function hostname2(_params) {
    return _stringFormat(ZodCustomStringFormat, "hostname", hostname, _params);
  }
  function hex2(_params) {
    return _stringFormat(ZodCustomStringFormat, "hex", hex, _params);
  }
  function currencyCode2(_params) {
    return _stringFormat(ZodCustomStringFormat, "currency_code", currencyCode, _params);
  }
  function hash(alg, params) {
    const enc = params?.enc ?? "hex";
    const format = `${alg}_${enc}`;
    const regex = regexes_exports[format];
    if (!regex)
      throw new Error(`Unrecognized hash format: ${format}`);
    return _stringFormat(ZodCustomStringFormat, format, regex, params);
  }
  var ZodNumber = /* @__PURE__ */ $constructor(
    "ZodNumber",
    (inst, def) => {
      $ZodNumber.init(inst, def);
      ZodType.init(inst, def);
      inst._zod.processJSONSchema = (ctx, json2, params) => numberProcessor(inst, ctx, json2, params);
      inst.isFinite = true;
    },
    /* @__PURE__ */ util_exports.derived({
      minValue: (inst) => {
        const { minimum, exclusiveMinimum } = aggregateChecks(inst);
        return Math.max(minimum ?? Number.NEGATIVE_INFINITY, exclusiveMinimum ?? Number.NEGATIVE_INFINITY);
      },
      maxValue: (inst) => {
        const { maximum, exclusiveMaximum } = aggregateChecks(inst);
        return Math.min(maximum ?? Number.POSITIVE_INFINITY, exclusiveMaximum ?? Number.POSITIVE_INFINITY);
      },
      isInt: (inst) => {
        const { isInt, multipleOf } = aggregateChecks(inst);
        return !!isInt || !!multipleOf?.some(Number.isSafeInteger);
      },
      format: (inst) => aggregateChecks(inst).format ?? null
    }, {
      gt(value, params) {
        return this.check(_gt(value, params));
      },
      gte(value, params) {
        return this.check(_gte(value, params));
      },
      min(value, params) {
        return this.check(_gte(value, params));
      },
      lt(value, params) {
        return this.check(_lt(value, params));
      },
      lte(value, params) {
        return this.check(_lte(value, params));
      },
      max(value, params) {
        return this.check(_lte(value, params));
      },
      int(params) {
        return this.check(int(params));
      },
      safe(params) {
        return this.check(int(params));
      },
      positive(params) {
        return this.check(_gt(0, params));
      },
      nonnegative(params) {
        return this.check(_gte(0, params));
      },
      negative(params) {
        return this.check(_lt(0, params));
      },
      nonpositive(params) {
        return this.check(_lte(0, params));
      },
      multipleOf(value, params) {
        return this.check(_multipleOf(value, params));
      },
      step(value, params) {
        return this.check(_multipleOf(value, params));
      },
      finite() {
        return this;
      }
    })
  );
  function number2(params) {
    return _number(ZodNumber, params);
  }
  var ZodNumberFormat = /* @__PURE__ */ $constructor("ZodNumberFormat", (inst, def) => {
    $ZodNumberFormat.init(inst, def);
    ZodNumber.init(inst, def);
  });
  function int(params) {
    return _int(ZodNumberFormat, params);
  }
  function float32(params) {
    return _float32(ZodNumberFormat, params);
  }
  function float64(params) {
    return _float64(ZodNumberFormat, params);
  }
  function int32(params) {
    return _int32(ZodNumberFormat, params);
  }
  function uint32(params) {
    return _uint32(ZodNumberFormat, params);
  }
  var ZodBoolean = /* @__PURE__ */ $constructor("ZodBoolean", (inst, def) => {
    $ZodBoolean.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => booleanProcessor(inst, ctx, json2, params);
  });
  function boolean2(params) {
    return _boolean(ZodBoolean, params);
  }
  var ZodBigInt = /* @__PURE__ */ $constructor(
    "ZodBigInt",
    (inst, def) => {
      $ZodBigInt.init(inst, def);
      ZodType.init(inst, def);
      inst._zod.processJSONSchema = (ctx, json2, params) => bigintProcessor(inst, ctx, json2, params);
    },
    /* @__PURE__ */ util_exports.derived({
      minValue: (inst) => aggregateChecks(inst).minimum ?? null,
      maxValue: (inst) => aggregateChecks(inst).maximum ?? null,
      format: (inst) => aggregateChecks(inst).format ?? null
    }, {
      gte(value, params) {
        return this.check(_gte(value, params));
      },
      min(value, params) {
        return this.check(_gte(value, params));
      },
      gt(value, params) {
        return this.check(_gt(value, params));
      },
      lt(value, params) {
        return this.check(_lt(value, params));
      },
      lte(value, params) {
        return this.check(_lte(value, params));
      },
      max(value, params) {
        return this.check(_lte(value, params));
      },
      positive(params) {
        return this.check(_gt(BigInt(0), params));
      },
      negative(params) {
        return this.check(_lt(BigInt(0), params));
      },
      nonpositive(params) {
        return this.check(_lte(BigInt(0), params));
      },
      nonnegative(params) {
        return this.check(_gte(BigInt(0), params));
      },
      multipleOf(value, params) {
        return this.check(_multipleOf(value, params));
      }
    })
  );
  function bigint2(params) {
    return _bigint(ZodBigInt, params);
  }
  var ZodBigIntFormat = /* @__PURE__ */ $constructor("ZodBigIntFormat", (inst, def) => {
    $ZodBigIntFormat.init(inst, def);
    ZodBigInt.init(inst, def);
  });
  function int64(params) {
    return _int64(ZodBigIntFormat, params);
  }
  function uint64(params) {
    return _uint64(ZodBigIntFormat, params);
  }
  var ZodSymbol = /* @__PURE__ */ $constructor("ZodSymbol", (inst, def) => {
    $ZodSymbol.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => symbolProcessor(inst, ctx, json2, params);
  });
  function symbol(params) {
    return _symbol(ZodSymbol, params);
  }
  var ZodUndefined = /* @__PURE__ */ $constructor("ZodUndefined", (inst, def) => {
    $ZodUndefined.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => undefinedProcessor(inst, ctx, json2, params);
  });
  function _undefined3(params) {
    return _undefined2(ZodUndefined, params);
  }
  var ZodNull = /* @__PURE__ */ $constructor("ZodNull", (inst, def) => {
    $ZodNull.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => nullProcessor(inst, ctx, json2, params);
  });
  function _null3(params) {
    return _null2(ZodNull, params);
  }
  var ZodAny = /* @__PURE__ */ $constructor("ZodAny", (inst, def) => {
    $ZodAny.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => anyProcessor(inst, ctx, json2, params);
  });
  function any() {
    return _any(ZodAny);
  }
  var ZodUnknown = /* @__PURE__ */ $constructor("ZodUnknown", (inst, def) => {
    $ZodUnknown.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => unknownProcessor(inst, ctx, json2, params);
  });
  function unknown() {
    return _unknown(ZodUnknown);
  }
  var ZodNever = /* @__PURE__ */ $constructor("ZodNever", (inst, def) => {
    $ZodNever.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => neverProcessor(inst, ctx, json2, params);
  });
  function never(params) {
    return _never(ZodNever, params);
  }
  var ZodVoid = /* @__PURE__ */ $constructor("ZodVoid", (inst, def) => {
    $ZodVoid.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => voidProcessor(inst, ctx, json2, params);
  });
  function _void2(params) {
    return _void(ZodVoid, params);
  }
  var ZodDate = /* @__PURE__ */ $constructor(
    "ZodDate",
    (inst, def) => {
      $ZodDate.init(inst, def);
      ZodType.init(inst, def);
      inst._zod.processJSONSchema = (ctx, json2, params) => dateProcessor(inst, ctx, json2, params);
      inst.min = (value, params) => inst.check(_gte(value, params));
      inst.max = (value, params) => inst.check(_lte(value, params));
    },
    /* @__PURE__ */ util_exports.derived({
      minDate: (inst) => {
        const { minimum } = aggregateChecks(inst);
        return minimum ? new Date(minimum) : null;
      },
      maxDate: (inst) => {
        const { maximum } = aggregateChecks(inst);
        return maximum ? new Date(maximum) : null;
      }
    }, {})
  );
  function date2(params) {
    return _date(ZodDate, params);
  }
  var ZodArray = /* @__PURE__ */ $constructor("ZodArray", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodArray.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => arrayProcessor(inst, ctx, json2, params);
    inst.element = def.element;
  }, {
    min(n, params) {
      return this.check(_minLength(n, params));
    },
    nonempty(params) {
      return this.check(_minLength(1, params));
    },
    max(n, params) {
      return this.check(_maxLength(n, params));
    },
    length(n, params) {
      return this.check(_length(n, params));
    },
    unwrap() {
      return this.element;
    }
  });
  function array(element, params) {
    return _array(ZodArray, element, params);
  }
  function keyof(schema) {
    const shape = schema._zod.def.shape;
    return _enum2(Object.keys(shape));
  }
  var ZodObject = /* @__PURE__ */ $constructor("ZodObject", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodObjectJIT.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => objectProcessor(inst, ctx, json2, params);
    util_exports.installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
  }, {
    keyof() {
      return _enum2(Object.keys(this._zod.def.shape));
    },
    catchall(catchall) {
      return this.clone(util_exports.mergeDefs(this._zod.def, { catchall }));
    },
    passthrough() {
      return this.clone(util_exports.mergeDefs(this._zod.def, { catchall: unknown() }));
    },
    loose() {
      return this.clone(util_exports.mergeDefs(this._zod.def, { catchall: unknown() }));
    },
    strict() {
      return this.clone(util_exports.mergeDefs(this._zod.def, { catchall: never() }));
    },
    strip() {
      return this.clone(util_exports.mergeDefs(this._zod.def, { catchall: void 0 }));
    },
    extend(incoming) {
      return util_exports.extend(this, incoming);
    },
    safeExtend(incoming) {
      return util_exports.safeExtend(this, incoming);
    },
    merge(other) {
      return util_exports.merge(this, other);
    },
    pick(mask) {
      return util_exports.pick(this, mask);
    },
    omit(mask) {
      return util_exports.omit(this, mask);
    },
    partial(...args) {
      return util_exports.partial(ZodOptional, this, args[0]);
    },
    exactPartial(...args) {
      return util_exports.partial(ZodExactOptional, this, args[0], "exactPartial");
    },
    required(...args) {
      return util_exports.required(ZodNonOptional, this, args[0]);
    }
  });
  function object(shape, params) {
    const def = {
      type: "object",
      shape: shape ?? {},
      ...util_exports.normalizeParams(params)
    };
    return new ZodObject(def);
  }
  function strictObject(shape, params) {
    return new ZodObject({
      type: "object",
      shape,
      catchall: never(),
      ...util_exports.normalizeParams(params)
    });
  }
  function looseObject(shape, params) {
    return new ZodObject({
      type: "object",
      shape,
      catchall: unknown(),
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodUnion = /* @__PURE__ */ $constructor("ZodUnion", (inst, def) => {
    $ZodUnion.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => unionProcessor(inst, ctx, json2, params);
    inst.options = def.options;
  });
  function union(options, params) {
    return new ZodUnion({
      type: "union",
      options,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodXor = /* @__PURE__ */ $constructor("ZodXor", (inst, def) => {
    ZodUnion.init(inst, def);
    $ZodXor.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => unionProcessor(inst, ctx, json2, params);
    inst.options = def.options;
  });
  function xor(options, params) {
    return new ZodXor({
      type: "union",
      options,
      inclusive: false,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("ZodDiscriminatedUnion", (inst, def) => {
    ZodUnion.init(inst, def);
    $ZodDiscriminatedUnion.init(inst, def);
  });
  function discriminatedUnion(discriminator, options, params) {
    return new ZodDiscriminatedUnion({
      type: "union",
      options,
      discriminator,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodIntersection = /* @__PURE__ */ $constructor("ZodIntersection", (inst, def) => {
    $ZodIntersection.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => intersectionProcessor(inst, ctx, json2, params);
  });
  function intersection(left, right) {
    return new ZodIntersection({
      type: "intersection",
      left,
      right
    });
  }
  var ZodTuple = /* @__PURE__ */ $constructor("ZodTuple", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodTuple.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => tupleProcessor(inst, ctx, json2, params);
  }, {
    rest(rest) {
      return this.clone({
        ...this._zod.def,
        rest
      });
    },
    partial() {
      const def = this._zod.def;
      if (def.checks?.length)
        throw new Error(".partial() cannot be used on tuple schemas containing refinements");
      return this.clone({
        ...def,
        items: def.items.map((item) => new ZodOptional({ type: "optional", innerType: item }))
      });
    }
  });
  function tuple(items, _paramsOrRest, _params) {
    const hasRest = _paramsOrRest instanceof $ZodType;
    const params = hasRest ? _params : _paramsOrRest;
    const rest = hasRest ? _paramsOrRest : null;
    return new ZodTuple({
      type: "tuple",
      items,
      rest,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodRecord = /* @__PURE__ */ $constructor("ZodRecord", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodRecord.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => recordProcessor(inst, ctx, json2, params);
    inst.keyType = def.keyType;
    inst.valueType = def.valueType;
  });
  function record(keyType, valueType, params) {
    if (!valueType || !valueType._zod) {
      return new ZodRecord({
        type: "record",
        keyType: string2(),
        valueType: keyType,
        ...util_exports.normalizeParams(valueType)
      });
    }
    return new ZodRecord({
      type: "record",
      keyType,
      valueType,
      ...util_exports.normalizeParams(params)
    });
  }
  function partialRecord(keyType, valueType, params) {
    return new ZodRecord({
      type: "record",
      keyType,
      valueType,
      ...util_exports.normalizeParams(params),
      partial: true
    });
  }
  function looseRecord(keyType, valueType, params) {
    return new ZodRecord({
      type: "record",
      keyType,
      valueType,
      mode: "loose",
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodMap = /* @__PURE__ */ $constructor("ZodMap", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodMap.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => mapProcessor(inst, ctx, json2, params);
    inst.keyType = def.keyType;
    inst.valueType = def.valueType;
    inst.min = (...args) => inst.check(_minSize(...args));
    inst.nonempty = (params) => inst.check(_minSize(1, params));
    inst.max = (...args) => inst.check(_maxSize(...args));
    inst.size = (...args) => inst.check(_size(...args));
  });
  function map(keyType, valueType, params) {
    return new ZodMap({
      type: "map",
      keyType,
      valueType,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodSet = /* @__PURE__ */ $constructor("ZodSet", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodSet.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => setProcessor(inst, ctx, json2, params);
    inst.min = (...args) => inst.check(_minSize(...args));
    inst.nonempty = (params) => inst.check(_minSize(1, params));
    inst.max = (...args) => inst.check(_maxSize(...args));
    inst.size = (...args) => inst.check(_size(...args));
  });
  function set(valueType, params) {
    return new ZodSet({
      type: "set",
      valueType,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodEnum = /* @__PURE__ */ $constructor("ZodEnum", (inst, def) => {
    $ZodEnum.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => enumProcessor(inst, ctx, json2, params);
    inst.enum = def.entries;
    inst.options = [...inst._zod.values];
    const keys = new Set(Object.keys(def.entries));
    inst.extract = (values, params) => {
      const newEntries = {};
      for (const value of values) {
        if (keys.has(value)) {
          newEntries[value] = def.entries[value];
        } else
          throw new Error(`Key ${value} not found in enum`);
      }
      return new ZodEnum({
        ...def,
        checks: [],
        ...util_exports.normalizeParams(params),
        entries: newEntries
      });
    };
    inst.exclude = (values, params) => {
      const newEntries = { ...def.entries };
      for (const value of values) {
        if (keys.has(value)) {
          delete newEntries[value];
        } else
          throw new Error(`Key ${value} not found in enum`);
      }
      return new ZodEnum({
        ...def,
        checks: [],
        ...util_exports.normalizeParams(params),
        entries: newEntries
      });
    };
  });
  function _enum2(values, params) {
    const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
    return new ZodEnum({
      type: "enum",
      entries,
      ...util_exports.normalizeParams(params)
    });
  }
  function nativeEnum(entries, params) {
    return new ZodEnum({
      type: "enum",
      entries,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodLiteral = /* @__PURE__ */ $constructor("ZodLiteral", (inst, def) => {
    $ZodLiteral.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => literalProcessor(inst, ctx, json2, params);
    inst.values = new Set(def.values);
    Object.defineProperty(inst, "value", {
      get() {
        if (def.values.length > 1) {
          throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
        }
        return def.values[0];
      }
    });
  });
  function literal(value, params) {
    return new ZodLiteral({
      type: "literal",
      values: Array.isArray(value) ? value : [value],
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodFile = /* @__PURE__ */ $constructor("ZodFile", (inst, def) => {
    $ZodFile.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => fileProcessor(inst, ctx, json2, params);
    inst.min = (size, params) => inst.check(_minSize(size, params));
    inst.max = (size, params) => inst.check(_maxSize(size, params));
    inst.mime = (types, params) => inst.check(_mime(Array.isArray(types) ? types : [types], params));
  });
  function file(params) {
    return _file(ZodFile, params);
  }
  var ZodTransform = /* @__PURE__ */ $constructor("ZodTransform", (inst, def) => {
    _ensureDefaultMemoizer();
    $ZodTransform.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => transformProcessor(inst, ctx, json2, params);
    inst._zod.parse = (payload, _ctx) => {
      if (_ctx.direction === "backward") {
        throw new $ZodEncodeError(inst.constructor.name);
      }
      payload.addIssue = (issue3) => {
        if (typeof issue3 === "string") {
          payload.issues.push(util_exports.issue(issue3, payload.value, def));
        } else {
          const _issue = issue3;
          if (_issue.fatal)
            _issue.continue = false;
          _issue.code ?? (_issue.code = "custom");
          if (!("input" in _issue))
            _issue.input = payload.value;
          _issue.inst ?? (_issue.inst = inst);
          payload.issues.push(util_exports.issue(_issue));
        }
      };
      const output2 = def.transform(payload.value, payload);
      if (output2 instanceof Promise) {
        return output2.then((output3) => {
          payload.value = output3;
          return payload;
        });
      }
      payload.value = output2;
      return payload;
    };
  });
  function transform(fn) {
    return new ZodTransform({
      type: "transform",
      transform: fn
    });
  }
  var ZodOptional = /* @__PURE__ */ $constructor("ZodOptional", (inst, def) => {
    $ZodOptional.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => optionalProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function optional(innerType) {
    return new ZodOptional({
      type: "optional",
      innerType
    });
  }
  var ZodExactOptional = /* @__PURE__ */ $constructor("ZodExactOptional", (inst, def) => {
    $ZodExactOptional.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => optionalProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function exactOptional(innerType) {
    return new ZodExactOptional({
      type: "optional",
      innerType
    });
  }
  var ZodNullable = /* @__PURE__ */ $constructor("ZodNullable", (inst, def) => {
    $ZodNullable.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => nullableProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function nullable(innerType) {
    return new ZodNullable({
      type: "nullable",
      innerType
    });
  }
  function nullish2(innerType) {
    return optional(nullable(innerType));
  }
  var ZodDefault = /* @__PURE__ */ $constructor("ZodDefault", (inst, def) => {
    $ZodDefault.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => defaultProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
    inst.removeDefault = inst.unwrap;
  });
  function _default2(innerType, defaultValue) {
    return new ZodDefault({
      type: "default",
      innerType,
      get defaultValue() {
        return typeof defaultValue === "function" ? defaultValue() : util_exports.shallowClone(defaultValue);
      }
    });
  }
  var ZodPrefault = /* @__PURE__ */ $constructor("ZodPrefault", (inst, def) => {
    $ZodPrefault.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => prefaultProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function prefault(innerType, defaultValue) {
    return new ZodPrefault({
      type: "prefault",
      innerType,
      get defaultValue() {
        return typeof defaultValue === "function" ? defaultValue() : util_exports.shallowClone(defaultValue);
      }
    });
  }
  var ZodNonOptional = /* @__PURE__ */ $constructor("ZodNonOptional", (inst, def) => {
    $ZodNonOptional.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => nonoptionalProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function nonoptional(innerType, params) {
    return new ZodNonOptional({
      type: "nonoptional",
      innerType,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodSuccess = /* @__PURE__ */ $constructor("ZodSuccess", (inst, def) => {
    $ZodSuccess.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => successProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function success(innerType) {
    return new ZodSuccess({
      type: "success",
      innerType
    });
  }
  var ZodCatch = /* @__PURE__ */ $constructor("ZodCatch", (inst, def) => {
    $ZodCatch.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => catchProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
    inst.removeCatch = inst.unwrap;
  });
  function _catch2(innerType, catchValue) {
    return new ZodCatch({
      type: "catch",
      innerType,
      catchValue: typeof catchValue === "function" ? catchValue : util_exports.constantCatch(catchValue)
    });
  }
  var ZodNaN = /* @__PURE__ */ $constructor("ZodNaN", (inst, def) => {
    $ZodNaN.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => nanProcessor(inst, ctx, json2, params);
  });
  function nan(params) {
    return _nan(ZodNaN, params);
  }
  var ZodPipe = /* @__PURE__ */ $constructor("ZodPipe", (inst, def) => {
    $ZodPipe.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => pipeProcessor(inst, ctx, json2, params);
    inst.in = def.in;
    inst.out = def.out;
  });
  function pipe(in_, out) {
    return new ZodPipe({
      type: "pipe",
      in: in_,
      out
      // ...util.normalizeParams(params),
    });
  }
  var ZodCodec = /* @__PURE__ */ $constructor("ZodCodec", (inst, def) => {
    ZodPipe.init(inst, def);
    $ZodCodec.init(inst, def);
  });
  function codec(in_, out, params) {
    return new ZodCodec({
      type: "pipe",
      in: in_,
      out,
      transform: params.decode,
      reverseTransform: params.encode
    });
  }
  function invertCodec(codec2) {
    const def = codec2._zod.def;
    return new ZodCodec({
      type: "pipe",
      in: def.out,
      out: def.in,
      transform: def.reverseTransform,
      reverseTransform: def.transform
    });
  }
  var ZodPreprocess = /* @__PURE__ */ $constructor("ZodPreprocess", (inst, def) => {
    ZodPipe.init(inst, def);
    $ZodPreprocess.init(inst, def);
  });
  var ZodReadonly = /* @__PURE__ */ $constructor("ZodReadonly", (inst, def) => {
    $ZodReadonly.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => readonlyProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function readonly(innerType) {
    return new ZodReadonly({
      type: "readonly",
      innerType
    });
  }
  var ZodTemplateLiteral = /* @__PURE__ */ $constructor("ZodTemplateLiteral", (inst, def) => {
    $ZodTemplateLiteral.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => templateLiteralProcessor(inst, ctx, json2, params);
  });
  function templateLiteral(parts, params) {
    return new ZodTemplateLiteral({
      type: "template_literal",
      parts,
      ...util_exports.normalizeParams(params)
    });
  }
  var ZodLazy = /* @__PURE__ */ $constructor("ZodLazy", (inst, def) => {
    $ZodLazy.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => lazyProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.getter();
  });
  function lazy(getter) {
    return new ZodLazy({
      type: "lazy",
      getter
    });
  }
  var ZodPromise = /* @__PURE__ */ $constructor("ZodPromise", (inst, def) => {
    $ZodPromise.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => promiseProcessor(inst, ctx, json2, params);
    inst.unwrap = () => inst._zod.def.innerType;
  });
  function promise(innerType) {
    return new ZodPromise({
      type: "promise",
      innerType
    });
  }
  var ZodFunction = /* @__PURE__ */ $constructor("ZodFunction", (inst, def) => {
    $ZodFunction.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => functionProcessor(inst, ctx, json2, params);
  });
  function _function(params) {
    return new ZodFunction({
      type: "function",
      input: Array.isArray(params?.input) ? tuple(params?.input) : params?.input ?? array(unknown()),
      output: params?.output ?? unknown()
    });
  }
  var ZodCustom = /* @__PURE__ */ $constructor("ZodCustom", (inst, def) => {
    $ZodCustom.init(inst, def);
    ZodType.init(inst, def);
    inst._zod.processJSONSchema = (ctx, json2, params) => customProcessor(inst, ctx, json2, params);
  });
  function check(fn) {
    const ch = new $ZodCheck({
      check: "custom"
      // ...util.normalizeParams(params),
    });
    ch._zod.check = fn;
    return ch;
  }
  function custom(fn, _params) {
    return _custom(ZodCustom, fn ?? (() => true), _params);
  }
  function refine(fn, _params = {}) {
    return _refine(ZodCustom, fn, _params);
  }
  function superRefine(fn, params) {
    return _superRefine(fn, params);
  }
  var describe2 = describe;
  var meta2 = meta;
  var ZodInstanceOf = /* @__PURE__ */ $constructor("ZodInstanceOf", (inst, def) => {
    ZodCustom.init(inst, def);
  }, {
    properties(shape, params) {
      return this.check(_properties(shape, params));
    }
  });
  function _instanceof(cls, params = {}) {
    const inst = new ZodInstanceOf({
      type: "custom",
      check: "custom",
      fn: (data) => data instanceof cls,
      abort: true,
      ...util_exports.normalizeParams(params)
    });
    inst._zod.bag.Class = cls;
    inst._zod.check = (payload) => {
      if (!(payload.value instanceof cls)) {
        payload.issues.push({
          code: "invalid_type",
          expected: cls.name,
          input: payload.value,
          inst,
          path: [...inst._zod.def.path ?? []]
        });
      }
    };
    return inst;
  }
  var stringbool = (...args) => _stringbool({
    Codec: ZodCodec,
    Boolean: ZodBoolean,
    String: ZodString
  }, ...args);
  function json(params) {
    const jsonSchema = lazy(() => {
      return union([string2(params), number2(), boolean2(), _null3(), array(jsonSchema), record(string2(), jsonSchema)]);
    });
    return jsonSchema;
  }
  function preprocess(fn, schema) {
    return new ZodPreprocess({
      type: "pipe",
      in: transform(fn),
      out: schema
    });
  }

  // ../../../node_modules/zod/v4/classic/compat.js
  var ZodIssueCode = {
    invalid_type: "invalid_type",
    too_big: "too_big",
    too_small: "too_small",
    invalid_format: "invalid_format",
    not_multiple_of: "not_multiple_of",
    unrecognized_keys: "unrecognized_keys",
    invalid_union: "invalid_union",
    invalid_key: "invalid_key",
    invalid_element: "invalid_element",
    invalid_value: "invalid_value",
    custom: "custom"
  };
  function setErrorMap(map2) {
    config({
      customError: map2
    });
  }
  function getErrorMap() {
    return config().customError;
  }
  var ZodFirstPartyTypeKind;
  /* @__PURE__ */ (function(ZodFirstPartyTypeKind2) {
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));

  // ../../../node_modules/zod/v4/classic/iso.js
  var iso_exports = {};
  __export(iso_exports, {
    ZodISODate: () => ZodISODate,
    ZodISODateTime: () => ZodISODateTime,
    ZodISODuration: () => ZodISODuration,
    ZodISOTime: () => ZodISOTime,
    date: () => date3,
    datetime: () => datetime2,
    duration: () => duration2,
    time: () => time2
  });
  function datetime2(params) {
    return _isoDateTime(ZodISODateTime, params);
  }
  function date3(params) {
    return _isoDate(ZodISODate, params);
  }
  function time2(params) {
    return _isoTime(ZodISOTime, params);
  }
  function duration2(params) {
    return _isoDuration(ZodISODuration, params);
  }

  // ../../../node_modules/zod/v4/classic/from-json-schema.js
  var z = {
    ...schemas_exports2,
    ...checks_exports2,
    iso: iso_exports
  };
  var RECOGNIZED_KEYS = /* @__PURE__ */ new Set([
    // Schema identification
    "$schema",
    "$ref",
    "$defs",
    "definitions",
    // Core schema keywords
    "$id",
    "id",
    "$comment",
    "$anchor",
    "$vocabulary",
    "$dynamicRef",
    "$dynamicAnchor",
    // Type
    "type",
    "enum",
    "const",
    // Composition
    "anyOf",
    "oneOf",
    "allOf",
    "not",
    // Object
    "properties",
    "required",
    "additionalProperties",
    "patternProperties",
    "propertyNames",
    "minProperties",
    "maxProperties",
    // Array
    "items",
    "prefixItems",
    "additionalItems",
    "minItems",
    "maxItems",
    "uniqueItems",
    "contains",
    "minContains",
    "maxContains",
    // String
    "minLength",
    "maxLength",
    "pattern",
    "format",
    // Number
    "minimum",
    "maximum",
    "exclusiveMinimum",
    "exclusiveMaximum",
    "multipleOf",
    // Already handled metadata
    "description",
    "default",
    // Content
    "contentEncoding",
    "contentMediaType",
    "contentSchema",
    // Unsupported (error-throwing)
    "unevaluatedItems",
    "unevaluatedProperties",
    "if",
    "then",
    "else",
    "dependentSchemas",
    "dependentRequired",
    // OpenAPI
    "nullable",
    "readOnly"
  ]);
  function detectVersion(schema, defaultTarget) {
    const $schema = schema.$schema;
    if ($schema === "https://json-schema.org/draft/2020-12/schema") {
      return "draft-2020-12";
    }
    if ($schema === "http://json-schema.org/draft-07/schema#") {
      return "draft-7";
    }
    if ($schema === "http://json-schema.org/draft-04/schema#") {
      return "draft-4";
    }
    return defaultTarget ?? "draft-2020-12";
  }
  function applyMinItems(items, minItems) {
    return items.map((item, index) => index < minItems ? item : item.optional());
  }
  function decodeJSONPointerSegment(segment) {
    return segment.replace(/~1/g, "/").replace(/~0/g, "~");
  }
  function resolveRef(ref, ctx) {
    if (!ref.startsWith("#")) {
      throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
    }
    const path = ref.slice(1).split("/").filter(Boolean);
    if (path.length === 0) {
      return ctx.rootSchema;
    }
    const defsKey = ctx.version === "draft-2020-12" ? "$defs" : "definitions";
    if (path[0] === defsKey) {
      const key6 = path[1] === void 0 ? void 0 : decodeJSONPointerSegment(path[1]);
      if (!key6 || !ctx.defs[key6]) {
        throw new Error(`Reference not found: ${ref}`);
      }
      return ctx.defs[key6];
    }
    throw new Error(`Reference not found: ${ref}`);
  }
  function checkObjectGuards(objectSchema, guards) {
    const guard = z.transform((value) => value).check((payload) => {
      const value = payload.value;
      if (typeof value !== "object" || value === null || Array.isArray(value))
        return;
      const keys = Object.getOwnPropertyNames(value);
      if (guards.minProperties !== void 0 && keys.length < guards.minProperties) {
        payload.issues.push({
          origin: "object",
          code: "too_small",
          minimum: guards.minProperties,
          inclusive: true,
          message: `Too small: expected object to have >=${guards.minProperties} properties`,
          input: value,
          inst: objectSchema,
          continue: true
        });
      }
      if (guards.maxProperties !== void 0 && keys.length > guards.maxProperties) {
        payload.issues.push({
          origin: "object",
          code: "too_big",
          maximum: guards.maxProperties,
          inclusive: true,
          message: `Too big: expected object to have <=${guards.maxProperties} properties`,
          input: value,
          inst: objectSchema,
          continue: true
        });
      }
      if (guards.keySchema) {
        for (const key6 of keys) {
          const result = guards.keySchema.safeParse(key6);
          if (result.success)
            continue;
          payload.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: result.error.issues,
            input: key6,
            path: [key6],
            continue: true
          });
        }
      }
    });
    return guard.pipe(objectSchema);
  }
  function canonicalKey(value, seen) {
    if (value === null)
      return "z";
    const type = typeof value;
    if (type !== "object") {
      if (type === "number" && Number.isNaN(value))
        return null;
      const raw = String(value);
      return `${type[0]}${raw.length}:${raw}`;
    }
    if (seen.has(value))
      return null;
    seen.add(value);
    try {
      if (Array.isArray(value)) {
        const parts2 = [];
        for (const item of value) {
          const key6 = canonicalKey(item, seen);
          if (key6 === null)
            return null;
          parts2.push(key6);
        }
        return `a${parts2.length}:[${parts2.join(",")}]`;
      }
      const keys = Object.keys(value).sort();
      const parts = [];
      for (const k of keys) {
        const key6 = canonicalKey(value[k], seen);
        if (key6 === null)
          return null;
        parts.push(`${k.length}:${k}=${key6}`);
      }
      return `o${parts.length}:{${parts.join(",")}}`;
    } finally {
      seen.delete(value);
    }
  }
  var SCHEMA_KEYWORDS = /* @__PURE__ */ new Set([
    "items",
    "prefixItems",
    "additionalItems",
    "additionalProperties",
    "contains",
    "propertyNames",
    "not",
    "if",
    "then",
    "else",
    "allOf",
    "anyOf",
    "oneOf",
    "unevaluatedItems",
    "unevaluatedProperties",
    "contentSchema"
  ]);
  var SCHEMA_MAP_KEYWORDS = /* @__PURE__ */ new Set([
    "properties",
    "patternProperties",
    "dependentSchemas",
    "dependencies",
    "$defs",
    "definitions"
  ]);
  function containsRef(value) {
    if (typeof value !== "object" || value === null)
      return false;
    if (Array.isArray(value))
      return value.some(containsRef);
    if (typeof value.$ref === "string")
      return true;
    return Object.entries(value).some(([key6, sub]) => {
      if (SCHEMA_KEYWORDS.has(key6))
        return containsRef(sub);
      if (!SCHEMA_MAP_KEYWORDS.has(key6) || typeof sub !== "object" || sub === null)
        return false;
      return Object.values(sub).some(containsRef);
    });
  }
  function plural(n) {
    return n === 1 ? "element" : "elements";
  }
  function checkArrayGuards(arraySchema, guards) {
    const guard = z.transform((value) => value).check((payload) => {
      const items = payload.value;
      if (!Array.isArray(items))
        return;
      if (guards.uniqueItems === true) {
        const firstSeen = /* @__PURE__ */ new Map();
        for (let i = 0; i < items.length; i++) {
          const key6 = canonicalKey(items[i], /* @__PURE__ */ new Set());
          if (key6 === null)
            continue;
          const first = firstSeen.get(key6);
          if (first === void 0) {
            firstSeen.set(key6, i);
            continue;
          }
          payload.issues.push({
            code: "custom",
            message: `Array items must be unique: element at index ${i} duplicates the one at index ${first}`,
            input: items,
            path: [i],
            continue: true
          });
        }
      }
      if (guards.containsSchema) {
        const minContains = guards.minContains ?? 1;
        const ceiling = guards.maxContains !== void 0 ? guards.maxContains + 1 : Number.POSITIVE_INFINITY;
        let matches = 0;
        for (const item of items) {
          if (guards.containsSchema.safeParse(item).success && ++matches >= ceiling)
            break;
        }
        if (matches < minContains) {
          payload.issues.push({
            code: "custom",
            message: `Array must contain at least ${minContains} matching ${plural(minContains)}; found ${matches}`,
            input: items,
            continue: true
          });
        }
        if (guards.maxContains !== void 0 && matches > guards.maxContains) {
          payload.issues.push({
            code: "custom",
            message: `Array must contain at most ${guards.maxContains} matching ${plural(guards.maxContains)}`,
            input: items,
            continue: true
          });
        }
      }
    });
    return guard.pipe(arraySchema);
  }
  function getTupleRest(restSchema, ctx) {
    if (restSchema === false) {
      return void 0;
    }
    if (restSchema === void 0 || restSchema === true) {
      return z.any();
    }
    return convertSchema(restSchema, ctx);
  }
  var fullTime = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
  function convertBaseSchema(schema, ctx) {
    if (schema.not !== void 0) {
      if (typeof schema.not === "object" && Object.keys(schema.not).length === 0) {
        return z.never();
      }
      throw new Error("not is not supported in Zod (except { not: {} } for never)");
    }
    if (schema.unevaluatedItems !== void 0) {
      throw new Error("unevaluatedItems is not supported");
    }
    if (schema.unevaluatedProperties !== void 0) {
      throw new Error("unevaluatedProperties is not supported");
    }
    if (schema.if !== void 0 || schema.then !== void 0 || schema.else !== void 0) {
      throw new Error("Conditional schemas (if/then/else) are not supported");
    }
    if (schema.dependentSchemas !== void 0 || schema.dependentRequired !== void 0) {
      throw new Error("dependentSchemas and dependentRequired are not supported");
    }
    if (schema.$ref) {
      const refPath = schema.$ref;
      if (ctx.refs.has(refPath)) {
        return ctx.refs.get(refPath);
      }
      if (ctx.processing.has(refPath)) {
        return z.lazy(() => {
          if (!ctx.refs.has(refPath)) {
            throw new Error(`Circular reference not resolved: ${refPath}`);
          }
          return ctx.refs.get(refPath);
        });
      }
      ctx.processing.add(refPath);
      const resolved = resolveRef(refPath, ctx);
      const zodSchema2 = convertSchema(resolved, ctx);
      ctx.refs.set(refPath, zodSchema2);
      ctx.processing.delete(refPath);
      return zodSchema2;
    }
    if (schema.enum !== void 0) {
      const enumValues = schema.enum;
      if (ctx.version === "openapi-3.0" && schema.nullable === true && enumValues.length === 1 && enumValues[0] === null) {
        return z.null();
      }
      if (enumValues.length === 0) {
        return z.never();
      }
      if (enumValues.length === 1) {
        return z.literal(enumValues[0]);
      }
      if (enumValues.every((v) => typeof v === "string")) {
        return z.enum(enumValues);
      }
      const literalSchemas = enumValues.map((v) => z.literal(v));
      if (literalSchemas.length < 2) {
        return literalSchemas[0];
      }
      return z.union([literalSchemas[0], literalSchemas[1], ...literalSchemas.slice(2)]);
    }
    if (schema.const !== void 0) {
      return z.literal(schema.const);
    }
    const type = schema.type;
    if (Array.isArray(type)) {
      const typeSchemas = type.map((t) => {
        const typeSchema = { ...schema, type: t };
        return convertBaseSchema(typeSchema, ctx);
      });
      if (typeSchemas.length === 0) {
        return z.never();
      }
      if (typeSchemas.length === 1) {
        return typeSchemas[0];
      }
      return z.union(typeSchemas);
    }
    if (!type) {
      return z.any();
    }
    let zodSchema;
    switch (type) {
      case "string": {
        let stringSchema = z.string();
        if (schema.format) {
          const format = schema.format;
          if (format === "email") {
            stringSchema = stringSchema.check(z.email());
          } else if (format === "uri" || format === "uri-reference") {
            stringSchema = stringSchema.check(z.url());
          } else if (format === "uuid" || format === "guid") {
            stringSchema = stringSchema.check(z.uuid());
          } else if (format === "date-time") {
            stringSchema = stringSchema.check(z.iso.datetime({ offset: true }));
          } else if (format === "date") {
            stringSchema = stringSchema.check(z.iso.date());
          } else if (format === "time") {
            stringSchema = stringSchema.check(z.regex(fullTime));
          } else if (format === "duration") {
            stringSchema = stringSchema.check(z.iso.duration());
          } else if (format === "hostname") {
            stringSchema = stringSchema.check(z.hostname());
          } else if (format === "ipv4") {
            stringSchema = stringSchema.check(z.ipv4());
          } else if (format === "ipv6") {
            stringSchema = stringSchema.check(z.ipv6());
          } else if (format === "mac") {
            stringSchema = stringSchema.check(z.mac());
          } else if (format === "cidr") {
            stringSchema = stringSchema.check(z.cidrv4());
          } else if (format === "cidr-v6") {
            stringSchema = stringSchema.check(z.cidrv6());
          } else if (format === "base64") {
            stringSchema = stringSchema.check(z.base64());
          } else if (format === "base64url") {
            stringSchema = stringSchema.check(z.base64url());
          } else if (format === "e164") {
            stringSchema = stringSchema.check(z.e164());
          } else if (format === "credit_card") {
            stringSchema = stringSchema.check(z.creditCard());
          } else if (format === "iban") {
            stringSchema = stringSchema.check(z.iban());
          } else if (format === "jwt") {
            stringSchema = stringSchema.check(z.jwt());
          } else if (format === "emoji") {
            stringSchema = stringSchema.check(z.emoji());
          } else if (format === "nanoid") {
            stringSchema = stringSchema.check(z.nanoid());
          } else if (format === "cuid") {
            stringSchema = stringSchema.check(z.cuid());
          } else if (format === "cuid2") {
            stringSchema = stringSchema.check(z.cuid2());
          } else if (format === "ulid") {
            stringSchema = stringSchema.check(z.ulid());
          } else if (format === "xid") {
            stringSchema = stringSchema.check(z.xid());
          } else if (format === "ksuid") {
            stringSchema = stringSchema.check(z.ksuid());
          }
        }
        if (typeof schema.minLength === "number") {
          stringSchema = stringSchema.min(schema.minLength);
        }
        if (typeof schema.maxLength === "number") {
          stringSchema = stringSchema.max(schema.maxLength);
        }
        if (schema.pattern) {
          stringSchema = stringSchema.regex(new RegExp(schema.pattern));
        }
        zodSchema = stringSchema;
        break;
      }
      case "number":
      case "integer": {
        let numberSchema = type === "integer" ? z.number().int() : z.number();
        if (typeof schema.minimum === "number" && schema.exclusiveMinimum !== true) {
          numberSchema = numberSchema.min(schema.minimum);
        }
        if (typeof schema.maximum === "number" && schema.exclusiveMaximum !== true) {
          numberSchema = numberSchema.max(schema.maximum);
        }
        if (typeof schema.exclusiveMinimum === "number") {
          numberSchema = numberSchema.gt(schema.exclusiveMinimum);
        } else if (schema.exclusiveMinimum === true && typeof schema.minimum === "number") {
          numberSchema = numberSchema.gt(schema.minimum);
        }
        if (typeof schema.exclusiveMaximum === "number") {
          numberSchema = numberSchema.lt(schema.exclusiveMaximum);
        } else if (schema.exclusiveMaximum === true && typeof schema.maximum === "number") {
          numberSchema = numberSchema.lt(schema.maximum);
        }
        if (typeof schema.multipleOf === "number") {
          numberSchema = numberSchema.multipleOf(schema.multipleOf);
        }
        zodSchema = numberSchema;
        break;
      }
      case "boolean": {
        zodSchema = z.boolean();
        break;
      }
      case "null": {
        zodSchema = z.null();
        break;
      }
      case "object": {
        const shape = {};
        const properties = schema.properties || {};
        const requiredSet = new Set(schema.required || []);
        const additionalSchema = typeof schema.additionalProperties === "object" ? convertSchema(schema.additionalProperties, ctx) : void 0;
        for (const [key6, propSchema] of Object.entries(properties)) {
          const propZodSchema = convertSchema(propSchema, ctx);
          assignProp(shape, key6, requiredSet.has(key6) ? propZodSchema : propZodSchema.optional());
        }
        if (schema.patternProperties) {
          const patternProps = schema.patternProperties;
          const patternKeys = Object.keys(patternProps);
          const looseRecords = [];
          for (const pattern of patternKeys) {
            const patternValue = convertSchema(patternProps[pattern], ctx);
            const keySchema = z.string().regex(new RegExp(pattern));
            looseRecords.push(z.looseRecord(keySchema, patternValue));
          }
          const schemasToIntersect = [];
          if (Object.keys(shape).length > 0) {
            schemasToIntersect.push(z.object(shape).passthrough());
          }
          schemasToIntersect.push(...looseRecords);
          if (schemasToIntersect.length === 0) {
            zodSchema = z.object({}).passthrough();
          } else if (schemasToIntersect.length === 1) {
            zodSchema = schemasToIntersect[0];
          } else {
            let result = z.intersection(schemasToIntersect[0], schemasToIntersect[1]);
            for (let i = 2; i < schemasToIntersect.length; i++) {
              result = z.intersection(result, schemasToIntersect[i]);
            }
            zodSchema = result;
          }
          if (schema.additionalProperties === false) {
            const propertyKeys = Object.keys(shape);
            const patterns = patternKeys.map((p) => new RegExp(p));
            const basePatternSchema = zodSchema;
            zodSchema = zodSchema.check((payload) => {
              if (!isPlainObject(payload.value))
                return;
              const unrecognized = [];
              for (const key6 of Object.keys(payload.value)) {
                if (propertyKeys.includes(key6))
                  continue;
                if (patterns.some((regex) => regex.test(key6)))
                  continue;
                unrecognized.push(key6);
              }
              if (unrecognized.length) {
                payload.issues.push({
                  code: "unrecognized_keys",
                  keys: unrecognized,
                  input: payload.value,
                  inst: basePatternSchema
                });
              }
            });
          }
        } else {
          const objectSchema = z.object(shape);
          if (schema.additionalProperties === false) {
            zodSchema = objectSchema.strict();
          } else if (additionalSchema) {
            zodSchema = objectSchema.catchall(additionalSchema);
          } else {
            zodSchema = objectSchema.passthrough();
          }
        }
        const hasKeyGuard = schema.propertyNames !== void 0 && schema.propertyNames !== true;
        const minProperties = typeof schema.minProperties === "number" ? schema.minProperties : void 0;
        const maxProperties = typeof schema.maxProperties === "number" ? schema.maxProperties : void 0;
        if (hasKeyGuard || minProperties !== void 0 || maxProperties !== void 0) {
          let keySchema;
          if (hasKeyGuard) {
            const keyJSONSchema = typeof schema.propertyNames === "object" && schema.propertyNames.type === void 0 ? { type: "string", ...schema.propertyNames } : schema.propertyNames;
            keySchema = convertSchema(keyJSONSchema, ctx);
          }
          zodSchema = checkObjectGuards(zodSchema, { keySchema, minProperties, maxProperties });
        }
        break;
      }
      case "array": {
        const prefixItems = schema.prefixItems;
        const items = schema.items;
        if (prefixItems && Array.isArray(prefixItems)) {
          const minItems = typeof schema.minItems === "number" ? schema.minItems : 0;
          const tupleItems = prefixItems.map((item) => convertSchema(item, ctx));
          const positionalItems = applyMinItems(tupleItems, minItems);
          const rest = !Array.isArray(items) ? getTupleRest(items, ctx) : void 0;
          const tupleSchema = z.tuple(positionalItems);
          zodSchema = rest ? tupleSchema.rest(rest) : tupleSchema;
          if (typeof schema.minItems === "number") {
            zodSchema = zodSchema.check(z.minLength(schema.minItems));
          }
          if (typeof schema.maxItems === "number") {
            zodSchema = zodSchema.check(z.maxLength(schema.maxItems));
          }
        } else if (Array.isArray(items)) {
          const minItems = typeof schema.minItems === "number" ? schema.minItems : 0;
          const tupleItems = items.map((item) => convertSchema(item, ctx));
          const positionalItems = applyMinItems(tupleItems, minItems);
          const rest = getTupleRest(schema.additionalItems, ctx);
          const tupleSchema = z.tuple(positionalItems);
          zodSchema = rest ? tupleSchema.rest(rest) : tupleSchema;
          if (typeof schema.minItems === "number") {
            zodSchema = zodSchema.check(z.minLength(schema.minItems));
          }
          if (typeof schema.maxItems === "number") {
            zodSchema = zodSchema.check(z.maxLength(schema.maxItems));
          }
        } else if (items !== void 0) {
          const element = convertSchema(items, ctx);
          let arraySchema = z.array(element);
          if (typeof schema.minItems === "number") {
            arraySchema = arraySchema.min(schema.minItems);
          }
          if (typeof schema.maxItems === "number") {
            arraySchema = arraySchema.max(schema.maxItems);
          }
          zodSchema = arraySchema;
        } else {
          zodSchema = z.array(z.any());
        }
        if (schema.uniqueItems === true || schema.contains !== void 0) {
          zodSchema = checkArrayGuards(zodSchema, {
            uniqueItems: schema.uniqueItems === true,
            containsSchema: schema.contains !== void 0 ? convertSchema(schema.contains, ctx) : void 0,
            minContains: typeof schema.minContains === "number" ? schema.minContains : void 0,
            maxContains: typeof schema.maxContains === "number" ? schema.maxContains : void 0
          });
        }
        break;
      }
      default:
        throw new Error(`Unsupported type: ${type}`);
    }
    return zodSchema;
  }
  function convertSchema(schema, ctx) {
    if (typeof schema === "boolean") {
      return schema ? z.any() : z.never();
    }
    let baseSchema = convertBaseSchema(schema, ctx);
    const hasExplicitType = schema.type || schema.enum !== void 0 || schema.const !== void 0;
    if (schema.anyOf && Array.isArray(schema.anyOf)) {
      const options = schema.anyOf.map((s) => convertSchema(s, ctx));
      const anyOfUnion = z.union(options);
      baseSchema = hasExplicitType ? z.intersection(baseSchema, anyOfUnion) : anyOfUnion;
    }
    if (schema.oneOf && Array.isArray(schema.oneOf)) {
      const options = schema.oneOf.map((s) => convertSchema(s, ctx));
      const oneOfUnion = z.xor(options);
      baseSchema = hasExplicitType ? z.intersection(baseSchema, oneOfUnion) : oneOfUnion;
    }
    if (schema.allOf && Array.isArray(schema.allOf)) {
      if (schema.allOf.length === 0) {
        baseSchema = hasExplicitType ? baseSchema : z.any();
      } else {
        let result = hasExplicitType ? baseSchema : convertSchema(schema.allOf[0], ctx);
        const startIdx = hasExplicitType ? 0 : 1;
        for (let i = startIdx; i < schema.allOf.length; i++) {
          result = z.intersection(result, convertSchema(schema.allOf[i], ctx));
        }
        baseSchema = result;
      }
    }
    if (schema.nullable === true && ctx.version === "openapi-3.0") {
      baseSchema = z.nullable(baseSchema);
    }
    if (schema.readOnly === true) {
      baseSchema = z.readonly(baseSchema);
    }
    if (schema.default !== void 0) {
      baseSchema = baseSchema.default(schema.default);
    }
    const extraMeta = {};
    const coreMetadataKeys = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
    for (const key6 of coreMetadataKeys) {
      if (key6 in schema) {
        extraMeta[key6] = schema[key6];
      }
    }
    const contentMetadataKeys = ["contentEncoding", "contentMediaType", "contentSchema"];
    for (const key6 of contentMetadataKeys) {
      if (key6 in schema) {
        extraMeta[key6] = schema[key6];
      }
    }
    if (schema.type === "object" && schema.$ref === void 0) {
      if (schema.propertyNames !== void 0 && !containsRef(schema.propertyNames)) {
        extraMeta.propertyNames = schema.propertyNames;
      }
      for (const key6 of ["minProperties", "maxProperties"]) {
        if (schema[key6] !== void 0)
          extraMeta[key6] = schema[key6];
      }
    }
    if (schema.type === "array" && schema.$ref === void 0) {
      if (schema.contains !== void 0 && !containsRef(schema.contains)) {
        extraMeta.contains = schema.contains;
      }
      for (const key6 of ["uniqueItems", "minContains", "maxContains"]) {
        if (schema[key6] !== void 0)
          extraMeta[key6] = schema[key6];
      }
    }
    for (const key6 of Object.keys(schema)) {
      if (!RECOGNIZED_KEYS.has(key6)) {
        assignProp(extraMeta, key6, schema[key6]);
      }
    }
    if (Object.keys(extraMeta).length > 0) {
      ctx.registry.add(baseSchema, extraMeta);
    }
    if (schema.description) {
      baseSchema = baseSchema.describe(schema.description);
    }
    return baseSchema;
  }
  function fromJSONSchema(schema, params) {
    if (typeof schema === "boolean") {
      return schema ? z.any() : z.never();
    }
    let normalized;
    try {
      normalized = JSON.parse(JSON.stringify(schema));
    } catch {
      throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
    }
    const version2 = detectVersion(normalized, params?.defaultTarget);
    const defs = normalized.$defs || normalized.definitions || {};
    const ctx = {
      version: version2,
      defs,
      refs: /* @__PURE__ */ new Map(),
      processing: /* @__PURE__ */ new Set(),
      rootSchema: normalized,
      registry: params?.registry ?? globalRegistry
    };
    return convertSchema(normalized, ctx);
  }

  // ../../../node_modules/zod/v4/core/visit.js
  var RESOLVING = /* @__PURE__ */ Symbol("z.visit/resolving");
  function visit(schema, fnOrHandlers) {
    const fn = typeof fnOrHandlers === "function" ? fnOrHandlers : (node2, rewritten) => {
      const h = fnOrHandlers[node2._zod.def.type];
      return h ? h(node2, rewritten) : node2;
    };
    const cache = /* @__PURE__ */ new Map();
    function run(s) {
      const cached2 = cache.get(s);
      if (cached2 === RESOLVING) {
        return new $ZodLazy({
          type: "lazy",
          getter: () => cache.get(s)
        });
      }
      if (cached2 !== void 0)
        return cached2;
      cache.set(s, RESOLVING);
      const inner = mapInner(s);
      const mapped = fn(inner, inner !== s);
      cache.set(s, mapped);
      return mapped;
    }
    function mapInner(s) {
      const def = s._zod.def;
      const kind = def.type;
      switch (kind) {
        case "object": {
          const oldShape = def.shape;
          const keys = Object.keys(oldShape);
          let changed = false;
          const newShape = {};
          for (const k of keys) {
            const mapped = run(oldShape[k]);
            if (mapped !== oldShape[k])
              changed = true;
            newShape[k] = mapped;
          }
          let newCatchall = def.catchall;
          if (def.catchall) {
            newCatchall = run(def.catchall);
            if (newCatchall !== def.catchall)
              changed = true;
          }
          return changed ? clone(s, { ...def, shape: newShape, catchall: newCatchall }) : s;
        }
        case "array": {
          const mapped = run(def.element);
          return mapped === def.element ? s : clone(s, { ...def, element: mapped });
        }
        case "tuple": {
          const oldItems = def.items;
          let changed = false;
          const newItems = [];
          for (const item of oldItems) {
            const mapped = run(item);
            if (mapped !== item)
              changed = true;
            newItems.push(mapped);
          }
          let newRest = def.rest;
          if (def.rest) {
            newRest = run(def.rest);
            if (newRest !== def.rest)
              changed = true;
          }
          return changed ? clone(s, { ...def, items: newItems, rest: newRest }) : s;
        }
        case "record":
        case "map": {
          const newKey = run(def.keyType);
          const newVal = run(def.valueType);
          return newKey === def.keyType && newVal === def.valueType ? s : clone(s, { ...def, keyType: newKey, valueType: newVal });
        }
        case "set": {
          const newVal = run(def.valueType);
          return newVal === def.valueType ? s : clone(s, { ...def, valueType: newVal });
        }
        case "union": {
          const oldOptions = def.options;
          let changed = false;
          const newOptions = [];
          for (const opt of oldOptions) {
            const mapped = run(opt);
            if (mapped !== opt)
              changed = true;
            newOptions.push(mapped);
          }
          return changed ? clone(s, { ...def, options: newOptions }) : s;
        }
        case "intersection": {
          const newLeft = run(def.left);
          const newRight = run(def.right);
          return newLeft === def.left && newRight === def.right ? s : clone(s, { ...def, left: newLeft, right: newRight });
        }
        case "optional":
        case "nullable":
        case "default":
        case "prefault":
        case "catch":
        case "readonly":
        case "nonoptional":
        case "promise":
        case "success": {
          const newInner = run(def.innerType);
          return newInner === def.innerType ? s : clone(s, { ...def, innerType: newInner });
        }
        case "pipe": {
          const newIn = run(def.in);
          const newOut = run(def.out);
          return newIn === def.in && newOut === def.out ? s : clone(s, { ...def, in: newIn, out: newOut });
        }
        case "function": {
          const newInput = run(def.input);
          const newOutput = run(def.output);
          return newInput === def.input && newOutput === def.output ? s : clone(s, { ...def, input: newInput, output: newOutput });
        }
        case "lazy": {
          const original = def.getter;
          const { _cachedInner, ...rest } = def;
          return clone(s, { ...rest, getter: () => run(original()) });
        }
        // A leaf by choice: `parts` are regex fragments, not data positions.
        case "template_literal":
        // Leaves.
        case "string":
        case "number":
        case "int":
        case "boolean":
        case "bigint":
        case "symbol":
        case "undefined":
        case "null":
        case "void":
        case "never":
        case "any":
        case "unknown":
        case "date":
        case "nan":
        case "enum":
        case "literal":
        case "file":
        case "transform":
        case "custom":
          return s;
        default: {
          kind;
          return s;
        }
      }
    }
    return run(schema);
  }

  // ../../../node_modules/zod/v4/classic/deep-partial.js
  function deepPartial(schema) {
    return visit(schema, {
      object: (s) => s.partial(),
      // Every partialed option now admits `undefined`, which the constructor rejects as a duplicate.
      union: (s) => {
        const def = s._zod.def;
        return def.discriminator === void 0 ? s : union(def.options);
      }
    });
  }

  // ../../../node_modules/zod/v4/classic/in-out.js
  function withChecks(side, checks) {
    if (!checks?.length)
      return side;
    const def = side._zod.def;
    return clone(side, mergeDefs(def, { checks: [...def.checks ?? [], ...checks] }), { parent: true });
  }
  function outSide(def) {
    return withChecks(def.out, def.checks);
  }
  function inSide(def) {
    return def.in._zod.traits.has("$ZodTransform") ? outSide(def) : def.in;
  }
  function input(schema) {
    return visit(schema, {
      pipe: (s) => inSide(s._zod.def),
      // A default value belongs to the output side, so a rewritten inner type leaves it stranded. `.default()` widens the declared input type with `undefined`, and `optional` is what carries that across.
      default: (s, rewritten) => rewritten ? optional(s._zod.def.innerType) : s,
      // A catch value is output-side too, but `.catch()` leaves the declared input type alone, so the inner schema stands on its own.
      catch: (s, rewritten) => rewritten ? s._zod.def.innerType : s
    });
  }
  function output(schema) {
    return visit(schema, {
      pipe: (s) => outSide(s._zod.def),
      // A prefault value is fed through the schema, which makes it input-side, so a rewritten inner type leaves it stranded.
      prefault: (s, rewritten) => rewritten ? s._zod.def.innerType : s
    });
  }

  // ../../../node_modules/zod/v4/classic/coerce.js
  var coerce_exports = {};
  __export(coerce_exports, {
    bigint: () => bigint3,
    boolean: () => boolean3,
    date: () => date4,
    number: () => number3,
    string: () => string3
  });
  function string3(params) {
    return _coercedString(ZodString, params);
  }
  function number3(params) {
    return _coercedNumber(ZodNumber, params);
  }
  function boolean3(params) {
    return _coercedBoolean(ZodBoolean, params);
  }
  function bigint3(params) {
    return _coercedBigint(ZodBigInt, params);
  }
  function date4(params) {
    return _coercedDate(ZodDate, params);
  }

  // packages/contracts/src/answer-draft.ts
  var ANSWER_DRAFT_PROTOCOL = "answer-draft-v2";
  var answerDraftFenceSchema = external_exports.object({
    actorId: external_exports.string().min(1).max(180),
    revision: external_exports.number().int().min(0),
    baseHash: external_exports.string().regex(/^[a-f0-9]{64}$/),
    attempt: external_exports.number().int().min(0).max(5)
  }).strict();
  var answerDraftSaveSchema = external_exports.union([
    external_exports.object({
      answer: external_exports.unknown(),
      protocol: external_exports.literal(ANSWER_DRAFT_PROTOCOL),
      actorId: external_exports.string().min(1).max(180),
      expectedRevision: external_exports.number().int().min(0),
      baseHash: external_exports.string().regex(/^[a-f0-9]{64}$/),
      attempt: external_exports.number().int().min(0).max(5),
      requestKey: external_exports.string().min(8).max(180)
    }).strict(),
    external_exports.object({ answer: external_exports.unknown() }).strict()
  ]);

  // packages/contracts/src/diagnostics.ts
  var subject = external_exports.enum(["chinese", "math", "english", "chemistry"]);
  var id = external_exports.string().min(1).max(180);
  var dimensionSchema = external_exports.enum(["understanding", "procedure", "transfer", "retention"]);
  var teachingVisualSchema = external_exports.object({
    kind: external_exports.literal("fraction_bars"),
    title: external_exports.string().trim().min(3).max(160),
    note: external_exports.string().trim().min(10).max(600),
    operator: external_exports.enum(["+", "-", "="]),
    commonDenominator: external_exports.number().int().min(2).max(24),
    terms: external_exports.array(external_exports.object({
      numerator: external_exports.number().int().min(0).max(24),
      denominator: external_exports.number().int().min(2).max(24),
      label: external_exports.string().trim().min(1).max(80)
    }).strict()).min(1).max(3),
    result: external_exports.object({
      numerator: external_exports.number().int().min(0).max(48),
      denominator: external_exports.number().int().min(2).max(24)
    }).strict()
  }).strict().superRefine((visual, context2) => {
    for (const [index, term] of visual.terms.entries()) {
      if (term.numerator > term.denominator) context2.addIssue({
        code: external_exports.ZodIssueCode.custom,
        path: ["terms", index, "numerator"],
        message: "\u6559\u5B66\u5206\u6570\u5FC5\u987B\u4F4D\u4E8E 0 \u4E0E\u540C\u4E00\u6574\u4F53\u4E4B\u95F4"
      });
      if (visual.commonDenominator % term.denominator !== 0) context2.addIssue({
        code: external_exports.ZodIssueCode.custom,
        path: ["commonDenominator"],
        message: "\u5171\u540C\u5206\u6BCD\u5FC5\u987B\u80FD\u7531\u6BCF\u4E2A\u5206\u6BCD\u7B49\u503C\u5207\u5206\u5F97\u5230"
      });
    }
    if (visual.result.numerator > visual.result.denominator) context2.addIssue({
      code: external_exports.ZodIssueCode.custom,
      path: ["result", "numerator"],
      message: "\u672C\u56FE\u6682\u53EA\u5448\u73B0\u4E0D\u8D85\u8FC7\u540C\u4E00\u6574\u4F53\u7684\u7ED3\u679C"
    });
    if (visual.operator === "=" && visual.terms.length !== 1) context2.addIssue({
      code: external_exports.ZodIssueCode.custom,
      path: ["terms"],
      message: "\u7B49\u503C\u56FE\u53EA\u80FD\u5C55\u793A\u4E00\u4E2A\u539F\u5206\u6570"
    });
    if (visual.operator !== "=" && visual.terms.length < 2) context2.addIssue({
      code: external_exports.ZodIssueCode.custom,
      path: ["terms"],
      message: "\u52A0\u51CF\u56FE\u81F3\u5C11\u9700\u8981\u4E24\u4E2A\u5206\u6570"
    });
  });
  var atomTeachingSchema = external_exports.object({
    reviewStatus: external_exports.enum(["draft", "approved"]),
    explanation: external_exports.string().trim().min(10).max(3e3),
    example: external_exports.object({
      prompt: external_exports.string().trim().min(5).max(1500),
      steps: external_exports.array(external_exports.string().trim().min(3).max(800)).min(1).max(12),
      conclusion: external_exports.string().trim().min(1).max(800)
    }).strict(),
    commonErrors: external_exports.array(external_exports.object({
      code: external_exports.string().trim().min(1).max(100),
      observation: external_exports.string().trim().min(5).max(600),
      alternativeExplanations: external_exports.array(external_exports.string().trim().min(5).max(400)).min(1).max(5),
      verification: external_exports.string().trim().min(10).max(1e3)
    }).strict()).min(1).max(12),
    verification: external_exports.object({
      understanding: external_exports.string().trim().min(10).max(1e3),
      procedure: external_exports.string().trim().min(10).max(1e3),
      transfer: external_exports.string().trim().min(10).max(1e3),
      retention: external_exports.string().trim().min(10).max(1e3)
    }).strict(),
    /** Optional, author-defined visual attached to an approved teaching card. */
    visual: teachingVisualSchema.optional()
  }).strict();
  var knowledgeAtomSchema = external_exports.object({
    id,
    subject,
    name: external_exports.string().min(1).max(120),
    strand: external_exports.string().min(1).max(120),
    grade: external_exports.number().int().min(1).max(9),
    term: external_exports.enum(["upper", "lower", "both"]),
    objective: external_exports.string().min(5).max(1e3),
    successCriterion: external_exports.string().min(5).max(1e3),
    prerequisiteIds: external_exports.array(id).max(30),
    curriculumVersion: external_exports.string().min(1).max(120),
    status: external_exports.enum(["draft", "published", "retired"]),
    version: external_exports.number().int().positive(),
    parentId: id.nullable().optional(),
    confusableAtomIds: external_exports.array(id).max(30).optional(),
    transferAtomIds: external_exports.array(id).max(30).optional(),
    teaching: atomTeachingSchema.optional()
  });
  var learningScopeInputSchema = external_exports.object({
    subject,
    grade: external_exports.number().int().min(1).max(9),
    term: external_exports.enum(["upper", "lower"]),
    textbookVolumeId: id.nullable(),
    textbookVersion: external_exports.string().min(1).max(150),
    learnedAtomIds: external_exports.array(id).min(1).max(1e3),
    currentAtomId: id.nullable(),
    minutesPerSession: external_exports.number().int().min(5).max(60),
    progressMode: external_exports.enum(["knowledge", "textbook"]).default("knowledge"),
    selectedLessonIds: external_exports.array(id).max(1e3).default([])
  }).strict();
  var learningScopeSchema = learningScopeInputSchema.extend({
    id,
    studentId: id,
    version: external_exports.number().int().positive(),
    confirmedAt: external_exports.string(),
    textbookRevision: external_exports.string().optional(),
    mappingSnapshots: external_exports.array(external_exports.object({ id, version: external_exports.number().int().positive(), lessonId: id, atomIds: external_exports.array(id) })).optional(),
    uncoveredLessonIds: external_exports.array(id).optional(),
    selectedLessonSnapshots: external_exports.array(external_exports.object({ id, name: external_exports.string(), chapterName: external_exports.string() })).optional()
  });
  var componentBindingSchema = external_exports.object({
    id,
    atomId: id,
    scoreKeys: external_exports.array(id).min(1).max(20),
    requiresKeys: external_exports.array(id).max(20),
    rationale: external_exports.string().trim().min(10).max(1500),
    atomDefinitionFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/).optional()
  }).strict();
  var measurementItemSchema = external_exports.object({
    id,
    questionId: id,
    questionVersion: external_exports.number().int().positive(),
    atomId: id,
    dimension: dimensionSchema,
    family: external_exports.string().min(1).max(180),
    probeRole: external_exports.enum(["anchor", "prerequisite", "contrast", "transfer", "retention"]),
    expectedSeconds: external_exports.number().int().min(5).max(1200),
    difficulty: external_exports.number().int().min(1).max(5),
    reviewStatus: external_exports.enum(["draft", "approved", "rejected"]),
    mappingWeight: external_exports.number().positive().max(1),
    observationCode: external_exports.string().min(1).max(100),
    version: external_exports.number().int().positive(),
    atomDefinitionFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/).optional(),
    contentFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/).optional(),
    componentBindings: external_exports.array(componentBindingSchema).max(12).optional()
  });
  var diagnosticStartSchema = external_exports.object({
    studentId: id,
    subject,
    intent: external_exports.enum(["baseline", "unit", "phase", "micro", "verification", "retest"]).default("baseline"),
    targetAtomIds: external_exports.array(id).max(100).optional(),
    maxItems: external_exports.number().int().min(2).max(30).optional(),
    includePrerequisites: external_exports.boolean().default(false),
    hypothesisId: id.optional(),
    reviewTaskId: id.optional(),
    planId: id.optional(),
    adaptive: external_exports.boolean().optional()
  }).strict();
  var diagnosticResponseInputSchema = external_exports.object({
    itemId: id,
    answer: external_exports.unknown().optional(),
    elapsedMs: external_exports.number().int().min(0).max(36e5),
    disposition: external_exports.enum(["answered", "skip", "dont_know"]).default("answered"),
    requestKey: external_exports.string().min(1).max(180).optional(),
    draftFence: answerDraftFenceSchema.optional()
  }).strict();

  // packages/contracts/src/measurement-content.ts
  var id2 = external_exports.string().trim().min(1).max(180);
  var createMeasurementDraftSchema = (subject2, block, answerSchema) => external_exports.object({
    subject: subject2,
    grade: external_exports.number().int().min(1).max(9),
    stem: external_exports.string().trim().min(3).max(12e3),
    analysis: external_exports.string().trim().min(5).max(8e3),
    blocks: external_exports.array(block).max(40),
    answer: external_exports.unknown(),
    answerSchema: answerSchema.omit({ questionId: true }).strict(),
    mapping: external_exports.object({
      primaryAtomId: id2,
      prerequisiteAtomIds: external_exports.array(id2).max(30),
      secondaryAtomIds: external_exports.array(id2).max(30),
      dimension: dimensionSchema,
      family: external_exports.string().trim().min(3).max(180),
      probeRole: external_exports.enum(["anchor", "prerequisite", "contrast", "transfer", "retention"]),
      expectedSeconds: external_exports.number().int().min(5).max(1200),
      difficulty: external_exports.number().int().min(1).max(5),
      observationCode: external_exports.string().trim().min(3).max(100),
      observedSteps: external_exports.array(external_exports.string().trim().min(3).max(500)).min(1).max(12),
      rationale: external_exports.string().trim().min(10).max(2e3),
      familyRationale: external_exports.string().trim().min(10).max(1500)
    }).strict(),
    license: external_exports.object({
      licenseClass: external_exports.enum(["A_INTERNAL", "B_OPEN", "C_PUBLIC_REFERENCE_ONLY", "D_COMMERCIAL_PARTNER"]),
      evidence: external_exports.string().trim().min(10).max(4e3)
    }).strict(),
    scoringCases: external_exports.array(external_exports.object({
      response: external_exports.unknown(),
      expectedScore: external_exports.number().min(0).max(1),
      rationale: external_exports.string().trim().min(5).max(1200)
    }).strict()).min(2).max(12)
  }).strict();

  // packages/contracts/src/curriculum.ts
  var key = external_exports.string().min(1).max(180);
  var textbookMappingInputSchema = external_exports.object({
    bookId: key,
    lessonId: key,
    atomIds: external_exports.array(key).min(1).max(30),
    status: external_exports.enum(["candidate", "approved", "rejected"]),
    rationale: external_exports.string().trim().min(8).max(2e3)
  }).strict();
  var curriculumPackageSchema = external_exports.object({
    format: external_exports.literal("study-curriculum-package-v1"),
    title: external_exports.string().trim().min(3).max(200),
    provenance: external_exports.string().trim().min(10).max(2e3),
    atoms: external_exports.array(external_exports.object({ expectedVersion: external_exports.number().int().min(0), atom: knowledgeAtomSchema.strict() }).strict()).min(1).max(2e3)
  }).strict();

  // packages/contracts/src/reviews.ts
  var evidenceKindSchema = external_exports.enum(["diagnostic", "practice"]);
  var rubricRatingSchema = external_exports.object({
    criterionIndex: external_exports.number().int().min(0).max(99),
    score: external_exports.number().min(0).max(1),
    observation: external_exports.string().trim().min(1).max(1e3)
  }).strict();
  var scoringReviewInputSchema = external_exports.object({
    expectedVersion: external_exports.number().int().min(0),
    requestKey: external_exports.string().min(1).max(180),
    reason: external_exports.string().trim().min(5).max(2e3),
    ratings: external_exports.array(rubricRatingSchema).min(1).max(100).optional(),
    score: external_exports.number().min(0).max(1).optional()
  }).strict();
  var evidenceFeedbackInputSchema = external_exports.object({
    kind: evidenceKindSchema,
    responseId: external_exports.string().min(1).max(500),
    category: external_exports.enum(["grading", "ambiguous_question", "display", "learning_context", "other"]),
    message: external_exports.string().trim().min(5).max(3e3),
    requestKey: external_exports.string().min(1).max(180)
  }).strict();

  // packages/contracts/src/answer-protocol.ts
  var key2 = external_exports.string().min(1).max(120).refine((value) => !["__proto__", "prototype", "constructor"].includes(value) && !/[\x00-\x1f]/.test(value));
  var choice = external_exports.object({ id: key2, label: external_exports.string().min(1).max(500) });
  var list = external_exports.array(choice).min(1).max(80).refine((values) => new Set(values.map((value) => value.id)).size === values.length);
  var target = choice.extend({ x: external_exports.number().min(0).max(1), y: external_exports.number().min(0).max(1), width: external_exports.number().positive().max(1), height: external_exports.number().positive().max(1) }).refine((value) => value.x + value.width <= 1.000001 && value.y + value.height <= 1.000001);
  var targets = external_exports.array(target).min(1).max(80).refine((values) => new Set(values.map((value) => value.id)).size === values.length);
  var point = external_exports.object({ x: external_exports.number().min(0).max(1), y: external_exports.number().min(0).max(1) }).strict();
  var drawing = external_exports.object({ strokes: external_exports.array(external_exports.object({ points: external_exports.array(point).min(1).max(1024) }).strict()).max(64), description: external_exports.string().max(4e3).default("") }).strict().refine((value) => value.strokes.reduce((sum, stroke) => sum + stroke.points.length, 0) <= 1024);

  // packages/contracts/src/student-media.ts
  var studentMediaTargetSchema = external_exports.object({ kind: external_exports.enum(["diagnostic", "practice"]), sessionId: external_exports.string().min(1).max(180), itemId: external_exports.string().min(1).max(180) }).strict();
  var studentMediaStartSchema = studentMediaTargetSchema.extend({
    requestKey: external_exports.string().min(8).max(180),
    name: external_exports.string().trim().min(1).max(180),
    size: external_exports.number().int().positive().max(12 * 1024 * 1024),
    mediaType: external_exports.enum(["image/png", "image/jpeg", "audio/webm", "audio/ogg", "audio/wav", "audio/mpeg", "audio/mp4"])
  }).strict();

  // packages/contracts/src/gesp.ts
  var gespSearchSchema = external_exports.object({
    level: external_exports.coerce.number().int().min(1).max(8).optional(),
    session: external_exports.string().regex(/^(20\d{2}-(03|06|09|12)|sample)$/).optional(),
    kind: external_exports.enum(["choice", "true-false", "programming"]).optional(),
    sourceKind: external_exports.enum(["exam", "official_explanation", "sample", "mirror_exam"]).optional(),
    atomId: external_exports.string().regex(/^gesp-cpp\.l[1-8]\.[a-z-]+$/).max(120).optional(),
    q: external_exports.string().trim().max(100).optional(),
    page: external_exports.coerce.number().int().min(1).max(1e4).default(1),
    pageSize: external_exports.coerce.number().int().min(1).max(40).default(20)
  }).strict();
  var gespLearningScopeSchema = external_exports.object({
    level: external_exports.number().int().min(1).max(4),
    expectedVersion: external_exports.number().int().nonnegative().optional(),
    atomIds: external_exports.array(external_exports.string().regex(/^gesp-cpp\.l[1-4]\.[a-z-]+$/)).min(1).max(49),
    requestKey: external_exports.string().trim().min(8).max(120),
    reason: external_exports.string().trim().min(8).max(500)
  }).strict();
  var gespCodeSubmissionSchema = external_exports.object({
    studentId: external_exports.string().regex(/^student_[0-9a-f-]{36}$/),
    atomId: external_exports.string().regex(/^gesp-cpp\.l[1-4]\.[a-z-]+$/),
    source: external_exports.string().min(1).max(65536),
    requestKey: external_exports.string().trim().min(8).max(120),
    hintEventId: external_exports.string().regex(/^gesp_hint_[0-9a-f-]{36}$/).optional(),
    reviewTaskId: external_exports.string().regex(/^gesp_review_[0-9a-f-]{36}$/).optional()
  }).strict();
  var gespProbeSubmissionSchema = external_exports.object({
    studentId: external_exports.string().regex(/^student_[0-9a-f-]{36}$/),
    atomId: external_exports.string().regex(/^gesp-cpp\.l[1-4]\.[a-z-]+$/),
    probeId: external_exports.string().regex(/^gesp-student-[a-z0-9-]{3,80}-(concept|trace)$/),
    answer: external_exports.string().trim().min(1).max(500),
    requestKey: external_exports.string().trim().min(8).max(120)
  }).strict();
  var gespHintRequestSchema = external_exports.object({
    studentId: external_exports.string().regex(/^student_[0-9a-f-]{36}$/),
    atomId: external_exports.string().regex(/^gesp-cpp\.l[1-4]\.[a-z-]+$/),
    taskId: external_exports.string().regex(/^gesp-student-[a-z0-9-]{3,100}$/),
    level: external_exports.number().int().min(1).max(3),
    requestKey: external_exports.string().trim().min(8).max(120)
  }).strict();
  var gespGuidancePlanCreateSchema = external_exports.object({
    studentId: external_exports.string().regex(/^student_[0-9a-f-]{36}$/),
    scopeVersion: external_exports.number().int().positive(),
    minutesPerDay: external_exports.number().int().min(5).max(60),
    requestKey: external_exports.string().trim().min(8).max(120),
    reason: external_exports.string().trim().min(8).max(500)
  }).strict();
  var gespGuidancePlanDecisionSchema = external_exports.object({
    status: external_exports.enum(["active", "completed"]),
    expectedVersion: external_exports.number().int().positive(),
    requestKey: external_exports.string().trim().min(8).max(120),
    reason: external_exports.string().trim().min(8).max(500)
  }).strict();
  var gespTaskReviewGateSchema = external_exports.object({
    atomAlignment: external_exports.enum(["approved", "rejected"]),
    instructions: external_exports.enum(["approved", "rejected"]),
    probes: external_exports.enum(["approved", "rejected"]),
    hiddenTests: external_exports.enum(["approved", "rejected"]),
    executionSafety: external_exports.enum(["approved", "rejected"])
  }).strict();
  var gespTaskReviewInputSchema = external_exports.object({
    taskId: external_exports.string().regex(/^gesp-student-[a-z0-9-]{3,100}$/),
    expectedVersion: external_exports.number().int().min(0),
    gates: gespTaskReviewGateSchema,
    rationale: external_exports.string().trim().min(20).max(3e3),
    requestKey: external_exports.string().trim().min(8).max(120)
  }).strict();

  // packages/contracts/src/source-course.ts
  var text = (max) => external_exports.string().trim().min(1).max(max);
  var sourceCourseLessonContentSchema = external_exports.object({
    title: text(100),
    objective: text(350),
    introduction: text(400),
    concept: text(900),
    notes: external_exports.array(text(80)).min(2).max(5),
    example: external_exports.object({ scenario: text(500), steps: external_exports.array(text(200)).min(2).max(6), board: external_exports.array(text(80)).min(2).max(6), conclusion: text(350) }).strict(),
    misconception: external_exports.object({ claim: text(250), correction: text(500), board: external_exports.array(text(80)).min(2).max(3) }).strict(),
    transfer: text(500),
    summary: text(300),
    takeaways: external_exports.array(text(80)).min(2).max(4),
    citations: external_exports.array(external_exports.object({ sourceKey: text(100), quote: text(500) }).strict()).min(1).max(5),
    questions: external_exports.array(external_exports.object({
      prompt: text(700),
      options: external_exports.array(text(220)).length(4),
      answer: external_exports.number().int().min(0).max(3),
      explanation: text(600),
      hints: external_exports.array(text(200)).length(2)
    }).strict()).min(2).max(4)
  }).strict();
  var sourceCourseContentSchema = external_exports.object({ title: text(180), overview: text(700), lessons: external_exports.array(sourceCourseLessonContentSchema).min(1).max(6) }).strict();
  var compiledSourceCourseContentSchema = sourceCourseContentSchema.extend({ lessons: external_exports.array(sourceCourseLessonContentSchema).min(1).max(24) });

  // packages/contracts/src/studio-material-upload.ts
  var studioMaterialLimits = { bytes: 50 * 1024 * 1024, pages: 120, chunkBytes: 4 * 1024 * 1024, expiresHours: 24 };

  // packages/contracts/src/project-assets.ts
  var projectAssetLimits = { bytes: 20 * 1024 * 1024, textBytes: 1024 * 1024, chunkBytes: 1024 * 1024, attachments: 20, pdfPages: 120, audioSeconds: 180, expiresHours: 24 };
  var projectAssetTypes = [
    "image/png",
    "image/jpeg",
    "application/pdf",
    "text/plain",
    "text/markdown",
    "text/csv",
    "text/x-c++src",
    "audio/webm",
    "audio/ogg",
    "audio/wav",
    "audio/mpeg",
    "audio/mp4",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  ];
  var id3 = external_exports.string().min(1).max(200);
  var hash2 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var projectAssetUploadSchema = external_exports.object({ projectId: id3, stageId: id3, definitionFingerprint: hash2, name: external_exports.string().trim().min(1).max(255), size: external_exports.number().int().positive().max(projectAssetLimits.bytes), mediaType: external_exports.enum(projectAssetTypes), sha256: hash2, requestKey: external_exports.string().min(8).max(180) }).strict();

  // packages/contracts/src/paper-review.ts
  function isPaperReviewDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date5 = /* @__PURE__ */ new Date(value + "T12:00:00Z");
    return Number.isFinite(date5.getTime()) && date5.toISOString().slice(0, 10) === value;
  }
  var paperReviewDateSchema = external_exports.string().refine(isPaperReviewDate, "\u8BF7\u9009\u62E9\u6709\u6548\u7684\u672C\u5730\u65E5\u5386\u65E5\u671F");
  var reviewId = external_exports.string().trim().min(1).max(180);
  var paperReviewVerificationSchema = external_exports.object({ studentId: reviewId, atomId: reviewId, requestKey: external_exports.string().trim().min(8).max(180) }).strict();
  var paperReviewOrganizationInputSchema = external_exports.object({
    tags: external_exports.array(external_exports.string().trim().min(1).max(40)).max(20).transform((tags) => [...new Set(tags)].sort()),
    favorite: external_exports.boolean(),
    archived: external_exports.boolean(),
    errorSteps: external_exports.string().max(12e3),
    reflection: external_exports.string().max(12e3),
    plannedDate: paperReviewDateSchema.nullable()
  }).strict();

  // packages/contracts/src/paper-practice.ts
  var paperPracticeId = external_exports.string().trim().min(1).max(180);
  var paperPracticeKey = external_exports.string().trim().min(8).max(180);
  var paperPracticeSelectionSchema = external_exports.object({
    studentId: paperPracticeId.nullable().optional().default(null),
    selection: external_exports.array(external_exports.object({
      paperId: paperPracticeId,
      positions: external_exports.array(external_exports.number().int().positive()).min(1).max(500).optional()
    }).strict()).min(1).max(16),
    origin: external_exports.object({ sessionId: paperPracticeId, itemId: paperPracticeId }).strict().optional()
  }).strict();
  var paperPracticeCreationSchema = paperPracticeSelectionSchema.extend({ sourceHash: external_exports.string().regex(/^[a-f0-9]{64}$/), requestKey: paperPracticeKey }).strict();
  var paperPracticeCommandBase = { expectedVersion: external_exports.number().int().positive(), requestKey: paperPracticeKey };
  var paperPracticeCommandSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("draft"), itemId: paperPracticeId, text: external_exports.string().max(24e3) }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("submit"), itemId: paperPracticeId, disposition: external_exports.enum(["answered", "dont_know", "skip"]), text: external_exports.string().max(24e3) }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("reveal"), itemId: paperPracticeId }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("self_review"), itemId: paperPracticeId, value: external_exports.enum(["matches_reference", "needs_correction", "unsure"]) }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("correct"), itemId: paperPracticeId, text: external_exports.string().trim().min(1).max(24e3) }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("navigate"), itemId: paperPracticeId }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.enum(["pause", "resume", "complete"]), acknowledgeUnanswered: external_exports.boolean().optional() }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.literal("organize"), itemId: paperPracticeId, values: paperReviewOrganizationInputSchema }).strict(),
    external_exports.object({ ...paperPracticeCommandBase, kind: external_exports.enum(["review_complete", "review_reopen"]), itemId: paperPracticeId }).strict()
  ]);

  // packages/contracts/src/source-course-check.ts
  var text2 = (max) => external_exports.string().trim().min(1).max(max);
  var sourceCourseCheckSelectionSchema = external_exports.object({ modelId: text2(120), lessonIds: external_exports.array(text2(400)).min(1).max(6) }).strict().superRefine((value, context2) => {
    if (new Set(value.lessonIds).size !== value.lessonIds.length) context2.addIssue({ code: "custom", message: "\u6838\u67E5\u76EE\u6807\u4E0D\u80FD\u91CD\u590D", path: ["lessonIds"] });
  });
  var sourceCourseCheckQuestionSchema = external_exports.object({
    prompt: text2(700),
    targetLessonIds: external_exports.array(text2(400)).min(1).max(2),
    options: external_exports.array(text2(220)).min(4).max(6),
    selectionMode: external_exports.enum(["single", "multiple"]),
    correctIndices: external_exports.array(external_exports.number().int().min(0).max(5)).min(1).max(5),
    optionExplanations: external_exports.array(text2(400)).min(4).max(6),
    explanation: text2(700),
    hints: external_exports.array(text2(200)).length(2),
    citations: external_exports.array(external_exports.object({ sourceKey: text2(100), quote: text2(500) }).strict()).min(1).max(3)
  }).strict();
  var sourceCourseCheckContentSchema = external_exports.object({ title: text2(180), instructions: text2(700), questions: external_exports.array(sourceCourseCheckQuestionSchema).min(4).max(8) }).strict();

  // packages/contracts/src/topic-whiteboard-visual.ts
  var id4 = external_exports.string().min(1).max(180);
  var digest = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var requestKey = external_exports.string().min(8).max(180);
  var topicVisualIdSchema = external_exports.string().regex(/^topic_whiteboard_visual_[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/);
  var topicWhiteboardFigureSchema = external_exports.object({
    visualId: topicVisualIdSchema,
    alt: external_exports.string().trim().min(3).max(600),
    caption: external_exports.string().trim().max(600)
  }).strict();
  var context = {
    draftId: id4,
    sceneIndex: external_exports.number().int().min(0).max(7),
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: digest,
    purpose: external_exports.enum(["scene", "concept", "comparison"]),
    requirements: external_exports.string().trim().min(3).max(1200)
  };
  var generate = external_exports.object({ ...context, operation: external_exports.literal("generate") }).strict();
  var edit = external_exports.object({
    ...context,
    operation: external_exports.literal("edit"),
    parentVisualId: topicVisualIdSchema,
    changes: external_exports.string().trim().min(3).max(1200)
  }).strict();
  var topicVisualPreflightSchema = external_exports.discriminatedUnion("operation", [generate, edit]);
  var topicVisualGenerateSchema = generate.extend({ preflightFingerprint: digest, requestKey }).strict();
  var topicVisualEditSchema = edit.extend({ preflightFingerprint: digest, requestKey }).strict();
  var topicVisualControlSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    generation: external_exports.number().int().positive(),
    taskVersion: external_exports.number().int().positive(),
    requestKey
  }).strict();
  var topicVisualListSchema = external_exports.object({
    draftId: id4,
    sceneIndex: external_exports.coerce.number().int().min(0).max(7),
    page: external_exports.coerce.number().int().min(1).max(1e6).default(1),
    limit: external_exports.coerce.number().int().min(1).max(24).default(12),
    search: external_exports.string().trim().max(120).default("")
  }).strict();

  // packages/contracts/src/topic-whiteboard.ts
  var id5 = external_exports.string().min(1).max(180);
  var digest2 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var requestKey2 = external_exports.string().min(8).max(180);
  var topicWhiteboardAudienceSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("adult") }).strict(),
    external_exports.object({
      kind: external_exports.literal("student"),
      studentId: id5,
      subject: external_exports.enum(["math", "chinese", "english", "chemistry"]),
      atomIds: external_exports.array(id5).min(1).max(6).refine((values) => new Set(values).size === values.length, "\u4E0D\u80FD\u91CD\u590D\u9009\u62E9\u76EE\u6807")
    }).strict()
  ]);
  var topicWhiteboardInputSchema = external_exports.object({
    audience: topicWhiteboardAudienceSchema,
    prompt: external_exports.string().trim().min(3).max(2e3),
    objective: external_exports.string().trim().min(3).max(1e3),
    modelId: external_exports.string().trim().min(1).max(160).optional()
  }).strict();
  var topicWhiteboardCreateSchema = topicWhiteboardInputSchema.extend({ preflightFingerprint: digest2, requestKey: requestKey2 }).strict();
  var table = external_exports.object({
    kind: external_exports.literal("table"),
    headers: external_exports.array(external_exports.string().trim().min(1).max(120)).min(2).max(5),
    rows: external_exports.array(external_exports.array(external_exports.string().trim().min(1).max(240)).min(2).max(5)).min(1).max(12)
  }).strict().refine((value) => value.rows.every((row2) => row2.length === value.headers.length), "\u8868\u683C\u6BCF\u884C\u9700\u8981\u4E0E\u8868\u5934\u5217\u6570\u4E00\u81F4");
  var formula = external_exports.object({
    kind: external_exports.literal("formula"),
    latex: external_exports.string().trim().min(1).max(600),
    explanation: external_exports.string().trim().min(1).max(1e3)
  }).strict();
  var topicWhiteboardContentSchema = external_exports.object({
    title: external_exports.string().trim().min(1).max(120),
    description: external_exports.string().trim().min(3).max(600),
    scenes: external_exports.array(external_exports.object({
      kind: external_exports.enum(["title", "concept", "steps", "check"]),
      title: external_exports.string().trim().min(1).max(120),
      narration: external_exports.string().trim().min(3).max(1800),
      body: external_exports.string().trim().max(1e3),
      bullets: external_exports.array(external_exports.string().trim().min(1).max(240)).max(6),
      targetAtomIds: external_exports.array(id5).max(6),
      exhibit: external_exports.union([table, formula, external_exports.null()]),
      figure: topicWhiteboardFigureSchema.optional()
    }).strict()).min(3).max(8)
  }).strict().superRefine((value, context2) => {
    if (JSON.stringify(value).length > 22e3) context2.addIssue({ code: "custom", message: "\u767D\u677F\u5168\u6587\u8D85\u8FC7\u9884\u7B97\uFF0C\u8BF7\u51CF\u5C11\u8303\u56F4" });
    value.scenes.forEach((scene, index) => {
      if (new Set(scene.targetAtomIds).size !== scene.targetAtomIds.length) context2.addIssue({ code: "custom", path: ["scenes", index, "targetAtomIds"], message: "\u76EE\u6807\u4E0D\u80FD\u91CD\u590D" });
      if (scene.bullets.some((bullet) => !scene.narration.includes(bullet))) context2.addIssue({ code: "custom", path: ["scenes", index, "bullets"], message: "\u5B8C\u6574\u8981\u70B9\u9700\u8981\u5BF9\u5E94\u5230\u8FD9\u4E00\u5E55\u7684\u539F\u8BB2\u8FF0" });
    });
  });
  var topicWhiteboardControlSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    generation: external_exports.number().int().positive(),
    taskVersion: external_exports.number().int().positive(),
    requestKey: requestKey2
  }).strict();
  var topicWhiteboardEditSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: digest2,
    content: topicWhiteboardContentSchema,
    requestKey: requestKey2
  }).strict();
  var topicWhiteboardConfirmSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: digest2,
    acknowledgeAiGeneratedContent: external_exports.literal(true),
    acknowledgeUnreviewedChanges: external_exports.boolean(),
    requestKey: requestKey2
  }).strict();

  // packages/contracts/src/whiteboard-question-visual.ts
  var id6 = external_exports.string().min(1).max(180);
  var digest3 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var requestKey3 = external_exports.string().min(8).max(180);
  var questionVisualIdSchema = external_exports.string().regex(/^whiteboard_question_visual_[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/);
  var questionTeachingVersionIdSchema = external_exports.union([external_exports.literal("original"), external_exports.string().uuid()]);
  var questionVisualTargetSchema = external_exports.object({
    targetKind: external_exports.literal("whiteboard-question"),
    boardKind: external_exports.enum(["guidance", "topic"]),
    boardId: id6,
    turnId: id6,
    replyFingerprint: digest3,
    definitionHash: digest3
  }).strict();
  var fields = { target: questionVisualTargetSchema, purpose: external_exports.enum(["scene", "concept", "comparison"]), requirements: external_exports.string().trim().min(3).max(1200) };
  var generate2 = external_exports.object({ ...fields, operation: external_exports.literal("generate") }).strict();
  var edit2 = external_exports.object({ ...fields, operation: external_exports.literal("edit"), parentVisualId: questionVisualIdSchema, changes: external_exports.string().trim().min(3).max(1200) }).strict();
  var questionVisualPreflightSchema = external_exports.discriminatedUnion("operation", [generate2, edit2]);
  var questionVisualGenerateSchema = generate2.extend({ preflightFingerprint: digest3, requestKey: requestKey3 }).strict();
  var questionVisualEditSchema = edit2.extend({ preflightFingerprint: digest3, requestKey: requestKey3 }).strict();
  var questionVisualAdoptSchema = external_exports.object({
    target: questionVisualTargetSchema,
    visualId: questionVisualIdSchema,
    expectedTeachingVersionId: questionTeachingVersionIdSchema,
    expectedVisualRevision: external_exports.number().int().nonnegative(),
    originalSha256: digest3,
    imageSha256: digest3,
    alt: external_exports.string().trim().min(3).max(600),
    caption: external_exports.string().trim().max(600),
    acknowledgeImageReviewed: external_exports.literal(true),
    requestKey: requestKey3
  }).strict();

  // packages/contracts/src/assistant-artifact.ts
  var messageId = external_exports.string().min(1).max(180);
  var assistantArtifactSelectionSchema = external_exports.object({
    messageIds: external_exports.array(messageId).min(1).max(20).refine((ids) => new Set(ids).size === ids.length, "\u8BF7\u79FB\u9664\u91CD\u590D\u7684\u539F\u6D88\u606F"),
    includeLinkedQuestions: external_exports.boolean().default(false)
  }).strict();
  var assistantArtifactPreflightSchema = external_exports.object({
    kind: external_exports.literal("verbatim_note"),
    selection: assistantArtifactSelectionSchema,
    objective: external_exports.string().trim().min(1).max(500)
  }).strict();
  var noteTitle = external_exports.string().trim().min(1).max(160);
  var noteKey = external_exports.string().min(8).max(180);
  var noteHash = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var assistantNoteCreateSchema = assistantArtifactPreflightSchema.extend({
    title: noteTitle,
    preflightFingerprint: noteHash,
    requestKey: noteKey
  }).strict();
  var assistantNoteEditSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    title: noteTitle,
    // A note is a verbatim document: leading/trailing whitespace is meaningful.
    markdown: external_exports.string().min(1).max(3e4),
    requestKey: noteKey
  }).strict();
  var assistantNoteConfirmSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: noteHash,
    acknowledgeReview: external_exports.literal(true),
    requestKey: noteKey
  }).strict();
  var assistantNoteListSchema = external_exports.object({
    pageSize: external_exports.coerce.number().int().min(1).max(50).default(20),
    cursor: external_exports.string().min(1).max(1e3).optional()
  }).strict();

  // packages/contracts/src/assistant-whiteboard.ts
  var assistantWhiteboardPreflightSchema = external_exports.object({
    selection: assistantArtifactSelectionSchema,
    objective: external_exports.string().trim().min(3).max(500),
    modelId: external_exports.string().trim().min(1).max(160).optional(),
    acknowledgeHistoricalSource: external_exports.boolean().default(false)
  }).strict();
  var assistantWhiteboardCreateSchema = assistantWhiteboardPreflightSchema.extend({
    preflightFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/),
    requestKey: external_exports.string().min(8).max(180)
  }).strict();
  var assistantWhiteboardSourceMapSchema = external_exports.object({
    messageIds: external_exports.array(external_exports.string().min(1).max(180)).max(20).refine((values) => new Set(values).size === values.length, "\u539F\u6D88\u606F\u4E0D\u80FD\u91CD\u590D"),
    referenceKeys: external_exports.array(external_exports.string().min(1).max(180)).max(40).refine((values) => new Set(values).size === values.length, "\u539F\u5F15\u7528\u4E0D\u80FD\u91CD\u590D"),
    status: external_exports.enum(["sourced", "supplementary"]),
    explanation: external_exports.string().trim().min(3).max(600)
  }).strict().superRefine((value, context2) => {
    if (value.status === "sourced" && !value.messageIds.length)
      context2.addIssue({ code: "custom", path: ["messageIds"], message: "\u539F\u6587\u652F\u6301\u9700\u8981\u5BF9\u5E94\u539F\u6D88\u606F" });
    if (value.status === "supplementary" && value.referenceKeys.length)
      context2.addIssue({ code: "custom", path: ["referenceKeys"], message: "\u65B0\u589E\u89E3\u91CA\u4E0D\u80FD\u5192\u5145\u539F\u6587\u5F15\u7528" });
  });
  var assistantWhiteboardContentSchema = topicWhiteboardContentSchema.safeExtend({
    scenes: external_exports.array(topicWhiteboardContentSchema.shape.scenes.element.extend({ sourceMap: assistantWhiteboardSourceMapSchema })).min(3).max(8)
  });
  var assistantWhiteboardEditSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/),
    content: assistantWhiteboardContentSchema,
    requestKey: external_exports.string().min(8).max(180)
  }).strict();

  // packages/contracts/src/assistant-practice.ts
  var id7 = external_exports.string().min(1).max(180);
  var assistantPracticePreflightSchema = external_exports.object({
    selection: assistantArtifactSelectionSchema,
    objective: external_exports.string().trim().min(3).max(500),
    audience: external_exports.discriminatedUnion("kind", [external_exports.object({ kind: external_exports.literal("adult") }).strict(), external_exports.object({
      kind: external_exports.literal("student"),
      studentId: id7,
      subject: external_exports.enum(["math", "chinese", "english", "chemistry"]),
      targetAtomIds: external_exports.array(id7).min(1).max(3).refine((values) => new Set(values).size === values.length, "\u77E5\u8BC6\u76EE\u6807\u4E0D\u80FD\u91CD\u590D")
    }).strict()]),
    acknowledgeHistoricalSource: external_exports.boolean().default(false),
    acknowledgeAudienceTransfer: external_exports.boolean().default(false)
  }).strict();

  // packages/contracts/src/assistant-practice-content.ts
  var ASSISTANT_PRACTICE_CONTENT_PROTOCOL = "assistant-teaching-practice-content-v1";
  var ASSISTANT_PRACTICE_CONTENT_BUDGET = 22e3;
  var id8 = external_exports.string().trim().min(1).max(180);
  var text3 = (max) => external_exports.string().trim().min(3).max(max);
  var option = external_exports.object({ id: id8, label: external_exports.string().trim().min(1).max(600) }).strict();
  var unique = (values) => new Set(values).size === values.length;
  var normalizeAssistantPracticeOption = (label) => label.normalize("NFKC").trim().replace(/\s+/gu, " ").toLowerCase();
  var assistantPracticeQuestionSchema = external_exports.object({
    id: id8,
    kind: external_exports.enum(["classification", "open_response"]),
    prompt: text3(5e3),
    reasonPrompt: text3(1e3),
    options: external_exports.array(option).max(6),
    referenceOptionId: id8.nullable(),
    referenceExplanation: text3(4e3),
    applicableConditions: external_exports.array(text3(600)).min(1).max(6),
    reasoningCriteria: external_exports.array(text3(600)).min(1).max(6),
    hints: external_exports.array(text3(1200)).min(1).max(3),
    contrast: external_exports.object({ prompt: text3(2500), referenceExplanation: text3(2500) }).strict(),
    targetAtomIds: external_exports.array(id8).max(1),
    sourceMap: assistantWhiteboardSourceMapSchema
  }).strict().superRefine((value, context2) => {
    if (!unique(value.options.map((item) => item.id)) || !unique(value.options.map((item) => normalizeAssistantPracticeOption(item.label))))
      context2.addIssue({ code: "custom", path: ["options"], message: "\u9009\u9879ID\u548C\u89C4\u8303\u5316\u540E\u7684\u6587\u5B57\u5747\u4E0D\u80FD\u91CD\u590D" });
    if (value.kind === "classification" && (value.options.length < 2 || !value.options.some((item) => item.id === value.referenceOptionId)))
      context2.addIssue({ code: "custom", path: ["referenceOptionId"], message: "\u5206\u7C7B\u9898\u81F3\u5C11\u4E24\u4E2A\u9009\u9879\uFF0C\u53C2\u8003\u9009\u9879\u5FC5\u987B\u5C5E\u4E8E\u672C\u9898" });
    if (value.kind === "open_response" && (value.options.length || value.referenceOptionId !== null))
      context2.addIssue({ code: "custom", path: ["options"], message: "\u5F00\u653E\u8868\u8FBE\u4E0D\u5305\u542B\u5206\u7C7B\u9009\u9879\u6216\u53C2\u8003\u9009\u9879" });
  });
  var assistantPracticeContentSchema = external_exports.object({
    protocol: external_exports.literal(ASSISTANT_PRACTICE_CONTENT_PROTOCOL),
    title: text3(160),
    objective: text3(1e3),
    questions: external_exports.array(assistantPracticeQuestionSchema).min(2).max(6)
  }).strict().superRefine((value, context2) => {
    if (!unique(value.questions.map((item) => item.id))) context2.addIssue({ code: "custom", path: ["questions"], message: "\u9898\u76EEID\u4E0D\u80FD\u91CD\u590D" });
    if (JSON.stringify(value).length > ASSISTANT_PRACTICE_CONTENT_BUDGET)
      context2.addIssue({ code: "custom", message: "\u5B8C\u6574\u7EC3\u4E60\u6B63\u6587\u8D85\u8FC722000\u5B57\u7B26\uFF0C\u8BF7\u5B8C\u6574\u8C03\u6574\uFF1B\u6CA1\u6709\u622A\u65AD" });
  });
  var assistantPracticeContentReviewSchema = external_exports.object({
    decision: external_exports.enum(["pass", "revised", "uncertain"]),
    issues: external_exports.array(text3(600)).max(12),
    revisedContent: assistantPracticeContentSchema.nullable()
  }).strict().superRefine((value, context2) => {
    if (value.decision === "pass" && (value.issues.length || value.revisedContent !== null))
      context2.addIssue({ code: "custom", message: "\u901A\u8FC7\u9700\u65E0\u95EE\u9898\u4E14\u65E0\u4FEE\u6539" });
    if (value.decision === "revised" && (!value.issues.length || value.revisedContent === null))
      context2.addIssue({ code: "custom", message: "\u4FEE\u8BA2\u9700\u5177\u4F53\u95EE\u9898\u53CA\u5B8C\u6574\u6B63\u6587" });
    if (value.decision === "uncertain" && (!value.issues.length || value.revisedContent !== null))
      context2.addIssue({ code: "custom", message: "\u4E0D\u786E\u5B9A\u9700\u5217\u51FA\u95EE\u9898\u5E76\u4FDD\u7559\u539F\u7A3F" });
  });
  var assistantPracticeContentInputSchema = assistantPracticePreflightSchema.extend({ modelId: id8.optional() }).strict();
  var target2 = knowledgeAtomSchema.pick({ name: true, objective: true, subject: true, grade: true, term: true }).extend({
    atomId: id8,
    definitionFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/)
  }).strict();
  var assistantPracticeTargetScopeSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("adult") }).strict(),
    external_exports.object({
      kind: external_exports.literal("student"),
      studentId: id8,
      subject: external_exports.enum(["math", "chinese", "english", "chemistry"]),
      scopeGrade: learningScopeInputSchema.shape.grade,
      scopeTerm: learningScopeInputSchema.shape.term,
      scopeVersion: external_exports.number().int().min(1),
      profileGrade: external_exports.number().int().min(1).max(12),
      scopeFingerprint: external_exports.string().regex(/^[a-f0-9]{64}$/),
      targets: external_exports.array(target2).min(1).max(3)
    }).strict()
  ]);

  // packages/contracts/src/assistant-reviewed-practice.ts
  var hash3 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var key3 = external_exports.string().min(8).max(180);
  var assistantReviewedPracticeCreateSchema = assistantPracticePreflightSchema.extend({
    contentMode: external_exports.literal("reviewed_bank"),
    preflightFingerprint: hash3,
    requestKey: key3
  }).strict().superRefine((value, context2) => {
    if (value.audience.kind !== "student") context2.addIssue({ code: "custom", path: ["audience"], message: "\u5BA1\u6838\u9898\u8BAD\u7EC3\u9700\u8981\u660E\u786E\u5B69\u5B50\u3001\u5B66\u79D1\u548C\u539F\u5B50\u70B9\uFF1B\u6210\u4EBA\u8BF7\u4F7F\u7528\u672C\u4EBA\u6559\u5B66\u7EC3\u4E60" });
  });
  var assistantReviewedPracticeEditSchema = external_exports.object({
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: hash3,
    title: external_exports.string().trim().min(1).max(160),
    instructions: external_exports.string().trim().min(3).max(3e3),
    requestKey: key3
  }).strict();

  // packages/contracts/src/assistant-practice-assignment.ts
  var hash4 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var assistantPracticeAssignSchema = external_exports.object({
    studentId: external_exports.string().min(1).max(180),
    expectedRevision: external_exports.number().int().nonnegative(),
    contentFingerprint: hash4,
    acknowledgePreview: external_exports.literal(true),
    requestKey: external_exports.string().min(8).max(180)
  }).strict();
  var assistantPracticeAssignmentsQuerySchema = external_exports.object({
    studentId: external_exports.string().min(1).max(180),
    subject: external_exports.enum(["math", "chinese", "english", "chemistry"]),
    pageSize: external_exports.coerce.number().int().min(1).max(30).default(10),
    cursor: external_exports.string().min(1).max(2e3).optional()
  }).strict();
  var assistantPracticeAssignmentWithdrawSchema = external_exports.object({
    expectedStateVersion: external_exports.literal(0),
    assignmentFingerprint: hash4,
    reason: external_exports.string().trim().min(5).max(500),
    requestKey: external_exports.string().min(8).max(180)
  }).strict();

  // packages/contracts/src/assistant-practice-learner.ts
  var ASSISTANT_PRACTICE_ANSWER_PROTOCOL = "assistant-practice-answer-v1";
  var key4 = external_exports.string().min(8).max(180);
  var hash5 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var assistantPracticeGroupStartSchema = external_exports.object({ assignmentFingerprint: hash5, requestKey: key4 }).strict();
  var assistantPracticeLearnerDraftSchema = external_exports.object({
    protocol: external_exports.literal(ASSISTANT_PRACTICE_ANSWER_PROTOCOL),
    actorId: external_exports.string().min(1).max(180),
    expectedRevision: external_exports.number().int().nonnegative(),
    baseHash: hash5,
    attempt: external_exports.number().int().min(0).max(5),
    answer: external_exports.unknown(),
    learnerExplanation: external_exports.string().max(3e3),
    requestKey: key4
  }).strict();
  var assistantPracticeLearnerResponseSchema = external_exports.object({
    protocol: external_exports.literal(ASSISTANT_PRACTICE_ANSWER_PROTOCOL),
    questionId: external_exports.string().min(1).max(180),
    requestKey: key4,
    answer: external_exports.unknown().optional(),
    learnerExplanation: external_exports.string().trim().max(3e3),
    disposition: external_exports.enum(["answered", "skip"]),
    elapsedMs: external_exports.number().int().min(0).max(36e5),
    draftFence: answerDraftFenceSchema
  }).strict().superRefine((value, context2) => {
    if (value.disposition === "answered" && !value.learnerExplanation)
      context2.addIssue({ code: "custom", path: ["learnerExplanation"], message: "\u8BF7\u8BF4\u660E\u5224\u65AD\u7406\u7531\uFF0C\u6216\u660E\u786E\u5199\u6682\u4E0D\u6E05\u695A\uFF1B\u539F\u7B54\u6848\u4ECD\u53EF\u4FDD\u7559" });
  });
  var assistantPracticeHelpSchema = external_exports.object({
    protocol: external_exports.literal(ASSISTANT_PRACTICE_ANSWER_PROTOCOL),
    kind: external_exports.enum(["hint", "solution", "guardian_demonstration"]),
    expectedAttempt: external_exports.number().int().min(0).max(5),
    baseHash: hash5,
    requestKey: key4
  }).strict();
  var assistantPracticeCompleteSchema = external_exports.object({
    protocol: external_exports.literal(ASSISTANT_PRACTICE_ANSWER_PROTOCOL),
    completionFingerprint: hash5,
    requestKey: key4
  }).strict();

  // packages/contracts/src/assistant-teaching-practice.ts
  var id9 = external_exports.string().trim().min(1).max(180);
  var hash6 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var assistantTeachingCreateSchema = assistantPracticeContentInputSchema.extend({ preflightFingerprint: hash6, requestKey: id9 }).strict();
  var assistantTeachingControlSchema = external_exports.object({ expectedRevision: external_exports.number().int().nonnegative(), expectedTaskVersion: external_exports.number().int().positive(), requestKey: id9 }).strict();
  var assistantTeachingContentCommandSchema = external_exports.object({ expectedRevision: external_exports.number().int().nonnegative(), contentFingerprint: hash6, requestKey: id9 }).strict();
  var assistantTeachingEditSchema = assistantTeachingContentCommandSchema.extend({ content: assistantPracticeContentSchema }).strict();
  var assistantTeachingListSchema = external_exports.object({ cursor: external_exports.string().max(2e3).optional(), pageSize: external_exports.coerce.number().int().min(1).max(20).default(10) }).strict();

  // packages/contracts/src/assistant-teaching-learner.ts
  var id10 = external_exports.string().min(1).max(180);
  var hash7 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var ASSISTANT_TEACHING_ANSWER_PROTOCOL = "assistant-teaching-answer-v1";
  var assistantTeachingAnswerSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("classification"), optionId: id10 }).strict(),
    external_exports.object({ kind: external_exports.literal("open_response"), text: external_exports.string().min(1).max(5e3).refine((value) => value.trim().length > 0, "\u8BF7\u4FDD\u7559\u5B8C\u6574\u8868\u8FBE\u3002") }).strict()
  ]);
  var assistantTeachingSelfStartSchema = external_exports.object({ contentFingerprint: hash7, requestKey: id10 }).strict();
  var assistantTeachingDraftSchema = external_exports.object({ protocol: external_exports.literal(ASSISTANT_TEACHING_ANSWER_PROTOCOL), questionId: id10, actorId: id10, expectedRevision: external_exports.number().int().nonnegative(), baseHash: hash7, attempt: external_exports.number().int().nonnegative(), answer: assistantTeachingAnswerSchema, learnerExplanation: external_exports.string().max(3e3), requestKey: id10 }).strict();
  var assistantTeachingResponseSchema = external_exports.object({ protocol: external_exports.literal(ASSISTANT_TEACHING_ANSWER_PROTOCOL), questionId: id10, answer: assistantTeachingAnswerSchema, learnerExplanation: external_exports.string().min(1).max(3e3).refine((value) => value.trim().length > 0, "\u8BF7\u4FDD\u7559\u81EA\u5DF1\u7684\u5B8C\u6574\u7406\u7531\u3002"), draftFence: answerDraftFenceSchema, requestKey: id10 }).strict();
  var assistantTeachingHelpSchema = external_exports.object({ protocol: external_exports.literal(ASSISTANT_TEACHING_ANSWER_PROTOCOL), questionId: id10, kind: external_exports.enum(["hint", "solution", "guardian_demonstration"]), baseHash: hash7, expectedAttempt: external_exports.number().int().nonnegative(), requestKey: id10 }).strict();
  var assistantTeachingCompleteSchema = external_exports.object({ protocol: external_exports.literal(ASSISTANT_TEACHING_ANSWER_PROTOCOL), completionFingerprint: hash7, requestKey: id10 }).strict();

  // packages/contracts/src/assistant-teaching-assignment.ts
  var id11 = external_exports.string().min(1).max(180);
  var hash8 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var assistantTeachingAssignSchema = external_exports.object({ studentId: id11, contentFingerprint: hash8, instructions: external_exports.string().min(3).max(3e3).refine((value) => value.trim().length >= 3), acknowledgePreview: external_exports.literal(true), requestKey: id11 }).strict();
  var assistantTeachingStudentStartSchema = external_exports.object({ assignmentFingerprint: hash8, requestKey: id11 }).strict();
  var assistantTeachingAssignmentWithdrawSchema = external_exports.object({ assignmentFingerprint: hash8, expectedStateVersion: external_exports.literal(0), reason: external_exports.string().min(3).max(3e3).refine((value) => value.trim().length >= 3), acknowledgeReadonlyHistory: external_exports.literal(true), requestKey: id11 }).strict();
  var assistantTeachingAssignmentsQuerySchema = external_exports.object({ studentId: id11, subject: external_exports.enum(["math", "chinese", "english", "chemistry"]), pageSize: external_exports.coerce.number().int().min(1).max(20).default(10), cursor: external_exports.string().max(2e3).optional() }).strict();

  // packages/contracts/src/assistant-guidance.ts
  var id12 = external_exports.string().min(1).max(180);
  var hash9 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var text4 = (max) => external_exports.string().min(3).max(max).refine((value) => value.trim().length >= 3, "\u8BF7\u4FDD\u7559\u5B8C\u6574\u4E14\u53EF\u89C2\u5BDF\u7684\u8BF4\u660E\u3002");
  var assistantGuidanceObservationSchema = external_exports.object({ observedBehaviour: text4(3e3), conditions: text4(3e3), question: text4(1500), alternativeExplanations: external_exports.array(text4(800)).min(1).max(6) }).strict();
  var assistantGuidancePreflightSchema = assistantPracticePreflightSchema.extend({ observation: assistantGuidanceObservationSchema }).strict();
  var assistantGuidanceCreateSchema = assistantGuidancePreflightSchema.extend({ preflightFingerprint: hash9, requestKey: id12 }).strict();
  var assistantGuidanceEditSchema = external_exports.object({ expectedRevision: external_exports.number().int().positive(), contentFingerprint: hash9, observation: assistantGuidanceObservationSchema, requestKey: id12 }).strict();
  var assistantGuidanceReportPreflightSchema = external_exports.object({ sessionId: id12, reportVersion: external_exports.number().int().positive() }).strict();
  var assistantGuidanceReportLinkSchema = assistantGuidanceReportPreflightSchema.extend({ expectedRevision: external_exports.number().int().positive(), contentFingerprint: hash9, reportFingerprint: hash9, requestKey: id12, acknowledgeEvidenceSeparation: external_exports.literal(true) }).strict();
  var assistantGuidancePlanSchema = external_exports.object({ expectedRevision: external_exports.number().int().positive(), contentFingerprint: hash9, reportFingerprint: hash9, minutesPerDay: external_exports.number().int().min(5).max(60), requestKey: id12, acknowledgeProposedPlan: external_exports.literal(true) }).strict();
  var assistantGuidanceListSchema = external_exports.object({ pageSize: external_exports.coerce.number().int().min(1).max(20).default(10), cursor: external_exports.string().max(2e3).optional() }).strict();

  // packages/contracts/src/guidance-calendar.ts
  var id13 = external_exports.string().min(1).max(220);
  var hash10 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var time3 = {
    localDate: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    localTime: external_exports.string().regex(/^\d{2}:\d{2}$/),
    offsetMinutes: external_exports.number().int().min(-840).max(840),
    durationMinutes: external_exports.number().int().min(5).max(60)
  };
  var guidanceCalendarEntrySchema = external_exports.discriminatedUnion("sourceKind", [
    external_exports.object({ ...time3, sourceKind: external_exports.literal("action"), entryKey: external_exports.string().min(1).max(650), actionId: id13, occurrenceKey: external_exports.uuid() }).strict(),
    external_exports.object({
      ...time3,
      sourceKind: external_exports.literal("review"),
      entryKey: external_exports.string().min(1).max(650),
      reviewTaskId: id13,
      rescheduleReason: external_exports.string().trim().max(1500).default(""),
      acknowledgeDueAtChange: external_exports.boolean().default(false)
    }).strict()
  ]).superRefine((entry, context2) => {
    const expected2 = entry.sourceKind === "action" ? `action:${entry.actionId}:${entry.occurrenceKey}` : `review:${entry.reviewTaskId}`;
    if (entry.entryKey !== expected2) context2.addIssue({ code: "custom", message: "\u6761\u76EE\u6807\u8BC6\u4E0E\u539F\u6D3B\u52A8\u6216\u539F\u590D\u6D4B\u4E0D\u4E00\u81F4\u3002" });
  });
  var guidanceCalendarInputSchema = external_exports.object({
    protocol: external_exports.literal("guidance-calendar-input-v1"),
    planId: id13,
    expectedPlanRevision: external_exports.number().int().positive(),
    timeZone: external_exports.string().min(1).max(100),
    dailyBudgetMinutes: external_exports.number().int().min(10).max(180),
    entries: external_exports.array(guidanceCalendarEntrySchema).max(60)
  }).strict().superRefine((input2, context2) => {
    if (new Set(input2.entries.map((entry) => entry.entryKey)).size !== input2.entries.length) context2.addIssue({ code: "custom", message: "\u540C\u4E00\u539F\u5B89\u6392\u4E0D\u80FD\u91CD\u590D\u51FA\u73B0\u3002" });
  });
  var guidanceCalendarConfirmSchema = external_exports.object({
    input: guidanceCalendarInputSchema,
    preflightFingerprint: hash10,
    expectedArrangementRevision: external_exports.number().int().positive().nullable(),
    requestKey: external_exports.string().min(8).max(180),
    acknowledgeExactSchedule: external_exports.literal(true)
  }).strict();
  var guidanceCalendarReviseSchema = guidanceCalendarConfirmSchema.extend({ reason: external_exports.string().trim().min(5).max(3e3) }).strict();

  // packages/contracts/src/controlled-contrast.ts
  var controlledId = external_exports.string().min(1).max(180);
  var controlledHash = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var controlledKey = external_exports.string().min(8).max(180);
  var controlledPreviewInputSchema = external_exports.object({ protocol: external_exports.literal("controlled-preview-input-v1"), studentId: controlledId, subject: external_exports.enum(["math", "chinese", "english", "chemistry"]), publicationId: controlledId, expectedPublicationFingerprint: controlledHash, expectedScopeId: controlledId, expectedScopeVersion: external_exports.number().int().positive(), independentUnits: external_exports.number().int().min(2).max(20), maxItems: external_exports.number().int().min(0).max(40), maxSeconds: external_exports.number().int().min(0).max(600), requestKey: controlledKey }).strict();
  var controlledStartInputSchema = external_exports.object({ protocol: external_exports.literal("controlled-start-input-v1"), expectedPreviewFingerprint: controlledHash, acknowledgeActualChild: external_exports.literal(true), requestKey: controlledKey }).strict();

  // packages/contracts/src/paper-capture-origin.ts
  var PAPER_CAPTURE_PDF_RENDERER = "pdf-lib-1.17.1/a4-contain-24pt-v1";
  var PAPER_CAPTURE_PDF_NOTICE = "\u56FE\u7247\u7EC4\u7684\u6D3E\u751FPDF\uFF1B\u539F\u4E0A\u4F20\u56FE\u7247\u4E0E\u539F\u9875\u8EAB\u4EFD\u72EC\u7ACB\u4FDD\u7559\u3002PDF\u9875\u53F7\u4EC5\u5BF9\u5E94\u8FD9\u4EFD\u51BB\u7ED3\u7EC4\u7248\u672C\uFF0C\u4E0D\u8868\u793A\u539F\u4E66\u9875\u7801\u6216\u5185\u5BB9\u5BA1\u6838\u3002";
  var id14 = external_exports.string().min(1).max(180);
  var hash11 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var dimension = external_exports.number().int().positive().max(6e3);
  var paperCapturePdfPageSchema = external_exports.object({
    page: external_exports.number().int().min(1).max(120),
    pageId: id14,
    originalSha256: hash11,
    baselineSha256: hash11,
    versionFingerprint: hash11,
    renderedSha256: hash11,
    width: dimension,
    height: dimension,
    pdfWidth: external_exports.number().positive(),
    pdfHeight: external_exports.number().positive(),
    imageBox: external_exports.object({ x: external_exports.number().nonnegative(), y: external_exports.number().nonnegative(), width: external_exports.number().positive(), height: external_exports.number().positive() }).strict(),
    coordinateSpace: external_exports.literal("pdf-bottom-left-points-v1")
  }).strict();
  var paperCapturePdfReceiptSchema = external_exports.object({ protocol: external_exports.literal("paper-capture-derived-pdf-v1"), groupId: id14, groupRevision: external_exports.number().int().positive(), groupFingerprint: hash11, renderer: external_exports.literal(PAPER_CAPTURE_PDF_RENDERER), pdfSha256: hash11, pdfBytes: external_exports.number().int().positive().max(80 * 1024 * 1024), pages: external_exports.array(paperCapturePdfPageSchema).min(1).max(120), fingerprint: hash11, notice: external_exports.literal(PAPER_CAPTURE_PDF_NOTICE) }).strict();

  // packages/contracts/src/paper-capture.ts
  var id15 = external_exports.string().min(1).max(180);
  var hash12 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var time4 = external_exports.string().datetime({ offset: true });
  var dimension2 = external_exports.number().int().min(1).max(6e3);
  var requestKey4 = external_exports.string().min(8).max(180);
  var paperCaptureIntentSchema = external_exports.enum(["single_question", "whole_page", "material_collection"]);
  var audience = { studentId: id15.nullable(), subject: external_exports.enum(["math", "chinese", "english", "chemistry"]).nullable() };
  var paperCapturePrivateScopeSchema = external_exports.object({ actorId: id15, ...audience }).strict().refine((value) => Boolean(value.studentId) === Boolean(value.subject));
  var paperCaptureScopeSchema = external_exports.object({ creatorFingerprint: hash12, ...audience }).strict().refine((value) => Boolean(value.studentId) === Boolean(value.subject));
  var paperImageSourceSchema = external_exports.object({ protocol: external_exports.literal("paper-image-source-v1"), pageId: id15, originalSha256: hash12, originalBytes: external_exports.number().int().min(5).max(12 * 1024 * 1024), originalMediaType: external_exports.enum(["image/png", "image/jpeg"]), baselineSha256: hash12, width: dimension2, height: dimension2 }).strict();
  var paperImageTransformSchema = external_exports.object({ crop: external_exports.object({ x: external_exports.number().int().min(0), y: external_exports.number().int().min(0), width: dimension2, height: dimension2 }).strict(), rotation: external_exports.union([external_exports.literal(0), external_exports.literal(90), external_exports.literal(180), external_exports.literal(270)]) }).strict();
  var paperImageVersionSchema = external_exports.object({ protocol: external_exports.literal("paper-image-version-v1"), pageId: id15, originalSha256: hash12, baselineSha256: hash12, coordinateSpace: external_exports.literal("normalized-original-pixels-v1"), transform: paperImageTransformSchema, width: dimension2, height: dimension2, fingerprint: hash12 }).strict();
  var paperCaptureGroupInputSchema = external_exports.object({ protocol: external_exports.literal("paper-capture-group-input-v1"), title: external_exports.string().trim().min(1).max(180), intent: paperCaptureIntentSchema, expectedRevision: external_exports.number().int().min(0), pages: external_exports.array(external_exports.object({ pageId: id15, versionFingerprint: hash12 }).strict()).min(1).max(120) }).strict();
  var paperCaptureGroupVersionSchema = external_exports.object({ protocol: external_exports.literal("paper-capture-group-version-v1"), groupId: id15, scope: paperCaptureScopeSchema, revision: external_exports.number().int().positive(), previousFingerprint: hash12.nullable(), title: external_exports.string().trim().min(1).max(180), intent: paperCaptureIntentSchema, pages: external_exports.array(external_exports.object({ pageId: id15, originalSha256: hash12, baselineSha256: hash12, versionFingerprint: hash12, renderedSha256: hash12, width: dimension2, height: dimension2 }).strict()).min(1).max(120), originalBytes: external_exports.number().int().min(5).max(50 * 1024 * 1024), fingerprint: hash12 }).strict();
  var paperCapturePendingCommandSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("upload"), requestKey: requestKey4, input: external_exports.object({ protocol: external_exports.literal("paper-image-upload-input-v1"), scope: paperCaptureScopeSchema, pageId: id15, name: external_exports.string().min(1).max(255), size: external_exports.number().int().min(5).max(12 * 1024 * 1024), sha256: hash12, mediaType: external_exports.enum(["image/png", "image/jpeg"]) }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("completeUpload"), requestKey: requestKey4, uploadId: id15, input: external_exports.object({ protocol: external_exports.literal("paper-image-upload-complete-v1"), expectedRevision: external_exports.number().int().min(0) }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("cancelUpload"), requestKey: requestKey4, uploadId: id15, input: external_exports.object({ protocol: external_exports.literal("paper-image-upload-cancel-v1"), expectedRevision: external_exports.number().int().min(0) }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("pageRevision"), requestKey: requestKey4, pageId: id15, input: external_exports.object({ protocol: external_exports.literal("paper-image-revision-input-v1"), expectedRevision: external_exports.number().int().positive(), expectedVersionFingerprint: hash12, transform: paperImageTransformSchema }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("groupRevision"), requestKey: requestKey4, groupId: id15, input: paperCaptureGroupInputSchema }).strict(),
    external_exports.object({ kind: external_exports.literal("recognize"), requestKey: requestKey4, groupId: id15, input: external_exports.object({ protocol: external_exports.literal("paper-capture-recognize-input-v1"), expectedRevision: external_exports.number().int().positive(), expectedFingerprint: hash12, acknowledgePageOrder: external_exports.literal(true) }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("cancelDerivation"), requestKey: requestKey4, groupId: id15, derivationId: id15, input: external_exports.object({ protocol: external_exports.literal("paper-capture-derivation-cancel-v1"), expectedTaskVersion: external_exports.number().int().positive(), expectedGeneration: external_exports.number().int().positive() }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("retryDerivation"), requestKey: requestKey4, groupId: id15, derivationId: id15, input: external_exports.object({ protocol: external_exports.literal("paper-capture-derivation-retry-v1"), expectedTaskVersion: external_exports.number().int().positive(), expectedGeneration: external_exports.number().int().positive() }).strict() }).strict()
  ]);
  var paperCaptureCommandResultSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("upload"), uploadId: id15, pageId: id15, chunkSize: external_exports.literal(1024 * 1024), createdAt: time4, expiresAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("completeUpload"), uploadId: id15, pageId: id15, revision: external_exports.literal(1), versionFingerprint: hash12, completedAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("cancelUpload"), uploadId: id15, revision: external_exports.number().int().positive(), cancelledAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("pageRevision"), pageId: id15, revision: external_exports.number().int().positive(), versionFingerprint: hash12, savedAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("groupRevision"), groupId: id15, revision: external_exports.number().int().positive(), fingerprint: hash12, savedAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("recognize"), derivationId: id15, groupId: id15, groupRevision: external_exports.number().int().positive(), groupFingerprint: hash12, taskId: id15, taskVersion: external_exports.literal(1), taskGeneration: external_exports.literal(1), createdAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("cancelDerivation"), derivationId: id15, groupId: id15, taskId: id15, taskVersion: external_exports.number().int().positive(), taskGeneration: external_exports.number().int().positive(), acceptedAt: time4 }).strict(),
    external_exports.object({ kind: external_exports.literal("retryDerivation"), derivationId: id15, groupId: id15, taskId: id15, taskVersion: external_exports.number().int().positive(), taskGeneration: external_exports.number().int().positive(), acceptedAt: time4 }).strict()
  ]);
  var paperCaptureCommandLookupSchema = external_exports.discriminatedUnion("state", [
    external_exports.object({ state: external_exports.literal("unknown"), requestKey: requestKey4 }).strict(),
    ...["preparing", "committed", "rejected"].map((state) => external_exports.object({ state: external_exports.literal(state), requestKey: requestKey4, input: paperCapturePendingCommandSchema, scope: paperCaptureScopeSchema, result: paperCaptureCommandResultSchema.nullable(), errorCode: external_exports.string().nullable(), generation: external_exports.number().int().positive() }).strict())
  ]);
  var paperCaptureUploadCommandsSchema = external_exports.object({ uploadId: id15, initialization: paperCaptureCommandLookupSchema, terminal: paperCaptureCommandLookupSchema.nullable() }).strict();
  var paperCaptureUploadViewSchema = external_exports.object({ id: id15, pageId: id15, scope: paperCaptureScopeSchema, name: external_exports.string().min(1).max(255), size: external_exports.number().int().min(5).max(12 * 1024 * 1024), sha256: hash12, mediaType: external_exports.enum(["image/png", "image/jpeg"]), chunkSize: external_exports.literal(1024 * 1024), chunks: external_exports.array(external_exports.object({ index: external_exports.number().int().min(0).max(11), sha256: hash12, bytes: external_exports.number().int().positive().max(1024 * 1024) }).strict()).max(12), revision: external_exports.number().int().min(0).max(13), status: external_exports.enum(["uploading", "completed", "cancelled"]), createdAt: time4, expiresAt: time4, endedAt: time4.nullable() }).strict();
  var paperCapturePageViewSchema = external_exports.object({ id: id15, filename: external_exports.string().min(1).max(255), scope: paperCaptureScopeSchema, revision: external_exports.number().int().positive(), selectedVersionFingerprint: hash12, canEdit: external_exports.boolean(), ownerClosed: external_exports.boolean(), source: paperImageSourceSchema, versions: external_exports.array(external_exports.object({ version: paperImageVersionSchema, createdAt: time4 }).strict()).min(1) }).strict();
  var paperCaptureGroupViewSchema = external_exports.object({ id: id15, scope: paperCaptureScopeSchema, revision: external_exports.number().int().positive(), createdAt: time4, ownerClosed: external_exports.boolean(), canEdit: external_exports.boolean(), history: external_exports.array(external_exports.object({ version: paperCaptureGroupVersionSchema, at: time4 }).strict()).min(1).max(1e3), current: paperCaptureGroupVersionSchema }).strict();
  var paperCaptureDerivationViewSchema = external_exports.object({
    id: id15,
    scope: paperCaptureScopeSchema,
    groupId: id15,
    groupRevision: external_exports.number().int().positive(),
    groupFingerprint: hash12,
    sourceChanged: external_exports.boolean(),
    createdAt: time4,
    ownerClosed: external_exports.boolean(),
    status: external_exports.enum(["pdf_ready", "unavailable", "processing", "cancelling", "queued", "cancelled", "failed", "succeeded"]),
    pdf: paperCapturePdfReceiptSchema.nullable(),
    materialId: id15.nullable(),
    publishedAt: time4.nullable(),
    canCancel: external_exports.boolean(),
    canRetry: external_exports.boolean(),
    task: external_exports.object({ id: id15, state: external_exports.enum(["queued", "running", "retry_wait", "cancel_requested", "cancelled", "succeeded", "failed"]), version: external_exports.number().int().positive(), generation: external_exports.number().int().positive(), errorCode: external_exports.string().nullable(), stage: external_exports.string().nullable() }).strict().nullable(),
    recognition: external_exports.object({ materialId: id15, status: external_exports.enum(["queued", "processing", "ready", "needs_review", "failed", "cancelled"]).optional(), pageCount: external_exports.number().int().min(0), processedPages: external_exports.number().int().min(0), reviewRequired: external_exports.boolean() }).strict().nullable()
  }).strict();
  var paperCaptureLimitsSchema = external_exports.object({ mediaTypes: external_exports.array(external_exports.enum(["image/png", "image/jpeg"])), imageBytes: external_exports.number().int().positive(), imagePixels: external_exports.number().int().positive(), imageDimension: external_exports.number().int().positive(), chunkBytes: external_exports.number().int().positive(), groupPages: external_exports.number().int().positive(), groupOriginalBytes: external_exports.number().int().positive(), wholePageImages: external_exports.literal(1), singleQuestionImages: external_exports.literal(4), derivedPdfPixels: external_exports.number().int().positive(), derivedPdfBytes: external_exports.number().int().positive() }).strict();
  var copyByteLimit = 50 * 1024 * 1024;
  var paperCaptureCopyOriginalSchema = external_exports.object({ sha256: hash12, bytes: external_exports.number().int().min(0).max(copyByteLimit), mediaType: external_exports.string().max(180) }).strict();
  var paperCaptureTransformDraftSchema = external_exports.object({ x: external_exports.string().max(1e4), y: external_exports.string().max(1e4), width: external_exports.string().max(1e4), height: external_exports.string().max(1e4), rotation: external_exports.string().max(1e4) }).strict();
  var paperCaptureCopyUploadBindingSchema = external_exports.object({ uploadId: id15, pageId: id15 }).strict();
  var paperCaptureCopyGroupBindingSchema = external_exports.object({ groupId: id15, pageIds: external_exports.array(id15).max(120) }).strict();
  var paperCaptureCopyDerivationBindingSchema = external_exports.object({ derivationId: id15, groupId: id15 }).strict();
  var paperCaptureEditorSchema = external_exports.object({
    slot: id15,
    activeGroupId: id15.nullable(),
    pageBases: external_exports.array(external_exports.object({ pageId: id15, revision: external_exports.number().int().positive(), selectedVersionFingerprint: hash12 }).strict()).max(120),
    groupBases: external_exports.array(external_exports.object({ groupId: id15, revision: external_exports.number().int().positive(), fingerprint: hash12 }).strict()).max(64)
  }).strict();
  var paperCaptureCompleteCopySchema = external_exports.object({
    protocol: external_exports.literal("paper-capture-complete-copy-v1"),
    actorId: id15,
    scope: paperCaptureScopeSchema,
    title: external_exports.string().max(180),
    intent: paperCaptureIntentSchema,
    pages: external_exports.array(external_exports.object({ pageId: id15, name: external_exports.string().min(1).max(255), original: paperCaptureCopyOriginalSchema, source: paperImageSourceSchema.nullable(), transform: paperImageTransformSchema.nullable(), draft: paperCaptureTransformDraftSchema.nullable(), base64: external_exports.string().max(Math.ceil(copyByteLimit / 3) * 4) }).strict()).max(120),
    selectedPageIds: external_exports.array(id15).max(120),
    uploads: external_exports.array(paperCaptureCopyUploadBindingSchema).max(240),
    groups: external_exports.array(paperCaptureCopyGroupBindingSchema).max(64),
    derivations: external_exports.array(paperCaptureCopyDerivationBindingSchema).max(240).optional(),
    editor: paperCaptureEditorSchema.optional(),
    pending: paperCapturePendingCommandSchema.nullable(),
    rejected: external_exports.array(paperCapturePendingCommandSchema).max(50),
    requiresOriginalResultLookup: external_exports.boolean(),
    fingerprint: hash12
  }).strict().superRefine((copy, context2) => {
    const editor = copy.editor;
    if (!editor) return;
    if (new Set(editor.pageBases.map((base) => base.pageId)).size !== editor.pageBases.length || editor.pageBases.some((base) => !copy.pages.some((page) => page.pageId === base.pageId && page.source !== null)) || new Set(editor.groupBases.map((base) => base.groupId)).size !== editor.groupBases.length || editor.groupBases.some((base) => !copy.groups.some((group) => group.groupId === base.groupId)) || editor.activeGroupId !== null && !editor.groupBases.some((base) => base.groupId === editor.activeGroupId)) context2.addIssue({ code: external_exports.ZodIssueCode.custom, path: ["editor"], message: "\u7F16\u8F91\u4F9D\u636E\u4E0E\u526F\u672C\u7684\u539F\u9875\u6216\u91C7\u96C6\u7EC4\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u4FDD\u7559\u539F\u8F93\u5165\u540E\u6838\u5BF9\u3002" });
  });

  // packages/contracts/src/paper-capture-integrity.ts
  var id16 = external_exports.string().min(1).max(180);
  var hash13 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var paperCaptureFileTargetSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("page"), pageId: id16, versionFingerprint: hash13 }).strict(),
    external_exports.object({ kind: external_exports.literal("derivation"), derivationId: id16, pdfFingerprint: hash13 }).strict()
  ]);
  var paperCaptureFileCheckSchema = external_exports.object({ role: external_exports.enum(["original", "baseline", "derived", "pdf", "material_pdf"]), sha256: hash13, bytes: external_exports.number().int().positive().max(80 * 1024 * 1024), mediaType: external_exports.enum(["image/png", "image/jpeg", "application/pdf"]), assetGeneration: external_exports.number().int().positive(), assetState: external_exports.enum(["available", "deleting", "deleted", "repairing"]), status: external_exports.enum(["verified", "missing", "changed", "busy", "unavailable"]), actualSha256: hash13.nullable(), actualBytes: external_exports.number().int().nonnegative().max(80 * 1024 * 1024).nullable(), observationFingerprint: hash13 }).strict();
  var paperCaptureFileReportSchema = external_exports.object({ protocol: external_exports.literal("paper-capture-file-report-v1"), target: paperCaptureFileTargetSchema, scope: paperCaptureScopeSchema, sourceFingerprint: hash13, files: external_exports.array(paperCaptureFileCheckSchema).min(2).max(3), relation: external_exports.enum(["verified", "unavailable", "changed", "review_required"]), relationCode: external_exports.enum(["source_files_unavailable", "source_mapping_changed", "renderer_review_required"]).nullable(), canRestore: external_exports.boolean(), checkedAt: external_exports.string().datetime({ offset: true }), fingerprint: hash13 }).strict();

  // packages/contracts/src/paper-capture-repair.ts
  var id17 = external_exports.string().min(1).max(180);
  var hash14 = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var key5 = external_exports.string().min(8).max(180);
  var time5 = external_exports.string().datetime({ offset: true });
  var paperCaptureRepairSelectionSchema = external_exports.object({ target: paperCaptureFileTargetSchema, sourceFingerprint: hash14, role: external_exports.enum(["original", "baseline", "derived", "pdf", "material_pdf"]), sha256: hash14, bytes: external_exports.number().int().positive().max(80 * 1024 * 1024), mediaType: external_exports.enum(["image/png", "image/jpeg", "application/pdf"]), assetGeneration: external_exports.number().int().positive(), observationFingerprint: hash14 }).strict().superRefine((value, context2) => {
    const pdf = value.role === "pdf" || value.role === "material_pdf", limit = value.role === "original" ? 12 * 1024 * 1024 : pdf ? 80 * 1024 * 1024 : 40 * 1024 * 1024;
    if (value.bytes > limit || pdf !== (value.mediaType === "application/pdf") || !["original", "pdf", "material_pdf"].includes(value.role) && value.mediaType !== "image/png" || value.target.kind === "derivation" !== pdf) context2.addIssue({ code: "custom", message: "The exact target role, MIME and byte budget must agree." });
  });
  var paperCaptureRepairCandidateSchema = external_exports.object({
    protocol: external_exports.literal("paper-capture-repair-candidate-v1"),
    selection: paperCaptureRepairSelectionSchema,
    strategy: external_exports.enum(["source_rebuild", "other_pdf"]),
    basis: external_exports.discriminatedUnion("kind", [
      external_exports.object({ kind: external_exports.literal("page"), pageId: id17, versionFingerprint: hash14, originalSha256: hash14, originalBytes: external_exports.number().int().min(5).max(12 * 1024 * 1024), originalMediaType: external_exports.enum(["image/png", "image/jpeg"]), renderer: external_exports.string().min(1).max(180) }).strict(),
      external_exports.object({ kind: external_exports.literal("group"), groupId: id17, revision: external_exports.number().int().positive(), fingerprint: hash14, pdfFingerprint: hash14, renderer: external_exports.string().min(1).max(180) }).strict(),
      external_exports.object({ kind: external_exports.literal("pdf"), role: external_exports.enum(["pdf", "material_pdf"]), sha256: hash14, bytes: external_exports.number().int().positive().max(80 * 1024 * 1024), pdfFingerprint: hash14 }).strict()
    ]),
    fingerprint: hash14
  }).strict().superRefine((value, context2) => {
    const { selection: s, basis: b } = value;
    if (value.strategy === "other_pdf" ? s.target.kind !== "derivation" || b.kind !== "pdf" || b.role === s.role || b.sha256 !== s.sha256 || b.bytes !== s.bytes || b.pdfFingerprint !== s.target.pdfFingerprint : s.target.kind === "page" ? b.kind !== "page" || s.role === "original" || b.pageId !== s.target.pageId || b.versionFingerprint !== s.target.versionFingerprint : b.kind !== "group" || b.pdfFingerprint !== s.target.pdfFingerprint) context2.addIssue({ code: "custom", message: "The candidate must retain the actual original page, frozen group or other PDF source." });
  });
  var paperCaptureRepairCandidateRequestSchema = external_exports.object({ selection: paperCaptureRepairSelectionSchema, strategy: external_exports.enum(["source_rebuild", "other_pdf"]) }).strict();
  var paperCaptureRepairCommandSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("upload"), requestKey: key5, input: external_exports.object({ protocol: external_exports.literal("paper-repair-upload-input-v1"), scope: paperCaptureScopeSchema, selection: paperCaptureRepairSelectionSchema, name: external_exports.string().min(1).max(255), candidate: paperCaptureRepairCandidateSchema.optional() }).strict() }).strict(),
    external_exports.object({ kind: external_exports.literal("start"), requestKey: key5, input: external_exports.object({ protocol: external_exports.literal("paper-repair-start-input-v1"), uploadId: id17, expectedRevision: external_exports.number().int().min(0).max(80), selection: paperCaptureRepairSelectionSchema, strategy: external_exports.enum(["exact_upload", "source_rebuild", "other_pdf"]), candidateFingerprint: hash14.optional() }).strict().superRefine((value, context2) => {
      if (value.strategy === "exact_upload" === (value.candidateFingerprint !== void 0)) context2.addIssue({ code: "custom", message: "A rebuilt candidate requires its exact original provenance." });
    }) }).strict(),
    external_exports.object({ kind: external_exports.literal("cancelUpload"), requestKey: key5, uploadId: id17, expectedRevision: external_exports.number().int().min(0).max(80) }).strict(),
    ...["cancel", "retry"].map((kind) => external_exports.object({ kind: external_exports.literal(kind), requestKey: key5, repairId: id17, expectedTaskVersion: external_exports.number().int().positive(), expectedTaskGeneration: external_exports.number().int().positive() }).strict())
  ]);
  var paperCaptureRepairCommandResultSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("upload"), uploadId: id17, chunkSize: external_exports.literal(1024 * 1024), createdAt: time5, expiresAt: time5 }).strict(),
    external_exports.object({ kind: external_exports.literal("cancelUpload"), uploadId: id17, revision: external_exports.number().int().positive().max(81), cancelledAt: time5 }).strict(),
    external_exports.object({ kind: external_exports.literal("start"), repairId: id17, uploadId: id17, taskId: id17, taskVersion: external_exports.literal(1), taskGeneration: external_exports.literal(1), createdAt: time5 }).strict(),
    ...["cancel", "retry"].map((kind) => external_exports.object({ kind: external_exports.literal(kind), repairId: id17, taskId: id17, taskVersion: external_exports.number().int().positive(), taskGeneration: external_exports.number().int().positive(), acceptedAt: time5 }).strict())
  ]);
  var paperCaptureRepairCommandLookupSchema = external_exports.discriminatedUnion("state", [
    external_exports.object({ state: external_exports.literal("unknown"), requestKey: key5 }).strict(),
    ...["committed", "rejected"].map((state) => external_exports.object({ state: external_exports.literal(state), requestKey: key5, input: paperCaptureRepairCommandSchema, scope: paperCaptureScopeSchema, result: paperCaptureRepairCommandResultSchema.nullable(), errorCode: external_exports.string().nullable() }).strict())
  ]);
  var paperCaptureRepairUploadViewSchema = external_exports.object({ id: id17, scope: paperCaptureScopeSchema, selection: paperCaptureRepairSelectionSchema, name: external_exports.string().min(1).max(255), candidate: paperCaptureRepairCandidateSchema.optional(), chunkSize: external_exports.literal(1024 * 1024), chunks: external_exports.array(external_exports.object({ index: external_exports.number().int().min(0).max(79), sha256: hash14, bytes: external_exports.number().int().positive().max(1024 * 1024) }).strict()).max(80), revision: external_exports.number().int().min(0).max(81), status: external_exports.enum(["uploading", "consumed", "cancelled"]), createdAt: time5, expiresAt: time5, endedAt: time5.nullable(), repairId: id17.nullable() }).strict();
  var paperCaptureRepairPublicationSchema = external_exports.object({ protocol: external_exports.literal("paper-capture-repair-publication-v1"), repairId: id17, target: paperCaptureFileTargetSchema, sourceFingerprint: hash14, role: external_exports.enum(["original", "baseline", "derived", "pdf", "material_pdf"]), sha256: hash14, bytes: external_exports.number().int().positive().max(80 * 1024 * 1024), assetGeneration: external_exports.number().int().positive(), taskGeneration: external_exports.number().int().positive(), restoredAt: time5, fingerprint: hash14 }).strict();
  var paperCaptureRepairViewSchema = external_exports.object({ id: id17, scope: paperCaptureScopeSchema, selection: paperCaptureRepairSelectionSchema, createdAt: time5, ownerClosed: external_exports.boolean(), canCancel: external_exports.boolean(), canRetry: external_exports.boolean(), publication: paperCaptureRepairPublicationSchema.nullable(), task: external_exports.object({ id: id17, state: external_exports.enum(["queued", "running", "retry_wait", "cancel_requested", "cancelled", "succeeded", "failed"]), generation: external_exports.number().int().positive(), version: external_exports.number().int().positive(), errorCode: external_exports.string().nullable(), stage: external_exports.string().nullable() }).strict() }).strict();

  // packages/contracts/src/paper-selection.ts
  var paperSelectionIdSchema = external_exports.string().regex(/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/);
  var paperSelectionHashSchema = external_exports.string().regex(/^[a-f0-9]{64}$/);
  var paperSelectionTimeSchema = external_exports.string().refine((value) => {
    const epoch = Date.parse(value);
    return Number.isFinite(epoch) && new Date(epoch).toISOString() === value;
  }, "\u65F6\u95F4\u5FC5\u987B\u662F\u51C6\u786E\u7684UTC\u65F6\u523B");
  var paperSelectionRequestKeySchema = external_exports.string().min(8).max(128);
  var validText = (value) => {
    for (const character of value) {
      const point2 = character.codePointAt(0);
      if (point2 < 32 && ![9, 10, 13].includes(point2) || point2 >= 55296 && point2 <= 57343 || [65534, 65535].includes(point2)) return false;
    }
    return Boolean(value.trim());
  };
  var paperSelectionTitleSchema = external_exports.string().max(180).refine(validText, "\u8BF7\u586B\u5199\u6709\u6548\u6807\u9898");
  var paperSelectionScopeSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("private_preparation"), studentId: external_exports.null() }).strict(),
    external_exports.object({ kind: external_exports.literal("student_self"), studentId: paperSelectionIdSchema }).strict()
  ]);
  var paperSelectionOriginalQuestionIdSchema = paperSelectionIdSchema.refine((value) => value.startsWith("paper:") && value.length > 6, "\u8BF7\u4F7F\u7528\u51C6\u786E\u7684\u539F\u5377\u9898\u76EE\u952E");
  var paperSelectionSourceIdentitySchema = external_exports.object({
    paperId: paperSelectionIdSchema,
    position: external_exports.number().int().min(1).max(1e5),
    sourceQuestionId: paperSelectionOriginalQuestionIdSchema,
    detailSha256: paperSelectionHashSchema,
    publicationVersion: external_exports.number().int().positive().nullable()
  }).strict();
  var paperSelectionSourceSchema = paperSelectionSourceIdentitySchema.extend({
    title: external_exports.string().max(2e3).refine(validText),
    originalPage: external_exports.number().int().positive().max(1e5).nullable()
  }).strict();
  var paperSelectionItemSchema = external_exports.object({
    id: paperSelectionIdSchema,
    source: paperSelectionSourceSchema,
    research: external_exports.boolean()
  }).strict();
  var paperSelectionSourceKey = (value) => JSON.stringify([value.paperId, value.position, value.sourceQuestionId]);
  var selectedSources = external_exports.array(paperSelectionSourceIdentitySchema).max(100).superRefine((items, context2) => {
    if (new Set(items.map(paperSelectionSourceKey)).size !== items.length) context2.addIssue({ code: "custom", message: "\u540C\u4E00\u539F\u9898\u4F4D\u53EA\u80FD\u4FDD\u7559\u4E00\u4EFD" });
    if (new Set(items.map((item) => item.paperId)).size > 10) context2.addIssue({ code: "custom", message: "\u4E00\u4EFD\u6E05\u5355\u6700\u591A\u5341\u4EFD\u539F\u5377" });
    if (items.some((item) => items.some((other) => other.paperId === item.paperId && (other.detailSha256 !== item.detailSha256 || other.publicationVersion !== item.publicationVersion))))
      context2.addIssue({ code: "custom", message: "\u540C\u4E00\u539F\u5377\u8BF7\u4F7F\u7528\u540C\u4E00\u7248\u672C\u7684\u9898\u4F4D" });
  });
  var paperSelectionCommandSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({
      kind: external_exports.literal("create"),
      requestKey: paperSelectionRequestKeySchema,
      scope: paperSelectionScopeSchema,
      title: paperSelectionTitleSchema,
      items: selectedSources
    }).strict(),
    external_exports.object({
      kind: external_exports.literal("revise"),
      requestKey: paperSelectionRequestKeySchema,
      listId: paperSelectionIdSchema,
      expectedRevision: external_exports.number().int().positive().max(1e3),
      expectedFingerprint: paperSelectionHashSchema,
      title: paperSelectionTitleSchema,
      items: selectedSources
    }).strict()
  ]);
  var paperSelectionResultSchema = external_exports.object({
    listId: paperSelectionIdSchema,
    revision: external_exports.number().int().positive().max(1e3),
    fingerprint: paperSelectionHashSchema,
    at: paperSelectionTimeSchema
  }).strict();
  var paperSelectionSnapshotSchema = external_exports.object({ title: paperSelectionTitleSchema, items: external_exports.array(paperSelectionItemSchema).max(100) }).strict();

  // packages/contracts/src/paper-source-read.ts
  var positions = external_exports.array(external_exports.object({ position: external_exports.number().int().min(1).max(1e5), sourceQuestionId: paperSelectionOriginalQuestionIdSchema }).strict()).min(1).max(1e3).superRefine((values, context2) => {
    if (new Set(values.map((value) => value.position)).size !== values.length) context2.addIssue({ code: "custom", message: "\u539F\u9898\u4F4D\u4E0D\u80FD\u91CD\u590D" });
  });
  var paperSourceReadCommandSchema = external_exports.object({
    kind: external_exports.enum(["read", "selection", "export"]),
    requestKey: paperSelectionRequestKeySchema,
    paperId: paperSelectionIdSchema,
    detailSha256: paperSelectionHashSchema,
    publicationVersion: external_exports.number().int().positive(),
    positions: external_exports.union([positions, external_exports.literal("document")]),
    answers: external_exports.boolean(),
    origin: external_exports.object({ kind: external_exports.enum(["selection_command", "export_command"]), id: paperSelectionIdSchema }).strict().nullable()
  }).strict().superRefine((value, context2) => {
    if (value.kind === "read" && value.origin !== null || value.kind === "selection" && (value.origin?.kind !== "selection_command" || value.positions === "document" || value.answers) || value.kind === "export" && (value.origin?.kind !== "export_command" || value.positions === "document")) context2.addIssue({ code: "custom", message: "\u6765\u6E90\u8BFB\u53D6\u5FC5\u987B\u7ED1\u5B9A\u51C6\u786E\u539F\u64CD\u4F5C" });
  });
  var paperSourceReadResultSchema = external_exports.object({
    exposureId: paperSelectionIdSchema,
    sources: external_exports.array(paperSelectionSourceSchema).max(1e3),
    document: external_exports.boolean(),
    answers: external_exports.boolean(),
    at: paperSelectionTimeSchema
  }).strict();

  // packages/contracts/src/paper-export.ts
  var paperExportBookSchema = external_exports.enum(["practice", "answers"]);
  var paperExportFormatSchema = external_exports.enum(["pdf", "docx"]);
  var paperExportLayoutSchema = external_exports.object({ answerLines: external_exports.number().int().min(0).max(12), breakBetweenQuestions: external_exports.boolean() }).strict();
  var unique2 = (values) => new Set(values).size === values.length;
  var books = external_exports.array(paperExportBookSchema).min(1).max(2).refine(unique2);
  var formats = external_exports.array(paperExportFormatSchema).min(1).max(2).refine(unique2);
  var paperExportCommandSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({
      kind: external_exports.literal("create"),
      requestKey: paperSelectionRequestKeySchema,
      listId: paperSelectionIdSchema,
      listRevision: external_exports.number().int().min(1).max(1e3),
      listFingerprint: paperSelectionHashSchema,
      title: paperSelectionTitleSchema,
      layout: paperExportLayoutSchema,
      books,
      formats
    }).strict(),
    ...["cancel", "retry"].map((kind) => external_exports.object({
      kind: external_exports.literal(kind),
      requestKey: paperSelectionRequestKeySchema,
      exportId: paperSelectionIdSchema,
      book: paperExportBookSchema,
      format: paperExportFormatSchema,
      expectedTaskVersion: external_exports.number().int().positive(),
      expectedGeneration: external_exports.number().int().positive()
    }).strict())
  ]);
  var slot = external_exports.object({ book: paperExportBookSchema, format: paperExportFormatSchema, taskId: paperSelectionIdSchema, generation: external_exports.literal(1) }).strict();
  var paperExportResultSchema = external_exports.discriminatedUnion("kind", [
    external_exports.object({ kind: external_exports.literal("create"), exportId: paperSelectionIdSchema, intentFingerprint: paperSelectionHashSchema, slots: external_exports.array(slot).min(1).max(4), at: paperSelectionTimeSchema }).strict(),
    ...["cancel", "retry"].map((kind) => external_exports.object({
      kind: external_exports.literal(kind),
      exportId: paperSelectionIdSchema,
      book: paperExportBookSchema,
      format: paperExportFormatSchema,
      taskId: paperSelectionIdSchema,
      previousVersion: external_exports.number().int().positive(),
      generation: external_exports.number().int().positive(),
      at: paperSelectionTimeSchema
    }).strict())
  ]);
  var text5 = (limit, empty = false) => external_exports.string().refine((value) => {
    if (!empty && !value.trim() || new TextEncoder().encode(value).byteLength > limit) return false;
    for (const character of value) {
      const point2 = character.codePointAt(0);
      if (point2 < 32 && ![9, 10, 13].includes(point2) || point2 >= 55296 && point2 <= 57343 || [65534, 65535].includes(point2)) return false;
    }
    return true;
  });
  var paperExportDocumentSourceSchema = paperSelectionSourceSchema.omit({ title: true, originalPage: true, publicationVersion: true }).extend({
    publicationVersion: external_exports.string().regex(/^(research-v1|published-v[1-9][0-9]*)$/),
    paperTitle: text5(128 * 1024),
    pageNumber: external_exports.number().int().positive().max(1e5).nullable()
  }).strict();
  var paperExportDocumentMediaSchema = external_exports.object({
    path: external_exports.string().regex(/^media\/[a-f0-9]{64}\.png$/),
    sha256: paperSelectionHashSchema,
    bytes: external_exports.number().int().min(1).max(12 * 1024 * 1024),
    width: external_exports.number().int().min(1).max(6e3),
    height: external_exports.number().int().min(1).max(6e3)
  }).strict();
  var paperExportDocumentSchema = external_exports.object({
    protocol: external_exports.literal("paper-export-document-v1"),
    title: paperSelectionTitleSchema,
    layout: paperExportLayoutSchema,
    items: external_exports.array(external_exports.object({
      id: paperSelectionIdSchema,
      source: paperExportDocumentSourceSchema,
      promptHtml: text5(8 * 1024 * 1024),
      optionHtml: external_exports.array(external_exports.object({ label: text5(128 * 1024), html: text5(8 * 1024 * 1024, true) }).strict()).max(30),
      reference: external_exports.object({ answerHtml: text5(8 * 1024 * 1024, true).nullable(), analysisHtml: text5(8 * 1024 * 1024, true).nullable() }).strict().nullable()
    }).strict()).min(1).max(100),
    media: external_exports.array(paperExportDocumentMediaSchema).max(500)
  }).strict();
  var paperExportMediaSchema = external_exports.object({
    id: paperSelectionIdSchema,
    sourceUrl: text5(8192),
    paperId: paperSelectionIdSchema,
    sha256: paperSelectionHashSchema,
    bytes: external_exports.number().int().min(1).max(12 * 1024 * 1024),
    mediaType: external_exports.literal("image/png"),
    width: external_exports.number().int().min(1).max(6e3),
    height: external_exports.number().int().min(1).max(6e3)
  }).strict();
  var paperExportSourceMapSchema = external_exports.array(external_exports.object({
    itemId: paperSelectionIdSchema,
    number: external_exports.number().int().min(1).max(100),
    source: paperExportDocumentSourceSchema,
    startPage: external_exports.number().int().min(1).max(120),
    endPage: external_exports.number().int().min(1).max(120),
    bookmark: external_exports.string().regex(/^PaperItem[0-9]{4}$/),
    endBookmark: external_exports.string().regex(/^PaperEnd[0-9]{4}$/),
    pdfDestinationName: external_exports.string().regex(/^PaperItem[0-9]{4}$/)
  }).strict()).min(1).max(100);
  var paperExportErasureProofSchema = external_exports.object({
    exportId: paperSelectionIdSchema,
    intentFingerprint: paperSelectionHashSchema,
    actorFingerprint: paperSelectionHashSchema,
    studentFingerprint: paperSelectionHashSchema.nullable(),
    tasks: external_exports.array(external_exports.object({ id: paperSelectionIdSchema, payloadHash: paperSelectionHashSchema }).strict()).min(1).max(4),
    files: external_exports.array(external_exports.object({ id: paperSelectionIdSchema, identityFingerprint: paperSelectionHashSchema }).strict()).max(1e5)
  }).strict().superRefine((value, context2) => {
    if (!unique2(value.tasks.map((task) => task.id)) || !unique2(value.files.map((file2) => file2.id))) context2.addIssue({ code: "custom", message: "\u5220\u9664\u8BC1\u660E\u4E2D\u7684\u4EFB\u52A1\u548C\u6587\u4EF6\u4E0D\u80FD\u91CD\u590D" });
  });

  // packages/contracts/src/paper-library-copy.ts
  var paperLibraryCopyOwnerSchema = external_exports.object({ actorId: paperSelectionIdSchema, role: external_exports.enum(["parent", "teacher", "operator", "admin", "student"]), scope: paperSelectionScopeSchema }).strict().superRefine((owner, context2) => {
    if (owner.role === "student" !== (owner.scope.kind === "student_self")) context2.addIssue({ code: "custom", message: "\u8BF7\u4F7F\u7528\u51C6\u786E\u7684\u672C\u4EBA\u5907\u8BFE\u6216\u5B66\u751F\u5B66\u4E60\u8EAB\u4EFD" });
  });
  var paperLibraryDraftSlotSchema = external_exports.string().regex(/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/);
  var originals = external_exports.array(paperSelectionSourceSchema).max(100).superRefine((items, context2) => {
    if (new Set(items.map(paperSelectionSourceKey)).size !== items.length || new Set(items.map((row2) => row2.paperId)).size > 10 || items.some((row2) => items.some((other) => row2.paperId === other.paperId && (row2.detailSha256 !== other.detailSha256 || row2.publicationVersion !== other.publicationVersion))))
      context2.addIssue({ code: "custom", message: "\u8BF7\u4FDD\u7559\u552F\u4E00\u51C6\u786E\u9898\u4F4D\uFF0C\u5E76\u6838\u5BF9\u540C\u5377\u7684\u539F\u7248\u672C" });
  });
  var paperLibraryBaselineSchema = external_exports.object({ identity: paperSelectionResultSchema, title: external_exports.string().max(180), items: originals }).strict();
  var phase = external_exports.enum(["prepared", "unknown", "received", "rejected"]);
  var paperLibraryJournalSchema = external_exports.discriminatedUnion("family", [
    external_exports.object({
      family: external_exports.literal("selection"),
      input: paperSelectionCommandSchema,
      requestFingerprint: paperSelectionHashSchema,
      phase,
      result: paperSelectionResultSchema.nullable(),
      message: external_exports.string().max(4e3)
    }).strict(),
    external_exports.object({
      family: external_exports.literal("export"),
      input: paperExportCommandSchema,
      requestFingerprint: paperSelectionHashSchema,
      phase,
      result: paperExportResultSchema.nullable(),
      message: external_exports.string().max(4e3)
    }).strict()
  ]).superRefine((entry, context2) => {
    if (entry.phase === "received" !== (entry.result !== null)) context2.addIssue({ code: "custom", message: "\u539F\u8BF7\u6C42\u7684\u56DE\u6267\u4E0E\u5F85\u6838\u5BF9\u72B6\u6001\u4E0D\u4E00\u81F4" });
  });
  var paperLibraryCompleteCopySchema = external_exports.object({
    protocol: external_exports.literal("paper-library-complete-copy-v1"),
    owner: paperLibraryCopyOwnerSchema,
    slot: paperLibraryDraftSlotSchema,
    title: external_exports.string().max(180),
    items: originals,
    baseline: paperLibraryBaselineSchema.nullable(),
    exportSettings: external_exports.object({
      title: external_exports.string().max(180),
      answerLines: external_exports.string().max(32),
      breakBetweenQuestions: external_exports.boolean(),
      books: external_exports.array(paperExportBookSchema).max(2),
      formats: external_exports.array(paperExportFormatSchema).max(2)
    }).strict(),
    editor: external_exports.object({
      pane: external_exports.enum(["selection", "exports"]),
      listPage: external_exports.number().int().min(1).max(1e4),
      exportPage: external_exports.number().int().min(1).max(1e4),
      exportId: paperSelectionIdSchema.nullable()
    }).strict(),
    journal: external_exports.array(paperLibraryJournalSchema).max(100),
    requiresOriginalResultLookup: external_exports.literal(true),
    fingerprint: paperSelectionHashSchema
  }).strict().superRefine((copy, context2) => {
    if (new Set(copy.exportSettings.books).size !== copy.exportSettings.books.length || new Set(copy.exportSettings.formats).size !== copy.exportSettings.formats.length || new Set(copy.journal.map((entry) => JSON.stringify([entry.family, entry.input.requestKey]))).size !== copy.journal.length)
      context2.addIssue({ code: "custom", message: "\u526F\u672C\u4E2D\u7684\u9009\u9879\u6216\u539F\u8BF7\u6C42\u91CD\u590D\uFF0C\u672A\u8986\u76D6\u5F53\u524D\u8349\u7A3F" });
    for (const entry of copy.journal) {
      if (entry.family === "selection" && entry.input.kind === "create" && JSON.stringify(entry.input.scope) !== JSON.stringify(copy.owner.scope))
        context2.addIssue({ code: "custom", message: "\u539F\u521B\u5EFA\u8BF7\u6C42\u4E0D\u5C5E\u4E8E\u8FD9\u4E2A\u51C6\u786E\u8303\u56F4" });
    }
  });

  // packages/contracts/src/index.ts
  var subjectSchema = external_exports.enum(["chinese", "math", "english", "chemistry"]);
  var roleSchema = external_exports.enum(["parent", "student", "teacher", "operator", "admin"]);
  var apiErrorSchema = external_exports.object({
    code: external_exports.string(),
    message: external_exports.string(),
    details: external_exports.record(external_exports.string(), external_exports.any()).optional()
  });
  var domainEventEnvelopeSchema = external_exports.object({
    eventName: external_exports.string(),
    eventVersion: external_exports.number().int().positive(),
    eventId: external_exports.string(),
    occurredAt: external_exports.string(),
    payload: external_exports.record(external_exports.string(), external_exports.any())
  });
  var studentProfileSchema = external_exports.object({
    id: external_exports.string(),
    userId: external_exports.string(),
    nickname: external_exports.string(),
    grade: external_exports.number().int().min(1).max(9),
    defaultVersionMap: external_exports.object({
      chinese: external_exports.string(),
      math: external_exports.string(),
      english: external_exports.string(),
      chemistry: external_exports.string().optional()
    }),
    preferredSessionMinutes: external_exports.number().int().positive()
  });
  var subjectEnrollmentSchema = external_exports.object({
    id: external_exports.string(),
    studentId: external_exports.string(),
    subject: subjectSchema,
    enabled: external_exports.boolean(),
    textbookVersionId: external_exports.string()
  });
  var textbookVolumeSchema = external_exports.object({
    id: external_exports.string(),
    subject: subjectSchema,
    publisherVersion: external_exports.string(),
    grade: external_exports.number().int().min(1).max(9),
    term: external_exports.enum(["first", "second"]),
    displayName: external_exports.string(),
    sourcePath: external_exports.string(),
    status: external_exports.enum(["draft", "published"])
  });
  var knowledgePointSchema = external_exports.object({
    id: external_exports.string(),
    subject: subjectSchema,
    name: external_exports.string(),
    parentId: external_exports.string().nullable(),
    gradeBand: external_exports.string(),
    difficultyLevel: external_exports.number().int().min(1).max(5),
    lessonId: external_exports.string().nullable(),
    status: external_exports.enum(["draft", "published"])
  });
  var questionSchema = external_exports.object({
    id: external_exports.string(),
    subject: subjectSchema,
    type: external_exports.enum(["objective", "subjective", "stepwise", "oral"]),
    stem: external_exports.string(),
    answer: external_exports.any(),
    analysis: external_exports.string(),
    difficultyLevel: external_exports.number().int().min(1).max(5),
    knowledgePointIds: external_exports.array(external_exports.string()),
    status: external_exports.enum(["draft", "published"])
  });
  var questionRuntimeSummarySchema = questionSchema.pick({
    id: true,
    subject: true,
    type: true,
    difficultyLevel: true,
    status: true
  });
  var questionBlockTypeSchema = external_exports.enum([
    "text",
    "math_inline",
    "math_display",
    "image",
    "table",
    "audio",
    "video",
    "reading_material",
    "sub_question_group",
    "geometry_canvas",
    "annotation",
    "divider"
  ]);
  var questionBlockBaseSchema = external_exports.object({
    id: external_exports.string(),
    type: questionBlockTypeSchema,
    text: external_exports.string().optional(),
    latex: external_exports.string().optional(),
    url: external_exports.string().optional(),
    alt: external_exports.string().optional(),
    caption: external_exports.string().optional(),
    prompt: external_exports.string().optional(),
    headers: external_exports.array(external_exports.string()).optional(),
    rows: external_exports.array(external_exports.array(external_exports.string())).optional(),
    meta: external_exports.record(external_exports.string(), external_exports.any()).optional()
  });
  var questionBlockSchema = external_exports.lazy(
    () => questionBlockBaseSchema.extend({
      children: external_exports.array(questionBlockSchema).optional()
    })
  );
  var questionAttachmentSchema = external_exports.object({
    id: external_exports.string(),
    kind: external_exports.enum(["image", "audio", "video", "file"]),
    url: external_exports.string(),
    mimeType: external_exports.string(),
    alt: external_exports.string().nullable().optional(),
    width: external_exports.number().int().positive().nullable().optional(),
    height: external_exports.number().int().positive().nullable().optional(),
    durationMs: external_exports.number().int().positive().nullable().optional(),
    sizeBytes: external_exports.number().int().positive().nullable().optional()
  });
  var questionLayoutModeSchema = external_exports.enum(["default", "reading_split", "multi_part", "canvas_assist"]);
  var questionDocumentSchema = external_exports.object({
    questionId: external_exports.string(),
    version: external_exports.number().int().positive(),
    locale: external_exports.literal("zh-CN"),
    blocks: external_exports.array(questionBlockSchema),
    attachments: external_exports.array(questionAttachmentSchema),
    layoutMode: questionLayoutModeSchema,
    accessibilityConfig: external_exports.record(external_exports.string(), external_exports.any())
  });
  var questionAnswerModeSchema = external_exports.enum([
    "single_choice",
    "multiple_choice",
    "boolean",
    "text_blank",
    "numeric_blank",
    "formula_blank",
    "multi_blank",
    "table_fill",
    "matching",
    "sorting",
    "drag_drop",
    "hotspot",
    "geometry_draw",
    "stepwise",
    "image_upload",
    "short_answer",
    "audio_record"
  ]);
  var questionOptionSchema = external_exports.object({
    id: external_exports.string(),
    label: external_exports.string(),
    value: external_exports.string(),
    content: external_exports.string().nullable().optional()
  });
  var questionAnswerSchemaSchema = external_exports.object({
    questionId: external_exports.string(),
    mode: questionAnswerModeSchema,
    responseShape: external_exports.record(external_exports.string(), external_exports.any()),
    validationRules: external_exports.record(external_exports.string(), external_exports.any()),
    gradingConfig: external_exports.record(external_exports.string(), external_exports.any()),
    options: external_exports.array(questionOptionSchema).optional(),
    placeholder: external_exports.string().nullable().optional()
  });
  var questionSourceTypeSchema = external_exports.enum([
    "internal_authoring",
    "internal_textbook",
    "open_content",
    "public_reference",
    "partner"
  ]);
  var questionLicenseClassSchema = external_exports.enum([
    "A_INTERNAL",
    "B_OPEN",
    "C_PUBLIC_REFERENCE_ONLY",
    "D_COMMERCIAL_PARTNER"
  ]);
  var questionSourceRecordSchema = external_exports.object({
    questionId: external_exports.string(),
    sourceType: questionSourceTypeSchema,
    sourceName: external_exports.string(),
    sourcePathOrUrl: external_exports.string(),
    licenseClass: questionLicenseClassSchema,
    licenseName: external_exports.string().nullable(),
    importJobId: external_exports.string().nullable(),
    reviewStatus: external_exports.enum(["pending", "approved", "rejected"]),
    notes: external_exports.string().nullable()
  });
  var questionImportTypeSchema = external_exports.enum(["textbook_pdf", "qti", "h5p", "manual_seed"]);
  var questionImportJobStatusSchema = external_exports.enum(["pending", "running", "completed", "failed", "cancelled"]);
  var questionImportReviewStatusSchema = external_exports.enum(["pending", "approved", "rejected"]);
  var questionImportSplitModeSchema = external_exports.enum(["page", "question"]);
  var questionImportQualityLevelSchema = external_exports.enum(["low", "medium", "high"]);
  var questionImportAiSuggestionSchema = external_exports.object({
    suggestedStem: external_exports.string(),
    suggestedSectionLabel: external_exports.string().nullable(),
    suggestedAnswerMode: questionAnswerModeSchema.nullable(),
    reviewAdvice: external_exports.string(),
    actionablePoints: external_exports.array(external_exports.string()),
    confidenceLevel: external_exports.enum(["low", "medium", "high"]),
    reviewRequired: external_exports.boolean(),
    model: external_exports.string().optional(),
    source: external_exports.string().optional(),
    promptVersion: external_exports.string().optional(),
    taskId: external_exports.string().optional()
  });
  var questionImportSourcePolicySchema = external_exports.object({
    sourceType: questionSourceTypeSchema,
    licenseClass: questionLicenseClassSchema,
    licenseName: external_exports.string().nullable()
  });
  var questionImportJobSchema = external_exports.object({
    id: external_exports.string(),
    importType: questionImportTypeSchema,
    subject: subjectSchema,
    sourcePathOrUrl: external_exports.string(),
    sourcePolicy: questionImportSourcePolicySchema,
    status: questionImportJobStatusSchema,
    fileCount: external_exports.number().int().nonnegative(),
    recordCount: external_exports.number().int().nonnegative(),
    warningCount: external_exports.number().int().nonnegative(),
    errorMessage: external_exports.string().nullable(),
    createdAt: external_exports.string(),
    completedAt: external_exports.string().nullable(),
    taskId: external_exports.string().optional(),
    fileIds: external_exports.array(external_exports.string()).optional(),
    ownerUserId: external_exports.string().optional(),
    requestKey: external_exports.string().optional(),
    inputHash: external_exports.string().optional(),
    pipelineVersion: external_exports.string().optional()
  });
  var questionImportRecordSchema = external_exports.object({
    id: external_exports.string(),
    jobId: external_exports.string(),
    subject: subjectSchema,
    sourcePath: external_exports.string(),
    sourceName: external_exports.string(),
    pageNumber: external_exports.number().int().positive().nullable(),
    candidateIndexOnPage: external_exports.number().int().positive(),
    splitMode: questionImportSplitModeSchema,
    sectionLabel: external_exports.string().nullable(),
    qualityLevel: questionImportQualityLevelSchema,
    qualityFlags: external_exports.array(external_exports.string()),
    excerpt: external_exports.string(),
    previewImageDataUrl: external_exports.string().nullable(),
    detectionReason: external_exports.string(),
    candidateStem: external_exports.string(),
    aiSuggestion: questionImportAiSuggestionSchema.nullable(),
    aiSuggestedAt: external_exports.string().nullable(),
    reviewStatus: questionImportReviewStatusSchema,
    reviewComment: external_exports.string().nullable(),
    candidateQuestionId: external_exports.string().nullable(),
    createdAt: external_exports.string(),
    reviewedAt: external_exports.string().nullable(),
    fileId: external_exports.string().optional(),
    sourceSha256: external_exports.string().optional(),
    extractionMethod: external_exports.enum(["pdf_text", "ocr", "unreadable"]).optional(),
    pageEvidence: external_exports.custom().optional(),
    pageEvidenceId: external_exports.string().optional(),
    reviewVersion: external_exports.number().int().nonnegative().optional(),
    reviewHistory: external_exports.array(external_exports.object({ version: external_exports.number(), decision: external_exports.enum(["approved", "rejected"]), actorId: external_exports.string(), at: external_exports.string(), comment: external_exports.string(), candidateStem: external_exports.string().optional(), excerpt: external_exports.string().optional() })).optional(),
    originalCandidate: external_exports.object({ stem: external_exports.string(), excerpt: external_exports.string() }).optional()
  });
  var questionRenderPayloadSchema = external_exports.object({
    question: questionRuntimeSummarySchema,
    document: questionDocumentSchema,
    answerSchema: questionAnswerSchemaSchema,
    source: questionSourceRecordSchema,
    inputAvailability: external_exports.object({ supported: external_exports.boolean(), reason: external_exports.string() }).optional()
  });
  var studentAnswerPayloadSchema = external_exports.object({
    questionId: external_exports.string(),
    mode: questionAnswerModeSchema,
    response: external_exports.record(external_exports.string(), external_exports.any()),
    clientMeta: external_exports.object({
      elapsedMs: external_exports.number().int().positive().optional(),
      inputMethod: external_exports.string().optional(),
      usedToolbar: external_exports.array(external_exports.string()).optional()
    }).optional()
  });
  var answerValidationFieldErrorSchema = external_exports.object({
    field: external_exports.string(),
    message: external_exports.string()
  });
  var answerValidationResultSchema = external_exports.object({
    valid: external_exports.boolean(),
    normalizedAnswer: external_exports.any().nullable(),
    fieldErrors: external_exports.array(answerValidationFieldErrorSchema),
    message: external_exports.string().nullable()
  });
  var assessmentSessionSchema = external_exports.object({
    id: external_exports.string(),
    studentId: external_exports.string(),
    subject: subjectSchema,
    assessmentType: external_exports.enum(["initial", "unit", "stage", "micro", "retry"]),
    itemIds: external_exports.array(external_exports.string()),
    status: external_exports.enum(["pending", "in_progress", "completed", "aborted"]),
    startedAt: external_exports.string(),
    completedAt: external_exports.string().nullable()
  });
  var assessmentResultSchema = external_exports.object({
    sessionId: external_exports.string(),
    overallScore: external_exports.number(),
    itemCount: external_exports.number().int().nonnegative(),
    knowledgeResults: external_exports.array(
      external_exports.object({
        knowledgePointId: external_exports.string(),
        knowledgePointName: external_exports.string(),
        score: external_exports.number(),
        correctCount: external_exports.number().int().nonnegative(),
        totalCount: external_exports.number().int().positive(),
        errorTypes: external_exports.array(external_exports.string())
      })
    ),
    recommendedActions: external_exports.array(external_exports.string()),
    parentSummary: external_exports.string()
  });
  var assessmentProgressItemSchema = external_exports.object({
    questionId: external_exports.string(),
    questionStem: external_exports.string(),
    answered: external_exports.boolean(),
    correct: external_exports.boolean().nullable(),
    score: external_exports.number().nullable(),
    errorType: external_exports.string().nullable(),
    analysis: external_exports.string().nullable(),
    elapsedMs: external_exports.number().int().nonnegative().nullable()
  });
  var assessmentProgressViewSchema = external_exports.object({
    sessionId: external_exports.string(),
    status: external_exports.enum(["pending", "in_progress", "completed", "aborted"]),
    answeredCount: external_exports.number().int().nonnegative(),
    totalCount: external_exports.number().int().positive(),
    progressPercent: external_exports.number(),
    currentIndex: external_exports.number().int().nonnegative(),
    currentItemId: external_exports.string().nullable(),
    items: external_exports.array(assessmentProgressItemSchema)
  });
  var missionTypeSchema = external_exports.enum(["new_learning", "practice", "retry", "review"]);
  var dailyMissionSchema = external_exports.object({
    id: external_exports.string(),
    studentId: external_exports.string(),
    subject: subjectSchema,
    missionType: missionTypeSchema,
    title: external_exports.string(),
    targetKnowledgePointIds: external_exports.array(external_exports.string()),
    questionIds: external_exports.array(external_exports.string()),
    estimatedMinutes: external_exports.number().int().positive(),
    status: external_exports.enum(["pending", "in_progress", "completed", "skipped"])
  });
  var missionResultItemSchema = external_exports.object({
    questionId: external_exports.string(),
    questionStem: external_exports.string(),
    attemptCount: external_exports.number().int().positive(),
    correct: external_exports.boolean(),
    score: external_exports.number(),
    hintLevelUsed: external_exports.number().int().nonnegative(),
    analysis: external_exports.string()
  });
  var missionResultViewSchema = external_exports.object({
    missionId: external_exports.string(),
    subject: subjectSchema,
    missionType: missionTypeSchema,
    title: external_exports.string(),
    status: external_exports.enum(["pending", "in_progress", "completed", "skipped"]),
    correctCount: external_exports.number().int().nonnegative(),
    totalCount: external_exports.number().int().positive(),
    incorrectCount: external_exports.number().int().nonnegative(),
    hintUsedCount: external_exports.number().int().nonnegative(),
    totalAttempts: external_exports.number().int().nonnegative(),
    summary: external_exports.string(),
    targetKnowledgePointIds: external_exports.array(external_exports.string()),
    targetKnowledgePointNames: external_exports.array(external_exports.string()),
    nextActions: external_exports.array(external_exports.string()),
    itemResults: external_exports.array(missionResultItemSchema)
  });
  var studyPlanDaySchema = external_exports.object({
    date: external_exports.string(),
    weekday: external_exports.enum(["mon", "tue", "wed", "thu", "fri", "sat", "sun"]),
    missionType: missionTypeSchema,
    estimatedMinutes: external_exports.number().int().positive(),
    focusKnowledgePointIds: external_exports.array(external_exports.string()),
    focusKnowledgePointNames: external_exports.array(external_exports.string()),
    goal: external_exports.string()
  });
  var studyPlanSchema = external_exports.object({
    id: external_exports.string(),
    studentId: external_exports.string(),
    subject: subjectSchema,
    weekStartDate: external_exports.string(),
    weekEndDate: external_exports.string(),
    availableMinutesPerDay: external_exports.number().int().positive(),
    goals: external_exports.array(external_exports.string()),
    requiredKnowledgePointIds: external_exports.array(external_exports.string()),
    requiredKnowledgePointNames: external_exports.array(external_exports.string()),
    dailyPlans: external_exports.array(studyPlanDaySchema),
    summary: external_exports.string(),
    status: external_exports.enum(["draft", "active", "completed"]),
    generatedAt: external_exports.string()
  });
  var generateWeeklyPlanRequestSchema = external_exports.object({
    studentId: external_exports.string(),
    subject: subjectSchema,
    weekStartDate: external_exports.string().optional(),
    availableMinutesPerDay: external_exports.number().int().positive().optional()
  });
  var masteryStatusSchema = external_exports.enum(["unknown", "learning", "unstable", "mastered", "at_risk"]);
  var studentMasterySnapshotSchema = external_exports.object({
    studentId: external_exports.string(),
    subject: subjectSchema,
    knowledgePointId: external_exports.string(),
    knowledgePointName: external_exports.string(),
    masteryScore: external_exports.number(),
    confidenceScore: external_exports.number(),
    status: masteryStatusSchema,
    updatedAt: external_exports.string()
  });
  var masteryHeatmapViewSchema = external_exports.object({
    studentId: external_exports.string(),
    subject: subjectSchema,
    summary: external_exports.object({
      masteredCount: external_exports.number().int().nonnegative(),
      learningCount: external_exports.number().int().nonnegative(),
      unstableCount: external_exports.number().int().nonnegative(),
      atRiskCount: external_exports.number().int().nonnegative(),
      unknownCount: external_exports.number().int().nonnegative()
    }),
    snapshots: external_exports.array(studentMasterySnapshotSchema)
  });
  var riskSignalSchema = external_exports.object({
    id: external_exports.string(),
    studentId: external_exports.string(),
    subject: subjectSchema,
    type: external_exports.enum(["streak_break", "retry_failure", "mastery_drop", "high_hint_dependency"]),
    level: external_exports.enum(["low", "medium", "high"]),
    summary: external_exports.string(),
    action: external_exports.string(),
    knowledgePointId: external_exports.string().nullable(),
    knowledgePointName: external_exports.string().nullable()
  });
  var weeklyReportKnowledgePointSchema = external_exports.object({
    knowledgePointId: external_exports.string(),
    knowledgePointName: external_exports.string(),
    masteryScore: external_exports.number(),
    status: masteryStatusSchema
  });
  var weeklyReportSchema = external_exports.object({
    studentId: external_exports.string(),
    subject: subjectSchema,
    weekStartDate: external_exports.string(),
    weekEndDate: external_exports.string(),
    assessmentCount: external_exports.number().int().nonnegative(),
    missionCompletedCount: external_exports.number().int().nonnegative(),
    totalAnsweredCount: external_exports.number().int().nonnegative(),
    correctRate: external_exports.number(),
    hintUsedCount: external_exports.number().int().nonnegative(),
    highlights: external_exports.array(external_exports.string()),
    strongestKnowledgePoints: external_exports.array(weeklyReportKnowledgePointSchema),
    focusKnowledgePoints: external_exports.array(weeklyReportKnowledgePointSchema),
    masterySnapshots: external_exports.array(studentMasterySnapshotSchema),
    riskSignals: external_exports.array(riskSignalSchema),
    parentSummary: external_exports.string(),
    generatedAt: external_exports.string()
  });
  var analyticsOverviewSchema = external_exports.object({
    studentCount: external_exports.number().int().nonnegative(),
    activeParentCount: external_exports.number().int().nonnegative(),
    textbookVolumeCount: external_exports.number().int().nonnegative(),
    knowledgePointCount: external_exports.number().int().nonnegative(),
    publishedQuestionCount: external_exports.number().int().nonnegative(),
    completedAssessmentCount: external_exports.number().int().nonnegative(),
    completedMissionCount: external_exports.number().int().nonnegative(),
    activeStudyPlanCount: external_exports.number().int().nonnegative(),
    aiInsightCount: external_exports.number().int().nonnegative()
  });
  var aiInsightSummarySchema = external_exports.object({
    id: external_exports.string(),
    sourceType: external_exports.enum(["assessment", "hint", "assistant"]),
    studentId: external_exports.string().nullable(),
    summary: external_exports.string(),
    confidenceLevel: external_exports.enum(["low", "medium", "high"]),
    reviewRequired: external_exports.boolean(),
    searchResultCount: external_exports.number().int().nonnegative(),
    createdAt: external_exports.string()
  });
  var aiQualityOverviewSchema = external_exports.object({
    totalInsightCount: external_exports.number().int().nonnegative(),
    sourceBreakdown: external_exports.object({
      assessment: external_exports.number().int().nonnegative(),
      hint: external_exports.number().int().nonnegative(),
      assistant: external_exports.number().int().nonnegative()
    }),
    confidenceBreakdown: external_exports.object({
      low: external_exports.number().int().nonnegative(),
      medium: external_exports.number().int().nonnegative(),
      high: external_exports.number().int().nonnegative()
    }),
    reviewRequiredCount: external_exports.number().int().nonnegative(),
    searchBackedAssistantCount: external_exports.number().int().nonnegative(),
    searchBackedAssistantRate: external_exports.number(),
    recentInsights: external_exports.array(aiInsightSummarySchema)
  });
  var aiAnalysisResponseSchema = external_exports.object({
    summary: external_exports.string(),
    structuredResult: external_exports.record(external_exports.string(), external_exports.any()),
    confidenceLevel: external_exports.enum(["low", "medium", "high"]),
    reviewRequired: external_exports.boolean(),
    source: external_exports.enum(["openai", "rules"])
  });
  var assistantSessionSchema = external_exports.object({
    id: external_exports.string(),
    userRole: external_exports.enum(["student", "parent"]),
    studentId: external_exports.string().nullable(),
    subject: subjectSchema.nullable(),
    pageContext: external_exports.enum(["student_home", "assessment", "mission", "review", "weekly_report", "classroom", "studio", "course"]),
    contextRefType: external_exports.string().nullable(),
    contextRefId: external_exports.string().nullable(),
    contextItemId: external_exports.string().nullable().optional(),
    status: external_exports.enum(["active", "closed"])
  });
  var measurementDraftSchema = createMeasurementDraftSchema(subjectSchema, questionBlockSchema, questionAnswerSchemaSchema);

  // apps/web/lib/paper-capture-copy.ts
  var byteLimit = 50 * 1024 * 1024;
  var stable = (value) => Array.isArray(value) ? value.map(stable) : value && typeof value === "object" ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key6, item]) => [key6, stable(item)])) : value;
  async function paperCaptureBytesHash(bytes) {
    if (!globalThis.crypto?.subtle) throw Error("\u5F53\u524D\u6D4F\u89C8\u5668\u6682\u4E0D\u80FD\u6821\u9A8C\u539F\u6587\u4EF6\uFF0C\u8BF7\u4FDD\u7559\u5F53\u524D\u6587\u4EF6\u5E76\u6362\u7528\u53D7\u652F\u6301\u7684\u6D4F\u89C8\u5668\u3002");
    const input2 = new Uint8Array(bytes.length);
    input2.set(bytes);
    return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", input2)), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  var paperCaptureValueHash = (value) => paperCaptureBytesHash(new TextEncoder().encode(JSON.stringify(stable(value))));

  // apps/web/lib/paper-library-copy.ts
  var paperLibraryCopyByteLimit = 2 * 1024 * 1024;
  var paperLibraryValueHash = paperCaptureValueHash;
  var issue2 = () => new Error("\u5B8C\u6574\u7A3F\u7684\u5F52\u5C5E\u3001\u539F\u547D\u4EE4\u6216\u56DE\u6267\u5BF9\u5E94\u5173\u7CFB\u65E0\u6CD5\u6838\u5BF9\uFF0C\u672A\u8986\u76D6\u5F53\u524D\u8349\u7A3F\u3002");
  function emptyPaperLibraryDraft(owner, slot2) {
    return {
      protocol: "paper-library-complete-copy-v1",
      owner: paperLibraryCopyOwnerSchema.parse(owner),
      slot: paperLibraryDraftSlotSchema.parse(slot2),
      title: "\u6211\u7684\u9009\u9898\u6E05\u5355",
      items: [],
      baseline: null,
      exportSettings: { title: "\u6211\u7684\u7EC3\u4E60\u9898\u5355", answerLines: "3", breakBetweenQuestions: false, books: ["practice"], formats: ["pdf"] },
      editor: { pane: "selection", listPage: 1, exportPage: 1, exportId: null },
      journal: [],
      requiresOriginalResultLookup: true
    };
  }
  function stopped(signal) {
    if (signal?.aborted) throw new DOMException("\u5B8C\u6574\u7A3F\u64CD\u4F5C\u5DF2\u505C\u6B62\uFF0C\u5F53\u524D\u8F93\u5165\u4ECD\u4FDD\u7559\u3002", "AbortError");
  }
  async function paperLibraryRequestFingerprint(ownerValue, family, input2) {
    const owner = paperLibraryCopyOwnerSchema.parse(ownerValue), actual = (family === "selection" ? paperSelectionCommandSchema : paperExportCommandSchema).parse(input2);
    if (family === "selection" && actual.kind === "create" && "scope" in actual && await paperCaptureValueHash(actual.scope) !== await paperCaptureValueHash(owner.scope)) throw issue2();
    return paperCaptureValueHash({ owner, family, input: actual });
  }
  async function paperLibraryJournalEntry(owner, family, input2) {
    return paperLibraryJournalSchema.parse({ family, input: structuredClone(input2), requestFingerprint: await paperLibraryRequestFingerprint(owner, family, input2), phase: "prepared", result: null, message: "" });
  }
  async function assertPaperLibraryJournal(owner, value) {
    const entry = paperLibraryJournalSchema.parse(value);
    if (await paperCaptureValueHash(entry) !== await paperCaptureValueHash(value) || entry.requestFingerprint !== await paperLibraryRequestFingerprint(owner, entry.family, entry.input)) throw issue2();
    if (!entry.result) return entry;
    if (entry.family === "selection") {
      const input2 = entry.input, result = paperSelectionResultSchema.parse(entry.result);
      if (input2.kind === "create" ? result.listId !== "paper_selection_" + await paperCaptureValueHash({ actorId: owner.actorId, requestKey: input2.requestKey }) || result.revision !== 1 : result.listId !== input2.listId || result.revision !== input2.expectedRevision + 1) throw issue2();
    } else {
      const input2 = entry.input, result = paperExportResultSchema.parse(entry.result);
      if (input2.kind !== result.kind) throw issue2();
      if (input2.kind === "create" && result.kind === "create") {
        if (result.exportId !== "paper_export_" + await paperCaptureValueHash({ actorId: owner.actorId, requestKey: input2.requestKey })) throw issue2();
        const expected2 = [];
        for (const book of input2.books) for (const format of input2.formats) expected2.push({ book, format, taskId: "paper_export_task_" + await paperCaptureValueHash({ exportId: result.exportId, book, format }), generation: 1 });
        if (await paperCaptureValueHash(expected2) !== await paperCaptureValueHash(result.slots)) throw issue2();
      } else if (input2.kind !== "create" && result.kind !== "create" && (result.exportId !== input2.exportId || result.book !== input2.book || result.format !== input2.format || result.previousVersion !== input2.expectedTaskVersion || result.generation !== input2.expectedGeneration + (input2.kind === "retry" ? 1 : 0) || result.taskId !== "paper_export_task_" + await paperCaptureValueHash({ exportId: input2.exportId, book: input2.book, format: input2.format }))) throw issue2();
    }
    return entry;
  }
  async function completePaperLibraryCopy(body, signal) {
    stopped(signal);
    const copy = paperLibraryCompleteCopySchema.parse({ ...body, fingerprint: "0".repeat(64) });
    if (await paperCaptureValueHash(copy) !== await paperCaptureValueHash({ ...body, fingerprint: "0".repeat(64) })) throw issue2();
    for (const entry of copy.journal) {
      stopped(signal);
      await assertPaperLibraryJournal(copy.owner, entry);
    }
    const { fingerprint: _fingerprint, ...actual } = copy;
    const final = { ...actual, fingerprint: await paperCaptureValueHash(actual) };
    if (new TextEncoder().encode(JSON.stringify(final)).length > paperLibraryCopyByteLimit) throw new Error("\u5B8C\u6574\u7A3F\u5DF2\u8FBE\u52302MiB\uFF0C\u8BF7\u5148\u4E0B\u8F7D\u5F53\u524D\u5B8C\u6574\u526F\u672C\u5E76\u53E6\u5EFA\u6E05\u5355\uFF1B\u6CA1\u6709\u622A\u65AD\u539F\u8BF7\u6C42\u3002");
    stopped(signal);
    return final;
  }
  async function readPaperLibraryCopy(value, ownerValue, signal) {
    stopped(signal);
    const owner = paperLibraryCopyOwnerSchema.parse(ownerValue), copy = paperLibraryCompleteCopySchema.parse(value), { fingerprint, ...body } = copy;
    if (await paperCaptureValueHash(owner) !== await paperCaptureValueHash(copy.owner) || await paperCaptureValueHash(body) !== fingerprint || await paperCaptureValueHash(value) !== await paperCaptureValueHash(copy)) throw issue2();
    const rebuilt = await completePaperLibraryCopy(body, signal);
    if (rebuilt.fingerprint !== fingerprint) throw issue2();
    return { copy: rebuilt, verifiedOriginalRequests: [], requiresOriginalResultLookup: true };
  }
  async function downloadPaperLibraryCopy(body) {
    const copy = await completePaperLibraryCopy(body), bytes = JSON.stringify(copy), url2 = URL.createObjectURL(new Blob([bytes], { type: "application/json" })), anchor2 = document.createElement("a");
    try {
      anchor2.href = url2;
      anchor2.download = "\u9009\u9898\u4E0E\u5BFC\u51FA\u5B8C\u6574\u7A3F-" + copy.slot + ".json";
      document.body.append(anchor2);
      anchor2.click();
    } finally {
      anchor2.remove();
      setTimeout(() => URL.revokeObjectURL(url2), 1e3);
    }
    return copy.fingerprint;
  }

  // apps/web/lib/paper-library-local.ts
  var paper_library_local_exports = {};
  __export(paper_library_local_exports, {
    PaperLibraryLocalConflict: () => PaperLibraryLocalConflict,
    PaperLibraryLocalUnavailable: () => PaperLibraryLocalUnavailable,
    clearPaperLibraryLocal: () => clearPaperLibraryLocal,
    loadPaperLibraryLocal: () => loadPaperLibraryLocal,
    paperLibraryLocalKey: () => paperLibraryLocalKey,
    savePaperLibraryLocal: () => savePaperLibraryLocal
  });
  var databaseName = "studyagent-paper-library-v1";
  var storeName = "drafts";
  var PaperLibraryLocalConflict = class extends Error {
    constructor() {
      super("\u53E6\u4E00\u6807\u7B7E\u6216\u672C\u673A\u8BB0\u5F55\u5DF2\u53D8\u5316\u3002\u5F53\u524D\u5B8C\u6574\u7A3F\u4ECD\u4FDD\u7559\uFF0C\u8BF7\u4E0B\u8F7D\u526F\u672C\u5E76\u6838\u5BF9\u4E24\u4E2A\u7248\u672C\u3002");
      this.name = "PaperLibraryLocalConflict";
    }
  };
  var PaperLibraryLocalUnavailable = class extends Error {
    constructor() {
      super("\u672C\u673A\u6682\u65F6\u4E0D\u80FD\u5B8C\u6574\u4FDD\u7559\u9009\u9898\u7A3F\u3002\u5F53\u524D\u8F93\u5165\u4ECD\u5728\u9875\u9762\u4E2D\uFF0C\u8BF7\u4E0B\u8F7D\u5B8C\u6574\u526F\u672C\u540E\u518D\u5173\u95ED\u3002");
      this.name = "PaperLibraryLocalUnavailable";
    }
  };
  var stopped2 = (signal) => {
    if (signal?.aborted) throw new DOMException("\u672C\u673A\u5B8C\u6574\u7A3F\u64CD\u4F5C\u5DF2\u505C\u6B62\uFF0C\u5F53\u524D\u8F93\u5165\u4ECD\u4FDD\u7559\u3002", "AbortError");
  };
  function paperLibraryLocalKey(owner, slot2) {
    const scope = paperLibraryCopyOwnerSchema.parse(owner);
    return JSON.stringify(["paper-library-local-v1", scope.actorId, scope.role, scope.scope.kind, scope.scope.studentId, paperLibraryDraftSlotSchema.parse(slot2)]);
  }
  function row(value, key6) {
    if (value === void 0) return null;
    const current = value;
    if (!current || typeof current !== "object" || Object.keys(current).sort().join(",") !== "body,fingerprint,key,revision,savedAt" || current.key !== key6 || !Number.isSafeInteger(current.revision) || current.revision < 1 || typeof current.savedAt !== "string" || !Number.isFinite(Date.parse(current.savedAt)) || (current.body === null ? current.fingerprint !== null : typeof current.body !== "string" || current.body.length > paperLibraryCopyByteLimit || typeof current.fingerprint !== "string" || !/^[a-f0-9]{64}$/.test(current.fingerprint)))
      throw new Error("\u672C\u673A\u65E7\u7A3F\u7684\u683C\u5F0F\u9700\u8981\u6838\u5BF9\uFF0C\u539F\u8BB0\u5F55\u6CA1\u6709\u88AB\u8986\u76D6\u6216\u79FB\u9664\u3002");
    return current;
  }
  var same = (a, b) => a === null || b === null ? a === b : a.key === b.key && a.revision === b.revision && a.fingerprint === b.fingerprint && a.body === b.body && a.savedAt === b.savedAt;
  function open2() {
    return new Promise((yes, no) => {
      let request, rejected = false;
      try {
        if (!globalThis.indexedDB) throw Error();
        request = indexedDB.open(databaseName, 1);
      } catch {
        no(new PaperLibraryLocalUnavailable());
        return;
      }
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(storeName)) request.result.createObjectStore(storeName, { keyPath: "key" });
      };
      request.onerror = request.onblocked = () => {
        rejected = true;
        no(new PaperLibraryLocalUnavailable());
      };
      request.onsuccess = () => {
        const db = request.result;
        if (rejected) {
          db.close();
          return;
        }
        db.onversionchange = () => db.close();
        yes(db);
      };
    });
  }
  async function readRaw(key6, signal) {
    stopped2(signal);
    const db = await open2();
    try {
      stopped2(signal);
      return await new Promise((yes, no) => {
        const tx = db.transaction(storeName, "readonly"), request = tx.objectStore(storeName).get(key6);
        let result = null, reason;
        const abort = () => {
          try {
            tx.abort();
          } catch {
          }
        };
        signal?.addEventListener("abort", abort, { once: true });
        request.onsuccess = () => {
          try {
            stopped2(signal);
            result = row(request.result, key6);
          } catch (error62) {
            reason = error62;
            abort();
          }
        };
        tx.oncomplete = () => {
          signal?.removeEventListener("abort", abort);
          try {
            stopped2(signal);
            yes(result);
          } catch (error62) {
            no(error62);
          }
        };
        tx.onerror = tx.onabort = () => {
          signal?.removeEventListener("abort", abort);
          no(reason ?? (signal?.aborted ? new DOMException("\u672C\u673A\u8BFB\u53D6\u5DF2\u505C\u6B62\u3002", "AbortError") : new PaperLibraryLocalUnavailable()));
        };
      });
    } finally {
      db.close();
    }
  }
  async function checkedRaw(owner, slot2, signal) {
    const current = await readRaw(paperLibraryLocalKey(owner, slot2), signal);
    if (current === null || current.body === null) return { row: current, copy: null };
    let parsed;
    try {
      parsed = JSON.parse(current.body);
    } catch {
      throw new Error("\u672C\u673A\u65E7\u7A3F\u5185\u5BB9\u9700\u8981\u6838\u5BF9\uFF0C\u539F\u8BB0\u5F55\u6CA1\u6709\u88AB\u8986\u76D6\u6216\u79FB\u9664\u3002");
    }
    const { copy } = await readPaperLibraryCopy(parsed, owner, signal);
    if (copy.slot !== slot2 || copy.fingerprint !== current.fingerprint) throw new PaperLibraryLocalConflict();
    return { row: current, copy };
  }
  async function loadPaperLibraryLocal(owner, slot2, signal) {
    const actual = await checkedRaw(owner, slot2, signal);
    return { copy: actual.copy, revision: actual.row?.revision ?? null, fingerprint: actual.row?.fingerprint ?? null, savedAt: actual.row?.savedAt ?? null };
  }
  async function replace(key6, reviewed, next, signal) {
    stopped2(signal);
    const db = await open2();
    try {
      stopped2(signal);
      await new Promise((yes, no) => {
        const tx = db.transaction(storeName, "readwrite"), store = tx.objectStore(storeName), request = store.get(key6);
        let reason;
        const abort = () => {
          try {
            tx.abort();
          } catch {
          }
        };
        signal?.addEventListener("abort", abort, { once: true });
        request.onsuccess = () => {
          try {
            stopped2(signal);
            if (!same(row(request.result, key6), reviewed)) throw new PaperLibraryLocalConflict();
            store.put(next);
          } catch (error62) {
            reason = error62;
            abort();
          }
        };
        tx.oncomplete = () => {
          signal?.removeEventListener("abort", abort);
          try {
            stopped2(signal);
            yes();
          } catch (error62) {
            no(error62);
          }
        };
        tx.onerror = tx.onabort = () => {
          signal?.removeEventListener("abort", abort);
          no(reason ?? (signal?.aborted ? new DOMException("\u672C\u673A\u5199\u5165\u5DF2\u505C\u6B62\u3002", "AbortError") : new PaperLibraryLocalUnavailable()));
        };
      });
    } finally {
      db.close();
    }
    if (!same(await readRaw(key6, signal), next)) throw new PaperLibraryLocalConflict();
  }
  function expected(current, value) {
    if (value.revision !== null && (!Number.isSafeInteger(value.revision) || value.revision < 1) || (current?.revision ?? null) !== value.revision || (current?.fingerprint ?? null) !== value.fingerprint || current?.revision === Number.MAX_SAFE_INTEGER) throw new PaperLibraryLocalConflict();
  }
  async function savePaperLibraryLocal(copyValue, owner, slot2, version2, signal) {
    const { copy } = await readPaperLibraryCopy(copyValue, owner, signal);
    if (copy.slot !== slot2) throw new PaperLibraryLocalConflict();
    const key6 = paperLibraryLocalKey(owner, slot2), reviewed = (await checkedRaw(owner, slot2, signal)).row;
    expected(reviewed, version2);
    const next = { key: key6, revision: (reviewed?.revision ?? 0) + 1, fingerprint: copy.fingerprint, body: JSON.stringify(copy), savedAt: (/* @__PURE__ */ new Date()).toISOString() };
    await replace(key6, reviewed, next, signal);
    return { revision: next.revision, fingerprint: next.fingerprint, savedAt: next.savedAt };
  }
  async function clearPaperLibraryLocal(owner, slot2, version2, signal) {
    const key6 = paperLibraryLocalKey(owner, slot2), reviewed = (await checkedRaw(owner, slot2, signal)).row;
    expected(reviewed, version2);
    if (!reviewed?.body) throw new PaperLibraryLocalConflict();
    const next = { key: key6, revision: reviewed.revision + 1, fingerprint: null, body: null, savedAt: (/* @__PURE__ */ new Date()).toISOString() };
    await replace(key6, reviewed, next, signal);
    return { revision: next.revision, fingerprint: null, savedAt: next.savedAt };
  }

  // apps/web/lib/paper-library-client.ts
  var paper_library_client_exports = {};
  __export(paper_library_client_exports, {
    lookupPaperLibraryCommand: () => lookupPaperLibraryCommand,
    sendPaperLibraryCommand: () => sendPaperLibraryCommand
  });

  // packages/config/src/index.ts
  var apiEnvSchema = external_exports.object({
    API_PORT: external_exports.coerce.number().int().min(1).max(65535).optional(),
    API_HOST: external_exports.string().trim().min(1).default("127.0.0.1"),
    PORT: external_exports.coerce.number().int().min(1).max(65535).default(4e3),
    DATABASE_URL: external_exports.string().default("postgresql://user:password@localhost:5432/study_agent"),
    OPENAI_API_KEY: external_exports.string().optional(),
    OPENAI_BASE_URL: external_exports.string().default("https://api.openai.com/v1"),
    OPENAI_MODEL: external_exports.string().default("gpt-4.1-mini"),
    OPENAI_TTS_MODEL: external_exports.string().default("tts-1"),
    OPENAI_TTS_VOICE: external_exports.string().default("alloy"),
    MINIMAX_API_KEY: external_exports.string().optional(),
    MINIMAX_TTS_BASE_URL: external_exports.string().url().default("https://api.minimaxi.com/v1/t2a_v2"),
    MINIMAX_TTS_MODEL: external_exports.string().default("speech-2.8-turbo"),
    MINIMAX_TTS_VOICE: external_exports.string().default("Chinese (Mandarin)_Warm_Girl"),
    MINIMAX_TTS_SPEED: external_exports.coerce.number().min(0.5).max(2).default(1),
    MINIMAX_TTS_VOLUME: external_exports.coerce.number().min(0.1).max(10).default(1),
    MINIMAX_TTS_PITCH: external_exports.coerce.number().int().min(-12).max(12).default(0),
    MINIMAX_TTS_EMOTION: external_exports.string().optional(),
    MINIMAX_TTS_MAX_RETRIES: external_exports.coerce.number().int().min(0).max(3).default(1),
    CODEX_COMMAND: external_exports.string().default("codex"),
    CODEX_MODEL: external_exports.string().optional(),
    CODEX_TIMEOUT_MS: external_exports.coerce.number().int().positive().default(12e4),
    CODEX_PDF_TIMEOUT_MS: external_exports.coerce.number().int().positive().default(24e4),
    CODEX_PDF_MODEL: external_exports.string().trim().min(1).default("deepseek-v4-flash"),
    XIAOJIU_CHAT_ENABLED: external_exports.enum(["true", "false"]).default("true"),
    XIAOJIU_CHAT_DEFAULT_MODEL: external_exports.string().trim().min(1).default("deepseek-v4-flash"),
    XIAOJIU_CHAT_TIMEOUT_MS: external_exports.coerce.number().int().positive().default(9e4),
    JWT_SECRET: external_exports.string().default("study-agent-dev-secret"),
    TEXTBOOK_BASE_PATH: external_exports.string().default("E:\\ChinaTextbook")
  });
  var webEnvSchema = external_exports.object({
    NEXT_PUBLIC_API_BASE_URL: external_exports.string().default("http://localhost:4000"),
    PORT: external_exports.coerce.number().optional(),
    WEB_PORT: external_exports.coerce.number().optional()
  });
  function loadWebEnv(source = process.env) {
    return webEnvSchema.parse(source);
  }

  // apps/web/lib/api.ts
  var webEnv = loadWebEnv({
    NEXT_PUBLIC_API_BASE_URL: ""
  });
  var apiBaseUrl = webEnv.NEXT_PUBLIC_API_BASE_URL;
  var sessionToken = null;
  function getAuthToken() {
    if (typeof window === "undefined") {
      return null;
    }
    return sessionToken;
  }
  var ApiRequestError = class extends Error {
    constructor(message2, status, code, details) {
      super(message2);
      this.status = status;
      this.code = code;
      this.details = details;
      this.name = "ApiRequestError";
    }
    status;
    code;
    details;
  };
  async function apiRequest(path, options = {}, token) {
    const bearer = token === void 0 ? getAuthToken() : token;
    const response = await fetch(`${apiBaseUrl}/api${path}`, {
      ...options,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...bearer ? { Authorization: `Bearer ${bearer}` } : {},
        ...options.headers ?? {}
      }
    }).catch((error62) => {
      if (error62.name === "AbortError") throw error62;
      throw new Error("\u6682\u65F6\u65E0\u6CD5\u8FDE\u63A5\u5B66\u4E60\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002\u5DF2\u4FDD\u5B58\u7684\u6570\u636E\u4F1A\u4FDD\u7559\u3002");
    });
    let payload = null;
    try {
      payload = await response.json();
    } catch {
      payload = null;
    }
    if (!response.ok || payload?.error) {
      const details = payload?.error?.details;
      throw new ApiRequestError(
        payload?.error?.message ?? `Request failed: ${response.status}`,
        response.status,
        payload?.error?.code,
        details && typeof details === "object" && !Array.isArray(details) ? details : void 0
      );
    }
    if (!payload) {
      throw new Error(`Request failed: ${response.status}`);
    }
    return payload.data;
  }

  // apps/web/lib/paper-library-client.ts
  var route = (family) => family === "selection" ? "/library/selection-commands" : "/library/export-commands";
  function stopped3(signal) {
    if (signal?.aborted) throw new DOMException("\u539F\u8BF7\u6C42\u6838\u5BF9\u5DF2\u505C\u6B62\uFF0C\u5B8C\u6574\u539F\u547D\u4EE4\u4ECD\u4FDD\u7559\u3002", "AbortError");
  }
  var message = (error62) => (error62 instanceof Error ? error62.message : "\u539F\u7ED3\u679C\u6682\u65F6\u4E0D\u80FD\u6838\u5BF9\uFF0C\u8BF7\u4FDD\u7559\u5B8C\u6574\u539F\u8BF7\u6C42\u3002").slice(0, 4e3);
  var uncertain = (entry, reason) => paperLibraryJournalSchema.parse({ ...entry, phase: entry.result ? "received" : "unknown", message: reason });
  async function receipt(owner, entry, resultValue) {
    const result = (entry.family === "selection" ? paperSelectionResultSchema : paperExportResultSchema).parse(resultValue);
    if (entry.result && await paperLibraryValueHash(entry.result) !== await paperLibraryValueHash(result)) throw new Error("\u670D\u52A1\u5668\u539F\u56DE\u6267\u4E0E\u8FD9\u4EFD\u526F\u672C\u4E0D\u540C\u3002\u4E24\u4EFD\u539F\u4FE1\u606F\u4ECD\u4FDD\u7559\uFF0C\u8BF7\u5148\u6838\u5BF9\uFF0C\u672A\u81EA\u52A8\u91C7\u7528\u6216\u91CD\u53D1\u3002");
    return assertPaperLibraryJournal(owner, { ...entry, phase: "received", result, message: "" });
  }
  async function lookupPaperLibraryCommand(owner, value, signal, transport = apiRequest) {
    stopped3(signal);
    const entry = await assertPaperLibraryJournal(owner, structuredClone(value));
    stopped3(signal);
    const response = await transport(route(entry.family) + "/" + encodeURIComponent(entry.input.requestKey), { signal });
    stopped3(signal);
    if (response === null) return { verified: false, entry: uncertain(entry, "\u8FD8\u672A\u67E5\u8BE2\u5230\u539F\u56DE\u6267\uFF0C\u539F\u8BF7\u6C42\u4ECD\u53EF\u80FD\u7A0D\u540E\u5B8C\u6210\u3002\u8BF7\u4FDD\u7559\u5B8C\u6574\u7A3F\uFF0C\u6838\u5BF9\u6216\u6309\u539F\u547D\u4EE4\u91CD\u8BD5\u3002"), current: null };
    if (!response || typeof response !== "object" || Object.keys(response).sort().join(",") !== "current,input,result") throw new Error("\u670D\u52A1\u5668\u8FD4\u56DE\u7684\u539F\u547D\u4EE4\u4E0D\u5B8C\u6574\uFF0C\u8BF7\u4FDD\u7559\u5F53\u524D\u5B8C\u6574\u7A3F\u3002");
    const original = response, input2 = (entry.family === "selection" ? paperSelectionCommandSchema : paperExportCommandSchema).parse(original.input);
    if (await paperLibraryValueHash(input2) !== await paperLibraryValueHash(original.input) || await paperLibraryRequestFingerprint(owner, entry.family, input2) !== entry.requestFingerprint) throw new Error("\u8FD9\u4E2A\u8BF7\u6C42\u952E\u5BF9\u5E94\u53E6\u4E00\u4EFD\u5B8C\u6574\u547D\u4EE4\uFF0C\u672A\u8986\u76D6\u5F53\u524D\u7F16\u8F91\u6216\u91CD\u53D1\u3002");
    const verified = await receipt(owner, entry, original.result);
    stopped3(signal);
    return { verified: true, entry: verified, current: structuredClone(original.current) };
  }
  async function sendPaperLibraryCommand(owner, value, retain, signal, transport = apiRequest) {
    stopped3(signal);
    let entry = uncertain(await assertPaperLibraryJournal(owner, structuredClone(value)), "\u6B63\u5728\u63D0\u4EA4\u539F\u8BF7\u6C42\uFF1B\u79BB\u5F00\u6216\u4E2D\u65AD\u540E\u8BF7\u5148\u6838\u5BF9\u539F\u7ED3\u679C\u3002");
    await retain(structuredClone(entry));
    stopped3(signal);
    try {
      const result = await transport(route(entry.family), { method: "POST", body: JSON.stringify(entry.input), signal });
      stopped3(signal);
      entry = await receipt(owner, entry, result);
      stopped3(signal);
      await retain(structuredClone(entry));
      stopped3(signal);
    } catch (error62) {
      stopped3(signal);
      entry = uncertain(entry, message(error62));
      await retain(structuredClone(entry));
      stopped3(signal);
    }
    try {
      const actual = await lookupPaperLibraryCommand(owner, entry, signal, transport);
      stopped3(signal);
      await retain(structuredClone(actual.entry));
      stopped3(signal);
      return actual;
    } catch (error62) {
      stopped3(signal);
      entry = uncertain(entry, message(error62));
      await retain(structuredClone(entry));
      stopped3(signal);
      return { verified: false, entry, current: null };
    }
  }

  // generated-library-codec-entry.ts
  window.libraryIO = { ...paper_library_copy_exports, ...paper_library_local_exports, ...paper_library_client_exports };
})();
