# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-settings.spec.ts >> share toolbar: a private link reopens the same board and a real PNG exactly decodes the visible frozen canvas
- Location: tests\e2e\whiteboard-settings.spec.ts:108:5

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator: getByRole('dialog', { name: '白板视频', exact: true }).getByRole('button', { name: '分享与导出', exact: true })
Expected: focused
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeFocused" getByRole('dialog', { name: '白板视频', exact: true }).getByRole('button', { name: '分享与导出', exact: true }) with timeout 15000ms
  - waiting for getByRole('dialog', { name: '白板视频', exact: true }).getByRole('button', { name: '分享与导出', exact: true })

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - button "Home": 首页
      - button "Courses": 课程
      - button "Calendar": 学习动态
      - button "History": 历史
      - button "Materials": 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - button "＋ 创建课程"
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom?lesson=soc-1-1-1
    - heading "近期活动" [level=2]
    - link "白板视频「异分母分数加法」":
      - /url: /studio?whiteboard=studio_whiteboard_7bac9014-9623-4fce-8910-6f34e333d0e7
    - link "返回学习首页 →":
      - /url: /learn?subject=math&student=student_635f1c59-4624-47e4-9441-5f7ad0fab586
  - combobox "学习档案":
    - option "匿名设置验证" [selected]
  - combobox "学科":
    - option "数学" [selected]
    - option "语文"
    - option "英语"
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "把下一步，做成一条走得通的路。" [level=1]
  - paragraph: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
  - textbox "围绕哪段学习内容设计课程？"
  - text: ＋ 资料
  - button "Concept Explanation"
  - text: 语音 模型
  - combobox "选择大模型":
    - option "Auto · 当前默认模型"
  - button "↑"
  - button "可视化 用图形解释异分母加法 通分、合并与验算"
  - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围"
  - button "主动学习 看看今天最值得做什么 按教育优先级排序"
  - heading "你的学习路径" [level=2]
  - button "创建课程"
  - heading "还没有课程" [level=3]
  - paragraph: 先确认学习范围，再从已学知识生成可审核蓝图。
  - button "生成第一门课程"
  - complementary:
    - article:
      - text: LEARNER SNAPSHOT
      - heading "匿名设置验证" [level=2]
      - text: 5 年级
      - strong: "0"
      - text: / 1 已有点有稳定证据 1 已确认知识点 0 日历安排
    - article:
      - text: NEXT BEST ACTION
      - button "全部 →"
      - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。":
        - /url: /student/assessment?studentId=student_635f1c59-4624-47e4-9441-5f7ad0fab586&subject=math
        - text: 1个已学点仍需补充证据
        - paragraph: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
    - article:
      - text: RECENT WHITEBOARDS
      - button "新建"
      - button "▶ 匿名逐句白板 2 幕 · 1 秒"
    - article:
      - text: SYNC STATUS
      - button "日历 →"
      - paragraph: 0 个 LMS / 日历来源 · 0 个安排
      - text: 同步只读取课程日期；学习掌握仍由独立测量形成。
```

# Test source

```ts
  16  |   await call('/students/'+child+'/learning-scope',{subject:'math',grade:5,term:'upper',textbookVolumeId:null,textbookVersion:'合成范围',learnedAtomIds:['core:math:fractionadd'],currentAtomId:'core:math:fractionadd',minutesPerSession:15,progressMode:'knowledge',selectedLessonIds:[]},actor.token,'PUT');
  17  |   const input={studentId:child,subject:'math',prompt:'解释异分母分数加法',atomId:'core:math:fractionadd'},preview=await call('/learning/studio/whiteboards/preview',input,actor.token),saved=await call('/learning/studio/whiteboards',{...input,fingerprint:preview.fingerprint,requestKey:randomUUID()},actor.token),board=await call('/qa/whiteboard-media',{boardId:saved.id},actor.token);
  18  |   await page.route('**/api/learning/studio/overview?*',async route=>{const response=await route.fetch(),payload=await response.json();payload.data.narrationAvailable=true;payload.data.speech={available:true,provider:'minimax',defaultVoice:manifest.voices[0].voiceId,voices:manifest.voices.map((voice:any)=>({id:voice.voiceId,label:voice.providerName,language:voice.language,classroomPreset:voice.preset}))};await route.fulfill({response,json:payload});});
  19  |   await page.addInitScript(()=>{const NativeAudio=window.Audio;(window as any).settingsAudio=[];(window as any).Audio=function(src?:string){const audio=new NativeAudio(src);(window as any).settingsAudio.push(audio);return audio;};});
  20  |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  21  |   const href='/studio?student='+child+'&subject=math&whiteboard='+board.id;await page.goto(href);const player=page.getByRole('dialog',{name:'白板视频',exact:true});await expect(player).toHaveAttribute('data-original-font-status','ready');
  22  |   const current=player.locator('.wb-current-sentence');await expect(current).toContainText('先统一单位');return {player,current,href,board};
  23  | }
  24  | 
  25  | test('original settings: six actual neutral MP3s decode, previews preserve selection and closing releases audio',async({page})=>{
  26  |   await page.setViewportSize({width:1280,height:800});const f=await fixture(page),unit=await f.current.getAttribute('data-unit-id'),writes:string[]=[];page.on('request',request=>{if(request.method()==='POST')writes.push(request.url());});
  27  |   await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});await expect(settings.getByRole('radio')).toHaveCount(6);
  28  |   await settings.evaluate(async element=>{await Promise.all(element.getAnimations().map(animation=>animation.finished));});
  29  |   expect((await settings.boundingBox())!.width).toBe(460);const selected=await f.player.getByRole('combobox',{name:'旁白音色',exact:true}).inputValue();
  30  |   const decoded=[];
  31  |   for(const voice of manifest.voices){await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect.poll(()=>page.evaluate(()=>{const audio=(window as any).settingsAudio.at(-1) as HTMLAudioElement;return audio&&!audio.paused&&audio.currentTime>0;})).toBe(true);
  32  |     const result=await page.evaluate(()=>{const audio=(window as any).settingsAudio.at(-1) as HTMLAudioElement;return {duration:audio.duration,rate:audio.playbackRate};});expect(Math.abs(result.duration-voice.durationSeconds)).toBeLessThan(.25);decoded.push({voice:voice.preset,...result});
  33  |     await expect(f.player.getByRole('combobox',{name:'旁白音色',exact:true})).toHaveValue(selected);await expect(f.current).toHaveAttribute('data-unit-id',unit!);
  34  |   }
  35  |   await settings.getByRole('radio',{name:'Calm',exact:true}).click();await expect(f.player.getByRole('combobox',{name:'旁白音色',exact:true})).toHaveValue(manifest.voices.find((voice:any)=>voice.preset==='calm').voiceId);
  36  |   await settings.getByRole('button',{name:'停止试听：'+manifest.voices.find((voice:any)=>voice.preset==='calm').providerName,exact:true}).click();
  37  |   await settings.evaluate(async element=>{await Promise.allSettled(element.getAnimations({subtree:true}).filter(animation=>animation.effect?.getTiming().iterations!==Infinity).map(animation=>animation.finished));});
  38  |   await page.screenshot({path:join(browserEvidence('whiteboard-settings'),'original-settings-1280.png')});
  39  |   await page.keyboard.press('Escape');await expect(settings).toHaveCount(0);await expect(f.player).toBeVisible();expect(await page.evaluate(()=>(window as any).settingsAudio.every((audio:HTMLAudioElement)=>audio.paused))).toBe(true);expect(writes).toEqual([]);
  40  |   await expect(f.player.getByRole('button',{name:'播放',exact:true})).toBeEnabled();writeFileSync(join(browserEvidence('whiteboard-settings'),'actual-neutral-clip-decode.json'),JSON.stringify({decoded,writes,unit},null,2)+'\n');
  41  | });
  42  | 
  43  | test('original settings: corrupt samples fail visibly, explicit retry works and a late closed sample never plays',async({page})=>{
  44  |   const f=await fixture(page),voice=manifest.voices[0],url='**/classroom-voice-samples/'+voice.file;await page.route(url,route=>route.fulfill({status:200,contentType:'audio/mpeg',body:Buffer.from('Changed sample')}));
  45  |   await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect(settings.getByRole('status')).toContainText('与原样本不一致');expect(await page.evaluate(()=>(window as any).settingsAudio.length)).toBe(0);
  46  |   await page.unroute(url);await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).settingsAudio.some((audio:HTMLAudioElement)=>!audio.paused))).toBe(true);
  47  |   await settings.getByRole('button',{name:'关闭白板设置',exact:true}).click();await f.player.getByRole('button',{name:'白板设置',exact:true}).click();let reached=false;
  48  |   await page.route(url,async route=>{reached=true;const response=await route.fetch();await new Promise(resolve=>setTimeout(resolve,800));try{await route.fulfill({response});}catch{}});
  49  |   await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect.poll(()=>reached).toBe(true);await settings.getByRole('button',{name:'关闭白板设置',exact:true}).click();await page.waitForTimeout(1000);expect(await page.evaluate(()=>(window as any).settingsAudio.every((audio:HTMLAudioElement)=>audio.paused))).toBe(true);await expect(f.current).toContainText('先统一单位');
  50  | });
  51  | 
  52  | test('original settings: half speed restores, double speed records real WAV and frozen captions at matching durations',async({page})=>{
  53  |   const f=await fixture(page);await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});await settings.getByRole('slider',{name:'白板语速',exact:true}).fill('0');await settings.getByRole('button',{name:'关闭白板设置',exact:true}).click();await expect(f.player.getByRole('combobox',{name:'播放速度',exact:true})).toHaveValue('0.5');
  54  |   await expect.poll(()=>page.evaluate(()=>Object.keys(localStorage).some(key=>key.includes('.location.v1.')&&JSON.parse(localStorage.getItem(key)!).speed===.5))).toBe(true);await page.reload();await expect(f.player.getByRole('combobox',{name:'播放速度',exact:true})).toHaveValue('0.5');
  55  |   await f.player.getByRole('button',{name:'播放',exact:true}).click();await expect.poll(()=>page.evaluate(()=>{const audio=(window as any).settingsAudio.find((audio:HTMLAudioElement)=>!audio.paused);return audio?.playbackRate;})).toBe(.5);await f.player.getByRole('button',{name:'暂停',exact:true}).click();
  56  |   const half=page.waitForEvent('download');await f.player.getByRole('button',{name:'导出字幕',exact:true}).click();expect(readFileSync((await(await half).path())!,'utf8')).toContain('00:00:12,000 --> 00:00:16,000');
  57  |   await f.player.getByRole('combobox',{name:'播放速度',exact:true}).selectOption('2');const video=page.waitForEvent('download');await f.player.getByRole('button',{name:'导出视频',exact:true}).click();const file=(await(await video).path())!,probe=JSON.parse(execFileSync(process.env.STUDY_FFPROBE??'ffprobe',['-v','error','-show_format','-show_streams','-of','json',file],{encoding:'utf8',windowsHide:true}));expect(probe.streams.some((stream:any)=>stream.codec_type==='audio')).toBe(true);expect(Math.abs(Number(probe.format.duration)-4)).toBeLessThan(.6);
  58  |   const subtitles=page.waitForEvent('download');await f.player.getByRole('button',{name:'导出字幕',exact:true}).click();const srt=readFileSync((await(await subtitles).path())!,'utf8');expect(srt).toContain('00:00:03,000 --> 00:00:04,000');const directory=browserEvidence('whiteboard-settings');copyFileSync(file,join(directory,'double-rate.webm'));writeFileSync(join(directory,'double-rate-probe.json'),JSON.stringify(probe,null,2)+'\n');writeFileSync(join(directory,'double-rate.srt'),srt);
  59  | });
  60  | 
  61  | for(const width of [390,1280])test('original settings: real seven-tool tour preserves position and focus at '+width,async({page})=>{
  62  |   await page.setViewportSize({width,height:800});const f=await fixture(page),unit=await f.current.getAttribute('data-unit-id'),writes:string[]=[];page.on('request',request=>{if(request.method()==='POST')writes.push(request.url());});
  63  |   await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});
  64  |   await expect(settings.getByRole('button',{name:/Replay the tour/})).toBeVisible();await settings.getByRole('button',{name:/Replay the tour/}).click();await expect(settings).toHaveCount(0);
  65  |   const tour=page.getByRole('dialog',{name:'白板工具导览',exact:true});await tour.getByRole('button',{name:'开始导览',exact:true}).click();
  66  |   for(const[index,anchor]of ['connection','zoom','settings','sound','playback','history','notes'].entries()){
  67  |     const target=tour.locator('.cl-tour-target');await expect(target).toHaveAttribute('data-anchor',anchor);await expect(tour.locator('.cl-tour-unavailable')).toHaveCount(0);
  68  |     const bounds=(await target.boundingBox())!;expect(bounds.x).toBeGreaterThanOrEqual(0);expect(bounds.y).toBeGreaterThanOrEqual(0);expect(bounds.x+bounds.width).toBeLessThanOrEqual(width+1);expect(bounds.y+bounds.height).toBeLessThanOrEqual(801);
  69  |     await tour.getByRole('button',{name:index===6?/^完成/:/^下一步/}).click();
  70  |   }
  71  |   await tour.getByRole('button',{name:'返回白板',exact:true}).click();await expect(tour).toHaveCount(0);await expect(f.current).toHaveAttribute('data-unit-id',unit!);await expect(f.player.getByRole('button',{name:'白板设置',exact:true})).toBeFocused();expect(writes).toEqual([]);
  72  | });
  73  | 
  74  | test('reading panel: original380 width, pointer and keyboard bounds, viewport cap and collapsed preference restore without teaching writes',async({page})=>{
  75  |   await page.setViewportSize({width:1440,height:900});const f=await fixture(page),unit=await f.current.getAttribute('data-unit-id'),writes:string[]=[];
  76  |   page.on('request',request=>{if(request.method()==='POST')writes.push(request.url());});
  77  |   const separator=f.player.getByRole('separator',{name:'调整讲稿面板宽度',exact:true});await expect(separator).toHaveAttribute('aria-valuenow','380');
  78  |   expect((await f.player.locator('.hk-reading-panel').boundingBox())!.width).toBe(380);
  79  |   const bounds=(await separator.boundingBox())!;await page.mouse.move(bounds.x+bounds.width/2,450);await page.mouse.down();await page.mouse.move(700,450,{steps:6});await page.mouse.up();
  80  |   await expect(separator).toHaveAttribute('aria-valuenow','560');await expect(f.current).toHaveAttribute('data-unit-id',unit!);
  81  |   await page.setViewportSize({width:1200,height:900});await expect(separator).toHaveAttribute('aria-valuenow','504');expect((await f.player.locator('.hk-reading-panel').boundingBox())!.width).toBe(504);
  82  |   await page.setViewportSize({width:1440,height:900});await expect(separator).toHaveAttribute('aria-valuenow','560');
  83  |   await separator.focus();await page.keyboard.press('Home');await expect(separator).toHaveAttribute('aria-valuenow','300');await page.keyboard.press('End');await expect(separator).toHaveAttribute('aria-valuenow','560');await page.keyboard.press('ArrowRight');await expect(separator).toHaveAttribute('aria-valuenow','550');
  84  |   const toggle=f.player.locator('[data-panel-toggle]');await toggle.click();await expect(toggle).toHaveAttribute('aria-expanded','false');await expect(f.player.getByLabel('完整讲稿与要点')).toBeHidden();
  85  |   await expect.poll(()=>page.evaluate(()=>Object.keys(localStorage).some(key=>key.startsWith('studyagent.whiteboard.layout.v1.')&&JSON.parse(localStorage.getItem(key)!).expanded===false))).toBe(true);
  86  |   await page.reload();await expect(f.player).toHaveAttribute('data-original-font-status','ready');await expect(toggle).toHaveAttribute('aria-expanded','false');await toggle.click();await expect(separator).toHaveAttribute('aria-valuenow','550');await expect(f.current).toHaveAttribute('data-unit-id',unit!);
  87  |   const preference=await page.evaluate(()=>JSON.parse(localStorage.getItem(Object.keys(localStorage).find(key=>key.startsWith('studyagent.whiteboard.layout.v1.'))!)!));expect(Object.keys(preference).sort()).toEqual(['expanded','ownerId','version','width']);expect(writes).toEqual([]);
  88  |   await page.screenshot({path:join(browserEvidence('whiteboard-settings'),'reading-panel-1440.png')});
  89  | });
  90  | 
  91  | for(const width of [390,768])test('reading panel: explicit mobile entry contains focus, returns to the same sentence and closes only its own layer at '+width,async({page})=>{
  92  |   await page.setViewportSize({width,height:800});const f=await fixture(page),unit=await f.current.getAttribute('data-unit-id'),writes:string[]=[];page.on('request',request=>{if(request.method()==='POST')writes.push(request.url());});
  93  |   const toggle=f.player.getByRole('button',{name:'讲稿与笔记',exact:true});await expect(toggle).toHaveAttribute('aria-expanded','false');await expect(f.player.getByLabel('完整讲稿与要点')).toBeHidden();
  94  |   await toggle.click();const reader=page.getByRole('dialog',{name:'讲稿与笔记',exact:true});await expect(reader).toBeVisible();await expect(reader.getByRole('button',{name:'返回白板画面',exact:true})).toBeFocused();
  95  |   expect(await reader.evaluate(element=>element.scrollWidth<=element.clientWidth+1)).toBe(true);await page.keyboard.press('Shift+Tab');expect(await reader.evaluate(element=>element.contains(document.activeElement))).toBe(true);
  96  |   await page.screenshot({path:join(browserEvidence('whiteboard-settings'),'reading-panel-'+width+'.png')});await page.keyboard.press('Escape');await expect(reader).toHaveCount(0);await expect(f.player).toBeVisible();await expect(toggle).toBeFocused();await expect(f.current).toHaveAttribute('data-unit-id',unit!);
  97  |   await toggle.click();await reader.getByRole('button',{name:'返回白板画面',exact:true}).click();await expect(toggle).toBeFocused();expect(writes).toEqual([]);
  98  | });
  99  | 
  100 | test('reading panel: malformed or wrong-owner device preferences are rejected and blocked storage leaves resizing usable',async({page})=>{
  101 |   await page.setViewportSize({width:1280,height:800});const f=await fixture(page);
  102 |   await page.evaluate(()=>{const key=Object.keys(localStorage).find(key=>key.startsWith('studyagent.whiteboard.layout.v1.'))!;localStorage.setItem(key,JSON.stringify({version:1,ownerId:'another-owner',width:560,expanded:false}));});
  103 |   await page.reload();const separator=f.player.getByRole('separator',{name:'调整讲稿面板宽度',exact:true});await expect(separator).toHaveAttribute('aria-valuenow','380');
  104 |   await page.addInitScript(()=>{const get=Storage.prototype.getItem,set=Storage.prototype.setItem;Storage.prototype.getItem=function(key){if(key.startsWith('studyagent.whiteboard.layout.v1.'))throw new DOMException('Blocked','SecurityError');return get.call(this,key);};Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.whiteboard.layout.v1.'))throw new DOMException('Blocked','QuotaExceededError');return set.call(this,key,value);};});
  105 |   await page.reload();await expect(f.player).toHaveAttribute('data-original-font-status','ready');await expect(separator).toHaveAttribute('aria-valuenow','380');await separator.focus();await page.keyboard.press('ArrowLeft');await expect(separator).toHaveAttribute('aria-valuenow','390');await expect(f.player.getByRole('button',{name:'播放',exact:true})).toBeEnabled();
  106 | });
  107 | 
  108 | test('share toolbar: a private link reopens the same board and a real PNG exactly decodes the visible frozen canvas',async({page,context})=>{
  109 |   await page.setViewportSize({width:1280,height:800});const f=await fixture(page),unit=await f.current.getAttribute('data-unit-id'),writes:string[]=[];page.on('request',request=>{if(request.method()==='POST')writes.push(request.url());});
  110 |   await context.grantPermissions(['clipboard-read','clipboard-write'],{origin:new URL(page.url()).origin});
  111 |   const icon=JSON.parse(readFileSync(join(process.cwd(),'apps/web/public/reference/hyperknow-controls/manifest.json'),'utf8')).files[0],iconResponse=await page.request.get('/reference/hyperknow-controls/chat.svg');expect(iconResponse.status()).toBe(200);expect(createHash('sha256').update(await iconResponse.body()).digest('hex')).toBe(icon.sha256);await expect(f.player.locator('[data-panel-toggle] img')).toHaveJSProperty('naturalWidth',32);
  112 |   await expect(f.player.getByRole('button',{name:'上一页白板',exact:true})).toBeDisabled();await expect(f.player.getByRole('button',{name:'下一页白板',exact:true})).toBeDisabled();
  113 |   const trigger=f.player.getByRole('button',{name:'分享与导出',exact:true});await trigger.click();const menu=page.getByRole('dialog',{name:'分享与导出',exact:true});
  114 |   await expect(menu.locator('.whiteboard-share-menu-hint').first()).toHaveText('需要原账号的访问权限。');await menu.getByRole('button',{name:'复制白板链接',exact:true}).click();await expect(menu.getByRole('status')).toHaveText('链接已复制。');
  115 |   const copied=await page.evaluate(()=>navigator.clipboard.readText()),url=new URL(copied);expect(url.origin).toBe(new URL(page.url()).origin);expect([...url.searchParams.keys()].sort()).toEqual(['student','subject','whiteboard']);expect(url.searchParams.get('whiteboard')).toBe(f.board.id);
> 116 |   await page.keyboard.press('Escape');await expect(menu).toHaveCount(0);await expect(trigger).toBeFocused();await expect(f.player).toBeVisible();await expect(f.current).toHaveAttribute('data-unit-id',unit!);
      |                                                                                               ^ Error: expect(locator).toBeFocused() failed
  117 |   const canvas=f.player.locator('canvas').first(),before=Buffer.from((await canvas.evaluate(element=>(element as HTMLCanvasElement).toDataURL('image/png'))).split(',')[1],'base64');
  118 |   await trigger.click();const download=page.waitForEvent('download');await menu.getByRole('button',{name:'下载当前视图 PNG',exact:true}).click();const saved=(await(await download).path())!,actual=readFileSync(saved),expectedPixels=await sharp(before).raw().toBuffer(),actualPixels=await sharp(actual).raw().toBuffer();
  119 |   expect(createHash('sha256').update(actualPixels).digest('hex')).toBe(createHash('sha256').update(expectedPixels).digest('hex'));expect((await sharp(actual).metadata()).width).toBe(1280);await expect(f.current).toHaveAttribute('data-unit-id',unit!);expect(writes).toEqual([]);
  120 |   const directory=browserEvidence('whiteboard-settings');copyFileSync(saved,join(directory,'actual-current-view.png'));writeFileSync(join(directory,'current-view-pixel-check.json'),JSON.stringify({unit,pixelsSha256:createHash('sha256').update(actualPixels).digest('hex'),metadata:await sharp(actual).metadata(),writes},null,2)+'\n');
  121 |   await page.goto(copied);await expect(f.player).toHaveAttribute('data-original-font-status','ready');await expect(f.current).toHaveAttribute('data-unit-id',unit!);
  122 | });
  123 | 
  124 | test('share toolbar: closing during original PNG authorization fences a late reply and never downloads',async({page})=>{
  125 |   const f=await fixture(page),downloads:string[]=[];page.on('download',download=>downloads.push(download.suggestedFilename()));let reached=false;
  126 |   await page.route('**/api/learning/studio/overview?*',async route=>{reached=true;const response=await route.fetch();await new Promise(resolve=>setTimeout(resolve,700));try{await route.fulfill({response});}catch{}});
  127 |   await f.player.getByRole('button',{name:'分享与导出',exact:true}).click();await page.getByRole('dialog',{name:'分享与导出',exact:true}).getByRole('button',{name:'下载当前视图 PNG',exact:true}).click();
  128 |   await expect.poll(()=>reached).toBe(true);await f.player.getByRole('button',{name:'关闭白板',exact:true}).click();await page.waitForTimeout(1000);await expect(f.player).toHaveCount(0);expect(downloads).toEqual([]);
  129 | });
  130 | 
  131 | for(const width of [390,768,1280])test('share toolbar: every visible playback and toolbar control stays inside the actual viewport at '+width,async({page})=>{
  132 |   await page.setViewportSize({width,height:800});const f=await fixture(page);
  133 |   const clipped=await f.player.evaluate((element,width)=>[...element.querySelectorAll<HTMLElement>('.sa-whiteboard-controls button,.sa-whiteboard-controls select,.hk-board-tools button')].filter(node=>node.getClientRects().length>0).map(node=>({label:node.getAttribute('aria-label')||node.textContent,rect:node.getBoundingClientRect().toJSON()})).filter(row=>row.rect.x<0||row.rect.right>width+1||row.rect.y<0||row.rect.bottom>801),width);
  134 |   expect(clipped).toEqual([]);await f.player.getByRole('button',{name:'分享与导出',exact:true}).click();const menu=page.getByRole('dialog',{name:'分享与导出',exact:true}),bounds=(await menu.boundingBox())!;expect(bounds.x).toBeGreaterThanOrEqual(0);expect(bounds.x+bounds.width).toBeLessThanOrEqual(width+1);expect(bounds.y+bounds.height).toBeLessThanOrEqual(800);
  135 |   await page.screenshot({path:join(browserEvidence('whiteboard-settings'),'share-toolbar-'+width+'.png')});await page.keyboard.press('Escape');await expect(f.player).toBeVisible();
  136 | });
  137 | 
```