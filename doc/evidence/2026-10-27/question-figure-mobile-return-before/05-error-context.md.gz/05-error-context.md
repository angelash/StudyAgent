# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-questions.spec.ts >> question figures: mobile adopted image layers contain keyboard focus and return to the actual original control at 768
- Location: tests\e2e\whiteboard-questions.spec.ts:386:37

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: '回答配图工作区', exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('region', { name: '回答配图工作区', exact: true }) with timeout 15000ms
  - waiting for getByRole('region', { name: '回答配图工作区', exact: true })

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - button "Home": 首页
      - button "Courses": 课程
      - button "Calendar": 学习动态
      - button "History": 历史
      - button "Materials": 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - button "＋ 创建课程"
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom?lesson=soc-1-1-1
    - heading "近期活动" [level=2]
    - link "白板视频「异分母分数加法」":
      - /url: /studio?whiteboard=studio_whiteboard_99864e69-ac37-414e-9c49-923df82d1812
    - link "返回学习首页 →":
      - /url: /learn?subject=math&student=student_8030ca8a-fb47-4e41-9189-43c7e3ff15b6
  - combobox "学习档案":
    - option "匿名插问验证" [selected]
  - combobox "学科":
    - option "数学" [selected]
    - option "语文"
    - option "英语"
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "把下一步，做成一条走得通的路。" [level=1]
  - paragraph: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
  - textbox "围绕哪段学习内容设计课程？"
  - text: ＋ 资料
  - button "Concept Explanation"
  - text: 语音 模型
  - combobox "选择大模型":
    - option "Auto · 当前默认模型"
  - button "↑"
  - button "可视化 用图形解释异分母加法 通分、合并与验算"
  - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围"
  - button "主动学习 看看今天最值得做什么 按教育优先级排序"
  - heading "你的学习路径" [level=2]
  - button "创建课程"
  - heading "还没有课程" [level=3]
  - paragraph: 先确认学习范围，再从已学知识生成可审核蓝图。
  - button "生成第一门课程"
  - dialog "白板视频":
    - button "关闭白板": ×
    - heading "匿名逐句白板" [level=2]
    - navigation "白板视图":
      - button "缩小白板": −
      - button "重置白板视图": 100%
      - button "放大白板": +
      - group "白板页码":
        - button "上一页白板" [disabled]: ‹
        - text: 1 / 1
        - button "下一页白板" [disabled]: ›
      - group "白板工具":
        - button "分享与导出"
        - button "白板设置"
      - button "讲稿与笔记"
    - button "静音"
    - main:
      - paragraph: "[whiteboard-fixture] 先统一单位。"
      - text: 播放进度（估计阅读）
      - slider "播放进度（估计阅读）": "0"
      - button "上一句" [disabled]: ←
      - button "播放": ▶
      - button "下一句": →
      - text: 1 / 4 句
      - combobox "阅读方式":
        - option "文字阅读（估计时长）" [selected]
      - combobox "播放速度":
        - option "0.5×"
        - option "0.75×"
        - option "1×" [selected]
        - option "1.25×"
        - option "1.5×"
        - option "2×"
      - text: 板书字体
      - combobox "板书字体":
        - option "手写板书" [selected]
        - option "标准板书"
      - checkbox "点阵" [checked]
      - text: 点阵
      - button "导出视频"
      - button "导出字幕"
      - status
      - button "01 统一单位"
      - button "02 保留证据"
```

# Test source

```ts
  296 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  297 |   await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click(); await expect(pane.getByRole('button', { name: '按原请求继续', exact: true })).toBeEnabled();
  298 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('保留原请求的完整配图要求。');
  299 |   await pane.getByRole('button', { name: '按原请求继续', exact: true }).click(); await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled(); expect(prepareWrites).toBe(1);
  300 |   let adoptionWrites = 0, first: any;
  301 |   await page.route('**/whiteboard-question-visuals/adopt', async route => { adoptionWrites++; const response = await route.fetch();
  302 |     if (adoptionWrites === 1) { first = (await response.json()).data; await route.abort('failed'); } else await route.fulfill({ response }); });
  303 |   await pane.getByLabel('图片说明', { exact: true }).fill('所有标签与条件已经核对。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  304 |   await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); await expect(pane.getByRole('button', { name: '按原请求继续', exact: true })).toBeEnabled();
  305 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await pane.getByRole('button', { name: '按原请求继续', exact: true }).click();
  306 |   await expect(page.getByRole('dialog', { name: 'AI补充讲解', exact: true })).toHaveAttribute('data-original-font-status', 'ready'); expect(adoptionWrites).toBe(2);
  307 |   const versions = await f.call('/learning/studio/whiteboards/' + f.board.id + '/questions/' + first.board.turnId + '/teaching-versions', undefined, f.actor.token, 'GET');
  308 |   expect(versions).toHaveLength(2); expect(versions.find((item: any) => item.current).id).toBe(first.versionId);
  309 | });
  310 | 
  311 | test('question figures: original PNG editing and two explicit adoptions preserve both prior teaching versions', async ({ page }) => {
  312 |   const f = await fixture(page, false, true), pane = await questionFigure(page, f); const versions: string[] = [];
  313 |   for (let pass = 0; pass < 2; pass++) {
  314 |     if (pass) { await pane.getByRole('button', { name: '以这张原图继续修改', exact: true }).click(); await pane.getByLabel('具体修改说明', { exact: true }).fill('把交集标签加大，并保留两个原始圆圈。');
  315 |       await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '用原PNG生成修改图', exact: true })).toBeEnabled();
  316 |       await pane.getByRole('button', { name: '用原PNG生成修改图', exact: true }).click(); await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled(); }
  317 |     await pane.getByLabel('图片说明', { exact: true }).fill('第' + pass + '幅已核对的关系图。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  318 |     const responsePromise = page.waitForResponse(response => response.request().method() === 'POST' && response.url().endsWith(questionFigureBase + '/adopt'));
  319 |     await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); const value = (await (await responsePromise).json()).data; versions.push(value.versionId);
  320 |     const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  321 |     await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click();
  322 |   }
  323 |   expect(versions[0]).not.toBe(versions[1]); await expect(f.region.getByRole('combobox', { name: '讲解版本', exact: true }).locator('option')).toHaveCount(3);
  324 |   await f.region.getByRole('combobox', { name: '讲解版本', exact: true }).selectOption(versions[0]); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  325 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  326 |   await lesson.getByRole('button', { name: '分享与导出', exact: true }).click(); expect(await lesson.getByLabel('原白板私有链接').inputValue()).toContain('teachingVersion=' + versions[0]);
  327 | });
  328 | 
  329 | test('question figures: explicit cancel and original retry keep the same image requirement and target', async ({ page }) => {
  330 |   const f = await fixture(page), pane = await questionFigure(page, f, '[image-pause-once] 完整条件与原图要求在重试后仍然保持。', false), commands: any[] = [];
  331 |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith(questionFigureBase)) commands.push(request.postDataJSON()); });
  332 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  333 |   await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click(); await pane.getByRole('button', { name: '取消图片生成', exact: true }).click();
  334 |   await expect(pane.getByRole('button', { name: '按原要求重试图片', exact: true })).toBeEnabled({ timeout: 20000 }); await pane.getByRole('button', { name: '按原要求重试图片', exact: true }).click();
  335 |   await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled({ timeout: 25000 }); expect(commands).toHaveLength(1);
  336 |   await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(commands[0].requirements);
  337 | });
  338 | 
  339 | test('question figures: duplicated documents keep separate full inputs and a closed workbench discards late preflight', async ({ page, context }) => {
  340 |   const f = await fixture(page), pane = await questionFigure(page, f, '第一标签的完整条件 A 尾部。', false), second = await context.newPage(); await second.goto(f.href);
  341 |   await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); const other = second.getByRole('region', { name: '回答配图工作区', exact: true });
  342 |   await other.getByRole('textbox', { name: '完整配图要求', exact: true }).fill('第二标签的完整条件 B 尾部。');
  343 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第一标签的完整条件 A 尾部。');
  344 |   await second.reload(); await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(other.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第二标签的完整条件 B 尾部。'); await second.close();
  345 |   let reached = false, delivered = false, release!: () => void; const gate = new Promise<void>(resolve => { release = resolve; });
  346 |   await page.route('**/whiteboard-question-visuals/preflight', async route => { const response = await route.fetch(); reached = true; await gate; try { await route.fulfill({ response }); } catch {} finally { delivered = true; } });
  347 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect.poll(() => reached).toBe(true); await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click();
  348 |   release(); await expect.poll(() => delivered).toBe(true); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeDisabled();
  349 | });
  350 | 
  351 | for (const width of [390, 768, 1280]) test('question figures: full input, storage failure, download and import remain usable at ' + width, async ({ page }) => {
  352 |   await page.setViewportSize({ width, height: 800 }); await page.addInitScript(() => { const set = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) {
  353 |     if (key.startsWith('studyagent.question-figures.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this, key, value); }; });
  354 |   const f = await fixture(page), requirements = '完整首部。' + '图示保留全部条件。'.repeat(100) + '完整尾部。', pane = await questionFigure(page, f, requirements, false);
  355 |   await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click(); await expect(pane).toBeVisible(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(requirements);
  356 |   for (const control of [pane.getByRole('textbox', { name: '完整配图要求', exact: true }), pane.getByRole('button', { name: '预检完整配图提示', exact: true })]) {
  357 |     const box = await control.boundingBox(); expect(box).not.toBeNull(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  358 |   }
  359 |   const promise = page.waitForEvent('download'); await pane.getByRole('button', { name: '下载完整配图副本', exact: true }).click(); const bytes = readFileSync((await (await promise).path())!);
  360 |   expect(JSON.parse(bytes.toString('utf8')).form.requirements).toBe(requirements); await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click(); await expect(pane).toHaveCount(0);
  361 |   await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await pane.getByText('保留与恢复完整配图要求', { exact: true }).click();
  362 |   await pane.getByLabel('导入完整配图副本', { exact: true }).setInputFiles({ name: 'complete-figure-copy.json', mimeType: 'application/json', buffer: bytes });
  363 |   await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(requirements);
  364 |   await page.screenshot({ path: join(browserEvidence('whiteboard-question-figures'), 'full-input-' + width + '.png') });
  365 | });
  366 | 
  367 | test('question figures: a stale second tab preserves its full requirements and rechecks the current adoption before choosing again', async ({ page, context }) => {
  368 |   const f = await fixture(page), pane = await questionFigure(page, f), second = await context.newPage(); await second.goto(f.href);
  369 |   await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click();
  370 |   const other = second.getByRole('region', { name: '回答配图工作区', exact: true });
  371 |   await other.getByRole('textbox', { name: '完整配图要求', exact: true }).fill('第二标签保留的完整选择理由与条件尾部。');
  372 |   await other.getByLabel('这段讲解的图片候选', { exact: true }).getByRole('button').first().click();
  373 |   await expect(other.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled();
  374 |   for (const target of [pane, other]) { await target.getByLabel('图片说明', { exact: true }).fill('已核对相同原PNG与全部标签。'); await target.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check(); }
  375 |   const responsePromise = page.waitForResponse(response => response.request().method() === 'POST' && response.url().endsWith(questionFigureBase + '/adopt'));
  376 |   await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); const first = (await (await responsePromise).json()).data;
  377 |   await other.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click();
  378 |   await expect(other).toContainText('当前采用版本已变化'); await expect(other.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第二标签保留的完整选择理由与条件尾部。');
  379 |   await expect(other.getByRole('button', { name: '重新读取原回答范围', exact: true })).toBeVisible();
  380 |   const versions = await f.call('/learning/studio/whiteboards/' + f.board.id + '/questions/' + first.board.turnId + '/teaching-versions', undefined, f.actor.token, 'GET');
  381 |   expect(versions).toHaveLength(2); expect(versions.find((item: any) => item.current).id).toBe(first.versionId);
  382 |   await other.getByRole('button', { name: '重新读取原回答范围', exact: true }).click(); await expect(other).toContainText('当前采用图片：');
  383 |   await expect(other.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true })).not.toBeChecked(); await second.close();
  384 | });
  385 | 
  386 | for (const width of [390, 768]) test('question figures: mobile adopted image layers contain keyboard focus and return to the actual original control at ' + width, async ({ page }) => {
  387 |   await page.setViewportSize({ width, height: 800 }); const f = await fixture(page), pane = await questionFigure(page, f);
  388 |   const open = pane.getByRole('button', { name: '放大参考图：回答配图', exact: true }); await open.click();
  389 |   const reader = page.getByRole('dialog', { name: '回答配图', exact: true }); await expect(reader).toBeVisible();
  390 |   await reader.getByRole('button', { name: '关闭图片', exact: true }).click(); await expect(open).toBeFocused();
  391 |   await pane.getByLabel('图片说明', { exact: true }).fill('窄屏核对过的完整标签与关系。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  392 |   const adopt = pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }); await adopt.click();
  393 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  394 |   await lesson.getByRole('button', { name: '关闭白板', exact: true }).focus(); await page.keyboard.press('Tab');
  395 |   expect(await lesson.evaluate(element => element.contains(document.activeElement))).toBe(true);
> 396 |   await page.keyboard.press('Escape'); await expect(lesson).toHaveCount(0); await expect(pane).toBeVisible(); await expect(adopt).toBeFocused();
      |                                                                                                ^ Error: expect(locator).toBeVisible() failed
  397 |   await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).not.toHaveValue('');
  398 | });
  399 | 
```