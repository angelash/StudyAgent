const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{spawn,execFileSync}=require('node:child_process'),{createHash}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),expected='16cea683e50d1f28e899aa2237fe5fa72de51733',receiptPath=path.join(__dirname,'model-check-ui-run-16cea68.json');
assert(!fs.existsSync(receiptPath));const sha=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const receipt={at:new Date().toISOString(),head:expected,status:'starting',passed:false,scope:'60 original synthetic UI attempts at3177/4177; current/historical/failed/unknown check labels and explicit directory recovery. No live text supplier in browser fixtures.'};
const env={...process.env,E2E_API_PORT:'4177',E2E_WEB_PORT:'3177',CI:'',NEXT_TELEMETRY_DISABLED:'1',XIAOJIU_MODEL_QUALIFICATION:path.join(__dirname,'model-check-ui-no-published-file.json')};
const save=()=>fs.writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n');
async function run(phase,args,log){receipt.phase=phase;receipt.phaseStartedAt=new Date().toISOString();save();const fd=fs.openSync(path.join(__dirname,log),'wx');
 try{return await new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{cwd:root,env,windowsHide:true,stdio:['ignore',fd,fd]});receipt.childPid=child.pid;save();child.once('error',reject);child.once('exit',code=>resolve(code??1));});}finally{fs.closeSync(fd);}}
(async()=>{
 assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),expected);
 assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');save();
 assert.equal(await run('build',['scripts/qa/experience-web.cjs','build'],'model-check-ui-web-16cea68.log'),0);
 const names=execFileSync('git',['ls-files','apps','packages','scripts','tests'],{cwd:root,encoding:'utf8'}).trim().split(/\r?\n/);
 const inputs=Object.fromEntries(names.filter(file=>fs.existsSync(path.join(root,file))).map(file=>[file,sha(path.join(root,file))]));
 fs.writeFileSync(path.join(__dirname,'model-check-ui-source-16cea68.json'),JSON.stringify({head:expected,sourceSha256:inputs},null,2)+'\n',{flag:'wx'});
 assert.equal(await run('browser',['scripts/qa/run-source-course-browser.cjs','--assistant','--whiteboard-questions','--teaching-settings','--skip-build','--result-file','data/qa/model-check-browser-first.json'],'model-check-ui-browser-16cea68.log'),0);
 for(const[file,digest]of Object.entries(inputs))assert.equal(sha(path.join(root,file)),digest,file);
 const report=JSON.parse(fs.readFileSync(path.join(__dirname,'model-check-browser-first.json'),'utf8')),cases=[];
 const walk=s=>{for(const spec of s.specs||[])cases.push(...spec.tests);for(const child of s.suites||[])walk(child);};report.suites.forEach(walk);
 assert.deepEqual([report.stats.expected,report.stats.unexpected,report.stats.flaky,report.stats.skipped,report.errors.length,cases.length],[60,0,0,0,0,60]);
 assert(cases.every(test=>test.results.length===1&&test.results[0].status==='passed'));
 Object.assign(receipt,{status:'complete',passed:true,stats:report.stats,originalAttempts:60,reportSha256:sha(path.join(__dirname,'model-check-browser-first.json')),completedAt:new Date().toISOString()});
})().catch(error=>{Object.assign(receipt,{status:'failed',passed:false,error:error.message,completedAt:new Date().toISOString()});process.exitCode=1;}).finally(save);
