# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-questions.spec.ts >> question figures: exact PNG adoption binds voice, video, private links, complete notes and original-version review
- Location: tests\e2e\whiteboard-questions.spec.ts:254:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '关闭图片', exact: true })
    - locator resolved to <button aria-label="关闭图片" class="cl-figure-reader-close">×</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <aside id="_r_0_-content" aria-label="完整讲稿与要点" data-classroom-tour="history" class="wb-reading-notes whiteboard-chat-inner">…</aside> from <main data-view="home" class="sa-app ws-app">…</main> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <aside id="_r_0_-content" aria-label="完整讲稿与要点" data-classroom-tour="history" class="wb-reading-notes whiteboard-chat-inner">…</aside> from <main data-view="home" class="sa-app ws-app">…</main> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    28 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <aside id="_r_0_-content" aria-label="完整讲稿与要点" data-classroom-tour="history" class="wb-reading-notes whiteboard-chat-inner">…</aside> from <main data-view="home" class="sa-app ws-app">…</main> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - button "Home" [ref=f1e10] [cursor=pointer]:
          - generic [ref=f1e13]: 首页
        - button "Courses" [ref=f1e14] [cursor=pointer]:
          - generic [ref=f1e17]: 课程
        - button "Calendar" [ref=f1e18] [cursor=pointer]:
          - generic [ref=f1e21]: 学习动态
        - button "History" [ref=f1e22] [cursor=pointer]:
          - generic [ref=f1e25]: 历史
        - button "Materials" [ref=f1e26] [cursor=pointer]:
          - generic [ref=f1e29]: 资料
        - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f1e33]: AI白板
      - button "＋ 创建课程" [ref=f1e34] [cursor=pointer]
      - generic [ref=f1e35]:
        - heading "继续学习" [level=2] [ref=f1e36]
        - link "讲座社会学想象力 社会学概论" [ref=f1e37] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f1e38]: 社会学概论
      - generic [ref=f1e39]:
        - heading "近期活动" [level=2] [ref=f1e40]
        - link "白板视频「异分母分数加法」" [ref=f1e41] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_800a549d-69c2-496d-a55b-358246d3a7c7
      - link "返回学习首页 →" [ref=f1e43] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_f2878355-db0d-4bc2-b8d6-dd5967521cd5
    - generic [ref=f1e44]:
      - generic [ref=f1e45]:
        - generic [ref=f1e46]:
          - combobox "学习档案" [ref=f1e47]:
            - option "匿名插问验证" [selected]
          - combobox "学科" [ref=f1e48]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e49]:
          - link "教学课堂 ↗" [ref=f1e50] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e51] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e52]:
        - generic [ref=f1e53]:
          - button "Craft Courses" [ref=f1e54] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e55] [cursor=pointer]
        - generic [ref=f1e56]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f1e57]
          - paragraph [ref=f1e58]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f1e59]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f1e60]
          - generic [ref=f1e61]:
            - generic [ref=f1e62]: ＋
            - generic [ref=f1e63]: 资料
            - button "Concept Explanation" [ref=f1e64] [cursor=pointer]
            - generic [ref=f1e65]: 语音
            - generic [ref=f1e68]:
              - generic [ref=f1e69]: 模型
              - combobox "选择大模型" [ref=f1e70] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f1e71] [cursor=pointer]
        - generic [ref=f1e72]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f1e73] [cursor=pointer]:
            - generic [ref=f1e74]: 可视化
            - generic [ref=f1e75]: 用图形解释异分母加法
            - generic [ref=f1e76]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f1e77] [cursor=pointer]:
            - generic [ref=f1e78]: 个性化练习
            - generic [ref=f1e79]: 从我的已知点生成练习
            - generic [ref=f1e80]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f1e81] [cursor=pointer]:
            - generic [ref=f1e82]: 主动学习
            - generic [ref=f1e83]: 看看今天最值得做什么
            - generic [ref=f1e84]: 按教育优先级排序
        - generic [ref=f1e85]:
          - heading "你的学习路径" [level=2] [ref=f1e86]
          - button "创建课程" [ref=f1e87] [cursor=pointer]
        - generic [ref=f1e88]:
          - heading "还没有课程" [level=3] [ref=f1e89]
          - paragraph [ref=f1e90]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f1e91] [cursor=pointer]
        - complementary [ref=f1e92]:
          - article [ref=f1e93]:
            - generic [ref=f1e94]:
              - generic [ref=f1e95]:
                - text: LEARNER SNAPSHOT
                - heading "匿名插问验证" [level=2] [ref=f1e96]
              - generic [ref=f1e97]: 5 年级
            - generic [ref=f1e98]:
              - strong [ref=f1e99]: "0"
              - generic [ref=f1e100]: / 1
              - generic [ref=f1e101]: 已有点有稳定证据
            - generic [ref=f1e102]:
              - generic [ref=f1e103]:
                - generic [ref=f1e104]: "1"
                - text: 已确认知识点
              - generic [ref=f1e105]:
                - generic [ref=f1e106]: "0"
                - text: 日历安排
          - article [ref=f1e107]:
            - generic [ref=f1e108]:
              - generic [ref=f1e109]: NEXT BEST ACTION
              - button "全部 →" [ref=f1e110] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f1e111] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_f2878355-db0d-4bc2-b8d6-dd5967521cd5&subject=math
              - generic [ref=f1e112]: 1个已学点仍需补充证据
              - paragraph [ref=f1e113]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f1e114]:
            - generic [ref=f1e115]:
              - generic [ref=f1e116]: RECENT WHITEBOARDS
              - button "新建" [ref=f1e117] [cursor=pointer]
            - button "▶ 匿名逐句白板 2 幕 · 1 秒" [ref=f1e118] [cursor=pointer]:
              - generic [ref=f1e119]: ▶
              - generic [ref=f1e120]:
                - generic [ref=f1e121]: 匿名逐句白板
                - generic [ref=f1e122]: 2 幕 · 1 秒
          - article [ref=f1e123]:
            - generic [ref=f1e124]:
              - generic [ref=f1e125]: SYNC STATUS
              - button "日历 →" [ref=f1e126] [cursor=pointer]
            - paragraph [ref=f1e127]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f1e128]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f1e129]:
      - generic:
        - button "关闭白板" [ref=f1e130] [cursor=pointer]: ×
        - heading "匿名逐句白板" [level=2] [ref=f1e132]
      - navigation "白板视图" [ref=f1e133]:
        - generic [ref=f1e134]:
          - button "缩小白板" [ref=f1e135] [cursor=pointer]: −
          - button "重置白板视图" [ref=f1e136] [cursor=pointer]: 100%
          - button "放大白板" [ref=f1e137] [cursor=pointer]: +
        - group "白板页码" [ref=f1e138]:
          - button "上一页白板" [disabled] [ref=f1e139]: ‹
          - generic [ref=f1e140]:
            - generic [ref=f1e141]: "1"
            - generic [ref=f1e142]: /
            - generic [ref=f1e143]: "1"
          - button "下一页白板" [disabled] [ref=f1e144]: ›
        - group "白板工具" [ref=f1e145]:
          - button "分享与导出" [ref=f1e147] [cursor=pointer]
          - button "白板设置" [ref=f1e150] [cursor=pointer]
        - button "收起讲稿与笔记" [expanded] [ref=f1e153] [cursor=pointer]
      - button "静音" [ref=f1e155] [cursor=pointer]
      - generic [ref=f1e158]:
        - main [ref=f1e159]:
          - generic "统一单位" [ref=f1e161]
          - paragraph [ref=f1e162]: "[whiteboard-fixture] 先统一单位。"
          - generic [ref=f1e163]:
            - generic [ref=f1e164]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f1e165] [cursor=pointer]: "0"
          - generic [ref=f1e166]:
            - button "上一句" [disabled] [ref=f1e167]: ←
            - button "播放" [ref=f1e168] [cursor=pointer]: ▶
            - button "下一句" [ref=f1e169] [cursor=pointer]: →
            - generic [ref=f1e170]: 1 / 4 句
            - combobox "阅读方式" [ref=f1e171] [cursor=pointer]:
              - option "文字阅读（估计时长）"
              - option "云语音逐句播放" [selected]
            - combobox "旁白音色" [ref=f1e172] [cursor=pointer]:
              - option "合成音色A" [selected]
              - option "合成音色B"
            - combobox "播放速度" [ref=f1e173] [cursor=pointer]:
              - option "0.5×"
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
              - option "1.5×"
              - option "2×"
            - generic [ref=f1e174]:
              - generic [ref=f1e175]: 板书字体
              - combobox "板书字体" [ref=f1e176] [cursor=pointer]:
                - option "手写板书" [selected]
                - option "标准板书"
            - generic [ref=f1e177]:
              - checkbox "点阵" [checked] [ref=f1e178]
              - text: 点阵
            - button "导出视频" [ref=f1e179] [cursor=pointer]
            - button "导出字幕" [ref=f1e180] [cursor=pointer]
          - status [ref=f1e181]
          - generic [ref=f1e182]:
            - button "01 统一单位" [ref=f1e183] [cursor=pointer]:
              - generic [ref=f1e184]: "01"
              - text: 统一单位
            - button "02 保留证据" [ref=f1e185] [cursor=pointer]:
              - generic [ref=f1e186]: "02"
              - text: 保留证据
        - generic [ref=f1e189]:
          - separator "调整讲稿面板宽度" [ref=f1e190]
          - complementary "完整讲稿与要点" [ref=f1e192]:
            - button "收起讲稿与笔记" [ref=f1e193] [cursor=pointer]
            - region "原句提问" [ref=f1e196]:
              - generic [ref=f1e197]:
                - heading "一起想清楚" [level=3] [ref=f1e198]
                - generic [ref=f1e199]: AI补充讲解
              - group [ref=f1e200]:
                - generic "带走完整教学笔记" [ref=f1e201] [cursor=pointer]
              - article [ref=f1e203]:
                - paragraph [ref=f1e204]: "[question-structure] 请将完整条件、表格和公式讲清楚。"
                - generic [ref=f1e205]:
                  - generic [ref=f1e206]: AI补充讲解
                  - generic [ref=f1e207]: Browser question fixture · deepseek-v4-flash
                - paragraph [ref=f1e208]: 先确认计数单位。第一行比较单位。第二行核对整体。现在解释分数公式。最后解释根式公式。
                - generic [ref=f1e209]: "[whiteboard-fixture] 先统一单位。"
                - button "查看补充板书与声音" [ref=f1e211] [cursor=pointer]
                - button "为这段讲解配图" [ref=f1e212] [cursor=pointer]
                - region "回答配图工作区" [ref=f1e213]:
                  - generic [ref=f1e214]:
                    - generic [ref=f1e215]:
                      - text: 这段讲解的配图
                      - heading "把关系画清楚" [level=4] [ref=f1e216]
                    - button "关闭回答配图" [ref=f1e217] [cursor=pointer]: ×
                  - paragraph [ref=f1e218]: 生成后先核对，再选用。原回答与之前的图片版本会一直保留。
                  - generic [ref=f1e219]:
                    - text: 图片用途
                    - combobox "图片用途" [ref=f1e220]:
                      - option "说明概念关系" [selected]
                      - option "对比条件与差异"
                      - option "展示具体情境"
                  - generic [ref=f1e221]:
                    - text: 完整配图要求
                    - textbox "完整配图要求" [ref=f1e222]:
                      - /placeholder: 想看清哪些概念、标签、条件和关系？
                      - text: 用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。
                  - generic [ref=f1e223]:
                    - button "预检完整配图提示" [ref=f1e224] [cursor=pointer]
                    - button "生成这段讲解的配图" [ref=f1e225] [cursor=pointer]
                  - generic [ref=f1e226]:
                    - paragraph [ref=f1e227]: Browser image fixture, not a real provider · gpt-image-2
                    - group [ref=f1e228]:
                      - generic "查看完整模型提示与教学上下文" [ref=f1e229] [cursor=pointer]
                  - generic "这段讲解的图片候选" [ref=f1e230]:
                    - button "待核对的回答配图 图片已就绪 用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。" [pressed] [ref=f1e231] [cursor=pointer]:
                      - img "待核对的回答配图" [ref=f1e233]
                      - generic [ref=f1e234]: 图片已就绪
                      - generic [ref=f1e235]: 用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。
                  - region "所选回答图片" [ref=f1e236]:
                    - paragraph [ref=f1e237]: 图片已就绪 · gpt-image-2
                    - paragraph [ref=f1e238]: 用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。
                    - figure "用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。" [ref=f1e239]:
                      - button "放大参考图：回答配图" [ref=f1e240]:
                        - img "待核对的回答配图" [ref=f1e241]
                        - generic [aria-hidden] [ref=f1e242]: ↗
                    - generic [ref=f1e244]:
                      - button "下载实际原PNG" [ref=f1e245] [cursor=pointer]
                      - button "以这张原图继续修改" [ref=f1e246] [cursor=pointer]
                    - generic [ref=f1e247]:
                      - text: 图片说明
                      - textbox "图片说明" [ref=f1e248]
                    - generic [ref=f1e249]:
                      - text: 展示图注
                      - textbox "展示图注" [ref=f1e250]
                    - generic [ref=f1e251]:
                      - checkbox "我已核对图中文字、条件和关系" [ref=f1e252]
                      - text: 我已核对图中文字、条件和关系
                    - button "采用并打开这个讲解版本" [disabled] [ref=f1e253]
                  - status [ref=f1e254]: 原操作已确认。图片就绪后请核对标签、条件和关系。
                  - group [ref=f1e255]:
                    - generic "保留与恢复完整配图要求" [ref=f1e256] [cursor=pointer]
                - button "回到这句 [whiteboard-fixture] 先统一单位。" [ref=f1e257] [cursor=pointer]:
                  - text: 回到这句
                  - generic [ref=f1e258]: "[whiteboard-fixture] 先统一单位。"
              - generic [ref=f1e259]:
                - generic [ref=f1e260]: 向老师提问
                - textbox "向老师提问" [ref=f1e261]:
                  - /placeholder: 对这句有疑问？
                - generic [ref=f1e262]:
                  - combobox "讲解方式" [ref=f1e263]:
                    - option "问一个问题" [selected]
                    - option "换个例子"
                    - option "讲简单些"
                    - option "补补基础"
                    - option "对比理解"
                  - combobox "选择大模型" [ref=f1e266] [cursor=pointer]:
                    - option "Auto · 当前默认模型"
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认" [selected]
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                  - button "发送" [disabled] [ref=f1e267]
                - group [ref=f1e268]:
                  - generic "保留与恢复提问" [ref=f1e269] [cursor=pointer]
            - heading "逐句讲稿" [level=3] [ref=f1e270]
            - paragraph [ref=f1e271]: 点击一句定位。观看与续播不计作掌握。
            - list [ref=f1e272]:
              - listitem [ref=f1e273]:
                - button "[whiteboard-fixture] 先统一单位。" [ref=f1e274] [cursor=pointer]
              - listitem [ref=f1e275]:
                - button "[whiteboard-fixture] 再合并份数。" [ref=f1e276] [cursor=pointer]
              - listitem [ref=f1e277]:
                - button "[whiteboard-fixture] 最后验证。" [ref=f1e278] [cursor=pointer]
              - listitem [ref=f1e279]:
                - button "[whiteboard-fixture] 保留新的独立观察。" [ref=f1e280] [cursor=pointer]
            - heading "完整笔记与来源" [level=3] [ref=f1e281]
            - group [ref=f1e282]:
              - generic "统一单位" [ref=f1e283] [cursor=pointer]
              - paragraph [ref=f1e284]: 完整正文首行。完整正文末行。
              - list [ref=f1e285]:
                - listitem [ref=f1e286]: 先统一单位
                - listitem [ref=f1e287]: 再合并份数
                - listitem [ref=f1e288]: 最后验证
            - group [ref=f1e289]:
              - generic "保留证据" [ref=f1e290] [cursor=pointer]
            - button "下载续播位置" [ref=f1e291] [cursor=pointer]
  - dialog [ref=f1e294]:
    - button "关闭图片" [active] [ref=f1e295] [cursor=pointer]: ×
    - heading "回答配图" [level=2] [ref=f1e296]
    - generic [ref=f1e297]:
      - img "待核对的回答配图" [ref=f1e298]
      - paragraph [ref=f1e299]: 用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。
```

# Test source

```ts
  161 | 
  162 | test('whiteboard questions: five intentions produce distinct original commands and retain completed history', async ({ page }) => {
  163 |   const f = await fixture(page), intentions = ['question','example','simplify','prerequisite','compare'], commands: any[] = [];
  164 |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/questions')) commands.push(request.postDataJSON()); });
  165 |   for (const [index, intent] of intentions.entries()) {
  166 |     await f.region.getByRole('combobox', { name: '讲解方式', exact: true }).selectOption(intent); await f.inputBox.fill('匿名讲解方式验证 ' + intent);
  167 |     await f.region.getByRole('button', { name: '发送', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(index + 1);
  168 |   }
  169 |   expect(commands.map(command => command.intent)).toEqual(intentions); expect(new Set(commands.map(command => command.requestKey)).size).toBe(5);
  170 |   await page.reload(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(5); await expect(f.inputBox).toHaveValue('');
  171 | });
  172 | 
  173 | test('whiteboard questions: a failed answer has an explicit original-model retry and preserves the next unsent question', async ({ page }) => {
  174 |   const f = await fixture(page); await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('deepseek-v4-flash');
  175 |   await f.inputBox.fill('[question-fail-once] 请解释相同单位。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  176 |   await expect(f.region.getByRole('button', { name: '用原模型重试', exact: true })).toBeVisible();
  177 |   await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6-astra'); await f.inputBox.fill('这是下一条未发送的完整问题，保留尾部。');
  178 |   await f.region.getByRole('button', { name: '用原模型重试', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  179 |   await expect(f.region.locator('.wb-question-meta')).toContainText('deepseek-v4-flash'); await expect(f.inputBox).toHaveValue('这是下一条未发送的完整问题，保留尾部。');
  180 | });
  181 | 
  182 | test('whiteboard questions: cancelling running work blocks the late answer and the same original can be retried', async ({ page }) => {
  183 |   const f = await fixture(page); await f.inputBox.fill('[question-pause-once] 保留当前原句。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  184 |   await expect(f.region.locator('.wb-question-meta')).toContainText('正在思考'); await f.region.getByRole('button', { name: '取消回答', exact: true }).click();
  185 |   await expect(f.region.locator('.wb-question-meta')).toContainText('已取消'); await expect(f.region.locator('.wb-question-answer')).toHaveCount(0);
  186 |   await f.region.getByRole('button', { name: '用原模型重试', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  187 | });
  188 | 
  189 | test('whiteboard questions: a lost create response is recovered after reload without a second write', async ({ page }) => {
  190 |   const f = await fixture(page), commands: any[] = [];
  191 |   await page.route('**/api/learning/studio/whiteboards/*/questions', async route => {
  192 |     if (route.request().method() !== 'POST') { await route.continue(); return; }
  193 |     commands.push(route.request().postDataJSON()); const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed');
  194 |   });
  195 |   await f.inputBox.fill('原创建回执丢失仍保留全部内容。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  196 |   await expect.poll(() => commands.length).toBe(1); await page.reload();
  197 |   await expect(f.region.locator('.wb-question-user')).toContainText('原创建回执丢失仍保留全部内容。');
  198 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1); expect(commands).toHaveLength(1); await expect(f.inputBox).toHaveValue('');
  199 | });
  200 | 
  201 | test('whiteboard questions: unavailable local storage keeps the full input, protects closing and round trips the downloaded JSON', async ({ page }) => {
  202 |   await page.addInitScript(() => {
  203 |     const get = Storage.prototype.getItem, set = Storage.prototype.setItem;
  204 |     Storage.prototype.getItem = function(key) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'SecurityError'); return get.call(this,key); };
  205 |     Storage.prototype.setItem = function(key,value) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this,key,value); };
  206 |   });
  207 |   const f = await fixture(page), message = '完整输入首部。' + '条件与理由。'.repeat(180) + '完整输入尾部。';
  208 |   await f.inputBox.fill(message); await expect(f.region).toContainText('本机副本暂未保存'); await f.player.getByRole('button', { name: '关闭白板', exact: true }).click();
  209 |   await expect(f.player).toBeVisible(); await expect(f.inputBox).toHaveValue(message);
  210 |   const downloadPromise = page.waitForEvent('download'); await f.region.getByRole('button', { name: '下载完整提问副本', exact: true }).click(); const download = await downloadPromise;
  211 |   const bytes = readFileSync((await download.path())!); expect(JSON.parse(bytes.toString('utf8')).form.message).toBe(message);
  212 |   await f.player.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(f.player).toHaveCount(0);
  213 |   await page.goto(f.href); await expect(f.player).toHaveAttribute('data-original-font-status','ready'); await expect(f.inputBox).toBeEnabled();
  214 |   await f.region.getByLabel('导入完整提问副本', { exact: true }).setInputFiles({ name: 'original-question.json', mimeType: 'application/json', buffer: bytes });
  215 |   await expect(f.inputBox).toHaveValue(message);
  216 | });
  217 | 
  218 | test('whiteboard questions: duplicated documents keep separate full drafts across independent reloads', async ({ page, context }) => {
  219 |   const f = await fixture(page), second = await context.newPage(); await second.goto(f.href);
  220 |   const other = second.getByRole('region', { name: '原句提问', exact: true }).getByRole('textbox', { name: '向老师提问', exact: true }); await expect(other).toBeEnabled();
  221 |   await f.inputBox.fill('第一标签页的完整问题 A 尾部。'); await other.fill('第二标签页的完整问题 B 尾部。');
  222 |   await page.reload(); await expect(f.inputBox).toHaveValue('第一标签页的完整问题 A 尾部。');
  223 |   await second.reload(); await expect(other).toHaveValue('第二标签页的完整问题 B 尾部。'); await second.close();
  224 | });
  225 | 
  226 | for (const width of [390,768,1280]) test('whiteboard questions: the real composer, model selection and return controls remain usable at ' + width, async ({ page }) => {
  227 |   await page.setViewportSize({ width, height: 800 }); const f = await fixture(page);
  228 |   await f.inputBox.fill('窄屏完整提问，回答后返回原句。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  229 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  230 |   for (const control of [f.inputBox, f.region.getByRole('combobox', { name: '讲解方式', exact: true }), f.region.getByRole('combobox', { name: '选择大模型', exact: true }),
  231 |     f.region.getByRole('button', { name: '发送', exact: true })]) {
  232 |     const box = await control.boundingBox(); expect(box).not.toBeNull(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  233 |   }
  234 |   await page.screenshot({ path: join(browserEvidence('whiteboard-questions'), 'question-panel-' + width + '.png') });
  235 |   await f.region.getByRole('button', { name: /回到这句/ }).click(); await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  236 | });
  237 | 
  238 | const questionFigureBase = '/learning/studio/whiteboard-question-visuals';
  239 | async function questionFigure(page: Page, f: Awaited<ReturnType<typeof fixture>>, requirements = '用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。', generate = true) {
  240 |   await f.inputBox.fill('[question-structure] 请将完整条件、表格和公式讲清楚。');
  241 |   await f.region.getByRole('button', { name: '发送', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  242 |   await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click();
  243 |   const pane = page.getByRole('region', { name: '回答配图工作区', exact: true });
  244 |   await pane.getByRole('textbox', { name: '完整配图要求', exact: true }).fill(requirements);
  245 |   if (generate) {
  246 |     await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click();
  247 |     await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  248 |     await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click();
  249 |     await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled({ timeout: 25000 });
  250 |   }
  251 |   return pane;
  252 | }
  253 | 
  254 | test('question figures: exact PNG adoption binds voice, video, private links, complete notes and original-version review', async ({ page }) => {
  255 |   const f = await fixture(page, true), pane = await questionFigure(page, f), commands: any[] = [], audio: any[] = [];
  256 |   page.on('request', request => { if (request.method() !== 'POST') return;
  257 |     if (request.url().endsWith(questionFigureBase + '/adopt')) commands.push(request.postDataJSON());
  258 |     if (request.url().includes('/questions/') && request.url().includes('/board/narration/')) audio.push(request.postDataJSON()); });
  259 |   const selected = pane.getByRole('region', { name: '所选回答图片', exact: true });
  260 |   await selected.getByRole('button', { name: '放大参考图：回答配图', exact: true }).click(); await expect(page.getByRole('dialog', { name: '回答配图', exact: true })).toBeVisible();
> 261 |   await page.getByRole('button', { name: '关闭图片', exact: true }).click();
      |                                                                 ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  262 |   const originalPromise = page.waitForEvent('download'); await pane.getByRole('button', { name: '下载实际原PNG', exact: true }).click();
  263 |   const original = readFileSync((await (await originalPromise).path())!); expect(original.subarray(0, 8)).toEqual(Buffer.from([137,80,78,71,13,10,26,10]));
  264 |   await selected.getByLabel('图片说明', { exact: true }).fill('单位与完整条件的交集，图中关系已经逐项核对。'); await selected.getByLabel('展示图注', { exact: true }).fill('先统一单位，再比较条件。');
  265 |   await expect(selected.getByRole('button', { name: '采用并打开这个讲解版本', exact: true })).toBeDisabled();
  266 |   await selected.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  267 |   await selected.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click();
  268 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  269 |   expect(commands).toHaveLength(1); expect(commands[0].originalSha256).toBe(createHash('sha256').update(original).digest('hex'));
  270 |   await lesson.getByRole('button', { name: '分享与导出', exact: true }).click(); const link = await lesson.getByLabel('原白板私有链接', { exact: true }).inputValue();
  271 |   const versionId = new URL(link).searchParams.get('teachingVersion'); expect(versionId).toMatch(/^[a-f0-9-]{36}$/); await page.keyboard.press('Escape');
  272 |   await lesson.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => audio.length).toBeGreaterThan(0); expect(audio[0].teachingVersionId).toBe(versionId);
  273 |   await lesson.getByRole('button', { name: '暂停', exact: true }).click();
  274 |   await lesson.getByRole('combobox', { name: '播放速度', exact: true }).selectOption('2');
  275 |   const videoPromise = page.waitForEvent('download'); await lesson.getByRole('button', { name: '导出视频', exact: true }).click();
  276 |   const videoPath = (await (await videoPromise).path())!, probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v','error','-show_format','-show_streams','-of','json',videoPath], { encoding: 'utf8', windowsHide: true }));
  277 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true); expect(audio.every(item => item.teachingVersionId === versionId)).toBe(true);
  278 |   copyFileSync(videoPath, join(browserEvidence('whiteboard-question-figures'), 'adopted-2x.webm'));
  279 |   await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click(); await expect(lesson).toHaveCount(0);
  280 |   await f.region.getByText('带走完整教学笔记', { exact: true }).click(); const jsonPromise = page.waitForEvent('download');
  281 |   await f.region.getByRole('button', { name: '下载完整教学笔记 JSON', exact: true }).click(); const notes = JSON.parse(readFileSync((await (await jsonPromise).path())!, 'utf8'));
  282 |   expect(notes.turns[0].teachingVersions).toHaveLength(2); expect(notes.turns[0].teachingVersions.find((item: any) => item.current).id).toBe(versionId);
  283 |   const mdPromise = page.waitForEvent('download'); await f.region.getByRole('button', { name: '下载完整教学笔记 Markdown', exact: true }).click();
  284 |   const markdown = readFileSync((await (await mdPromise).path())!, 'utf8'); expect(markdown).toContain(versionId!); expect(markdown).toContain(commands[0].imageSha256); expect(markdown).not.toContain('sessionTokenHash');
  285 |   await f.region.getByRole('combobox', { name: '讲解版本', exact: true }).selectOption('original'); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  286 |   await expect(lesson).toHaveAttribute('data-original-font-status', 'ready'); await expect(lesson.locator('.tw-figure')).toHaveCount(0); await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click();
  287 |   await page.goto(link); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready'); await expect(lesson.locator('.tw-figure')).toHaveCount(1);
  288 |   await page.screenshot({ path: join(browserEvidence('whiteboard-question-figures'), 'adopted-version.png') });
  289 | });
  290 | 
  291 | test('question figures: lost prepare and adoption receipts retain original commands through reload without duplicate images or versions', async ({ page }) => {
  292 |   const f = await fixture(page), pane = await questionFigure(page, f, '保留原请求的完整配图要求。', false); let prepareWrites = 0;
  293 |   await page.route('**/api/learning/studio/whiteboard-question-visuals', async route => {
  294 |     if (route.request().method() !== 'POST') return route.continue(); prepareWrites++; await route.fetch(); await route.abort('failed'); });
  295 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  296 |   await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click(); await expect(pane.getByRole('button', { name: '按原请求继续', exact: true })).toBeEnabled();
  297 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('保留原请求的完整配图要求。');
  298 |   await pane.getByRole('button', { name: '按原请求继续', exact: true }).click(); await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled(); expect(prepareWrites).toBe(1);
  299 |   let adoptionWrites = 0, first: any;
  300 |   await page.route('**/whiteboard-question-visuals/adopt', async route => { adoptionWrites++; const response = await route.fetch();
  301 |     if (adoptionWrites === 1) { first = (await response.json()).data; await route.abort('failed'); } else await route.fulfill({ response }); });
  302 |   await pane.getByLabel('图片说明', { exact: true }).fill('所有标签与条件已经核对。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  303 |   await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); await expect(pane.getByRole('button', { name: '按原请求继续', exact: true })).toBeEnabled();
  304 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await pane.getByRole('button', { name: '按原请求继续', exact: true }).click();
  305 |   await expect(page.getByRole('dialog', { name: 'AI补充讲解', exact: true })).toHaveAttribute('data-original-font-status', 'ready'); expect(adoptionWrites).toBe(2);
  306 |   const versions = await f.call('/learning/studio/whiteboards/' + f.board.id + '/questions/' + first.board.turnId + '/teaching-versions', undefined, f.actor.token, 'GET');
  307 |   expect(versions).toHaveLength(2); expect(versions.find((item: any) => item.current).id).toBe(first.versionId);
  308 | });
  309 | 
  310 | test('question figures: original PNG editing and two explicit adoptions preserve both prior teaching versions', async ({ page }) => {
  311 |   const f = await fixture(page, false, true), pane = await questionFigure(page, f); const versions: string[] = [];
  312 |   for (let pass = 0; pass < 2; pass++) {
  313 |     if (pass) { await pane.getByRole('button', { name: '以这张原图继续修改', exact: true }).click(); await pane.getByLabel('具体修改说明', { exact: true }).fill('把交集标签加大，并保留两个原始圆圈。');
  314 |       await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '用原PNG生成修改图', exact: true })).toBeEnabled();
  315 |       await pane.getByRole('button', { name: '用原PNG生成修改图', exact: true }).click(); await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled(); }
  316 |     await pane.getByLabel('图片说明', { exact: true }).fill('第' + pass + '幅已核对的关系图。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  317 |     const responsePromise = page.waitForResponse(response => response.request().method() === 'POST' && response.url().endsWith(questionFigureBase + '/adopt'));
  318 |     await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); const value = (await (await responsePromise).json()).data; versions.push(value.versionId);
  319 |     const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  320 |     await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click();
  321 |   }
  322 |   expect(versions[0]).not.toBe(versions[1]); await expect(f.region.getByRole('combobox', { name: '讲解版本', exact: true }).locator('option')).toHaveCount(3);
  323 |   await f.region.getByRole('combobox', { name: '讲解版本', exact: true }).selectOption(versions[0]); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  324 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  325 |   await lesson.getByRole('button', { name: '分享与导出', exact: true }).click(); expect(await lesson.getByLabel('原白板私有链接').inputValue()).toContain('teachingVersion=' + versions[0]);
  326 | });
  327 | 
  328 | test('question figures: explicit cancel and original retry keep the same image requirement and target', async ({ page }) => {
  329 |   const f = await fixture(page), pane = await questionFigure(page, f, '[image-pause-once] 完整条件与原图要求在重试后仍然保持。', false), commands: any[] = [];
  330 |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith(questionFigureBase)) commands.push(request.postDataJSON()); });
  331 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  332 |   await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click(); await pane.getByRole('button', { name: '取消图片生成', exact: true }).click();
  333 |   await expect(pane.getByRole('button', { name: '按原要求重试图片', exact: true })).toBeEnabled({ timeout: 20000 }); await pane.getByRole('button', { name: '按原要求重试图片', exact: true }).click();
  334 |   await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled({ timeout: 25000 }); expect(commands).toHaveLength(1);
  335 |   await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(commands[0].requirements);
  336 | });
  337 | 
  338 | test('question figures: duplicated documents keep separate full inputs and a closed workbench discards late preflight', async ({ page, context }) => {
  339 |   const f = await fixture(page), pane = await questionFigure(page, f, '第一标签的完整条件 A 尾部。', false), second = await context.newPage(); await second.goto(f.href);
  340 |   await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); const other = second.getByRole('region', { name: '回答配图工作区', exact: true });
  341 |   await other.getByRole('textbox', { name: '完整配图要求', exact: true }).fill('第二标签的完整条件 B 尾部。');
  342 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第一标签的完整条件 A 尾部。');
  343 |   await second.reload(); await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(other.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第二标签的完整条件 B 尾部。'); await second.close();
  344 |   let reached = false, delivered = false, release!: () => void; const gate = new Promise<void>(resolve => { release = resolve; });
  345 |   await page.route('**/whiteboard-question-visuals/preflight', async route => { const response = await route.fetch(); reached = true; await gate; try { await route.fulfill({ response }); } catch {} finally { delivered = true; } });
  346 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect.poll(() => reached).toBe(true); await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click();
  347 |   release(); await expect.poll(() => delivered).toBe(true); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeDisabled();
  348 | });
  349 | 
  350 | for (const width of [390, 768, 1280]) test('question figures: full input, storage failure, download and import remain usable at ' + width, async ({ page }) => {
  351 |   await page.setViewportSize({ width, height: 800 }); await page.addInitScript(() => { const set = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) {
  352 |     if (key.startsWith('studyagent.question-figures.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this, key, value); }; });
  353 |   const f = await fixture(page), requirements = '完整首部。' + '图示保留全部条件。'.repeat(100) + '完整尾部。', pane = await questionFigure(page, f, requirements, false);
  354 |   await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click(); await expect(pane).toBeVisible(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(requirements);
  355 |   for (const control of [pane.getByRole('textbox', { name: '完整配图要求', exact: true }), pane.getByRole('button', { name: '预检完整配图提示', exact: true })]) {
  356 |     const box = await control.boundingBox(); expect(box).not.toBeNull(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  357 |   }
  358 |   const promise = page.waitForEvent('download'); await pane.getByRole('button', { name: '下载完整配图副本', exact: true }).click(); const bytes = readFileSync((await (await promise).path())!);
  359 |   expect(JSON.parse(bytes.toString('utf8')).form.requirements).toBe(requirements); await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click(); await expect(pane).toHaveCount(0);
  360 |   await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await pane.getByRole('button', { name: '下载完整配图副本', exact: true }).click();
  361 |   await pane.getByLabel('导入完整配图副本', { exact: true }).setInputFiles({ name: 'complete-figure-copy.json', mimeType: 'application/json', buffer: bytes });
```