# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: paper-practice.spec.ts >> paper review next: a late recovery-file read cannot replace the subsequently confirmed original preview
- Location: tests\e2e\paper-practice.spec.ts:508:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('region', { name: '原题再练与独立新题' }).getByRole('region', { name: '独立新题原预览恢复' })
Expected: 0
Received: 1
Timeout:  15000ms

Call log:
  - Expect "toHaveCount" getByRole('region', { name: '原题再练与独立新题' }).getByRole('region', { name: '独立新题原预览恢复' }) with timeout 15000ms
  - waiting for getByRole('region', { name: '原题再练与独立新题' }).getByRole('region', { name: '独立新题原预览恢复' })
    33 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - main [ref=f1e2]:
    - generic [ref=f1e3]:
      - link "学习观察室" [ref=f1e4] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f1e5]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f1e6]:
        - link "学习首页" [ref=f1e7] [cursor=pointer]:
          - /url: /learn?subject=math
        - link "学习工作台" [ref=f1e8] [cursor=pointer]:
          - /url: /studio?subject=math
        - link "家长空间" [ref=f1e9] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math
        - link "知识诊断" [ref=f1e10] [cursor=pointer]:
          - /url: /student/assessment?subject=math
        - link "今日学习" [ref=f1e11] [cursor=pointer]:
          - /url: /student/today?subject=math
        - link "题卷资料" [ref=f1e12] [cursor=pointer]:
          - /url: /library?subject=math
      - generic [ref=f1e13]:
        - link "资料管理" [ref=f1e14] [cursor=pointer]:
          - /url: /parent/data
        - button "退出" [ref=f1e15] [cursor=pointer]
    - generic [ref=f1e16]:
      - link "← 返回原筛选与复习清单" [ref=f1e17] [cursor=pointer]:
        - /url: /library/practice/review?
      - paragraph [ref=f1e18]: 原练习中的首答与订正保持，下面继续整理这道题。
    - generic [ref=f1e19]:
      - generic [ref=f1e20]:
        - link "← 我的原卷练习" [ref=f1e21] [cursor=pointer]:
          - /url: /library/practice
        - link "待复习与反思 ↗" [ref=f1e22] [cursor=pointer]:
          - /url: /library/practice/review
        - strong [ref=f1e23]: 原卷练习
        - status [ref=f1e24]: 原记录已读取
      - paragraph [ref=f1e25]: 本人陪练 · 不作为孩子的实际作答
      - generic [ref=f1e26]:
        - generic [ref=f1e27]:
          - generic [ref=f1e28]: 1 / 1
          - paragraph [ref=f1e29]: 已提交记录
        - generic [ref=f1e30]:
          - text: "0"
          - paragraph [ref=f1e31]: 未答
        - generic [ref=f1e32]:
          - text: "0"
          - paragraph [ref=f1e33]: 自评待订正
        - generic [ref=f1e34]:
          - text: "0"
          - paragraph [ref=f1e35]: 缺题或来源不可用
      - paragraph [ref=f1e36]: 这里保留练习与自我核对，不计算未经审核的总分，也不自动改变知识掌握度。
      - generic [ref=f1e37]:
        - complementary "原卷题位目录" [ref=f1e38]:
          - generic [ref=f1e39]:
            - text: 查看范围
            - combobox "查看范围" [ref=f1e40]:
              - option "全部题位" [selected]
              - option "未答"
              - option "待订正"
              - option "暂时不会"
              - option "已跳过"
          - button "匿名原卷 37 · 完整 第 1 题 暂时不会" [pressed] [ref=f1e42] [cursor=pointer]:
            - generic [ref=f1e43]: 匿名原卷 37 · 完整
            - strong [ref=f1e44]: 第 1 题
            - generic [ref=f1e45]: 暂时不会
        - region "当前原题与首次回答" [ref=f1e46]:
          - generic [ref=f1e47]:
            - text: 匿名原卷 37 · 完整
            - heading "第 1 题" [level=1] [ref=f1e48]
            - link "回到原卷题位 ↗" [ref=f1e49] [cursor=pointer]:
              - /url: /library?paper=qa%3Apaper%3A37%3Acomplete&position=1
          - generic [ref=f1e50]:
            - generic [ref=f1e51]:
              - paragraph [ref=f1e52]:
                - text: 合成原题：
                - generic [ref=f1e54]:
                  - math [ref=f1e56]:
                    - generic [ref=f1e58]:
                      - generic [ref=f1e59]: "3"
                      - generic [ref=f1e60]: +
                      - generic [ref=f1e61]: "2"
                      - generic [ref=f1e62]: =
                      - generic [ref=f1e63]: "?"
                  - generic [aria-hidden] [ref=f1e64]:
                    - generic [ref=f1e65]: 3 +
                    - generic [ref=f1e66]: 2 =
                    - generic [ref=f1e67]: "?"
              - table [ref=f1e68]:
                - rowgroup [ref=f1e69]:
                  - row [ref=f1e70]:
                    - columnheader "第一组" [ref=f1e71]
                    - columnheader "第二组" [ref=f1e72]
                  - row [ref=f1e73]:
                    - cell "3" [ref=f1e74]
                    - cell "2" [ref=f1e75]
            - generic [ref=f1e76]:
              - generic [ref=f1e77]: A
              - paragraph [ref=f1e79]: "4"
            - generic [ref=f1e80]:
              - generic [ref=f1e81]: B
              - paragraph [ref=f1e83]: "5"
          - region "不可覆盖的首次回答" [ref=f1e84]:
            - text: 暂时不会
            - heading "当时的首次回答" [level=2] [ref=f1e85]
            - paragraph [ref=f1e86]: 本题没有提交解题文字。
            - time [ref=f1e87]: 2026/10/27 02:17:11
            - button "核对本题参考答案" [ref=f1e88] [cursor=pointer]
          - region "追加订正记录" [ref=f1e89]:
            - heading "保留第一次，再补充新的理解。" [level=2] [ref=f1e90]
            - generic [ref=f1e91]: 追加订正
            - textbox "追加订正" [ref=f1e92]
            - button "保存这次订正" [disabled] [ref=f1e93]
          - region "原卷复习与反思" [ref=f1e94]:
            - generic [ref=f1e95]:
              - text: 把问题说具体，再安排下一步
              - heading "这次，卡在哪里。" [level=2] [ref=f1e96]
              - paragraph [ref=f1e97]: 记录自己的判断与反思；能力原因仍需独立题目验证。
            - group "本人整理" [ref=f1e98]:
              - generic [ref=f1e100]:
                - text: 标签，用逗号分隔
                - textbox "标签，用逗号分隔" [ref=f1e101]
              - generic [ref=f1e102]:
                - text: 具体错误步骤
                - textbox "具体错误步骤" [ref=f1e103]:
                  - /placeholder: 例如：读到了数量，却漏掉了单位不同这个条件。
              - generic [ref=f1e104]:
                - text: 我的反思
                - textbox "我的反思" [ref=f1e105]:
                  - /placeholder: 当时为什么这样想，下次准备怎样检查？
                  - text: PRIVATE_CALENDAR_REFLECTION
              - generic [ref=f1e106]:
                - generic [ref=f1e107]:
                  - text: 计划回看日期
                  - textbox "计划回看日期" [ref=f1e108]: 2026-11-09
                - generic [ref=f1e109]:
                  - checkbox "收藏这道题" [ref=f1e110]
                  - text: 收藏这道题
                - generic [ref=f1e111]:
                  - checkbox "从待复习中归档" [ref=f1e112]
                  - text: 从待复习中归档
            - generic [ref=f1e113]:
              - button "保存反思与安排" [disabled] [ref=f1e114]
              - button "我已实际回看" [ref=f1e115] [cursor=pointer]
              - button "下载反思草稿保护文件" [ref=f1e116] [cursor=pointer]
            - paragraph [ref=f1e117]: 尚未记录实际回看。
            - group [ref=f1e118]:
              - generic "完整整理历史 · 1 次" [ref=f1e119] [cursor=pointer]
            - group [ref=f1e120]:
              - generic "恢复本机反思或原操作" [ref=f1e121] [cursor=pointer]
          - region "原题再练与独立新题" [ref=f1e122]:
            - generic [ref=f1e123]:
              - text: 下一步，选择怎样核对
              - heading "再练原题，或换一道新题。" [level=2] [ref=f1e124]
              - paragraph [ref=f1e125]: 原题用于练熟过程；独立新题用于检验知识与原因，分别保留依据。
            - status [ref=f1e126]: 原预览已读回，请明确核对原结果；不会自动开始评测。
            - generic [ref=f1e127]:
              - generic [ref=f1e128]:
                - heading "再练这道原题" [level=3] [ref=f1e129]
                - paragraph [ref=f1e130]: 确认同一原题与作答身份后创建新练习，旧首答保持。
                - paragraph [ref=f1e131]: 当前账号将记录新的本人陪练，不冒充孩子作答。
                - link "核对来源，再练原题 ↗" [ref=f1e132] [cursor=pointer]:
                  - /url: /library/practice?paper=qa%3Apaper%3A37%3Acomplete&originSession=paper_practice_05026bbc70903634331da310b06179e95c338822&originItem=paper_item_dd2cee19aea5037ad3b4331bebfe1aa4528cab1e&studentId=student_6f01cfa9-cf57-48bf-99af-e325d983f9d3&positions=1
              - generic [ref=f1e133]:
                - heading "用独立新题验证" [level=3] [ref=f1e134]
                - paragraph [ref=f1e135]: 来源、五门审核和当前知识定义均已核对；请确认学习范围后预览独立新题。
                - group "先确认孩子和当前学习范围" [ref=f1e136]:
                  - generic [ref=f1e138]:
                    - text: 验证的孩子
                    - combobox "验证的孩子" [disabled] [ref=f1e139]:
                      - option "请选择有权的孩子" [disabled]
                      - option "合成原预览恢复孩子" [disabled] [selected]
                  - generic [ref=f1e140]:
                    - text: 核对的知识点
                    - combobox "核对的知识点" [disabled] [ref=f1e141]:
                      - option "20以内加法合并" [disabled] [selected]
                  - paragraph [ref=f1e142]: 当前确认：3年级 · 上学期 · 合成已确认范围
                  - paragraph [ref=f1e143]: 此知识点在已确认的已学范围内。
                  - generic [ref=f1e144]:
                    - checkbox "我已核对这位孩子的当前年级、教材和已学范围" [disabled] [ref=f1e145]
                    - text: 我已核对这位孩子的当前年级、教材和已学范围
                  - button "预览独立新题蓝图" [disabled] [ref=f1e146]
                - link "查看学习范围，手动选择知识点 ↗" [ref=f1e147] [cursor=pointer]:
                  - /url: /student/assessment?studentId=student_6f01cfa9-cf57-48bf-99af-e325d983f9d3&subject=math
            - region "原卷关联的新题蓝图" [ref=f1e148]:
              - heading "继续原来的独立新题蓝图。" [level=3] [ref=f1e149]
              - paragraph [ref=f1e150]: 这份蓝图已保存在原记录中，尚未开始作答。请在蓝图页核对范围、有效期和可用题目。
              - link "打开原蓝图，确认后开始 ↗" [ref=f1e151] [cursor=pointer]:
                - /url: /student/assessment?studentId=student_6f01cfa9-cf57-48bf-99af-e325d983f9d3&subject=math&blueprint=blueprint%3A758dcf64460868d49aa664036716931b6303db1335bb38aefe3d08f79c1189dc
            - group [ref=f1e152]:
              - generic "这次原题之后的实际活动 · 1 条" [ref=f1e153] [cursor=pointer]
            - region "独立新题原预览恢复" [ref=f1e154]:
              - heading "保留原范围，再核对结果。" [level=3] [ref=f1e155]
              - button "下载原预览保护文件" [ref=f1e156] [cursor=pointer]
              - button "核对或重试原新题预览" [ref=f1e157] [cursor=pointer]
            - group [ref=f1e158]:
              - generic "从原新题预览保护文件恢复" [ref=f1e159] [cursor=pointer]
              - generic [ref=f1e160]:
                - text: 选择新题预览保护文件
                - button "选择新题预览保护文件" [disabled] [ref=f1e161]
          - generic [ref=f1e162]:
            - button "上一题位" [disabled] [ref=f1e163]
            - button "下一题位 ↗" [disabled] [ref=f1e164]
      - generic [ref=f1e165]:
        - button "保存位置并暂停" [ref=f1e166] [cursor=pointer]
        - button "结束并复盘" [ref=f1e167] [cursor=pointer]
        - button "下载本机草稿保护文件" [ref=f1e168] [cursor=pointer]
      - button "查看其他本机草稿与原操作" [ref=f1e169] [cursor=pointer]
      - generic [ref=f1e170]:
        - text: 从本次练习保护文件恢复
        - button "从本次练习保护文件恢复" [ref=f1e171]
  - alert [ref=f1e172]
```

# Test source

```ts
  418 | async function plannedPaperReview(f: Awaited<ReturnType<typeof fixture>>, paper: string, date: string, studentId?: string, actor = f.actor.token) {
  419 |   const selection = [{ paperId: paper, positions: [1] }], scope = { selection, ...(studentId ? { studentId } : {}) };
  420 |   const preview = await f.call('/library/practice/preview', scope, actor);
  421 |   let row = await f.call('/library/practice/sessions', { ...scope, sourceHash: preview.sourceHash, requestKey: randomUUID() }, actor);
  422 |   const itemId = row.items[0].id;
  423 |   row = (await f.call('/library/practice/sessions/' + row.id + '/commands', { expectedVersion: row.version, requestKey: randomUUID(), kind: 'submit', itemId, disposition: 'dont_know', text: '' }, actor)).session;
  424 |   row = (await f.call('/library/practice/sessions/' + row.id + '/commands', { expectedVersion: row.version, requestKey: randomUUID(), kind: 'organize', itemId, values: { tags: [], favorite: false, archived: false, errorSteps: '', reflection: 'PRIVATE_CALENDAR_REFLECTION', plannedDate: date } }, actor)).session;
  425 |   return { row, itemId };
  426 | }
  427 | 
  428 | for (const timezoneId of ['America/Los_Angeles', 'Pacific/Kiritimati']) test.describe('paper calendar timezone ' + timezoneId, () => {
  429 |   test.use({ timezoneId });
  430 |   test('paper calendar: an adult without a child keeps the actual all-day date, original review and calendar return through reloads', async ({ page }) => {
  431 |     const f = await fixture(page, 30), { row, itemId } = await plannedPaperReview(f, f.papers.complete, '2026-03-08');
  432 |     await page.goto('/studio?view=calendar&date=2026-03-08&mode=week');
  433 |     const grid = page.locator('.ws-month-grid'), card = page.getByRole('region', { name: '日历中的原卷复习' });
  434 |     await expect(grid.getByRole('link', { name: /原卷.*匿名原卷 30/ })).toBeVisible();
  435 |     await expect(page.getByRole('button', { name: '选择日期 2026-03-08', exact: true })).toHaveAttribute('aria-pressed', 'true');
  436 |     await expect(card).not.toContainText('PRIVATE_CALENDAR_REFLECTION');
  437 |     for (let index = 0; index < 3; index++) { await page.reload(); await expect(grid.getByRole('link', { name: /原卷.*匿名原卷 30/ })).toBeVisible(); }
  438 |     expect((await f.call('/library/practice/sessions/' + row.id)).version).toBe(row.version);
  439 |     const waiting = page.waitForEvent('download'); await card.getByRole('button', { name: '导出当前范围原卷 ICS' }).click(); const download = await waiting;
  440 |     const contents = readFileSync((await download.path())!, 'utf8'); expect(contents).toContain('DTSTART;VALUE=DATE:20260308'); expect(contents).not.toContain('PRIVATE_CALENDAR_REFLECTION');
  441 |     await grid.getByRole('link', { name: /原卷.*匿名原卷 30/ }).click(); await expect(page.getByRole('link', { name: '← 返回原日期与课程日历' })).toBeVisible();
  442 |     const editor = page.getByRole('region', { name: '原卷复习与反思' }); await expect(editor.getByLabel('我的反思')).toHaveValue('PRIVATE_CALENDAR_REFLECTION');
  443 |     await editor.getByRole('button', { name: '我已实际回看', exact: true }).click(); await expect(editor.getByRole('button', { name: '重新放回待复习', exact: true })).toBeVisible();
  444 |     await page.getByRole('link', { name: '← 返回原日期与课程日历' }).click(); expect(new URL(page.url()).searchParams.get('date')).toBe('2026-03-08'); expect(new URL(page.url()).searchParams.get('mode')).toBe('week');
  445 |     await expect(page.locator('.ws-day-done').getByRole('link', { name: /匿名原卷 30.*已实际回看/ })).toBeVisible();
  446 |     const item = await f.call('/library/practice/sessions/' + row.id + '/items/' + itemId); expect(item.firstAnswer.disposition).toBe('dont_know'); expect(item.organization.status).toBe('reviewed');
  447 |     await page.goto('/library/practice/review?session=' + row.id + '&item=' + itemId + '&calendarReturn=' + encodeURIComponent('https://untrusted.invalid/studio?view=calendar'));
  448 |     await expect(page.getByRole('region', { name: '原卷复习与反思' })).toBeVisible(); await expect(page.getByRole('link', { name: '← 返回原日期与课程日历' })).toHaveCount(0);
  449 |   });
  450 | });
  451 | 
  452 | for (const width of [390, 768, 1440]) test('paper calendar: the original review shares the real course grid without becoming a removable course event at ' + width, async ({ page }) => {
  453 |   const f = await fixture(page, width === 390 ? 32 : width === 768 ? 33 : 34), child = (await f.call('/students', { nickname: '合成原卷日历孩子', grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile.id;
  454 |   await plannedPaperReview(f, f.papers.complete, '2026-11-09', child);
  455 |   await f.call('/learning/studio/calendar/events', { studentId: child, subject: 'math', title: '合成课程学习安排', description: '只有手动课程事件可以批量删除', startsAt: '2026-11-09T02:00:00Z', endsAt: '2026-11-09T02:25:00Z', requestKey: randomUUID() });
  456 |   await page.setViewportSize({ width, height: 1000 }); await page.goto('/studio?view=calendar&student=' + child + '&date=2026-11-09');
  457 |   const grid = page.locator('.ws-month-grid'); await expect(grid.getByRole('link', { name: /原卷.*匿名原卷/ })).toBeVisible(); await expect(grid.getByRole('button', { name: /合成课程学习安排/ })).toBeVisible();
  458 |   await expect(page.getByRole('region', { name: '日历中的原卷复习' }).getByLabel('原卷作答范围')).toHaveValue('mine');
  459 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  460 |   await page.screenshot({ path: join(browserEvidence('paper-practice'), 'unified-calendar-' + width + '.png'), fullPage: true });
  461 |   await page.getByRole('button', { name: '批量删除日程', exact: true }).click(); await expect(grid.getByRole('checkbox')).toHaveCount(1); await expect(grid.getByRole('link', { name: /原卷.*匿名原卷/ })).toBeVisible();
  462 | });
  463 | 
  464 | test('paper calendar: changing the actual actor scope fences a late private response and preserves an explicit read failure', async ({ page }) => {
  465 |   const f = await fixture(page, 35), child = (await f.call('/students', { nickname: '合成范围隔离孩子', grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile.id;
  466 |   await plannedPaperReview(f, f.papers.complete, '2026-11-09', child);
  467 |   await f.call('/students/' + child + '/learning-access', { enabled: true, expectedVersion: 0, requestKey: randomUUID(), reason: '合成日历本人和学习账号隔离' });
  468 |   const issued = await f.call('/students/' + child + '/learning-access/codes', { expectedVersion: 1, requestKey: randomUUID() });
  469 |   const learner = await f.call('/auth/learning-code', { code: issued.code }, ''); await plannedPaperReview(f, f.papers.partial, '2026-11-09', child, learner.token);
  470 |   await page.goto('/studio?view=calendar&student=' + child + '&date=2026-11-09'); const grid = page.locator('.ws-month-grid'), controls = page.getByRole('region', { name: '日历中的原卷复习' });
  471 |   await expect(grid.getByRole('link', { name: /匿名原卷 35.*完整/ })).toBeVisible(); await expect(grid.getByRole('link', { name: /匿名原卷 35.*部分/ })).toHaveCount(0);
  472 |   let release!: () => void, reached!: () => void, finished!: () => void, held = false;
  473 |   const gate = new Promise<void>(resolve => { release = resolve; }), seen = new Promise<void>(resolve => { reached = resolve; }), done = new Promise<void>(resolve => { finished = resolve; });
  474 |   await page.route('**/api/library/practice/reviews/calendar?**', async route => {
  475 |     if (new URL(route.request().url()).searchParams.get('scope') === 'mine' && !held) { held = true; const response = await route.fetch(); reached(); await gate; await route.fulfill({ response }); finished(); }
  476 |     else await route.continue();
  477 |   });
  478 |   try {
  479 |     await controls.getByRole('button', { name: '刷新原卷安排' }).click(); await seen;
  480 |     await controls.getByLabel('原卷作答范围').selectOption('learner'); await expect(grid.getByRole('link', { name: /匿名原卷 35.*部分/ })).toBeVisible(); await expect(grid.getByRole('link', { name: /匿名原卷 35.*完整/ })).toHaveCount(0);
  481 |   } finally { release(); }
  482 |   await done; await expect(grid.getByRole('link', { name: /匿名原卷 35.*完整/ })).toHaveCount(0);
  483 |   await page.unrouteAll({ behavior: 'wait' }); let failOnce = true;
  484 |   await page.route('**/api/library/practice/reviews/calendar?**', async route => { if (failOnce) { failOnce = false; await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ data: null, error: { message: '合成原卷日历暂不可读', code: 'fixture_calendar_unavailable' } }) }); } else await route.continue(); });
  485 |   await controls.getByRole('button', { name: '刷新原卷安排' }).click(); await expect(controls.getByRole('alert')).toContainText('合成原卷日历暂不可读'); await expect(grid.getByRole('link')).toHaveCount(0);
  486 |   await controls.getByRole('button', { name: '刷新原卷安排' }).click(); await expect(grid.getByRole('link', { name: /匿名原卷 35.*部分/ })).toBeVisible(); await expect(controls.getByRole('alert')).toHaveCount(0);
  487 | });
  488 | 
  489 | 
  490 | async function reviewVerificationFixture(f: Awaited<ReturnType<typeof fixture>>) {
  491 |   const atoms = await f.call('/diagnostics/curriculum?subject=math&grade=3&term=upper'), atom = atoms.find((value: any) => /加法|加减|合并/.test(value.name) && value.status === 'published'); expect(atom).toBeTruthy();
  492 |   const staged = await f.call('/measurement-content/candidates', { paperId: f.papers.complete, positions: [1] }, administrator);
  493 |   let candidate = await f.call('/measurement-content/candidates/' + encodeURIComponent(staged.items[0].id), undefined, administrator);
  494 |   const command = () => ({ expectedVersion: candidate.version, requestKey: randomUUID(), reason: '合成恢复文件和原请求核对' });
  495 |   const draft = { subject: 'math', grade: 3, stem: '合成独立核对：3个球和2个球合起来一共多少个？', answer: 5, analysis: '把两部分3和2合并得到5。', blocks: [],
  496 |     answerSchema: { mode: 'numeric_blank', responseShape: { value: 'number' }, validationRules: {}, gradingConfig: {} },
  497 |     mapping: { primaryAtomId: atom.id, prerequisiteAtomIds: [], secondaryAtomIds: [], dimension: 'procedure', family: 'qa:browser-review:' + f.papers.complete, probeRole: 'anchor', expectedSeconds: 40, difficulty: 1, observationCode: 'part_whole_mismatch', observedSteps: ['确认两组数量并合并得到总量'], rationale: '只依据合成原题的合并数量过程，不猜测反思', familyRationale: '受控数量合并任务，仅用于恢复流程核对' },
  498 |     license: { licenseClass: 'A_INTERNAL', evidence: '独立构造的合成原卷与题干' }, scoringCases: [{ response: 5, expectedScore: 1, rationale: '将两组数量合并' }, { response: 1, expectedScore: 0, rationale: '误把合并当成求差' }] };
  499 |   candidate = await f.call('/measurement-content/candidates/' + encodeURIComponent(candidate.id) + '/draft', { ...command(), draft }, administrator);
  500 |   for (const gate of ['source', 'content', 'media', 'scoring', 'mapping']) candidate = await f.call('/measurement-content/candidates/' + encodeURIComponent(candidate.id) + '/reviews', { ...command(), gate, decision: 'approved' }, administrator);
  501 |   await f.call('/measurement-content/candidates/' + encodeURIComponent(candidate.id) + '/publish', command(), administrator);
  502 |   const child = (await f.call('/students', { nickname: '合成原预览恢复孩子', grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile.id;
  503 |   await f.call('/students/' + child + '/learning-scope', { subject: 'math', grade: 3, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已确认范围', learnedAtomIds: [atom.id], currentAtomId: atom.id, minutesPerSession: 15 }, f.actor.token, 200, 'PUT');
  504 |   const { row, itemId } = await plannedPaperReview(f, f.papers.complete, '2026-11-09', child);
  505 |   return { atom, child, row, itemId, saved: { format: 'paper-review-verification-v1', ownerId: f.actor.user.id, sessionId: row.id, itemId, body: { studentId: child, atomId: atom.id, requestKey: randomUUID() } } };
  506 | }
  507 | 
  508 | test('paper review next: a late recovery-file read cannot replace the subsequently confirmed original preview', async ({ page }) => {
  509 |   const f = await fixture(page, 37), data = await reviewVerificationFixture(f);
  510 |   await page.goto('/library/practice/review?session=' + data.row.id + '&item=' + data.itemId); const next = page.getByRole('region', { name: '原题再练与独立新题' });
  511 |   await expect(next).toContainText('此知识点在已确认的已学范围内。');
  512 |   await page.evaluate(() => { const original = File.prototype.text; File.prototype.text = async function () { const result = await original.call(this); if (this.name === 'delayed-preview.json') await new Promise<void>(resolve => { (window as unknown as { releasePaperFile: () => void }).releasePaperFile = resolve; }); return result; }; });
  513 |   await next.getByText('从原新题预览保护文件恢复', { exact: true }).click(); await next.getByLabel('选择新题预览保护文件').setInputFiles({ name: 'delayed-preview.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(data.saved)) });
  514 |   await expect.poll(() => page.evaluate(() => typeof (window as unknown as { releasePaperFile?: unknown }).releasePaperFile)).toBe('function');
  515 |   await next.getByLabel('我已核对这位孩子的当前年级、教材和已学范围').check(); await next.getByRole('button', { name: '预览独立新题蓝图', exact: true }).click();
  516 |   await expect(next.getByRole('link', { name: '打开原蓝图，确认后开始 ↗' })).toBeVisible();
  517 |   await page.evaluate(() => (window as unknown as { releasePaperFile: () => void }).releasePaperFile());
> 518 |   await expect(next.getByRole('region', { name: '独立新题原预览恢复' })).toHaveCount(0);
      |                                                                 ^ Error: expect(locator).toHaveCount(expected) failed
  519 |   expect(await f.call('/library/practice/sessions/' + data.row.id + '/items/' + data.itemId + '/verification-requests/' + data.saved.body.requestKey)).toBeNull();
  520 |   const options = await f.call('/library/practice/sessions/' + data.row.id + '/items/' + data.itemId + '/next-options'); expect(options.activities.filter((activity: any) => activity.kind === 'verification_preview')).toHaveLength(1);
  521 | });
  522 | 
  523 | test('paper review next: denied storage requires a real original file and rejects another owner before explicit exact-key preview recovery', async ({ page }) => {
  524 |   const f = await fixture(page, 38), data = await reviewVerificationFixture(f); let posts = 0;
  525 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('study.paper-review.verification:')) throw new DOMException('Synthetic denied preview storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  526 |   await page.goto('/library/practice/review?session=' + data.row.id + '&item=' + data.itemId); const next = page.getByRole('region', { name: '原题再练与独立新题' });
  527 |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/verification-preview')) posts++; });
  528 |   await expect(next).toContainText('此知识点在已确认的已学范围内。'); await next.getByLabel('我已核对这位孩子的当前年级、教材和已学范围').check(); await next.getByRole('button', { name: '预览独立新题蓝图', exact: true }).click();
  529 |   const recovery = next.getByRole('region', { name: '独立新题原预览恢复' }); await expect(recovery.getByRole('button', { name: '核对或重试原新题预览' })).toBeDisabled(); expect(posts).toBe(0);
  530 |   const waiting = page.waitForEvent('download'); await recovery.getByRole('button', { name: '下载原预览保护文件' }).click(); const download = await waiting, saved = JSON.parse(readFileSync((await download.path())!, 'utf8'));
  531 |   expect(saved).toMatchObject({ format: data.saved.format, ownerId: f.actor.user.id, sessionId: data.row.id, itemId: data.itemId });
  532 |   page.once('dialog', dialog => dialog.accept()); await page.reload(); await next.getByText('从原新题预览保护文件恢复', { exact: true }).click();
  533 |   await next.getByLabel('选择新题预览保护文件').setInputFiles({ name: 'other-owner.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify({ ...saved, ownerId: 'another-owner' })) });
  534 |   await expect(next.getByRole('alert')).toContainText('不属于当前账号'); expect(posts).toBe(0);
  535 |   await next.getByLabel('选择新题预览保护文件').setInputFiles({ name: 'original-preview.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(saved)) });
  536 |   await expect(recovery).toBeVisible(); await recovery.getByLabel('我已另外保留完整预览文件').check(); await recovery.getByRole('button', { name: '核对或重试原新题预览' }).click();
  537 |   await expect(next.getByRole('link', { name: '打开原蓝图，确认后开始 ↗' })).toBeVisible(); expect(posts).toBe(1);
  538 |   const original = await f.call('/library/practice/sessions/' + data.row.id + '/items/' + data.itemId + '/verification-requests/' + saved.body.requestKey); expect(original.paperReviewOrigin).toMatchObject({ sessionId: data.row.id, itemId: data.itemId });
  539 | });
  540 | 
```