# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio.spec.ts >> a parent can build and reopen an evidence-backed learning studio course
- Location: tests\e2e\studio.spec.ts:30:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Calendar' })

```

# Page snapshot

```yaml
- generic [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - button "打开学习导航" [ref=f3e4] [cursor=pointer]
    - generic [ref=f3e7]:
      - generic [ref=f3e8]:
        - generic [ref=f3e9]:
          - combobox "学习档案" [ref=f3e10]:
            - option "工作台验收" [selected]
          - combobox "学科" [ref=f3e11]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f3e12]:
          - link "教学课堂 ↗" [ref=f3e13] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f3e14] [cursor=pointer]:
            - /url: /
      - generic [ref=f3e15]:
        - tablist [ref=f3e16]:
          - tab "PDF 页级资料" [ref=f3e17] [cursor=pointer]
          - tab "个性化学案" [active] [selected] [ref=f3e18] [cursor=pointer]
        - generic [ref=f3e19]:
          - generic [ref=f3e20]:
            - generic [ref=f3e21]:
              - text: PERSONAL STUDY PACK
              - heading "一份学案，四个证据环节。" [level=1] [ref=f3e22]
              - paragraph [ref=f3e23]: 从已审核知识定义、讲解、例子和易错点生成讲义、闪卡与微测清单；可选 PDF 页作为人工对照来源。
            - button "打印当前学案" [ref=f3e24] [cursor=pointer]
          - generic [ref=f3e25]:
            - complementary [ref=f3e26]:
              - generic [ref=f3e27]: 01 / SELECT FOCUS
              - generic [ref=f3e28]:
                - text: 学案名称
                - textbox "学案名称" [ref=f3e29]:
                  - /placeholder: 留空则按知识点自动命名
              - generic [ref=f3e30]:
                - generic [ref=f3e31] [cursor=pointer]:
                  - checkbox "异分母分数加法 尚未测量 · 通分到共同单位后相加" [checked] [ref=f3e32]
                  - generic [ref=f3e33]:
                    - generic [ref=f3e34]: 异分母分数加法
                    - generic [ref=f3e35]: 尚未测量 · 通分到共同单位后相加
                - generic [ref=f3e36] [cursor=pointer]:
                  - checkbox "异分母分数减法 尚未测量 · 通分后求所占部分的差" [checked] [ref=f3e37]
                  - generic [ref=f3e38]:
                    - generic [ref=f3e39]: 异分母分数减法
                    - generic [ref=f3e40]: 尚未测量 · 通分后求所占部分的差
              - generic [ref=f3e41]:
                - text: 对照 PDF（可选）
                - combobox "对照 PDF（可选）" [ref=f3e42]:
                  - option "只使用已审核知识素材" [selected]
                  - option "分数讲义"
              - paragraph [ref=f3e43]: PDF 页面不会自动等同于知识点映射；系统只在能核对文本时保留页码，并明确标注待人工确认。
              - button "生成学案预览" [ref=f3e44] [cursor=pointer]
            - main [ref=f3e45]:
              - generic [ref=f3e46]:
                - generic [ref=f3e47]: GROUNDED, NOT INVENTED
                - heading "讲义先解释，再用新题验证。" [level=2] [ref=f3e48]
                - paragraph [ref=f3e49]: 选择 1–4 个知识点后预览。学案会区分知识定义、已审核例子、可验证易错假设与迁移任务；内容不足时明确停止。
            - complementary [ref=f3e50]:
              - button "8 段 · 6 卡 异分母分数加法 × 异分母分数减法 · 个性化学案 2026/10/27" [ref=f3e51] [cursor=pointer]:
                - generic [ref=f3e52]: 8 段 · 6 卡
                - generic [ref=f3e53]: 异分母分数加法 × 异分母分数减法 · 个性化学案
                - generic [ref=f3e54]: 2026/10/27
              - article [ref=f3e55]:
                - generic [ref=f3e56]:
                  - generic [ref=f3e57]: 2 个知识点
                  - heading "异分母分数加法 × 异分母分数减法 · 个性化学案" [level=3] [ref=f3e58]
                - generic [ref=f3e59]:
                  - group [ref=f3e60]:
                    - generic "先用自己的话建立关系" [ref=f3e61]
                  - group [ref=f3e62]:
                    - generic "跟着已审核例子走一遍" [ref=f3e63]
                  - group [ref=f3e64]:
                    - generic "把易错点变成可验证假设" [ref=f3e65]
                  - group [ref=f3e66]:
                    - generic "换一个情境再检查" [ref=f3e67]
                  - group [ref=f3e68]:
                    - generic "先用自己的话建立关系" [ref=f3e69]
                  - group [ref=f3e70]:
                    - generic "跟着已审核例子走一遍" [ref=f3e71]
                  - group [ref=f3e72]:
                    - generic "把易错点变成可验证假设" [ref=f3e73]
                  - group [ref=f3e74]:
                    - generic "换一个情境再检查" [ref=f3e75]
                - button "打印 / 保存 PDF" [ref=f3e76] [cursor=pointer]
                - link "开始定向微测 ↗" [ref=f3e77] [cursor=pointer]:
                  - /url: /student/assessment?studentId=student_933ce819-80b9-4691-8dc3-bf9be2f2ad73&subject=math&atom=core%3Amath%3Afractionadd
```

# Test source

```ts
  63  |   await page.getByRole('button', { name: '生成第一门课程' }).click();
  64  |   await page.getByLabel('课程名称', {exact:true}).fill('分数关系与证据');
  65  |   await page.getByRole('button', { name: '预览课程蓝图' }).click();
  66  |   await expect(page.getByText('Unit 1:', { exact: false }).first()).toBeVisible();
  67  |   await page.getByRole('button', { name: '确认并创建' }).click();
  68  |   await expect(page.getByRole('heading', { name: '分数关系与证据' })).toBeVisible();
  69  |   await expect(page.getByText('Unit 1:', { exact: false }).first()).toBeVisible();
  70  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-course-polished.png', fullPage: true });
  71  | 
  72  |   await page.getByRole('button', { name: 'Courses', exact: true }).click();
  73  |   const ticket = page.locator('.ws-course-ticket').filter({ has: page.getByRole('button', { name: '打开课程：分数关系与证据', exact: true }) });
  74  |   await page.evaluate(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  75  |   await ticket.locator('.ws-ticket-next').click();
  76  |   await expect(page.locator('.cl-room')).toBeVisible();
  77  |   await page.getByRole('button', { name: '离开课堂', exact: true }).click();
  78  |   await page.getByRole('button', { name: '保存并离开' }).click();
  79  |   await expect(page.getByRole('heading', { name: '分数关系与证据' })).toBeVisible();
  80  | 
  81  |   await page.getByRole('button', { name: 'Home' }).click();
  82  |   await page.getByRole('button', { name: 'Instant Assistance' }).click();
  83  |   await page.getByRole('button', { name: 'Concept Explanation' }).click();
  84  |   await page.locator('.sa-tools-popover').getByRole('button', { name: /Whiteboard session/ }).click();
  85  |   await page.locator('.sa-composer textarea').fill('解释异分母分数加法');
  86  |   await page.locator('.sa-composer > div > button:last-child').click();
  87  |   await expect(page.getByText('WHITEBOARD SESSION', { exact: true })).toBeVisible();
  88  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-whiteboard-preview.png', fullPage: true });
  89  |   await page.getByRole('button', { name: '保存到学习工作台' }).click();
  90  |   await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  91  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-whiteboard-player.png', fullPage: true });
  92  |   const videoDownload = page.waitForEvent('download', { timeout: 120_000 });
  93  |   await page.getByRole('button', { name: '导出视频' }).click();
  94  |   const video = await videoDownload;
  95  |   expect(video.suggestedFilename()).toMatch(/\.webm$/);
  96  |   expect(statSync(await video.path()).size).toBeGreaterThan(2_000);
  97  |   const subtitleDownload = page.waitForEvent('download');
  98  |   await page.getByRole('button', { name: '导出字幕' }).click();
  99  |   expect((await subtitleDownload).suggestedFilename()).toMatch(/\.srt$/);
  100 |   await page.getByRole('button', { name: '关闭白板' }).click();
  101 | 
  102 |   await page.getByRole('button', { name: 'Calendar' }).click();
  103 |   await page.getByRole('button', { name: '＋ 新建学习安排' }).click();
  104 |   await page.getByLabel('任务名称').fill('分数复习安排');
  105 |   await page.getByLabel('完成标准').fill('独立完成 5 道新题并说出关键步骤');
  106 |   await page.getByRole('button', { name: '加入学习日历' }).click();
  107 |   await expect(page.locator('.ws-month-grid').getByText('分数复习安排')).toBeVisible();
  108 |   await page.getByRole('button', { name: '连接 LMS / 日历' }).click();
  109 |   await page.getByLabel('来源类型').selectOption('lms_ics');
  110 |   await page.getByLabel('或粘贴 ICS 文件内容').fill('BEGIN:VCALENDAR\nBEGIN:VEVENT\nUID:school-1\nDTSTART:20261103T080000+0800\nDTEND:20261103T084500+0800\nSUMMARY:学校单元复习\nEND:VEVENT\nEND:VCALENDAR');
  111 |   await page.getByRole('button', { name: '连接并同步' }).click();
  112 |   await page.getByRole('button', {name:'下一个日期范围'}).click();
  113 |   await expect(page.locator('.ws-month-grid').getByText('学校单元复习')).toBeVisible();
  114 |   await expect(page.getByRole('button', { name: '连接并同步' })).toHaveCount(0);
  115 |   await page.locator('.ws-calendar-management > summary').click();
  116 |   await page.getByRole('button', { name: '＋ 生成诊断学习计划' }).click();
  117 |   await expect(page.getByLabel('计划目标')).toBeVisible();
  118 |   await page.getByRole('button', { name: '预览学习计划' }).click();
  119 |   await expect(page.getByText('审阅后再加入日历')).toBeVisible();
  120 |   await expect(page.getByText(/计划完成只表示执行过任务/)).toBeVisible();
  121 |   await page.getByRole('button', { name: '确认并加入日历' }).click();
  122 |   await expect(page.locator('.sa-plan-card')).toBeVisible();
  123 |   await page.locator('.sa-plan-actions').getByRole('button', { name: '完成', exact: true }).first().click();
  124 |   await expect(page.getByText('D+1 延迟复测', { exact: false }).first()).toBeVisible();
  125 |   await expect(page.getByText(/D\+14/).last()).toBeVisible();
  126 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-calendar-polished.png', fullPage: true });
  127 | 
  128 |   const pdf = writeTextPdf();
  129 |   await page.getByRole('button', { name: 'Materials' }).click();
  130 |   await expect(page.getByRole('tab', { name: 'PDF 页级资料' })).toHaveAttribute('aria-selected', 'true');
  131 |   await page.locator('input[type=file]').setInputFiles(pdf.path);
  132 |   await expect(page.getByText('分数讲义', { exact: true }).first()).toBeVisible({ timeout: 30_000 });
  133 |   await page.waitForFunction(() => Boolean(document.querySelector('.sa-pdf-paper img') || document.querySelector('.sa-pdf-failed')),
  134 |     undefined, { timeout: 30_000 });
  135 |   if (await page.locator('.sa-pdf-failed').count())
  136 |     throw new Error('PDF processing failed: ' + await page.locator('.sa-pdf-failed').innerText());
  137 |   await expect(page.locator('.sa-pdf-paper img')).toBeVisible({ timeout: 30_000 });
  138 |   await page.getByRole('button', { name: '结构恢复' }).click();
  139 |   await expect(page.getByText('公式结构', { exact: true })).toBeVisible();
  140 |   await expect(page.getByText(/候选 LaTeX/)).toBeVisible();
  141 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-pdf-structure-review.png', fullPage: true });
  142 |   await page.getByRole('button', { name: '已对照原页确认结构' }).click();
  143 |   await expect(page.getByText('结构已恢复')).toBeVisible();
  144 |   await page.getByRole('button', { name: '原版页面' }).click();
  145 |   const originalDownload = page.waitForEvent('download');
  146 |   await page.getByRole('button', { name: '下载原文件' }).click();
  147 |   expect((await originalDownload).suggestedFilename()).toMatch(/\.pdf$/);
  148 |   await page.getByRole('tab', { name: '个性化学案' }).click();
  149 |   await page.getByRole('button', { name: '生成学案预览' }).click();
  150 |   await expect(page.getByText('REVIEW BEFORE SAVING')).toBeVisible();
  151 |   await page.getByRole('button', { name: '保存到 Materials' }).click();
  152 |   await expect(page.locator('.sa-pack-library')).toContainText('个性化学案');
  153 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-materials-and-pack.png', fullPage: true });
  154 |   pdf.cleanup();
  155 | 
  156 |   await page.setViewportSize({ width: 390, height: 844 });
  157 |   await page.goto('/studio');
  158 |   await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  159 |   await page.getByRole('button', { name: 'Materials' }).click();
  160 |   await page.getByRole('tab', { name: '个性化学案' }).click();
  161 |   await expect(page.locator('.sa-pack-layout')).toBeVisible();
  162 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
> 163 |   await page.getByRole('button', { name: 'Calendar' }).click();
      |                                                        ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  164 |   await page.locator('.ws-calendar-management > summary').click();
  165 |   await expect(page.locator('.sa-plan-card')).toBeVisible();
  166 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  167 | 
  168 |   await page.getByRole('button', { name: 'Home' }).click();
  169 |   await page.reload();
  170 |   await expect(page.getByRole('button', { name: 'Craft Courses' })).toBeVisible();
  171 |   expect(errors).toEqual([]);
  172 | });
  173 | 
```