// Existing installed CLI + synthetic local Responses provider; never invoke a model or a tool.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),{spawn}=require('node:child_process');
const root=process.cwd(),base=fs.mkdtempSync(path.join(root,'data/qa/cli-text-tools-'));
const vendor=path.join(process.env.APPDATA,'npm/node_modules/@openai/codex/node_modules/@openai/codex-win32-x64/vendor');
const binary=fs.readdirSync(vendor).map(name=>path.join(vendor,name,'bin/codex.exe')).find(file=>fs.existsSync(file));
if(!binary)throw Error('Existing installed CLI required');
const catalog=JSON.parse(fs.readFileSync('data/qa/cli-compatible-catalog.json'));
const restrictedCatalog=structuredClone(catalog);for(const model of restrictedCatalog.models){model.apply_patch_tool_type=null;model.tool_mode='code_mode_only';}
const sourceCatalog=path.join(base,'original-catalog.json'),limitedCatalog=path.join(base,'text-catalog.json');fs.writeFileSync(sourceCatalog,JSON.stringify(catalog));fs.writeFileSync(limitedCatalog,JSON.stringify(restrictedCatalog));
const cliHome=path.join(base,'cli-home'),appWork=path.join(base,'app-work'),emptyWork=path.join(base,'empty-work');for(const dir of [cliHome,appWork,emptyWork])fs.mkdirSync(dir);
fs.writeFileSync(path.join(appWork,'.env'),'STUDY_TEST_PRIVATE=FAKE_FILE_SENTINEL_131\n');
const schema=path.join(base,'output.schema.json');fs.writeFileSync(schema,JSON.stringify({type:'object',properties:{reply:{type:'string'},anchors:{type:'array',items:{type:'string'}}},required:['reply','anchors'],additionalProperties:false}));
const observations=[];let active;
function names(tools,prefix=''){return tools.flatMap(tool=>tool.type==='namespace'?names(tool.tools||[],prefix+tool.name+'.'):[prefix+(tool.name||tool.type)]);}
const server=http.createServer(async(req,res)=>{
 let raw='';for await(const chunk of req)raw+=chunk;
 if(!req.url.endsWith('/responses')){res.writeHead(404);res.end();return;}
 const body=JSON.parse(raw);const observation={mode:active.mode,model:body.model,tools:names(body.tools||[]),fileSentinelSeen:raw.includes('FAKE_FILE_SENTINEL_131'),environmentSentinelSeen:raw.includes('FAKE_ENV_SENTINEL_131')};observations.push(observation);
 const text=JSON.stringify({reply:'本机合成结构验证。',anchors:[]}),message={id:'msg_fixture',type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text,annotations:[]}]};
 const response={id:'resp_fixture',object:'response',created_at:Math.floor(Date.now()/1000),model:body.model,status:'completed',output:[message],usage:{input_tokens:10,output_tokens:10,total_tokens:20}};
 res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache'});
 const send=(name,event)=>res.write('event: '+name+'\ndata: '+JSON.stringify({type:name,...event})+'\n\n');
 send('response.created',{response:{...response,status:'in_progress',output:[]}});
 send('response.output_item.added',{output_index:0,item:{...message,status:'in_progress',content:[]}});
 send('response.content_part.added',{item_id:message.id,output_index:0,content_index:0,part:{type:'output_text',text:'',annotations:[]}});
 send('response.output_text.delta',{item_id:message.id,output_index:0,content_index:0,delta:text});
 send('response.output_text.done',{item_id:message.id,output_index:0,content_index:0,text});
 send('response.output_item.done',{output_index:0,item:message});send('response.completed',{response});res.end();
});
const commonDisabled=['view_image','apps','plugins','remote_plugin','hooks','memories','shell_snapshot','browser_use','browser_use_external','browser_use_full_cdp_access','in_app_browser','computer_use','image_generation','multi_agent','goals','code_mode_host','skill_mcp_dependency_install','tool_suggest'];
function run(mode,model,port){return new Promise((resolve,reject)=>{
 active={mode,model};const work=mode==='restricted'?emptyWork:appWork,args=['exec','--ephemeral','--json','--skip-git-repo-check','--sandbox','read-only','--color','never','-C',work,'-m',model,'--output-schema',schema,
 '-c','model_provider="fixture"','-c','model_catalog_json="'+(mode==='restricted'?limitedCatalog:sourceCatalog).replaceAll('\\','/')+'"',
 '-c','model_providers.fixture.name="Local fixture"','-c','model_providers.fixture.base_url="http://127.0.0.1:'+port+'/v1"','-c','model_providers.fixture.wire_api="responses"','-c','model_providers.fixture.env_key="STUDY_TEST_CLI_KEY"','-c','model_providers.fixture.requires_openai_auth=false',
 '-c','web_search="disabled"','-c','tools.view_image=false','-c','shell_environment_policy.inherit="none"'];
 for(const name of commonDisabled)args.push('-c','features.'+name+'=false');if(mode==='restricted')args.push('-c','features.shell_tool=false');args.push('-');
 const env={};for(const key of ['PATH','Path','SystemRoot','WINDIR','COMSPEC','PATHEXT','TEMP','TMP','APPDATA','LOCALAPPDATA','USERPROFILE','HOMEDRIVE','HOMEPATH'])if(process.env[key]!==undefined)env[key]=process.env[key];
 Object.assign(env,{CODEX_HOME:cliHome,STUDY_TEST_CLI_KEY:'synthetic-local-only',STUDY_TEST_INHERITED:mode==='baseline'?'FAKE_ENV_SENTINEL_131':''});
 const child=spawn(binary,args,{cwd:work,env,windowsHide:true,stdio:['pipe','pipe','pipe']});let stdout='',stderr='';
 const timer=setTimeout(()=>{child.kill();reject(Error('Local CLI probe timed out'));},25000);child.stdout.on('data',chunk=>stdout+=chunk);child.stderr.on('data',chunk=>stderr+=chunk);
 child.on('error',error=>{clearTimeout(timer);reject(error);});child.on('close',code=>{clearTimeout(timer);fs.writeFileSync(path.join(base,mode+'-'+model+'.stdout'),stdout);fs.writeFileSync(path.join(base,mode+'-'+model+'.stderr'),stderr);if(code||!stdout.includes('agent_message'))reject(Error('Local CLI '+mode+' failed('+code+'): '+stderr.slice(-1200)));else resolve();});
 child.stdin.end('只返回完整JSON。reply用一句中文确认收到，anchors为空数组。不要调用工具。');
});}
(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const port=server.address().port;try{
 await run('baseline','deepseek-v4-flash',port);for(const model of restrictedCatalog.models)await run('restricted',model.slug,port);
 fs.writeFileSync(path.join(base,'observations.json'),JSON.stringify({scope:'Installed CLI against a synthetic local provider; no real credentials, actual model or tool execution.',binaryVersion:'0.144.1',observations},null,2)+'\n');
 fs.writeFileSync('data/qa/cli-text-tools-probe-latest.json',JSON.stringify({folder:path.relative(root,base).replaceAll('\\','/'),observations},null,2)+'\n');
 console.log(JSON.stringify({folder:path.relative(root,base),observations},null,2));
 }finally{await new Promise(resolve=>server.close(resolve));}})().catch(error=>{console.error(error.message);process.exitCode=1;});
