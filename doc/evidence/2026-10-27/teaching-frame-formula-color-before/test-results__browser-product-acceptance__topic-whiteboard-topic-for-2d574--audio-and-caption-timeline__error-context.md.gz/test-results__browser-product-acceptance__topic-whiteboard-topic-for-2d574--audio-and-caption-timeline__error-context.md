# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> topic-formula: actual shared image and fraction/root/alignment vector video decodes with full audio and caption timeline
- Location: tests\e2e\topic-whiteboard.spec.ts:119:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 100
Received:   0
```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - complementary "学习工作台导航" [ref=f3e4]:
      - link "StudyAgent" [ref=f3e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f3e9]:
        - link "Home" [ref=f3e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f3e13]: 首页
        - link "Courses" [ref=f3e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f3e17]: 课程
        - link "Calendar" [ref=f3e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f3e21]: 学习动态
        - link "History" [ref=f3e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f3e25]: 历史
        - link "Materials" [ref=f3e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f3e29]: 资料
        - link "AI Whiteboards" [ref=f3e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f3e33]: AI白板
      - generic [ref=f3e34]:
        - heading "继续学习" [level=2] [ref=f3e35]
        - link "讲座社会学想象力 社会学概论" [ref=f3e36] [cursor=pointer]:
          - /url: /studio/classroom
          - text: 讲座社会学想象力
          - generic [ref=f3e37]: 社会学概论
      - generic [ref=f3e38]:
        - heading "近期活动" [level=2] [ref=f3e39]
        - paragraph [ref=f3e40]: 开始学习后，活动会出现在这里。
      - link "返回学习首页 →" [ref=f3e42] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f3e43]:
      - generic [ref=f3e44]:
        - generic [ref=f3e45]:
          - text: WHITEBOARD STUDIO
          - heading "从一个问题开始，讲清每一步。" [level=1] [ref=f3e46]
          - paragraph [ref=f3e47]: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
        - link "返回学习工作台 →" [ref=f3e48] [cursor=pointer]:
          - /url: /studio
      - generic [ref=f3e49]:
        - complementary [ref=f3e50]:
          - generic [ref=f3e51]:
            - text: NEW BOARD
            - heading "这次想弄懂什么？" [level=2] [ref=f3e52]
          - generic [ref=f3e53]:
            - text: 学习对象
            - combobox "白板学习对象" [ref=f3e54]:
              - option "我自己 · 成人主题" [selected]
          - region "新建AI白板" [ref=f3e55]:
            - group [ref=f3e56]:
              - generic [ref=f3e57]:
                - text: 讲解主题
                - textbox "讲解主题" [ref=f3e58]:
                  - /placeholder: 例如：为什么先统一单位，才能比较和合并？
                  - text: 用匿名观察解释条件与推断
              - generic [ref=f3e59]:
                - text: 希望弄懂什么
                - textbox "希望弄懂什么" [ref=f3e60]:
                  - /placeholder: 想理解的区别、步骤，或一个具体困惑
                  - text: 保留完整条件，说明观察、推断和替代解释的区别。
              - generic [ref=f3e62]:
                - generic [ref=f3e63]: 模型
                - combobox "选择大模型" [ref=f3e64] [cursor=pointer]:
                  - option "Auto · 当前默认模型"
                  - option "GPT-6.1 Sol"
                  - option "GPT-6 Astra"
                  - option "GPT-6 Luna"
                  - option "Grok-4.7"
                  - option "GLM-5.3 Flash"
                  - option "DeepSeek V4.1 Flash · 默认" [selected]
                  - option "Claude Opus 5.5"
                  - option "Claude Sonnet 5"
                  - option "GPT-6 Sol"
                  - option "GPT-5.6 Sol"
                  - option "GPT-5.6 Terra"
                  - option "GPT-5.6 Luna"
                  - option "GPT-5.5"
                  - option "Grok-4.6"
                  - option "GLM-5.2"
                  - option "GLM-5.3"
                  - option "Claude Opus 5"
                  - option "Claude Fable 5.1"
                  - option "MiMo V2.6 Pro"
                  - option "MiMo V2.6 Flash"
                  - option "MiMo V2.6 Pro Ultraspeed"
                  - option "Qwen3.8 Max"
            - status [ref=f3e65]: 已恢复此标签页的原主题与模型选择。
            - generic [ref=f3e66]:
              - button "预检主题与范围" [ref=f3e67] [cursor=pointer]
              - button "生成教学稿" [disabled] [ref=f3e68]
            - button "下载原主题与请求" [ref=f3e69] [cursor=pointer]
            - group [ref=f3e70]:
              - generic "查看其他本机主题" [ref=f3e71] [cursor=pointer]
        - region "白板工作区" [ref=f3e72]:
          - generic [ref=f3e73]:
            - text: SAVED BOARD
            - heading "把条件讲清楚" [level=2] [ref=f3e74]
            - paragraph [ref=f3e75]: AI生成 · 待内容核对 · Browser fixture · not a real model
            - button "继续阅读" [ref=f3e76] [cursor=pointer]
            - button "查看自己的原稿" [ref=f3e77] [cursor=pointer]
          - dialog "白板视频" [ref=f3e78]:
            - generic:
              - button "关闭白板" [ref=f3e79] [cursor=pointer]: ×
              - heading "把条件讲清楚" [level=2] [ref=f3e81]
            - navigation "白板视图" [ref=f3e82]:
              - generic [ref=f3e83]:
                - button "缩小白板" [ref=f3e84] [cursor=pointer]: −
                - button "重置白板视图" [ref=f3e85] [cursor=pointer]: 100%
                - button "放大白板" [ref=f3e86] [cursor=pointer]: +
            - generic [ref=f3e87]:
              - main [ref=f3e88]:
                - generic [ref=f3e89]:
                  - generic "公式示例 1" [ref=f3e90]
                  - figure "AI参考图，标签和关系待核对。" [ref=f3e91]:
                    - button "放大参考图：公式示例 1" [ref=f3e92]:
                      - generic [aria-hidden] [ref=f3e93]: ↗
                - paragraph [ref=f3e94]: "[whiteboard-fixture] 核对完整表达。"
                - generic [ref=f3e95]:
                  - generic [ref=f3e96]: 播放进度（实际音轨）
                  - slider "播放进度（实际音轨）" [ref=f3e97] [cursor=pointer]: "0"
                - generic [ref=f3e98]:
                  - button "上一句" [disabled] [ref=f3e99]: ←
                  - button "播放" [ref=f3e100] [cursor=pointer]: ▶
                  - button "下一句" [ref=f3e101] [cursor=pointer]: →
                  - generic [ref=f3e102]: 1 / 6 句
                  - combobox "阅读方式" [ref=f3e103] [cursor=pointer]:
                    - option "文字阅读（估计时长）"
                    - option "云语音逐句播放" [selected]
                  - combobox "旁白音色" [ref=f3e104] [cursor=pointer]:
                    - option "合成音轨 A" [selected]
                  - combobox "播放速度" [ref=f3e105] [cursor=pointer]:
                    - option "0.75×"
                    - option "1×" [selected]
                    - option "1.25×"
                  - generic [ref=f3e106]:
                    - generic [ref=f3e107]: 板书字体
                    - combobox "板书字体" [ref=f3e108] [cursor=pointer]:
                      - option "手写板书" [selected]
                      - option "标准板书"
                  - generic [ref=f3e109]:
                    - checkbox "点阵" [checked] [ref=f3e110]
                    - text: 点阵
                  - button "导出视频" [ref=f3e111] [cursor=pointer]
                  - button "导出字幕" [ref=f3e112] [cursor=pointer]
                - status [ref=f3e113]: 带云语音的 WebM 已生成；导出字幕将使用相同音轨时间表。
                - generic [ref=f3e114]:
                  - button "01 公式示例 1" [ref=f3e115] [cursor=pointer]:
                    - generic [ref=f3e116]: "01"
                    - text: 公式示例 1
                  - button "02 公式示例 2" [ref=f3e117] [cursor=pointer]:
                    - generic [ref=f3e118]: "02"
                    - text: 公式示例 2
                  - button "03 公式示例 3" [ref=f3e119] [cursor=pointer]:
                    - generic [ref=f3e120]: "03"
                    - text: 公式示例 3
              - complementary "完整讲稿与要点" [ref=f3e121]:
                - heading "逐句讲稿" [level=3] [ref=f3e122]
                - paragraph [ref=f3e123]: 点击一句定位。观看与续播不计作掌握。
                - list [ref=f3e124]:
                  - listitem [ref=f3e125]:
                    - button "[whiteboard-fixture] 核对完整表达。" [ref=f3e126] [cursor=pointer]
                  - listitem [ref=f3e127]:
                    - button "[whiteboard-fixture] 保留最后一项。" [ref=f3e128] [cursor=pointer]
                  - listitem [ref=f3e129]:
                    - button "[whiteboard-fixture] 核对完整表达。" [ref=f3e130] [cursor=pointer]
                  - listitem [ref=f3e131]:
                    - button "[whiteboard-fixture] 保留最后一项。" [ref=f3e132] [cursor=pointer]
                  - listitem [ref=f3e133]:
                    - button "[whiteboard-fixture] 核对完整表达。" [ref=f3e134] [cursor=pointer]
                  - listitem [ref=f3e135]:
                    - button "[whiteboard-fixture] 保留最后一项。" [ref=f3e136] [cursor=pointer]
                - heading "完整笔记与来源" [level=3] [ref=f3e137]
                - group [ref=f3e138]:
                  - generic "公式示例 1" [ref=f3e139] [cursor=pointer]
                  - paragraph [ref=f3e140]: 完整说明首行。完整说明尾行。
                  - list [ref=f3e141]:
                    - listitem [ref=f3e142]: 核对完整表达
                    - listitem [ref=f3e143]: 保留最后一项
                  - figure "分式、根号与对齐关系需要完整保留，最后一项不能省略。" [ref=f3e144]:
                    - region "完整公式，可横向滚动" [ref=f3e146]
                    - math [ref=f3e175]:
                      - generic [ref=f3e177]:
                        - generic [ref=f3e178]:
                          - generic [ref=f3e179]: "1"
                          - generic [ref=f3e180]: "2"
                        - generic [ref=f3e181]: +
                        - generic [ref=f3e183]:
                          - generic [ref=f3e184]:
                            - generic [ref=f3e185]: x
                            - generic [ref=f3e186]: "2"
                          - generic [ref=f3e187]: +
                          - generic [ref=f3e188]: "1"
                    - group [ref=f3e189]:
                      - generic "可复制的公式原文" [ref=f3e190] [cursor=pointer]
                  - figure "AI参考图，标签和关系待核对。" [ref=f3e191]:
                    - button "放大参考图：公式示例 1" [ref=f3e192]:
                      - img "公式示例 1，图中概念和关系待核对。" [ref=f3e193]
                      - generic [aria-hidden] [ref=f3e194]: ↗
                - group [ref=f3e196]:
                  - generic "公式示例 2" [ref=f3e197] [cursor=pointer]
                - group [ref=f3e198]:
                  - generic "公式示例 3" [ref=f3e199] [cursor=pointer]
                - paragraph [ref=f3e200]: AI生成 · 待内容核对 · Browser fixture · not a real model
                - button "下载续播位置" [ref=f3e201] [cursor=pointer]
        - complementary "白板与候选历史" [ref=f3e202]:
          - generic [ref=f3e203]:
            - heading "我的白板" [level=2] [ref=f3e204]
            - button "＋ 新白板" [ref=f3e205] [cursor=pointer]
          - generic [ref=f3e206]:
            - button "教学草稿" [pressed] [ref=f3e207] [cursor=pointer]
            - button "已保存" [ref=f3e208] [cursor=pointer]
          - generic [ref=f3e209]:
            - generic [ref=f3e210]: 搜索我的白板
            - textbox "搜索我的白板" [ref=f3e211]:
              - /placeholder: 搜索主题或标题
          - button "已保存白板 · 本人主题 把条件讲清楚 Browser fixture · not a real model" [ref=f3e212] [cursor=pointer]:
            - generic [ref=f3e213]: 已保存白板 · 本人主题
            - generic [ref=f3e214]: 把条件讲清楚
            - generic [ref=f3e215]: Browser fixture · not a real model
          - generic [ref=f3e216]:
            - button "上一页" [disabled] [ref=f3e217]
            - generic [ref=f3e218]: 1 / 1
            - button "下一页" [disabled] [ref=f3e219]
```

# Test source

```ts
  50  |   await pane.getByLabel('希望图片说明什么').fill(requirements);
  51  |   await pane.getByRole('button', { name: '预检配图范围', exact: true }).click();
  52  |   await expect(pane.getByText('本次完整教学范围与配图要求', { exact: true })).toBeVisible();
  53  |   await expect(pane.getByRole('button', { name: '生成参考图', exact: true })).toBeEnabled();
  54  |   await pane.getByRole('button', { name: '生成参考图', exact: true }).click(); return pane;
  55  | }
  56  | 
  57  | test('continuity: a confirmed adult topic also overlaps its adjacent WAV and preserves its frozen sentence identity', async ({ page }) => {
  58  |   const timing = await installNarrationTiming(page); await fixture(page); await generate(page); await ready(page);
  59  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click();
  60  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  61  |   const player = page.getByRole('dialog', { name: '白板视频' });
  62  |   try {
  63  |     await player.getByRole('button', { name: '播放', exact: true }).click();
  64  |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'playing'), { timeout: 10000 }).toBe(true);
  65  |     await player.getByRole('button', { name: '暂停', exact: true }).click(); const result = await timing.save('adult-topic-transfer');
  66  |     const ended = result.audio.find(row => row.index === 0 && row.event === 'ended')!, next = result.audio.find(row => row.index === 1 && row.event === 'playing')!;
  67  |     expect(result.requests[1].startedAt).toBeLessThan(ended.at - 100);
  68  |     expect(next.at - ended.at).toBeLessThan(result.delayMs * .75); expect(next.currentTime).toBeLessThan(.15);
  69  |     expect(result.requests.filter(row => row.unitId === result.requests[1].unitId)).toHaveLength(1);
  70  |     await expect(player.locator('.wb-current-sentence')).toContainText('保留未知条件');
  71  |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  72  | });
  73  | 
  74  | async function formulaBoard(page: Page, expressions: string[], withFigure = false) {
  75  |   const f = await fixture(page); await generate(page); await ready(page);
  76  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  77  |   const content = { ...view.content, scenes: expressions.map((latex, index) => ({ ...view.content.scenes[index % 3], title: '公式示例 ' + (index + 1),
  78  |     narration: '[whiteboard-fixture] 核对完整表达。 [whiteboard-fixture] 保留最后一项。',
  79  |     bullets: ['核对完整表达', '保留最后一项'], figure: undefined, exhibit: { kind: 'formula', latex, explanation: '分式、根号与对齐关系需要完整保留，最后一项不能省略。' } })) };
  80  |   const edited = await f.call(base + '/drafts/' + id + '/content', { expectedRevision: view.revision, contentFingerprint: view.contentFingerprint, content, requestKey: randomUUID() }, 'PATCH');
  81  |   let current = edited;
  82  |   if (withFigure) {
  83  |     await page.reload(); await ready(page);
  84  |     await page.getByRole('button', { name: '采用服务器稿', exact: true }).click();
  85  |     await expect(page.getByRole('region', { name: '白板配图工作区' }).getByRole('button', { name: '预检配图范围', exact: true })).toBeEnabled();
  86  |     const pane = await figure(page); await pane.getByRole('checkbox', { name: '我已阅读图片，并核对本次要使用的标签和关系。' }).check();
  87  |     await pane.getByRole('button', { name: '选入当前完整稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  88  |     await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  89  |     current = await f.call(base + '/drafts/' + id, undefined, 'GET');
  90  |   }
  91  |   await f.call(base + '/drafts/' + id + '/confirm', { expectedRevision: current.revision, contentFingerprint: current.contentFingerprint,
  92  |     acknowledgeAiGeneratedContent: true, acknowledgeUnreviewedChanges: true, requestKey: randomUUID() });
  93  |   await page.reload(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  94  |   const player = page.getByRole('dialog', { name: '白板视频' }); await expect(player).toBeVisible();
  95  |   return { ...f, player };
  96  | }
  97  | 
  98  | test('topic-formula: complete vector fractions, aligned roots and Unicode fit narrow notes and preserve copyable source and safe fallback', async ({ page }) => {
  99  |   const expressions = ['\\frac{1}{2}+\\sqrt{x^2+1}', '\\begin{aligned}a&=b+c\\\\d&=\\frac{e}{f}\\end{aligned}', '\\frac{1}{2}\\text{个整体}', '\\unknownprivate{最后一项}', 'a+'.repeat(280) + 'z'];
  100 |   const { player } = await formulaBoard(page, expressions);
  101 |   for (const width of [390, 768, 1440]) {
  102 |     await page.setViewportSize({ width, height: 1000 });
  103 |     for (const [index, latex] of expressions.entries()) {
  104 |       const detail = player.locator('.wb-reading-notes > details').nth(index);
  105 |       if (!(await detail.getAttribute('open') !== null)) await detail.locator(':scope > summary').click();
  106 |       const formula = detail.locator('.wb-complete-formula');
  107 |       if (index !== 3) { await expect(formula.locator('.wb-formula-vector svg')).toHaveCount(1); await expect(formula.locator('math')).toHaveCount(1); }
  108 |       else await expect(formula.getByRole('status')).toContainText('分页保留原式');
  109 |       const raw = formula.locator('details'); if (await raw.getAttribute('open') === null) await raw.locator('summary').click();
  110 |       expect(await raw.locator('pre').textContent()).toBe(latex);
  111 |       expect(await formula.evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
  112 |     }
  113 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  114 |     await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'topic-formula-reader-' + width + '.png'), fullPage: false });
  115 |   }
  116 |   expect(await page.locator('[href^="javascript:"],script[src*="mathjax"],image[href^="http"]').count()).toBe(0);
  117 | });
  118 | 
  119 | test('topic-formula: actual shared image and fraction/root/alignment vector video decodes with full audio and caption timeline', async ({ page }) => {
  120 |   await page.addInitScript(() => {
  121 |     const original = CanvasRenderingContext2D.prototype.drawImage;
  122 |     (window as any).formulaVideoCrops = [];
  123 |     CanvasRenderingContext2D.prototype.drawImage = function (...args: any[]) {
  124 |       const image = args[0];
  125 |       if (!this.canvas.isConnected && args.length === 9 && image instanceof HTMLImageElement) {
  126 |         const transform = this.getTransform();
  127 |         (window as any).formulaVideoCrops.push({ naturalWidth: image.naturalWidth, sourceRight: args[1] + args[3],
  128 |           scale: args[7] / args[3], left: transform.a * args[5] + transform.e, top: transform.d * args[6] + transform.f,
  129 |           right: transform.a * (args[5] + args[7]) + transform.e, bottom: transform.d * (args[6] + args[8]) + transform.f });
  130 |       }
  131 |       return original.apply(this, args as any);
  132 |     };
  133 |   });
  134 |   const { player } = await formulaBoard(page, ['\\frac{1}{2}+\\sqrt{x^2+1}', '\\begin{aligned}a&=b+c\\\\d&=\\frac{e}{f}\\end{aligned}', 'a+'.repeat(280) + 'z'], true);
  135 |   await expect(player.locator('.sa-whiteboard-notice')).not.toContainText('无法解码');
  136 |   await expect(player.locator('.wb-formula-vector svg').first()).toBeVisible();
  137 |   const download = page.waitForEvent('download', { timeout: 30000 }); await player.getByRole('button', { name: '导出视频', exact: true }).click();
  138 |   const video = (await (await download).path())!, directory = browserEvidence('topic-whiteboard'); copyFileSync(video, join(directory, 'topic-formula-video.webm'));
  139 |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', video], { windowsHide: true, encoding: 'utf8' }));
  140 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true); expect(probe.streams.some((stream: any) => stream.codec_type === 'video')).toBe(true);
  141 |   const receipts: unknown[] = [];
  142 |   for (const [name, time, left] of [['first', .2, 72], ['aligned', 4.2, 672], ['last', 11.9, 72]] as const) {
  143 |     const frame = spawnSync(process.env.STUDY_FFMPEG ?? 'ffmpeg', ['-v', 'error', '-ss', String(time), '-i', video, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'], { windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
  144 |     expect(frame.status).toBe(0); const decoded = await sharp(frame.stdout).removeAlpha().raw().toBuffer({ resolveWithObject: true }); let ink = 0;
  145 |     // Frozen scenes occupy alternating columns in the cumulative board. Count
  146 |     // the vector's distinctive green ink, excluding black notes and subtitles.
  147 |     for (let y = 0; y < 610; y++) for (let x = left; x < left + 536; x++) { const offset = (y * 1280 + x) * 3;
  148 |       const [r,g,b] = decoded.data.subarray(offset, offset + 3);
  149 |       if (r < 140 && g < 160 && g > r + 5 && g > b + 5) ink++; }
> 150 |     expect(ink).toBeGreaterThan(100); receipts.push({ name, time, ink }); writeFileSync(join(directory, 'topic-formula-video-' + name + '.png'), frame.stdout);
      |                 ^ Error: expect(received).toBeGreaterThan(expected)
  151 |   }
  152 |   writeFileSync(join(directory, 'topic-formula-video-probe.json'), JSON.stringify({ probe, frames: receipts }, null, 2) + '\n');
  153 |   const crops = await page.evaluate(() => (window as any).formulaVideoCrops as Array<{ naturalWidth: number; sourceRight: number; scale: number; left: number; top: number; right: number; bottom: number }>);
  154 |   const long = crops.filter(crop => crop.naturalWidth > 1500); expect(long.length).toBeGreaterThan(0);
  155 |   expect(Math.min(...long.map(crop => crop.scale))).toBeGreaterThanOrEqual(.79);
  156 |   expect(long.some(crop => crop.sourceRight >= crop.naturalWidth - 1 && crop.left >= 0 && crop.right <= 1280 && crop.top >= 0 && crop.bottom <= 610)).toBe(true);
  157 |   writeFileSync(join(directory, 'topic-formula-readable-video-crops.json'), JSON.stringify({ minimumScale: Math.min(...long.map(crop => crop.scale)), crops }, null, 2) + '\n');
  158 |   const captions = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); const srt = readFileSync((await (await captions).path())!, 'utf8');
  159 |   expect(srt).toContain('00:00:00,000 --> 00:00:02,000'); expect(srt).toContain('00:00:10,000 --> 00:00:12,000'); expect(srt).toContain('保留最后一项');
  160 |   writeFileSync(join(directory, 'topic-formula-video.srt'), srt);
  161 |   const later: string[] = []; page.on('download', item => later.push(item.suggestedFilename()));
  162 |   await player.getByRole('button', { name: '导出视频', exact: true }).click(); await player.getByRole('button', { name: '取消导出', exact: true }).click();
  163 |   await expect(player.locator('.sa-whiteboard-notice')).toContainText('没有下载半成品'); expect(later).toEqual([]);
  164 |   const retained = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); expect(readFileSync((await (await retained).path())!, 'utf8')).toBe(srt);
  165 | });
  166 | 
  167 | test('login forms cannot submit before their client handlers are ready', async ({ browser }) => {
  168 |   const context = await browser.newContext({ javaScriptEnabled: false, baseURL: test.info().project.use.baseURL });
  169 |   try {
  170 |     const page = await context.newPage();
  171 |     for (const path of ['/parent/login', '/student/login']) {
  172 |       await page.goto(path);
  173 |       for (const input of await page.locator('form input, form button').all()) await expect(input).toBeDisabled();
  174 |     }
  175 |   } finally { await context.close(); }
  176 | });
  177 | 
  178 | test('topic-figure: restores a lost original image prepare without duplicate writes, edits its PNG and publishes an image with pause/read/resume', async ({ page }) => {
  179 |   const f = await fixture(page); await generate(page); await ready(page); const id = new URL(page.url()).searchParams.get('draft')!;
  180 |   let dropped = true, writes = 0;
  181 |   await page.route('**/api/learning/studio/topic-whiteboard-visuals', async route => {
  182 |     if (route.request().method() !== 'POST') return route.continue(); writes++;
  183 |     if (dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  184 |   });
  185 |   await figure(page); const pane = page.getByRole('region', { name: '白板配图工作区' });
  186 |   await expect(pane.getByRole('button', { name: '恢复原配图请求', exact: true })).toBeEnabled(); await page.reload(); await ready(page);
  187 |   await pane.getByRole('button', { name: '恢复原配图请求', exact: true }).click();
  188 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible(); expect(writes).toBe(1);
  189 |   expect((await f.call(figureBase + '?draftId=' + id + '&sceneIndex=0', undefined, 'GET')).total).toBe(1);
  190 |   await pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).click();
  191 |   await expect(page.locator('.cl-figure-reader-sheet img')).toBeVisible(); await page.keyboard.press('Escape');
  192 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeFocused();
  193 |   await pane.getByRole('button', { name: '以原图继续修订', exact: true }).click();
  194 |   await pane.getByLabel('具体修改').fill('只去掉顶端标题，保留圆、交集和其他标签。');
  195 |   await pane.getByRole('button', { name: '预检配图范围', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成修订图片', exact: true })).toBeEnabled();
  196 |   await pane.getByRole('button', { name: '生成修订图片', exact: true }).click();
  197 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible();
  198 |   await pane.getByRole('textbox', { name: '图片替代说明', exact: true }).fill('两个概念圆及其交集，说明观察和条件的关系。');
  199 |   await pane.getByRole('textbox', { name: '图注', exact: true }).fill('比较观察与条件，保留这条完整图注。');
  200 |   await expect(pane.locator('.tw-figure-list .tw-figure-thumbnail img').first()).toBeVisible();
  201 |   await pane.getByRole('button', { name: '加入对照', exact: true }).last().click(); await expect(pane.getByRole('region', { name: '两个图片候选对照' })).toBeVisible();
  202 |   await expect(pane.getByRole('region', { name: '两个图片候选对照' }).locator('img').first()).toBeVisible();
  203 |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.figures.')).map(key => JSON.parse(localStorage.getItem(key)!).caption))).toContain('比较观察与条件，保留这条完整图注。');
  204 |   await page.reload(); await ready(page); await expect(pane.getByRole('textbox', { name: '图片替代说明', exact: true })).toHaveValue('两个概念圆及其交集，说明观察和条件的关系。');
  205 |   await expect(pane.getByRole('textbox', { name: '图注', exact: true })).toHaveValue('比较观察与条件，保留这条完整图注。');
  206 |   await pane.getByRole('checkbox', { name: '我已阅读图片，并核对本次要使用的标签和关系。' }).check();
  207 |   await pane.getByRole('button', { name: '选入当前完整稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  208 |   await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  209 |   const draft = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(draft.content.scenes[0].figure).toBeTruthy();
  210 |   const candidate = await f.call(figureBase + '/' + draft.content.scenes[0].figure.visualId, undefined, 'GET'); expect(candidate.operation).toBe('edit'); expect(candidate.parentVisualId).toBeTruthy();
  211 |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  212 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  213 |   const player = page.getByRole('dialog', { name: '白板视频' }); await expect(player).toBeVisible();
  214 |   await expect(player.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).first()).toBeVisible();
  215 |   await player.getByRole('button', { name: '播放', exact: true }).click();
  216 |   await player.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).first().click();
  217 |   const unit = await page.locator('.wb-current-sentence').getAttribute('data-unit-id');
  218 |   await expect(page.locator('.cl-figure-reader-sheet')).toBeVisible(); await expect(player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  219 |   await page.keyboard.press('Escape'); await expect(player).toBeVisible(); await expect(page.locator('.cl-figure-reader-sheet')).toHaveCount(0);
  220 |   await expect(page.locator('.wb-current-sentence')).toHaveAttribute('data-unit-id', unit!);
  221 |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'topic-figure-saved-player.png'), fullPage: false });
  222 |   const board = await f.call(base + '/' + (await f.call(base + '/drafts/' + id, undefined, 'GET')).whiteboardId, undefined, 'GET');
  223 |   expect(JSON.stringify(board)).not.toContain(candidate.id); expect(board.scenes[0].figure.sha256).toBe(candidate.sha256);
  224 |   const downloaded = page.waitForEvent('download', { timeout: 30000 }); await player.getByRole('button', { name: '导出视频', exact: true }).click();
  225 |   const video = await downloaded, videoPath = (await video.path())!, directory = browserEvidence('topic-whiteboard'); copyFileSync(videoPath, join(directory, 'topic-figure-video.webm'));
  226 |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', videoPath], { encoding: 'utf8', windowsHide: true }));
  227 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true); expect(probe.streams.some((stream: any) => stream.codec_type === 'video')).toBe(true);
  228 |   const frame = spawnSync(process.env.STUDY_FFMPEG ?? 'ffmpeg', ['-v', 'error', '-ss', '0.2', '-i', videoPath, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'], { windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
  229 |   expect(frame.status).toBe(0); const decoded = await sharp(frame.stdout).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  230 |   expect([decoded.info.width, decoded.info.height, decoded.info.channels]).toEqual([1280, 720, 3]);
  231 |   let blue = 0, warm = 0;
  232 |   for (let y = 206; y < 566; y++) for (let x = 88; x < 698; x++) {
  233 |     const offset = (y * 1280 + x) * 3, r = decoded.data[offset], g = decoded.data[offset + 1], b = decoded.data[offset + 2];
  234 |     if (b > r + 5 && b > g) blue++; if (r > b + 10 && g > b + 5) warm++;
  235 |   }
  236 |   expect(blue).toBeGreaterThan(9000); expect(warm).toBeGreaterThan(9000);
  237 |   writeFileSync(join(directory, 'topic-figure-video-first-frame.png'), frame.stdout); writeFileSync(join(directory, 'topic-figure-video-probe.json'), JSON.stringify({ probe, decodedImageRegion: { blue, warm } }, null, 2) + '\n');
  238 |   const captions = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); const srt = readFileSync((await (await captions).path())!, 'utf8');
  239 |   expect(srt).toContain('00:00:00,000 --> 00:00:02,000'); expect(srt).toContain('00:00:10,000 --> 00:00:12,000'); writeFileSync(join(directory, 'topic-figure-video.srt'), srt);
  240 |   const later: string[] = []; page.on('download', value => later.push(value.suggestedFilename()));
  241 |   await page.route('**/api/learning/studio/topic-whiteboards/*/figures/*/image', route => route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.from('Changed frozen image fixture') }));
  242 |   await player.getByRole('button', { name: '导出视频', exact: true }).click(); await expect(player.locator('.sa-whiteboard-notice')).toContainText('字节与已保存版本不一致'); expect(later).toEqual([]);
  243 |   const retained = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); expect(readFileSync((await (await retained).path())!, 'utf8')).toBe(srt);
  244 | });
  245 | 
  246 | test('topic-figure: uncached complete image commands block leaving until their exact complete download', async ({ page }) => {
  247 |   await fixture(page); await generate(page); await ready(page);
  248 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  249 |     if (key.startsWith('studyagent.topic-whiteboard.figures.')) throw new DOMException('Synthetic unavailable image storage', 'QuotaExceededError'); return original.call(this, key, value);
  250 |   }; });
```