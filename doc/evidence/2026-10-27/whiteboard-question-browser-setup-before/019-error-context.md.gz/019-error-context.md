# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-questions.spec.ts >> whiteboard questions: a lost create response is recovered after reload without a second write
- Location: tests\e2e\whiteboard-questions.spec.ts:77:5

# Error details

```
Error: /qa/whiteboard-media 400

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { createHash, randomUUID } from 'node:crypto';
  3   | import { readFileSync, writeFileSync } from 'node:fs';
  4   | import { join } from 'node:path';
  5   | import { browserEvidence } from './evidence';
  6   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4172') + '/api';
  7   | test.afterEach(async ({ page }) => page.unrouteAll({ behavior: 'wait' }));
  8   | async function fixture(page: Page) {
  9   |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  10  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  11  |   const principal = 'question-' + randomUUID() + '@local.test', credential = 'Synthetic-questions-only-20261027';
  12  |   async function call(path: string, body: unknown, token?: string, method = 'POST') {
  13  |     const response = await fetch(api + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address,
  14  |       ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: JSON.stringify(body) });
> 15  |     expect(response.ok, path + ' ' + response.status).toBe(true); return (await response.json()).data;
      |                                                       ^ Error: /qa/whiteboard-media 400
  16  |   }
  17  |   const actor = await call('/auth/register', { principal, credential }), child = (await call('/students', { nickname: '匿名插问验证', grade: 5, preferredSessionMinutes: 15,
  18  |     defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token)).profile.id;
  19  |   await call('/students/' + child + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成范围',
  20  |     learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, actor.token, 'PUT');
  21  |   const input = { studentId: child, subject: 'math', prompt: '解释异分母分数加法', atomId: 'core:math:fractionadd' };
  22  |   const preview = await call('/learning/studio/whiteboards/preview', input, actor.token), saved = await call('/learning/studio/whiteboards', { ...input, fingerprint: preview.fingerprint, requestKey: randomUUID() }, actor.token);
  23  |   const board = await call('/qa/whiteboard-media', { boardId: saved.id }, actor.token);
  24  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  25  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  26  |   const href = '/studio?student=' + child + '&subject=math&whiteboard=' + board.id; await page.goto(href);
  27  |   const player = page.getByRole('dialog', { name: '白板视频', exact: true }); await expect(player).toHaveAttribute('data-original-font-status', 'ready');
  28  |   const region = page.getByRole('region', { name: '原句提问', exact: true }), current = player.locator('.wb-current-sentence');
  29  |   if ((await page.viewportSize())!.width <= 900) await player.getByRole('button', { name: '讲稿与笔记', exact: true }).click();
  30  |   const inputBox = region.getByRole('textbox', { name: '向老师提问', exact: true }); await expect(inputBox).toBeEnabled();
  31  |   return { player, region, current, inputBox, href, actor, board, call };
  32  | }
  33  | 
  34  | test('whiteboard questions: selected model, exact sentence and pause bookmark survive a real queued answer and return', async ({ page }) => {
  35  |   await page.setViewportSize({ width: 1280, height: 800 }); const f = await fixture(page), commands: any[] = [];
  36  |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/questions')) commands.push(request.postDataJSON()); });
  37  |   await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6-astra');
  38  |   const unit = await f.current.getAttribute('data-unit-id'); await f.player.getByRole('button', { name: '播放', exact: true }).click();
  39  |   await expect(f.player.getByRole('button', { name: '暂停', exact: true })).toBeVisible();
  40  |   await f.inputBox.fill('为什么需要统一计数单位？'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  41  |   await expect(f.region.locator('.wb-question-answer')).toContainText('当前原句：'); await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  42  |   expect(commands).toHaveLength(1); expect(commands[0]).toMatchObject({ modelId: 'gpt-6-astra', unitId: unit, intent: 'question' });
  43  |   expect(commands[0].bookmark.progress).toBeGreaterThanOrEqual(0); expect(commands[0].bookmark.progress).toBeLessThan(1);
  44  |   await f.player.getByRole('button', { name: '下一句', exact: true }).click(); await expect(f.current).not.toHaveAttribute('data-unit-id', unit!);
  45  |   await f.region.getByRole('button', { name: /回到这句/ }).click(); await expect(f.current).toHaveAttribute('data-unit-id', unit!);
  46  |   await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible(); await expect(f.region.locator('.wb-question-meta')).toContainText('gpt-6-astra');
  47  |   writeFileSync(join(browserEvidence('whiteboard-questions'), 'original-sentence-command.json'), JSON.stringify({ commands, restoredUnit: unit }, null, 2));
  48  | });
  49  | 
  50  | test('whiteboard questions: five intentions produce distinct original commands and retain completed history', async ({ page }) => {
  51  |   const f = await fixture(page), intentions = ['question','example','simplify','prerequisite','compare'], commands: any[] = [];
  52  |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/questions')) commands.push(request.postDataJSON()); });
  53  |   for (const [index, intent] of intentions.entries()) {
  54  |     await f.region.getByRole('combobox', { name: '讲解方式', exact: true }).selectOption(intent); await f.inputBox.fill('匿名讲解方式验证 ' + intent);
  55  |     await f.region.getByRole('button', { name: '发送', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(index + 1);
  56  |   }
  57  |   expect(commands.map(command => command.intent)).toEqual(intentions); expect(new Set(commands.map(command => command.requestKey)).size).toBe(5);
  58  |   await page.reload(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(5); await expect(f.inputBox).toHaveValue('');
  59  | });
  60  | 
  61  | test('whiteboard questions: a failed answer has an explicit original-model retry and preserves the next unsent question', async ({ page }) => {
  62  |   const f = await fixture(page); await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('deepseek-v4-flash');
  63  |   await f.inputBox.fill('[question-fail-once] 请解释相同单位。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  64  |   await expect(f.region.getByRole('button', { name: '用原模型重试', exact: true })).toBeVisible();
  65  |   await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6-astra'); await f.inputBox.fill('这是下一条未发送的完整问题，保留尾部。');
  66  |   await f.region.getByRole('button', { name: '用原模型重试', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  67  |   await expect(f.region.locator('.wb-question-meta')).toContainText('deepseek-v4-flash'); await expect(f.inputBox).toHaveValue('这是下一条未发送的完整问题，保留尾部。');
  68  | });
  69  | 
  70  | test('whiteboard questions: cancelling running work blocks the late answer and the same original can be retried', async ({ page }) => {
  71  |   const f = await fixture(page); await f.inputBox.fill('[question-pause-once] 保留当前原句。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  72  |   await expect(f.region.locator('.wb-question-meta')).toContainText('正在思考'); await f.region.getByRole('button', { name: '取消回答', exact: true }).click();
  73  |   await expect(f.region.locator('.wb-question-meta')).toContainText('已取消'); await expect(f.region.locator('.wb-question-answer')).toHaveCount(0);
  74  |   await f.region.getByRole('button', { name: '用原模型重试', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  75  | });
  76  | 
  77  | test('whiteboard questions: a lost create response is recovered after reload without a second write', async ({ page }) => {
  78  |   const f = await fixture(page), commands: any[] = [];
  79  |   await page.route('**/api/learning/studio/whiteboards/*/questions', async route => {
  80  |     if (route.request().method() !== 'POST') { await route.continue(); return; }
  81  |     commands.push(route.request().postDataJSON()); const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed');
  82  |   });
  83  |   await f.inputBox.fill('原创建回执丢失仍保留全部内容。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  84  |   await expect.poll(() => commands.length).toBe(1); await page.reload();
  85  |   await expect(f.region.locator('.wb-question-user')).toContainText('原创建回执丢失仍保留全部内容。');
  86  |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1); expect(commands).toHaveLength(1); await expect(f.inputBox).toHaveValue('');
  87  | });
  88  | 
  89  | test('whiteboard questions: unavailable local storage keeps the full input, protects closing and round trips the downloaded JSON', async ({ page }) => {
  90  |   await page.addInitScript(() => {
  91  |     const get = Storage.prototype.getItem, set = Storage.prototype.setItem;
  92  |     Storage.prototype.getItem = function(key) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'SecurityError'); return get.call(this,key); };
  93  |     Storage.prototype.setItem = function(key,value) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this,key,value); };
  94  |   });
  95  |   const f = await fixture(page), message = '完整输入首部。' + '条件与理由。'.repeat(180) + '完整输入尾部。';
  96  |   await f.inputBox.fill(message); await expect(f.region).toContainText('本机副本暂未保存'); await f.player.getByRole('button', { name: '关闭白板', exact: true }).click();
  97  |   await expect(f.player).toBeVisible(); await expect(f.inputBox).toHaveValue(message);
  98  |   const downloadPromise = page.waitForEvent('download'); await f.region.getByRole('button', { name: '下载完整提问副本', exact: true }).click(); const download = await downloadPromise;
  99  |   const bytes = readFileSync((await download.path())!); expect(JSON.parse(bytes.toString('utf8')).form.message).toBe(message);
  100 |   await f.player.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(f.player).toHaveCount(0);
  101 |   await page.goto(f.href); await expect(f.player).toHaveAttribute('data-original-font-status','ready'); await expect(f.inputBox).toBeEnabled();
  102 |   await f.region.getByLabel('导入完整提问副本', { exact: true }).setInputFiles({ name: 'original-question.json', mimeType: 'application/json', buffer: bytes });
  103 |   await expect(f.inputBox).toHaveValue(message);
  104 | });
  105 | 
  106 | test('whiteboard questions: duplicated documents keep separate full drafts across independent reloads', async ({ page, context }) => {
  107 |   const f = await fixture(page), second = await context.newPage(); await second.goto(f.href);
  108 |   const other = second.getByRole('region', { name: '原句提问', exact: true }).getByRole('textbox', { name: '向老师提问', exact: true }); await expect(other).toBeEnabled();
  109 |   await f.inputBox.fill('第一标签页的完整问题 A 尾部。'); await other.fill('第二标签页的完整问题 B 尾部。');
  110 |   await page.reload(); await expect(f.inputBox).toHaveValue('第一标签页的完整问题 A 尾部。');
  111 |   await second.reload(); await expect(other).toHaveValue('第二标签页的完整问题 B 尾部。'); await second.close();
  112 | });
  113 | 
  114 | for (const width of [390,768,1280]) test('whiteboard questions: the real composer, model selection and return controls remain usable at ' + width, async ({ page }) => {
  115 |   await page.setViewportSize({ width, height: 800 }); const f = await fixture(page);
```