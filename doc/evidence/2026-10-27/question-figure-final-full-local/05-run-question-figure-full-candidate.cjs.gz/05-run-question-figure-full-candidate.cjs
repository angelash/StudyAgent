const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const { spawn, execFileSync } = require('node:child_process'), { createHash } = require('node:crypto');
const root = path.resolve(__dirname, '../..'), expected = '3523b41d5e8242a285502a7a1c927adc720ca243';
const git = args => execFileSync('git', args, { cwd: root, encoding: 'utf8', windowsHide: true }).trim();
const sha = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const receiptPath = path.join(__dirname, 'question-figure-full-candidate-3523b41.json');
assert(!fs.existsSync(receiptPath), 'This original full attempt already exists');
const receipt = { head: expected, at: new Date().toISOString(), pid: process.pid, status: 'starting', passed: false,
  scope: 'One fixed complete local production Web build and365 original Playwright attempts using isolated3173/4173 fixtures. No production data or real model calls.' };
function save() { fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n'); }
function files(dir) { return fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => {
  if (['.next', 'node_modules'].includes(e.name) || e.name === '.runtime-lock.json') return [];
  const p = path.join(dir, e.name); return e.isDirectory() ? files(p) : e.isFile() ? [p] : [];
}); }
async function run(phase, args, file) {
  Object.assign(receipt, { phase, phaseStartedAt: new Date().toISOString() }); save();
  const fd = fs.openSync(path.join(root, file), 'wx');
  try { return await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, { cwd: root, windowsHide: true,
      env: { ...process.env, E2E_API_PORT: '4173', E2E_WEB_PORT: '3173', CI: '', NEXT_TELEMETRY_DISABLED: '1' }, stdio: ['ignore', fd, fd] });
    receipt.childPid = child.pid; save(); child.once('error', reject); child.once('exit', code => resolve(code ?? 1));
  }); } finally { fs.closeSync(fd); }
}
(async () => {
  assert.equal(git(['rev-parse', 'HEAD']), expected); assert.equal(git(['status', '--porcelain']), ''); save();
  assert.equal(await run('build', ['scripts/qa/experience-web.cjs', 'build'], 'data/qa/question-figure-full-web-3523b41.log'), 0, 'Complete isolated Web build failed');
  const names = git(['ls-files', 'apps', 'packages', 'scripts', 'tests', '.github', 'package.json', 'package-lock.json', 'tsconfig.base.json', 'playwright.config.ts', '.gitattributes', '.gitignore']).split(/\r?\n/);
  const source = Object.fromEntries(names.filter(p => fs.existsSync(path.join(root, p))).map(p => [p, sha(path.join(root, p))]));
  const compiled = Object.fromEntries(['apps/api/dist', 'packages/contracts/dist', 'packages/config/dist'].flatMap(dir => files(path.join(root, dir))).map(p => [path.relative(root, p).replaceAll('\\', '/'), sha(p)]));
  const qa = path.join(root, 'data/qa/experience-web'), qaSource = Object.fromEntries(files(qa).map(p => [path.relative(qa, p).replaceAll('\\', '/'), sha(p)]));
  fs.writeFileSync(path.join(__dirname, 'question-figure-fixed-inputs-3523b41.json'), JSON.stringify({ head: expected, at: new Date().toISOString(), sourceSha256: source, compiledSha256: compiled, qaWeb: { sourceSha256: qaSource } }, null, 2) + '\n', { flag: 'wx' });
  assert(!fs.existsSync(path.join(root, 'data/qa/source-course-full-browser.json')), 'Original full-browser report already exists');
  const exit = await run('browser', ['scripts/qa/run-source-course-browser.cjs', '--full', '--skip-build'], 'data/qa/question-figure-full-browser-3523b41.log');
  for (const [p, digest] of Object.entries(source)) assert.equal(sha(path.join(root, p)), digest, 'Frozen source changed: ' + p);
  for (const [p, digest] of Object.entries(compiled)) assert.equal(sha(path.join(root, p)), digest, 'Frozen compiled input changed: ' + p);
  for (const [p, digest] of Object.entries(qaSource)) assert.equal(sha(path.join(qa, p)), digest, 'Actual QA Web changed: ' + p);
  const report = JSON.parse(fs.readFileSync(path.join(root, 'data/qa/source-course-full-browser.json'), 'utf8')), cases = [];
  const walk = s => { for (const spec of s.specs || []) cases.push(...spec.tests); for (const child of s.suites || []) walk(child); }; report.suites.forEach(walk);
  receipt.stats = report.stats; receipt.originalAttempts = cases.reduce((sum, t) => sum + t.results.length, 0);
  assert.equal(exit, 0); assert.equal(report.stats.expected, 365); assert.equal(report.stats.unexpected, 0); assert.equal(report.stats.flaky, 0); assert.equal(report.stats.skipped, 0); assert.equal(report.errors.length, 0);
  assert.equal(cases.length, 365); assert(cases.every(t => t.results.length === 1 && t.results[0].status === 'passed'));
  Object.assign(receipt, { status: 'complete', passed: true, reportSha256: sha(path.join(root, 'data/qa/source-course-full-browser.json')), completedAt: new Date().toISOString() });
})().catch(error => { Object.assign(receipt, { status: 'failed', error: error.message, completedAt: new Date().toISOString() }); process.exitCode = 1; }).finally(save);
