const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{spawn,execFileSync}=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'../..'),out=path.join(__dirname,'model134-corrected-api-f820751'),head='f820751';
if(fs.existsSync(out))throw Error('Preserve original acceptance attempts');fs.mkdirSync(out);
const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();assert(revision.startsWith(head));assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const original=JSON.parse(fs.readFileSync(path.join(__dirname,'model134-full-3a93387/source.json'),'utf8')).sha256;
const changed=['apps/api/src/modules/ai/evidence-coach.integration.test.ts','apps/api/src/modules/learning/notebook.integration.test.ts'];
for(const[file,digest]of Object.entries(original))if(!changed.includes(file))assert.equal(sha(path.join(root,file)),digest,file);
const fixed=JSON.parse(fs.readFileSync(path.join(__dirname,'current-models-bound-16cea68/receipt.json'),'utf8')).sourceAndCompiledSha256;
for(const[file,digest]of Object.entries(fixed))assert.equal(sha(path.join(root,file)),digest,file);
const inputs=Object.fromEntries(Object.keys(original).map(file=>[file,sha(path.join(root,file))]));fs.writeFileSync(path.join(out,'source.json'),JSON.stringify({head:revision,sha256:inputs},null,2)+'\n',{flag:'wx'});
const receipt={head:revision,startedAt:new Date().toISOString(),status:'running',passed:false,
 scope:'Full API after replacing only the two legacy model fixtures. Product source and compiled inputs identical to the 368-case browser and real model executions; those original browser attempts are retained separately.',
 changedTestFiles:changed,productAndCompiledUnchanged:true};const save=()=>fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');save();
(async()=>{
 const fd=fs.openSync(path.join(out,'api.log'),'wx');let code;
 try{code=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,['--env-file=../../.env','../../node_modules/vitest/vitest.mjs','run','--reporter=json','--outputFile='+path.join(out,'api.json')],{cwd:path.join(root,'apps/api'),env:{...process.env,STUDY_DATA_DIR:path.join(out,'isolated-default-data')},windowsHide:true,stdio:['ignore',fd,fd]});receipt.childPid=child.pid;save();child.once('error',reject);child.once('exit',value=>resolve(value??1));});}finally{fs.closeSync(fd);}
 receipt.exitCode=code;assert.equal(code,0,'Corrected full API failed; preserve report');
 for(const[file,digest]of Object.entries(inputs))assert.equal(sha(path.join(root,file)),digest,file);for(const[file,digest]of Object.entries(fixed))assert.equal(sha(path.join(root,file)),digest,file);
 const api=JSON.parse(fs.readFileSync(path.join(out,'api.json'),'utf8'));assert(api.success);assert.deepEqual([api.numPassedTests,api.numFailedTests,api.numPendingTests],[1468,0,60]);
 Object.assign(receipt,{status:'complete',passed:true,api:{passed:api.numPassedTests,failed:api.numFailedTests,environmentSkipped:api.numPendingTests,reportSha256:sha(path.join(out,'api.json'))}});
})().catch(error=>{receipt.status='failed';receipt.failure=error.message;process.exitCode=1;}).finally(()=>{receipt.completedAt=new Date().toISOString();save();console.log(JSON.stringify({status:receipt.status,passed:receipt.passed,api:receipt.api}));});
