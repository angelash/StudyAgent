# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-navigation.spec.ts >> reference navigation: truthful empty history, actual navigation and complete compact or modal controls at 390
- Location: tests\e2e\reference-navigation.spec.ts:18:49

# Error details

```
Error: the open drawer keeps the icon and complete label in one horizontal row

expect(received).toBeGreaterThan(expected)

Expected: > 150
Received:   127
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - button "打开学习导航" [expanded] [ref=f1e4] [cursor=pointer]
    - dialog "学习工作台导航" [ref=f1e9]:
      - generic [ref=f1e10]:
        - generic [ref=f1e11]:
          - link "StudyAgent 学习工作台" [active] [ref=f1e12] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f1e15]: StudyAgent
          - button "关闭学习导航" [expanded] [ref=f1e16] [cursor=pointer]
        - generic [ref=f1e19]:
          - navigation "工作台主要入口" [ref=f1e20]:
            - link "Home" [ref=f1e21] [cursor=pointer]:
              - /url: /studio?view=home
              - generic [ref=f1e24]: 首页
            - link "Courses" [ref=f1e25] [cursor=pointer]:
              - /url: /studio?view=courses
              - generic [ref=f1e28]: 课程
            - link "Calendar" [ref=f1e29] [cursor=pointer]:
              - /url: /studio?view=calendar
              - generic [ref=f1e32]: 学习动态
            - link "History" [ref=f1e33] [cursor=pointer]:
              - /url: /studio?view=history
              - generic [ref=f1e36]: 历史
            - link "Materials" [ref=f1e37] [cursor=pointer]:
              - /url: /studio?view=materials
              - generic [ref=f1e40]: 资料
            - link "AI Whiteboards" [ref=f1e41] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f1e44]: AI白板
          - generic [ref=f1e45]:
            - region "开始学习" [ref=f1e46]:
              - heading "开始学习" [level=3] [ref=f1e48]
              - link "打开课程 从一节适合自己的课开始。" [ref=f1e49] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f1e50]: 打开课程
                - generic [ref=f1e51]: 从一节适合自己的课开始。
            - generic [ref=f1e52]:
              - heading "近期活动" [level=3] [ref=f1e54]
              - paragraph [ref=f1e56]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f1e58] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f1e59]:
      - complementary [ref=f1e60]:
        - link "× 退出课程" [ref=f1e61] [cursor=pointer]:
          - /url: /studio?view=courses
          - text: ×
          - generic [ref=f1e62]: 退出课程
        - img "由阶梯与拱门构成的课程封面" [ref=f1e63]
        - generic [ref=f1e83]:
          - generic [ref=f1e84]: S
          - generic [ref=f1e85]:
            - generic [ref=f1e86]: 策划自
            - generic [ref=f1e87]: StudyAgent Learning Studio
        - heading "社会学概论" [level=1] [ref=f1e88]
        - paragraph [ref=f1e89]: 从自己的生活出发，看见文化、关系和制度如何共同塑造社会。五个单元串起概念、案例、练习与一个持续推进的社区研究。
        - group [ref=f1e90]:
          - generic "显示更多" [ref=f1e91] [cursor=pointer]
        - generic [ref=f1e92]:
          - tablist "课程面板" [ref=f1e93]:
            - tab "单元" [selected] [ref=f1e94] [cursor=pointer]
            - tab "资料" [ref=f1e95] [cursor=pointer]
            - tab "练习" [ref=f1e96] [cursor=pointer]
          - tabpanel "单元" [ref=f1e97]:
            - generic [ref=f1e98]:
              - button "1 社会学视角" [ref=f1e99] [cursor=pointer]:
                - generic [ref=f1e100]: "1"
                - generic [ref=f1e101]: 社会学视角
              - button "2 文化与自我" [ref=f1e102] [cursor=pointer]:
                - generic [ref=f1e103]: "2"
                - generic [ref=f1e104]: 文化与自我
              - button "3 不平等" [ref=f1e105] [cursor=pointer]:
                - generic [ref=f1e106]: "3"
                - generic [ref=f1e107]: 不平等
              - button "4 制度" [ref=f1e108] [cursor=pointer]:
                - generic [ref=f1e109]: "4"
                - generic [ref=f1e110]: 制度
              - button "5 越轨与社会变迁" [ref=f1e111] [cursor=pointer]:
                - generic [ref=f1e112]: "5"
                - generic [ref=f1e113]: 越轨与社会变迁
      - generic [ref=f1e114]:
        - generic [ref=f1e115]:
          - generic [ref=f1e116]: 第 1 单元，共 5 单元
          - heading "单元 1：社会学视角" [level=2] [ref=f1e117]
          - paragraph [ref=f1e118]: 把个人经验放回社会背景，比较理论解释并设计可检验的研究。
        - link "▤ 把自己的资料带进课堂 PDF、页级阅读、个性化学案与白板 ↗" [ref=f1e119] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e120]: ▤
          - generic [ref=f1e121]:
            - generic [ref=f1e122]: 把自己的资料带进课堂
            - generic [ref=f1e123]: PDF、页级阅读、个性化学案与白板
          - generic [ref=f1e124]: ↗
        - generic [ref=f1e125]:
          - generic [ref=f1e126]:
            - generic "讲解已读" [ref=f1e127]: ✓
            - text: 讲解已读
          - generic [ref=f1e128]:
            - generic "已接触" [ref=f1e129]
            - text: 已接触
          - generic [ref=f1e130]:
            - generic "未开始" [ref=f1e131]
            - text: 未开始
          - generic [ref=f1e132]: ▣ Project
          - generic [ref=f1e133]: ♙ Exam
        - generic [ref=f1e134]:
          - generic [ref=f1e135]:
            - button "未开始" [ref=f1e136] [cursor=pointer]
            - button "未开始" [ref=f1e138] [cursor=pointer]
            - button "未开始" [ref=f1e140] [cursor=pointer]
            - button "未开始" [ref=f1e142] [cursor=pointer]
            - button "未开始" [ref=f1e144] [cursor=pointer]
            - button "未开始" [ref=f1e146] [cursor=pointer]
            - button "未开始" [ref=f1e148] [cursor=pointer]
            - button "未开始" [ref=f1e150] [cursor=pointer]
            - button "未开始" [ref=f1e152] [cursor=pointer]
            - button "未开始" [ref=f1e154] [cursor=pointer]
            - button "未开始" [ref=f1e156] [cursor=pointer]
            - button "未开始" [ref=f1e158] [cursor=pointer]
            - link "▣" [ref=f1e160] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
            - button "♙" [ref=f1e161] [cursor=pointer]
          - button "▶ 下一步：社会学想象力 ›" [ref=f1e162] [cursor=pointer]:
            - text: ▶
            - generic [ref=f1e163]: 下一步：社会学想象力
            - text: ›
        - group "本单元学习进程" [ref=f1e164]:
          - generic "学习进程 · 本单元" [ref=f1e165] [cursor=pointer]
        - generic [ref=f1e166]:
          - article [ref=f1e167]:
            - button "讲次 1：社会学思考" [expanded] [ref=f1e169] [cursor=pointer]
            - paragraph [ref=f1e170]: 围绕社会学思考，通过四段微课完成概念辨析与情境应用。
            - generic [ref=f1e171]:
              - generic [ref=f1e172]:
                - generic [ref=f1e173]:
                  - text: 社会学想象力
                  - button "查看学习目标：社会学想象力" [ref=f1e174] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e175] [cursor=pointer]
                - button "♧ 练习" [ref=f1e176] [cursor=pointer]
                - generic "未开始" [ref=f1e177]
              - generic [ref=f1e178]:
                - generic [ref=f1e179]:
                  - text: 结构与能动性
                  - button "查看学习目标：结构与能动性" [ref=f1e180] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e181] [cursor=pointer]
                - button "♧ 练习" [ref=f1e182] [cursor=pointer]
                - generic "未开始" [ref=f1e183]
              - generic [ref=f1e184]:
                - generic [ref=f1e185]:
                  - text: 社会事实
                  - button "查看学习目标：社会事实" [ref=f1e186] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e187] [cursor=pointer]
                - button "♧ 练习" [ref=f1e188] [cursor=pointer]
                - generic "未开始" [ref=f1e189]
              - generic [ref=f1e190]:
                - generic [ref=f1e191]:
                  - text: 社会学与日常生活
                  - button "查看学习目标：社会学与日常生活" [ref=f1e192] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e193] [cursor=pointer]
                - button "♧ 练习" [ref=f1e194] [cursor=pointer]
                - generic "未开始" [ref=f1e195]
          - article [ref=f1e196]:
            - button "讲次 2：理论传统" [ref=f1e198] [cursor=pointer]
            - paragraph [ref=f1e199]: 围绕理论传统，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e200]:
            - button "讲次 3：研究方法" [ref=f1e202] [cursor=pointer]
            - paragraph [ref=f1e203]: 围绕研究方法，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e204]:
            - generic [ref=f1e205]: PROJECT · 1 / 5
            - heading "研究问题与方法设计" [level=3] [ref=f1e206]
            - paragraph [ref=f1e207]: 选择一个社区现象，写出研究问题、调查对象、方法与保护参与者的办法。
            - link "开始项目 →" [ref=f1e208] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
          - article [ref=f1e209]:
            - text: UNIT CHECK
            - heading "社会学视角综合核查" [level=3] [ref=f1e210]
            - paragraph [ref=f1e211]: 覆盖本单元的 12 个主题，12 道新情境题保留首次作答、跳过与提示记录。
            - button "Start →" [ref=f1e212] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash } from 'node:crypto';
  3  | import { browserEvidence } from './evidence';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`, evidence = browserEvidence('reference-navigation');
  5  | async function enter(page: Page, width: number) {
  6  |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  7  |   const nonce = crypto.randomUUID(), principal = 'navigation-' + nonce + '@local.test', credential = 'Nav-QA-' + nonce;
  8  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.20.' + hash[0] + '.' + hash[1];
  9  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  10 |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  11 |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
  12 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  13 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  14 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  15 |   await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  16 |   return actor;
  17 | }
  18 | for (const width of [390, 768, 1280, 1440]) test(`reference navigation: truthful empty history, actual navigation and complete compact or modal controls at ${width}`, async ({ page }) => {
  19 |   await enter(page, width);
  20 |   if (width <= 1000) await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  21 |   const sidebar = page.getByLabel('学习工作台导航', { exact: true }); await expect(sidebar).toBeVisible();
  22 |   await expect(sidebar.getByRole('region', { name: '开始学习', exact: true })).toContainText('打开课程');
  23 |   await expect(sidebar.getByRole('region', { name: '继续学习', exact: true })).toHaveCount(0);
  24 |   if (width <= 1000) {
  25 |     await expect(sidebar).toHaveAttribute('aria-modal', 'true');
  26 |     const row = sidebar.getByRole('link', { name: 'Courses', exact: true }), icon = await row.locator('svg').boundingBox(), label = await row.locator('.button-label').boundingBox();
> 27 |     expect(label!.x, 'the open drawer keeps the icon and complete label in one horizontal row').toBeGreaterThan(icon!.x + icon!.width);
     |                                                                                                 ^ Error: the open drawer keeps the icon and complete label in one horizontal row
  28 |     expect(Math.abs(label!.y + label!.height / 2 - icon!.y - icon!.height / 2)).toBeLessThanOrEqual(4);
  29 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(true);
  30 |     await page.keyboard.press('Shift+Tab'); expect(await sidebar.evaluate(node => node.contains(document.activeElement))).toBe(true);
  31 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  32 |     await page.keyboard.press('Escape'); await expect(sidebar).toHaveCount(0);
  33 |     await expect(page.getByRole('button', { name: '打开学习导航', exact: true })).toBeFocused();
  34 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  35 |     await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  36 |   } else {
  37 |     expect((await sidebar.boundingBox())!.width).toBe(240);
  38 |     await sidebar.getByRole('button', { name: '收起学习导航', exact: true }).click(); await expect(sidebar).toHaveCSS('width', '60px');
  39 |     await expect(sidebar.getByRole('link', { name: 'Courses', exact: true })).toBeVisible();
  40 |     await page.reload(); await expect(page.getByRole('button', { name: '展开学习导航', exact: true })).toBeVisible();
  41 |     await page.getByRole('button', { name: '展开学习导航', exact: true }).click();
  42 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  43 |   }
  44 |   await sidebar.getByRole('link', { name: 'Courses', exact: true }).click(); await expect(page.getByRole('heading', { name: '我的课程', exact: true })).toBeVisible();
  45 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  46 | });
  47 | test('reference navigation: a real saved classroom opens the exact original session and position from the course library', async ({ page }) => {
  48 |   await enter(page, 1280); await page.getByRole('button', { name: '▶ 学习', exact: true }).first().click();
  49 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  50 |   const original = new URL(page.url()).searchParams.get('session');
  51 |   await page.getByRole('button', { name: '离开课堂', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  52 |   await page.goto('/studio?view=courses'); const resume = page.getByRole('region', { name: '继续学习', exact: true }); await expect(resume).toContainText('社会学想象力');
  53 |   await resume.getByRole('link').click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  54 |   expect(new URL(page.url()).searchParams.get('session')).toBe(original);
  55 | });
  56 | test('reference navigation: resizing an open drawer restores usable desktop controls and releases the original background', async ({ page }) => {
  57 |   await enter(page, 768); await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  58 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toBeVisible(); await page.setViewportSize({ width: 1280, height: 900 });
  59 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toHaveCount(0);
  60 |   await expect(page.getByRole('button', { name: '收起学习导航', exact: true })).toBeVisible();
  61 |   expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  62 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  63 |   await page.getByRole('tab', { name: '练习', exact: true }).click(); await expect(page.getByRole('tabpanel', { name: '练习', exact: true })).toBeVisible();
  64 | });
  65 | test('reference navigation: blocked preference storage keeps current controls usable without inventing a saved preference', async ({ page }) => {
  66 |   await enter(page, 1280);
  67 |   await page.addInitScript(() => {
  68 |     const read = Storage.prototype.getItem, write = Storage.prototype.setItem;
  69 |     Storage.prototype.getItem = function (key) { if (key.startsWith('studyagent.navigation.compact.')) throw new Error('Synthetic unavailable navigation preferences'); return read.call(this, key); };
  70 |     Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.navigation.compact.')) throw new Error('Synthetic unavailable navigation preferences'); return write.call(this, key, value); };
  71 |   });
  72 |   await page.reload(); const sidebar = page.getByLabel('学习工作台导航', { exact: true });
  73 |   await sidebar.getByRole('button', { name: '收起学习导航', exact: true }).click(); await expect(sidebar).toHaveCSS('width', '60px');
  74 |   await sidebar.getByRole('button', { name: '展开学习导航', exact: true }).click(); await expect(sidebar).toHaveCSS('width', '240px');
  75 |   await page.reload(); await expect(sidebar.getByRole('button', { name: '收起学习导航', exact: true })).toBeVisible();
  76 | });
  77 | 
```