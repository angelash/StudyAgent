// Private delivery helper. Refuse every mutation until the exact candidate and old runtime are verified.
const fs = require('node:fs'), path = require('node:path'), { createHash } = require('node:crypto'), { execFileSync } = require('node:child_process');
const root = process.cwd(), names = ['study-agent-api', 'study-agent-web', 'study-agent-health'];
const latest = JSON.parse(fs.readFileSync('data/qa/question-figure-release-latest.json'));
const release = path.resolve(root, latest.folder), base = path.join(root, 'output/daemon/release-backups');
if (!release.startsWith(base + path.sep) || fs.realpathSync(release).toLowerCase() !== release.toLowerCase()) throw Error('Unexpected exact rollback directory');
const read = name => JSON.parse(fs.readFileSync(path.join(release, name), 'utf8'));
const before = read('deployment-before.json'), candidate = read('candidate.json');
const sha = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const git = args => execFileSync('git', args, { encoding: 'utf8', windowsHide: true }).trim();
function pm(args) { return execFileSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', 'pm2 ' + args], { encoding: 'utf8', windowsHide: true, maxBuffer: 10 * 1024 * 1024 }); }
async function main() {
  if (candidate.schemaVersion !== 20 || candidate.apiLocalPassed !== 1451 || candidate.apiLocalFailed !== 0 || candidate.apiEnvironmentSkipped !== 60 || Object.keys(candidate.compiledSha256).length !== 363) throw Error('Complete schema20 and full local API gate required');
  if (candidate.status !== 'ready-for-release' || candidate.verifiedZeroRetries !== true || candidate.localBrowserCases !== 365 || candidate.remoteBrowserCases !== 365) throw Error('Complete candidate gate required');
  const ci = JSON.parse(execFileSync('gh', ['run', 'view', String(candidate.ciRun), '--json', 'status,conclusion,headSha,jobs'], { encoding: 'utf8', windowsHide: true }));
  if (ci.status !== 'completed' || ci.conclusion !== 'success' || ci.headSha !== candidate.head || ci.jobs.length !== 3 || ci.jobs.some(row => row.status !== 'completed' || row.conclusion !== 'success')) throw Error('Exact candidate CI not complete');
  if (git(['rev-parse', 'HEAD']) !== before.revision || before.revision !== 'cbf734abb167fbd2dcd1832745d9f41fddd107be') throw Error('Expected original131 main revision');
  const changed = git(['diff', '--name-only']).split(/\r?\n/).sort();
  if (JSON.stringify(changed) !== JSON.stringify(Object.keys(before.protectedFiles).sort()) || git(['diff', '--cached', '--name-only'])) throw Error('Unexpected modified or staged main files');
  function verifyConfig() {
    for (const [file, expected] of Object.entries(before.protectedFiles)) if (sha(file) !== expected) throw Error('Protected configuration changed: ' + file);
    if (sha('.env') !== sha(path.join(release, 'config/.env'))) throw Error('Private environment changed');
  }
  verifyConfig();
  const services = JSON.parse(pm('jlist')).filter(row => names.includes(row.name));
  if (services.length !== 3 || services.some(row => row.pm2_env.status !== 'online' || path.resolve(row.pm2_env.pm_cwd).toLowerCase() !== root.toLowerCase())) throw Error('Unexpected guardian ownership/state');
  pm('stop ' + names.join(' '));
  const stopped = JSON.parse(pm('jlist')).filter(row => names.includes(row.name));
  if (stopped.length !== 3 || stopped.some(row => row.pm2_env.status !== 'stopped' || row.pid)) throw Error('Service did not stop');
  const backup = require(path.join(root, 'scripts/operations/backup.cjs')), bundle = path.join(release, 'data-bundle-final');
  await backup.createBundle({ dataDir: path.join(root, 'data'), destination: bundle });
  const verified = await backup.verifyBundle({ bundle });
  if (verified.database.schemaVersions.at(-1) !== 19) throw Error('Fresh schema19 rollback required before132 delivery');
  const receipt = { at: new Date().toISOString(), bundle: 'data-bundle-final', verifiedFiles: verified.verifiedFiles, assetsIncluded: false, servicesStopped: names,
    scope: 'Fresh stopped-service consistent SQLite database and database-referenced runtime files. Original compiled build/configuration separately copied and hashed. No complete research-asset backup or full recovery rehearsal.' };
  fs.writeFileSync(path.join(release, 'backup-verified.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  git(['merge', '--ff-only', candidate.deliveryHead]); verifyConfig();
  fs.writeFileSync(path.join(release, 'deployment-target.json'), JSON.stringify({ ciHead: candidate.head, ciRun: candidate.ciRun, applicationRevision: candidate.applicationRevision }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ stopped: names, backup: receipt, head: git(['rev-parse', 'HEAD']), protectedFilesUnchanged: 5 }));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
