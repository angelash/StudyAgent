const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib'),{execFileSync}=require('node:child_process');
const root=process.cwd(),latest=JSON.parse(fs.readFileSync(path.join(root,'data/qa/question-figure-release-latest.json'),'utf8'));
const release=path.resolve(root,latest.folder),base='http://127.0.0.1:3217',sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8').replace(/^\uFEFF/,''));
if(!release.startsWith(path.join(root,'output/daemon/release-backups')+path.sep)||fs.realpathSync(release).toLowerCase()!==release.toLowerCase())throw Error('Unexpected fresh131 rollback path');
async function main(){
 const candidate=read(path.join(release,'candidate.json'));
 if(candidate.status!=='ready-for-release'||candidate.verifiedZeroRetries!==true)throw Error('Candidate release gate incomplete');
 const artifact=path.resolve(root,candidate.browserArtifact);if(!artifact.startsWith(root+path.sep)||sha(fs.readFileSync(artifact))!==candidate.browserArtifactSha256)throw Error('Browser artifact identity differs');
 const original=zlib.gunzipSync(fs.readFileSync(artifact));if(sha(original)!==candidate.originalBrowserSha256)throw Error('Original browser digest differs');
 const stats=JSON.parse(original).stats;if(stats.expected!==365||stats.unexpected!==0||stats.flaky!==0||stats.skipped!==0)throw Error('Complete browser gate failed');
 const ci=JSON.parse(execFileSync('gh',['run','view',String(candidate.ciRun),'--json','status,conclusion,headSha,jobs'],{encoding:'utf8',windowsHide:true}));
 if(ci.status!=='completed'||ci.conclusion!=='success'||ci.headSha!==candidate.head||ci.jobs.length!==3||ci.jobs.some(job=>job.status!=='completed'||job.conclusion!=='success'))throw Error('Exact current candidate CI incomplete');
 const target=path.join(release,'runtime.json');
 if(process.argv.includes('--finalize')){
  const report=read(target),observations=[1,2,3].map(index=>read(path.join(root,'data/qa/question-figure-observation-'+index+'.json'))),first=observations[0];
  const interval=Date.parse(observations[2].at)-Date.parse(first.at);if(interval<60000)throw Error('At least sixty seconds required');
  for(const sample of observations){if(sample.services.length!==3)throw Error('Missing guardian');for(const service of sample.services){const original=first.services.find(row=>row.name===service.name);if(!original||service.status!=='online'||service.pid!==original.pid||service.restarts!==original.restarts||path.resolve(service.cwd).toLowerCase()!==root.toLowerCase())throw Error('Guardian changed');}}
  Object.assign(report,{at:new Date().toISOString(),observations,observedIntervalMs:interval,passed:true,status:'runtime-delivered'});fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({passed:true,httpChecks:report.httpChecks.length,voiceSamples:report.voiceSamples.length,originalAssets:report.originalAssets.length,observedIntervalMs:interval,webBuildId:report.webBuildId}));return;
 }
 execFileSync('git',['merge-base','--is-ancestor',candidate.head,'HEAD']);
 const before=read(path.join(release,'deployment-before.json')),protectedFiles={};
 for(const[file,expected]of Object.entries(before.protectedFiles)){protectedFiles[file]=sha(fs.readFileSync(path.join(root,file)))===expected;if(!protectedFiles[file])throw Error('Protected configuration changed: '+file);}
 if(sha(fs.readFileSync(path.join(root,'.env')))!==sha(fs.readFileSync(path.join(release,'config/.env'))))throw Error('Private local environment changed');
 const compiled=[];for(const[file,expected]of Object.entries(candidate.compiledSha256)){const actual=sha(fs.readFileSync(path.join(root,file)));if(actual!==expected){const exception=candidate.formatOnlyCompiledDifferences.find(row=>row.file===file);if(!exception||sha(fs.readFileSync(path.join(root,file),'utf8').replace(/\r\n/g,'\n'))!==exception.lfSha256)throw Error('Actual compiled source differs: '+file);}compiled.push({file,sha256:actual,expectedSha256:expected,formatOnly:actual!==expected});}
 const {DatabaseSync}=require('node:sqlite'),database=new DatabaseSync(path.join(root,'data/study-agent.sqlite3'),{readOnly:true});let schemaVersion;try{schemaVersion=database.prepare('SELECT MAX(version) AS version FROM schema_migrations').get().version;}finally{database.close();}if(schemaVersion!==20)throw Error('Expected production schema20');
 const httpChecks=[];async function check(url,status=200,method='GET'){const response=await fetch(base+url,{method,signal:AbortSignal.timeout(15000),...(method==='POST'?{headers:{'Content-Type':'application/json'},body:'{}'}:{})});httpChecks.push({url,method,status:response.status});if(response.status!==status)throw Error(method+' '+url+' -> '+response.status);return response;}
 for(const page of ['/learn','/parent/login','/studio','/studio/classroom','/studio/source-courses','/studio/projects','/studio/whiteboards','/student/assessment'])await check(page);
 await check('/api/health');if((await(await check('/api/ready')).json()).data.status!=='ready')throw Error('API not ready');
 for(const url of ['/api/diagnostics/sessions/nonexistent/report','/api/diagnostics/students/nonexistent/plans?subject=math','/api/diagnostics/plans/nonexistent/reviews','/api/diagnostics/students/nonexistent/evidence/nonexistent','/api/learning/studio/overview','/api/learning/source-courses/nonexistent','/api/learning/projects/nonexistent/teaching'])await check(url,401);
 await check('/api/learning/studio/whiteboards/nonexistent',404);
 for(const url of ['/api/learning/studio/topic-whiteboards','/api/learning/studio/topic-whiteboards/drafts','/api/learning/studio/topic-whiteboards/drafts/nonexistent','/api/learning/studio/topic-whiteboards/drafts/nonexistent/requests/nonexistent','/api/learning/studio/topic-whiteboards/drafts/nonexistent/history','/api/learning/studio/topic-whiteboards/nonexistent'])await check(url,401);
 for(const url of ['/api/learning/studio/topic-whiteboards/preflight','/api/learning/studio/topic-whiteboards/drafts','/api/learning/studio/topic-whiteboards/drafts/nonexistent/cancel','/api/learning/studio/topic-whiteboards/drafts/nonexistent/retry','/api/learning/studio/topic-whiteboards/drafts/nonexistent/confirm','/api/learning/studio/topic-whiteboards/nonexistent/narration/nonexistent'])await check(url,401,'POST');
 await check('/api/learning/studio/topic-whiteboards/drafts/nonexistent/content',401,'PATCH');
 for(const url of ['/api/learning/studio/whiteboards','/api/learning/studio/whiteboards/nonexistent/narration/nonexistent'])await check(url,401,'POST');
 for(const url of ["/api/learning/studio/topic-whiteboard-visuals/capabilities","/api/learning/studio/topic-whiteboard-visuals","/api/learning/studio/topic-whiteboard-visuals/requests/nonexistent","/api/learning/studio/topic-whiteboard-visuals/nonexistent/requests/nonexistent","/api/learning/studio/topic-whiteboard-visuals/nonexistent","/api/learning/studio/topic-whiteboard-visuals/nonexistent/image","/api/learning/studio/topic-whiteboard-visuals/nonexistent/original"])await check(url,401);
 for(const url of ["/api/learning/studio/topic-whiteboard-visuals/preflight","/api/learning/studio/topic-whiteboard-visuals","/api/learning/studio/topic-whiteboard-visuals/nonexistent/cancel","/api/learning/studio/topic-whiteboard-visuals/nonexistent/retry","/api/learning/studio/topic-whiteboard-visuals/nonexistent/edits"])await check(url,401,'POST');
 for(const suffix of ['image','original'])await check('/api/learning/studio/topic-whiteboards/nonexistent/figures/nonexistent/'+suffix,401);
 for(const url of ['/api/library/overview','/api/library/facets','/api/library/papers','/api/library/media','/api/library/practice/requests/nonexistent','/api/library/practice/sessions','/api/library/practice/sessions/nonexistent','/api/library/practice/sessions/nonexistent/items/nonexistent','/api/library/practice/sessions/nonexistent/commands/nonexistent'])await check(url,401);
 for(const url of ['/api/library/practice/preview','/api/library/practice/sessions','/api/library/practice/sessions/nonexistent/commands'])await check(url,401,'POST');
 await check('/library/practice');
 await check('/library/practice/review');
 for(const url of ['/api/library/practice/reviews','/api/library/practice/reviews/calendar?from=2026-10-01&to=2026-10-31','/api/library/practice/reviews/calendar/export?from=2026-10-01&to=2026-10-31','/api/library/practice/sessions/nonexistent/items/nonexistent/next-options','/api/library/practice/sessions/nonexistent/items/nonexistent/verification-requests/nonexistent'])await check(url,401);
 await check('/api/library/practice/sessions/nonexistent/items/nonexistent/verification-preview',401,'POST');
 for(const kind of ['whiteboards','topic-whiteboards']){
  const questions='/api/learning/studio/'+kind+'/nonexistent/questions';
  for(const suffix of ['', '/context', '/requests/nonexistent', '/notes', '/notes/identity', '/nonexistent', '/nonexistent/board'])await check(questions+suffix,401);
  for(const suffix of ['', '/nonexistent/cancel', '/nonexistent/retry', '/nonexistent/board/narration/nonexistent'])await check(questions+suffix,401,'POST');
 }
 for(const suffix of ['', '/capabilities', '/source', '/requests/nonexistent', '/nonexistent', '/nonexistent/requests/nonexistent', '/nonexistent/image', '/nonexistent/original'])await check('/api/learning/studio/whiteboard-question-visuals'+suffix,401);
 for(const suffix of ['', '/preflight', '/adopt', '/nonexistent/edit', '/nonexistent/cancel', '/nonexistent/retry'])await check('/api/learning/studio/whiteboard-question-visuals'+suffix,401,'POST');
 for(const kind of ['whiteboards','topic-whiteboards'])for(const suffix of ['', '/original/board', '/original/figure/image', '/original/figure/original'])await check('/api/learning/studio/'+kind+'/nonexistent/questions/nonexistent/teaching-versions'+suffix,401);
 const pageChecks=[],scriptDigests=[];
 for(const[page,markers]of [['/library/practice/review',['把每一次卡住','原卷复习与反思','原题再练与独立新题','独立新题原预览恢复','文件读取期间当前操作已变化','完整整理历史']],["/library",["把这份原卷，真正做一遍。","整卷练习 ↗","把所选题加入跨卷清单","预览跨卷清单"]],["/library/practice",["先留下思考，","不可覆盖的首次回答","先写下自己的回答","原开始记录恢复","保留原开始记录，重新预览","paper-practice-cleared-v1","study.paper-practice.document-ancestors"]],['/student/assessment',['知识掌握与证据范围','reportAtom','重新读取指导安排','这条判断怎样变化','独立新题的原卷来源','返回原首答与反思']],['/studio/whiteboards',['tw-candidate','studyagent.topic-whiteboard.document-slot','预检主题与范围','查看其他本机改稿','恢复原配图请求','topic-whiteboard-visuals','wb-formula-vector','mathjax4-svg-v1']],['/studio',['日历中的原卷复习','原卷作答范围','导出当前范围原卷 ICS','ws-grid-paper-review','wb-sentence-player','whiteboard-speech-v1','createConstantSource','完整讲稿与要点','当前登录已变化，请重新打开白板。','当前句语音准备超时，可重试或选择文字阅读。','hk-teaching whiteboard-root','重置白板视图','正在准备板书字体','font-faces-427e7624ac0b3f9e.css','whiteboard-page-nav','whiteboard-action-pill','讲稿与笔记','下载当前视图 PNG','白板工具导览','原句提问','查看补充板书与声音','带走完整教学笔记','question-whiteboard','whiteboard-teaching-notes.json','完整配图要求','预检完整配图提示','采用并打开这个讲解版本','whiteboard-question-visuals','teaching-versions','已保存独立图片版本，原回答和旧版本都保留。']],['/studio/source-courses',['sc-check-manuscript','选择1～6个课时目标']],['/studio/classroom',['ca-journey','cl-check-source']],['/studio/projects',['pj-teaching-toolbar']]]){
  const markup=await(await check(page)).text(),urls=[...new Set([...markup.matchAll(/<script[^>]+src="([^"]+)"/g)].map(match=>match[1]).filter(url=>url.startsWith('/_next/')&&url.includes('.js')))];let body='';
  for(const url of urls){const bytes=Buffer.from(await(await check(url)).arrayBuffer());body+=bytes.toString('utf8');scriptDigests.push({page,url,sha256:sha(bytes),bytes:bytes.length});}
  for(const marker of markers)if(!body.includes(marker))throw Error('Actual Web marker missing: '+page+' '+marker);pageChecks.push({page,markers,passed:true});
 }
 const manifest=await(await check('/classroom-voice-samples/manifest.json')).json(),voiceSamples=[];
 for(const voice of manifest.voices){const bytes=Buffer.from(await(await check('/classroom-voice-samples/'+voice.file)).arrayBuffer());if(sha(bytes)!==voice.sha256)throw Error('Voice bytes differ');voiceSamples.push({file:voice.file,bytes:bytes.length,sha256:voice.sha256,passed:true});}if(voiceSamples.length!==6)throw Error('Expected six original samples');
 const originalAssets=[];
 const assetManifest=await(await check('/reference/hyperknow/asset-manifest.json')).json(),localAssets=read(path.join(root,'apps/web/public/reference/hyperknow/asset-manifest.json'));
 if(JSON.stringify(assetManifest)!==JSON.stringify(localAssets)||assetManifest.files.length!==937)throw Error('Original local asset manifest differs');
 const queue=[...assetManifest.files],fonts=read(path.join(root,'apps/web/lib/original-teaching-fonts.json'));
 queue.push({publicPath:fonts.stylesheet,bytes:fonts.bytes,sha256:fonts.sha256});
 const extra=read(path.join(root,'apps/web/public/reference/hyperknow-controls/manifest.json'));
 const servedExtra=await(await check('/reference/hyperknow-controls/manifest.json')).json();
 if(JSON.stringify(extra)!==JSON.stringify(servedExtra)||extra.files.length!==1)throw Error('Controls manifest differs');
 queue.push(...extra.files.map(row=>({publicPath:'/reference/hyperknow-controls/'+row.file,bytes:row.bytes,sha256:row.sha256}))); 
 const math=await(await check('/vendor/mathlive/manifest.json')).json(),localMath=read(path.join(root,'apps/web/public/vendor/mathlive/manifest.json'));
 if(JSON.stringify(math)!==JSON.stringify(localMath)||math.files.length!==20)throw Error('Prepared math manifest differs');
 queue.push(...math.files.map(row=>({publicPath:'/vendor/mathlive/'+row.path,bytes:row.size,sha256:row.sha256})));
 let cursor=0;await Promise.all(Array.from({length:8},async()=>{while(cursor<queue.length){const row=queue[cursor++],bytes=Buffer.from(await(await check(row.publicPath)).arrayBuffer());if(bytes.length!==row.bytes||sha(bytes)!==row.sha256)throw Error('Actual static asset differs: '+row.publicPath);originalAssets.push({url:row.publicPath,bytes:bytes.length,sha256:sha(bytes)});}}));originalAssets.sort((a,b)=>a.url.localeCompare(b.url));
 const backup=read(path.join(release,'backup-verified.json')),webBuildId=fs.readFileSync(path.join(root,'apps/web/.next/BUILD_ID'),'utf8').trim();if(webBuildId===before.oldWebBuildId)throw Error('Old build still present');
 const report={at:new Date().toISOString(),passed:false,status:'awaiting-stability-observations',revision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),applicationRevision:candidate.applicationRevision,apiRevision:candidate.apiRevision,ciHead:candidate.head,ciRun:candidate.ciRun,webBuildId,schemaVersion,protectedFiles,localEnvironmentPreserved:true,httpChecks,pageChecks,scriptDigests,compiled,voiceSamples,originalAssets,
  backup:{path:release,bundle:'data-bundle-final',verifiedFiles:backup.verifiedFiles,assetsIncluded:backup.assetsIncluded,buildCopy:read(path.join(release,'build-backup-verification.json')),scope:'Fresh stopped-service consistent database and referenced runtime files plus SHA-verified131 compiled builds and private config. No independent research-asset archive or full restore rehearsal.'},limitations:['Anonymous production checks; authorized synthetic flows and media decode verified in isolated storage.','Captured fonts/CSS and local static bytes are verified; manual original geometry, full reference states/DPR/original audio, teacher, real-device and long-term acceptance remain incomplete.']};
 fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,httpChecks:httpChecks.length,voiceSamples:voiceSamples.length,webBuildId}));
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
