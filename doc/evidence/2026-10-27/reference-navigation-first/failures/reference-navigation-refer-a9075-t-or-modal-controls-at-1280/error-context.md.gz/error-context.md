# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-navigation.spec.ts >> reference navigation: truthful empty history, actual navigation and complete compact or modal controls at 1280
- Location: tests\e2e\reference-navigation.spec.ts:18:49

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 60
Received: 240
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - generic [ref=f1e5]:
        - generic [ref=f1e6]:
          - link "StudyAgent 学习工作台" [ref=f1e7] [cursor=pointer]:
            - /url: /studio
          - button "展开学习导航" [active] [ref=f1e10] [cursor=pointer]
        - navigation "工作台主要入口" [ref=f1e14]:
          - link "Home" [ref=f1e15] [cursor=pointer]:
            - /url: /studio?view=home
          - link "Courses" [ref=f1e18] [cursor=pointer]:
            - /url: /studio?view=courses
          - link "Calendar" [ref=f1e21] [cursor=pointer]:
            - /url: /studio?view=calendar
          - link "History" [ref=f1e24] [cursor=pointer]:
            - /url: /studio?view=history
          - link "Materials" [ref=f1e27] [cursor=pointer]:
            - /url: /studio?view=materials
          - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
            - /url: /studio/whiteboards
    - generic [ref=f1e33]:
      - complementary [ref=f1e34]:
        - link "× 退出课程" [ref=f1e35] [cursor=pointer]:
          - /url: /studio?view=courses
          - text: ×
          - generic [ref=f1e36]: 退出课程
        - img "由阶梯与拱门构成的课程封面" [ref=f1e37]
        - generic [ref=f1e57]:
          - generic [ref=f1e58]: S
          - generic [ref=f1e59]:
            - generic [ref=f1e60]: 策划自
            - generic [ref=f1e61]: StudyAgent Learning Studio
        - heading "社会学概论" [level=1] [ref=f1e62]
        - paragraph [ref=f1e63]: 从自己的生活出发，看见文化、关系和制度如何共同塑造社会。五个单元串起概念、案例、练习与一个持续推进的社区研究。
        - group [ref=f1e64]:
          - generic "显示更多" [ref=f1e65] [cursor=pointer]
        - generic [ref=f1e66]:
          - generic [ref=f1e67]: 面板
          - tablist "课程面板" [ref=f1e68]:
            - tab "单元" [selected] [ref=f1e69] [cursor=pointer]
            - tab "资料" [ref=f1e70] [cursor=pointer]
            - tab "练习" [ref=f1e71] [cursor=pointer]
          - tabpanel "单元" [ref=f1e72]:
            - generic [ref=f1e73]:
              - button "1 社会学视角" [ref=f1e74] [cursor=pointer]:
                - generic [ref=f1e75]: "1"
                - generic [ref=f1e76]: 社会学视角
              - button "2 文化与自我" [ref=f1e77] [cursor=pointer]:
                - generic [ref=f1e78]: "2"
                - generic [ref=f1e79]: 文化与自我
              - button "3 不平等" [ref=f1e80] [cursor=pointer]:
                - generic [ref=f1e81]: "3"
                - generic [ref=f1e82]: 不平等
              - button "4 制度" [ref=f1e83] [cursor=pointer]:
                - generic [ref=f1e84]: "4"
                - generic [ref=f1e85]: 制度
              - button "5 越轨与社会变迁" [ref=f1e86] [cursor=pointer]:
                - generic [ref=f1e87]: "5"
                - generic [ref=f1e88]: 越轨与社会变迁
      - generic [ref=f1e89]:
        - generic [ref=f1e90]:
          - generic [ref=f1e91]: 第 1 单元，共 5 单元
          - heading "单元 1：社会学视角" [level=2] [ref=f1e92]
          - paragraph [ref=f1e93]: 把个人经验放回社会背景，比较理论解释并设计可检验的研究。
        - link "▤ 把自己的资料带进课堂 PDF、页级阅读、个性化学案与白板 ↗" [ref=f1e94] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e95]: ▤
          - generic [ref=f1e96]:
            - generic [ref=f1e97]: 把自己的资料带进课堂
            - generic [ref=f1e98]: PDF、页级阅读、个性化学案与白板
          - generic [ref=f1e99]: ↗
        - generic [ref=f1e100]:
          - generic [ref=f1e101]:
            - generic "讲解已读" [ref=f1e102]: ✓
            - text: 讲解已读
          - generic [ref=f1e103]:
            - generic "已接触" [ref=f1e104]
            - text: 已接触
          - generic [ref=f1e105]:
            - generic "未开始" [ref=f1e106]
            - text: 未开始
          - generic [ref=f1e107]: ▣ Project
          - generic [ref=f1e108]: ♙ Exam
        - generic [ref=f1e109]:
          - generic [ref=f1e110]:
            - button "未开始" [ref=f1e111] [cursor=pointer]
            - button "未开始" [ref=f1e113] [cursor=pointer]
            - button "未开始" [ref=f1e115] [cursor=pointer]
            - button "未开始" [ref=f1e117] [cursor=pointer]
            - button "未开始" [ref=f1e119] [cursor=pointer]
            - button "未开始" [ref=f1e121] [cursor=pointer]
            - button "未开始" [ref=f1e123] [cursor=pointer]
            - button "未开始" [ref=f1e125] [cursor=pointer]
            - button "未开始" [ref=f1e127] [cursor=pointer]
            - button "未开始" [ref=f1e129] [cursor=pointer]
            - button "未开始" [ref=f1e131] [cursor=pointer]
            - button "未开始" [ref=f1e133] [cursor=pointer]
            - link "▣" [ref=f1e135] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
            - button "♙" [ref=f1e136] [cursor=pointer]
          - button "▶ 下一步：社会学想象力 ›" [ref=f1e137] [cursor=pointer]:
            - text: ▶
            - generic [ref=f1e138]: 下一步：社会学想象力
            - text: ›
        - group "本单元学习进程" [ref=f1e139]:
          - generic "学习进程 · 本单元" [ref=f1e140] [cursor=pointer]
        - generic [ref=f1e141]:
          - article [ref=f1e142]:
            - generic [ref=f1e143]: ▧
            - generic [ref=f1e144]:
              - button "讲次 1：社会学思考" [expanded] [ref=f1e145] [cursor=pointer]
              - button "获取帮助" [ref=f1e146] [cursor=pointer]
            - paragraph [ref=f1e147]: 围绕社会学思考，通过四段微课完成概念辨析与情境应用。
            - generic [ref=f1e148]:
              - generic [ref=f1e149]:
                - generic [ref=f1e150]:
                  - text: 社会学想象力
                  - button "查看学习目标：社会学想象力" [ref=f1e151] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e152] [cursor=pointer]
                - button "♧ 练习" [ref=f1e153] [cursor=pointer]
                - generic "未开始" [ref=f1e154]
              - generic [ref=f1e155]:
                - generic [ref=f1e156]:
                  - text: 结构与能动性
                  - button "查看学习目标：结构与能动性" [ref=f1e157] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e158] [cursor=pointer]
                - button "♧ 练习" [ref=f1e159] [cursor=pointer]
                - generic "未开始" [ref=f1e160]
              - generic [ref=f1e161]:
                - generic [ref=f1e162]:
                  - text: 社会事实
                  - button "查看学习目标：社会事实" [ref=f1e163] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e164] [cursor=pointer]
                - button "♧ 练习" [ref=f1e165] [cursor=pointer]
                - generic "未开始" [ref=f1e166]
              - generic [ref=f1e167]:
                - generic [ref=f1e168]:
                  - text: 社会学与日常生活
                  - button "查看学习目标：社会学与日常生活" [ref=f1e169] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e170] [cursor=pointer]
                - button "♧ 练习" [ref=f1e171] [cursor=pointer]
                - generic "未开始" [ref=f1e172]
          - article [ref=f1e173]:
            - generic [ref=f1e174]: ▧
            - generic [ref=f1e175]:
              - button "讲次 2：理论传统" [ref=f1e176] [cursor=pointer]
              - button "获取帮助" [ref=f1e177] [cursor=pointer]
            - paragraph [ref=f1e178]: 围绕理论传统，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e179]:
            - generic [ref=f1e180]: ▧
            - generic [ref=f1e181]:
              - button "讲次 3：研究方法" [ref=f1e182] [cursor=pointer]
              - button "获取帮助" [ref=f1e183] [cursor=pointer]
            - paragraph [ref=f1e184]: 围绕研究方法，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e185]:
            - generic [ref=f1e186]: ▣
            - generic [ref=f1e187]: PROJECT · 1 / 5
            - heading "研究问题与方法设计" [level=3] [ref=f1e188]
            - paragraph [ref=f1e189]: 选择一个社区现象，写出研究问题、调查对象、方法与保护参与者的办法。
            - link "开始项目 →" [ref=f1e190] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
          - article [ref=f1e191]:
            - generic [ref=f1e192]: ♙
            - text: UNIT CHECK
            - heading "社会学视角综合核查" [level=3] [ref=f1e193]
            - paragraph [ref=f1e194]: 覆盖本单元的 12 个主题，12 道新情境题保留首次作答、跳过与提示记录。
            - button "Start →" [ref=f1e195] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash } from 'node:crypto';
  3  | import { browserEvidence } from './evidence';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`, evidence = browserEvidence('reference-navigation');
  5  | async function enter(page: Page, width: number) {
  6  |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  7  |   const nonce = crypto.randomUUID(), principal = 'navigation-' + nonce + '@local.test', credential = 'Nav-QA-' + nonce;
  8  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.20.' + hash[0] + '.' + hash[1];
  9  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  10 |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  11 |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
  12 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  13 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  14 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  15 |   await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  16 |   return actor;
  17 | }
  18 | for (const width of [390, 768, 1280, 1440]) test(`reference navigation: truthful empty history, actual navigation and complete compact or modal controls at ${width}`, async ({ page }) => {
  19 |   await enter(page, width);
  20 |   if (width <= 1000) await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  21 |   const sidebar = page.getByLabel('学习工作台导航', { exact: true }); await expect(sidebar).toBeVisible();
  22 |   await expect(sidebar.getByRole('region', { name: '开始学习', exact: true })).toContainText('打开课程');
  23 |   await expect(sidebar.getByRole('region', { name: '继续学习', exact: true })).toHaveCount(0);
  24 |   if (width <= 1000) {
  25 |     await expect(sidebar).toHaveAttribute('aria-modal', 'true');
  26 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(true);
  27 |     await page.keyboard.press('Shift+Tab'); expect(await sidebar.evaluate(node => node.contains(document.activeElement))).toBe(true);
  28 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  29 |     await page.keyboard.press('Escape'); await expect(sidebar).toHaveCount(0);
  30 |     await expect(page.getByRole('button', { name: '打开学习导航', exact: true })).toBeFocused();
  31 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  32 |     await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  33 |   } else {
  34 |     expect((await sidebar.boundingBox())!.width).toBe(240);
> 35 |     await sidebar.getByRole('button', { name: '收起学习导航', exact: true }).click(); expect((await sidebar.boundingBox())!.width).toBe(60);
     |                                                                                                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  36 |     await expect(sidebar.getByRole('link', { name: 'Courses', exact: true })).toBeVisible();
  37 |     await page.reload(); await expect(page.getByRole('button', { name: '展开学习导航', exact: true })).toBeVisible();
  38 |     await page.getByRole('button', { name: '展开学习导航', exact: true }).click();
  39 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  40 |   }
  41 |   await sidebar.getByRole('link', { name: 'Courses', exact: true }).click(); await expect(page.getByRole('heading', { name: '我的课程', exact: true })).toBeVisible();
  42 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  43 | });
  44 | test('reference navigation: a real saved classroom opens the exact original session and position from the course library', async ({ page }) => {
  45 |   await enter(page, 1280); await page.getByRole('button', { name: '▶ 学习', exact: true }).first().click();
  46 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  47 |   const original = new URL(page.url()).searchParams.get('session');
  48 |   await page.getByRole('button', { name: '离开课堂', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  49 |   await page.goto('/studio?view=courses'); const resume = page.getByRole('region', { name: '继续学习', exact: true }); await expect(resume).toContainText('社会学想象力');
  50 |   await resume.getByRole('link').click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  51 |   expect(new URL(page.url()).searchParams.get('session')).toBe(original);
  52 | });
  53 | test('reference navigation: resizing an open drawer restores usable desktop controls and releases the original background', async ({ page }) => {
  54 |   await enter(page, 768); await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  55 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toBeVisible(); await page.setViewportSize({ width: 1280, height: 900 });
  56 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toHaveCount(0);
  57 |   await expect(page.getByRole('button', { name: '收起学习导航', exact: true })).toBeVisible();
  58 |   expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  59 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  60 |   await page.getByRole('tab', { name: '练习', exact: true }).click(); await expect(page.getByRole('tabpanel', { name: '练习', exact: true })).toBeVisible();
  61 | });
  62 | 
```