# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-navigation.spec.ts >> reference navigation: truthful empty history, actual navigation and complete compact or modal controls at 390
- Location: tests\e2e\reference-navigation.spec.ts:18:49

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByRole('button', { name: '打开学习导航', exact: true })
Expected: focused
Received: inactive
Timeout:  15000ms

Call log:
  - Expect "toBeFocused" getByRole('button', { name: '打开学习导航', exact: true }) with timeout 15000ms
  - waiting for getByRole('button', { name: '打开学习导航', exact: true })
    33 × locator resolved to <button type="button" aria-label="打开学习导航" aria-expanded="false" aria-controls="_r_0_" class="ws-reference-trigger">…</button>
       - unexpected value "inactive"

```

```yaml
- button "打开学习导航"
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash } from 'node:crypto';
  3  | import { browserEvidence } from './evidence';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`, evidence = browserEvidence('reference-navigation');
  5  | async function enter(page: Page, width: number) {
  6  |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  7  |   const nonce = crypto.randomUUID(), principal = 'navigation-' + nonce + '@local.test', credential = 'Nav-QA-' + nonce;
  8  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.20.' + hash[0] + '.' + hash[1];
  9  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  10 |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  11 |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
  12 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  13 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  14 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  15 |   await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  16 |   return actor;
  17 | }
  18 | for (const width of [390, 768, 1280, 1440]) test(`reference navigation: truthful empty history, actual navigation and complete compact or modal controls at ${width}`, async ({ page }) => {
  19 |   await enter(page, width);
  20 |   if (width <= 1000) await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  21 |   const sidebar = page.getByLabel('学习工作台导航', { exact: true }); await expect(sidebar).toBeVisible();
  22 |   await expect(sidebar.getByRole('region', { name: '开始学习', exact: true })).toContainText('打开课程');
  23 |   await expect(sidebar.getByRole('region', { name: '继续学习', exact: true })).toHaveCount(0);
  24 |   if (width <= 1000) {
  25 |     await expect(sidebar).toHaveAttribute('aria-modal', 'true');
  26 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(true);
  27 |     await page.keyboard.press('Shift+Tab'); expect(await sidebar.evaluate(node => node.contains(document.activeElement))).toBe(true);
  28 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  29 |     await page.keyboard.press('Escape'); await expect(sidebar).toHaveCount(0);
> 30 |     await expect(page.getByRole('button', { name: '打开学习导航', exact: true })).toBeFocused();
     |                                                                             ^ Error: expect(locator).toBeFocused() failed
  31 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  32 |     await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  33 |   } else {
  34 |     expect((await sidebar.boundingBox())!.width).toBe(240);
  35 |     await sidebar.getByRole('button', { name: '收起学习导航', exact: true }).click(); expect((await sidebar.boundingBox())!.width).toBe(60);
  36 |     await expect(sidebar.getByRole('link', { name: 'Courses', exact: true })).toBeVisible();
  37 |     await page.reload(); await expect(page.getByRole('button', { name: '展开学习导航', exact: true })).toBeVisible();
  38 |     await page.getByRole('button', { name: '展开学习导航', exact: true }).click();
  39 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  40 |   }
  41 |   await sidebar.getByRole('link', { name: 'Courses', exact: true }).click(); await expect(page.getByRole('heading', { name: '我的课程', exact: true })).toBeVisible();
  42 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  43 | });
  44 | test('reference navigation: a real saved classroom opens the exact original session and position from the course library', async ({ page }) => {
  45 |   await enter(page, 1280); await page.getByRole('button', { name: '▶ 学习', exact: true }).first().click();
  46 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  47 |   const original = new URL(page.url()).searchParams.get('session');
  48 |   await page.getByRole('button', { name: '离开课堂', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  49 |   await page.goto('/studio?view=courses'); const resume = page.getByRole('region', { name: '继续学习', exact: true }); await expect(resume).toContainText('社会学想象力');
  50 |   await resume.getByRole('link').click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  51 |   expect(new URL(page.url()).searchParams.get('session')).toBe(original);
  52 | });
  53 | test('reference navigation: resizing an open drawer restores usable desktop controls and releases the original background', async ({ page }) => {
  54 |   await enter(page, 768); await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  55 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toBeVisible(); await page.setViewportSize({ width: 1280, height: 900 });
  56 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toHaveCount(0);
  57 |   await expect(page.getByRole('button', { name: '收起学习导航', exact: true })).toBeVisible();
  58 |   expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  59 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  60 |   await page.getByRole('tab', { name: '练习', exact: true }).click(); await expect(page.getByRole('tabpanel', { name: '练习', exact: true })).toBeVisible();
  61 | });
  62 | 
```