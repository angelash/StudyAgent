# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: original-teaching-fonts.spec.ts >> original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board
- Location: tests\e2e\original-teaching-fonts.spec.ts:49:5

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByRole('dialog', { name: '白板视频', exact: true })
Expected: "ready"
Received: "error"
Timeout:  15000ms

Call log:
  - Expect "toHaveAttribute" getByRole('dialog', { name: '白板视频', exact: true }) with timeout 15000ms
  - waiting for getByRole('dialog', { name: '白板视频', exact: true })
    33 × locator resolved to <div role="dialog" aria-modal="true" aria-label="白板视频" data-original-font-status="error" class="sa-whiteboard-modal wb-sentence-player">…</div>
       - unexpected value "error"

```

```yaml
- dialog "白板视频":
  - text: WHITEBOARD SESSION / 原白板
  - heading "异分母分数加法" [level=2]
  - paragraph: 逐句文字阅读 · 使用估计阅读时长 · 板书按完整要点呈现
  - button "关闭白板": ×
  - alert
  - paragraph: 这次我们从“异分母分数加法”开始，把关键关系拆成看得见的步骤。
  - text: 播放进度（估计阅读）
  - slider "播放进度（估计阅读）": "0"
  - button "上一句" [disabled]: ←
  - button "播放" [disabled]: ▶
  - button "下一句": →
  - text: 1 / 10 句
  - combobox "阅读方式"
  - combobox "播放速度"
  - button "导出视频" [disabled]
  - button "导出字幕"
  - status
  - button "01 异分母分数加法"
  - button "02 先建立概念"
  - button "03 跟着步骤走"
  - button "04 先统一切法，再合并份数"
  - button "05 换一道新题验证"
  - complementary "完整讲稿与要点"
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash, randomUUID } from 'node:crypto';
  3  | import { readFileSync, writeFileSync } from 'node:fs';
  4  | import { join } from 'node:path';
  5  | import { browserEvidence } from './evidence';
  6  | 
  7  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4168') + '/api';
  8  | test.afterEach(async ({ page }) => { await page.unrouteAll({ behavior: 'wait' }); });
  9  | async function board(page: Page) {
  10 |   const key = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + key[0] + '.' + key[1], principal = 'font-fixture-' + randomUUID(), credential = 'Synthetic-fonts-only-20261027';
  11 |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  12 |   async function call(path: string, body: object, token?: string, method = 'POST') {
  13 |     const response = await fetch(api + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: JSON.stringify(body) });
  14 |     expect(response.ok, path + ' ' + response.status).toBe(true); return (await response.json()).data;
  15 |   }
  16 |   const actor = await call('/auth/register', { principal, credential }), child = (await call('/students', { nickname: '匿名字体白板', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token)).profile.id;
  17 |   await call('/students/' + child + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15 }, actor.token, 'PUT');
  18 |   const command = { studentId: child, subject: 'math', prompt: '异分母分数加法：先理解单位，再通分。', atomId: 'core:math:fractionadd' }, preview = await call('/learning/studio/whiteboards/preview', command, actor.token);
  19 |   const saved = await call('/learning/studio/whiteboards', { ...command, fingerprint: preview.fingerprint, requestKey: randomUUID() }, actor.token);
  20 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  21 |   return '/studio?student=' + child + '&subject=math&whiteboard=' + saved.id;
  22 | }
  23 | 
  24 | test('original fonts: real captured Latin and Chinese faces decode before a board is measured, played or exported', async ({ page }) => {
  25 |   const url = await board(page), requests: string[] = [];
  26 |   page.on('request', request => { if (request.resourceType() === 'font') requests.push(request.url()); });
  27 |   await page.addInitScript(() => {
  28 |     const original = CanvasRenderingContext2D.prototype.fillText;
  29 |     (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts = [];
  30 |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) {
  31 |       (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.push(this.font); return original.apply(this, args);
  32 |     };
  33 |   });
  34 |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  35 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  36 |   const loaded = await page.evaluate(() => [...new Set(Array.from(document.fonts).filter(face => face.status === 'loaded').map(face => face.family.replace(/^['"]|['"]$/g, '')))]);
  37 |   for (const family of ['Virgil', 'Xiaolai', 'Satoshi-Regular', 'Satoshi-Medium', 'Satoshi-Bold', 'MiSans']) expect(loaded).toContain(family);
  38 |   await expect.poll(() => page.evaluate(() => (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.some(font => /Virgil/.test(font) && /Xiaolai/.test(font)))).toBe(true);
  39 |   expect(requests.length).toBeGreaterThan(4); for (const request of requests) expect(new URL(request).pathname).toMatch(/^\/reference\/hyperknow\//);
  40 |   const manifest = JSON.parse(readFileSync(join(process.cwd(), 'apps/web/public/reference/hyperknow/asset-manifest.json'), 'utf8'));
  41 |   for (const request of [...new Set(requests)].slice(0, 8)) {
  42 |     const entry = manifest.files.find((entry: { publicPath: string }) => entry.publicPath === new URL(request).pathname); expect(entry).toBeTruthy();
  43 |     const response = await page.request.get(request), bytes = await response.body(); expect(response.status()).toBe(200); expect(createHash('sha256').update(bytes).digest('hex')).toBe(entry.sha256);
  44 |   }
  45 |   writeFileSync(join(browserEvidence('original-teaching-fonts'), 'actual-loaded-fonts.json'), JSON.stringify({ loaded, requests, originalFontManifest: manifest.captureFingerprint }, null, 2) + '\n');
  46 |   await page.screenshot({ path: join(browserEvidence('original-teaching-fonts'), 'actual-board-fonts.png'), fullPage: true });
  47 | });
  48 | 
  49 | test('original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board', async ({ page }) => {
  50 |   const url = await board(page); let blocked = false;
  51 |   await page.route('**/reference/hyperknow/assets/woff2/Xiaolai-*.woff2*', async route => { if (!blocked) { blocked = true; await route.abort('failed'); } else await route.continue(); });
  52 |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  53 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'error'); expect(blocked).toBe(true); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeDisabled(); await expect(dialog.getByRole('button', { name: '导出视频', exact: true })).toBeDisabled();
  54 |   await page.unrouteAll({ behavior: 'wait' }); await dialog.getByRole('button', { name: '重新准备板书字体' }).click();
> 55 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
     |                        ^ Error: expect(locator).toHaveAttribute(expected) failed
  56 |   expect(page.url()).toContain(new URL(url, 'http://fixture').searchParams.get('whiteboard')!);
  57 | });
  58 | 
```