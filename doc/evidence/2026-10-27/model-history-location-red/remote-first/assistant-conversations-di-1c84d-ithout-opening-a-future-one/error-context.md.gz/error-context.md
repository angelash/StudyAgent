# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: assistant-conversations.spec.ts >> diagnostic rules stay deterministic and history locates an answered frozen question without opening a future one
- Location: tests/e2e/assistant-conversations.spec.ts:176:5

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /item=answer-atom-qa_8a5c2d43-f910-473b-b13d-a647e0b48113-q3-item/
Received string:  "http://localhost:3107/student/assessment?studentId=student_256e4318-035e-4ad5-8ebd-e4671a36eb51&subject=math&session=diagnostic_7b4310b5-0426-4cbe-bec5-4400c072fd5a"
Timeout: 15000ms

Call log:
  - Expect "toHaveURL" with timeout 15000ms
    34 × locator resolved to <html lang="zh-CN">…</html>
       - unexpected value "http://localhost:3107/student/assessment?studentId=student_256e4318-035e-4ad5-8ebd-e4671a36eb51&subject=math&session=diagnostic_7b4310b5-0426-4cbe-bec5-4400c072fd5a"

```

```yaml
- main:
  - link "学习观察室":
    - /url: /
  - navigation "主要导航":
    - link "学习首页":
      - /url: /learn?subject=math&student=student_256e4318-035e-4ad5-8ebd-e4671a36eb51
    - link "学习工作台":
      - /url: /studio?subject=math&student=student_256e4318-035e-4ad5-8ebd-e4671a36eb51
    - link "家长空间":
      - /url: /parent/dashboard?subject=math&studentId=student_256e4318-035e-4ad5-8ebd-e4671a36eb51
    - link "知识诊断":
      - /url: /student/assessment?subject=math&studentId=student_256e4318-035e-4ad5-8ebd-e4671a36eb51
    - link "今日学习":
      - /url: /student/today?subject=math&studentId=student_256e4318-035e-4ad5-8ebd-e4671a36eb51
    - link "题卷资料":
      - /url: /library?subject=math&studentId=student_256e4318-035e-4ad5-8ebd-e4671a36eb51
  - link "资料管理":
    - /url: /parent/data
  - button "退出"
  - complementary:
    - text: LEARNING / INSIGHT
    - heading "把知识 学扎实。" [level=1]:
      - text: 把知识
      - emphasis: 学扎实。
    - paragraph: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
    - list:
      - listitem: 01 确认学习进度
      - listitem: 02 完成一组评测
      - listitem: 03 看懂知识与原因
      - listitem: 04 指导、复测与复盘
    - text: 匿
    - strong: 匿名助教验收
    - text: 3年级 · 数学
    - button "返回学习进度与历史"
  - text: 02 / 一次只看一步
  - heading "合成输入验收" [level=2]
  - text: 2 / 4
  - paragraph: 先独立想一想。暂时不会也可以如实记录。
  - progressbar "评测进度"
  - text: 第1小组 尚未填写
  - group "本题作答":
    - text: 本题作答 合成题型验收 numeric_blank · 3
    - strong: 输入数字或分数
    - textbox "数字或分数答案":
      - /placeholder: 请输入数字或分数，例如 0.5 或 1/2
  - button "给我一点提示"
  - button "暂时不会"
  - button "提交，下一步 →"
  - button "题目显示不清或有问题，先跳过"
  - button "保存草稿，休息一下"
  - button "提前结束本组"
  - button "刷新当前状态"
  - paragraph: 首次提交会保留为测量证据；提示记录会单独计入。随时可以离开，回来继续。
  - button "收起学习观察助教" [expanded]: 学习观察助教 提示会与独立作答分开记录
  - text: 历史对话
  - button "查找历史"
  - complementary:
    - paragraph: 正在回看已保存的提问和回答。
    - button "返回当前学习对话"
    - button "回到相关学习位置"
  - text: 当前会话关键词
  - textbox "检索当前对话"
  - button "查找这段对话" [disabled]
  - button "恢复最近消息"
  - log "当前学习对话":
    - article:
      - strong: 我
      - paragraph: DIAGNOSTIC_9b07f51e-53c5-47f2-a672-c299c2af8365
    - article:
      - strong: 学习助教
      - paragraph: 我们先看“合成输入验收”。保留完整输入和恢复过程。先用自己的话说一说题目要解决什么，再列出已知条件。你可以告诉我卡在哪一步；完成后再用一道新题检查。
      - text: 根据学习记录给出的引导 本题已记录使用助教提示。
  - region "提问任务":
    - status: 回答已保存
    - text: 本地规则引导
    - group: 原问题与记录
  - group: 提问记录（已读取 1 条）
  - button "下载提问副本"
- alert
```

# Test source

```ts
  81  | test('a saved question survives collapse and refresh without duplicate creation or retroactive first-answer evidence',async({page})=>{
  82  |   const f=await setup(page),posts:any[]=[];page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(r.url()))posts.push(r.postDataJSON());});
  83  |   const message='[assistant-pause-once] '+crypto.randomUUID()+' 请围绕条件给下一步提示。';await send(page,message);await expect(task(page)).toContainText(message);await expect(task(page)).toHaveAttribute('data-status',/queued|running/);
  84  |   await page.getByRole('button',{name:'收起学习小助教',exact:true}).click();await page.reload();await page.getByRole('button',{name:'打开学习小助教',exact:true}).click();await expect(task(page)).toContainText(message);
  85  |   await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:25000});expect(posts).toHaveLength(1);expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(2);
  86  |   await expect(panel(page).locator('.assistant-message').first()).toHaveClass(/from-user/);await expect(panel(page).locator('.assistant-message').last()).toHaveClass(/from-assistant/);
  87  |   for(const width of [1440,768,390]){await page.setViewportSize({width,height:width===390?844:1000});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await shot(page,'saved-conversation-'+width);}
  88  |   await page.getByRole('button',{name:'收起学习小助教',exact:true}).click();await page.getByLabel('数字或分数答案').fill('6');await page.getByRole('button',{name:'完成这一题 →',exact:true}).click();await expect(page.locator('.daily-feedback')).toContainText('使用了 1 级提示');
  89  | });
  90  | test('a lost creation receipt restores the same original command from server state without sending it again',async({page})=>{
  91  |   const f=await setup(page),commands:any[]=[];let release!:()=>void;const gate=new Promise<void>(r=>release=r);
  92  |   await page.route('**/api/ai/assistant/sessions/*/turns',async route=>{if(route.request().method()!=='POST')return route.continue();commands.push(route.request().postDataJSON());const response=await route.fetch();await gate;try{await route.fulfill({response});}catch{/* Page reloaded with its unacknowledged command retained. */}});
  93  |   try{const text='[assistant-pause-once] '+crypto.randomUUID()+' 我的问题需要保留完整原文。';await send(page,text);await expect(page.getByLabel('待确认提问')).toContainText(text);await expect.poll(()=>commands.length).toBe(1);
  94  |     await page.reload();await page.getByRole('button',{name:'打开学习小助教',exact:true}).click();await expect(task(page)).toContainText(text);release();
  95  |     await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:25000});expect(commands).toHaveLength(1);
  96  |     const turns=await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns');expect(turns.turns).toHaveLength(1);expect(turns.turns[0].requestKey).toBe(commands[0].requestKey);
  97  |     await expect(page.getByLabel('想一起看看什么')).toHaveValue('');
  98  |   }finally{release();}
  99  | });
  100 | test('running cancellation settles after refresh and retry retains the original model despite a new composer selection',async({page})=>{
  101 |   const f=await setup(page);await send(page,'[assistant-pause-once] '+crypto.randomUUID()+' 暂停后再核对这个条件。');
  102 |   await expect(task(page)).toHaveAttribute('data-status','running');await task(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','cancelled',{timeout:10000});
  103 |   expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(0);await page.reload();await open(page);
  104 |   await page.getByRole('combobox',{name:'选择大模型',exact:true}).selectOption('glm-5.3-flash');await task(page).getByRole('button',{name:'重试原任务',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:20000});
  105 |   const turns=(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns;expect(turns).toHaveLength(1);expect(turns[0].task.generation).toBe(2);expect(turns[0].modelId).toBe('deepseek-v4-flash');
  106 |   await expect(page.getByRole('combobox',{name:'选择大模型',exact:true})).toHaveValue('glm-5.3-flash');await shot(page,'retry-original-model');
  107 | });
  108 | test('invalid model evidence remains a visible failure and an explicit retry publishes one validated answer',async({page})=>{
  109 |   const f=await setup(page);await send(page,'[assistant-invalid-once] '+crypto.randomUUID()+' 请按证据解释。');await expect(task(page)).toHaveAttribute('data-status','failed',{timeout:15000});
  110 |   expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(0);await expect(panel(page)).not.toContainText('synthetic-unsupported-evidence');
  111 |   await task(page).getByRole('button',{name:'重试原任务',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:15000});expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(2);
  112 | });
  113 | test('history reads beyond fifty messages, locates an old search match and returns to its actual practice question',async({page})=>{
  114 |   const f=await setup(page),marker='HISTORY_'+crypto.randomUUID(),seed=await call(f.actor,'/qa/assistant/seed-history',{sessionId:f.assistantId,count:75,marker});
  115 |   await page.reload();await open(page);await expect(panel(page).locator('.assistant-message')).toHaveCount(25);
  116 |   await panel(page).getByRole('button',{name:'更早的消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(50);
  117 |   await panel(page).getByRole('button',{name:'更早的消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(75);
  118 |   await panel(page).getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill(marker+' · 匿名历史第0条');await panel(page).getByRole('button',{name:'搜索历史',exact:true}).click();
  119 |   await expect(page.getByLabel('助教历史检索')).toContainText('找到 1 段对话');await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  120 |   await expect(page.locator('[data-message-id="'+seed.ids[0]+'"]')).toBeInViewport();await expect(page.getByRole('button',{name:'返回当前学习对话',exact:true})).toBeVisible();
  121 |   await page.setViewportSize({width:768,height:1000});await shot(page,'history-old-message-768');
  122 |   await page.getByRole('button',{name:'回到相关学习位置',exact:true}).click();await expect(page).toHaveURL(new RegExp('question='+encodeURIComponent(f.itemId)));await expect(page.getByLabel('数字或分数答案')).toBeVisible();
  123 | });
  124 | test('unavailable local storage keeps the full question editable, exportable and recoverable once the server accepts it',async({page})=>{
  125 |   const f=await setup(page);await page.evaluate(()=>{Storage.prototype.setItem=()=>{throw new DOMException('QA storage unavailable','QuotaExceededError');};});
  126 |   const text='[assistant-pause-once] '+crypto.randomUUID()+' '+('完整问题需要保留。'.repeat(20));await page.getByLabel('想一起看看什么').fill(text);await expect(panel(page)).toContainText('本机未能暂存提问');
  127 |   await page.getByRole('button',{name:'收起学习小助教',exact:true}).click();await open(page);await expect(page.getByLabel('想一起看看什么')).toHaveValue(text);
  128 |   const copy=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载提问副本',exact:true}).click();const json=JSON.parse(readFileSync((await (await copy).path())!,'utf8'));expect(json.input).toBe(text);expect(JSON.stringify(json)).not.toMatch(/token|gradingConfig|standardAnswer/);
  129 |   await panel(page).getByRole('button',{name:'一起想一想 →',exact:true}).click();await expect(task(page)).toContainText(text);await page.reload();await page.getByRole('button',{name:'打开学习小助教',exact:true}).click();await expect(task(page)).toContainText(text);
  130 |   await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:25000});expect((await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns).toHaveLength(1);
  131 | });
  132 | test('a forged cache owned by another account is ignored without exposing or sending its text',async({page})=>{
  133 |   await setup(page);await page.evaluate(()=>{const key=Object.keys(localStorage).find(k=>k.startsWith('studyagent.assistant.v1.'))!,value=JSON.parse(localStorage.getItem(key)!);value.ownerId='another-owner';value.input='FOREIGN_PRIVATE_DRAFT';value.pending={requestKey:crypto.randomUUID(),message:'FOREIGN_PRIVATE_PENDING',modelId:'deepseek-v4-flash',contextVersion:'a'.repeat(64)};localStorage.setItem(key,JSON.stringify(value));});
  134 |   let posts=0;page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(r.url()))posts++;});await page.reload();await open(page);
  135 |   await expect(panel(page)).not.toContainText('FOREIGN_PRIVATE');await expect(page.getByLabel('想一起看看什么')).toHaveValue('');expect(posts).toBe(0);
  136 | });
  137 | 
  138 | test('stopping local waiting leaves the real server task running until explicit cancellation',async({page})=>{
  139 |   const f=await setup(page);let cancels=0;page.on('request',r=>{if(r.method()==='POST'&&r.url().endsWith('/cancel'))cancels++;});
  140 |   await send(page,'[assistant-hold] '+crypto.randomUUID()+' 先保留原任务。');await expect(task(page)).toHaveAttribute('data-status','running');
  141 |   await panel(page).getByRole('button',{name:'停止等待',exact:true}).click();await expect(panel(page)).toContainText('已停止本次等待');
  142 |   const original=(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns[0];expect(original.status).toBe('running');expect(cancels).toBe(0);
  143 |   await panel(page).getByRole('button',{name:'读取最新状态',exact:true}).click();await task(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','cancelled');expect(cancels).toBe(1);
  144 | });
  145 | 
  146 | test('conversation search pages beyond the first results and recovers from an empty result',async({page})=>{
  147 |   const f=await setup(page);await call(f.actor,'/qa/assistant/seed-history',{sessionId:f.assistantId,count:75});await page.reload();await open(page);
  148 |   await page.getByLabel('检索当前对话', {exact:true}).fill('合成历史');await panel(page).getByRole('button',{name:'查找这段对话',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(25);
  149 |   await panel(page).getByRole('button',{name:'更早的消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(50);
  150 |   await page.getByLabel('检索当前对话', {exact:true}).fill('NO_MATCH_'+crypto.randomUUID());await panel(page).getByRole('button',{name:'查找这段对话',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(0);
  151 |   await panel(page).getByRole('button',{name:'恢复最近消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(25);
  152 | });
  153 | 
  154 | test('identity recovery: one failed identity request retries without asking the signed-in learner to log in again',async({page})=>{
  155 |   await setup(page);await page.goto('/student/today');await expect(page.getByRole('link',{name:'资料管理',exact:true})).toBeVisible();let reads=0;await page.route('**/api/auth/me',async route=>{if(route.request().method()!=='GET'){await route.continue();return;}reads++;if(reads===1)await route.abort('failed');else await route.continue();});
  156 |   await page.reload();await open(page);expect(reads).toBe(2);await expect(panel(page)).not.toContainText('请先进入学习或登录家长账号');await expect(page.getByRole('alert',{name:'身份确认未完成',exact:true})).toHaveCount(0);
  157 | });
  158 | 
  159 | test('identity recovery: a persistent connection failure offers a bounded manual retry and reuses the existing saved conversation',async({page})=>{
  160 |   const f=await setup(page);await page.goto('/student/today');await expect(page.getByRole('link',{name:'资料管理',exact:true})).toBeVisible();let reads=0,signIns=0;page.on('request',request=>{if(request.method()==='POST'&&new URL(request.url()).pathname==='/api/auth/login')signIns++;});await page.route('**/api/auth/me',async route=>{if(route.request().method()!=='GET'){await route.continue();return;}reads++;if(reads<=2)await route.abort('failed');else await route.continue();});
  161 |   await page.reload();const warning=page.getByRole('alert',{name:'身份确认未完成',exact:true});await expect(warning).toBeVisible();expect(reads).toBe(2);await page.getByRole('button',{name:/^打开学习(?:小助教|观察助教)$/}).click();await expect(page.getByRole('status').filter({hasText:'正在确认学习身份…'})).toBeVisible();await expect(page.getByLabel('想一起看看什么')).toHaveCount(0);await warning.getByRole('button',{name:'重新确认登录',exact:true}).click();await expect(page.getByLabel('想一起看看什么')).toBeEnabled();await expect(warning).toHaveCount(0);expect(reads).toBe(3);expect(signIns).toBe(0);
  162 |   await page.unroute('**/api/auth/me');await page.goto(f.href);await open(page);const cached=await page.evaluate((id)=>Object.keys(localStorage).filter(key=>key.startsWith('studyagent.assistant.v1.')).map(key=>JSON.parse(localStorage.getItem(key)!)).find(value=>value.sessionId===id)?.sessionId,f.assistantId);expect(cached).toBe(f.assistantId);
  163 | });
  164 | 
  165 | test('identity recovery: an explicit unauthenticated response clears private identity without retrying or calling it a connection failure',async({page})=>{
  166 |   await setup(page);await page.goto('/student/today');await expect(page.getByRole('link',{name:'资料管理',exact:true})).toBeVisible();let reads=0;await page.route('**/api/auth/me',async route=>{if(route.request().method()!=='GET'){await route.continue();return;}reads++;await route.fulfill({status:401,json:{data:null,error:{code:'unauthorized',message:'合成登录已失效'}}});});await page.reload();await page.getByRole('button',{name:/^打开学习(?:小助教|观察助教)$/}).click();await expect(page.getByRole('status').filter({hasText:'请先进入学习或登录家长账号'})).toBeVisible();await expect(page.getByRole('alert',{name:'身份确认未完成',exact:true})).toHaveCount(0);expect(reads).toBe(1);await expect(page.getByLabel('想一起看看什么')).toHaveCount(0);
  167 | });
  168 | 
  169 | test('reviewing an earlier task preserves selection while the new task finishes in the background',async({page})=>{
  170 |   const f=await setup(page);const original='EARLIER_'+crypto.randomUUID();await send(page,original);await expect(task(page)).toHaveAttribute('data-status','completed');
  171 |   await send(page,'[assistant-pause-once] '+crypto.randomUUID()+' 保留后台提问状态。');await expect(task(page)).toHaveAttribute('data-status','running');
  172 |   await panel(page).locator('.assistant-task-history summary').click();await panel(page).locator('.assistant-task-history').getByRole('button',{name:new RegExp(original)}).click();await expect(task(page)).toContainText(original);
  173 |   await expect(page.getByLabel('想一起看看什么')).toBeEnabled({timeout:20000});await expect(task(page)).toContainText(original);expect((await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns.every((t:any)=>t.status==='completed')).toBe(true);await expect(panel(page).locator('.assistant-message')).toHaveCount(4);
  174 | });
  175 | 
  176 | test('diagnostic rules stay deterministic and history locates an answered frozen question without opening a future one',async({page})=>{
  177 |   const f=await setup(page,'diagnostic'),message='DIAGNOSTIC_'+crypto.randomUUID();await send(page,message);await expect(task(page)).toHaveAttribute('data-status','completed');await expect(task(page)).toContainText('规则');
  178 |   await page.getByRole('button',{name:'收起学习观察助教',exact:true}).click();await page.getByLabel('数字或分数答案').fill('6');await page.getByRole('button',{name:'提交，下一步',exact:false}).click();
  179 |   await expect.poll(async()=>(await call(f.actor,'/diagnostics/sessions/'+f.sessionId)).answeredCount).toBe(1);await expect(page.getByLabel('数字或分数答案')).toBeVisible();
  180 |   await open(page);await panel(page).getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill(message);await panel(page).getByRole('button',{name:'搜索历史',exact:true}).click();await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
> 181 |   await page.getByRole('button',{name:'回到相关学习位置',exact:true}).click();await expect(page).toHaveURL(new RegExp('item='+encodeURIComponent(f.itemId)));await expect(page.getByRole('region',{name:'从历史对话定位的题目'})).toContainText('合成题型验收 numeric_blank');await expect(page.getByLabel('数字或分数答案')).toHaveCount(0);await shot(page,'diagnostic-history-readonly');
      |                                                                                          ^ Error: expect(page).toHaveURL(expected) failed
  182 |   await page.getByRole('button',{name:'回到当前核查进度',exact:true}).click();await expect(page.getByLabel('数字或分数答案')).toBeVisible();
  183 |   const state=await call(f.actor,'/diagnostics/sessions/'+f.sessionId),future=state.items[2].id;await page.goto(f.href+'&item='+encodeURIComponent(future));await expect(page.getByRole('region',{name:'从历史对话定位的题目'})).toHaveCount(0);await expect(page.getByText('这道题尚未开放或不属于原评测，请按当前核查顺序继续。')).toBeVisible();expect((await call(f.actor,'/diagnostics/sessions/'+f.sessionId)).answeredCount).toBe(1);
  184 | });
  185 | 
```