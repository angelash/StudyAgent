# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: teaching-tools.spec.ts >> teaching tools: oversized original text is rejected without losing or truncating the form or making a provider call
- Location: tests\e2e\teaching-tools.spec.ts:128:5

# Error details

```
TimeoutError: locator.fill: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('.tt-composer').getByLabel('完整题干', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]: 学习观察室 · 看见孩子怎样学会
  - main [ref=e3]:
    - generic [ref=e4]:
      - link "学习观察室" [ref=e5] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=e6]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=e7]:
        - link "学习首页" [ref=e8] [cursor=pointer]:
          - /url: /learn?subject=math
        - link "学习工作台" [ref=e9] [cursor=pointer]:
          - /url: /studio?subject=math
        - link "家长空间" [ref=e10] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math
        - link "知识诊断" [ref=e11] [cursor=pointer]:
          - /url: /student/assessment?subject=math
        - link "今日学习" [ref=e12] [cursor=pointer]:
          - /url: /student/today?subject=math
        - link "题卷资料" [ref=e13] [cursor=pointer]:
          - /url: /library?subject=math
      - generic [ref=e14]:
        - link "教研后台" [ref=e15] [cursor=pointer]:
          - /url: /admin/curriculum
        - link "AI教研" [ref=e16] [cursor=pointer]:
          - /url: /admin/ai-tools
        - link "账号权限" [ref=e17] [cursor=pointer]:
          - /url: /admin/accounts
        - button "退出" [ref=e18] [cursor=pointer]
    - generic [ref=e19]:
      - navigation "教研导航" [ref=e20]:
        - link "知识与覆盖" [ref=e21] [cursor=pointer]:
          - /url: /admin/curriculum
        - link "AI 教研草稿" [ref=e22] [cursor=pointer]:
          - /url: /admin/ai-tools
        - link "作答复核" [ref=e23] [cursor=pointer]:
          - /url: /admin/reviews
        - link "内容管理" [ref=e24] [cursor=pointer]:
          - /url: /admin/content
      - generic [ref=e25]:
        - generic [ref=e26]:
          - text: TEACHING STUDIO / PRIVATE DRAFTS
          - heading "把一次作答，看得更清楚。" [level=1] [ref=e27]
          - paragraph [ref=e28]: 保留完整条件与推导，比较可能的解释，再用新证据核对。这里产生的是待复核建议。
        - complementary [ref=e29]:
          - generic [ref=e30]: 教研草稿
          - generic [ref=e31]: 尚未人工核对
          - paragraph [ref=e32]: 不会自动写入评分、能力判断或指导计划。
      - generic [ref=e33]:
        - generic [ref=e34]:
          - tablist "教研用途" [ref=e35]:
            - tab "答案分析建议" [selected] [ref=e36] [cursor=pointer]
            - tab "提示草稿" [ref=e37] [cursor=pointer]
          - region "答案分析输入" [ref=e38]:
            - generic [ref=e39]:
              - generic [ref=e40]: 01 / 输入
              - button "下载完整原稿 ↗" [ref=e41] [cursor=pointer]
            - group "完整教研输入" [ref=e42]:
              - generic [ref=e44]:
                - button "自编临时题" [pressed] [ref=e45] [cursor=pointer]
                - button "选择题库原题" [ref=e46] [cursor=pointer]
              - generic [ref=e47]:
                - generic [ref=e48]:
                  - text: 草稿名称
                  - textbox "草稿名称" [ref=e49]:
                    - /placeholder: 给这份临时题起个名字
                    - text: 匿名平均对象的完整原稿
                - generic [ref=e50]:
                  - text: 学科或主题
                  - textbox "学科或主题" [ref=e51]: 数学
              - generic [ref=e52]:
                - text: 完整题干
                - textbox "完整题干" [ref=e53]:
                  - /placeholder: 保留所有条件、单位与问题。
                  - text: 三人与两人的总分分别18与14，求五人平均分。原题尾行条件保持。
              - generic [ref=e54]:
                - generic [ref=e55]:
                  - generic [ref=e56]:
                    - text: 参考答案格式
                    - combobox "参考答案格式" [ref=e57]:
                      - option "普通文字" [selected]
                      - option "结构化 JSON"
                  - generic [ref=e58]:
                    - checkbox "暂不清楚参考答案" [ref=e59]
                    - text: 暂不清楚参考答案
                - generic [ref=e60]:
                  - text: 参考答案
                  - textbox "参考答案" [ref=e61]:
                    - /placeholder: 完整保留原文与推导过程。
                    - text: "6.4"
              - generic [ref=e62]:
                - text: 参考解析（可选）
                - textbox "参考解析（可选）" [ref=e63]: 先合计总分32，再以总人数5作为分母。
              - group [ref=e64]:
                - generic "补充表格、公式与答案结构" [ref=e65] [cursor=pointer]
              - generic [ref=e66]:
                - generic [ref=e67]:
                  - generic [ref=e68]:
                    - text: 待核对作答格式
                    - combobox "待核对作答格式" [ref=e69]:
                      - option "普通文字" [selected]
                      - option "结构化 JSON"
                  - generic [ref=e70]:
                    - checkbox "暂不清楚待核对作答" [ref=e71]
                    - text: 暂不清楚待核对作答
                - generic [ref=e72]:
                  - text: 待核对作答
                  - textbox "待核对作答" [active] [ref=e73]:
                    - /placeholder: 完整保留原文与推导过程。
                    - text: 18+14=32；32/2=16。保留首次原文尾行。
              - generic [ref=e74]:
                - generic [ref=e75]:
                  - generic [ref=e76]: 模型
                  - combobox "选择大模型" [ref=e77] [cursor=pointer]:
                    - option "Auto · 平台默认 DeepSeek V4.1 Flash" [selected]
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认"
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                - generic [ref=e78]: 尚未进行文字检查
                - paragraph [ref=e80]:
                  - generic [ref=e81]: DeepSeek V4.1 Flash
                  - generic [ref=e82]: 使用平台默认：DeepSeek V4.1 Flash
            - generic [ref=e83]:
              - button "预检完整输入" [ref=e84] [cursor=pointer]
              - button "确认输入并生成草稿" [disabled] [ref=e85]
            - group [ref=e86]:
              - generic "本机其他标签页的原稿" [ref=e87] [cursor=pointer]
        - complementary "本人教研历史" [ref=e88]:
          - generic [ref=e89]:
            - generic [ref=e90]: 本人原记录
            - button "刷新" [ref=e91] [cursor=pointer]
          - generic [ref=e92]:
            - text: 用途
            - combobox "用途" [ref=e93]:
              - option "全部" [selected]
              - option "答案分析"
              - option "提示草稿"
          - group [ref=e94]:
            - generic "按时间查找" [ref=e95] [cursor=pointer]
          - generic [ref=e96]:
            - text: 还没有匹配记录
            - paragraph [ref=e97]: 预检不会生成建议。核对输入后，可明确创建一份草稿。
          - generic [ref=e98]:
            - button "上一页" [disabled] [ref=e99]
            - generic [ref=e100]: 第 1 页
            - button "下一页" [disabled] [ref=e101]
```

# Test source

```ts
  29  |   await composer(page).getByLabel('参考解析（可选）', { exact: true }).fill('先合计总分32，再以总人数5作为分母。');
  30  |   if (await composer(page).getByLabel('待核对作答', { exact: true }).count()) await composer(page).getByLabel('待核对作答', { exact: true }).fill('18+14=32；32/2=16。保留首次原文尾行。');
  31  |   await expect(composer(page).getByLabel('选择大模型', { exact: true })).toBeEnabled();
  32  | }
  33  | async function preview(page: Page) { await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).getByRole('region', { name: '完整输入预检', exact: true })).toBeVisible(); }
  34  | async function generate(page: Page) { await composer(page).getByRole('button', { name: '确认输入并生成草稿', exact: true }).click(); await expect(detail(page)).toBeVisible(); return new URL(page.url()).searchParams.get('run')!; }
  35  | async function done(page: Page) { await expect(detail(page).getByText('草稿已生成', { exact: true })).toBeVisible({ timeout: 25000 }); }
  36  | 
  37  | for (const width of [390, 768, 1280]) test(`teaching tools: complete analysis, original input and unreviewed result at ${width}`, async ({ page }) => {
  38  |   const f = await enter(page, width); await fill(page); await expect(composer(page).getByLabel('选择大模型')).toHaveValue('auto');
  39  |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); await preview(page);
  40  |   await expect(composer(page).getByRole('region', { name: '完整输入预检' })).toContainText('原题尾行条件保持。');
  41  |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  42  |   const runId = await generate(page); await done(page); await expect(detail(page)).toContainText('尚未人工核对'); await expect(detail(page)).toContainText('单次回答尚不足以确定稳定的能力原因。');
  43  |   const run = await f.call('/ai/teaching-tools/runs/' + runId); expect(run).toMatchObject({ status: 'completed', modelId: 'deepseek-v4-flash', advisoryOnly: true, reviewRequired: true });
  44  |   expect(run.snapshot.answer).toContain('保留首次原文尾行'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  45  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  46  |   await page.screenshot({ path: evidence + '/analysis-' + width + '.png', fullPage: true }); await page.reload(); await done(page);
  47  |   expect(new URL(page.url()).searchParams.get('run')).toBe(runId); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('匿名平均对象的完整原稿');
  48  | });
  49  | 
  50  | test('teaching tools: bank preflight shows actual table and formula, freezing the server original version and structured answer', async ({ page }) => {
  51  |   const f = await enter(page); await composer(page).getByRole('button', { name: '选择题库原题', exact: true }).click();
  52  |   await composer(page).getByLabel('查找题目').fill(f.questionId); await composer(page).locator('.tt-question-list>button').filter({ hasText: f.questionId }).click();
  53  |   await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); await composer(page).getByLabel('待核对作答', { exact: true }).fill(JSON.stringify({ steps: ['18+14=32', '32/2=16'], result: 16 }));
  54  |   await preview(page); const panel = composer(page).getByRole('region', { name: '完整输入预检' });
  55  |   await expect(panel.getByRole('table')).toBeVisible(); await expect(panel.locator('.katex')).toBeVisible(); await expect(panel).toContainText('原文版本 3');
  56  |   const id = await generate(page); await done(page); const run = await f.call('/ai/teaching-tools/runs/' + id);
  57  |   expect(run.snapshot.source).toMatchObject({ kind: 'question_bank', questionId: f.questionId }); expect(run.snapshot.question.originalDocument.version).toBe(3);
  58  |   expect(run.snapshot.question.originalDocument.blocks.map((block: any) => block.type)).toEqual(['text', 'table', 'math_display']); expect(run.snapshot.answer.steps[1]).toBe('32/2=16');
  59  | });
  60  | 
  61  | test('teaching tools: hint failure stays explicit and a retry uses the frozen original model after changing the composer', async ({ page }) => {
  62  |   const f = await enter(page); await page.getByRole('tab', { name: '提示草稿', exact: true }).click(); await fill(page, '分母提示草稿');
  63  |   await composer(page).getByLabel('帮助层级').selectOption('2'); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  64  |   await f.call('/qa/teaching-tools/behavior', { mode: 'fail_once' }); await preview(page); const id = await generate(page);
  65  |   await expect(detail(page).getByText('本次未完成', { exact: true })).toBeVisible(); await expect(detail(page).getByText('先把全部人数逐个列出来，再解释要平均的是谁。', { exact: true })).toHaveCount(0);
  66  |   await composer(page).getByLabel('选择大模型').selectOption('gpt-6.1-sol'); await detail(page).getByRole('button', { name: '使用原模型重试 · Claude Sonnet 5', exact: true }).click(); await done(page);
  67  |   const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.modelId).toBe('claude-sonnet-5'); expect(run.result.hint.suggestedLevel).toBe(2);
  68  |   expect((await f.call('/qa/teaching-tools/observations')).calls.map((item: any) => item.modelId)).toEqual(['claude-sonnet-5', 'claude-sonnet-5']);
  69  | });
  70  | 
  71  | test('teaching tools: lost creation acknowledgement restores the same original command after reload without duplicate generation', async ({ page }) => {
  72  |   const f = await enter(page); await fill(page, '原命令必须只生成一次'); await preview(page);
  73  |   let posts = 0; await page.route('**/api/ai/teaching-tools/runs', async route => { if (route.request().method() !== 'POST') return route.continue(); posts++; await route.fetch(); await route.abort('failed'); });
  74  |   await composer(page).getByRole('button', { name: '确认输入并生成草稿', exact: true }).click(); await expect(composer(page).getByRole('button', { name: '恢复原请求', exact: true })).toBeVisible();
  75  |   await expect(composer(page).getByLabel('选择大模型')).toBeEnabled(); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  76  |   await page.unroute('**/api/ai/teaching-tools/runs'); await page.reload(); await composer(page).getByRole('button', { name: '恢复原请求', exact: true }).click(); await done(page);
  77  |   expect(posts).toBe(1); const list = await f.call('/ai/teaching-tools/runs'); expect(list.runs).toHaveLength(1); expect(list.runs[0].modelId).toBe('deepseek-v4-flash');
  78  |   await expect(composer(page).getByLabel('选择大模型')).toHaveValue('claude-sonnet-5'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  79  | });
  80  | 
  81  | test('teaching tools: two tabs retain their own complete drafts and copying another preserves the current version', async ({ page, context }) => {
  82  |   await enter(page); await fill(page, 'FIRST_DOCUMENT_COMPLETE_TAIL'); const second = await context.newPage(); await second.goto('/admin/ai-tools'); await fill(second, 'SECOND_DOCUMENT_COMPLETE_TAIL');
  83  |   await page.reload(); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  84  |   await second.reload(); await expect(composer(second).getByLabel('草稿名称')).toHaveValue('SECOND_DOCUMENT_COMPLETE_TAIL');
  85  |   await composer(second).getByText('本机其他标签页的原稿', { exact: true }).click();
  86  |   await composer(second).locator('.tt-copies article').filter({ hasText: 'FIRST_DOCUMENT_COMPLETE_TAIL' }).first().getByRole('button', { name: '载入这个副本', exact: true }).click();
  87  |   await expect(composer(second).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  88  |   const titles = await second.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.form.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).form.title));
  89  |   expect(titles).toContain('FIRST_DOCUMENT_COMPLETE_TAIL'); expect(titles).toContain('SECOND_DOCUMENT_COMPLETE_TAIL'); await second.close();
  90  | });
  91  | 
  92  | test('teaching tools: failed local storage blocks navigation and logout until the complete original input is downloaded', async ({ page }) => {
  93  |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.teaching-tool.')) throw new DOMException('Synthetic quota', 'QuotaExceededError'); return original.call(this, key, value); }; });
  94  |   const f = await enter(page); await fill(page, 'STORAGE_FAILURE_FULL_ORIGINAL'); await expect(composer(page)).toContainText('本机存储暂不可用');
  95  |   await page.getByRole('link', { name: '教研后台', exact: true }).click(); await expect(page).toHaveURL(/\/admin\/ai-tools/); await page.getByRole('button', { name: '退出', exact: true }).click();
  96  |   await expect(page).toHaveURL(/\/admin\/ai-tools/); expect((await f.call('/auth/me')).role).toBe('admin');
  97  |   const downloadPromise = page.waitForEvent('download'); await composer(page).getByRole('button', { name: '下载完整原稿 ↗', exact: true }).click(); const download = await downloadPromise;
  98  |   const saved = JSON.parse(readFileSync((await download.path())!, 'utf8')); expect(saved.form.title).toBe('STORAGE_FAILURE_FULL_ORIGINAL'); expect(saved.form.answer).toContain('保留首次原文尾行');
  99  |   await page.getByRole('button', { name: '退出', exact: true }).click(); await expect(page).toHaveURL(/\/parent\/login/);
  100 | });
  101 | 
  102 | test('teaching tools: a provider finishing after cancellation cannot publish its late result', async ({ page }) => {
  103 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page); await preview(page); const id = await generate(page);
  104 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click();
  105 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible({ timeout: 20000 }); const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  106 | });
  107 | 
  108 | test('teaching tools: cancellation acknowledgement loss recovers its original control key after reload', async ({ page }) => {
  109 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  110 |   await page.route('**/api/ai/teaching-tools/runs/*/cancel', async route => { await route.fetch(); await route.abort('failed'); });
  111 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toBeVisible();
  112 |   await page.unroute('**/api/ai/teaching-tools/runs/*/cancel'); await page.reload(); await detail(page).getByRole('button', { name: '恢复原操作', exact: true }).click();
  113 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  114 | });
  115 | 
  116 | test('teaching tools: a role revocation unloads private work and fences the late provider reply', async ({ page }) => {
  117 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page, 'PRIVATE_TEACHING_OWNER_ONLY'); await preview(page); const id = await generate(page);
  118 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await f.call('/qa/teaching-tools/revoke', {});
  119 |   await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(page.getByText('PRIVATE_TEACHING_OWNER_ONLY', { exact: true })).toHaveCount(0);
  120 |   await page.waitForTimeout(1800); await f.call('/qa/teaching-tools/setup', {});
  121 |   await expect.poll(async () => (await f.call('/ai/teaching-tools/runs/' + id)).status, { timeout: 20000 }).toBe('failed'); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull();
  122 | });
  123 | 
  124 | test('teaching tools: parent identity cannot read the admin workspace or load model generation controls', async ({ page }) => {
  125 |   await enter(page, 1280, false); await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(composer(page)).toHaveCount(0);
  126 | });
  127 | 
  128 | test('teaching tools: oversized original text is rejected without losing or truncating the form or making a provider call', async ({ page }) => {
> 129 |   const f = await enter(page); await fill(page); const text = '题'.repeat(6001) + 'OVERSIZE_ORIGINAL_TAIL'; await composer(page).getByLabel('完整题干', { exact: true }).fill(text);
      |                                                                                                                                                                     ^ TimeoutError: locator.fill: Timeout 15000ms exceeded.
  130 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('完整教研输入不可用');
  131 |   await expect(composer(page).getByLabel('完整题干')).toHaveValue(text); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); expect((await f.call('/ai/teaching-tools/runs')).runs).toHaveLength(0);
  132 | });
  133 | 
  134 | test('teaching tools: malformed structured work survives a reload and never gets silently converted into a score', async ({ page }) => {
  135 |   const f = await enter(page); await fill(page); await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); const raw = '{"steps":["第一步原文","COMPLETE_INVALID_JSON_TAIL"'; await composer(page).getByLabel('待核对作答', { exact: true }).fill(raw);
  136 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('不是完整JSON'); await page.reload(); await expect(composer(page).getByLabel('待核对作答', { exact: true })).toHaveValue(raw);
  137 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  138 | });
  139 | 
```