# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: teaching-tools.spec.ts >> teaching tools: an unknown control original remains discoverable across reloads and cannot execute as a command
- Location: tests\e2e\teaching-tools.spec.ts:169:5

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 1
Received length: 0
Received array:  []
```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - alert [ref=f2e2]
  - main [ref=f2e3]:
    - generic [ref=f2e4]:
      - link "学习观察室" [ref=f2e5] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e6]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f2e7]:
        - link "学习首页" [ref=f2e8] [cursor=pointer]:
          - /url: /learn?subject=math
        - link "学习工作台" [ref=f2e9] [cursor=pointer]:
          - /url: /studio?subject=math
        - link "家长空间" [ref=f2e10] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math
        - link "知识诊断" [ref=f2e11] [cursor=pointer]:
          - /url: /student/assessment?subject=math
        - link "今日学习" [ref=f2e12] [cursor=pointer]:
          - /url: /student/today?subject=math
        - link "题卷资料" [ref=f2e13] [cursor=pointer]:
          - /url: /library?subject=math
      - generic [ref=f2e14]:
        - link "教研后台" [ref=f2e15] [cursor=pointer]:
          - /url: /admin/curriculum
        - link "AI教研" [ref=f2e16] [cursor=pointer]:
          - /url: /admin/ai-tools
        - link "账号权限" [ref=f2e17] [cursor=pointer]:
          - /url: /admin/accounts
        - button "退出" [ref=f2e18] [cursor=pointer]
    - generic [ref=f2e19]:
      - navigation "教研导航" [ref=f2e20]:
        - link "知识与覆盖" [ref=f2e21] [cursor=pointer]:
          - /url: /admin/curriculum
        - link "AI 教研草稿" [ref=f2e22] [cursor=pointer]:
          - /url: /admin/ai-tools
        - link "作答复核" [ref=f2e23] [cursor=pointer]:
          - /url: /admin/reviews
        - link "内容管理" [ref=f2e24] [cursor=pointer]:
          - /url: /admin/content
      - generic [ref=f2e25]:
        - generic [ref=f2e26]:
          - text: TEACHING STUDIO / PRIVATE DRAFTS
          - heading "把一次作答，看得更清楚。" [level=1] [ref=f2e27]
          - paragraph [ref=f2e28]: 保留完整条件与推导，比较可能的解释，再用新证据核对。这里产生的是待复核建议。
        - complementary [ref=f2e29]:
          - generic [ref=f2e30]: 教研草稿
          - generic [ref=f2e31]: 尚未人工核对
          - paragraph [ref=f2e32]: 不会自动写入评分、能力判断或指导计划。
      - generic [ref=f2e33]:
        - generic [ref=f2e34]:
          - tablist "教研用途" [ref=f2e35]:
            - tab "答案分析建议" [selected] [ref=f2e36] [cursor=pointer]
            - tab "提示草稿" [ref=f2e37] [cursor=pointer]
          - region "答案分析输入" [ref=f2e38]:
            - generic [ref=f2e39]:
              - generic [ref=f2e40]: 01 / 输入
              - button "下载完整原稿 ↗" [ref=f2e41] [cursor=pointer]
            - status [ref=f2e42]: 已恢复原输入与待核对请求。
            - group "完整教研输入" [ref=f2e43]:
              - generic [ref=f2e45]:
                - button "自编临时题" [pressed] [ref=f2e46] [cursor=pointer]
                - button "选择题库原题" [ref=f2e47] [cursor=pointer]
              - generic [ref=f2e48]:
                - generic [ref=f2e49]:
                  - text: 草稿名称
                  - textbox "草稿名称" [ref=f2e50]:
                    - /placeholder: 给这份临时题起个名字
                    - text: 匿名平均对象的完整原稿
                - generic [ref=f2e51]:
                  - text: 学科或主题
                  - textbox "学科或主题" [ref=f2e52]: 数学
              - generic [ref=f2e53]:
                - generic [ref=f2e54]: 完整题干
                - textbox "完整题干" [ref=f2e55]:
                  - /placeholder: 保留所有条件、单位与问题。
                  - text: 三人与两人的总分分别18与14，求五人平均分。原题尾行条件保持。
              - generic [ref=f2e56]:
                - generic [ref=f2e57]:
                  - generic [ref=f2e58]:
                    - text: 参考答案格式
                    - combobox "参考答案格式" [ref=f2e59]:
                      - option "普通文字" [selected]
                      - option "结构化 JSON"
                  - generic [ref=f2e60]:
                    - checkbox "暂不清楚参考答案" [ref=f2e61]
                    - text: 暂不清楚参考答案
                - generic [ref=f2e62]:
                  - generic [ref=f2e63]: 参考答案
                  - textbox "参考答案" [ref=f2e64]:
                    - /placeholder: 完整保留原文与推导过程。
                    - text: "6.4"
              - generic [ref=f2e65]:
                - generic [ref=f2e66]: 参考解析（可选）
                - textbox "参考解析（可选）" [ref=f2e67]: 先合计总分32，再以总人数5作为分母。
              - group [ref=f2e68]:
                - generic "补充表格、公式与答案结构" [ref=f2e69] [cursor=pointer]
              - generic [ref=f2e70]:
                - generic [ref=f2e71]:
                  - generic [ref=f2e72]:
                    - text: 待核对作答格式
                    - combobox "待核对作答格式" [ref=f2e73]:
                      - option "普通文字" [selected]
                      - option "结构化 JSON"
                  - generic [ref=f2e74]:
                    - checkbox "暂不清楚待核对作答" [ref=f2e75]
                    - text: 暂不清楚待核对作答
                - generic [ref=f2e76]:
                  - generic [ref=f2e77]: 待核对作答
                  - textbox "待核对作答" [ref=f2e78]:
                    - /placeholder: 完整保留原文与推导过程。
                    - text: 18+14=32；32/2=16。保留首次原文尾行。
              - generic [ref=f2e79]:
                - generic [ref=f2e80]:
                  - generic [ref=f2e81]: 模型
                  - combobox "选择大模型" [ref=f2e82] [cursor=pointer]:
                    - option "Auto · 平台默认 DeepSeek V4.1 Flash" [selected]
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认"
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                - generic [ref=f2e83]: 尚未进行文字检查
                - paragraph [ref=f2e85]:
                  - generic [ref=f2e86]: DeepSeek V4.1 Flash
                  - generic [ref=f2e87]: 使用平台默认：DeepSeek V4.1 Flash
            - generic [ref=f2e88]:
              - button "预检完整输入" [ref=f2e89] [cursor=pointer]
              - button "确认输入并生成草稿" [disabled] [ref=f2e90]
            - group [ref=f2e91]:
              - generic "本机其他标签页的原稿" [ref=f2e92] [cursor=pointer]
        - complementary "本人教研历史" [ref=f2e93]:
          - generic [ref=f2e94]:
            - generic [ref=f2e95]: 本人原记录
            - button "刷新" [ref=f2e96] [cursor=pointer]
          - generic [ref=f2e97]:
            - text: 用途
            - combobox "用途" [ref=f2e98]:
              - option "全部" [selected]
              - option "答案分析"
              - option "提示草稿"
          - group [ref=f2e99]:
            - generic "按时间查找" [ref=f2e100] [cursor=pointer]
          - button "答案分析建议 匿名平均对象的完整原稿 DeepSeek V4.1 Flash · 草稿已生成 2026/10/27 23:30:49" [pressed] [ref=f2e102] [cursor=pointer]:
            - generic [ref=f2e103]: 答案分析建议
            - generic [ref=f2e104]: 匿名平均对象的完整原稿
            - generic [ref=f2e105]: DeepSeek V4.1 Flash · 草稿已生成
            - time [ref=f2e106]: 2026/10/27 23:30:49
          - generic [ref=f2e107]:
            - button "上一页" [disabled] [ref=f2e108]
            - generic [ref=f2e109]: 第 1 页
            - button "下一页" [disabled] [ref=f2e110]
      - region "教研建议原记录" [ref=f2e111]:
        - generic [ref=f2e112]:
          - text: 03 / 原记录
          - generic [ref=f2e113]: 草稿已生成
          - heading "答案分析建议" [level=2] [ref=f2e114]
          - paragraph [ref=f2e115]: DeepSeek V4.1 Flash · 2026/10/27 23:30:49
          - generic [ref=f2e116]: 尚未人工核对 · 仅为教研建议
        - region "未识别的本机操作" [ref=f2e117]:
          - paragraph [ref=f2e118]: 有 1 份原操作暂不能读取，原件保持。
          - button "下载暂不能读取的原操作 1" [active] [ref=f2e119] [cursor=pointer]
        - generic [ref=f2e120]:
          - paragraph [ref=f2e121]: 保留原推导后，先核对分母所代表的平均对象，再用独立新题验证。
          - generic [ref=f2e122]:
            - generic [ref=f2e123]:
              - term [ref=f2e124]: 建议判断
              - definition [ref=f2e125]: 可能有误
            - generic [ref=f2e126]:
              - term [ref=f2e127]: 建议置信度
              - definition [ref=f2e128]: 低
          - heading "观察与原文依据" [level=3] [ref=f2e129]
          - article [ref=f2e130]:
            - text: 待核对作答
            - blockquote [ref=f2e131]: 18+14=32；32/2=16。保留首次原文尾行。
            - paragraph [ref=f2e132]: 这里只记录本次原文能够支持的观察。
          - heading "还不能确定什么" [level=3] [ref=f2e133]
          - list [ref=f2e134]:
            - listitem [ref=f2e135]: 单次回答尚不足以确定稳定的能力原因。
          - heading "怎样进一步验证" [level=3] [ref=f2e136]
          - list [ref=f2e137]:
            - listitem [ref=f2e138]: 换一个人数不同的情境，独立说明分母代表什么。
        - generic [ref=f2e139]:
          - button "下载完整草稿" [ref=f2e140] [cursor=pointer]
          - button "用原输入另建建议" [ref=f2e141] [cursor=pointer]
        - paragraph [ref=f2e142]: 这些建议没有改变原题、首次作答、正式评分或能力记录。用于教学内容前，继续走现有内容审核。
        - group [ref=f2e143]:
          - generic "完整原题与本次输入" [ref=f2e144] [cursor=pointer]
        - group [ref=f2e145]:
          - generic "原请求与完整结果" [ref=f2e146] [cursor=pointer]
```

# Test source

```ts
  75  |   await expect(composer(page).getByLabel('选择大模型')).toBeEnabled(); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  76  |   await page.unroute('**/api/ai/teaching-tools/runs'); await page.reload(); await composer(page).getByRole('button', { name: '恢复原请求', exact: true }).click(); await done(page);
  77  |   expect(posts).toBe(1); const list = await f.call('/ai/teaching-tools/runs'); expect(list.runs).toHaveLength(1); expect(list.runs[0].modelId).toBe('deepseek-v4-flash');
  78  |   await expect(composer(page).getByLabel('选择大模型')).toHaveValue('claude-sonnet-5'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  79  | });
  80  | 
  81  | test('teaching tools: two tabs retain their own complete drafts and copying another preserves the current version', async ({ page, context }) => {
  82  |   await enter(page); await fill(page, 'FIRST_DOCUMENT_COMPLETE_TAIL'); const second = await context.newPage(); await second.goto('/admin/ai-tools'); await fill(second, 'SECOND_DOCUMENT_COMPLETE_TAIL');
  83  |   await page.reload(); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  84  |   await second.reload(); await expect(composer(second).getByLabel('草稿名称')).toHaveValue('SECOND_DOCUMENT_COMPLETE_TAIL');
  85  |   await composer(second).getByText('本机其他标签页的原稿', { exact: true }).click();
  86  |   await composer(second).locator('.tt-copies article').filter({ hasText: 'FIRST_DOCUMENT_COMPLETE_TAIL' }).first().getByRole('button', { name: '载入这个副本', exact: true }).click();
  87  |   await expect(composer(second).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  88  |   const titles = await second.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.form.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).form.title));
  89  |   expect(titles).toContain('FIRST_DOCUMENT_COMPLETE_TAIL'); expect(titles).toContain('SECOND_DOCUMENT_COMPLETE_TAIL'); await second.close();
  90  | });
  91  | 
  92  | test('teaching tools: failed local storage blocks navigation and logout until the complete original input is downloaded', async ({ page }) => {
  93  |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.teaching-tool.')) throw new DOMException('Synthetic quota', 'QuotaExceededError'); return original.call(this, key, value); }; });
  94  |   const f = await enter(page); await fill(page, 'STORAGE_FAILURE_FULL_ORIGINAL'); await expect(composer(page)).toContainText('本机存储暂不可用');
  95  |   await page.getByRole('link', { name: '教研后台', exact: true }).click(); await expect(page).toHaveURL(/\/admin\/ai-tools/); await page.getByRole('button', { name: '退出', exact: true }).click();
  96  |   await expect(page).toHaveURL(/\/admin\/ai-tools/); expect((await f.call('/auth/me')).role).toBe('admin');
  97  |   const downloadPromise = page.waitForEvent('download'); await composer(page).getByRole('button', { name: '下载完整原稿 ↗', exact: true }).click(); const download = await downloadPromise;
  98  |   const saved = JSON.parse(readFileSync((await download.path())!, 'utf8')); expect(saved.form.title).toBe('STORAGE_FAILURE_FULL_ORIGINAL'); expect(saved.form.answer).toContain('保留首次原文尾行');
  99  |   await page.getByRole('button', { name: '退出', exact: true }).click(); await expect(page).toHaveURL(/\/parent\/login/);
  100 | });
  101 | 
  102 | test('teaching tools: a provider finishing after cancellation cannot publish its late result', async ({ page }) => {
  103 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page); await preview(page); const id = await generate(page);
  104 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click();
  105 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible({ timeout: 20000 }); const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  106 | });
  107 | 
  108 | test('teaching tools: cancellation acknowledgement loss recovers its original control key after reload', async ({ page }) => {
  109 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  110 |   await expect.poll(async () => (await f.call('/qa/teaching-tools/observations')).calls.length).toBe(1);
  111 |   let lost!: () => void; const lostAcknowledgement = new Promise<void>(resolve => { lost = resolve; });
  112 |   await page.route('**/api/ai/teaching-tools/runs/*/cancel', async route => { await route.fetch(); await route.abort('failed'); lost(); });
  113 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toBeVisible();
  114 |   await lostAcknowledgement; await page.unroute('**/api/ai/teaching-tools/runs/*/cancel'); await page.reload(); await detail(page).getByRole('button', { name: '恢复原操作', exact: true }).click();
  115 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  116 | });
  117 | 
  118 | test('teaching tools: a role revocation unloads private work and fences the late provider reply', async ({ page }) => {
  119 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page, 'PRIVATE_TEACHING_OWNER_ONLY'); await preview(page); const id = await generate(page);
  120 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await f.call('/qa/teaching-tools/revoke', {});
  121 |   await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(page.getByText('PRIVATE_TEACHING_OWNER_ONLY', { exact: true })).toHaveCount(0);
  122 |   await page.waitForTimeout(1800); await f.call('/qa/teaching-tools/setup', {});
  123 |   await expect.poll(async () => (await f.call('/ai/teaching-tools/runs/' + id)).status, { timeout: 20000 }).toBe('failed'); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull();
  124 | });
  125 | 
  126 | test('teaching tools: parent identity cannot read the admin workspace or load model generation controls', async ({ page }) => {
  127 |   await enter(page, 1280, false); await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(composer(page)).toHaveCount(0);
  128 | });
  129 | 
  130 | test('teaching tools: oversized original text is rejected without losing or truncating the form or making a provider call', async ({ page }) => {
  131 |   const f = await enter(page); await fill(page); const text = '题'.repeat(6001) + 'OVERSIZE_ORIGINAL_TAIL'; await composer(page).getByLabel('完整题干', { exact: true }).fill(text);
  132 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('完整教研输入不可用');
  133 |   await expect(composer(page).getByLabel('完整题干')).toHaveValue(text); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); expect((await f.call('/ai/teaching-tools/runs')).runs).toHaveLength(0);
  134 | });
  135 | 
  136 | test('teaching tools: malformed structured work survives a reload and never gets silently converted into a score', async ({ page }) => {
  137 |   const f = await enter(page); await fill(page); await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); const raw = '{"steps":["第一步原文","COMPLETE_INVALID_JSON_TAIL"'; await composer(page).getByLabel('待核对作答', { exact: true }).fill(raw);
  138 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('不是完整JSON'); await page.reload(); await expect(composer(page).getByLabel('待核对作答', { exact: true })).toHaveValue(raw);
  139 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  140 | });
  141 | 
  142 | test('teaching tools: a stale cancellation preserves its command, reads the latest state explicitly and requires a new user action', async ({ page }) => {
  143 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page);
  144 |   await expect.poll(async () => (await f.call('/qa/teaching-tools/observations')).calls.length).toBe(1);
  145 |   const pattern = '**/api/ai/teaching-tools/runs/' + id;
  146 |   await page.route(pattern, async route => { const response = await route.fetch(), json = await response.json(); json.data.task.version--; await route.fulfill({ response, json }); });
  147 |   await page.reload(); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  148 |   const posts: Array<Record<string, unknown>> = []; page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/' + id + '/cancel')) posts.push(request.postDataJSON()); });
  149 |   const failed = page.waitForResponse(response => response.url().endsWith('/' + id + '/cancel') && response.status() === 409);
  150 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await failed;
  151 |   await expect(detail(page).getByRole('button', { name: '保留原操作副本，核对最新状态', exact: true })).toBeVisible(); expect(posts).toHaveLength(1);
  152 |   await page.unroute(pattern); await detail(page).getByRole('button', { name: '保留原操作副本，核对最新状态', exact: true }).click();
  153 |   await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toHaveCount(0); expect(posts).toHaveLength(1);
  154 |   const archived = await page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.control.v1.')).map(key => JSON.parse(localStorage.getItem(key)!)).filter(copy => copy.pending));
  155 |   expect(archived.some(copy => copy.pending.command.requestKey === posts[0].requestKey)).toBe(true);
  156 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect(posts).toHaveLength(2); expect(posts[1].requestKey).not.toBe(posts[0].requestKey);
  157 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  158 | });
  159 | 
  160 | test('teaching tools: an unreadable original remains discoverable after two reloads and downloads byte for byte', async ({ page }) => {
  161 |   const f = await enter(page); await fill(page); const original = '{"version":999,"unparsed":"COMPLETE_FUTURE_ORIGINAL_TAIL"\n';
  162 |   await page.evaluate(raw => { const key = Object.keys(localStorage).find(key => key.startsWith('studyagent.teaching-tool.form.v1.'))!; localStorage.setItem(key, raw); }, original);
  163 |   await page.reload(); await expect(composer(page).getByRole('region', { name: '未识别的本机原稿', exact: true })).toBeVisible(); await page.reload();
  164 |   await expect(composer(page).getByRole('region', { name: '未识别的本机原稿', exact: true })).toBeVisible(); const pending = page.waitForEvent('download');
  165 |   await composer(page).getByRole('button', { name: '下载暂不能读取的原件 1', exact: true }).click(); expect(readFileSync((await (await pending).path())!, 'utf8')).toBe(original);
  166 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  167 | });
  168 | 
  169 | test('teaching tools: an unknown control original remains discoverable across reloads and cannot execute as a command', async ({ page }) => {
  170 |   const f = await enter(page); await fill(page); await preview(page); await generate(page); await done(page); const original = '{"version":999,"operation":"UNKNOWN_CONTROL_COMPLETE_TAIL"\n';
  171 |   await page.evaluate(raw => { const key = Object.keys(localStorage).find(key => key.startsWith('studyagent.teaching-tool.control.v1.'))!; localStorage.setItem(key, raw); }, original);
  172 |   await page.reload(); await expect(detail(page).getByRole('region', { name: '未识别的本机操作', exact: true })).toBeVisible(); await page.reload();
  173 |   await expect(detail(page).getByRole('region', { name: '未识别的本机操作', exact: true })).toBeVisible(); const pending = page.waitForEvent('download');
  174 |   await detail(page).getByRole('button', { name: '下载暂不能读取的原操作 1', exact: true }).click(); expect(readFileSync((await (await pending).path())!, 'utf8')).toBe(original);
> 175 |   await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toHaveCount(0); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
      |                                                                                                                                                                  ^ Error: expect(received).toHaveLength(expected)
  176 | });
  177 | 
```