# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: teaching-tools.spec.ts >> teaching tools: cancellation acknowledgement loss recovers its original control key after reload
- Location: tests\e2e\teaching-tools.spec.ts:108:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - alert [ref=e2]: 学习观察室 · 看见孩子怎样学会
  - main [ref=e3]:
    - generic [ref=e4]:
      - link "学习观察室" [ref=e5] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=e6]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=e7]:
        - link "学习首页" [ref=e8] [cursor=pointer]:
          - /url: /learn?subject=math
        - link "学习工作台" [ref=e9] [cursor=pointer]:
          - /url: /studio?subject=math
        - link "家长空间" [ref=e10] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math
        - link "知识诊断" [ref=e11] [cursor=pointer]:
          - /url: /student/assessment?subject=math
        - link "今日学习" [ref=e12] [cursor=pointer]:
          - /url: /student/today?subject=math
        - link "题卷资料" [ref=e13] [cursor=pointer]:
          - /url: /library?subject=math
      - generic [ref=e14]:
        - link "教研后台" [ref=e15] [cursor=pointer]:
          - /url: /admin/curriculum
        - link "AI教研" [ref=e16] [cursor=pointer]:
          - /url: /admin/ai-tools
        - link "账号权限" [ref=e17] [cursor=pointer]:
          - /url: /admin/accounts
        - button "退出" [ref=e18] [cursor=pointer]
    - generic [ref=e19]:
      - navigation "教研导航" [ref=e20]:
        - link "知识与覆盖" [ref=e21] [cursor=pointer]:
          - /url: /admin/curriculum
        - link "AI 教研草稿" [ref=e22] [cursor=pointer]:
          - /url: /admin/ai-tools
        - link "作答复核" [ref=e23] [cursor=pointer]:
          - /url: /admin/reviews
        - link "内容管理" [ref=e24] [cursor=pointer]:
          - /url: /admin/content
      - generic [ref=e25]:
        - generic [ref=e26]:
          - text: TEACHING STUDIO / PRIVATE DRAFTS
          - heading "把一次作答，看得更清楚。" [level=1] [ref=e27]
          - paragraph [ref=e28]: 保留完整条件与推导，比较可能的解释，再用新证据核对。这里产生的是待复核建议。
        - complementary [ref=e29]:
          - generic [ref=e30]: 教研草稿
          - generic [ref=e31]: 尚未人工核对
          - paragraph [ref=e32]: 不会自动写入评分、能力判断或指导计划。
      - generic [ref=e33]:
        - generic [ref=e34]:
          - tablist "教研用途" [ref=e35]:
            - tab "答案分析建议" [selected] [ref=e36] [cursor=pointer]
            - tab "提示草稿" [ref=e37] [cursor=pointer]
          - region "答案分析输入" [ref=e38]:
            - generic [ref=e39]:
              - generic [ref=e40]: 01 / 输入
              - button "下载完整原稿 ↗" [ref=e41] [cursor=pointer]
            - status [ref=e42]: 原输入已保存到任务，生成结果仍需人工核对。
            - group "完整教研输入" [ref=e43]:
              - generic [ref=e45]:
                - button "自编临时题" [pressed] [ref=e46] [cursor=pointer]
                - button "选择题库原题" [ref=e47] [cursor=pointer]
              - generic [ref=e48]:
                - generic [ref=e49]:
                  - text: 草稿名称
                  - textbox "草稿名称" [ref=e50]:
                    - /placeholder: 给这份临时题起个名字
                    - text: 匿名平均对象的完整原稿
                - generic [ref=e51]:
                  - text: 学科或主题
                  - textbox "学科或主题" [ref=e52]: 数学
              - generic [ref=e53]:
                - generic [ref=e54]: 完整题干
                - textbox "完整题干" [ref=e55]:
                  - /placeholder: 保留所有条件、单位与问题。
                  - text: 三人与两人的总分分别18与14，求五人平均分。原题尾行条件保持。
              - generic [ref=e56]:
                - generic [ref=e57]:
                  - generic [ref=e58]:
                    - text: 参考答案格式
                    - combobox "参考答案格式" [ref=e59]:
                      - option "普通文字" [selected]
                      - option "结构化 JSON"
                  - generic [ref=e60]:
                    - checkbox "暂不清楚参考答案" [ref=e61]
                    - text: 暂不清楚参考答案
                - generic [ref=e62]:
                  - generic [ref=e63]: 参考答案
                  - textbox "参考答案" [ref=e64]:
                    - /placeholder: 完整保留原文与推导过程。
                    - text: "6.4"
              - generic [ref=e65]:
                - generic [ref=e66]: 参考解析（可选）
                - textbox "参考解析（可选）" [ref=e67]: 先合计总分32，再以总人数5作为分母。
              - group [ref=e68]:
                - generic "补充表格、公式与答案结构" [ref=e69] [cursor=pointer]
              - generic [ref=e70]:
                - generic [ref=e71]:
                  - generic [ref=e72]:
                    - text: 待核对作答格式
                    - combobox "待核对作答格式" [ref=e73]:
                      - option "普通文字" [selected]
                      - option "结构化 JSON"
                  - generic [ref=e74]:
                    - checkbox "暂不清楚待核对作答" [ref=e75]
                    - text: 暂不清楚待核对作答
                - generic [ref=e76]:
                  - generic [ref=e77]: 待核对作答
                  - textbox "待核对作答" [ref=e78]:
                    - /placeholder: 完整保留原文与推导过程。
                    - text: 18+14=32；32/2=16。保留首次原文尾行。
              - generic [ref=e79]:
                - generic [ref=e80]:
                  - generic [ref=e81]: 模型
                  - combobox "选择大模型" [ref=e82] [cursor=pointer]:
                    - option "Auto · 平台默认 DeepSeek V4.1 Flash" [selected]
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认"
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                - generic [ref=e83]: 尚未进行文字检查
                - paragraph [ref=e85]:
                  - generic [ref=e86]: DeepSeek V4.1 Flash
                  - generic [ref=e87]: 使用平台默认：DeepSeek V4.1 Flash
            - generic [ref=e88]:
              - button "预检完整输入" [ref=e89] [cursor=pointer]
              - button "确认输入并生成草稿" [disabled] [ref=e90]
            - group [ref=e91]:
              - generic "本机其他标签页的原稿" [ref=e92] [cursor=pointer]
        - complementary "本人教研历史" [ref=e93]:
          - generic [ref=e94]:
            - generic [ref=e95]: 本人原记录
            - button "刷新" [ref=e96] [cursor=pointer]
          - generic [ref=e97]:
            - text: 用途
            - combobox "用途" [ref=e98]:
              - option "全部" [selected]
              - option "答案分析"
              - option "提示草稿"
          - group [ref=e99]:
            - generic "按时间查找" [ref=e100] [cursor=pointer]
          - button "答案分析建议 匿名平均对象的完整原稿 DeepSeek V4.1 Flash · 已排队 2026/10/27 23:29:56" [pressed] [ref=e102] [cursor=pointer]:
            - generic [ref=e103]: 答案分析建议
            - generic [ref=e104]: 匿名平均对象的完整原稿
            - generic [ref=e105]: DeepSeek V4.1 Flash · 已排队
            - time [ref=e106]: 2026/10/27 23:29:56
          - generic [ref=e107]:
            - button "上一页" [disabled] [ref=e108]
            - generic [ref=e109]: 第 1 页
            - button "下一页" [disabled] [ref=e110]
      - region "教研建议原记录" [ref=e111]:
        - generic [ref=e112]:
          - text: 03 / 原记录
          - generic [ref=e113]: 草稿已生成
          - heading "答案分析建议" [level=2] [ref=e114]
          - paragraph [ref=e115]: DeepSeek V4.1 Flash · 2026/10/27 23:29:56
          - generic [ref=e116]: 尚未人工核对 · 仅为教研建议
        - generic [ref=e117]:
          - paragraph [ref=e118]: 保留原推导后，先核对分母所代表的平均对象，再用独立新题验证。
          - generic [ref=e119]:
            - generic [ref=e120]:
              - term [ref=e121]: 建议判断
              - definition [ref=e122]: 可能有误
            - generic [ref=e123]:
              - term [ref=e124]: 建议置信度
              - definition [ref=e125]: 低
          - heading "观察与原文依据" [level=3] [ref=e126]
          - article [ref=e127]:
            - text: 待核对作答
            - blockquote [ref=e128]: 18+14=32；32/2=16。保留首次原文尾行。
            - paragraph [ref=e129]: 这里只记录本次原文能够支持的观察。
          - heading "还不能确定什么" [level=3] [ref=e130]
          - list [ref=e131]:
            - listitem [ref=e132]: 单次回答尚不足以确定稳定的能力原因。
          - heading "怎样进一步验证" [level=3] [ref=e133]
          - list [ref=e134]:
            - listitem [ref=e135]: 换一个人数不同的情境，独立说明分母代表什么。
        - generic [ref=e136]:
          - button "下载完整草稿" [ref=e137] [cursor=pointer]
          - button "用原输入另建建议" [ref=e138] [cursor=pointer]
        - paragraph [ref=e139]: 这些建议没有改变原题、首次作答、正式评分或能力记录。用于教学内容前，继续走现有内容审核。
        - group [ref=e140]:
          - generic "完整原题与本次输入" [ref=e141] [cursor=pointer]
        - group [ref=e142]:
          - generic "原请求与完整结果" [ref=e143] [cursor=pointer]
```

# Test source

```ts
  10  |   const hash = createHash('sha256').update(test.info().testId + suffix).digest(), address = `198.21.${hash[0]}.${hash[1]}`;
  11  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  12  |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  13  |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
  14  |   async function call(path: string, body?: unknown, method = body === undefined ? 'GET' : 'POST') {
  15  |     const response = await fetch(api + path, { method, headers: { 'content-type': 'application/json', authorization: 'Bearer ' + actor.token, 'X-Forwarded-For': address }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  16  |     const data = await response.json(); expect(response.ok, JSON.stringify(data.error)).toBe(true); return data.data;
  17  |   }
  18  |   const seeded = admin ? await call('/qa/teaching-tools/setup', {}) : null;
  19  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  20  |   await page.getByRole('button', { name: '登录，查看学习记录 →', exact: true }).click(); await expect(page).toHaveURL(admin ? /\/admin\/analytics/ : /\/learn/);
  21  |   if (admin) await page.getByRole('link', { name: 'AI教研', exact: true }).click(); else await page.goto('/admin/ai-tools');
  22  |   if (admin) await expect(page.getByRole('heading', { name: '把一次作答，看得更清楚。', exact: true })).toBeVisible();
  23  |   return { actor, call, questionId: seeded?.questionId as string, principal, credential };
  24  | }
  25  | async function fill(page: Page, title = '匿名平均对象的完整原稿') {
  26  |   await composer(page).getByLabel('草稿名称', { exact: true }).fill(title);
  27  |   await composer(page).getByLabel('完整题干', { exact: true }).fill('三人与两人的总分分别18与14，求五人平均分。原题尾行条件保持。');
  28  |   await composer(page).getByLabel('参考答案', { exact: true }).fill('6.4');
  29  |   await composer(page).getByLabel('参考解析（可选）', { exact: true }).fill('先合计总分32，再以总人数5作为分母。');
  30  |   if (await composer(page).getByLabel('待核对作答', { exact: true }).count()) await composer(page).getByLabel('待核对作答', { exact: true }).fill('18+14=32；32/2=16。保留首次原文尾行。');
  31  |   await expect(composer(page).getByLabel('选择大模型', { exact: true })).toBeEnabled();
  32  | }
  33  | async function preview(page: Page) { await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).getByRole('region', { name: '完整输入预检', exact: true })).toBeVisible(); }
  34  | async function generate(page: Page) { await composer(page).getByRole('button', { name: '确认输入并生成草稿', exact: true }).click(); await expect(detail(page)).toBeVisible(); return new URL(page.url()).searchParams.get('run')!; }
  35  | async function done(page: Page) { await expect(detail(page).getByText('草稿已生成', { exact: true })).toBeVisible({ timeout: 25000 }); }
  36  | 
  37  | for (const width of [390, 768, 1280]) test(`teaching tools: complete analysis, original input and unreviewed result at ${width}`, async ({ page }) => {
  38  |   const f = await enter(page, width); await fill(page); await expect(composer(page).getByLabel('选择大模型')).toHaveValue('auto');
  39  |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); await preview(page);
  40  |   await expect(composer(page).getByRole('region', { name: '完整输入预检' })).toContainText('原题尾行条件保持。');
  41  |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  42  |   const runId = await generate(page); await done(page); await expect(detail(page)).toContainText('尚未人工核对'); await expect(detail(page)).toContainText('单次回答尚不足以确定稳定的能力原因。');
  43  |   const run = await f.call('/ai/teaching-tools/runs/' + runId); expect(run).toMatchObject({ status: 'completed', modelId: 'deepseek-v4-flash', advisoryOnly: true, reviewRequired: true });
  44  |   expect(run.snapshot.answer).toContain('保留首次原文尾行'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  45  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  46  |   await page.screenshot({ path: evidence + '/analysis-' + width + '.png', fullPage: true }); await page.reload(); await done(page);
  47  |   expect(new URL(page.url()).searchParams.get('run')).toBe(runId); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('匿名平均对象的完整原稿');
  48  | });
  49  | 
  50  | test('teaching tools: bank preflight shows actual table and formula, freezing the server original version and structured answer', async ({ page }) => {
  51  |   const f = await enter(page); await composer(page).getByRole('button', { name: '选择题库原题', exact: true }).click();
  52  |   await composer(page).getByLabel('查找题目').fill(f.questionId); await composer(page).locator('.tt-question-list>button').filter({ hasText: f.questionId }).click();
  53  |   await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); await composer(page).getByLabel('待核对作答', { exact: true }).fill(JSON.stringify({ steps: ['18+14=32', '32/2=16'], result: 16 }));
  54  |   await preview(page); const panel = composer(page).getByRole('region', { name: '完整输入预检' });
  55  |   await expect(panel.getByRole('table')).toBeVisible(); await expect(panel.locator('.katex')).toBeVisible(); await expect(panel).toContainText('原文版本 3');
  56  |   const id = await generate(page); await done(page); const run = await f.call('/ai/teaching-tools/runs/' + id);
  57  |   expect(run.snapshot.source).toMatchObject({ kind: 'question_bank', questionId: f.questionId }); expect(run.snapshot.question.originalDocument.version).toBe(3);
  58  |   expect(run.snapshot.question.originalDocument.blocks.map((block: any) => block.type)).toEqual(['text', 'table', 'math_display']); expect(run.snapshot.answer.steps[1]).toBe('32/2=16');
  59  | });
  60  | 
  61  | test('teaching tools: hint failure stays explicit and a retry uses the frozen original model after changing the composer', async ({ page }) => {
  62  |   const f = await enter(page); await page.getByRole('tab', { name: '提示草稿', exact: true }).click(); await fill(page, '分母提示草稿');
  63  |   await composer(page).getByLabel('帮助层级').selectOption('2'); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  64  |   await f.call('/qa/teaching-tools/behavior', { mode: 'fail_once' }); await preview(page); const id = await generate(page);
  65  |   await expect(detail(page).getByText('本次未完成', { exact: true })).toBeVisible(); await expect(detail(page).getByText('先把全部人数逐个列出来，再解释要平均的是谁。', { exact: true })).toHaveCount(0);
  66  |   await composer(page).getByLabel('选择大模型').selectOption('gpt-6.1-sol'); await detail(page).getByRole('button', { name: '使用原模型重试 · Claude Sonnet 5', exact: true }).click(); await done(page);
  67  |   const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.modelId).toBe('claude-sonnet-5'); expect(run.result.hint.suggestedLevel).toBe(2);
  68  |   expect((await f.call('/qa/teaching-tools/observations')).calls.map((item: any) => item.modelId)).toEqual(['claude-sonnet-5', 'claude-sonnet-5']);
  69  | });
  70  | 
  71  | test('teaching tools: lost creation acknowledgement restores the same original command after reload without duplicate generation', async ({ page }) => {
  72  |   const f = await enter(page); await fill(page, '原命令必须只生成一次'); await preview(page);
  73  |   let posts = 0; await page.route('**/api/ai/teaching-tools/runs', async route => { if (route.request().method() !== 'POST') return route.continue(); posts++; await route.fetch(); await route.abort('failed'); });
  74  |   await composer(page).getByRole('button', { name: '确认输入并生成草稿', exact: true }).click(); await expect(composer(page).getByRole('button', { name: '恢复原请求', exact: true })).toBeVisible();
  75  |   await expect(composer(page).getByLabel('选择大模型')).toBeEnabled(); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  76  |   await page.unroute('**/api/ai/teaching-tools/runs'); await page.reload(); await composer(page).getByRole('button', { name: '恢复原请求', exact: true }).click(); await done(page);
  77  |   expect(posts).toBe(1); const list = await f.call('/ai/teaching-tools/runs'); expect(list.runs).toHaveLength(1); expect(list.runs[0].modelId).toBe('deepseek-v4-flash');
  78  |   await expect(composer(page).getByLabel('选择大模型')).toHaveValue('claude-sonnet-5'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  79  | });
  80  | 
  81  | test('teaching tools: two tabs retain their own complete drafts and copying another preserves the current version', async ({ page, context }) => {
  82  |   await enter(page); await fill(page, 'FIRST_DOCUMENT_COMPLETE_TAIL'); const second = await context.newPage(); await second.goto('/admin/ai-tools'); await fill(second, 'SECOND_DOCUMENT_COMPLETE_TAIL');
  83  |   await page.reload(); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  84  |   await second.reload(); await expect(composer(second).getByLabel('草稿名称')).toHaveValue('SECOND_DOCUMENT_COMPLETE_TAIL');
  85  |   await composer(second).getByText('本机其他标签页的原稿', { exact: true }).click();
  86  |   await composer(second).locator('.tt-copies article').filter({ hasText: 'FIRST_DOCUMENT_COMPLETE_TAIL' }).first().getByRole('button', { name: '载入这个副本', exact: true }).click();
  87  |   await expect(composer(second).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  88  |   const titles = await second.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.form.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).form.title));
  89  |   expect(titles).toContain('FIRST_DOCUMENT_COMPLETE_TAIL'); expect(titles).toContain('SECOND_DOCUMENT_COMPLETE_TAIL'); await second.close();
  90  | });
  91  | 
  92  | test('teaching tools: failed local storage blocks navigation and logout until the complete original input is downloaded', async ({ page }) => {
  93  |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.teaching-tool.')) throw new DOMException('Synthetic quota', 'QuotaExceededError'); return original.call(this, key, value); }; });
  94  |   const f = await enter(page); await fill(page, 'STORAGE_FAILURE_FULL_ORIGINAL'); await expect(composer(page)).toContainText('本机存储暂不可用');
  95  |   await page.getByRole('link', { name: '教研后台', exact: true }).click(); await expect(page).toHaveURL(/\/admin\/ai-tools/); await page.getByRole('button', { name: '退出', exact: true }).click();
  96  |   await expect(page).toHaveURL(/\/admin\/ai-tools/); expect((await f.call('/auth/me')).role).toBe('admin');
  97  |   const downloadPromise = page.waitForEvent('download'); await composer(page).getByRole('button', { name: '下载完整原稿 ↗', exact: true }).click(); const download = await downloadPromise;
  98  |   const saved = JSON.parse(readFileSync((await download.path())!, 'utf8')); expect(saved.form.title).toBe('STORAGE_FAILURE_FULL_ORIGINAL'); expect(saved.form.answer).toContain('保留首次原文尾行');
  99  |   await page.getByRole('button', { name: '退出', exact: true }).click(); await expect(page).toHaveURL(/\/parent\/login/);
  100 | });
  101 | 
  102 | test('teaching tools: a provider finishing after cancellation cannot publish its late result', async ({ page }) => {
  103 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page); await preview(page); const id = await generate(page);
  104 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click();
  105 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible({ timeout: 20000 }); const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  106 | });
  107 | 
  108 | test('teaching tools: cancellation acknowledgement loss recovers its original control key after reload', async ({ page }) => {
  109 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
> 110 |   await expect.poll(async () => (await f.call('/qa/teaching-tools/observations')).calls.length).toBe(1);
      |                                                                                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  111 |   let lost!: () => void; const lostAcknowledgement = new Promise<void>(resolve => { lost = resolve; });
  112 |   await page.route('**/api/ai/teaching-tools/runs/*/cancel', async route => { await route.fetch(); await route.abort('failed'); lost(); });
  113 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toBeVisible();
  114 |   await lostAcknowledgement; await page.unroute('**/api/ai/teaching-tools/runs/*/cancel'); await page.reload(); await detail(page).getByRole('button', { name: '恢复原操作', exact: true }).click();
  115 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  116 | });
  117 | 
  118 | test('teaching tools: a role revocation unloads private work and fences the late provider reply', async ({ page }) => {
  119 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page, 'PRIVATE_TEACHING_OWNER_ONLY'); await preview(page); const id = await generate(page);
  120 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await f.call('/qa/teaching-tools/revoke', {});
  121 |   await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(page.getByText('PRIVATE_TEACHING_OWNER_ONLY', { exact: true })).toHaveCount(0);
  122 |   await page.waitForTimeout(1800); await f.call('/qa/teaching-tools/setup', {});
  123 |   await expect.poll(async () => (await f.call('/ai/teaching-tools/runs/' + id)).status, { timeout: 20000 }).toBe('failed'); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull();
  124 | });
  125 | 
  126 | test('teaching tools: parent identity cannot read the admin workspace or load model generation controls', async ({ page }) => {
  127 |   await enter(page, 1280, false); await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(composer(page)).toHaveCount(0);
  128 | });
  129 | 
  130 | test('teaching tools: oversized original text is rejected without losing or truncating the form or making a provider call', async ({ page }) => {
  131 |   const f = await enter(page); await fill(page); const text = '题'.repeat(6001) + 'OVERSIZE_ORIGINAL_TAIL'; await composer(page).getByLabel('完整题干', { exact: true }).fill(text);
  132 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('完整教研输入不可用');
  133 |   await expect(composer(page).getByLabel('完整题干')).toHaveValue(text); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); expect((await f.call('/ai/teaching-tools/runs')).runs).toHaveLength(0);
  134 | });
  135 | 
  136 | test('teaching tools: malformed structured work survives a reload and never gets silently converted into a score', async ({ page }) => {
  137 |   const f = await enter(page); await fill(page); await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); const raw = '{"steps":["第一步原文","COMPLETE_INVALID_JSON_TAIL"'; await composer(page).getByLabel('待核对作答', { exact: true }).fill(raw);
  138 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('不是完整JSON'); await page.reload(); await expect(composer(page).getByLabel('待核对作答', { exact: true })).toHaveValue(raw);
  139 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  140 | });
  141 | 
  142 | test('teaching tools: a stale cancellation preserves its command, reads the latest state explicitly and requires a new user action', async ({ page }) => {
  143 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page);
  144 |   await expect.poll(async () => (await f.call('/qa/teaching-tools/observations')).calls.length).toBe(1);
  145 |   const pattern = '**/api/ai/teaching-tools/runs/' + id;
  146 |   await page.route(pattern, async route => { const response = await route.fetch(), json = await response.json(); json.data.task.version--; await route.fulfill({ response, json }); });
  147 |   await page.reload(); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  148 |   const posts: Array<Record<string, unknown>> = []; page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/' + id + '/cancel')) posts.push(request.postDataJSON()); });
  149 |   const failed = page.waitForResponse(response => response.url().endsWith('/' + id + '/cancel') && response.status() === 409);
  150 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await failed;
  151 |   await expect(detail(page).getByRole('button', { name: '保留原操作副本，核对最新状态', exact: true })).toBeVisible(); expect(posts).toHaveLength(1);
  152 |   await page.unroute(pattern); await detail(page).getByRole('button', { name: '保留原操作副本，核对最新状态', exact: true }).click();
  153 |   await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toHaveCount(0); expect(posts).toHaveLength(1);
  154 |   const archived = await page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.control.v1.')).map(key => JSON.parse(localStorage.getItem(key)!)).filter(copy => copy.pending));
  155 |   expect(archived.some(copy => copy.pending.command.requestKey === posts[0].requestKey)).toBe(true);
  156 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect(posts).toHaveLength(2); expect(posts[1].requestKey).not.toBe(posts[0].requestKey);
  157 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  158 | });
  159 | 
  160 | test('teaching tools: an unreadable original remains discoverable after two reloads and downloads byte for byte', async ({ page }) => {
  161 |   const f = await enter(page); await fill(page); const original = '{"version":999,"unparsed":"COMPLETE_FUTURE_ORIGINAL_TAIL"\n';
  162 |   await page.evaluate(raw => { const key = Object.keys(localStorage).find(key => key.startsWith('studyagent.teaching-tool.form.v1.'))!; localStorage.setItem(key, raw); }, original);
  163 |   await page.reload(); await expect(composer(page).getByRole('region', { name: '未识别的本机原稿', exact: true })).toBeVisible(); await page.reload();
  164 |   await expect(composer(page).getByRole('region', { name: '未识别的本机原稿', exact: true })).toBeVisible(); const pending = page.waitForEvent('download');
  165 |   await composer(page).getByRole('button', { name: '下载暂不能读取的原件 1', exact: true }).click(); expect(readFileSync((await (await pending).path())!, 'utf8')).toBe(original);
  166 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  167 | });
  168 | 
  169 | test('teaching tools: an unknown control original remains discoverable across reloads and cannot execute as a command', async ({ page }) => {
  170 |   const f = await enter(page); await fill(page); await preview(page); await generate(page); await done(page); const original = '{"version":999,"operation":"UNKNOWN_CONTROL_COMPLETE_TAIL"\n';
  171 |   await page.evaluate(raw => { const key = Object.keys(localStorage).find(key => key.startsWith('studyagent.teaching-tool.control.v1.'))!; localStorage.setItem(key, raw); }, original);
  172 |   await page.reload(); await expect(detail(page).getByRole('region', { name: '未识别的本机操作', exact: true })).toBeVisible(); await page.reload();
  173 |   await expect(detail(page).getByRole('region', { name: '未识别的本机操作', exact: true })).toBeVisible(); const pending = page.waitForEvent('download');
  174 |   await detail(page).getByRole('button', { name: '下载暂不能读取的原操作 1', exact: true }).click(); expect(readFileSync((await (await pending).path())!, 'utf8')).toBe(original);
  175 |   await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toHaveCount(0); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  176 | });
  177 | 
```