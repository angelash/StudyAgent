# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: teaching-tools.spec.ts >> teaching tools: cancellation acknowledgement loss recovers its original control key after reload
- Location: tests\e2e\teaching-tools.spec.ts:108:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: 'AI教研', exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - alert [ref=e2]: 运营看板
  - main [ref=e3]:
    - generic [ref=e4]:
      - generic [ref=e5]:
        - heading "运营看板" [level=1] [ref=e6]
        - paragraph [ref=e7]: 这里查看内容供给、训练完成度和 AI 使用质量，方便判断系统当前是否在稳定输出学习价值。
      - generic [ref=e8]:
        - link "进入内容后台" [ref=e9] [cursor=pointer]:
          - /url: /admin/content
        - button "刷新指标" [ref=e10]
    - generic [ref=e11]:
      - generic [ref=e12]:
        - generic [ref=e13]: 学生数
        - generic [ref=e14]: "0"
      - generic [ref=e15]:
        - generic [ref=e16]: 活跃家长
        - generic [ref=e17]: "0"
      - generic [ref=e18]:
        - generic [ref=e19]: 教材册次
        - generic [ref=e20]: "3"
      - generic [ref=e21]:
        - generic [ref=e22]: 原子知识点
        - generic [ref=e23]: "258"
      - generic [ref=e24]:
        - generic [ref=e25]: 已发布题目
        - generic [ref=e26]: "15783"
      - generic [ref=e27]:
        - generic [ref=e28]: 完成评估
        - generic [ref=e29]: "0"
      - generic [ref=e30]:
        - generic [ref=e31]: 完成训练活动
        - generic [ref=e32]: "0"
      - generic [ref=e33]:
        - generic [ref=e34]: 进行中指导计划
        - generic [ref=e35]: "0"
      - generic [ref=e36]:
        - generic [ref=e37]: AI 洞察总数
        - generic [ref=e38]: "0"
    - region "运行与待办监控" [ref=e39]:
      - heading "运行与待办" [level=2] [ref=e40]
      - paragraph [ref=e41]: 学习与队列来自当前存储；请求统计从本进程启动累计。更新于 2026/10/27 23:12:11。
      - generic [ref=e42]:
        - generic [ref=e43]:
          - generic [ref=e44]: 等待量规复核
          - generic [ref=e45]: "0"
        - generic [ref=e46]:
          - generic [ref=e47]: 待处理学习反馈
          - generic [ref=e48]: "0"
        - generic [ref=e49]:
          - generic [ref=e50]: 到期复测
          - generic [ref=e51]: "0"
        - generic [ref=e52]:
          - generic [ref=e53]: 排队 / 待重试任务
          - generic [ref=e54]: "0"
        - generic [ref=e55]:
          - generic [ref=e56]: 任务运行中
          - generic [ref=e57]: "0"
        - generic [ref=e58]:
          - generic [ref=e59]: 失败任务
          - generic [ref=e60]: "0"
        - generic [ref=e61]:
          - generic [ref=e62]: 请求 / 服务错误
          - generic [ref=e63]: 70 / 0
        - generic [ref=e64]:
          - generic [ref=e65]: 限流拒绝
          - generic [ref=e66]: "0"
      - paragraph [ref=e67]: 存储：sqlite · 持久化已启用可用容量：89.6 GB · 进程内存：498 MB最早待办距今：0 秒 · 存储冲突：0
      - generic [ref=e68]:
        - link "处理量规与反馈" [ref=e69] [cursor=pointer]:
          - /url: /admin/reviews
        - link "查看导入任务" [ref=e70] [cursor=pointer]:
          - /url: /admin/imports
        - link "检查课程覆盖" [ref=e71] [cursor=pointer]:
          - /url: /admin/curriculum
      - group [ref=e72]:
        - generic "请求延迟明细" [ref=e73] [cursor=pointer]
    - generic [ref=e74]:
      - generic [ref=e75]:
        - heading "AI 质量概览" [level=2] [ref=e76]
        - generic [ref=e77]:
          - generic [ref=e78]:
            - generic [ref=e79]: 评估分析洞察
            - generic [ref=e80]: "0"
          - generic [ref=e81]:
            - generic [ref=e82]: 提示生成洞察
            - generic [ref=e83]: "0"
          - generic [ref=e84]:
            - generic [ref=e85]: 助教对话洞察
            - generic [ref=e86]: "0"
          - generic [ref=e87]:
            - generic [ref=e88]: 需人工复核
            - generic [ref=e89]: "0"
          - generic [ref=e90]:
            - generic [ref=e91]: 历史检索记录
            - generic [ref=e92]: "0"
        - generic [ref=e93]:
          - generic [ref=e94]:
            - generic [ref=e95]: 置信度分布
            - generic [ref=e96]: 高置信：0中置信：0低置信：0
          - generic [ref=e97]:
            - generic [ref=e98]: 当前判断
            - generic [ref=e99]: 当前还没有形成足够的 AI 洞察数据，建议先完成几轮真实评估、提示和助教交互。
      - generic [ref=e100]:
        - heading "最近 AI 洞察" [level=2] [ref=e101]
        - generic [ref=e102]: 当前还没有 AI 洞察记录。
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { createHash } from 'node:crypto';
  3   | import { readFileSync } from 'node:fs';
  4   | import { browserEvidence } from './evidence';
  5   | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`, evidence = browserEvidence('teaching-tools');
  6   | const composer = (page: Page) => page.locator('.tt-composer'), detail = (page: Page) => page.getByRole('region', { name: '教研建议原记录', exact: true });
  7   | async function enter(page: Page, width = 1280, admin = true) {
  8   |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  9   |   const suffix = crypto.randomUUID(), principal = 'teaching-ui-' + suffix + '@local.test', credential = 'Teaching-UI-QA-' + suffix;
  10  |   const hash = createHash('sha256').update(test.info().testId + suffix).digest(), address = `198.21.${hash[0]}.${hash[1]}`;
  11  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  12  |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  13  |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
  14  |   async function call(path: string, body?: unknown, method = body === undefined ? 'GET' : 'POST') {
  15  |     const response = await fetch(api + path, { method, headers: { 'content-type': 'application/json', authorization: 'Bearer ' + actor.token, 'X-Forwarded-For': address }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  16  |     const data = await response.json(); expect(response.ok, JSON.stringify(data.error)).toBe(true); return data.data;
  17  |   }
  18  |   const seeded = admin ? await call('/qa/teaching-tools/setup', {}) : null;
  19  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  20  |   await page.getByRole('button', { name: '登录，查看学习记录 →', exact: true }).click(); await expect(page).toHaveURL(admin ? /\/admin\/analytics/ : /\/learn/);
> 21  |   if (admin) await page.getByRole('link', { name: 'AI教研', exact: true }).click(); else await page.goto('/admin/ai-tools');
      |                                                                          ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  22  |   if (admin) await expect(page.getByRole('heading', { name: '把一次作答，看得更清楚。', exact: true })).toBeVisible();
  23  |   return { actor, call, questionId: seeded?.questionId as string, principal, credential };
  24  | }
  25  | async function fill(page: Page, title = '匿名平均对象的完整原稿') {
  26  |   await composer(page).getByLabel('草稿名称', { exact: true }).fill(title);
  27  |   await composer(page).getByLabel('完整题干', { exact: true }).fill('三人与两人的总分分别18与14，求五人平均分。原题尾行条件保持。');
  28  |   await composer(page).getByLabel('参考答案', { exact: true }).fill('6.4');
  29  |   await composer(page).getByLabel('参考解析（可选）', { exact: true }).fill('先合计总分32，再以总人数5作为分母。');
  30  |   if (await composer(page).getByLabel('待核对作答', { exact: true }).count()) await composer(page).getByLabel('待核对作答', { exact: true }).fill('18+14=32；32/2=16。保留首次原文尾行。');
  31  |   await expect(composer(page).getByLabel('选择大模型', { exact: true })).toBeEnabled();
  32  | }
  33  | async function preview(page: Page) { await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).getByRole('region', { name: '完整输入预检', exact: true })).toBeVisible(); }
  34  | async function generate(page: Page) { await composer(page).getByRole('button', { name: '确认输入并生成草稿', exact: true }).click(); await expect(detail(page)).toBeVisible(); return new URL(page.url()).searchParams.get('run')!; }
  35  | async function done(page: Page) { await expect(detail(page).getByText('草稿已生成', { exact: true })).toBeVisible({ timeout: 25000 }); }
  36  | 
  37  | for (const width of [390, 768, 1280]) test(`teaching tools: complete analysis, original input and unreviewed result at ${width}`, async ({ page }) => {
  38  |   const f = await enter(page, width); await fill(page); await expect(composer(page).getByLabel('选择大模型')).toHaveValue('auto');
  39  |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); await preview(page);
  40  |   await expect(composer(page).getByRole('region', { name: '完整输入预检' })).toContainText('原题尾行条件保持。');
  41  |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  42  |   const runId = await generate(page); await done(page); await expect(detail(page)).toContainText('尚未人工核对'); await expect(detail(page)).toContainText('单次回答尚不足以确定稳定的能力原因。');
  43  |   const run = await f.call('/ai/teaching-tools/runs/' + runId); expect(run).toMatchObject({ status: 'completed', modelId: 'deepseek-v4-flash', advisoryOnly: true, reviewRequired: true });
  44  |   expect(run.snapshot.answer).toContain('保留首次原文尾行'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  45  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  46  |   await page.screenshot({ path: evidence + '/analysis-' + width + '.png', fullPage: true }); await page.reload(); await done(page);
  47  |   expect(new URL(page.url()).searchParams.get('run')).toBe(runId); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('匿名平均对象的完整原稿');
  48  | });
  49  | 
  50  | test('teaching tools: bank preflight shows actual table and formula, freezing the server original version and structured answer', async ({ page }) => {
  51  |   const f = await enter(page); await composer(page).getByRole('button', { name: '选择题库原题', exact: true }).click();
  52  |   await composer(page).getByLabel('查找题目').fill(f.questionId); await composer(page).locator('.tt-question-list>button').filter({ hasText: f.questionId }).click();
  53  |   await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); await composer(page).getByLabel('待核对作答', { exact: true }).fill(JSON.stringify({ steps: ['18+14=32', '32/2=16'], result: 16 }));
  54  |   await preview(page); const panel = composer(page).getByRole('region', { name: '完整输入预检' });
  55  |   await expect(panel.getByRole('table')).toBeVisible(); await expect(panel.locator('.katex')).toBeVisible(); await expect(panel).toContainText('原文版本 3');
  56  |   const id = await generate(page); await done(page); const run = await f.call('/ai/teaching-tools/runs/' + id);
  57  |   expect(run.snapshot.source).toMatchObject({ kind: 'question_bank', questionId: f.questionId }); expect(run.snapshot.question.originalDocument.version).toBe(3);
  58  |   expect(run.snapshot.question.originalDocument.blocks.map((block: any) => block.type)).toEqual(['text', 'table', 'math_display']); expect(run.snapshot.answer.steps[1]).toBe('32/2=16');
  59  | });
  60  | 
  61  | test('teaching tools: hint failure stays explicit and a retry uses the frozen original model after changing the composer', async ({ page }) => {
  62  |   const f = await enter(page); await page.getByRole('tab', { name: '提示草稿', exact: true }).click(); await fill(page, '分母提示草稿');
  63  |   await composer(page).getByLabel('帮助层级').selectOption('2'); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  64  |   await f.call('/qa/teaching-tools/behavior', { mode: 'fail_once' }); await preview(page); const id = await generate(page);
  65  |   await expect(detail(page).getByText('本次未完成', { exact: true })).toBeVisible(); await expect(detail(page).getByText('先把全部人数逐个列出来，再解释要平均的是谁。', { exact: true })).toHaveCount(0);
  66  |   await composer(page).getByLabel('选择大模型').selectOption('gpt-6.1-sol'); await detail(page).getByRole('button', { name: '使用原模型重试 · Claude Sonnet 5', exact: true }).click(); await done(page);
  67  |   const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.modelId).toBe('claude-sonnet-5'); expect(run.result.hint.suggestedLevel).toBe(2);
  68  |   expect((await f.call('/qa/teaching-tools/observations')).calls.map((item: any) => item.modelId)).toEqual(['claude-sonnet-5', 'claude-sonnet-5']);
  69  | });
  70  | 
  71  | test('teaching tools: lost creation acknowledgement restores the same original command after reload without duplicate generation', async ({ page }) => {
  72  |   const f = await enter(page); await fill(page, '原命令必须只生成一次'); await preview(page);
  73  |   let posts = 0; await page.route('**/api/ai/teaching-tools/runs', async route => { if (route.request().method() !== 'POST') return route.continue(); posts++; await route.fetch(); await route.abort('failed'); });
  74  |   await composer(page).getByRole('button', { name: '确认输入并生成草稿', exact: true }).click(); await expect(composer(page).getByRole('button', { name: '恢复原请求', exact: true })).toBeVisible();
  75  |   await expect(composer(page).getByLabel('选择大模型')).toBeEnabled(); await composer(page).getByLabel('选择大模型').selectOption('claude-sonnet-5');
  76  |   await page.unroute('**/api/ai/teaching-tools/runs'); await page.reload(); await composer(page).getByRole('button', { name: '恢复原请求', exact: true }).click(); await done(page);
  77  |   expect(posts).toBe(1); const list = await f.call('/ai/teaching-tools/runs'); expect(list.runs).toHaveLength(1); expect(list.runs[0].modelId).toBe('deepseek-v4-flash');
  78  |   await expect(composer(page).getByLabel('选择大模型')).toHaveValue('claude-sonnet-5'); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  79  | });
  80  | 
  81  | test('teaching tools: two tabs retain their own complete drafts and copying another preserves the current version', async ({ page, context }) => {
  82  |   await enter(page); await fill(page, 'FIRST_DOCUMENT_COMPLETE_TAIL'); const second = await context.newPage(); await second.goto('/admin/ai-tools'); await fill(second, 'SECOND_DOCUMENT_COMPLETE_TAIL');
  83  |   await page.reload(); await expect(composer(page).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  84  |   await second.reload(); await expect(composer(second).getByLabel('草稿名称')).toHaveValue('SECOND_DOCUMENT_COMPLETE_TAIL');
  85  |   await composer(second).getByText('本机其他标签页的原稿', { exact: true }).click();
  86  |   await composer(second).locator('.tt-copies article').filter({ hasText: 'FIRST_DOCUMENT_COMPLETE_TAIL' }).first().getByRole('button', { name: '载入这个副本', exact: true }).click();
  87  |   await expect(composer(second).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  88  |   const titles = await second.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.form.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).form.title));
  89  |   expect(titles).toContain('FIRST_DOCUMENT_COMPLETE_TAIL'); expect(titles).toContain('SECOND_DOCUMENT_COMPLETE_TAIL'); await second.close();
  90  | });
  91  | 
  92  | test('teaching tools: failed local storage blocks navigation and logout until the complete original input is downloaded', async ({ page }) => {
  93  |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.teaching-tool.')) throw new DOMException('Synthetic quota', 'QuotaExceededError'); return original.call(this, key, value); }; });
  94  |   const f = await enter(page); await fill(page, 'STORAGE_FAILURE_FULL_ORIGINAL'); await expect(composer(page)).toContainText('本机存储暂不可用');
  95  |   await page.getByRole('link', { name: '教研后台', exact: true }).click(); await expect(page).toHaveURL(/\/admin\/ai-tools/); await page.getByRole('button', { name: '退出', exact: true }).click();
  96  |   await expect(page).toHaveURL(/\/admin\/ai-tools/); expect((await f.call('/auth/me')).role).toBe('admin');
  97  |   const downloadPromise = page.waitForEvent('download'); await composer(page).getByRole('button', { name: '下载完整原稿 ↗', exact: true }).click(); const download = await downloadPromise;
  98  |   const saved = JSON.parse(readFileSync((await download.path())!, 'utf8')); expect(saved.form.title).toBe('STORAGE_FAILURE_FULL_ORIGINAL'); expect(saved.form.answer).toContain('保留首次原文尾行');
  99  |   await page.getByRole('button', { name: '退出', exact: true }).click(); await expect(page).toHaveURL(/\/parent\/login/);
  100 | });
  101 | 
  102 | test('teaching tools: a provider finishing after cancellation cannot publish its late result', async ({ page }) => {
  103 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page); await preview(page); const id = await generate(page);
  104 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click();
  105 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible({ timeout: 20000 }); const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  106 | });
  107 | 
  108 | test('teaching tools: cancellation acknowledgement loss recovers its original control key after reload', async ({ page }) => {
  109 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  110 |   await page.route('**/api/ai/teaching-tools/runs/*/cancel', async route => { await route.fetch(); await route.abort('failed'); });
  111 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toBeVisible();
  112 |   await page.unroute('**/api/ai/teaching-tools/runs/*/cancel'); await page.reload(); await detail(page).getByRole('button', { name: '恢复原操作', exact: true }).click();
  113 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  114 | });
  115 | 
  116 | test('teaching tools: a role revocation unloads private work and fences the late provider reply', async ({ page }) => {
  117 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page, 'PRIVATE_TEACHING_OWNER_ONLY'); await preview(page); const id = await generate(page);
  118 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await f.call('/qa/teaching-tools/revoke', {});
  119 |   await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(page.getByText('PRIVATE_TEACHING_OWNER_ONLY', { exact: true })).toHaveCount(0);
  120 |   await page.waitForTimeout(1800); await f.call('/qa/teaching-tools/setup', {});
  121 |   await expect.poll(async () => (await f.call('/ai/teaching-tools/runs/' + id)).status, { timeout: 20000 }).toBe('failed'); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull();
```