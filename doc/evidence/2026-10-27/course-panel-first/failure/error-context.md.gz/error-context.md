# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-panels.spec.ts >> course panels: a cross-unit practice returns to its original panel and reopens the exact first answer after refresh
- Location: tests\e2e\course-panels.spec.ts:38:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.cl-answer-feedback')
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.cl-answer-feedback') with timeout 15000ms
  - waiting for locator('.cl-answer-feedback')

```

```yaml
- alert
- main:
  - region "课堂练习题目":
    - button "关闭独立练习"
    - navigation "题目进度":
      - button "第1题"
      - button "第2题"
      - button "第3题"
    - text: 已答 1/3
    - button "☏ Assistant": Assistant
    - text: SINGLE CHOICE 第2题，共3题 · 规范与价值观
    - heading "共享厨房倡导“尊重使用者”，规定用完擦净台面，管理员会提醒未清理者。哪项区分正确？" [level=2]
    - paragraph: 选择一个最合适的选项。
    - status: 当前选择：未选
    - group "选择一个选项":
      - text: 选择一个选项
      - radio "没有罚款就不存在规范和制裁"
      - text: 没有罚款就不存在规范和制裁
      - radio "三者都是同一种个人偏好"
      - text: 三者都是同一种个人偏好
      - radio "擦台面是价值观，尊重使用者只是惩罚"
      - text: 擦台面是价值观，尊重使用者只是惩罚
      - radio "尊重是价值取向，清理是具体规范，提醒是非正式制裁"
      - text: 尊重是价值取向，清理是具体规范，提醒是非正式制裁
    - button "先给我一个提示"
    - button "上一题"
    - button "Check →" [disabled]
    - button "Skip"
    - button "这题我不会"
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash } from 'node:crypto';
  3  | import { browserEvidence } from './evidence';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  5  | const evidence = browserEvidence('course-panels');
  6  | async function enter(page: Page, width = 1280) {
  7  |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  8  |   const nonce = crypto.randomUUID(), principal = 'course-panel-' + nonce + '@local.test', credential = 'Panel-QA-' + nonce;
  9  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  10 |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  11 |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  12 |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  13 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  14 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  15 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  16 |   await page.goto('/studio/classroom?unit=0&panel=units');
  17 |   await expect(page.locator('.cl-lecture')).toHaveCount(5);
  18 |   const read = async (path: string) => { const response = await fetch(api + path, { headers: { Authorization: 'Bearer ' + actor.token, 'X-Forwarded-For': address } }); expect(response.ok).toBe(true); return (await response.json()).data; };
  19 |   return { read };
  20 | }
  21 | for (const width of [390, 768, 1280, 1440]) test(`course panels: references and all activities preserve the unit outline, complete titles and keyboard focus at ${width}`, async ({ page }) => {
  22 |   await enter(page, width);
  23 |   const first = page.locator('.cl-lecture').first(); await expect(first.getByRole('button').first()).toHaveAttribute('aria-expanded', 'true');
  24 |   const units = page.getByRole('tab', { name: '单元', exact: true }); await units.focus(); await page.keyboard.press('ArrowRight');
  25 |   await expect(page.getByRole('tab', { name: '资料', exact: true })).toBeFocused();
  26 |   await expect(page.getByRole('tabpanel', { name: '资料', exact: true })).toContainText('延伸阅读');
  27 |   await expect(page.locator('.cl-lecture')).toHaveCount(5); await expect(first.getByRole('button').first()).toHaveAttribute('aria-expanded', 'true');
  28 |   await page.keyboard.press('End'); await expect(page.getByRole('tab', { name: '练习', exact: true })).toBeFocused();
  29 |   const practices = page.getByRole('tabpanel', { name: '练习', exact: true }); await expect(practices.locator('.cl-panel-activity')).toHaveCount(70);
  30 |   await expect(practices).toContainText('单元 5 · Unit Check');
  31 |   await expect(page.locator('.cl-lecture')).toHaveCount(5);
  32 |   const last = practices.locator('.cl-panel-activity').last(); await last.scrollIntoViewIfNeeded();
  33 |   const box = await last.boundingBox(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width);
  34 |   await page.screenshot({ path: evidence + '/activities-' + width + '.png', fullPage: true });
  35 |   await page.reload(); await expect(page.getByRole('tab', { name: '练习', exact: true })).toHaveAttribute('aria-selected', 'true');
  36 |   await expect(page.locator('.cl-lecture')).toHaveCount(5);
  37 | });
  38 | test('course panels: a cross-unit practice returns to its original panel and reopens the exact first answer after refresh', async ({ page }) => {
  39 |   const { read } = await enter(page), catalog = await read('/learning/classroom/catalog'), lesson = catalog.course.units[1].lectures[0].lessons[0];
  40 |   await page.getByRole('tab', { name: '练习', exact: true }).click();
  41 |   const entry = () => page.getByRole('tabpanel', { name: '练习', exact: true }).getByRole('button').filter({ hasText: lesson.title }).first();
  42 |   await entry().click(); await expect(page.getByRole('button', { name: 'Check →', exact: true })).toBeVisible();
  43 |   const original = new URL(page.url()).searchParams.get('session')!;
  44 |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →', exact: true }).click();
  45 |   await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  46 |   const saved = await read('/learning/classroom/sessions/' + original); expect(saved.answers).toHaveLength(1);
  47 |   await page.getByRole('button', { name: '关闭独立练习', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  48 |   await expect(page.getByRole('tab', { name: '练习', exact: true })).toHaveAttribute('aria-selected', 'true');
  49 |   await expect(page).toHaveURL(/unit=1/); await page.reload(); await entry().click();
> 50 |   await expect(page.locator('.cl-answer-feedback')).toBeVisible(); expect(new URL(page.url()).searchParams.get('session')).toBe(original);
     |                                                     ^ Error: expect(locator).toBeVisible() failed
  51 |   expect((await read('/learning/classroom/sessions/' + original)).answers).toEqual(saved.answers);
  52 | });
  53 | 
```