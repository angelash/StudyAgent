# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player
- Location: tests/e2e/topic-whiteboard.spec.ts:321:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('table')
Expected substring: "完整尾行条件"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('table') with timeout 15000ms
  - waiting for getByRole('table')

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - link "Home":
        - /url: /studio?view=home
        - text: 首页
      - link "Courses":
        - /url: /studio?view=courses
        - text: 课程
      - link "Calendar":
        - /url: /studio?view=calendar
        - text: 学习动态
      - link "History":
        - /url: /studio?view=history
        - text: 历史
      - link "Materials":
        - /url: /studio?view=materials
        - text: 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom
    - heading "近期活动" [level=2]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页 →":
      - /url: /learn?subject=math
  - text: WHITEBOARD STUDIO
  - heading "从一个问题开始，讲清每一步。" [level=1]
  - paragraph: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
  - link "返回学习工作台 →":
    - /url: /studio
  - complementary:
    - text: NEW BOARD
    - heading "这次想弄懂什么？" [level=2]
    - text: 学习对象
    - combobox "白板学习对象":
      - option "我自己 · 成人主题" [selected]
    - region "新建AI白板":
      - group:
        - text: 讲解主题
        - textbox "讲解主题":
          - /placeholder: 例如：为什么先统一单位，才能比较和合并？
          - text: 用匿名观察解释条件与推断
        - text: 希望弄懂什么
        - textbox "希望弄懂什么":
          - /placeholder: 想理解的区别、步骤，或一个具体困惑
          - text: 保留完整条件，说明观察、推断和替代解释的区别。
        - text: 模型
        - combobox "选择大模型":
          - option "Auto · 当前默认模型"
      - status: 已恢复此标签页的原主题与模型选择。
      - button "预检主题与范围"
      - button "生成教学稿" [disabled]
      - button "下载原主题与请求"
      - group: 查看其他本机主题
  - region "白板工作区":
    - text: SAVED BOARD
    - heading "把条件讲清楚" [level=2]
    - paragraph: AI生成 · 待内容核对 · Browser fixture · not a real model
    - button "继续阅读"
    - button "查看自己的原稿"
    - dialog "白板视频":
      - button "关闭白板": ×
      - heading "把条件讲清楚" [level=2]
      - navigation "白板视图":
        - button "缩小白板": −
        - button "重置白板视图": 100%
        - button "放大白板": +
        - group "白板页码":
          - button "上一页白板" [disabled]: ‹
          - text: 1 / 1
          - button "下一页白板" [disabled]: ›
        - group "白板工具":
          - button "分享与导出"
          - button "白板设置"
        - button "收起讲稿与笔记" [expanded]
      - button "静音"
      - main:
        - paragraph: "[whiteboard-fixture] 先核对观察。"
        - text: 播放进度（估计阅读）
        - slider "播放进度（估计阅读）": "0"
        - button "上一句" [disabled]: ←
        - button "播放": ▶
        - button "下一句": →
        - text: 1 / 6 句
        - combobox "阅读方式":
          - option "文字阅读（估计时长）"
          - option "云语音逐句播放" [selected]
        - combobox "旁白音色":
          - option "合成音轨 A" [selected]
        - combobox "播放速度":
          - option "0.5×"
          - option "0.75×"
          - option "1×" [selected]
          - option "1.25×"
          - option "1.5×"
          - option "2×"
        - text: 板书字体
        - combobox "板书字体":
          - option "手写板书" [selected]
          - option "标准板书"
        - checkbox "点阵" [checked]
        - text: 点阵
        - button "导出视频"
        - button "导出字幕"
        - status
        - button "01 先核对观察"
        - button "02 再比较条件"
        - button "03 最后保留反例"
      - separator "调整讲稿面板宽度"
      - complementary "完整讲稿与要点":
        - button "收起讲稿与笔记"
        - region "原句提问":
          - heading "一起想清楚" [level=3]
          - text: AI补充讲解
          - group: 带走完整教学笔记
          - paragraph: 哪里没听懂，就从那一句问起。
          - text: 向老师提问
          - textbox "向老师提问":
            - /placeholder: 对这句有疑问？
          - combobox "讲解方式":
            - option "问一个问题" [selected]
            - option "换个例子"
            - option "讲简单些"
            - option "补补基础"
            - option "对比理解"
          - combobox "选择大模型":
            - option "Auto · 当前默认模型"
          - button "发送" [disabled]
          - group:
            - text: 保留与恢复提问
            - button "下载完整提问副本"
            - button "查看其他本机输入"
            - text: 导入完整提问副本
            - button "导入完整提问副本"
        - heading "逐句讲稿" [level=3]
        - paragraph: 点击一句定位。观看与续播不计作掌握。
        - list:
          - listitem:
            - button "[whiteboard-fixture] 先核对观察。"
          - listitem:
            - button "保留未知条件，不把一次观察当成完整能力证明。"
          - listitem:
            - button "[whiteboard-fixture] 再比较条件。"
          - listitem:
            - button "保留未知条件，不把一次观察当成完整能力证明。"
          - listitem:
            - button "[whiteboard-fixture] 最后保留反例。"
          - listitem:
            - button "保留未知条件，不把一次观察当成完整能力证明。"
        - heading "完整笔记与来源" [level=3]
        - group:
          - text: 先核对观察
          - paragraph: 完整说明首行。完整说明尾行。
          - list:
            - listitem: 先核对观察
        - group: 再比较条件
        - group: 最后保留反例
        - paragraph: AI生成 · 待内容核对 · Browser fixture · not a real model
        - button "下载续播位置"
  - complementary "白板与候选历史":
    - heading "我的白板" [level=2]
    - button "＋ 新白板"
    - button "教学草稿" [pressed]
    - button "已保存"
    - text: 搜索我的白板
    - textbox "搜索我的白板":
      - /placeholder: 搜索主题或标题
    - button "已保存白板 · 本人主题 把条件讲清楚 Browser fixture · not a real model"
    - button "上一页" [disabled]
    - text: 1 / 1
    - button "下一页" [disabled]
```

# Test source

```ts
  253 | test('topic-figure: uncached complete image commands block leaving until their exact complete download', async ({ page }) => {
  254 |   await fixture(page); await generate(page); await ready(page);
  255 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  256 |     if (key.startsWith('studyagent.topic-whiteboard.figures.')) throw new DOMException('Synthetic unavailable image storage', 'QuotaExceededError'); return original.call(this, key, value);
  257 |   }; });
  258 |   let writes = 0;
  259 |   await page.route('**/api/learning/studio/topic-whiteboard-visuals', async route => {
  260 |     if (route.request().method() !== 'POST') return route.continue(); writes++; expect((await route.fetch()).status()).toBe(201); await route.abort('failed');
  261 |   });
  262 |   const pane = await figure(page, '即使本机拒写，也要保留这一完整需求及原图生成命令。');
  263 |   await expect(pane.getByRole('button', { name: '恢复原配图请求', exact: true })).toBeEnabled();
  264 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(pane).toBeVisible();
  265 |   const download = page.waitForEvent('download'); await pane.getByRole('button', { name: '下载完整配图请求', exact: true }).click();
  266 |   const saved = JSON.parse(readFileSync((await (await download).path())!, 'utf8'));
  267 |   expect(saved.pending.body).toMatchObject({ operation: 'generate', requirements: '即使本机拒写，也要保留这一完整需求及原图生成命令。' });
  268 |   expect(saved.pending.body.requestKey).toBeTruthy(); expect(saved.draftId).toBe(saved.pending.body.draftId); expect(writes).toBe(1);
  269 |   expect(saved.pending.path).toBe(figureBase);
  270 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(pane).toHaveCount(0);
  271 | });
  272 | 
  273 | test('topic-figure: mismatched image bytes stay hidden and can be reread without creating another candidate', async ({ page }) => {
  274 |   const f = await fixture(page); await generate(page); await ready(page); const id = new URL(page.url()).searchParams.get('draft')!;
  275 |   await page.route('**/api/learning/studio/topic-whiteboard-visuals/*/image', route => route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.from('Synthetic changed PNG bytes') }));
  276 |   const pane = await figure(page), current = pane.getByRole('article', { name: '当前图片候选' });
  277 |   await expect(current.getByRole('alert')).toContainText('字节与已保存版本不一致'); await expect(current.getByRole('button', { name: '选入当前完整稿', exact: true })).toBeDisabled();
  278 |   await expect(current.locator('.tw-figure-open')).toHaveCount(0);
  279 |   await page.unroute('**/api/learning/studio/topic-whiteboard-visuals/*/image');
  280 |   await current.getByRole('button', { name: '重新读取图片', exact: true }).click();
  281 |   await expect(current.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible();
  282 |   expect((await f.call(figureBase + '?draftId=' + id + '&sceneIndex=0', undefined, 'GET')).total).toBe(1);
  283 | });
  284 | 
  285 | test('topic-figure: an explicit running cancellation and retry keep the same original candidate and advance its task generation', async ({ page }) => {
  286 |   const f = await fixture(page); await generate(page); await ready(page); const id = new URL(page.url()).searchParams.get('draft')!;
  287 |   const pane = await figure(page, '[image-pause-once] 暂停的匿名概念图，用于验证原任务取消和重试。');
  288 |   const current = pane.getByRole('article', { name: '当前图片候选' }); await expect(current.getByRole('heading', { name: '正在生成参考图', exact: true })).toBeVisible();
  289 |   await current.getByRole('button', { name: '取消图片生成', exact: true }).click();
  290 |   await expect(current.getByRole('heading', { name: '生成已取消', exact: true })).toBeVisible();
  291 |   await current.getByRole('button', { name: '重试原图片任务', exact: true }).click(); await expect(current.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible();
  292 |   const list = await f.call(figureBase + '?draftId=' + id + '&sceneIndex=0', undefined, 'GET'); expect(list.total).toBe(1); expect(list.items[0].task.generation).toBe(2);
  293 | });
  294 | 
  295 | test('topic-figure: two actual tabs retain separate full figure inputs and metadata across reloads', async ({ page }) => {
  296 |   await fixture(page); await generate(page); await ready(page); const second = await page.context().newPage();
  297 |   try {
  298 |     await second.goto(page.url()); await ready(second);
  299 |     const firstPane = page.getByRole('region', { name: '白板配图工作区' }), secondPane = second.getByRole('region', { name: '白板配图工作区' });
  300 |     await firstPane.getByLabel('希望图片说明什么').fill('第一标签页完整的配图要求。'); await secondPane.getByLabel('希望图片说明什么').fill('第二标签页不同的配图要求。');
  301 |     const copies = () => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.figures.')).map(key => JSON.parse(localStorage.getItem(key)!).form.requirements));
  302 |     await expect.poll(copies).toContain('第一标签页完整的配图要求。'); await expect.poll(copies).toContain('第二标签页不同的配图要求。');
  303 |     await page.reload(); await ready(page); await expect(firstPane.getByLabel('希望图片说明什么')).toHaveValue('第一标签页完整的配图要求。');
  304 |     await second.reload(); await ready(second); await expect(secondPane.getByLabel('希望图片说明什么')).toHaveValue('第二标签页不同的配图要求。');
  305 |   } finally { await second.close(); }
  306 | });
  307 | 
  308 | for (const width of [390, 768, 1440]) test('topic-figure: complete verified image and keyboard reader fit ' + width, async ({ page }) => {
  309 |   await page.setViewportSize({ width, height: 900 }); await fixture(page); await generate(page); await ready(page); const pane = await figure(page);
  310 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible();
  311 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  312 |   await pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).click();
  313 |   const reader = page.locator('.cl-figure-reader-sheet'); await expect(reader).toBeVisible();
  314 |   const image = reader.locator('img'); expect(await image.evaluate((item: HTMLImageElement) => [item.naturalWidth, item.naturalHeight])).toEqual([1536, 1024]);
  315 |   expect(await reader.evaluate(item => item.scrollWidth <= item.clientWidth + 1)).toBe(true);
  316 |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'topic-figure-reader-' + width + '.png'), fullPage: false });
  317 |   await page.keyboard.press('Escape'); await expect(reader).toHaveCount(0);
  318 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeFocused();
  319 | });
  320 | 
  321 | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  322 |   const f = await fixture(page); let dropped = true;
  323 |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  324 |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  325 |   });
  326 |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  327 |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  328 |   const id = new URL(page.url()).searchParams.get('draft')!;
  329 |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  330 |   let editDropped = true, editWrites = 0;
  331 |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  332 |     editWrites++;
  333 |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  334 |   });
  335 |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  336 |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  337 |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  338 |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  339 |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  340 |   expect(editWrites).toBe(1);
  341 |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  342 |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  343 |   let confirmationDropped = true, confirmationWrites = 0;
  344 |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  345 |     confirmationWrites++;
  346 |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  347 |   });
  348 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  349 |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
  350 |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  351 |   expect(confirmationWrites).toBe(1);
  352 |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
> 353 |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
      |                                                                                                                                ^ Error: expect(locator).toContainText(expected) failed
  354 |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  355 |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  356 |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  357 |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  358 | });
  359 | 
  360 | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  361 |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  362 |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  363 |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  364 |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  365 |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  366 |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  367 |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  368 |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  369 | });
  370 | 
  371 | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  372 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  373 |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  374 |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  375 |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  376 |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  377 |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  378 |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  379 |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  380 | });
  381 | 
  382 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  383 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  384 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  385 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  386 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  387 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  388 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  389 | });
  390 | 
  391 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  392 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  393 |   try {
  394 |     await second.goto(href); await ready(second);
  395 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  396 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  397 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  398 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  399 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
  400 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  401 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  402 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  403 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  404 |   } finally { await second.close(); }
  405 | });
  406 | 
  407 | test('uncached original topic cannot disappear on a scope change until its complete input is downloaded', async ({ page }) => {
  408 |   const f = await fixture(page, true);
  409 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  410 |     if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value);
  411 |   }; });
  412 |   await page.getByLabel('讲解主题').fill('尚未生成也不能丢失的匿名主题');
  413 |   await page.getByLabel('希望弄懂什么').fill('保留我的完整教学目标。');
  414 |   await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  415 |   await expect(page.getByLabel('白板学习对象')).toHaveValue('');
  416 |   await expect(page.getByLabel('讲解主题')).toHaveValue('尚未生成也不能丢失的匿名主题');
  417 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载原主题与请求', exact: true }).click();
  418 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8'));
  419 |   expect(copy.form).toMatchObject({ prompt: '尚未生成也不能丢失的匿名主题', objective: '保留我的完整教学目标。' });
  420 |   await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  421 |   await expect(page.getByLabel('白板学习对象')).toHaveValue(f.studentId!);
  422 | });
  423 | 
  424 | test('another explicit local manuscript cannot replace uncached dirty input until the current complete copy is downloaded', async ({ page }) => {
  425 |   await fixture(page); await generate(page); await ready(page);
  426 |   await page.getByLabel('讲解概要').fill('第一份可恢复的完整本机改稿。');
  427 |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.description))).toContain('第一份可恢复的完整本机改稿。');
  428 |   await page.reload(); await ready(page);
  429 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  430 |     if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value);
  431 |   }; });
  432 |   await page.getByLabel('讲解概要').fill('尚无本机缓存的第二份完整改稿。');
  433 |   await page.getByText('查看其他本机改稿', { exact: true }).click();
  434 |   const restore = page.getByRole('button', { name: '恢复这份本机改稿', exact: true }).first(); await expect(restore).toBeDisabled();
  435 |   await expect(page.getByLabel('讲解概要')).toHaveValue('尚无本机缓存的第二份完整改稿。');
  436 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  437 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('尚无本机缓存的第二份完整改稿。');
  438 |   await expect(restore).toBeEnabled(); await restore.click();
  439 |   await expect(page.getByLabel('讲解概要')).toHaveValue('第一份可恢复的完整本机改稿。');
  440 | });
  441 | 
  442 | test('recovery: an uncached original cancellation survives object changes until its exact command is downloaded', async ({ page }) => {
  443 |   await fixture(page); await generate(page, '匿名观察 [topic-pause-once]');
  444 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  445 |     if (key.startsWith('studyagent.topic-whiteboard.command.')) throw new DOMException('Synthetic unavailable command storage', 'QuotaExceededError'); return original.call(this, key, value);
  446 |   }; });
  447 |   let writes = 0;
  448 |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/cancel', async route => {
  449 |     writes++; expect((await route.fetch()).status()).toBe(201); await route.abort('failed');
  450 |   });
  451 |   await page.getByRole('button', { name: '取消生成', exact: true }).click();
  452 |   await expect(page.getByRole('button', { name: '恢复原取消请求', exact: true })).toBeEnabled();
  453 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.locator('.tw-candidate')).toBeVisible();
```