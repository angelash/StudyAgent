const fs = require('node:fs'), path = require('node:path'), zlib = require('node:zlib'), assert = require('node:assert/strict');
const { createHash } = require('node:crypto'), { execFileSync } = require('node:child_process');
const root = process.cwd(), branch = path.resolve(root, '../StudyAgent-whiteboard-questions'), head = 'e99e4da818645a057eba98641405086098105ac2', run = 40428575995;
const read = p => JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '')), hash = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const git = (args, cwd = root) => execFileSync('git', args, { cwd, encoding: 'utf8', windowsHide: true }).trim();
const inputFile = 'doc/evidence/2026-10-27/whiteboard-question-final-full-local/receipt.json', input = read(path.join(branch, inputFile));
assert.equal(input.applicationRevision, head); assert.equal(input.schemaVersion, 19); assert.equal(input.api.passed, 1418); assert.equal(input.api.environmentSkipped, 54); assert.equal(input.api.failed, 0);
assert.equal(input.postgres.passed, 24); assert.equal(input.postgres.newLocalRun, true); assert.equal(Object.keys(input.compiledSha256).length, 353);
assert.equal(git(['status', '--porcelain'], branch), ''); const deliveryHead = git(['rev-parse', 'HEAD'], branch);
git(['merge-base', '--is-ancestor', head, deliveryHead], branch);
assert(git(['diff', '--name-only', head, deliveryHead], branch).split(/\r?\n/).filter(Boolean).every(p => p.startsWith('doc/')));
for (const [p, expected] of Object.entries(input.sourceSha256)) assert.equal(hash(path.join(branch, p)), expected, 'Source changed: ' + p);
for (const [p, expected] of Object.entries(input.compiledSha256)) assert.equal(hash(path.join(branch, p)), expected, 'Compiled input changed: ' + p);
for (const [p, expected] of Object.entries(input.qaWeb.sourceSha256)) assert.equal(hash(path.join(branch, 'data/qa/experience-web', p)), expected, 'Actual QA Web changed: ' + p);
function browser(p) {
  const report = read(p), cases = []; const walk = s => { for (const spec of s.specs || []) cases.push(...spec.tests); for (const child of s.suites || []) walk(child); }; report.suites.forEach(walk);
  assert.equal(report.stats.expected, 354); assert.equal(report.stats.unexpected, 0); assert.equal(report.stats.flaky, 0); assert.equal(report.stats.skipped, 0); assert.equal(report.errors.length, 0);
  assert.equal(cases.length, 354); assert(cases.every(t => t.results.length === 1 && t.results[0].status === 'passed'));
}
const local = path.join(branch, 'data/qa/source-course-full-browser.json'), remote = path.join(branch, 'data/qa/whiteboard-question-ci-e99e4da-artifacts/data/qa/source-course-full-browser.json');
browser(local); browser(remote); assert.equal(hash(local), input.browser.sha256);
const api = read(path.join(branch, input.api.source)); assert(api.success && api.numPassedTests === 1418 && api.numPendingTests === 54 && api.numFailedTests === 0); assert.equal(hash(path.join(branch, input.api.source)), input.api.sha256);
const pg = read(path.join(branch, input.postgres.source)); assert(pg.success && pg.numPassedTests === 24 && pg.numFailedTests === 0); assert.equal(hash(path.join(branch, input.postgres.source)), input.postgres.sha256);
const ci = JSON.parse(execFileSync('gh', ['run', 'view', String(run), '--json', 'status,conclusion,headSha,jobs'], { encoding: 'utf8', windowsHide: true }));
assert(ci.status === 'completed' && ci.conclusion === 'success' && ci.headSha === head && ci.jobs.length === 3 && ci.jobs.every(j => j.status === 'completed' && j.conclusion === 'success'));
const latest = read('data/qa/whiteboard-question-release-latest.json'), release = path.resolve(root, latest.folder), before = read(path.join(release, 'deployment-before.json'));
assert(release.startsWith(path.join(root, 'output/daemon/release-backups') + path.sep) && fs.realpathSync(release).toLowerCase() === release.toLowerCase());
assert.equal(git(['rev-parse', 'HEAD']), before.revision); assert(before.revision.startsWith('a9b33d8')); assert.equal(before.oldWebBuildId, 'HzR4EwWBJcn7nJkoQa_Jw');
for (const [p, expected] of Object.entries(before.protectedFiles)) assert.equal(hash(p), expected, 'Protected configuration changed');
assert.equal(hash('.env'), hash(path.join(release, 'config/.env')));
for (const file of read(path.join(release, 'build-files.json'))) {
  assert.equal(hash(file.path), file.sha256, 'Original build changed: ' + file.path); assert.equal(hash(path.join(release, 'build', file.path)), file.sha256, 'Original rollback copy changed');
}
const artifact = 'data/qa/whiteboard-question-ci-40428575995-browser-original.json.gz'; fs.writeFileSync(artifact, zlib.gzipSync(fs.readFileSync(remote)), { flag: 'wx' });
const candidate = { status: 'ready-for-release', at: new Date().toISOString(), head, deliveryHead, applicationRevision: head, apiRevision: head, schemaVersion: 19,
  ciRun: run, verifiedZeroRetries: true, apiLocalPassed: 1418, apiLocalFailed: 0, apiEnvironmentSkipped: 54, postgresNewLocalRun: true, localPostgresCases: 24,
  localBrowserCases: 354, remoteBrowserCases: 354, inputReceipt: inputFile, inputReceiptSha256: hash(path.join(branch, inputFile)),
  browserArtifact: artifact, browserArtifactSha256: hash(artifact), originalBrowserSha256: hash(remote), localBrowserSha256: hash(local), compiledSha256: input.compiledSha256, formatOnlyCompiledDifferences: [] };
fs.writeFileSync(path.join(release, 'candidate.json'), JSON.stringify(candidate, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: candidate.status, ciHead: head, deliveryHead, localBrowser: 354, remoteBrowser: 354, compiledFiles: 353, localApi: 1418, localPostgres: 24 }));
