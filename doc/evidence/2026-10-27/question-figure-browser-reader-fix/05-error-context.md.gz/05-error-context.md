# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-questions.spec.ts >> question figures: exact PNG adoption binds voice, video, private links, complete notes and original-version review
- Location: tests\e2e\whiteboard-questions.spec.ts:254:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('dialog', { name: 'AI补充讲解', exact: true }).locator('.tw-figure')
Expected: 1
Received: 2
Timeout:  15000ms

Call log:
  - Expect "toHaveCount" getByRole('dialog', { name: 'AI补充讲解', exact: true }).locator('.tw-figure') with timeout 15000ms
  - waiting for getByRole('dialog', { name: 'AI补充讲解', exact: true }).locator('.tw-figure')
    33 × locator resolved to 2 elements
       - unexpected value "2"

```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - alert [ref=f2e2]
  - main [ref=f2e3]:
    - complementary "学习工作台导航" [ref=f2e4]:
      - link "StudyAgent" [ref=f2e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f2e9]:
        - button "Home" [ref=f2e10] [cursor=pointer]:
          - generic [ref=f2e13]: 首页
        - button "Courses" [ref=f2e14] [cursor=pointer]:
          - generic [ref=f2e17]: 课程
        - button "Calendar" [ref=f2e18] [cursor=pointer]:
          - generic [ref=f2e21]: 学习动态
        - button "History" [ref=f2e22] [cursor=pointer]:
          - generic [ref=f2e25]: 历史
        - button "Materials" [ref=f2e26] [cursor=pointer]:
          - generic [ref=f2e29]: 资料
        - link "AI Whiteboards" [ref=f2e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f2e33]: AI白板
      - button "＋ 创建课程" [ref=f2e34] [cursor=pointer]
      - generic [ref=f2e35]:
        - heading "继续学习" [level=2] [ref=f2e36]
        - link "讲座社会学想象力 社会学概论" [ref=f2e37] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f2e38]: 社会学概论
      - generic [ref=f2e39]:
        - heading "近期活动" [level=2] [ref=f2e40]
        - link "白板视频「异分母分数加法」" [ref=f2e41] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_2e6eed0e-d29f-48eb-bdd3-3e8c0e311b6c
      - link "返回学习首页 →" [ref=f2e43] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_55e66b79-3711-459f-a392-28660f88f34e
    - generic [ref=f2e44]:
      - generic [ref=f2e45]:
        - generic [ref=f2e46]:
          - combobox "学习档案" [ref=f2e47]:
            - option "匿名插问验证" [selected]
          - combobox "学科" [ref=f2e48]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f2e49]:
          - link "教学课堂 ↗" [ref=f2e50] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f2e51] [cursor=pointer]:
            - /url: /
      - generic [ref=f2e52]:
        - generic [ref=f2e53]:
          - button "Craft Courses" [ref=f2e54] [cursor=pointer]
          - button "Instant Assistance" [ref=f2e55] [cursor=pointer]
        - generic [ref=f2e56]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f2e57]
          - paragraph [ref=f2e58]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f2e59]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f2e60]
          - generic [ref=f2e61]:
            - generic [ref=f2e62]: ＋
            - generic [ref=f2e63]: 资料
            - button "Concept Explanation" [ref=f2e64] [cursor=pointer]
            - generic [ref=f2e65]: 语音
            - generic [ref=f2e68]:
              - generic [ref=f2e69]: 模型
              - combobox "选择大模型" [ref=f2e70] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f2e71] [cursor=pointer]
        - generic [ref=f2e72]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f2e73] [cursor=pointer]:
            - generic [ref=f2e74]: 可视化
            - generic [ref=f2e75]: 用图形解释异分母加法
            - generic [ref=f2e76]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f2e77] [cursor=pointer]:
            - generic [ref=f2e78]: 个性化练习
            - generic [ref=f2e79]: 从我的已知点生成练习
            - generic [ref=f2e80]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f2e81] [cursor=pointer]:
            - generic [ref=f2e82]: 主动学习
            - generic [ref=f2e83]: 看看今天最值得做什么
            - generic [ref=f2e84]: 按教育优先级排序
        - generic [ref=f2e85]:
          - heading "你的学习路径" [level=2] [ref=f2e86]
          - button "创建课程" [ref=f2e87] [cursor=pointer]
        - generic [ref=f2e88]:
          - heading "还没有课程" [level=3] [ref=f2e89]
          - paragraph [ref=f2e90]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f2e91] [cursor=pointer]
        - complementary [ref=f2e92]:
          - article [ref=f2e93]:
            - generic [ref=f2e94]:
              - generic [ref=f2e95]:
                - text: LEARNER SNAPSHOT
                - heading "匿名插问验证" [level=2] [ref=f2e96]
              - generic [ref=f2e97]: 5 年级
            - generic [ref=f2e98]:
              - strong [ref=f2e99]: "0"
              - generic [ref=f2e100]: / 1
              - generic [ref=f2e101]: 已有点有稳定证据
            - generic [ref=f2e102]:
              - generic [ref=f2e103]:
                - generic [ref=f2e104]: "1"
                - text: 已确认知识点
              - generic [ref=f2e105]:
                - generic [ref=f2e106]: "0"
                - text: 日历安排
          - article [ref=f2e107]:
            - generic [ref=f2e108]:
              - generic [ref=f2e109]: NEXT BEST ACTION
              - button "全部 →" [ref=f2e110] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f2e111] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_55e66b79-3711-459f-a392-28660f88f34e&subject=math
              - generic [ref=f2e112]: 1个已学点仍需补充证据
              - paragraph [ref=f2e113]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f2e114]:
            - generic [ref=f2e115]:
              - generic [ref=f2e116]: RECENT WHITEBOARDS
              - button "新建" [ref=f2e117] [cursor=pointer]
            - button "▶ 匿名逐句白板 2 幕 · 1 秒" [ref=f2e118] [cursor=pointer]:
              - generic [ref=f2e119]: ▶
              - generic [ref=f2e120]:
                - generic [ref=f2e121]: 匿名逐句白板
                - generic [ref=f2e122]: 2 幕 · 1 秒
          - article [ref=f2e123]:
            - generic [ref=f2e124]:
              - generic [ref=f2e125]: SYNC STATUS
              - button "日历 →" [ref=f2e126] [cursor=pointer]
            - paragraph [ref=f2e127]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f2e128]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f2e129]:
      - generic:
        - button "关闭白板" [ref=f2e130] [cursor=pointer]: ×
        - heading "匿名逐句白板" [level=2] [ref=f2e132]
      - navigation "白板视图" [ref=f2e133]:
        - generic [ref=f2e134]:
          - button "缩小白板" [ref=f2e135] [cursor=pointer]: −
          - button "重置白板视图" [ref=f2e136] [cursor=pointer]: 100%
          - button "放大白板" [ref=f2e137] [cursor=pointer]: +
        - group "白板页码" [ref=f2e138]:
          - button "上一页白板" [disabled] [ref=f2e139]: ‹
          - generic [ref=f2e140]:
            - generic [ref=f2e141]: "1"
            - generic [ref=f2e142]: /
            - generic [ref=f2e143]: "1"
          - button "下一页白板" [disabled] [ref=f2e144]: ›
        - group "白板工具" [ref=f2e145]:
          - button "分享与导出" [ref=f2e147] [cursor=pointer]
          - button "白板设置" [ref=f2e150] [cursor=pointer]
        - button "收起讲稿与笔记" [expanded] [ref=f2e153] [cursor=pointer]
      - button "静音" [ref=f2e155] [cursor=pointer]
      - generic [ref=f2e158]:
        - main [ref=f2e159]:
          - generic "统一单位" [ref=f2e161]
          - paragraph [ref=f2e162]: "[whiteboard-fixture] 先统一单位。"
          - generic [ref=f2e163]:
            - generic [ref=f2e164]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f2e165] [cursor=pointer]: "0"
          - generic [ref=f2e166]:
            - button "上一句" [disabled] [ref=f2e167]: ←
            - button "播放" [ref=f2e168] [cursor=pointer]: ▶
            - button "下一句" [ref=f2e169] [cursor=pointer]: →
            - generic [ref=f2e170]: 1 / 4 句
            - combobox "阅读方式" [ref=f2e171] [cursor=pointer]:
              - option "文字阅读（估计时长）"
              - option "云语音逐句播放" [selected]
            - combobox "旁白音色" [ref=f2e172] [cursor=pointer]:
              - option "合成音色A" [selected]
              - option "合成音色B"
            - combobox "播放速度" [ref=f2e173] [cursor=pointer]:
              - option "0.5×"
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
              - option "1.5×"
              - option "2×"
            - generic [ref=f2e174]:
              - generic [ref=f2e175]: 板书字体
              - combobox "板书字体" [ref=f2e176] [cursor=pointer]:
                - option "手写板书" [selected]
                - option "标准板书"
            - generic [ref=f2e177]:
              - checkbox "点阵" [checked] [ref=f2e178]
              - text: 点阵
            - button "导出视频" [ref=f2e179] [cursor=pointer]
            - button "导出字幕" [ref=f2e180] [cursor=pointer]
          - status [ref=f2e181]: 已恢复此账号在原白板的阅读位置；点击播放继续。
          - generic [ref=f2e182]:
            - button "01 统一单位" [ref=f2e183] [cursor=pointer]:
              - generic [ref=f2e184]: "01"
              - text: 统一单位
            - button "02 保留证据" [ref=f2e185] [cursor=pointer]:
              - generic [ref=f2e186]: "02"
              - text: 保留证据
        - generic [ref=f2e189]:
          - separator "调整讲稿面板宽度" [ref=f2e190]
          - complementary "完整讲稿与要点" [ref=f2e192]:
            - button "收起讲稿与笔记" [ref=f2e193] [cursor=pointer]
            - region "原句提问" [ref=f2e196]:
              - generic [ref=f2e197]:
                - heading "一起想清楚" [level=3] [ref=f2e198]
                - generic [ref=f2e199]: AI补充讲解
              - group [ref=f2e200]:
                - generic "带走完整教学笔记" [ref=f2e201] [cursor=pointer]
              - article [ref=f2e203]:
                - paragraph [ref=f2e204]: "[question-structure] 请将完整条件、表格和公式讲清楚。"
                - generic [ref=f2e205]:
                  - generic [ref=f2e206]: AI补充讲解
                  - generic [ref=f2e207]: Browser question fixture · deepseek-v4-flash
                - paragraph [ref=f2e208]: 先确认计数单位。第一行比较单位。第二行核对整体。现在解释分数公式。最后解释根式公式。
                - generic [ref=f2e209]: "[whiteboard-fixture] 先统一单位。"
                - button "查看补充板书与声音" [ref=f2e211] [cursor=pointer]
                - generic [ref=f2e212]:
                  - text: 讲解版本
                  - combobox "讲解版本" [ref=f2e213]:
                    - option "原回答 · 无配图"
                    - option "图片版本 1 · 10/27/2026, 9:10:00 AM · 当前采用" [selected]
                - button "为这段讲解配图" [ref=f2e214] [cursor=pointer]
                - button "回到这句 [whiteboard-fixture] 先统一单位。" [ref=f2e215] [cursor=pointer]:
                  - text: 回到这句
                  - generic [ref=f2e216]: "[whiteboard-fixture] 先统一单位。"
              - generic [ref=f2e217]:
                - generic [ref=f2e218]: 向老师提问
                - textbox "向老师提问" [ref=f2e219]:
                  - /placeholder: 对这句有疑问？
                - generic [ref=f2e220]:
                  - combobox "讲解方式" [ref=f2e221]:
                    - option "问一个问题" [selected]
                    - option "换个例子"
                    - option "讲简单些"
                    - option "补补基础"
                    - option "对比理解"
                  - combobox "选择大模型" [ref=f2e224] [cursor=pointer]:
                    - option "Auto · 当前默认模型"
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认" [selected]
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                  - button "发送" [disabled] [ref=f2e225]
                - status [ref=f2e226]: 已恢复这份原稿在本页的完整输入和原请求。
                - group [ref=f2e227]:
                  - generic "保留与恢复提问" [ref=f2e228] [cursor=pointer]
            - heading "逐句讲稿" [level=3] [ref=f2e229]
            - paragraph [ref=f2e230]: 点击一句定位。观看与续播不计作掌握。
            - list [ref=f2e231]:
              - listitem [ref=f2e232]:
                - button "[whiteboard-fixture] 先统一单位。" [ref=f2e233] [cursor=pointer]
              - listitem [ref=f2e234]:
                - button "[whiteboard-fixture] 再合并份数。" [ref=f2e235] [cursor=pointer]
              - listitem [ref=f2e236]:
                - button "[whiteboard-fixture] 最后验证。" [ref=f2e237] [cursor=pointer]
              - listitem [ref=f2e238]:
                - button "[whiteboard-fixture] 保留新的独立观察。" [ref=f2e239] [cursor=pointer]
            - heading "完整笔记与来源" [level=3] [ref=f2e240]
            - group [ref=f2e241]:
              - generic "统一单位" [ref=f2e242] [cursor=pointer]
              - paragraph [ref=f2e243]: 完整正文首行。完整正文末行。
              - list [ref=f2e244]:
                - listitem [ref=f2e245]: 先统一单位
                - listitem [ref=f2e246]: 再合并份数
                - listitem [ref=f2e247]: 最后验证
            - group [ref=f2e248]:
              - generic "保留证据" [ref=f2e249] [cursor=pointer]
            - button "下载续播位置" [ref=f2e250] [cursor=pointer]
      - dialog "AI补充讲解" [ref=f2e251]:
        - generic:
          - button "关闭白板" [active] [ref=f2e252] [cursor=pointer]: ×
          - button "返回原讲解" [ref=f2e253] [cursor=pointer]: ↩
          - heading "统一单位再比较" [level=2] [ref=f2e255]
        - navigation "白板视图" [ref=f2e256]:
          - generic [ref=f2e257]:
            - button "缩小白板" [ref=f2e258] [cursor=pointer]: −
            - button "重置白板视图" [ref=f2e259] [cursor=pointer]: 100%
            - button "放大白板" [ref=f2e260] [cursor=pointer]: +
          - group "白板页码" [ref=f2e261]:
            - button "上一页白板" [disabled] [ref=f2e262]: ‹
            - generic [ref=f2e263]:
              - generic [ref=f2e264]: "1"
              - generic [ref=f2e265]: /
              - generic [ref=f2e266]: "1"
            - button "下一页白板" [disabled] [ref=f2e267]: ›
          - group "白板工具" [ref=f2e268]:
            - button "分享与导出" [ref=f2e270] [cursor=pointer]
            - button "白板设置" [ref=f2e273] [cursor=pointer]
          - button "收起讲稿与笔记" [expanded] [ref=f2e276] [cursor=pointer]
        - button "静音" [ref=f2e278] [cursor=pointer]
        - generic [ref=f2e281]:
          - main [ref=f2e282]:
            - generic [ref=f2e283]:
              - generic "统一单位再比较" [ref=f2e284]
              - figure "先统一单位，再比较条件。" [ref=f2e285]:
                - button "放大参考图：统一单位再比较" [ref=f2e286]:
                  - generic [aria-hidden] [ref=f2e287]: ↗
            - paragraph [ref=f2e288]: 先确认计数单位。
            - generic [ref=f2e289]:
              - generic [ref=f2e290]: 播放进度（估计阅读）
              - slider "播放进度（估计阅读）" [ref=f2e291] [cursor=pointer]: "0"
            - generic [ref=f2e292]:
              - button "上一句" [disabled] [ref=f2e293]: ←
              - button "播放" [ref=f2e294] [cursor=pointer]: ▶
              - button "下一句" [ref=f2e295] [cursor=pointer]: →
              - generic [ref=f2e296]: 1 / 5 句
              - combobox "阅读方式" [ref=f2e297] [cursor=pointer]:
                - option "文字阅读（估计时长）"
                - option "云语音逐句播放" [selected]
              - combobox "旁白音色" [ref=f2e298] [cursor=pointer]:
                - option "合成音色A" [selected]
                - option "合成音色B"
              - combobox "播放速度" [ref=f2e299] [cursor=pointer]:
                - option "0.5×"
                - option "0.75×"
                - option "1×"
                - option "1.25×"
                - option "1.5×"
                - option "2×" [selected]
              - generic [ref=f2e300]:
                - generic [ref=f2e301]: 板书字体
                - combobox "板书字体" [ref=f2e302] [cursor=pointer]:
                  - option "手写板书" [selected]
                  - option "标准板书"
              - generic [ref=f2e303]:
                - checkbox "点阵" [checked] [ref=f2e304]
                - text: 点阵
              - button "导出视频" [ref=f2e305] [cursor=pointer]
              - button "导出字幕" [ref=f2e306] [cursor=pointer]
            - status [ref=f2e307]: 已恢复此账号在原白板的阅读位置；点击播放继续。
            - button "01 统一单位再比较" [ref=f2e309] [cursor=pointer]:
              - generic [ref=f2e310]: "01"
              - text: 统一单位再比较
          - generic [ref=f2e313]:
            - separator "调整讲稿面板宽度" [ref=f2e314]
            - complementary "完整讲稿与要点" [ref=f2e316]:
              - button "收起讲稿与笔记" [ref=f2e317] [cursor=pointer]
              - heading "逐句讲稿" [level=3] [ref=f2e320]
              - paragraph [ref=f2e321]: 点击一句定位。观看与续播不计作掌握。
              - list [ref=f2e322]:
                - listitem [ref=f2e323]:
                  - button "先确认计数单位。" [ref=f2e324] [cursor=pointer]
                - listitem [ref=f2e325]:
                  - button "第一行比较单位。" [ref=f2e326] [cursor=pointer]
                - listitem [ref=f2e327]:
                  - button "第二行核对整体。" [ref=f2e328] [cursor=pointer]
                - listitem [ref=f2e329]:
                  - button "现在解释分数公式。" [ref=f2e330] [cursor=pointer]
                - listitem [ref=f2e331]:
                  - button "最后解释根式公式。" [ref=f2e332] [cursor=pointer]
              - heading "完整笔记与来源" [level=3] [ref=f2e333]
              - group [ref=f2e334]:
                - generic "统一单位再比较" [ref=f2e335] [cursor=pointer]
                - list [ref=f2e336]:
                  - listitem [ref=f2e337]: 比较前确认计数单位
                - generic "完整对照表" [ref=f2e338]:
                  - table [ref=f2e339]:
                    - rowgroup [ref=f2e340]:
                      - row [ref=f2e341]:
                        - columnheader "对象" [ref=f2e342]
                        - columnheader "条件" [ref=f2e343]
                    - rowgroup [ref=f2e344]:
                      - row [ref=f2e345]:
                        - cell "第一行" [ref=f2e346]
                        - cell "单位相同" [ref=f2e347]
                      - row [ref=f2e348]:
                        - cell "第二行" [ref=f2e349]
                        - cell "整体相同" [ref=f2e350]
                - figure "分数：平均分成两份中的一份。" [ref=f2e351]:
                  - region "完整公式，可横向滚动" [ref=f2e353]
                  - math [ref=f2e366]:
                    - generic [ref=f2e369]:
                      - generic [ref=f2e370]: "1"
                      - generic [ref=f2e371]: "2"
                  - group [ref=f2e372]:
                    - generic "可复制的公式原文" [ref=f2e373] [cursor=pointer]
                - figure "根式：核对正数平方关系。" [ref=f2e374]:
                  - region "完整公式，可横向滚动" [ref=f2e376]
                  - math [ref=f2e394]:
                    - generic [ref=f2e396]:
                      - generic [ref=f2e397]: "9"
                      - generic [ref=f2e399]: =
                      - generic [ref=f2e400]: "3"
                  - group [ref=f2e401]:
                    - generic "可复制的公式原文" [ref=f2e402] [cursor=pointer]
                - figure "比较路线" [ref=f2e404]:
                  - img "比较路线" [ref=f2e405]:
                    - generic [ref=f2e406]: 确认单位
                    - generic [ref=f2e410]: 核对整体
                    - generic [ref=f2e414]: 独立验证
                  - button "放大图形：比较路线" [ref=f2e418]: ↗
                - figure "先统一单位，再比较条件。" [ref=f2e419]:
                  - button "放大参考图：统一单位再比较" [ref=f2e420]:
                    - img "单位与完整条件的交集，图中关系已经逐项核对。" [ref=f2e421]
                    - generic [aria-hidden] [ref=f2e422]: ↗
              - paragraph [ref=f2e424]: AI生成 · 待内容核对 · Browser question fixture · deepseek-v4-flash
              - button "下载续播位置" [ref=f2e425] [cursor=pointer]
```

# Test source

```ts
  187 | });
  188 | 
  189 | test('whiteboard questions: a lost create response is recovered after reload without a second write', async ({ page }) => {
  190 |   const f = await fixture(page), commands: any[] = [];
  191 |   await page.route('**/api/learning/studio/whiteboards/*/questions', async route => {
  192 |     if (route.request().method() !== 'POST') { await route.continue(); return; }
  193 |     commands.push(route.request().postDataJSON()); const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed');
  194 |   });
  195 |   await f.inputBox.fill('原创建回执丢失仍保留全部内容。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  196 |   await expect.poll(() => commands.length).toBe(1); await page.reload();
  197 |   await expect(f.region.locator('.wb-question-user')).toContainText('原创建回执丢失仍保留全部内容。');
  198 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1); expect(commands).toHaveLength(1); await expect(f.inputBox).toHaveValue('');
  199 | });
  200 | 
  201 | test('whiteboard questions: unavailable local storage keeps the full input, protects closing and round trips the downloaded JSON', async ({ page }) => {
  202 |   await page.addInitScript(() => {
  203 |     const get = Storage.prototype.getItem, set = Storage.prototype.setItem;
  204 |     Storage.prototype.getItem = function(key) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'SecurityError'); return get.call(this,key); };
  205 |     Storage.prototype.setItem = function(key,value) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this,key,value); };
  206 |   });
  207 |   const f = await fixture(page), message = '完整输入首部。' + '条件与理由。'.repeat(180) + '完整输入尾部。';
  208 |   await f.inputBox.fill(message); await expect(f.region).toContainText('本机副本暂未保存'); await f.player.getByRole('button', { name: '关闭白板', exact: true }).click();
  209 |   await expect(f.player).toBeVisible(); await expect(f.inputBox).toHaveValue(message);
  210 |   const downloadPromise = page.waitForEvent('download'); await f.region.getByRole('button', { name: '下载完整提问副本', exact: true }).click(); const download = await downloadPromise;
  211 |   const bytes = readFileSync((await download.path())!); expect(JSON.parse(bytes.toString('utf8')).form.message).toBe(message);
  212 |   await f.player.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(f.player).toHaveCount(0);
  213 |   await page.goto(f.href); await expect(f.player).toHaveAttribute('data-original-font-status','ready'); await expect(f.inputBox).toBeEnabled();
  214 |   await f.region.getByLabel('导入完整提问副本', { exact: true }).setInputFiles({ name: 'original-question.json', mimeType: 'application/json', buffer: bytes });
  215 |   await expect(f.inputBox).toHaveValue(message);
  216 | });
  217 | 
  218 | test('whiteboard questions: duplicated documents keep separate full drafts across independent reloads', async ({ page, context }) => {
  219 |   const f = await fixture(page), second = await context.newPage(); await second.goto(f.href);
  220 |   const other = second.getByRole('region', { name: '原句提问', exact: true }).getByRole('textbox', { name: '向老师提问', exact: true }); await expect(other).toBeEnabled();
  221 |   await f.inputBox.fill('第一标签页的完整问题 A 尾部。'); await other.fill('第二标签页的完整问题 B 尾部。');
  222 |   await page.reload(); await expect(f.inputBox).toHaveValue('第一标签页的完整问题 A 尾部。');
  223 |   await second.reload(); await expect(other).toHaveValue('第二标签页的完整问题 B 尾部。'); await second.close();
  224 | });
  225 | 
  226 | for (const width of [390,768,1280]) test('whiteboard questions: the real composer, model selection and return controls remain usable at ' + width, async ({ page }) => {
  227 |   await page.setViewportSize({ width, height: 800 }); const f = await fixture(page);
  228 |   await f.inputBox.fill('窄屏完整提问，回答后返回原句。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  229 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  230 |   for (const control of [f.inputBox, f.region.getByRole('combobox', { name: '讲解方式', exact: true }), f.region.getByRole('combobox', { name: '选择大模型', exact: true }),
  231 |     f.region.getByRole('button', { name: '发送', exact: true })]) {
  232 |     const box = await control.boundingBox(); expect(box).not.toBeNull(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  233 |   }
  234 |   await page.screenshot({ path: join(browserEvidence('whiteboard-questions'), 'question-panel-' + width + '.png') });
  235 |   await f.region.getByRole('button', { name: /回到这句/ }).click(); await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  236 | });
  237 | 
  238 | const questionFigureBase = '/learning/studio/whiteboard-question-visuals';
  239 | async function questionFigure(page: Page, f: Awaited<ReturnType<typeof fixture>>, requirements = '用两个圆与交集说明单位、条件和共同结论，保留全部中文标签。', generate = true) {
  240 |   await f.inputBox.fill('[question-structure] 请将完整条件、表格和公式讲清楚。');
  241 |   await f.region.getByRole('button', { name: '发送', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  242 |   await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click();
  243 |   const pane = page.getByRole('region', { name: '回答配图工作区', exact: true });
  244 |   await pane.getByRole('textbox', { name: '完整配图要求', exact: true }).fill(requirements);
  245 |   if (generate) {
  246 |     await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click();
  247 |     await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  248 |     await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click();
  249 |     await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled({ timeout: 25000 });
  250 |   }
  251 |   return pane;
  252 | }
  253 | 
  254 | test('question figures: exact PNG adoption binds voice, video, private links, complete notes and original-version review', async ({ page }) => {
  255 |   const f = await fixture(page, true), pane = await questionFigure(page, f), commands: any[] = [], audio: any[] = [];
  256 |   page.on('request', request => { if (request.method() !== 'POST') return;
  257 |     if (request.url().endsWith(questionFigureBase + '/adopt')) commands.push(request.postDataJSON());
  258 |     if (request.url().includes('/questions/') && request.url().includes('/board/narration/')) audio.push(request.postDataJSON()); });
  259 |   const selected = pane.getByRole('region', { name: '所选回答图片', exact: true });
  260 |   await selected.getByRole('button', { name: '放大参考图：回答配图', exact: true }).click(); await expect(page.getByRole('dialog', { name: '回答配图', exact: true })).toBeVisible();
  261 |   await page.getByRole('button', { name: '关闭图片', exact: true }).click();
  262 |   const originalPromise = page.waitForEvent('download'); await pane.getByRole('button', { name: '下载实际原PNG', exact: true }).click();
  263 |   const original = readFileSync((await (await originalPromise).path())!); expect(original.subarray(0, 8)).toEqual(Buffer.from([137,80,78,71,13,10,26,10]));
  264 |   await selected.getByLabel('图片说明', { exact: true }).fill('单位与完整条件的交集，图中关系已经逐项核对。'); await selected.getByLabel('展示图注', { exact: true }).fill('先统一单位，再比较条件。');
  265 |   await expect(selected.getByRole('button', { name: '采用并打开这个讲解版本', exact: true })).toBeDisabled();
  266 |   await selected.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  267 |   await selected.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click();
  268 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  269 |   expect(commands).toHaveLength(1); expect(commands[0].originalSha256).toBe(createHash('sha256').update(original).digest('hex'));
  270 |   await lesson.getByRole('button', { name: '分享与导出', exact: true }).click(); const link = await lesson.getByLabel('原白板私有链接', { exact: true }).inputValue();
  271 |   const versionId = new URL(link).searchParams.get('teachingVersion'); expect(versionId).toMatch(/^[a-f0-9-]{36}$/); await page.keyboard.press('Escape');
  272 |   await lesson.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => audio.length).toBeGreaterThan(0); expect(audio[0].teachingVersionId).toBe(versionId);
  273 |   await lesson.getByRole('button', { name: '暂停', exact: true }).click();
  274 |   await lesson.getByRole('combobox', { name: '播放速度', exact: true }).selectOption('2');
  275 |   const videoPromise = page.waitForEvent('download'); await lesson.getByRole('button', { name: '导出视频', exact: true }).click();
  276 |   const videoPath = (await (await videoPromise).path())!, probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v','error','-show_format','-show_streams','-of','json',videoPath], { encoding: 'utf8', windowsHide: true }));
  277 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true); expect(audio.every(item => item.teachingVersionId === versionId)).toBe(true);
  278 |   copyFileSync(videoPath, join(browserEvidence('whiteboard-question-figures'), 'adopted-2x.webm'));
  279 |   await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click(); await expect(lesson).toHaveCount(0);
  280 |   await f.region.getByText('带走完整教学笔记', { exact: true }).click(); const jsonPromise = page.waitForEvent('download');
  281 |   await f.region.getByRole('button', { name: '下载完整教学笔记 JSON', exact: true }).click(); const notes = JSON.parse(readFileSync((await (await jsonPromise).path())!, 'utf8'));
  282 |   expect(notes.turns[0].teachingVersions).toHaveLength(2); expect(notes.turns[0].teachingVersions.find((item: any) => item.current).id).toBe(versionId);
  283 |   const mdPromise = page.waitForEvent('download'); await f.region.getByRole('button', { name: '下载完整教学笔记 Markdown', exact: true }).click();
  284 |   const markdown = readFileSync((await (await mdPromise).path())!, 'utf8'); expect(markdown).toContain(versionId!); expect(markdown).toContain(commands[0].imageSha256); expect(markdown).not.toContain('sessionTokenHash');
  285 |   await f.region.getByRole('combobox', { name: '讲解版本', exact: true }).selectOption('original'); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  286 |   await expect(lesson).toHaveAttribute('data-original-font-status', 'ready'); await expect(lesson.locator('.tw-figure')).toHaveCount(0); await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click();
> 287 |   await page.goto(link); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready'); await expect(lesson.locator('.tw-figure')).toHaveCount(1);
      |                                                                                                                                                 ^ Error: expect(locator).toHaveCount(expected) failed
  288 |   await page.screenshot({ path: join(browserEvidence('whiteboard-question-figures'), 'adopted-version.png') });
  289 | });
  290 | 
  291 | test('question figures: lost prepare and adoption receipts retain original commands through reload without duplicate images or versions', async ({ page }) => {
  292 |   const f = await fixture(page), pane = await questionFigure(page, f, '保留原请求的完整配图要求。', false); let prepareWrites = 0;
  293 |   await page.route('**/api/learning/studio/whiteboard-question-visuals', async route => {
  294 |     if (route.request().method() !== 'POST') return route.continue(); prepareWrites++; await route.fetch(); await route.abort('failed'); });
  295 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  296 |   await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click(); await expect(pane.getByRole('button', { name: '按原请求继续', exact: true })).toBeEnabled();
  297 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('保留原请求的完整配图要求。');
  298 |   await pane.getByRole('button', { name: '按原请求继续', exact: true }).click(); await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled(); expect(prepareWrites).toBe(1);
  299 |   let adoptionWrites = 0, first: any;
  300 |   await page.route('**/whiteboard-question-visuals/adopt', async route => { adoptionWrites++; const response = await route.fetch();
  301 |     if (adoptionWrites === 1) { first = (await response.json()).data; await route.abort('failed'); } else await route.fulfill({ response }); });
  302 |   await pane.getByLabel('图片说明', { exact: true }).fill('所有标签与条件已经核对。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  303 |   await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); await expect(pane.getByRole('button', { name: '按原请求继续', exact: true })).toBeEnabled();
  304 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await pane.getByRole('button', { name: '按原请求继续', exact: true }).click();
  305 |   await expect(page.getByRole('dialog', { name: 'AI补充讲解', exact: true })).toHaveAttribute('data-original-font-status', 'ready'); expect(adoptionWrites).toBe(2);
  306 |   const versions = await f.call('/learning/studio/whiteboards/' + f.board.id + '/questions/' + first.board.turnId + '/teaching-versions', undefined, f.actor.token, 'GET');
  307 |   expect(versions).toHaveLength(2); expect(versions.find((item: any) => item.current).id).toBe(first.versionId);
  308 | });
  309 | 
  310 | test('question figures: original PNG editing and two explicit adoptions preserve both prior teaching versions', async ({ page }) => {
  311 |   const f = await fixture(page, false, true), pane = await questionFigure(page, f); const versions: string[] = [];
  312 |   for (let pass = 0; pass < 2; pass++) {
  313 |     if (pass) { await pane.getByRole('button', { name: '以这张原图继续修改', exact: true }).click(); await pane.getByLabel('具体修改说明', { exact: true }).fill('把交集标签加大，并保留两个原始圆圈。');
  314 |       await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '用原PNG生成修改图', exact: true })).toBeEnabled();
  315 |       await pane.getByRole('button', { name: '用原PNG生成修改图', exact: true }).click(); await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled(); }
  316 |     await pane.getByLabel('图片说明', { exact: true }).fill('第' + pass + '幅已核对的关系图。'); await pane.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check();
  317 |     const responsePromise = page.waitForResponse(response => response.request().method() === 'POST' && response.url().endsWith(questionFigureBase + '/adopt'));
  318 |     await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); const value = (await (await responsePromise).json()).data; versions.push(value.versionId);
  319 |     const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  320 |     await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click();
  321 |   }
  322 |   expect(versions[0]).not.toBe(versions[1]); await expect(f.region.getByRole('combobox', { name: '讲解版本', exact: true }).locator('option')).toHaveCount(3);
  323 |   await f.region.getByRole('combobox', { name: '讲解版本', exact: true }).selectOption(versions[0]); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  324 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  325 |   await lesson.getByRole('button', { name: '分享与导出', exact: true }).click(); expect(await lesson.getByLabel('原白板私有链接').inputValue()).toContain('teachingVersion=' + versions[0]);
  326 | });
  327 | 
  328 | test('question figures: explicit cancel and original retry keep the same image requirement and target', async ({ page }) => {
  329 |   const f = await fixture(page), pane = await questionFigure(page, f, '[image-pause-once] 完整条件与原图要求在重试后仍然保持。', false), commands: any[] = [];
  330 |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith(questionFigureBase)) commands.push(request.postDataJSON()); });
  331 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeEnabled();
  332 |   await pane.getByRole('button', { name: '生成这段讲解的配图', exact: true }).click(); await pane.getByRole('button', { name: '取消图片生成', exact: true }).click();
  333 |   await expect(pane.getByRole('button', { name: '按原要求重试图片', exact: true })).toBeEnabled({ timeout: 20000 }); await pane.getByRole('button', { name: '按原要求重试图片', exact: true }).click();
  334 |   await expect(pane.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled({ timeout: 25000 }); expect(commands).toHaveLength(1);
  335 |   await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(commands[0].requirements);
  336 | });
  337 | 
  338 | test('question figures: duplicated documents keep separate full inputs and a closed workbench discards late preflight', async ({ page, context }) => {
  339 |   const f = await fixture(page), pane = await questionFigure(page, f, '第一标签的完整条件 A 尾部。', false), second = await context.newPage(); await second.goto(f.href);
  340 |   await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); const other = second.getByRole('region', { name: '回答配图工作区', exact: true });
  341 |   await other.getByRole('textbox', { name: '完整配图要求', exact: true }).fill('第二标签的完整条件 B 尾部。');
  342 |   await page.reload(); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第一标签的完整条件 A 尾部。');
  343 |   await second.reload(); await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(other.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第二标签的完整条件 B 尾部。'); await second.close();
  344 |   let reached = false, delivered = false, release!: () => void; const gate = new Promise<void>(resolve => { release = resolve; });
  345 |   await page.route('**/whiteboard-question-visuals/preflight', async route => { const response = await route.fetch(); reached = true; await gate; try { await route.fulfill({ response }); } catch {} finally { delivered = true; } });
  346 |   await pane.getByRole('button', { name: '预检完整配图提示', exact: true }).click(); await expect.poll(() => reached).toBe(true); await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click();
  347 |   release(); await expect.poll(() => delivered).toBe(true); await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成这段讲解的配图', exact: true })).toBeDisabled();
  348 | });
  349 | 
  350 | for (const width of [390, 768, 1280]) test('question figures: full input, storage failure, download and import remain usable at ' + width, async ({ page }) => {
  351 |   await page.setViewportSize({ width, height: 800 }); await page.addInitScript(() => { const set = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) {
  352 |     if (key.startsWith('studyagent.question-figures.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this, key, value); }; });
  353 |   const f = await fixture(page), requirements = '完整首部。' + '图示保留全部条件。'.repeat(100) + '完整尾部。', pane = await questionFigure(page, f, requirements, false);
  354 |   await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click(); await expect(pane).toBeVisible(); await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(requirements);
  355 |   for (const control of [pane.getByRole('textbox', { name: '完整配图要求', exact: true }), pane.getByRole('button', { name: '预检完整配图提示', exact: true })]) {
  356 |     const box = await control.boundingBox(); expect(box).not.toBeNull(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  357 |   }
  358 |   const promise = page.waitForEvent('download'); await pane.getByRole('button', { name: '下载完整配图副本', exact: true }).click(); const bytes = readFileSync((await (await promise).path())!);
  359 |   expect(JSON.parse(bytes.toString('utf8')).form.requirements).toBe(requirements); await pane.getByRole('button', { name: '关闭回答配图', exact: true }).click(); await expect(pane).toHaveCount(0);
  360 |   await f.region.getByRole('button', { name: '为这段讲解配图', exact: true }).click(); await pane.getByText('保留与恢复完整配图要求', { exact: true }).click();
  361 |   await pane.getByLabel('导入完整配图副本', { exact: true }).setInputFiles({ name: 'complete-figure-copy.json', mimeType: 'application/json', buffer: bytes });
  362 |   await expect(pane.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue(requirements);
  363 |   await page.screenshot({ path: join(browserEvidence('whiteboard-question-figures'), 'full-input-' + width + '.png') });
  364 | });
  365 | 
  366 | test('question figures: a stale second tab preserves its full requirements and rechecks the current adoption before choosing again', async ({ page, context }) => {
  367 |   const f = await fixture(page), pane = await questionFigure(page, f), second = await context.newPage(); await second.goto(f.href);
  368 |   await second.getByRole('button', { name: '为这段讲解配图', exact: true }).click();
  369 |   const other = second.getByRole('region', { name: '回答配图工作区', exact: true });
  370 |   await other.getByRole('textbox', { name: '完整配图要求', exact: true }).fill('第二标签保留的完整选择理由与条件尾部。');
  371 |   await other.getByLabel('这段讲解的图片候选', { exact: true }).getByRole('button').first().click();
  372 |   await expect(other.getByRole('button', { name: '下载实际原PNG', exact: true })).toBeEnabled();
  373 |   for (const target of [pane, other]) { await target.getByLabel('图片说明', { exact: true }).fill('已核对相同原PNG与全部标签。'); await target.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true }).check(); }
  374 |   const responsePromise = page.waitForResponse(response => response.request().method() === 'POST' && response.url().endsWith(questionFigureBase + '/adopt'));
  375 |   await pane.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click(); const first = (await (await responsePromise).json()).data;
  376 |   await other.getByRole('button', { name: '采用并打开这个讲解版本', exact: true }).click();
  377 |   await expect(other).toContainText('当前采用版本已变化'); await expect(other.getByRole('textbox', { name: '完整配图要求', exact: true })).toHaveValue('第二标签保留的完整选择理由与条件尾部。');
  378 |   await expect(other.getByRole('button', { name: '重新读取原回答范围', exact: true })).toBeVisible();
  379 |   const versions = await f.call('/learning/studio/whiteboards/' + f.board.id + '/questions/' + first.board.turnId + '/teaching-versions', undefined, f.actor.token, 'GET');
  380 |   expect(versions).toHaveLength(2); expect(versions.find((item: any) => item.current).id).toBe(first.versionId);
  381 |   await other.getByRole('button', { name: '重新读取原回答范围', exact: true }).click(); await expect(other).toContainText('当前采用图片：');
  382 |   await expect(other.getByRole('checkbox', { name: '我已核对图中文字、条件和关系', exact: true })).not.toBeChecked(); await second.close();
  383 | });
  384 | 
```