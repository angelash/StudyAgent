# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: teaching-tools.spec.ts >> teaching tools: non-finite JSON in 原答案结构 JSON stays original and cannot become an unknown null
- Location: tests\e2e\teaching-tools.spec.ts:179:73

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.tt-composer').locator('.tt-notice')
Expected substring: "有限JSON"
Received string:    "完整输入已预检，核对后再生成。"
Timeout: 15000ms

Call log:
  - Expect "toContainText" locator('.tt-composer').locator('.tt-notice') with timeout 15000ms
  - waiting for locator('.tt-composer').locator('.tt-notice')
    32 × locator resolved to <p role="status" class="tt-notice">完整输入已预检，核对后再生成。</p>
       - unexpected value "完整输入已预检，核对后再生成。"

```

```yaml
- status: 完整输入已预检，核对后再生成。
```

# Test source

```ts
  85  |   await composer(second).getByText('本机其他标签页的原稿', { exact: true }).click();
  86  |   await composer(second).locator('.tt-copies article').filter({ hasText: 'FIRST_DOCUMENT_COMPLETE_TAIL' }).first().getByRole('button', { name: '载入这个副本', exact: true }).click();
  87  |   await expect(composer(second).getByLabel('草稿名称')).toHaveValue('FIRST_DOCUMENT_COMPLETE_TAIL');
  88  |   const titles = await second.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.teaching-tool.form.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).form.title));
  89  |   expect(titles).toContain('FIRST_DOCUMENT_COMPLETE_TAIL'); expect(titles).toContain('SECOND_DOCUMENT_COMPLETE_TAIL'); await second.close();
  90  | });
  91  | 
  92  | test('teaching tools: failed local storage blocks navigation and logout until the complete original input is downloaded', async ({ page }) => {
  93  |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.teaching-tool.')) throw new DOMException('Synthetic quota', 'QuotaExceededError'); return original.call(this, key, value); }; });
  94  |   const f = await enter(page); await fill(page, 'STORAGE_FAILURE_FULL_ORIGINAL'); await expect(composer(page)).toContainText('本机存储暂不可用');
  95  |   await page.getByRole('link', { name: '教研后台', exact: true }).click(); await expect(page).toHaveURL(/\/admin\/ai-tools/); await page.getByRole('button', { name: '退出', exact: true }).click();
  96  |   await expect(page).toHaveURL(/\/admin\/ai-tools/); expect((await f.call('/auth/me')).role).toBe('admin');
  97  |   const downloadPromise = page.waitForEvent('download'); await composer(page).getByRole('button', { name: '下载完整原稿 ↗', exact: true }).click(); const download = await downloadPromise;
  98  |   const saved = JSON.parse(readFileSync((await download.path())!, 'utf8')); expect(saved.form.title).toBe('STORAGE_FAILURE_FULL_ORIGINAL'); expect(saved.form.answer).toContain('保留首次原文尾行');
  99  |   await page.getByRole('button', { name: '退出', exact: true }).click(); await expect(page).toHaveURL(/\/parent\/login/);
  100 | });
  101 | 
  102 | test('teaching tools: a provider finishing after cancellation cannot publish its late result', async ({ page }) => {
  103 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page); await preview(page); const id = await generate(page);
  104 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click();
  105 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible({ timeout: 20000 }); const run = await f.call('/ai/teaching-tools/runs/' + id); expect(run.result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  106 | });
  107 | 
  108 | test('teaching tools: cancellation acknowledgement loss recovers its original control key after reload', async ({ page }) => {
  109 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  110 |   await expect.poll(async () => (await f.call('/qa/teaching-tools/observations')).calls.length).toBe(1);
  111 |   let lost!: () => void; const lostAcknowledgement = new Promise<void>(resolve => { lost = resolve; });
  112 |   await page.route('**/api/ai/teaching-tools/runs/*/cancel', async route => { await route.fetch(); await route.abort('failed'); lost(); });
  113 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toBeVisible();
  114 |   await lostAcknowledgement; await page.unroute('**/api/ai/teaching-tools/runs/*/cancel'); await page.reload(); await detail(page).getByRole('button', { name: '恢复原操作', exact: true }).click();
  115 |   await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull(); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  116 | });
  117 | 
  118 | test('teaching tools: a role revocation unloads private work and fences the late provider reply', async ({ page }) => {
  119 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'late' }); await fill(page, 'PRIVATE_TEACHING_OWNER_ONLY'); await preview(page); const id = await generate(page);
  120 |   await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible(); await f.call('/qa/teaching-tools/revoke', {});
  121 |   await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(page.getByText('PRIVATE_TEACHING_OWNER_ONLY', { exact: true })).toHaveCount(0);
  122 |   await page.waitForTimeout(1800); await f.call('/qa/teaching-tools/setup', {});
  123 |   await expect.poll(async () => (await f.call('/ai/teaching-tools/runs/' + id)).status, { timeout: 20000 }).toBe('failed'); expect((await f.call('/ai/teaching-tools/runs/' + id)).result).toBeNull();
  124 | });
  125 | 
  126 | test('teaching tools: parent identity cannot read the admin workspace or load model generation controls', async ({ page }) => {
  127 |   await enter(page, 1280, false); await expect(page.getByRole('heading', { name: '这是一处内部教研工作区', exact: true })).toBeVisible(); await expect(composer(page)).toHaveCount(0);
  128 | });
  129 | 
  130 | test('teaching tools: oversized original text is rejected without losing or truncating the form or making a provider call', async ({ page }) => {
  131 |   const f = await enter(page); await fill(page); const text = '题'.repeat(6001) + 'OVERSIZE_ORIGINAL_TAIL'; await composer(page).getByLabel('完整题干', { exact: true }).fill(text);
  132 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('完整教研输入不可用');
  133 |   await expect(composer(page).getByLabel('完整题干')).toHaveValue(text); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0); expect((await f.call('/ai/teaching-tools/runs')).runs).toHaveLength(0);
  134 | });
  135 | 
  136 | test('teaching tools: malformed structured work survives a reload and never gets silently converted into a score', async ({ page }) => {
  137 |   const f = await enter(page); await fill(page); await composer(page).getByLabel('待核对作答格式', { exact: true }).selectOption('json'); const raw = '{"steps":["第一步原文","COMPLETE_INVALID_JSON_TAIL"'; await composer(page).getByLabel('待核对作答', { exact: true }).fill(raw);
  138 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('不是完整JSON'); await page.reload(); await expect(composer(page).getByLabel('待核对作答', { exact: true })).toHaveValue(raw);
  139 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  140 | });
  141 | 
  142 | test('teaching tools: a stale cancellation preserves its command, reads the latest state explicitly and requires a new user action', async ({ page }) => {
  143 |   const f = await enter(page); await f.call('/qa/teaching-tools/behavior', { mode: 'hold' }); await fill(page); await preview(page); const id = await generate(page);
  144 |   await expect.poll(async () => (await f.call('/qa/teaching-tools/observations')).calls.length).toBe(1);
  145 |   const pattern = '**/api/ai/teaching-tools/runs/' + id;
  146 |   await page.route(pattern, async route => { const response = await route.fetch(), json = await response.json(); json.data.task.version--; await route.fulfill({ response, json }); });
  147 |   await page.reload(); await expect(detail(page).getByText('正在生成', { exact: true })).toBeVisible();
  148 |   const posts: Array<Record<string, unknown>> = []; page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/' + id + '/cancel')) posts.push(request.postDataJSON()); });
  149 |   const failed = page.waitForResponse(response => response.url().endsWith('/' + id + '/cancel') && response.status() === 409);
  150 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await failed;
  151 |   await expect(detail(page).getByRole('button', { name: '保留原操作副本，核对最新状态', exact: true })).toBeVisible(); expect(posts).toHaveLength(1);
  152 |   await page.unroute(pattern); await detail(page).getByRole('button', { name: '保留原操作副本，核对最新状态', exact: true }).click();
  153 |   await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toHaveCount(0); expect(posts).toHaveLength(1);
  154 |   await detail(page).getByText('本机原操作副本', { exact: true }).click(); const downloaded = page.waitForEvent('download');
  155 |   await detail(page).getByRole('button', { name: '下载原操作副本', exact: true }).first().click(); const archived = JSON.parse(readFileSync((await (await downloaded).path())!, 'utf8'));
  156 |   expect(archived.pending.command.requestKey).toBe(posts[0].requestKey); expect(posts).toHaveLength(1);
  157 |   await detail(page).getByRole('button', { name: '取消本次生成', exact: true }).click(); await expect(detail(page).getByText('已取消', { exact: true })).toBeVisible(); expect(posts).toHaveLength(2); expect(posts[1].requestKey).not.toBe(posts[0].requestKey);
  158 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  159 | });
  160 | 
  161 | test('teaching tools: an unreadable original remains discoverable after two reloads and downloads byte for byte', async ({ page }) => {
  162 |   const f = await enter(page); await fill(page); const original = '{"version":999,"unparsed":"COMPLETE_FUTURE_ORIGINAL_TAIL"\n';
  163 |   await page.evaluate(raw => { const key = Object.keys(localStorage).find(key => key.startsWith('studyagent.teaching-tool.form.v1.'))!; localStorage.setItem(key, raw); }, original);
  164 |   await page.reload(); await expect(composer(page).getByRole('region', { name: '未识别的本机原稿', exact: true })).toBeVisible(); await page.reload();
  165 |   await expect(composer(page).getByRole('region', { name: '未识别的本机原稿', exact: true })).toBeVisible(); const pending = page.waitForEvent('download');
  166 |   await composer(page).getByRole('button', { name: '下载暂不能读取的原件 1', exact: true }).click(); expect(readFileSync((await (await pending).path())!, 'utf8')).toBe(original);
  167 |   expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  168 | });
  169 | 
  170 | test('teaching tools: an unknown control original remains discoverable across reloads and cannot execute as a command', async ({ page }) => {
  171 |   const f = await enter(page); await fill(page); await preview(page); await generate(page); await done(page); const original = '{"version":999,"operation":"UNKNOWN_CONTROL_COMPLETE_TAIL"\n';
  172 |   await page.evaluate(raw => { const key = Object.keys(localStorage).find(key => key.startsWith('studyagent.teaching-tool.control.v1.'))!; localStorage.setItem(key, raw); }, original);
  173 |   await page.reload(); await expect(detail(page).getByRole('region', { name: '未识别的本机操作', exact: true })).toBeVisible(); await page.reload();
  174 |   await expect(detail(page).getByRole('region', { name: '未识别的本机操作', exact: true })).toBeVisible(); const pending = page.waitForEvent('download');
  175 |   await detail(page).getByRole('button', { name: '下载暂不能读取的原操作 1', exact: true }).click(); expect(readFileSync((await (await pending).path())!, 'utf8')).toBe(original);
  176 |   await expect(detail(page).getByRole('button', { name: '恢复原操作', exact: true })).toHaveCount(0); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(1);
  177 | });
  178 | 
  179 | for (const field of ['待核对作答', '参考答案', '完整题目结构 JSON', '原答案结构 JSON']) test(`teaching tools: non-finite JSON in ${field} stays original and cannot become an unknown null`, async ({ page }) => {
  180 |   const f = await enter(page); await fill(page); const original = '{"value":1e999,"tail":"NON_FINITE_ORIGINAL_COMPLETE"}';
  181 |   if (['待核对作答', '参考答案'].includes(field)) await composer(page).getByLabel(field + '格式', { exact: true }).selectOption('json');
  182 |   else await composer(page).getByText('补充表格、公式与答案结构', { exact: true }).click();
  183 |   await composer(page).getByLabel(field, { exact: true }).fill(original);
  184 |   let posts = 0; page.on('request', request => { if (request.method() === 'POST' && request.url().includes('/ai/teaching-tools/')) posts++; });
> 185 |   await composer(page).getByRole('button', { name: '预检完整输入', exact: true }).click(); await expect(composer(page).locator('.tt-notice')).toContainText('有限JSON');
      |                                                                                                                                         ^ Error: expect(locator).toContainText(expected) failed
  186 |   expect(posts).toBe(0); await expect(composer(page).getByLabel(field, { exact: true })).toHaveValue(original); await page.reload();
  187 |   if (field.endsWith('JSON')) await composer(page).getByText('补充表格、公式与答案结构', { exact: true }).click();
  188 |   await expect(composer(page).getByLabel(field, { exact: true })).toHaveValue(original); expect((await f.call('/qa/teaching-tools/observations')).calls).toHaveLength(0);
  189 |   if (field === '待核对作答') { await composer(page).getByLabel('暂不清楚待核对作答', { exact: true }).check(); await preview(page);
  190 |     await expect(composer(page).getByRole('region', { name: '完整输入预检', exact: true })).toContainText('明确未知');
  191 |     await composer(page).getByLabel('暂不清楚待核对作答', { exact: true }).uncheck(); await expect(composer(page).getByLabel(field, { exact: true })).toHaveValue(original); }
  192 | });
  193 | 
```