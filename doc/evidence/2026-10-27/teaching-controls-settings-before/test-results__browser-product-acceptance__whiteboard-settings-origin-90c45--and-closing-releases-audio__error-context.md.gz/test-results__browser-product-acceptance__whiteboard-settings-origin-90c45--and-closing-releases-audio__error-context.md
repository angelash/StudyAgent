# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-settings.spec.ts >> original settings: six actual neutral MP3s decode, previews preserve selection and closing releases audio
- Location: tests\e2e\whiteboard-settings.spec.ts:24:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 460
Received: 441.5999755859375
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - button "Home" [ref=f1e10] [cursor=pointer]:
          - generic [ref=f1e13]: 首页
        - button "Courses" [ref=f1e14] [cursor=pointer]:
          - generic [ref=f1e17]: 课程
        - button "Calendar" [ref=f1e18] [cursor=pointer]:
          - generic [ref=f1e21]: 学习动态
        - button "History" [ref=f1e22] [cursor=pointer]:
          - generic [ref=f1e25]: 历史
        - button "Materials" [ref=f1e26] [cursor=pointer]:
          - generic [ref=f1e29]: 资料
        - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f1e33]: AI白板
      - button "＋ 创建课程" [ref=f1e34] [cursor=pointer]
      - generic [ref=f1e35]:
        - heading "继续学习" [level=2] [ref=f1e36]
        - link "讲座社会学想象力 社会学概论" [ref=f1e37] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f1e38]: 社会学概论
      - generic [ref=f1e39]:
        - heading "近期活动" [level=2] [ref=f1e40]
        - link "白板视频「异分母分数加法」" [ref=f1e41] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_dca847f3-10b4-4400-a61f-d6066541b9c2
      - link "返回学习首页 →" [ref=f1e43] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_8fca66c9-b691-4982-b458-5a595d522385
    - generic [ref=f1e44]:
      - generic [ref=f1e45]:
        - generic [ref=f1e46]:
          - combobox "学习档案" [ref=f1e47]:
            - option "匿名设置验证" [selected]
          - combobox "学科" [ref=f1e48]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e49]:
          - link "教学课堂 ↗" [ref=f1e50] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e51] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e52]:
        - generic [ref=f1e53]:
          - button "Craft Courses" [ref=f1e54] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e55] [cursor=pointer]
        - generic [ref=f1e56]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f1e57]
          - paragraph [ref=f1e58]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f1e59]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f1e60]
          - generic [ref=f1e61]:
            - generic [ref=f1e62]: ＋
            - generic [ref=f1e63]: 资料
            - button "Concept Explanation" [ref=f1e64] [cursor=pointer]
            - generic [ref=f1e65]: 语音
            - generic [ref=f1e68]:
              - generic [ref=f1e69]: 模型
              - combobox "选择大模型" [ref=f1e70] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f1e71] [cursor=pointer]
        - generic [ref=f1e72]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f1e73] [cursor=pointer]:
            - generic [ref=f1e74]: 可视化
            - generic [ref=f1e75]: 用图形解释异分母加法
            - generic [ref=f1e76]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f1e77] [cursor=pointer]:
            - generic [ref=f1e78]: 个性化练习
            - generic [ref=f1e79]: 从我的已知点生成练习
            - generic [ref=f1e80]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f1e81] [cursor=pointer]:
            - generic [ref=f1e82]: 主动学习
            - generic [ref=f1e83]: 看看今天最值得做什么
            - generic [ref=f1e84]: 按教育优先级排序
        - generic [ref=f1e85]:
          - heading "你的学习路径" [level=2] [ref=f1e86]
          - button "创建课程" [ref=f1e87] [cursor=pointer]
        - generic [ref=f1e88]:
          - heading "还没有课程" [level=3] [ref=f1e89]
          - paragraph [ref=f1e90]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f1e91] [cursor=pointer]
        - complementary [ref=f1e92]:
          - article [ref=f1e93]:
            - generic [ref=f1e94]:
              - generic [ref=f1e95]:
                - text: LEARNER SNAPSHOT
                - heading "匿名设置验证" [level=2] [ref=f1e96]
              - generic [ref=f1e97]: 5 年级
            - generic [ref=f1e98]:
              - strong [ref=f1e99]: "0"
              - generic [ref=f1e100]: / 1
              - generic [ref=f1e101]: 已有点有稳定证据
            - generic [ref=f1e102]:
              - generic [ref=f1e103]:
                - generic [ref=f1e104]: "1"
                - text: 已确认知识点
              - generic [ref=f1e105]:
                - generic [ref=f1e106]: "0"
                - text: 日历安排
          - article [ref=f1e107]:
            - generic [ref=f1e108]:
              - generic [ref=f1e109]: NEXT BEST ACTION
              - button "全部 →" [ref=f1e110] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f1e111] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_8fca66c9-b691-4982-b458-5a595d522385&subject=math
              - generic [ref=f1e112]: 1个已学点仍需补充证据
              - paragraph [ref=f1e113]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f1e114]:
            - generic [ref=f1e115]:
              - generic [ref=f1e116]: RECENT WHITEBOARDS
              - button "新建" [ref=f1e117] [cursor=pointer]
            - button "▶ 匿名逐句白板 2 幕 · 1 秒" [ref=f1e118] [cursor=pointer]:
              - generic [ref=f1e119]: ▶
              - generic [ref=f1e120]:
                - generic [ref=f1e121]: 匿名逐句白板
                - generic [ref=f1e122]: 2 幕 · 1 秒
          - article [ref=f1e123]:
            - generic [ref=f1e124]:
              - generic [ref=f1e125]: SYNC STATUS
              - button "日历 →" [ref=f1e126] [cursor=pointer]
            - paragraph [ref=f1e127]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f1e128]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f1e129]:
      - generic:
        - button "关闭白板" [ref=f1e130] [cursor=pointer]: ×
        - heading "匿名逐句白板" [level=2] [ref=f1e132]
      - navigation "白板视图" [ref=f1e133]:
        - generic [ref=f1e134]:
          - button "缩小白板" [ref=f1e135] [cursor=pointer]: −
          - button "重置白板视图" [ref=f1e136] [cursor=pointer]: 100%
          - button "放大白板" [ref=f1e137] [cursor=pointer]: +
        - button "白板设置" [ref=f1e138] [cursor=pointer]
      - button "静音" [ref=f1e141] [cursor=pointer]
      - generic [ref=f1e144]:
        - main [ref=f1e145]:
          - generic "统一单位" [ref=f1e147]
          - paragraph [ref=f1e148]: "[whiteboard-fixture] 先统一单位。"
          - generic [ref=f1e149]:
            - generic [ref=f1e150]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f1e151] [cursor=pointer]: "0"
          - generic [ref=f1e152]:
            - button "上一句" [disabled] [ref=f1e153]: ←
            - button "播放" [ref=f1e154] [cursor=pointer]: ▶
            - button "下一句" [ref=f1e155] [cursor=pointer]: →
            - generic [ref=f1e156]: 1 / 4 句
            - combobox "阅读方式" [ref=f1e157] [cursor=pointer]:
              - option "文字阅读（估计时长）"
              - option "云语音逐句播放" [selected]
            - combobox "旁白音色" [ref=f1e158] [cursor=pointer]:
              - option "温暖少女" [selected]
              - option "温润男声"
              - option "清脆少女"
              - option "温柔学姐"
              - option "播报男声"
              - option "俏皮萌妹"
            - combobox "播放速度" [ref=f1e159] [cursor=pointer]:
              - option "0.5×"
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
              - option "1.5×"
              - option "2×"
            - generic [ref=f1e160]:
              - generic [ref=f1e161]: 板书字体
              - combobox "板书字体" [ref=f1e162] [cursor=pointer]:
                - option "手写板书" [selected]
                - option "标准板书"
            - generic [ref=f1e163]:
              - checkbox "点阵" [checked] [ref=f1e164]
              - text: 点阵
            - button "导出视频" [ref=f1e165] [cursor=pointer]
            - button "导出字幕" [ref=f1e166] [cursor=pointer]
          - status [ref=f1e167]
          - generic [ref=f1e168]:
            - button "01 统一单位" [ref=f1e169] [cursor=pointer]:
              - generic [ref=f1e170]: "01"
              - text: 统一单位
            - button "02 保留证据" [ref=f1e171] [cursor=pointer]:
              - generic [ref=f1e172]: "02"
              - text: 保留证据
        - complementary "完整讲稿与要点" [ref=f1e173]:
          - heading "逐句讲稿" [level=3] [ref=f1e174]
          - paragraph [ref=f1e175]: 点击一句定位。观看与续播不计作掌握。
          - list [ref=f1e176]:
            - listitem [ref=f1e177]:
              - button "[whiteboard-fixture] 先统一单位。" [ref=f1e178] [cursor=pointer]
            - listitem [ref=f1e179]:
              - button "[whiteboard-fixture] 再合并份数。" [ref=f1e180] [cursor=pointer]
            - listitem [ref=f1e181]:
              - button "[whiteboard-fixture] 最后验证。" [ref=f1e182] [cursor=pointer]
            - listitem [ref=f1e183]:
              - button "[whiteboard-fixture] 保留新的独立观察。" [ref=f1e184] [cursor=pointer]
          - heading "完整笔记与来源" [level=3] [ref=f1e185]
          - group [ref=f1e186]:
            - generic "统一单位" [ref=f1e187] [cursor=pointer]
            - paragraph [ref=f1e188]: 完整正文首行。完整正文末行。
            - list [ref=f1e189]:
              - listitem [ref=f1e190]: 先统一单位
              - listitem [ref=f1e191]: 再合并份数
              - listitem [ref=f1e192]: 最后验证
          - group [ref=f1e193]:
            - generic "保留证据" [ref=f1e194] [cursor=pointer]
          - button "下载续播位置" [ref=f1e195] [cursor=pointer]
      - dialog "白板设置" [ref=f1e198]:
        - generic [ref=f1e199]:
          - heading "Session settings" [level=3] [ref=f1e200]
          - button "关闭白板设置" [active] [ref=f1e201] [cursor=pointer]
        - generic [ref=f1e204]:
          - generic [ref=f1e205]:
            - generic [ref=f1e206]: Voice options
            - generic [ref=f1e207]: Warm
          - radiogroup "白板音色" [ref=f1e208]:
            - radio "Warm" [checked] [ref=f1e209] [cursor=pointer]:
              - generic "温暖少女 · 中文(普通话)" [ref=f1e216]:
                - generic [ref=f1e217]: Warm
                - generic [ref=f1e218]: Like a patient teacher, close and natural
              - button "试听音色：温暖少女" [ref=f1e219]
              - generic [aria-hidden] [ref=f1e222]: ✓
            - radio "Calm" [ref=f1e223] [cursor=pointer]:
              - generic "温润男声 · 中文(普通话)" [ref=f1e230]:
                - generic [ref=f1e231]: Calm
                - generic [ref=f1e232]: Low and steady, easy on long listens
              - button "试听音色：温润男声" [ref=f1e233]
            - radio "Bright" [ref=f1e236] [cursor=pointer]:
              - generic "清脆少女 · 中文(普通话)" [ref=f1e243]:
                - generic [ref=f1e244]: Bright
                - generic [ref=f1e245]: Clear and energetic, key points pop
              - button "试听音色：清脆少女" [ref=f1e246]
            - radio "Gentle" [ref=f1e249] [cursor=pointer]:
              - generic "温柔学姐 · 中文(普通话)" [ref=f1e256]:
                - generic [ref=f1e257]: Gentle
                - generic [ref=f1e258]: Soft-spoken and unhurried
              - button "试听音色：温柔学姐" [ref=f1e259]
            - radio "Professional" [ref=f1e262] [cursor=pointer]:
              - generic "播报男声 · 中文(普通话)" [ref=f1e269]:
                - generic [ref=f1e270]: Professional
                - generic [ref=f1e271]: Crisp and clear, like a lecture hall
              - button "试听音色：播报男声" [ref=f1e272]
            - radio "Lively" [ref=f1e275] [cursor=pointer]:
              - generic "俏皮萌妹 · 中文(普通话)" [ref=f1e282]:
                - generic [ref=f1e283]: Lively
                - generic [ref=f1e284]: Quick-paced and full of energy
              - button "试听音色：俏皮萌妹" [ref=f1e285]
        - generic [ref=f1e288]:
          - generic [ref=f1e289]:
            - generic [ref=f1e290]: Voice speed
            - generic [ref=f1e291]: 1×
          - slider "白板语速" [ref=f1e292] [cursor=pointer]: "2"
          - generic [ref=f1e293]:
            - generic [ref=f1e294]: 0.5×
            - generic [ref=f1e295]: 0.75×
            - generic [ref=f1e296]: 1×
            - generic [ref=f1e297]: 1.25×
            - generic [ref=f1e298]: 1.5×
            - generic [ref=f1e299]: 2×
        - generic [ref=f1e300]:
          - generic [ref=f1e301]: Board font
          - generic [ref=f1e302]:
            - button "Aa Bb Handwriting" [pressed] [ref=f1e303] [cursor=pointer]:
              - generic [ref=f1e304]: Aa Bb
              - generic [ref=f1e305]: Handwriting
            - button "Aa Bb Standard" [ref=f1e306] [cursor=pointer]:
              - generic [ref=f1e307]: Aa Bb
              - generic [ref=f1e308]: Standard
        - generic [ref=f1e309]:
          - generic [ref=f1e310]: Display
          - switch "Background dots" [checked] [ref=f1e311] [cursor=pointer]:
            - generic [ref=f1e312]:
              - generic [ref=f1e313]: Background dots
              - generic [ref=f1e314]: The dot grid behind the board.
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash, randomUUID } from 'node:crypto';
  3  | import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
  4  | import { join } from 'node:path';
  5  | import { execFileSync } from 'node:child_process';
  6  | import { browserEvidence } from './evidence';
  7  | const manifest = JSON.parse(readFileSync(join(process.cwd(),'apps/web/public/classroom-voice-samples/manifest.json'),'utf8'));
  8  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4170') + '/api';
  9  | test.afterEach(async ({ page }) => page.unrouteAll({ behavior: 'wait' }));
  10 | async function fixture(page: Page) {
  11 |   const digest=createHash('sha256').update(test.info().testId).digest(),address='198.19.'+digest[0]+'.'+digest[1],principal='whiteboard-'+randomUUID()+'@local.test',credential='Synthetic-controls-only-20261027';
  12 |   await page.setExtraHTTPHeaders({'X-Forwarded-For':address});
  13 |   async function call(path:string,body:unknown,token?:string,method='POST') { const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json','X-Forwarded-For':address,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});expect(response.ok,path+' '+response.status).toBe(true);return(await response.json()).data; }
  14 |   const actor=await call('/auth/register',{principal,credential}),child=(await call('/students',{nickname:'匿名设置验证',grade:5,preferredSessionMinutes:15,defaultVersionMap:{math:'common',chinese:'common',english:'common'}},actor.token)).profile.id;
  15 |   await call('/students/'+child+'/learning-scope',{subject:'math',grade:5,term:'upper',textbookVolumeId:null,textbookVersion:'合成范围',learnedAtomIds:['core:math:fractionadd'],currentAtomId:'core:math:fractionadd',minutesPerSession:15,progressMode:'knowledge',selectedLessonIds:[]},actor.token,'PUT');
  16 |   const input={studentId:child,subject:'math',prompt:'解释异分母分数加法',atomId:'core:math:fractionadd'},preview=await call('/learning/studio/whiteboards/preview',input,actor.token),saved=await call('/learning/studio/whiteboards',{...input,fingerprint:preview.fingerprint,requestKey:randomUUID()},actor.token),board=await call('/qa/whiteboard-media',{boardId:saved.id},actor.token);
  17 |   await page.route('**/api/learning/studio/overview?*',async route=>{const response=await route.fetch(),payload=await response.json();payload.data.narrationAvailable=true;payload.data.speech={available:true,provider:'minimax',defaultVoice:manifest.voices[0].voiceId,voices:manifest.voices.map((voice:any)=>({id:voice.voiceId,label:voice.providerName,language:voice.language,classroomPreset:voice.preset}))};await route.fulfill({response,json:payload});});
  18 |   await page.addInitScript(()=>{const NativeAudio=window.Audio;(window as any).settingsAudio=[];(window as any).Audio=function(src?:string){const audio=new NativeAudio(src);(window as any).settingsAudio.push(audio);return audio;};});
  19 |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  20 |   const href='/studio?student='+child+'&subject=math&whiteboard='+board.id;await page.goto(href);const player=page.getByRole('dialog',{name:'白板视频',exact:true});await expect(player).toHaveAttribute('data-original-font-status','ready');
  21 |   const current=player.locator('.wb-current-sentence');await expect(current).toContainText('先统一单位');return {player,current,href,board};
  22 | }
  23 | 
  24 | test('original settings: six actual neutral MP3s decode, previews preserve selection and closing releases audio',async({page})=>{
  25 |   await page.setViewportSize({width:1280,height:800});const f=await fixture(page),unit=await f.current.getAttribute('data-unit-id'),writes:string[]=[];page.on('request',request=>{if(request.method()==='POST')writes.push(request.url());});
  26 |   await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});await expect(settings.getByRole('radio')).toHaveCount(6);
> 27 |   expect((await settings.boundingBox())!.width).toBe(460);const selected=await f.player.getByRole('combobox',{name:'旁白音色',exact:true}).inputValue();
     |                                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  28 |   const decoded=[];
  29 |   for(const voice of manifest.voices){await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect.poll(()=>page.evaluate(()=>{const audio=(window as any).settingsAudio.at(-1) as HTMLAudioElement;return audio&&!audio.paused&&audio.currentTime>0;})).toBe(true);
  30 |     const result=await page.evaluate(()=>{const audio=(window as any).settingsAudio.at(-1) as HTMLAudioElement;return {duration:audio.duration,rate:audio.playbackRate};});expect(Math.abs(result.duration-voice.durationSeconds)).toBeLessThan(.25);decoded.push({voice:voice.preset,...result});
  31 |     await expect(f.player.getByRole('combobox',{name:'旁白音色',exact:true})).toHaveValue(selected);await expect(f.current).toHaveAttribute('data-unit-id',unit!);
  32 |   }
  33 |   await settings.getByRole('radio',{name:'Calm',exact:true}).click();await expect(f.player.getByRole('combobox',{name:'旁白音色',exact:true})).toHaveValue(manifest.voices.find((voice:any)=>voice.preset==='calm').voiceId);
  34 |   await page.screenshot({path:join(browserEvidence('whiteboard-settings'),'original-settings-1280.png')});
  35 |   await page.keyboard.press('Escape');await expect(settings).toHaveCount(0);await expect(f.player).toBeVisible();expect(await page.evaluate(()=>(window as any).settingsAudio.every((audio:HTMLAudioElement)=>audio.paused))).toBe(true);expect(writes).toEqual([]);
  36 |   await expect(f.player.getByRole('button',{name:'播放',exact:true})).toBeEnabled();writeFileSync(join(browserEvidence('whiteboard-settings'),'actual-neutral-clip-decode.json'),JSON.stringify({decoded,writes,unit},null,2)+'\n');
  37 | });
  38 | 
  39 | test('original settings: corrupt samples fail visibly, explicit retry works and a late closed sample never plays',async({page})=>{
  40 |   const f=await fixture(page),voice=manifest.voices[0],url='**/classroom-voice-samples/'+voice.file;await page.route(url,route=>route.fulfill({status:200,contentType:'audio/mpeg',body:Buffer.from('Changed sample')}));
  41 |   await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect(settings.getByRole('status')).toContainText('与原样本不一致');expect(await page.evaluate(()=>(window as any).settingsAudio.length)).toBe(0);
  42 |   await page.unroute(url);await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).settingsAudio.some((audio:HTMLAudioElement)=>!audio.paused))).toBe(true);
  43 |   await settings.getByRole('button',{name:'关闭白板设置',exact:true}).click();await f.player.getByRole('button',{name:'白板设置',exact:true}).click();let reached=false;
  44 |   await page.route(url,async route=>{reached=true;const response=await route.fetch();await new Promise(resolve=>setTimeout(resolve,800));try{await route.fulfill({response});}catch{}});
  45 |   await settings.getByRole('button',{name:'试听音色：'+voice.providerName,exact:true}).click();await expect.poll(()=>reached).toBe(true);await settings.getByRole('button',{name:'关闭白板设置',exact:true}).click();await page.waitForTimeout(1000);expect(await page.evaluate(()=>(window as any).settingsAudio.every((audio:HTMLAudioElement)=>audio.paused))).toBe(true);await expect(f.current).toContainText('先统一单位');
  46 | });
  47 | 
  48 | test('original settings: half speed restores, double speed records real WAV and frozen captions at matching durations',async({page})=>{
  49 |   const f=await fixture(page);await f.player.getByRole('button',{name:'白板设置',exact:true}).click();const settings=page.getByRole('dialog',{name:'白板设置',exact:true});await settings.getByRole('slider',{name:'白板语速',exact:true}).fill('0');await settings.getByRole('button',{name:'关闭白板设置',exact:true}).click();await expect(f.player.getByRole('combobox',{name:'播放速度',exact:true})).toHaveValue('0.5');
  50 |   await expect.poll(()=>page.evaluate(()=>Object.keys(localStorage).some(key=>key.includes('.location.v1.')&&JSON.parse(localStorage.getItem(key)!).speed===.5))).toBe(true);await page.reload();await expect(f.player.getByRole('combobox',{name:'播放速度',exact:true})).toHaveValue('0.5');
  51 |   await f.player.getByRole('button',{name:'播放',exact:true}).click();await expect.poll(()=>page.evaluate(()=>{const audio=(window as any).settingsAudio.find((audio:HTMLAudioElement)=>!audio.paused);return audio?.playbackRate;})).toBe(.5);await f.player.getByRole('button',{name:'暂停',exact:true}).click();
  52 |   const half=page.waitForEvent('download');await f.player.getByRole('button',{name:'导出字幕',exact:true}).click();expect(readFileSync((await(await half).path())!,'utf8')).toContain('00:00:12,000 --> 00:00:16,000');
  53 |   await f.player.getByRole('combobox',{name:'播放速度',exact:true}).selectOption('2');const video=page.waitForEvent('download');await f.player.getByRole('button',{name:'导出视频',exact:true}).click();const file=(await(await video).path())!,probe=JSON.parse(execFileSync(process.env.STUDY_FFPROBE??'ffprobe',['-v','error','-show_format','-show_streams','-of','json',file],{encoding:'utf8',windowsHide:true}));expect(probe.streams.some((stream:any)=>stream.codec_type==='audio')).toBe(true);expect(Math.abs(Number(probe.format.duration)-4)).toBeLessThan(.6);
  54 |   const subtitles=page.waitForEvent('download');await f.player.getByRole('button',{name:'导出字幕',exact:true}).click();const srt=readFileSync((await(await subtitles).path())!,'utf8');expect(srt).toContain('00:00:03,000 --> 00:00:04,000');const directory=browserEvidence('whiteboard-settings');copyFileSync(file,join(directory,'double-rate.webm'));writeFileSync(join(directory,'double-rate-probe.json'),JSON.stringify(probe,null,2)+'\n');writeFileSync(join(directory,'double-rate.srt'),srt);
  55 | });
  56 | 
```