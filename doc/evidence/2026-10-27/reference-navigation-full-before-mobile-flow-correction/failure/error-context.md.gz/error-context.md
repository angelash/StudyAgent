# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio.spec.ts >> a parent can build and reopen an evidence-backed learning studio course
- Location: tests\e2e\studio.spec.ts:30:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Materials' })

```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - button "打开学习导航" [ref=f3e4] [cursor=pointer]
    - generic [ref=f3e7]:
      - generic [ref=f3e8]:
        - generic [ref=f3e9]:
          - combobox "学习档案" [ref=f3e10]:
            - option "工作台验收" [selected]
          - combobox "学科" [ref=f3e11]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f3e12]:
          - link "教学课堂 ↗" [ref=f3e13] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f3e14] [cursor=pointer]:
            - /url: /
      - generic [ref=f3e15]:
        - generic [ref=f3e16]:
          - button "Craft Courses" [ref=f3e17] [cursor=pointer]
          - button "Instant Assistance" [ref=f3e18] [cursor=pointer]
        - generic [ref=f3e19]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f3e20]
          - paragraph [ref=f3e21]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f3e22]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f3e23]
          - generic [ref=f3e24]:
            - generic [ref=f3e25]: ＋
            - generic [ref=f3e26]: 资料
            - button "Concept Explanation" [ref=f3e27] [cursor=pointer]
            - generic [ref=f3e28]: 语音
            - generic [ref=f3e30]:
              - generic [ref=f3e31]:
                - generic [ref=f3e32]: 模型
                - combobox "选择大模型" [ref=f3e33] [cursor=pointer]:
                  - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                  - option "GPT-6.1 Sol"
                  - option "GPT-6 Astra"
                  - option "GPT-6 Luna"
                  - option "Grok-4.7"
                  - option "GLM-5.3 Flash"
                  - option "DeepSeek V4.1 Flash · 默认" [selected]
                  - option "Claude Opus 5.5"
                  - option "Claude Sonnet 5"
                  - option "GPT-6 Sol"
                  - option "GPT-5.6 Sol"
                  - option "GPT-5.6 Terra"
                  - option "GPT-5.6 Luna"
                  - option "GPT-5.5"
                  - option "Grok-4.6"
                  - option "GLM-5.2"
                  - option "GLM-5.3"
                  - option "Claude Opus 5"
                  - option "Claude Fable 5.1"
                  - option "MiMo V2.6 Pro"
                  - option "MiMo V2.6 Flash"
                  - option "MiMo V2.6 Pro Ultraspeed"
                  - option "Qwen3.8 Max"
              - generic [ref=f3e34]: 尚未进行文字检查
            - button "↑" [ref=f3e36] [cursor=pointer]
        - generic [ref=f3e37]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f3e38] [cursor=pointer]:
            - generic [ref=f3e39]: 可视化
            - generic [ref=f3e40]: 用图形解释异分母加法
            - generic [ref=f3e41]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f3e42] [cursor=pointer]:
            - generic [ref=f3e43]: 个性化练习
            - generic [ref=f3e44]: 从我的已知点生成练习
            - generic [ref=f3e45]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f3e46] [cursor=pointer]:
            - generic [ref=f3e47]: 主动学习
            - generic [ref=f3e48]: 看看今天最值得做什么
            - generic [ref=f3e49]: 按教育优先级排序
        - generic [ref=f3e50]:
          - heading "你的学习路径" [level=2] [ref=f3e51]
          - button "创建课程" [ref=f3e52] [cursor=pointer]
        - button "5年级 分数关系与证据 从已确认的2个知识点出发，用可验证的新题与间隔复测形成连续学习路径。 1 单元 · 2 目标" [ref=f3e54] [cursor=pointer]:
          - generic [ref=f3e55]: 5年级
          - heading "分数关系与证据" [level=3] [ref=f3e56]
          - paragraph [ref=f3e57]: 从已确认的2个知识点出发，用可验证的新题与间隔复测形成连续学习路径。
          - generic [ref=f3e58]: 1 单元 · 2 目标
```

# Test source

```ts
  58  |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  59  |   await page.goto('/studio');
  60  |   await expect(page.getByRole('button', { name: 'Craft Courses' })).toBeVisible();
  61  |   await expect(page.getByRole('button', { name: 'Instant Assistance' })).toBeVisible();
  62  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-home-polished.png', fullPage: true });
  63  |   await page.getByRole('button', { name: '生成第一门课程' }).click();
  64  |   await page.getByLabel('课程名称', {exact:true}).fill('分数关系与证据');
  65  |   await page.getByRole('button', { name: '预览课程蓝图' }).click();
  66  |   await expect(page.getByText('Unit 1:', { exact: false }).first()).toBeVisible();
  67  |   await page.getByRole('button', { name: '确认并创建' }).click();
  68  |   await expect(page.getByRole('heading', { name: '分数关系与证据' })).toBeVisible();
  69  |   await expect(page.getByText('Unit 1:', { exact: false }).first()).toBeVisible();
  70  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-course-polished.png', fullPage: true });
  71  | 
  72  |   await page.getByRole('button', { name: 'Courses', exact: true }).click();
  73  |   const ticket = page.locator('.ws-course-ticket').filter({ has: page.getByRole('button', { name: '打开课程：分数关系与证据', exact: true }) });
  74  |   await page.evaluate(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  75  |   await ticket.locator('.ws-ticket-next').click();
  76  |   await expect(page.locator('.cl-room')).toBeVisible();
  77  |   await page.getByRole('button', { name: '离开课堂', exact: true }).click();
  78  |   await page.getByRole('button', { name: '保存并离开' }).click();
  79  |   await expect(page.getByRole('heading', { name: '分数关系与证据' })).toBeVisible();
  80  | 
  81  |   await page.getByRole('button', { name: 'Home' }).click();
  82  |   await page.getByRole('button', { name: 'Instant Assistance' }).click();
  83  |   await page.getByRole('button', { name: 'Concept Explanation' }).click();
  84  |   await page.locator('.sa-tools-popover').getByRole('button', { name: /Whiteboard session/ }).click();
  85  |   await page.locator('.sa-composer textarea').fill('解释异分母分数加法');
  86  |   await page.locator('.sa-composer > div > button:last-child').click();
  87  |   await expect(page.getByText('WHITEBOARD SESSION', { exact: true })).toBeVisible();
  88  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-whiteboard-preview.png', fullPage: true });
  89  |   await page.getByRole('button', { name: '保存到学习工作台' }).click();
  90  |   await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  91  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-whiteboard-player.png', fullPage: true });
  92  |   const videoDownload = page.waitForEvent('download', { timeout: 120_000 });
  93  |   await page.getByRole('button', { name: '导出视频' }).click();
  94  |   const video = await videoDownload;
  95  |   expect(video.suggestedFilename()).toMatch(/\.webm$/);
  96  |   expect(statSync(await video.path()).size).toBeGreaterThan(2_000);
  97  |   const subtitleDownload = page.waitForEvent('download');
  98  |   await page.getByRole('button', { name: '导出字幕' }).click();
  99  |   expect((await subtitleDownload).suggestedFilename()).toMatch(/\.srt$/);
  100 |   await page.getByRole('button', { name: '关闭白板' }).click();
  101 | 
  102 |   await page.getByRole('button', { name: 'Calendar' }).click();
  103 |   await page.getByRole('button', { name: '＋ 新建学习安排' }).click();
  104 |   await page.getByLabel('任务名称').fill('分数复习安排');
  105 |   await page.getByLabel('完成标准').fill('独立完成 5 道新题并说出关键步骤');
  106 |   await page.getByRole('button', { name: '加入学习日历' }).click();
  107 |   await expect(page.locator('.ws-month-grid').getByText('分数复习安排')).toBeVisible();
  108 |   await page.getByRole('button', { name: '连接 LMS / 日历' }).click();
  109 |   await page.getByLabel('来源类型').selectOption('lms_ics');
  110 |   await page.getByLabel('或粘贴 ICS 文件内容').fill('BEGIN:VCALENDAR\nBEGIN:VEVENT\nUID:school-1\nDTSTART:20261103T080000+0800\nDTEND:20261103T084500+0800\nSUMMARY:学校单元复习\nEND:VEVENT\nEND:VCALENDAR');
  111 |   await page.getByRole('button', { name: '连接并同步' }).click();
  112 |   await page.getByRole('button', {name:'下一个日期范围'}).click();
  113 |   await expect(page.locator('.ws-month-grid').getByText('学校单元复习')).toBeVisible();
  114 |   await expect(page.getByRole('button', { name: '连接并同步' })).toHaveCount(0);
  115 |   await page.locator('.ws-calendar-management > summary').click();
  116 |   await page.getByRole('button', { name: '＋ 生成诊断学习计划' }).click();
  117 |   await expect(page.getByLabel('计划目标')).toBeVisible();
  118 |   await page.getByRole('button', { name: '预览学习计划' }).click();
  119 |   await expect(page.getByText('审阅后再加入日历')).toBeVisible();
  120 |   await expect(page.getByText(/计划完成只表示执行过任务/)).toBeVisible();
  121 |   await page.getByRole('button', { name: '确认并加入日历' }).click();
  122 |   await expect(page.locator('.sa-plan-card')).toBeVisible();
  123 |   await page.locator('.sa-plan-actions').getByRole('button', { name: '完成', exact: true }).first().click();
  124 |   await expect(page.getByText('D+1 延迟复测', { exact: false }).first()).toBeVisible();
  125 |   await expect(page.getByText(/D\+14/).last()).toBeVisible();
  126 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-calendar-polished.png', fullPage: true });
  127 | 
  128 |   const pdf = writeTextPdf();
  129 |   await page.getByRole('button', { name: 'Materials' }).click();
  130 |   await expect(page.getByRole('tab', { name: 'PDF 页级资料' })).toHaveAttribute('aria-selected', 'true');
  131 |   await page.locator('input[type=file]').setInputFiles(pdf.path);
  132 |   await expect(page.getByText('分数讲义', { exact: true }).first()).toBeVisible({ timeout: 30_000 });
  133 |   await page.waitForFunction(() => Boolean(document.querySelector('.sa-pdf-paper img') || document.querySelector('.sa-pdf-failed')),
  134 |     undefined, { timeout: 30_000 });
  135 |   if (await page.locator('.sa-pdf-failed').count())
  136 |     throw new Error('PDF processing failed: ' + await page.locator('.sa-pdf-failed').innerText());
  137 |   await expect(page.locator('.sa-pdf-paper img')).toBeVisible({ timeout: 30_000 });
  138 |   await page.getByRole('button', { name: '结构恢复' }).click();
  139 |   await expect(page.getByText('公式结构', { exact: true })).toBeVisible();
  140 |   await expect(page.getByText(/候选 LaTeX/)).toBeVisible();
  141 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-pdf-structure-review.png', fullPage: true });
  142 |   await page.getByRole('button', { name: '已对照原页确认结构' }).click();
  143 |   await expect(page.getByText('结构已恢复')).toBeVisible();
  144 |   await page.getByRole('button', { name: '原版页面' }).click();
  145 |   const originalDownload = page.waitForEvent('download');
  146 |   await page.getByRole('button', { name: '下载原文件' }).click();
  147 |   expect((await originalDownload).suggestedFilename()).toMatch(/\.pdf$/);
  148 |   await page.getByRole('tab', { name: '个性化学案' }).click();
  149 |   await page.getByRole('button', { name: '生成学案预览' }).click();
  150 |   await expect(page.getByText('REVIEW BEFORE SAVING')).toBeVisible();
  151 |   await page.getByRole('button', { name: '保存到 Materials' }).click();
  152 |   await expect(page.locator('.sa-pack-library')).toContainText('个性化学案');
  153 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-materials-and-pack.png', fullPage: true });
  154 |   pdf.cleanup();
  155 | 
  156 |   await page.setViewportSize({ width: 390, height: 844 });
  157 |   await page.goto('/studio');
> 158 |   await page.getByRole('button', { name: 'Materials' }).click();
      |                                                         ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  159 |   await page.getByRole('tab', { name: '个性化学案' }).click();
  160 |   await expect(page.locator('.sa-pack-layout')).toBeVisible();
  161 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  162 |   await page.getByRole('button', { name: 'Calendar' }).click();
  163 |   await page.locator('.ws-calendar-management > summary').click();
  164 |   await expect(page.locator('.sa-plan-card')).toBeVisible();
  165 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  166 | 
  167 |   await page.getByRole('button', { name: 'Home' }).click();
  168 |   await page.reload();
  169 |   await expect(page.getByRole('button', { name: 'Craft Courses' })).toBeVisible();
  170 |   expect(errors).toEqual([]);
  171 | });
  172 | 
```