# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-media.spec.ts >> continuity: changing voice fences the old adjacent request and preserves an explicit fresh play
- Location: tests/e2e/whiteboard-media.spec.ts:226:5

# Error details

```
Error: expect(received).toBeTruthy()

Received: undefined
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - button "Home" [ref=f1e10] [cursor=pointer]:
          - generic [ref=f1e13]: 首页
        - button "Courses" [ref=f1e14] [cursor=pointer]:
          - generic [ref=f1e17]: 课程
        - button "Calendar" [ref=f1e18] [cursor=pointer]:
          - generic [ref=f1e21]: 学习动态
        - button "History" [ref=f1e22] [cursor=pointer]:
          - generic [ref=f1e25]: 历史
        - button "Materials" [ref=f1e26] [cursor=pointer]:
          - generic [ref=f1e29]: 资料
        - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f1e33]: AI白板
      - button "＋ 创建课程" [ref=f1e34] [cursor=pointer]
      - generic [ref=f1e35]:
        - heading "继续学习" [level=2] [ref=f1e36]
        - link "讲座社会学想象力 社会学概论" [ref=f1e37] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f1e38]: 社会学概论
      - generic [ref=f1e39]:
        - heading "近期活动" [level=2] [ref=f1e40]
        - link "白板视频「异分母分数加法」" [ref=f1e41] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_4509bcab-a56e-42b5-9f81-ba227cc0a2d1
      - link "返回学习首页 →" [ref=f1e43] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_8ffd25e8-c796-4cf1-99f5-0fb1a02e7bef
    - generic [ref=f1e44]:
      - generic [ref=f1e45]:
        - generic [ref=f1e46]:
          - combobox "学习档案" [ref=f1e47]:
            - option "匿名白板验证" [selected]
          - combobox "学科" [ref=f1e48]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e49]:
          - link "教学课堂 ↗" [ref=f1e50] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e51] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e52]:
        - generic [ref=f1e53]:
          - button "Craft Courses" [ref=f1e54] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e55] [cursor=pointer]
        - generic [ref=f1e56]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f1e57]
          - paragraph [ref=f1e58]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f1e59]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f1e60]
          - generic [ref=f1e61]:
            - generic [ref=f1e62]: ＋
            - generic [ref=f1e63]: 资料
            - button "Concept Explanation" [ref=f1e64] [cursor=pointer]
            - generic [ref=f1e65]: 语音
            - generic [ref=f1e68]:
              - generic [ref=f1e69]: 模型
              - combobox "选择大模型" [ref=f1e70] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f1e71] [cursor=pointer]
        - generic [ref=f1e72]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f1e73] [cursor=pointer]:
            - generic [ref=f1e74]: 可视化
            - generic [ref=f1e75]: 用图形解释异分母加法
            - generic [ref=f1e76]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f1e77] [cursor=pointer]:
            - generic [ref=f1e78]: 个性化练习
            - generic [ref=f1e79]: 从我的已知点生成练习
            - generic [ref=f1e80]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f1e81] [cursor=pointer]:
            - generic [ref=f1e82]: 主动学习
            - generic [ref=f1e83]: 看看今天最值得做什么
            - generic [ref=f1e84]: 按教育优先级排序
        - generic [ref=f1e85]:
          - heading "你的学习路径" [level=2] [ref=f1e86]
          - button "创建课程" [ref=f1e87] [cursor=pointer]
        - generic [ref=f1e88]:
          - heading "还没有课程" [level=3] [ref=f1e89]
          - paragraph [ref=f1e90]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f1e91] [cursor=pointer]
        - complementary [ref=f1e92]:
          - article [ref=f1e93]:
            - generic [ref=f1e94]:
              - generic [ref=f1e95]:
                - text: LEARNER SNAPSHOT
                - heading "匿名白板验证" [level=2] [ref=f1e96]
              - generic [ref=f1e97]: 5 年级
            - generic [ref=f1e98]:
              - strong [ref=f1e99]: "0"
              - generic [ref=f1e100]: / 1
              - generic [ref=f1e101]: 已有点有稳定证据
            - generic [ref=f1e102]:
              - generic [ref=f1e103]:
                - generic [ref=f1e104]: "1"
                - text: 已确认知识点
              - generic [ref=f1e105]:
                - generic [ref=f1e106]: "0"
                - text: 日历安排
          - article [ref=f1e107]:
            - generic [ref=f1e108]:
              - generic [ref=f1e109]: NEXT BEST ACTION
              - button "全部 →" [ref=f1e110] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f1e111] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_8ffd25e8-c796-4cf1-99f5-0fb1a02e7bef&subject=math
              - generic [ref=f1e112]: 1个已学点仍需补充证据
              - paragraph [ref=f1e113]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f1e114]:
            - generic [ref=f1e115]:
              - generic [ref=f1e116]: RECENT WHITEBOARDS
              - button "新建" [ref=f1e117] [cursor=pointer]
            - button "▶ 匿名逐句白板 2 幕 · 1 秒" [ref=f1e118] [cursor=pointer]:
              - generic [ref=f1e119]: ▶
              - generic [ref=f1e120]:
                - generic [ref=f1e121]: 匿名逐句白板
                - generic [ref=f1e122]: 2 幕 · 1 秒
          - article [ref=f1e123]:
            - generic [ref=f1e124]:
              - generic [ref=f1e125]: SYNC STATUS
              - button "日历 →" [ref=f1e126] [cursor=pointer]
            - paragraph [ref=f1e127]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f1e128]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f1e129]:
      - generic [ref=f1e130]:
        - generic [ref=f1e131]:
          - generic [ref=f1e132]: WHITEBOARD SESSION / 原白板
          - heading "匿名逐句白板" [level=2] [ref=f1e133]
          - paragraph [ref=f1e134]: 逐句云语音 · 实际音轨结束后继续 · 板书按完整要点呈现
        - button "关闭白板" [ref=f1e135] [cursor=pointer]: ×
      - generic [ref=f1e136]:
        - generic [ref=f1e137]:
          - generic "统一单位" [ref=f1e139]
          - paragraph [ref=f1e140]: "[whiteboard-fixture] 先统一单位。"
          - generic [ref=f1e141]:
            - generic [ref=f1e142]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f1e143] [cursor=pointer]: "0"
          - generic [ref=f1e144]:
            - button "上一句" [disabled] [ref=f1e145]: ←
            - button "播放" [active] [ref=f1e146] [cursor=pointer]: ▶
            - button "下一句" [ref=f1e147] [cursor=pointer]: →
            - generic [ref=f1e148]: 1 / 4 句
            - combobox "阅读方式" [ref=f1e149] [cursor=pointer]:
              - option "文字阅读（估计时长）"
              - option "云语音逐句播放" [selected]
            - combobox "旁白音色" [ref=f1e150] [cursor=pointer]:
              - option "合成音轨 A"
              - option "受控延迟音轨" [selected]
              - option "受控失败音轨"
            - combobox "播放速度" [ref=f1e151] [cursor=pointer]:
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
            - button "导出视频" [ref=f1e152] [cursor=pointer]
            - button "导出字幕" [ref=f1e153] [cursor=pointer]
          - status [ref=f1e154]: 音色已切换，下次播放从当前句开头开始。
          - generic [ref=f1e155]:
            - button "01 统一单位" [ref=f1e156] [cursor=pointer]:
              - generic [ref=f1e157]: "01"
              - text: 统一单位
            - button "02 保留证据" [ref=f1e158] [cursor=pointer]:
              - generic [ref=f1e159]: "02"
              - text: 保留证据
        - complementary "完整讲稿与要点" [ref=f1e160]:
          - heading "逐句讲稿" [level=3] [ref=f1e161]
          - paragraph [ref=f1e162]: 点击一句定位。观看与续播不计作掌握。
          - list [ref=f1e163]:
            - listitem [ref=f1e164]:
              - button "[whiteboard-fixture] 先统一单位。" [ref=f1e165] [cursor=pointer]
            - listitem [ref=f1e166]:
              - button "[whiteboard-fixture] 再合并份数。" [ref=f1e167] [cursor=pointer]
            - listitem [ref=f1e168]:
              - button "[whiteboard-fixture] 最后验证。" [ref=f1e169] [cursor=pointer]
            - listitem [ref=f1e170]:
              - button "[whiteboard-fixture] 保留新的独立观察。" [ref=f1e171] [cursor=pointer]
          - heading "完整笔记与来源" [level=3] [ref=f1e172]
          - group [ref=f1e173]:
            - generic "统一单位" [ref=f1e174] [cursor=pointer]
            - paragraph [ref=f1e175]: 完整正文首行。完整正文末行。
            - list [ref=f1e176]:
              - listitem [ref=f1e177]: 先统一单位
              - listitem [ref=f1e178]: 再合并份数
              - listitem [ref=f1e179]: 最后验证
          - group [ref=f1e180]:
            - generic "保留证据" [ref=f1e181] [cursor=pointer]
          - button "下载续播位置" [ref=f1e182] [cursor=pointer]
```

# Test source

```ts
  132 |     expect(await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeGreaterThanOrEqual(at);
  133 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 2 && row.event === 'ended'), { timeout: 12000 }).toBe(true);
  134 |     await page.getByRole('button', { name: '暂停', exact: true }).click();
  135 |     const result = await timing.save('three-complete-with-speed');
  136 |     const completed = result.audio.filter(row => row.event === 'ended');
  137 |     expect(completed.map(row => row.index)).toEqual([0, 1, 2]);
  138 |     for (const row of completed) expect(row.currentTime).toBe(row.duration);
  139 |     for (const index of [1, 2]) {
  140 |       const start = result.audio.find(row => row.index === index && row.event === 'playing')!;
  141 |       expect(start.at).toBeGreaterThanOrEqual(completed[index - 1].at); expect(start.currentTime).toBeLessThan(.15);
  142 |       expect(result.audio.filter(row => row.index === index && row.event === 'playing')).toHaveLength(1);
  143 |     }
  144 |     expect(new Set(result.requests.map(row => row.unitId)).size).toBe(result.requests.length);
  145 |     await expect(f.current).toContainText('保留新的独立观察');
  146 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  147 | });
  148 | 
  149 | test('continuity: an already prepared WAV cannot survive actual login-session revocation', async ({ page }) => {
  150 |   const timing = await installNarrationTiming(page, 150), f = await fixture(page);
  151 |   try {
  152 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  153 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'loadedmetadata')).toBe(true);
  154 |     // Registration and browser login deliberately create different sessions.
  155 |     // Revoke the current browser Cookie session rather than the setup actor.
  156 |     expect(await page.evaluate(async base => (await fetch(base + '/api/auth/logout', {
  157 |       method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: '{}',
  158 |     })).status, api)).toBe(201);
  159 |     await expect(page.getByRole('dialog', { name: '白板视频' })).toHaveCount(0);
  160 |     const result = await timing.save('revoked-session');
  161 |     expect(result.audio.filter(row => row.index === 1 && row.event === 'playing')).toEqual([]);
  162 |     expect(await page.evaluate(() => (window as any).__whiteboardAudio.every((audio: HTMLAudioElement) => audio.paused && !audio.getAttribute('src')))).toBe(true);
  163 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  164 | });
  165 | 
  166 | test('continuity: a failed adjacent preparation preserves current playback and needs an explicit retry at its original sentence', async ({ page }) => {
  167 |   const f = await fixture(page); let first = '', second = '', secondCalls = 0;
  168 |   await page.route('**/api/learning/studio/whiteboards/*/narration/*', async route => {
  169 |     const unitId = route.request().postDataJSON().unitId;
  170 |     if (!first) first = unitId;
  171 |     if (unitId !== first && !second) second = unitId;
  172 |     if (unitId === second && ++secondCalls === 1) return route.fulfill({ status: 503, contentType: 'application/json', body: '{"error":{"message":"Synthetic preparation failure"}}' });
  173 |     return route.continue();
  174 |   });
  175 |   try {
  176 |     await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => secondCalls).toBe(1);
  177 |     await expect(f.current).toContainText('先统一单位'); await expect(page.getByRole('button', { name: '暂停', exact: true })).toBeVisible();
  178 |     await page.getByRole('button', { name: '暂停', exact: true }).click(); await page.getByRole('button', { name: '播放', exact: true }).click();
  179 |     await expect(f.current).toContainText('再合并份数'); await expect(page.locator('.sa-whiteboard-notice')).toContainText('重试或选择文字');
  180 |     expect(secondCalls).toBe(1); await page.getByRole('button', { name: '播放', exact: true }).click();
  181 |     await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[1]?.currentTime ?? 0)).toBeGreaterThan(.1);
  182 |     expect(secondCalls).toBe(2); await expect(f.current).toContainText('再合并份数');
  183 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  184 | });
  185 | 
  186 | test('continuity: closing during adjacent preparation aborts it and no late audio can play', async ({ page }) => {
  187 |   const timing = await installNarrationTiming(page), f = await fixture(page);
  188 |   try {
  189 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  190 |     await expect.poll(async () => (await timing.read()).requests.length).toBe(2);
  191 |     await page.getByRole('button', { name: '关闭白板', exact: true }).click(); await page.waitForTimeout(1000);
  192 |     const result = await timing.save('close-pending'); expect(result.requests[1].failure).toBeTruthy();
  193 |     expect(result.audio.filter(row => row.index > 0 && row.event === 'playing')).toEqual([]);
  194 |     expect(await page.evaluate(() => (window as any).__whiteboardAudio.every((audio: HTMLAudioElement) => audio.paused && !audio.getAttribute('src')))).toBe(true);
  195 |     await expect(page.getByRole('dialog', { name: '白板视频' })).toHaveCount(0);
  196 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  197 | });
  198 | 
  199 | test('continuity: an exact manual next keeps the prepared WAV paused and transfers it without another request', async ({ page }) => {
  200 |   const timing = await installNarrationTiming(page), f = await fixture(page);
  201 |   try {
  202 |     await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(async () => (await timing.read()).requests.length).toBe(2);
  203 |     const target = (await timing.read()).requests[1].unitId;
  204 |     await page.getByRole('button', { name: '下一句', exact: true }).click(); await expect(f.current).toContainText('再合并份数');
  205 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'loadedmetadata')).toBe(true);
  206 |     expect((await timing.read()).audio.filter(row => row.index === 1 && row.event === 'playing')).toEqual([]);
  207 |     await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'playing')).toBe(true);
  208 |     await page.getByRole('button', { name: '暂停', exact: true }).click(); const result = await timing.save('manual-next');
  209 |     expect(result.requests.filter(row => row.unitId === target)).toHaveLength(1);
  210 |     expect(result.audio.find(row => row.index === 1 && row.event === 'playing')!.currentTime).toBeLessThan(.15);
  211 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  212 | });
  213 | 
  214 | test('continuity: a prepared WAV cannot play after actual guardian revocation before handover', async ({ page }) => {
  215 |   const timing = await installNarrationTiming(page, 150), f = await fixture(page);
  216 |   try {
  217 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  218 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'loadedmetadata')).toBe(true);
  219 |     await f.call('/qa/whiteboard-media', { boardId: f.board.id, revoke: true }, f.actor.token);
  220 |     await expect(page.getByRole('dialog', { name: '白板视频' })).toHaveCount(0);
  221 |     const result = await timing.save('revoked-prepared'); expect(result.audio.filter(row => row.index === 1 && row.event === 'playing')).toEqual([]);
  222 |     expect(await page.evaluate(() => (window as any).__whiteboardAudio.every((audio: HTMLAudioElement) => audio.paused && !audio.getAttribute('src')))).toBe(true);
  223 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  224 | });
  225 | 
  226 | test('continuity: changing voice fences the old adjacent request and preserves an explicit fresh play', async ({ page }) => {
  227 |   const timing = await installNarrationTiming(page), f = await fixture(page);
  228 |   try {
  229 |     await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(async () => (await timing.read()).requests.length).toBe(2);
  230 |     const old = (await timing.read()).requests[1].unitId;
  231 |     await page.getByLabel('旁白音色').selectOption('fixture-delay'); await page.waitForTimeout(1000);
> 232 |     let result = await timing.read(); expect(result.requests[1].failure).toBeTruthy();
      |                                                                          ^ Error: expect(received).toBeTruthy()
  233 |     expect(result.audio.filter(row => row.index > 0 && row.event === 'playing')).toEqual([]); await expect(f.current).toContainText('先统一单位');
  234 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  235 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'playing'), { timeout: 10000 }).toBe(true);
  236 |     result = await timing.save('voice-change'); expect(result.requests.filter(row => row.unitId === old && row.voice === 'fixture-a')).toHaveLength(1);
  237 |     expect(result.requests.some(row => row.voice === 'fixture-delay')).toBe(true);
  238 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  239 | });
  240 | 
  241 | test('continuity: slow adjacent audio cannot advance early and can be paused while waiting', async ({ page }) => {
  242 |   const timing = await installNarrationTiming(page, 3300), f = await fixture(page);
  243 |   try {
  244 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  245 |     await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0), { timeout: 10000 }).toBeGreaterThan(.8);
  246 |     await expect(f.current).toContainText('先统一单位');
  247 |     await expect(f.current).toContainText('再合并份数'); await expect(page.locator('.sa-whiteboard-notice')).toContainText('正在准备当前句');
  248 |     await page.getByRole('button', { name: '暂停', exact: true }).click(); await page.waitForTimeout(1800);
  249 |     const result = await timing.save('slow-cancel'); expect(result.requests[1].failure).toBeTruthy();
  250 |     expect(result.audio.filter(row => row.index === 1 && row.event === 'playing')).toEqual([]);
  251 |     await expect(f.current).toContainText('再合并份数'); await expect(page.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  252 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  253 | });
  254 | 
  255 | test('voice switch fences delayed requests and an audio failure offers explicit retry or text reading', async ({ page }) => {
  256 |   const f = await fixture(page); await page.getByLabel('旁白音色').selectOption('fixture-delay');
  257 |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect(page.getByRole('status').last()).toContainText('正在准备当前句');
  258 |   await page.getByLabel('旁白音色').selectOption('fixture-fail'); await page.waitForTimeout(2100);
  259 |   expect(await page.evaluate(() => (window as any).__whiteboardAudio.length)).toBe(0);
  260 |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect(page.locator('.sa-whiteboard-notice')).toContainText('重试或选择文字');
  261 |   await expect(f.current).toContainText('先统一单位'); await page.getByLabel('阅读方式').selectOption('text');
  262 |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => page.getByRole('slider').inputValue()).not.toBe('0');
  263 | });
  264 | 
  265 | test('reopening a paused cloud sentence restores its known audio time in the verified original board', async ({ page }) => {
  266 |   const f = await fixture(page); await page.getByRole('button', { name: '播放', exact: true }).click();
  267 |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(.35);
  268 |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  269 |   const at = await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime);
  270 |   await page.waitForTimeout(1700); await page.reload(); await expect(f.current).toContainText('先统一单位');
  271 |   await page.getByRole('button', { name: '播放', exact: true }).click();
  272 |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(at - .05);
  273 |   expect(await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeLessThan(at + .6);
  274 | });
  275 | 
  276 | test('scoped local resume and complete accessible notes fit phone, tablet and desktop', async ({ page }) => {
  277 |   const f = await fixture(page); await page.getByRole('button', { name: '下一句' }).click();
  278 |   await expect(f.current).toContainText('再合并份数'); await page.waitForTimeout(1700); await page.reload();
  279 |   await expect(f.current).toContainText('再合并份数'); await expect(page.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  280 |   const stored = await page.evaluate(() => Object.entries(localStorage).filter(([key]) => key.startsWith('studyagent.whiteboard.location.v1.')));
  281 |   expect(stored).toHaveLength(1); expect(stored[0][1]).not.toContain('再合并份数');
  282 |   for (const width of [390, 768, 1440]) {
  283 |     await page.setViewportSize({ width, height: 1000 }); await expect(f.current).toBeVisible();
  284 |     expect(await page.locator('.wb-sentence-player').evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
  285 |   }
  286 |   await page.getByRole('button', { name: '关闭白板' }).click();
  287 |   await page.evaluate(([key, value]) => localStorage.setItem(key, JSON.stringify({ ...JSON.parse(value), fingerprint: 'b'.repeat(64) })), stored[0]);
  288 |   await page.reload(); await expect(f.current).toContainText('先统一单位'); await expect(page.locator('.sa-whiteboard-notice')).toContainText('版本不符');
  289 | });
  290 | 
  291 | test('actual WebM has a decoded audio track and the same complete SRT timeline at the selected speed', async ({ page }) => {
  292 |   const f = await fixture(page); await page.getByLabel('播放速度').selectOption('1.25');
  293 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '导出视频' }).click(); const video = await download;
  294 |   const directory = browserEvidence('whiteboard-media'); copyFileSync((await video.path())!, join(directory, 'decoded-fixture.webm'));
  295 |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', (await video.path())!], { encoding: 'utf8', windowsHide: true }));
  296 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true);
  297 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'video')).toBe(true);
  298 |   expect(Math.abs(Number(probe.format.duration) - 6.4)).toBeLessThan(.6);
  299 |   const ffmpeg = process.env.STUDY_FFMPEG ?? 'ffmpeg', path = (await video.path())!;
  300 |   const decoded = spawnSync(ffmpeg, ['-v', 'error', '-xerror', '-i', path, '-f', 'null', '-'], { windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  301 |   expect(decoded.status).toBe(0); expect(decoded.stdout.length).toBe(0);
  302 |   const eofParserMessage = /^\[opus @ [^\]]+\] Error parsing Opus packet header\.\s*$/u;
  303 |   let controlReceipt: { exit: number | null; stderr: string } | null = null;
  304 |   if (decoded.stderr.length) {
  305 |     // FFmpeg 8.0.1 also logs this parser EOF error for its own valid Opus file.
  306 |     // A different message, a codec error, or an absent independent control fails.
  307 |     expect(decoded.stderr.toString()).toMatch(eofParserMessage);
  308 |     const controlPath = join(directory, 'independent-opus-control.webm');
  309 |     execFileSync(ffmpeg, ['-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000:duration=1', '-c:a', 'libopus', '-y', controlPath], { windowsHide: true });
  310 |     const control = spawnSync(ffmpeg, ['-v', 'error', '-xerror', '-i', controlPath, '-f', 'null', '-'], { windowsHide: true });
  311 |     expect(control.status).toBe(0); expect(control.stderr.toString()).toMatch(eofParserMessage);
  312 |     controlReceipt = { exit: control.status, stderr: control.stderr.toString() };
  313 |   }
  314 |   const pcm = spawnSync(ffmpeg, ['-v', 'error', '-xerror', '-fflags', '+noparse+nofillin', '-i', path, '-map', '0:a:0', '-ac', '1', '-ar', '48000', '-f', 'f32le', '-'],
  315 |     { windowsHide: true, maxBuffer: 16 * 1024 * 1024 });
  316 |   expect(pcm.status).toBe(0); expect(pcm.stderr.toString()).toBe('');
  317 |   const samples = pcm.stdout.length / 4; expect(samples / 48000).toBeGreaterThanOrEqual(6.4);
  318 |   function marker(frequency: number, from: number, to: number) {
  319 |     let peak = 0;
  320 |     for (let offset = from; offset + 768 <= to; offset += 192) {
  321 |       let real = 0, imaginary = 0;
  322 |       for (let i = 0; i < 768; i++) { const value = pcm.stdout.readFloatLE((offset + i) * 4), angle = 2 * Math.PI * frequency * i / 48000; real += value * Math.cos(angle); imaginary += value * Math.sin(angle); }
  323 |       peak = Math.max(peak, Math.hypot(real, imaginary) / 768);
  324 |     }
  325 |     return peak;
  326 |   }
  327 |   const firstMarker = marker(1100 * 1.25, 0, Math.min(samples, 14400)), lastMarker = marker(1900 * 1.25, Math.max(0, samples - 14400), samples);
  328 |   expect(firstMarker).toBeGreaterThan(.003); expect(lastMarker).toBeGreaterThan(.003);
  329 |   writeFileSync(join(directory, 'decoder.json'), JSON.stringify({ defaultExit: decoded.status, defaultStderr: decoded.stderr.toString(), control: controlReceipt,
  330 |     pcmExit: pcm.status, pcmStderr: pcm.stderr.toString(), samples, durationSeconds: samples / 48000, firstMarker, lastMarker }, null, 2) + '\n');
  331 |   const subtitles = page.waitForEvent('download'); await page.getByRole('button', { name: '导出字幕' }).click(); const srt = readFileSync((await (await subtitles).path())!, 'utf8');
  332 |   copyFileSync((await (await subtitles).path())!, join(directory, 'decoded-fixture.srt'));
```