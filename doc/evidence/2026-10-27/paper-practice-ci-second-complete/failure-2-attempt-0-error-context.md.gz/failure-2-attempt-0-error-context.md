# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-media.spec.ts >> scoped local resume and complete accessible notes fit phone, tablet and desktop
- Location: tests/e2e/whiteboard-media.spec.ts:276:5

# Error details

```
Error: "route.fetch: Test ended.
Call log:
  - → GET http://localhost:4107/api/learning/studio/overview?studentId=student_c7f16649-b6a0-4fa5-ab84-f4bfb906308c&subject=math
    - user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/156.0.8078.4 Safari/537.36
    - accept: */*
    - accept-encoding: gzip,deflate,br
    - accept-language: en-US
    - content-type: application/json
    - cookie: study_session=5jt-nExx21FN0NkxJksFSzHDuY_TdZKa-R9W87Ufo5M
    - origin: http://localhost:3107
    - referer: http://localhost:3107/
    - x-forwarded-for: 198.19.35.251
    - sec-ch-ua: "Not:A-Brand";v="8", "Chromium";v="156", "HeadlessChrome";v="156"
    - sec-ch-ua-mobile: ?0
    - sec-ch-ua-platform: "Linux"
" while running route callback.
Consider awaiting `await page.unrouteAll({ behavior: 'ignoreErrors' })`
before the end of the test to ignore remaining routes in flight.
```

# Page snapshot

```yaml
- generic [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - complementary "学习工作台导航" [ref=f3e4]:
      - link "StudyAgent" [ref=f3e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f3e9]:
        - button "Home" [ref=f3e10] [cursor=pointer]:
          - generic [ref=f3e13]: 首页
        - button "Courses" [ref=f3e14] [cursor=pointer]:
          - generic [ref=f3e17]: 课程
        - button "Calendar" [ref=f3e18] [cursor=pointer]:
          - generic [ref=f3e21]: 学习动态
        - button "History" [ref=f3e22] [cursor=pointer]:
          - generic [ref=f3e25]: 历史
        - button "Materials" [ref=f3e26] [cursor=pointer]:
          - generic [ref=f3e29]: 资料
        - link "AI Whiteboards" [ref=f3e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f3e33]: AI白板
      - button "＋ 创建课程" [ref=f3e34] [cursor=pointer]
      - generic [ref=f3e35]:
        - heading "继续学习" [level=2] [ref=f3e36]
        - link "讲座社会学想象力 社会学概论" [ref=f3e37] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f3e38]: 社会学概论
      - generic [ref=f3e39]:
        - heading "近期活动" [level=2] [ref=f3e40]
        - link "白板视频「异分母分数加法」" [ref=f3e41] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_e969dee1-3608-4405-90c3-e45ab7bb80ea
      - link "返回学习首页 →" [ref=f3e43] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_674ec552-3971-486e-ad64-edbb6f4c2c9a
    - generic [ref=f3e44]:
      - generic [ref=f3e45]:
        - generic [ref=f3e46]:
          - combobox "学习档案" [ref=f3e47]:
            - option "匿名白板验证" [selected]
          - combobox "学科" [ref=f3e48]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f3e49]:
          - link "教学课堂 ↗" [ref=f3e50] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f3e51] [cursor=pointer]:
            - /url: /
      - generic [ref=f3e52]:
        - generic [ref=f3e53]:
          - button "Craft Courses" [ref=f3e54] [cursor=pointer]
          - button "Instant Assistance" [ref=f3e55] [cursor=pointer]
        - generic [ref=f3e56]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f3e57]
          - paragraph [ref=f3e58]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f3e59]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f3e60]
          - generic [ref=f3e61]:
            - generic [ref=f3e62]: ＋
            - generic [ref=f3e63]: 资料
            - button "Concept Explanation" [ref=f3e64] [cursor=pointer]
            - generic [ref=f3e65]: 语音
            - generic [ref=f3e68]:
              - generic [ref=f3e69]: 模型
              - combobox "选择大模型" [ref=f3e70] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f3e71] [cursor=pointer]
        - generic [ref=f3e72]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f3e73] [cursor=pointer]:
            - generic [ref=f3e74]: 可视化
            - generic [ref=f3e75]: 用图形解释异分母加法
            - generic [ref=f3e76]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f3e77] [cursor=pointer]:
            - generic [ref=f3e78]: 个性化练习
            - generic [ref=f3e79]: 从我的已知点生成练习
            - generic [ref=f3e80]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f3e81] [cursor=pointer]:
            - generic [ref=f3e82]: 主动学习
            - generic [ref=f3e83]: 看看今天最值得做什么
            - generic [ref=f3e84]: 按教育优先级排序
        - generic [ref=f3e85]:
          - heading "你的学习路径" [level=2] [ref=f3e86]
          - button "创建课程" [ref=f3e87] [cursor=pointer]
        - generic [ref=f3e88]:
          - heading "还没有课程" [level=3] [ref=f3e89]
          - paragraph [ref=f3e90]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f3e91] [cursor=pointer]
        - complementary [ref=f3e92]:
          - article [ref=f3e93]:
            - generic [ref=f3e94]:
              - generic [ref=f3e95]:
                - text: LEARNER SNAPSHOT
                - heading "匿名白板验证" [level=2] [ref=f3e96]
              - generic [ref=f3e97]: 5 年级
            - generic [ref=f3e98]:
              - strong [ref=f3e99]: "0"
              - generic [ref=f3e100]: / 1
              - generic [ref=f3e101]: 已有点有稳定证据
            - generic [ref=f3e102]:
              - generic [ref=f3e103]:
                - generic [ref=f3e104]: "1"
                - text: 已确认知识点
              - generic [ref=f3e105]:
                - generic [ref=f3e106]: "0"
                - text: 日历安排
          - article [ref=f3e107]:
            - generic [ref=f3e108]:
              - generic [ref=f3e109]: NEXT BEST ACTION
              - button "全部 →" [ref=f3e110] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f3e111] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_674ec552-3971-486e-ad64-edbb6f4c2c9a&subject=math
              - generic [ref=f3e112]: 1个已学点仍需补充证据
              - paragraph [ref=f3e113]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f3e114]:
            - generic [ref=f3e115]:
              - generic [ref=f3e116]: RECENT WHITEBOARDS
              - button "新建" [ref=f3e117] [cursor=pointer]
            - button "▶ 匿名逐句白板 2 幕 · 1 秒" [ref=f3e118] [cursor=pointer]:
              - generic [ref=f3e119]: ▶
              - generic [ref=f3e120]:
                - generic [ref=f3e121]: 匿名逐句白板
                - generic [ref=f3e122]: 2 幕 · 1 秒
          - article [ref=f3e123]:
            - generic [ref=f3e124]:
              - generic [ref=f3e125]: SYNC STATUS
              - button "日历 →" [ref=f3e126] [cursor=pointer]
            - paragraph [ref=f3e127]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f3e128]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f3e129]:
      - generic [ref=f3e130]:
        - generic [ref=f3e131]:
          - generic [ref=f3e132]: WHITEBOARD SESSION / 原白板
          - heading "匿名逐句白板" [level=2] [ref=f3e133]
          - paragraph [ref=f3e134]: 逐句云语音 · 实际音轨结束后继续 · 板书按完整要点呈现
        - button "关闭白板" [active] [ref=f3e135] [cursor=pointer]: ×
      - generic [ref=f3e136]:
        - generic [ref=f3e137]:
          - generic "统一单位" [ref=f3e139]
          - paragraph [ref=f3e140]: "[whiteboard-fixture] 先统一单位。"
          - generic [ref=f3e141]:
            - generic [ref=f3e142]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f3e143] [cursor=pointer]: "0"
          - generic [ref=f3e144]:
            - button "上一句" [disabled] [ref=f3e145]: ←
            - button "播放" [ref=f3e146] [cursor=pointer]: ▶
            - button "下一句" [ref=f3e147] [cursor=pointer]: →
            - generic [ref=f3e148]: 1 / 4 句
            - combobox "阅读方式" [ref=f3e149] [cursor=pointer]:
              - option "文字阅读（估计时长）"
              - option "云语音逐句播放" [selected]
            - combobox "旁白音色" [ref=f3e150] [cursor=pointer]:
              - option "合成音轨 A" [selected]
              - option "受控延迟音轨"
              - option "受控失败音轨"
            - combobox "播放速度" [ref=f3e151] [cursor=pointer]:
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
            - button "导出视频" [ref=f3e152] [cursor=pointer]
            - button "导出字幕" [ref=f3e153] [cursor=pointer]
          - status [ref=f3e154]: 旧续播位置与当前白板版本不符，已从开头打开。
          - generic [ref=f3e155]:
            - button "01 统一单位" [ref=f3e156] [cursor=pointer]:
              - generic [ref=f3e157]: "01"
              - text: 统一单位
            - button "02 保留证据" [ref=f3e158] [cursor=pointer]:
              - generic [ref=f3e159]: "02"
              - text: 保留证据
        - complementary "完整讲稿与要点" [ref=f3e160]:
          - heading "逐句讲稿" [level=3] [ref=f3e161]
          - paragraph [ref=f3e162]: 点击一句定位。观看与续播不计作掌握。
          - list [ref=f3e163]:
            - listitem [ref=f3e164]:
              - button "[whiteboard-fixture] 先统一单位。" [ref=f3e165] [cursor=pointer]
            - listitem [ref=f3e166]:
              - button "[whiteboard-fixture] 再合并份数。" [ref=f3e167] [cursor=pointer]
            - listitem [ref=f3e168]:
              - button "[whiteboard-fixture] 最后验证。" [ref=f3e169] [cursor=pointer]
            - listitem [ref=f3e170]:
              - button "[whiteboard-fixture] 保留新的独立观察。" [ref=f3e171] [cursor=pointer]
          - heading "完整笔记与来源" [level=3] [ref=f3e172]
          - group [ref=f3e173]:
            - generic "统一单位" [ref=f3e174] [cursor=pointer]
            - paragraph [ref=f3e175]: 完整正文首行。完整正文末行。
            - list [ref=f3e176]:
              - listitem [ref=f3e177]: 先统一单位
              - listitem [ref=f3e178]: 再合并份数
              - listitem [ref=f3e179]: 最后验证
          - group [ref=f3e180]:
            - generic "保留证据" [ref=f3e181] [cursor=pointer]
          - button "下载续播位置" [ref=f3e182] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { copyFileSync, readFileSync, writeFileSync } from 'node:fs';
  3   | import { execFileSync, spawnSync } from 'node:child_process';
  4   | import { createHash } from 'node:crypto';
  5   | import { browserEvidence } from './evidence';
  6   | import { join } from 'node:path';
  7   | import { installNarrationTiming } from './whiteboard-timing';
  8   | 
  9   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107');
  10  | const credential = 'Synthetic-whiteboard-only-20261026';
  11  | async function fixture(page: Page, endedBoundary = false) {
  12  |   const principal = 'whiteboard-' + crypto.randomUUID() + '@local.test';
  13  |   const bucket = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + bucket[0] + '.' + bucket[1];
  14  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  15  |   async function call(path: string, body?: unknown, actor?: string, method = 'POST') {
  16  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(actor ? { Authorization: 'Bearer ' + actor } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  17  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
  18  |   }
  19  |   const actor = await call('/auth/register', { principal, credential });
  20  |   const child = await call('/students', { nickname: '匿名白板验证', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token);
  21  |   const studentId = child.profile.id;
  22  |   await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, actor.token, 'PUT');
  23  |   const draft = { studentId, subject: 'math', prompt: '解释异分母分数加法', atomId: 'core:math:fractionadd' };
  24  |   const preview = await call('/learning/studio/whiteboards/preview', draft, actor.token);
  25  |   const saved = await call('/learning/studio/whiteboards', { ...draft, fingerprint: preview.fingerprint, requestKey: crypto.randomUUID() }, actor.token);
  26  |   const board = await call('/qa/whiteboard-media', { boardId: saved.id }, actor.token);
  27  |   await page.route('**/api/learning/studio/overview?*', async route => {
> 28  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
      |                                  ^ Error: "route.fetch: Test ended.
  29  |     const payload = await response.json(); payload.data.narrationAvailable = true;
  30  |     payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [
  31  |       { id: 'fixture-a', label: '合成音轨 A' }, { id: 'fixture-delay', label: '受控延迟音轨' }, { id: 'fixture-fail', label: '受控失败音轨' },
  32  |     ] }; await route.fulfill({ response, json: payload });
  33  |   });
  34  |   await page.addInitScript(({ endedBoundary }) => {
  35  |     const NativeAudio = window.Audio; (window as any).__whiteboardAudio = [];
  36  |     const pending = new Map<number, FrameRequestCallback>();
  37  |     (window as any).__whiteboardStarts = []; (window as any).__whiteboardBoundaryTicks = 0;
  38  |     if (endedBoundary) {
  39  |       const raf = requestAnimationFrame.bind(window), cancel = cancelAnimationFrame.bind(window);
  40  |       window.requestAnimationFrame = callback => { const id = raf(time => { pending.delete(id); callback(time); }); pending.set(id, callback); return id; };
  41  |       window.cancelAnimationFrame = id => { pending.delete(id); cancel(id); };
  42  |     }
  43  |     (window as any).Audio = function (src?: string) {
  44  |       const audio = new NativeAudio(src), index = (window as any).__whiteboardAudio.length; (window as any).__whiteboardAudio.push(audio);
  45  |       if (endedBoundary) {
  46  |         let onEnded: ((this: HTMLAudioElement, event: Event) => unknown) | null = null;
  47  |         Object.defineProperty(audio, 'onended', { configurable: true, get: () => onEnded, set: value => { onEnded = value; } });
  48  |         audio.addEventListener('playing', () => (window as any).__whiteboardStarts.push({ index, currentTime: audio.currentTime, duration: audio.duration }));
  49  |         audio.addEventListener('ended', event => {
  50  |           const queued = [...pending.values()], handler = onEnded; handler?.call(audio, event);
  51  |           // Force an already-queued old progress frame at the ended/React cleanup boundary.
  52  |           if (index === 0 && handler) { (window as any).__whiteboardBoundaryTicks += queued.length; queued.forEach(callback => callback(performance.now())); }
  53  |         });
  54  |       }
  55  |       return audio;
  56  |     };
  57  |   }, { endedBoundary });
  58  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  59  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  60  |   const href = '/studio?' + new URLSearchParams({ student: studentId, subject: 'math', whiteboard: board.id });
  61  |   await page.goto(href); await expect(page.locator('.wb-current-sentence')).toContainText('先统一单位');
  62  |   return { actor, board, studentId, href, call, current: page.locator('.wb-current-sentence') };
  63  | }
  64  | 
  65  | test('complete sentence, complete notes, paused text reading and explicit sentence navigation', async ({ page }) => {
  66  |   const f = await fixture(page); await page.getByLabel('阅读方式').selectOption('text');
  67  |   await expect(f.current).not.toContainText('最后验证'); await expect(page.locator('.wb-reading-notes ol li')).toHaveCount(4);
  68  |   await expect(page.getByLabel('完整讲稿与要点')).toContainText('完整正文末行');
  69  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  70  |   await expect.poll(() => page.getByRole('slider').inputValue()).not.toBe('0');
  71  |   await page.getByRole('button', { name: '暂停', exact: true }).click(); const at = await page.getByRole('slider').inputValue();
  72  |   await page.waitForTimeout(250); expect(await page.getByRole('slider').inputValue()).toBe(at);
  73  |   await page.getByRole('button', { name: '下一句' }).click(); await expect(f.current).toContainText('再合并份数');
  74  |   await expect(page.locator('.wb-reading-notes [aria-current=step]')).toHaveText('[whiteboard-fixture] 再合并份数。');
  75  |   await page.getByRole('button', { name: '上一句' }).click(); await expect(f.current).toContainText('先统一单位');
  76  |   await page.getByRole('button', { name: '关闭白板' }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toHaveCount(0);
  77  | });
  78  | 
  79  | test('real WAV ended drives cloud playback, pause retains audio time and late ended cannot move a new sentence', async ({ page }) => {
  80  |   const f = await fixture(page); await page.getByRole('button', { name: '播放', exact: true }).click();
  81  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(.15);
  82  |   await expect(f.current).toContainText('先统一单位'); // Original nominal scene duration is only 10ms.
  83  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  84  |   const before = await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime);
  85  |   await page.waitForTimeout(250); expect(await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeCloseTo(before, 1);
  86  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  87  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeGreaterThan(before);
  88  |   await expect(f.current).toContainText('再合并份数', { timeout: 5000 });
  89  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  90  |   await page.evaluate(() => (window as any).__whiteboardAudio[0].dispatchEvent(new Event('ended')));
  91  |   await expect(f.current).toContainText('再合并份数');
  92  |   await page.getByRole('button', { name: '关闭白板' }).click();
  93  |   expect(await page.evaluate(() => (window as any).__whiteboardAudio.every((audio: HTMLAudioElement) => audio.paused && !audio.getAttribute('src')))).toBe(true);
  94  | });
  95  | 
  96  | test('ended boundary: a queued previous audio frame cannot seek the next actual WAV to its end', async ({ page }) => {
  97  |   const f = await fixture(page, true); await page.getByRole('button', { name: '播放', exact: true }).click();
  98  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardStarts.some((row: any) => row.index === 1))).toBe(true);
  99  |   const starts = await page.evaluate(() => (window as any).__whiteboardStarts as Array<{ index: number; currentTime: number; duration: number }>);
  100 |   expect(starts.find(row => row.index === 1)!.currentTime).toBeLessThan(.15);
  101 |   expect(await page.evaluate(() => (window as any).__whiteboardBoundaryTicks)).toBeGreaterThan(0);
  102 |   await page.getByRole('button', { name: '暂停', exact: true }).click(); await expect(f.current).toContainText('再合并份数');
  103 |   await page.evaluate(() => (window as any).__whiteboardAudio[0].dispatchEvent(new Event('ended'))); await expect(f.current).toContainText('再合并份数');
  104 | });
  105 | 
  106 | test('continuity: adjacent actual WAV prepares during the current sentence and transfers once at its beginning', async ({ page }) => {
  107 |   const timing = await installNarrationTiming(page), f = await fixture(page);
  108 |   try {
  109 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  110 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'playing'), { timeout: 10000 }).toBe(true);
  111 |     await page.getByRole('button', { name: '暂停', exact: true }).click();
  112 |     const result = await timing.save('adjacent-transfer'), firstEnd = result.audio.find(row => row.index === 0 && row.event === 'ended')!;
  113 |     const prepared = result.audio.find(row => row.index === 1 && row.event === 'loadedmetadata')!, next = result.audio.find(row => row.index === 1 && row.event === 'playing')!;
  114 |     expect(result.requests[1].startedAt).toBeLessThan(firstEnd.at - 100);
  115 |     expect(prepared.at).toBeLessThan(firstEnd.at);
  116 |     expect(next.at - firstEnd.at).toBeLessThan(result.delayMs * .75);
  117 |     expect(next.currentTime).toBeLessThan(.15);
  118 |     expect(result.requests.filter(row => row.unitId === result.requests[1].unitId)).toHaveLength(1);
  119 |     expect(result.audio.filter(row => row.index === 1 && row.event === 'playing')).toHaveLength(1);
  120 |     await expect(f.current).toContainText('再合并份数');
  121 |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  122 | });
  123 | 
  124 | test('continuity: three complete actual WAVs remain ordered through a live speed change without duplicate preparation', async ({ page }) => {
  125 |   const timing = await installNarrationTiming(page, 300), f = await fixture(page);
  126 |   try {
  127 |     await page.getByRole('button', { name: '播放', exact: true }).click();
  128 |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'loadedmetadata')).toBe(true);
```