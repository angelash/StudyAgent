# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: product-smoke.spec.ts >> an approved fraction teaching card renders a safe step-by-step visual
- Location: tests\e2e\product-smoke.spec.ts:129:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  34  |   await expect(page.getByRole('heading', { name: '继续孩子的学习旅程。' })).toBeVisible();
  35  |   await page.getByRole('button', { name: '首次使用，创建家长账号' }).tap();
  36  |   await expect(page.getByRole('heading', { name: '从一份学习档案开始。' })).toBeVisible();
  37  |   const principal = page.getByLabel('登录账号');
  38  |   await principal.focus();
  39  |   await page.keyboard.type('touch-keyboard@local.test');
  40  |   await page.keyboard.press('Tab');
  41  |   await page.keyboard.type('Touch-keyboard-only-20261021');
  42  |   await expect(principal).toHaveValue('touch-keyboard@local.test');
  43  |   await expect(page.getByLabel('密码')).toHaveValue('Touch-keyboard-only-20261021');
  44  |   await expect(page.getByRole('button', { name: '创建家长账号 →' })).toBeEnabled();
  45  |   await context.close();
  46  | });
  47  | 
  48  | test('a parent can create a learning profile and complete an evidence-limited assessment', async ({ page }) => {
  49  |   test.setTimeout(120_000);
  50  |   let analysisStatusRequests = 0;
  51  |   page.on('request', request => { if (request.url().includes('/analysis-status')) analysisStatusRequests += 1; });
  52  |   const suffix = `${Date.now()}${Math.floor(Math.random() * 10_000)}`;
  53  |   const principal = `browser-${suffix}@local.test`;
  54  |   const credential = `Browser-only-${suffix}`;
  55  |   const registration = await fetch(`${apiUrl}/api/auth/register`, {
  56  |     method: 'POST',
  57  |     headers: { 'content-type': 'application/json' },
  58  |     body: JSON.stringify({ principal, credential }),
  59  |   });
  60  |   expect(registration.status, 'synthetic parent registration').toBe(201);
  61  | 
  62  |   await page.goto('/parent/login');
  63  |   await page.getByLabel('登录账号').fill(principal);
  64  |   await page.getByLabel('密码').fill(credential);
  65  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click();
  66  |   await expect(page).toHaveURL(/\/learn(?:\?|$)/); await page.getByRole('link', { name: '建立学习档案 →', exact: true }).click();
  67  |   await expect(page.getByRole('heading', { name: '建立孩子的学习档案' })).toBeVisible();
  68  | 
  69  |   await page.getByLabel('孩子昵称').fill('浏览器验收');
  70  |   await page.getByLabel('当前年级').selectOption('2');
  71  |   await page.getByRole('button', { name: '保存档案 ↗' }).click();
  72  |   await expect(page.getByRole('heading', { name: /浏览器验收的每一步/ })).toBeVisible();
  73  |   await expect(page.getByText('当前 2 年级。')).toBeVisible();
  74  |   const memory = page.getByRole('region', { name: '证据化学习记忆' });
  75  |   await expect(memory).toBeVisible();
  76  |   await expect(memory.getByRole('heading', { name: '这次从哪里继续。' })).toBeVisible();
  77  |   await expect(memory.getByText('先确认当前学习进度', { exact: true })).toBeVisible();
  78  |   if (process.env.E2E_VISUAL_SNAPSHOT === '1') await page.screenshot({ path: 'data/qa/learning-memory-dashboard.png', fullPage: true });
  79  |   await page.getByRole('button', { name: '打开家长陪伴助教' }).click();
  80  |   const modelSelect = page.getByLabel('选择大模型');
  81  |   await expect(modelSelect).toHaveValue('deepseek-v4-flash');
  82  |   expect(await modelSelect.locator('option').count()).toBeGreaterThanOrEqual(23);
  83  |   await modelSelect.selectOption('claude-opus-5.5');
  84  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-model-selector.png', fullPage: true });
  85  |   await page.getByLabel('想一起看看什么').fill('请根据当前学习记录告诉我下一步。');
  86  |   await page.getByRole('button', { name: '一起想一想 →' }).click();
  87  |   const assistantTask = page.getByRole('region', { name: '提问任务' });
  88  |   await expect(assistantTask).toHaveAttribute('data-status', 'completed');
  89  |   await expect(assistantTask).toContainText('Claude Opus 5.5');
  90  |   await expect(page.locator('.assistant-message.from-assistant')).toContainText('独立新例子');
  91  |   await page.getByRole('button', { name: '收起家长陪伴助教' }).click();
  92  | 
  93  |   await page.getByRole('link', { name: '调整学习范围 ↗' }).click();
  94  |   await expect(page.getByRole('heading', { name: '先告诉我们，学到哪里了。' })).toBeVisible();
  95  |   const gradePoint = page.getByRole('checkbox', { name: /十进制位值换算/ });
  96  |   await expect(gradePoint).toBeVisible();
  97  |   await gradePoint.check();
  98  |   const previewButton = page.getByRole('button', { name: /确认进度，查看题组/ });
  99  |   await expect(previewButton).toBeEnabled();
  100 |   await previewButton.click();
  101 |   await expect(page.getByRole('region', { name: '本次评测范围与题组' })).toBeVisible();
  102 |   await page.getByRole('button', { name: /准备好了，开始这一组/ }).click();
  103 |   await expect(page.getByRole('progressbar', { name: '评测进度' })).toBeVisible();
  104 | 
  105 |   const reportHeading = page.getByRole('heading', { name: '从知识点看清下一步。' });
  106 |   for (let index = 0; index < 11; index += 1) {
  107 |     const dontKnow = page.getByRole('button', { name: '暂时不会' });
  108 |     await expect(dontKnow).toBeEnabled();
  109 |     await dontKnow.click();
  110 |   }
  111 |   await expect(reportHeading).toBeVisible();
  112 |   expect(analysisStatusRequests).toBeLessThanOrEqual(1);
  113 |   await expect(page.getByRole('heading', { name: '知识掌握与证据范围' })).toBeVisible();
  114 |   await expect(page.getByRole('heading', { name: '可能卡在哪里，以及怎样验证' })).toBeVisible();
  115 |   await page.getByRole('button', { name: /制定指导计划/ }).click();
  116 |   await expect(page.getByRole('heading', { name: /每天 .*分钟/ })).toBeVisible();
  117 |   await expect(page.getByRole('button', { name: '确认并开始计划' })).toBeVisible();
  118 |   await page.getByRole('button', { name: '确认并开始计划' }).click();
  119 |   await expect(page.getByRole('button', { name: '暂停计划' })).toBeVisible();
  120 |   await expect(page.getByText('D+1', { exact: true }).first()).toBeVisible();
  121 |   await expect(page.getByText('D+14', { exact: true }).first()).toBeVisible();
  122 |   await page.goto('/parent/dashboard');
  123 |   const refreshedMemory = page.getByRole('region', { name: '证据化学习记忆' });
  124 |   await expect(refreshedMemory.getByText(/指导计划正在执行/)).toBeVisible();
  125 |   await expect(refreshedMemory.getByText(/今天还有\d+个指导活动/)).toBeVisible();
  126 |   if (process.env.E2E_VISUAL_SNAPSHOT === '1') await page.screenshot({ path: 'data/qa/learning-memory-populated.png', fullPage: true });
  127 | });
  128 | 
  129 | test('an approved fraction teaching card renders a safe step-by-step visual', async ({ page }) => {
  130 |   test.setTimeout(120_000);
  131 |   const suffix = `${Date.now()}${Math.floor(Math.random() * 10_000)}`;
  132 |   const principal = `fraction-${suffix}@local.test`, credential = `Fraction-only-${suffix}`;
  133 |   expect((await fetch(`${apiUrl}/api/auth/register`, { method: 'POST', headers: { 'content-type': 'application/json' },
> 134 |     body: JSON.stringify({ principal, credential }) })).status).toBe(201);
      |                                                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  135 |   await page.goto('/parent/login');
  136 |   await page.getByLabel('登录账号').fill(principal);
  137 |   await page.getByLabel('密码').fill(credential);
  138 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click();
  139 |   await page.getByRole('link', { name: '建立学习档案 →', exact: true }).click();
  140 |   await expect(page.getByRole('heading', { name: '建立孩子的学习档案' })).toBeVisible();
  141 |   await page.getByLabel('孩子昵称').fill('分数图验收');
  142 |   await page.getByLabel('当前年级').selectOption('5');
  143 |   await page.getByRole('button', { name: '保存档案 ↗' }).click();
  144 |   await page.getByRole('link', { name: '调整学习范围 ↗' }).click();
  145 |   await expect(page.getByRole('heading', { name: '先告诉我们，学到哪里了。' })).toBeVisible();
  146 |   const fractionPoint = page.getByRole('checkbox', { name: /异分母分数加法/ }).first();
  147 |   await fractionPoint.check();
  148 |   await page.getByLabel('这次想怎样了解孩子').selectOption('micro');
  149 |   const microTarget = page.locator('.assessment-targets').getByRole('checkbox', { name: /异分母分数加法/ });
  150 |   await microTarget.check();
  151 |   await page.getByRole('checkbox', { name: /加入必要的前置基础核查/ }).uncheck();
  152 |   await page.getByRole('button', { name: /确认进度，查看题组/ }).click();
  153 |   await page.getByRole('button', { name: /准备好了，开始这一组/ }).click();
  154 |   await expect(page.getByRole('progressbar', { name: '评测进度' })).toBeVisible();
  155 |   const reportHeading = page.getByRole('heading', { name: '从知识点看清下一步。' });
  156 |   for (let index = 0; index < 3; index += 1) {
  157 |     const skip = page.getByRole('button', { name: '暂时不会' });
  158 |     await expect(skip).toBeEnabled();
  159 |     await skip.click();
  160 |   }
  161 |   await expect(reportHeading).toBeVisible();
  162 |   await page.getByRole('button', { name: /制定指导计划/ }).click();
  163 |   await expect(page.getByRole('button', { name: '确认并开始计划' })).toBeVisible();
  164 |   await page.getByText('先看讲解和示例', { exact: true }).first().click();
  165 |   await expect(page.getByRole('heading', { name: '先统一切法，再合并份数' })).toBeVisible();
  166 |   if (process.env.E2E_VISUAL_SNAPSHOT === '1') await page.screenshot({ path: 'data/qa/teaching-visual.png', fullPage: true });
  167 | });
  168 | 
  169 | test('an administrator can reach the curriculum review workbench', async ({ page }) => {
  170 |   await page.goto('/parent/login');
  171 |   await page.getByLabel('登录账号').fill(process.env.E2E_ADMIN_PRINCIPAL ?? 'browser-admin');
  172 |   await page.getByLabel('密码').fill(process.env.E2E_ADMIN_PASSWORD ?? 'Browser-admin-only-20261021');
  173 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click();
  174 |   await expect(page).toHaveURL(/\/admin\/analytics$/);
  175 | 
  176 |   await page.goto('/admin/curriculum');
  177 |   await expect(page.getByRole('heading', { name: '每一个点，都能追到依据。' })).toBeVisible();
  178 |   await expect(page.getByRole('navigation', { name: '教研导航' })).toBeVisible();
  179 |   await expect(page.getByRole('heading', { name: '教材课时与知识映射' })).toBeVisible();
  180 |   await expect(page.getByRole('link', { name: '运营观察' })).toBeVisible();
  181 |   await expect(page.getByText(/来源总览：250 条有同版原卷/)).toBeVisible();
  182 |   await expect(page.getByRole('button', { name: /无同版原卷/ })).toBeVisible();
  183 |   await page.getByLabel('选择目录').selectOption('archive-book:44deea6d4015a5183e175acc');
  184 |   await expect(page.getByText(/教材目录与现有原卷的版本年份不一致/)).toBeVisible();
  185 |   await page.getByLabel('选择目录').selectOption('public-book:33c8d495-9862-4e19-aab9-61d2af08608a');
  186 |   const installedSource = page.getByRole('region', { name: '教材内审原页' });
  187 |   const missingAssets = page.getByText(/同版来源已登记，但本地原卷未安装/);
  188 |   await expect(installedSource.or(missingAssets)).toBeVisible();
  189 | });
  190 | 
```