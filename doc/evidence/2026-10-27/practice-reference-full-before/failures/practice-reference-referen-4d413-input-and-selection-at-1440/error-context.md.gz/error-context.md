# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: practice-reference.spec.ts >> reference practice: multiple choice and local assistant preserve complete input and selection at 1440
- Location: tests\e2e\practice-reference.spec.ts:45:49

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { browserEvidence } from './evidence';
  3  | import { writeFileSync } from 'node:fs';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`, evidence = browserEvidence('practice-reference');
  5  | async function open(page: Page, width: number) {
  6  |   await page.setViewportSize({ width, height: width >= 1000 ? 800 : width === 390 ? 844 : 900 });
  7  |   const nonce = crypto.randomUUID(), principal = 'practice-reference-' + nonce + '@local.test', credential = 'Practice-QA-' + nonce;
  8  |   const response = await fetch(api + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
> 9  |   expect(response.status).toBe(201);
     |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  10 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  11 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  13 |   await page.goto('/studio/classroom?lesson=soc-1-1-1&tab=practice');
  14 |   await expect(page.getByRole('button', { name: 'Check →' })).toBeVisible();
  15 | }
  16 | async function inside(page: Page) {
  17 |   const boxes = await page.locator('.cl-practice-top, .cl-practice-card, .cl-practice-options label, .cl-practice-actions button:visible').evaluateAll(nodes => nodes.map(node => {
  18 |     const box = node.getBoundingClientRect(); return { name: node.className, x: box.x, right: box.right, width: box.width };
  19 |   }));
  20 |   for (const box of boxes) { expect(box.width, box.name).toBeGreaterThan(0); expect(box.x, box.name).toBeGreaterThanOrEqual(-1); expect(box.right, box.name).toBeLessThanOrEqual(page.viewportSize()!.width + 1); }
  21 | }
  22 | test('reference practice: explicit frozen media, three-column answer, readable full feedback and no unrelated next-question image', async ({ page }) => {
  23 |   await open(page, 1280);
  24 |   const fonts = await page.evaluate(async () => {
  25 |     await document.fonts.load('15px "Satoshi-Medium"', 'Practice'); await document.fonts.load('15px MiSans', '社会学想象力');
  26 |     return [...document.fonts].filter(face=>face.status==='loaded').map(face=>face.family.replaceAll('"','').replaceAll("'",''));
  27 |   });
  28 |   expect(fonts).toContain('Satoshi-Medium'); expect(fonts).toContain('MiSans');
  29 |   await expect(page.locator('.cl-practice-options label').first().locator('svg')).toHaveCSS('fill', 'rgb(195, 71, 71)');
  30 |   await expect(page.locator('.cl-practice-prompt .cl-lesson-image img')).toHaveAttribute('src', '/classroom/venn-d8b3f1.webp');
  31 |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  32 |   await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');
  33 |   const prompt = await page.locator('.cl-practice-prompt').boundingBox(), options = await page.locator('.cl-practice-options').boundingBox(), verdict = await page.locator('.cl-practice-support').boundingBox();
  34 |   expect(prompt!.x + prompt!.width).toBeLessThan(options!.x); expect(options!.x + options!.width).toBeLessThan(verdict!.x);
  35 |   await page.screenshot({ path: evidence + '/single-answered-1280.png', fullPage: true });
  36 |   writeFileSync(evidence + '/actual-desktop-layout.json', JSON.stringify({ viewport: page.viewportSize(), dpr: await page.evaluate(()=>devicePixelRatio),
  37 |     frame: await page.locator('.cl-practice-card').boundingBox(), prompt, options, verdict, decodedFontFamilies: fonts,
  38 |     scope: 'Actual local DOM layout and decoded local fonts only; original DPR not measured and question/image content differs.' }, null, 2) + '\n');
  39 |   await page.getByText('逐项对照选择与解释', { exact: true }).click(); await expect(page.locator('.cl-option-feedback')).toHaveCount(4);
  40 |   await inside(page); await page.screenshot({ path: evidence + '/single-answer-details-1280.png', fullPage: true });
  41 |   await page.getByRole('button', { name: '第2题', exact: true }).click(); await expect(page.locator('.cl-practice-prompt .cl-lesson-image')).toHaveCount(0);
  42 |   await page.getByRole('button', { name: '第3题', exact: true }).click(); await expect(page.locator('.cl-practice-prompt .cl-lesson-image img')).toHaveAttribute('src', '/classroom/agency-river-c7a9e2.webp');
  43 |   await page.reload(); await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确'); await expect(page.locator('.cl-practice-options input').first()).toBeDisabled();
  44 | });
  45 | for (const width of [390, 768, 1280, 1440]) test(`reference practice: multiple choice and local assistant preserve complete input and selection at ${width}`, async ({ page }) => {
  46 |   await open(page, width); await page.getByRole('button', { name: '第6题', exact: true }).click();
  47 |   await expect(page.locator('.cl-practice-prompt .cl-lesson-image')).toHaveCount(0);
  48 |   await expect(page.locator('.cl-practice-options input[type=checkbox]')).toHaveCount(5);
  49 |   const input = page.locator('.cl-practice-options input').first(), frameBefore = await page.locator('.cl-practice-card').boundingBox(); await input.check();
  50 |   await expect(page.getByRole('button', { name: 'Check →' })).toBeEnabled();
  51 |   expect((await page.locator('.cl-practice-card').boundingBox())!.y).toBe(frameBefore!.y);
  52 |   const cards = page.locator('.cl-practice-options label');
  53 |   if (width > 720) { const first = await cards.first().boundingBox(), last = await cards.last().boundingBox(); expect(last!.width).toBeGreaterThan(first!.width * 1.9); }
  54 |   await inside(page); await page.screenshot({ path: evidence + '/multiple-selected-' + width + '.png', fullPage: true });
  55 |   const trigger = page.getByRole('button', { name: '☏ Assistant', exact: true }); await trigger.click();
  56 |   const field = page.getByRole('textbox', { name: '向课堂老师提问' }); await field.fill('请保留这段完整的未发送文字，并帮我区分观察和推断。');
  57 |   expect((await field.boundingBox())!.height).toBeGreaterThanOrEqual(70);
  58 |   if (width <= 1000) {
  59 |     const dialog = page.getByRole('dialog', { name: '练习助教' }); await expect(dialog).toBeVisible();
  60 |     await page.keyboard.press('Tab'); expect(await dialog.evaluate(node => node.contains(document.activeElement))).toBe(true);
  61 |     await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0);
  62 |   } else { await page.getByRole('button', { name: '隐藏对话面板' }).click(); }
  63 |   await expect(trigger).toBeFocused(); await expect(input).toBeChecked();
  64 |   await trigger.click(); await expect(field).toHaveValue('请保留这段完整的未发送文字，并帮我区分观察和推断。');
  65 |   await page.screenshot({ path: evidence + '/assistant-' + width + '.png', fullPage: true });
  66 |   await page.getByRole('button', { name: '隐藏对话面板' }).click(); await expect(trigger).toBeFocused(); await expect(input).toBeChecked();
  67 | });
  68 | 
```