const fs = require('node:fs'), path = require('node:path'); require('reflect-metadata');
const destination = path.join(__dirname, 'model-opus5-schema-mode.json');
if (fs.existsSync(destination)) throw Error('Original schema-mode diagnostic already exists');
process.env.XIAOJIU_CHAT_TIMEOUT_MS = '60000';
const load = name => require(path.resolve(__dirname, '../../apps/api/dist/apps/api/src/modules/ai', name + '.js'));
const service = new (load('xiaojiu-chat.service').XiaojiuChatService)(new (load('xiaojiu-models.service').XiaojiuModelsService)());
const originalRun = service.run;
service.run = function(args, ...rest) { const copy = [...args], index = copy.indexOf('--output-schema');
  if (index < 0) throw Error('Expected original strict-schema flag'); copy.splice(index, 2); return originalRun.call(this, copy, ...rest); };
const schema = { type: 'object', properties: { startToken: { type: 'string' }, endToken: { type: 'string' },
  sum: { type: 'integer' }, evidenceIds: { type: 'array', items: { type: 'string' } } },
  required: ['startToken', 'endToken', 'sum', 'evidenceIds'], additionalProperties: false };
(async () => { const started = Date.now(), attempts = []; let passed = false;
  try { await service.structured({ modelId: 'claude-opus-5', system: '这是匿名文字通路检查。只依据学习证据返回完整JSON，不调用工具。',
    context: JSON.stringify({ startToken: 'BEGIN_ANON_OPUS', evidence: { id: 'anonymous-opus', left: 17, right: 25 }, endToken: 'END_ANON_OPUS' }),
    history: [], message: '复制startToken和endToken；sum为left与right之和；evidenceIds仅包含这份证据的id。' }, schema, value => {
      if (value?.sum !== 42 || value.startToken !== 'BEGIN_ANON_OPUS' || value.endToken !== 'END_ANON_OPUS' ||
        JSON.stringify(value.evidenceIds) !== '["anonymous-opus"]') throw Error('Semantic validation failed'); return value;
    }, true, event => attempts.push(event)); passed = true;
  } catch { /* No raw provider errors or responses retained. */ }
  const result = { passed, elapsedMs: Date.now() - started, attempts,
    scope: 'Controlled experiment only: same original model, prompt/schema and application validator, but CLI --output-schema omitted in this diagnostic process. Does not prove the unchanged application supports this mode.' };
  fs.writeFileSync(destination, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' }); console.log(JSON.stringify(result));
})().catch(() => { console.error('Anonymous schema-mode diagnostic failed'); process.exitCode = 1; });
