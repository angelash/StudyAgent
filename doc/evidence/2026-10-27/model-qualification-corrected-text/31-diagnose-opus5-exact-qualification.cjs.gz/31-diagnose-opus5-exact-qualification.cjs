const fs = require('node:fs'), path = require('node:path'), actualFetch = global.fetch;
const observations = [], destination = path.join(__dirname, 'model-opus5-exact-protocol.json');
if (fs.existsSync(destination)) throw Error('Original protocol observation already exists');
global.fetch = async (url, options) => {
  const row = { at: new Date().toISOString(), model: JSON.parse(options.body).model, eventTypes: [] }; observations.push(row);
  try {
    const response = await actualFetch(url, options); row.httpStatus = response.status;
    void response.clone().text().then(raw => {
      for (const line of raw.split(/\r?\n/)) if (line.startsWith('data:')) {
        try { const value = JSON.parse(line.slice(5)); if (typeof value.type === 'string' && !row.eventTypes.includes(value.type)) row.eventTypes.push(value.type); }
        catch { /* No provider content is retained. */ }
      }
      row.streamEnded = true;
    }).catch(() => { row.streamEnded = false; });
    return response;
  } catch (error) { row.connectionFailed = true; throw error; }
};
process.once('beforeExit', () => fs.writeFileSync(destination, JSON.stringify({
  scope: 'One explicit old Opus model with the exact anonymous full-qualification challenge; only protocol event names retained.', observations }, null, 2) + '\n', { flag: 'wx' }));
process.argv = [process.execPath, path.resolve(__dirname, '../../scripts/qa/qualify-xiaojiu-models.cjs'),
  '--output', 'data/qa/model-opus5-exact-10b0ada', '--model', 'claude-opus-5'];
require('../../scripts/qa/qualify-xiaojiu-models.cjs');
