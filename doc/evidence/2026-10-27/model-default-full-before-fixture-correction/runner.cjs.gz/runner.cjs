const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{spawn,execFileSync}=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'../..'),head='3a933875b3b6ee26a4b6cdc6fdd6cf354a848441';
const output=path.join(__dirname,'model134-full-3a93387');if(fs.existsSync(output))throw Error('Preserve prior full runs');fs.mkdirSync(output);
const sha=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
assert.equal(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),head);
assert.equal(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim(),'');
const files=execFileSync('git',['ls-files','apps','packages','scripts','tests','.github','resources/ai'],{cwd:root,encoding:'utf8'}).trim().split(/\r?\n/);
const inputs=Object.fromEntries(files.filter(file=>fs.existsSync(path.join(root,file))).map(file=>[file,sha(path.join(root,file))]));
const previous=JSON.parse(fs.readFileSync(path.join(__dirname,'model-check-ui-source-16cea68.json'),'utf8')).sourceSha256;
for(const[file,digest]of Object.entries(previous))if(file!=='scripts/qa/run-source-course-browser.cjs')assert.equal(sha(path.join(root,file)),digest,file);
const receipt={version:1,head,startedAt:new Date().toISOString(),status:'running',passed:false,expectedBrowserCases:368,
  scope:'Full isolated API and synthetic browser regression. Compiled API and QA Web unchanged from controlled 16cea68 build; original evidence preserved. No production or live supplier calls.',jobs:{}};
fs.writeFileSync(path.join(output,'source.json'),JSON.stringify({head,sha256:inputs},null,2)+'\n',{flag:'wx'});
const save=()=>fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
async function run(name,args,cwd,env){const fd=fs.openSync(path.join(output,name+'.log'),'wx');receipt.jobs[name]={status:'running',startedAt:new Date().toISOString()};save();
  try{const code=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{cwd,env,windowsHide:true,stdio:['ignore',fd,fd]});receipt.jobs[name].pid=child.pid;save();child.once('error',reject);child.once('exit',code=>resolve(code??1));});
    Object.assign(receipt.jobs[name],{status:code===0?'passed':'failed',exitCode:code,completedAt:new Date().toISOString()});save();assert.equal(code,0,name+' failed; preserve original report');
  }finally{fs.closeSync(fd);}}
(async()=>{
  const env={...process.env,CI:'',NEXT_TELEMETRY_DISABLED:'1',E2E_API_PORT:'4177',E2E_WEB_PORT:'3177'};
  const results=await Promise.allSettled([
    run('api',['--env-file=../../.env','../../node_modules/vitest/vitest.mjs','run','--reporter=json','--outputFile='+path.join(output,'api.json')],path.join(root,'apps/api'),env),
    run('browser',['scripts/qa/run-source-course-browser.cjs','--full','--skip-build','--result-file','data/qa/model134-full-3a93387/browser.json'],root,env)
  ]);
  for(const result of results)if(result.status==='rejected')throw result.reason;
  for(const[file,digest]of Object.entries(inputs))assert.equal(sha(path.join(root,file)),digest,file);
  const api=JSON.parse(fs.readFileSync(path.join(output,'api.json'),'utf8'));assert(api.success);assert.equal(api.numFailedTests,0);
  receipt.api={passed:api.numPassedTests,pending:api.numPendingTests,failed:api.numFailedTests,reportSha256:sha(path.join(output,'api.json'))};
  const browser=JSON.parse(fs.readFileSync(path.join(output,'browser.json'),'utf8')),cases=[];
  const walk=s=>{for(const spec of s.specs||[])cases.push(...spec.tests);for(const child of s.suites||[])walk(child);};browser.suites.forEach(walk);
  assert.deepEqual([browser.stats.expected,browser.stats.unexpected,browser.stats.flaky,browser.stats.skipped,browser.errors.length,cases.length],[368,0,0,0,0,368]);
  assert(cases.every(test=>test.results.length===1&&test.results[0].status==='passed'));
  receipt.browser={stats:browser.stats,originalAttempts:cases.length,reportSha256:sha(path.join(output,'browser.json'))};receipt.status='complete';receipt.passed=true;
})().catch(error=>{receipt.status='failed';receipt.failure=error.message;process.exitCode=1;}).finally(()=>{receipt.completedAt=new Date().toISOString();save();console.log(JSON.stringify({status:receipt.status,passed:receipt.passed,jobs:receipt.jobs}));});
