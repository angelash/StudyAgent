const fs = require('node:fs'), path = require('node:path');
const root = path.resolve(__dirname, '../..'), destination = path.join(__dirname, 'model-gpt-route-diagnostic-01.json');
if (fs.existsSync(destination)) throw Error('Original diagnostic already exists');
const observations = [], taps = [], actualFetch = global.fetch;
global.fetch = async (url, options) => {
  const request = JSON.parse(options.body), observation = { startedAt: new Date().toISOString(), model: request.model,
    reasoning: request.reasoning ?? null, toolCount: request.tools?.length, stream: request.stream,
    eventTypes: [], itemTypes: [], contentTypes: [] };
  observations.push(observation);
  const response = await actualFetch(url, options); observation.httpStatus = response.status;
  const clone = response.clone();
  taps.push((async () => {
    const reader = clone.body.getReader(), decoder = new TextDecoder(); let pending = '';
    try { for (;;) { const result = await reader.read(); if (result.done) break;
      pending += decoder.decode(result.value, { stream: true }); const lines = pending.split('\n'); pending = lines.pop();
      for (const line of lines) if (line.startsWith('data:')) {
        try { const value = JSON.parse(line.slice(5)); if (typeof value.type === 'string' && !observation.eventTypes.includes(value.type)) observation.eventTypes.push(value.type);
          if (value.item?.type && !observation.itemTypes.includes(value.item.type)) observation.itemTypes.push(value.item.type);
          if (value.part?.type && !observation.contentTypes.includes(value.part.type)) observation.contentTypes.push(value.part.type);
        } catch { /* Only protocol type names are retained. */ }
      }
    } observation.streamEnded = true;
    } catch { observation.streamEnded = false; }
  })());
  return response;
};
require('reflect-metadata');
const load = module => require(path.join(root, 'apps/api/dist/apps/api/src/modules/ai', module + '.js'));
process.env.XIAOJIU_CHAT_TIMEOUT_MS = '60000';
const service = new (load('xiaojiu-chat.service').XiaojiuChatService)(new (load('xiaojiu-models.service').XiaojiuModelsService)());
const started = Date.now();
(async () => {
  let succeeded = false; const attempts = [];
  try { await service.structured({ modelId: 'gpt-6.1-sol', system: '只返回匿名通路检查JSON。', context: '17+25=42', history: [], message: '返回sum为42。' },
    { type: 'object', properties: { sum: { type: 'integer' } }, required: ['sum'], additionalProperties: false },
    value => { if (value?.sum !== 42) throw Error('incorrect'); return value; }, true, event => attempts.push(event)); succeeded = true;
  } catch { /* Never retain raw provider errors. */ }
  await Promise.allSettled(taps);
  fs.writeFileSync(destination, JSON.stringify({ at: new Date().toISOString(), succeeded, elapsedMs: Date.now() - started,
    scope: 'One anonymous actual-service diagnostic. Original provider responses are unchanged; only protocol type names and non-sensitive request settings are retained.', attempts, observations }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ succeeded, elapsedMs: Date.now() - started, observations }));
})().catch(() => { console.error('Diagnostic failed without retaining provider content'); process.exitCode = 1; });
