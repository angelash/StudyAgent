# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: paper-practice.spec.ts >> paper review: a lost organization receipt is recovered after three reloads without duplicating history or clearing later reflection
- Location: tests\e2e\paper-practice.spec.ts:318:5

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('region', { name: '整理原操作恢复' }).getByRole('button', { name: '核对或重试整理原操作' })
Expected: enabled
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" getByRole('region', { name: '整理原操作恢复' }).getByRole('button', { name: '核对或重试整理原操作' }) with timeout 15000ms
  - waiting for getByRole('region', { name: '整理原操作恢复' }).getByRole('button', { name: '核对或重试整理原操作' })

```

```yaml
- main:
  - link "学习观察室":
    - /url: /
  - navigation "主要导航":
    - link "学习首页":
      - /url: /learn?subject=math
    - link "学习工作台":
      - /url: /studio?subject=math
    - link "家长空间":
      - /url: /parent/dashboard?subject=math
    - link "知识诊断":
      - /url: /student/assessment?subject=math
    - link "今日学习":
      - /url: /student/today?subject=math
    - link "题卷资料":
      - /url: /library?subject=math
  - link "资料管理":
    - /url: /parent/data
  - button "退出"
  - link "← 返回原筛选与复习清单":
    - /url: /library/practice/review?
  - paragraph: 原练习中的首答与订正保持，下面继续整理这道题。
  - link "← 我的原卷练习":
    - /url: /library/practice
  - link "待复习与反思 ↗":
    - /url: /library/practice/review
  - strong: 原卷练习
  - status: 原记录已读取
  - paragraph: 本人练习记录
  - text: 0 / 2
  - paragraph: 已提交记录
  - text: "2"
  - paragraph: 未答
  - text: "0"
  - paragraph: 自评待订正
  - text: "0"
  - paragraph: 缺题或来源不可用
  - paragraph: 这里保留练习与自我核对，不计算未经审核的总分，也不自动改变知识掌握度。
  - complementary "原卷题位目录":
    - text: 查看范围
    - combobox "查看范围":
      - option "全部题位" [selected]
      - option "未答"
      - option "待订正"
      - option "暂时不会"
      - option "已跳过"
    - button "匿名原卷 23 · 完整 第 1 题 尚未作答" [pressed]:
      - text: 匿名原卷 23 · 完整
      - strong: 第 1 题
      - text: 尚未作答
    - button "匿名原卷 23 · 完整 第 2 题 尚未作答":
      - text: 匿名原卷 23 · 完整
      - strong: 第 2 题
      - text: 尚未作答
  - region "当前原题与首次回答":
    - text: 匿名原卷 23 · 完整
    - heading "第 1 题" [level=1]
    - link "回到原卷题位 ↗":
      - /url: /library?paper=qa%3Apaper%3A23%3Acomplete&position=1
    - paragraph:
      - text: 合成原题：
      - math: 3 + 2 = ?
    - table:
      - rowgroup:
        - row "第一组 第二组":
          - columnheader "第一组"
          - columnheader "第二组"
        - row "3 2":
          - cell "3"
          - cell "2"
    - text: A
    - paragraph: "4"
    - text: B
    - paragraph: "5"
    - text: 先写下自己的回答
    - textbox "先写下自己的回答":
      - /placeholder: 写下你的选择、过程或解释。先保留自己的思考，再核对参考。
    - button "提交本题回答" [disabled]
    - button "保存草稿" [disabled]
    - button "暂时不会"
    - button "先跳过"
    - region "原卷复习与反思":
      - text: 把问题说具体，再安排下一步
      - heading "这次，卡在哪里。" [level=2]
      - paragraph: 记录自己的判断与反思；能力原因仍需独立题目验证。
      - alert: 暂时无法连接学习服务，请检查网络后重试。已保存的数据会保留。
      - heading "原操作还在，可以核对后继续。" [level=3]
      - button "下载整理原操作保护文件"
      - button "核对或重试整理原操作"
      - button "保留冲突文件，读取最新版本"
      - group "本人整理":
        - text: 本人整理 标签，用逗号分隔
        - textbox "标签，用逗号分隔" [disabled]
        - text: 具体错误步骤
        - textbox "具体错误步骤" [disabled]:
          - /placeholder: 例如：读到了数量，却漏掉了单位不同这个条件。
        - text: 我的反思
        - textbox "我的反思" [disabled]:
          - /placeholder: 当时为什么这样想，下次准备怎样检查？
          - text: 离线丢回执仍保留同一次反思。
        - text: 计划回看日期
        - textbox "计划回看日期" [disabled]
        - checkbox "收藏这道题" [disabled]
        - text: 收藏这道题
        - checkbox "从待复习中归档" [disabled]
        - text: 从待复习中归档
      - button "保存反思与安排" [disabled]
      - button "我已实际回看" [disabled]
      - button "下载反思草稿保护文件"
      - paragraph: 尚未记录实际回看。 请先保存反思，再记录回看完成。
      - group: 完整整理历史 · 0 次
      - group: 恢复本机反思或原操作
    - button "上一题位" [disabled]
    - button "下一题位 ↗"
  - button "保存位置并暂停"
  - button "结束并复盘"
  - button "下载本机草稿保护文件"
  - button "查看其他本机草稿与原操作"
  - text: 从本次练习保护文件恢复
  - button "从本次练习保护文件恢复"
- alert
```

# Test source

```ts
  222 |     await page.getByRole('button', { name: '下一题位 ↗', exact: true }).click(); await expect.poll(() => arrived).toBe(true); await page.goBack();
  223 |     await expect(page.getByRole('heading', { name: '第 1 题', exact: true })).toBeVisible(); await expect(page.getByLabel('先写下自己的回答')).toHaveValue('前后退仍属于第一题');
  224 |     release(); await expect(page.getByRole('heading', { name: '第 2 题', exact: true })).toHaveCount(0); await page.goForward();
  225 |     await expect(page.getByRole('heading', { name: '第 2 题', exact: true })).toBeVisible(); await expect(page.getByLabel('先写下自己的回答')).toHaveValue('');
  226 |   } finally { release(); }
  227 | });
  228 | 
  229 | test('paper practice: metadata refreshes keep the same original PDF frame through submit and explicit reference reading', async ({ page }) => {
  230 |   const f = await fixture(page, 12), row = await f.begin(f.papers.pdf); await page.goto('/library/practice?session=' + row.id);
  231 |   const frame = page.locator('iframe[title="原始试卷 PDF"]'); await expect(frame).toBeVisible(); await frame.evaluate(node => node.setAttribute('data-original-instance', 'retained'));
  232 |   await page.getByLabel('先写下自己的回答').fill('保留原 PDF 阅读位置'); await page.getByRole('button', { name: '提交本题回答', exact: true }).click();
  233 |   await expect(page.getByRole('region', { name: '不可覆盖的首次回答' })).toBeVisible(); await expect(frame).toHaveAttribute('data-original-instance', 'retained');
  234 |   await page.getByRole('button', { name: '核对本题参考答案', exact: true }).click(); await expect(page.getByRole('region', { name: '本题原参考与自评' })).toBeVisible();
  235 |   await expect(frame).toHaveAttribute('data-original-instance', 'retained');
  236 | });
  237 | 
  238 | test('paper practice: recovery files from another account, session or item never replace the current private draft', async ({ page }) => {
  239 |   const f = await fixture(page, 13), row = await f.begin(); await page.goto('/library/practice?session=' + row.id); await page.getByLabel('先写下自己的回答').fill('这份私人草稿保持');
  240 |   const original = { format: 'paper-practice-draft-v1', ownerId: f.actor.user.id, sessionId: row.id, itemId: row.items[0].id, text: '错误范围不能写入', baseText: '' };
  241 |   for (const change of [{ ownerId: 'another-account' }, { sessionId: 'another-session' }, { itemId: row.items[1].id }]) {
  242 |     await page.getByLabel('从本次练习保护文件恢复').setInputFiles({ name: 'foreign.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify({ ...original, ...change })) });
  243 |     await expect(page.locator('.pp-shell').getByRole('alert')).toBeVisible(); await expect(page.getByLabel('先写下自己的回答')).toHaveValue('这份私人草稿保持');
  244 |     await expect(page.getByRole('region', { name: '本机与服务器草稿冲突' })).toHaveCount(0);
  245 |   }
  246 |   expect((await f.call('/library/practice/sessions/' + row.id)).version).toBe(1);
  247 | });
  248 | 
  249 | test('paper practice: a real learning-code student writes only their own record and loses the private workspace after grant revocation', async ({ page, context }) => {
  250 |   const f = await fixture(page, 14), child = (await f.call('/students', { nickname: '匿名练习孩子', grade: 3, preferredSessionMinutes: 10, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile.id;
  251 |   await f.call('/students/' + child + '/learning-access', { enabled: true, expectedVersion: 0, requestKey: randomUUID(), reason: '合成原卷练习权限核对' });
  252 |   const issued = await f.call('/students/' + child + '/learning-access/codes', { expectedVersion: 1, requestKey: randomUUID() });
  253 |   await context.clearCookies(); await page.goto('/student/login'); await page.getByLabel('一次性学习码').fill(issued.code); await page.getByRole('button', { name: '进入我的学习 →', exact: true }).click();
  254 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/); await page.goto('/library/practice?paper=' + encodeURIComponent(f.papers.complete));
  255 |   await expect(page.getByLabel('这次练习记录给谁')).toHaveValue(child); await page.getByRole('button', { name: '预览这次练习', exact: true }).click();
  256 |   await page.getByRole('button', { name: '确认范围，开始练习 ↗' }).click(); await page.getByLabel('先写下自己的回答').fill('孩子自己的原答');
  257 |   await page.getByRole('button', { name: '提交本题回答', exact: true }).click(); await expect(page.getByRole('region', { name: '不可覆盖的首次回答' })).toContainText('孩子自己的原答');
  258 |   const id = new URL(page.url()).searchParams.get('session')!, parentRead = await f.call('/library/practice/sessions/' + id); expect(parentRead.permissions.edit).toBe(false);
  259 |   await f.call('/students/' + child + '/learning-access', { enabled: false, expectedVersion: 1, requestKey: randomUUID(), reason: '合成练习实时撤权核对' });
  260 |   await page.getByRole('button', { name: '核对本题参考答案', exact: true }).click(); await expect(page.getByRole('region', { name: '当前原题与首次回答' })).toHaveCount(0);
  261 |   await expect(page.getByRole('heading', { name: '从原卷开始，留下自己的思考。', exact: true })).toBeVisible();
  262 | });
  263 | 
  264 | test('paper practice: an actual login logout and another family cannot reuse a private record or its visible answer', async ({ page, context }) => {
  265 |   const f = await fixture(page, 15), row = await f.begin(); await page.goto('/library/practice?session=' + row.id); await page.getByLabel('先写下自己的回答').fill('属于原家庭的私人回答');
  266 |   await page.getByRole('button', { name: '提交本题回答', exact: true }).click(); await expect(page.getByRole('region', { name: '不可覆盖的首次回答' })).toBeVisible();
  267 |   expect(await page.evaluate(async base => (await fetch(base + '/auth/logout', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status, api)).toBe(201);
  268 |   await page.getByRole('button', { name: '核对本题参考答案', exact: true }).click(); await expect(page.getByRole('region', { name: '当前原题与首次回答' })).toHaveCount(0);
  269 |   const principal = 'paper-other-' + randomUUID(), credential = 'Synthetic-other-family-20261026', other = await f.call('/auth/register', { principal, credential }, '');
  270 |   await f.call('/library/practice/sessions/' + row.id, undefined, other.token, 403); await context.clearCookies(); await page.goto('/parent/login');
  271 |   await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  272 |   await page.goto('/library/practice?session=' + row.id); await expect(page.locator('.pp-shell').getByRole('alert')).toBeVisible();
  273 |   await expect(page.getByText('属于原家庭的私人回答', { exact: true })).toHaveCount(0); await expect(page.getByLabel('先写下自己的回答')).toHaveCount(0);
  274 | });
  275 | 
  276 | test('paper practice: an expired original preview can be safely retained and previewed again without duplicating a started record', async ({ page }) => {
  277 |   const f = await fixture(page, 16); await page.goto('/library/practice?paper=' + encodeURIComponent(f.papers.complete));
  278 |   await page.getByRole('button', { name: '预览这次练习', exact: true }).click(); await expect(page.getByRole('button', { name: '确认范围，开始练习 ↗' })).toBeVisible();
  279 |   await f.publish(f.papers.complete, 'withdrawn'); await f.publish(f.papers.complete); await page.getByRole('button', { name: '确认范围，开始练习 ↗' }).click();
  280 |   const recovery = page.getByRole('region', { name: '原开始记录恢复' }); await expect(recovery.getByRole('button', { name: '保留原开始记录，重新预览', exact: true })).toBeVisible();
  281 |   expect((await f.call('/library/practice/sessions')).total).toBe(0); const downloadEvent = page.waitForEvent('download'); await recovery.getByRole('button', { name: '下载开始记录保护文件' }).click();
  282 |   const original = JSON.parse(readFileSync((await (await downloadEvent).path())!, 'utf8')); expect(original.body.selection).toEqual([{ paperId: f.papers.complete }]);
  283 |   expect(await f.call('/library/practice/requests/' + original.body.requestKey)).toBeNull(); await recovery.getByRole('button', { name: '保留原开始记录，重新预览', exact: true }).click();
  284 |   await expect(recovery).toHaveCount(0); await page.getByRole('button', { name: '预览这次练习', exact: true }).click(); await page.getByRole('button', { name: '确认范围，开始练习 ↗' }).click();
  285 |   await expect(page.getByLabel('先写下自己的回答')).toBeVisible(); expect((await f.call('/library/practice/sessions')).total).toBe(1);
  286 |   expect(await page.evaluate(key => Object.entries(localStorage).some(([name, value]) => name.startsWith('study.paper-practice.start:') && JSON.parse(value).body?.requestKey === key), original.body.requestKey)).toBe(true);
  287 | });
  288 | 
  289 | test('recovery: paper practice retains an uncommitted original start through three actual refreshes before one explicit retry', async ({ page }) => {
  290 |   const f = await fixture(page, 17); await page.goto('/library/practice?paper=' + encodeURIComponent(f.papers.complete)); await page.getByRole('button', { name: '预览这次练习', exact: true }).click();
  291 |   let original: any;
  292 |   await page.route('**/api/library/practice/sessions', async route => { if (route.request().method() === 'POST' && !original) { original = route.request().postDataJSON(); return route.abort('failed'); } await route.continue(); });
  293 |   await page.getByRole('button', { name: '确认范围，开始练习 ↗' }).click(); await expect.poll(() => Boolean(original)).toBe(true);
  294 |   for (let refresh = 0; refresh < 3; refresh++) { await page.reload(); await expect(page.getByRole('region', { name: '原开始记录恢复' })).toBeVisible(); expect(await f.call('/library/practice/requests/' + original.requestKey)).toBeNull(); }
  295 |   expect((await f.call('/library/practice/sessions')).total).toBe(0); await page.getByRole('button', { name: '继续核对原开始记录 ↗', exact: true }).click();
  296 |   await expect(page.getByLabel('先写下自己的回答')).toBeVisible(); const receipt = await f.call('/library/practice/requests/' + original.requestKey);
  297 |   expect(new URL(page.url()).searchParams.get('session')).toBe(receipt.session.id); expect((await f.call('/library/practice/sessions')).total).toBe(1);
  298 | });
  299 | 
  300 | test('paper review: a completed first answer leads through real reflection, actual review and the stable local-date calendar', async ({ page }) => {
  301 |   const f = await fixture(page, 22); let row = await f.begin(); const itemId = row.items[0].id;
  302 |   row = (await f.call('/library/practice/sessions/' + row.id + '/commands', { expectedVersion: row.version, requestKey: randomUUID(), kind: 'submit', itemId, disposition: 'dont_know', text: '原首答保留' })).session;
  303 |   row = (await f.call('/library/practice/sessions/' + row.id + '/commands', { expectedVersion: row.version, requestKey: randomUUID(), kind: 'complete', acknowledgeUnanswered: true })).session;
  304 |   await page.goto('/library/practice/review?session=' + row.id + '&item=' + itemId);
  305 |   const editor = page.getByRole('region', { name: '原卷复习与反思' }); await expect(editor.getByLabel('我的反思')).toBeEnabled();
  306 |   await editor.getByLabel('标签，用逗号分隔').pressSequentially('读题，单位'); await expect(editor.getByLabel('标签，用逗号分隔')).toHaveValue('读题，单位');
  307 |   await editor.getByLabel('具体错误步骤').fill('没有统一长度单位'); await editor.getByLabel('我的反思').fill('先检查单位，再写计算过程。'); await editor.getByLabel('计划回看日期').fill('2026-11-09');
  308 |   await editor.getByRole('button', { name: '保存反思与安排', exact: true }).click(); await expect(editor.getByText('完整整理历史 · 1 次', { exact: true })).toBeVisible();
  309 |   const saved = await f.call('/library/practice/sessions/' + row.id + '/items/' + itemId); expect(saved.firstAnswer.text).toBe('原首答保留'); expect(saved.organization).toMatchObject({ tags: ['单位', '读题'], reflection: '先检查单位，再写计算过程。', plannedDate: '2026-11-09' }); expect(saved.reference).toBeNull();
  310 |   await editor.getByRole('button', { name: '我已实际回看', exact: true }).click(); await expect(editor.getByRole('button', { name: '重新放回待复习', exact: true })).toBeEnabled();
  311 |   await page.goto('/library/practice/review?filter=reviewed&q=' + encodeURIComponent('先检查单位'));
  312 |   await expect(page.getByRole('link', { name: /匿名原卷 22.*第 1 题/ })).toBeVisible(); await page.getByLabel('复习月份').fill('2026-11');
  313 |   const calendar = page.getByRole('region', { name: '原卷复习日历' }); await expect(calendar.getByRole('link', { name: /2026-11-09.*匿名原卷 22/ })).toBeVisible();
  314 |   const download = page.waitForEvent('download'); await calendar.getByRole('button', { name: '导出本月复习 ICS' }).click(); const exported = await download;
  315 |   const content = readFileSync((await exported.path())!, 'utf8'); expect(content).toContain('DTSTART;VALUE=DATE:20261109'); expect(content).not.toContain('先检查单位');
  316 | });
  317 | 
  318 | test('paper review: a lost organization receipt is recovered after three reloads without duplicating history or clearing later reflection', async ({ page }) => {
  319 |   const f = await fixture(page, 23), row = await f.begin(), itemId = row.items[0].id; await page.goto('/library/practice/review?session=' + row.id + '&item=' + itemId);
  320 |   const editor = page.getByRole('region', { name: '原卷复习与反思' }); await expect(editor.getByLabel('我的反思')).toBeEnabled(); await editor.getByLabel('我的反思').fill('离线丢回执仍保留同一次反思。'); let captured: any;
  321 |   await page.route('**/api/library/practice/sessions/*/commands', async route => { if (route.request().method() === 'POST' && route.request().postDataJSON()?.kind === 'organize' && !captured) { captured = route.request().postDataJSON(); await route.fetch(); return route.abort('failed'); } await route.continue(); });
> 322 |   await editor.getByRole('button', { name: '保存反思与安排', exact: true }).click(); await expect(page.getByRole('region', { name: '整理原操作恢复' }).getByRole('button', { name: '核对或重试整理原操作' })).toBeEnabled();
      |                                                                                                                                                                                       ^ Error: expect(locator).toBeEnabled() failed
  323 |   for (let index = 0; index < 3; index++) { await page.reload(); await expect(page.getByRole('region', { name: '整理原操作恢复' })).toHaveCount(0); await expect(editor.getByLabel('我的反思')).toHaveValue('离线丢回执仍保留同一次反思。'); }
  324 |   expect((await f.call('/library/practice/sessions/' + row.id + '/items/' + itemId)).organization.history).toHaveLength(1);
  325 |   await editor.getByLabel('我的反思').fill('确认之后继续写的新反思。'); for (let index = 0; index < 3; index++) { await page.reload(); await expect(editor.getByLabel('我的反思')).toHaveValue('确认之后继续写的新反思。'); }
  326 |   await editor.getByRole('button', { name: '保存反思与安排', exact: true }).click(); await expect(editor.getByText('完整整理历史 · 2 次', { exact: true })).toBeVisible();
  327 |   const result = await f.call('/library/practice/sessions/' + row.id + '/items/' + itemId); expect(result.organization.reflection).toBe('确认之后继续写的新反思。'); expect(result.organization.history).toHaveLength(2);
  328 | });
  329 | 
  330 | test('paper review: two real pages compare conflicting reflection drafts before saving a new command', async ({ page, context }) => {
  331 |   const f = await fixture(page, 24), row = await f.begin(), itemId = row.items[0].id, url = '/library/practice/review?session=' + row.id + '&item=' + itemId;
  332 |   await page.goto(url); const second = await context.newPage(); await second.goto(url);
  333 |   const firstEditor = page.getByRole('region', { name: '原卷复习与反思' }), secondEditor = second.getByRole('region', { name: '原卷复习与反思' });
  334 |   await expect(firstEditor.getByLabel('我的反思')).toBeEnabled(); await expect(secondEditor.getByLabel('我的反思')).toBeEnabled();
  335 |   await firstEditor.getByLabel('我的反思').fill('第一页已保存的判断。'); await secondEditor.getByLabel('我的反思').fill('第二页保留的另一种判断。');
  336 |   await firstEditor.getByRole('button', { name: '保存反思与安排', exact: true }).click(); await expect(firstEditor.getByText('完整整理历史 · 1 次', { exact: true })).toBeVisible();
  337 |   await secondEditor.getByRole('button', { name: '保存反思与安排', exact: true }).click(); await expect(secondEditor.getByRole('alert')).toBeVisible();
  338 |   expect((await f.call('/library/practice/sessions/' + row.id + '/items/' + itemId)).organization.reflection).toBe('第一页已保存的判断。');
  339 |   await secondEditor.getByRole('button', { name: '保留冲突文件，读取最新版本' }).click(); await expect(secondEditor.getByText('服务器反思：第一页已保存的判断。', { exact: true })).toBeVisible();
  340 |   await secondEditor.getByRole('button', { name: '保留本机反思，按当前版本继续' }).click(); await expect(secondEditor.getByLabel('我的反思')).toHaveValue('第二页保留的另一种判断。');
  341 |   await secondEditor.getByRole('button', { name: '保存反思与安排', exact: true }).click(); await expect(secondEditor.getByText('完整整理历史 · 2 次', { exact: true })).toBeVisible();
  342 |   const saved = await f.call('/library/practice/sessions/' + row.id + '/items/' + itemId); expect(saved.organization.reflection).toBe('第二页保留的另一种判断。'); expect(saved.organization.history).toHaveLength(2); await second.close();
  343 | });
  344 | 
  345 | for (const width of [390, 768, 1440]) test('paper review: current item, full reflection and protected calendar fit ' + width, async ({ page }) => {
  346 |   const f = await fixture(page, width === 390 ? 25 : width === 768 ? 26 : 27); let row = await f.begin(); const itemId = row.items[0].id;
  347 |   row = (await f.call('/library/practice/sessions/' + row.id + '/commands', { expectedVersion: row.version, requestKey: randomUUID(), kind: 'submit', itemId, disposition: 'dont_know', text: '' })).session;
  348 |   await f.call('/library/practice/sessions/' + row.id + '/commands', { expectedVersion: row.version, requestKey: randomUUID(), kind: 'organize', itemId, values: { tags: ['合成原题'], favorite: true, archived: false, errorSteps: '需要重新核对所给条件', reflection: '一份完整、可继续修改的合成反思。', plannedDate: '2026-11-09' } });
  349 |   await page.setViewportSize({ width, height: 1000 }); await page.goto('/library/practice/review'); await expect(page.getByRole('link', { name: /匿名原卷.*第 1 题/ })).toBeVisible();
  350 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true); await page.screenshot({ path: join(browserEvidence('paper-practice'), 'review-workspace-' + width + '.png'), fullPage: true });
  351 |   await page.getByRole('link', { name: /匿名原卷.*第 1 题/ }).click(); const editor = page.getByRole('region', { name: '原卷复习与反思' }); await expect(editor.getByLabel('我的反思')).toHaveValue('一份完整、可继续修改的合成反思。');
  352 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  353 | });
  354 | 
```