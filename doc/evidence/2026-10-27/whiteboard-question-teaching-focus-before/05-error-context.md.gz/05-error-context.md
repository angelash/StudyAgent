# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-questions.spec.ts >> supplementary close: a late authorized sentence stays silent while the original board remains open
- Location: tests\e2e\whiteboard-questions.spec.ts:148:5

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByRole('region', { name: '原句提问', exact: true }).getByRole('button', { name: '查看补充板书与声音', exact: true })
Expected: focused
Received: inactive
Timeout:  15000ms

Call log:
  - Expect "toBeFocused" getByRole('region', { name: '原句提问', exact: true }).getByRole('button', { name: '查看补充板书与声音', exact: true }) with timeout 15000ms
  - waiting for getByRole('region', { name: '原句提问', exact: true }).getByRole('button', { name: '查看补充板书与声音', exact: true })
    33 × locator resolved to <button type="button" class="wb-question-open">查看补充板书与声音</button>
       - unexpected value "inactive"

```

```yaml
- button "查看补充板书与声音"
```

# Test source

```ts
  58  |   await f.inputBox.fill('为什么需要统一计数单位？'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  59  |   await expect(f.region.locator('.wb-question-answer')).toContainText('当前原句：'); await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  60  |   expect(commands).toHaveLength(1); expect(commands[0]).toMatchObject({ modelId: 'gpt-6-astra', unitId: unit, intent: 'question' });
  61  |   expect(commands[0].bookmark.progress).toBeGreaterThanOrEqual(0); expect(commands[0].bookmark.progress).toBeLessThan(1);
  62  |   await f.player.getByRole('button', { name: '下一句', exact: true }).click(); await expect(f.current).not.toHaveAttribute('data-unit-id', unit!);
  63  |   await f.region.getByRole('button', { name: /回到这句/ }).click(); await expect(f.current).toHaveAttribute('data-unit-id', unit!);
  64  |   await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible(); await expect(f.region.locator('.wb-question-meta')).toContainText('gpt-6-astra');
  65  |   writeFileSync(join(browserEvidence('whiteboard-questions'), 'original-sentence-command.json'), JSON.stringify({ commands, restoredUnit: unit }, null, 2));
  66  | });
  67  | 
  68  | test('supplementary board: explicit audio, whole structured items, real video/SRT and original camera restoration', async ({page})=>{
  69  |   const f=await fixture(page,true),writes:any[]=[];let audioRequests=0;
  70  |   page.on('request',request=>{if(request.method()==='POST'&&request.url().endsWith('/questions'))writes.push(request.postDataJSON());if(request.url().includes('/questions/')&&request.url().includes('/board/narration/'))audioRequests++;});
  71  |   for(let index=0;index<5;index++)await f.player.getByRole('button',{name:'放大白板',exact:true}).click();const originalCanvas=f.player.locator('canvas');
  72  |   await originalCanvas.focus();await page.keyboard.press('ArrowRight');
  73  |   await expect.poll(async()=>JSON.parse((await originalCanvas.getAttribute('data-frame-camera'))??'{}').follow).toBe(false);
  74  |   const pixels=()=>originalCanvas.evaluate(async element=>{const canvas=element as HTMLCanvasElement,bytes=canvas.getContext('2d')!.getImageData(0,0,canvas.width,canvas.height).data;
  75  |     return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(value=>value.toString(16).padStart(2,'0')).join('');});
  76  |   const originalPixels=await pixels();
  77  |   await f.inputBox.fill('[question-structure] 请用表格与公式讲解。');await f.region.getByRole('button',{name:'发送',exact:true}).click();await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  78  |   await f.region.getByRole('button',{name:'查看补充板书与声音',exact:true}).click();const lesson=page.getByRole('dialog',{name:'AI补充讲解',exact:true});await expect(lesson).toHaveAttribute('data-original-font-status','ready');
  79  |   expect(audioRequests).toBe(0);await expect(lesson.getByRole('region',{name:'原句提问',exact:true})).toHaveCount(0);const canvas=lesson.locator('canvas');
  80  |   const parts=()=>canvas.getAttribute('data-frame-parts');await expect.poll(parts).not.toContain('exhibit:0:row:1');await expect.poll(parts).toContain('question-answer:diagram');
  81  |   await lesson.getByRole('button',{name:'下一句',exact:true}).click();await expect.poll(parts).toContain('exhibit:0:row:1');await expect.poll(parts).not.toContain('exhibit:0:row:2');
  82  |   await lesson.getByRole('button',{name:'下一句',exact:true}).click();await expect.poll(parts).toContain('exhibit:0:row:2');await expect.poll(parts).not.toContain('exhibit:1:formula');
  83  |   await lesson.getByRole('button',{name:'下一句',exact:true}).click();await expect.poll(parts).toContain('exhibit:1:formula');await expect.poll(parts).not.toContain('exhibit:2:formula');
  84  |   await lesson.getByRole('button',{name:'下一句',exact:true}).click();await expect.poll(parts).toContain('exhibit:2:formula');
  85  |   await lesson.getByRole('button',{name:'播放',exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).questionAudio.some((audio:HTMLAudioElement)=>!audio.paused&&audio.currentTime>0))).toBe(true);
  86  |   await lesson.getByRole('button',{name:'暂停',exact:true}).click();await lesson.getByRole('combobox',{name:'播放速度',exact:true}).selectOption('2');
  87  |   const videoPromise=page.waitForEvent('download');await lesson.getByRole('button',{name:'导出视频',exact:true}).click();const video=await videoPromise,videoPath=(await video.path())!;
  88  |   const probe=JSON.parse(execFileSync(process.env.STUDY_FFPROBE??'ffprobe',['-v','error','-show_format','-show_streams','-of','json',videoPath],{encoding:'utf8',windowsHide:true}));
  89  |   expect(probe.streams.some((stream:any)=>stream.codec_type==='audio')).toBe(true);expect(Math.abs(Number(probe.format.duration)-5.12)).toBeLessThan(.6);
  90  |   copyFileSync(videoPath,join(browserEvidence('whiteboard-questions'),'supplement-2x.webm'));writeFileSync(join(browserEvidence('whiteboard-questions'),'supplement-2x-probe.json'),JSON.stringify(probe,null,2));
  91  |   const srtPromise=page.waitForEvent('download');await lesson.getByRole('button',{name:'导出字幕',exact:true}).click();const srt=readFileSync((await(await srtPromise).path())!,'utf8');expect((srt.match(/ --> /g)??[]).length).toBe(5);expect(srt).toContain('最后解释根式公式');writeFileSync(join(browserEvidence('whiteboard-questions'),'supplement-2x.srt'),srt);
  92  |   await lesson.getByRole('button',{name:'返回原讲解',exact:true}).click();await expect(lesson).toHaveCount(0);await expect(f.player.getByRole('button',{name:'重置白板视图',exact:true})).toHaveText('150%');
  93  |   await expect.poll(pixels).toBe(originalPixels);expect(writes[0].bookmark.camera.follow).toBe(false);expect(writes[0].bookmark.camera.zoom).toBeCloseTo(1.5,8);
  94  |   expect(await page.evaluate(()=>(window as any).questionAudio.every((audio:HTMLAudioElement)=>audio.paused))).toBe(true);
  95  | });
  96  | 
  97  | test('supplementary board: a delayed authorized audio response cannot play after the original grant is revoked',async({page})=>{
  98  |   const f=await fixture(page,true);await f.inputBox.fill('迟到声音仍须复核原权限。');await f.region.getByRole('button',{name:'发送',exact:true}).click();await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  99  |   await f.region.getByRole('button',{name:'查看补充板书与声音',exact:true}).click();const lesson=page.getByRole('dialog',{name:'AI补充讲解',exact:true});await expect(lesson).toHaveAttribute('data-original-font-status','ready');
  100 |   let reached=false,delivered=false,release!:()=>void;const gate=new Promise<void>(resolve=>{release=resolve;});
  101 |   await page.route('**/questions/*/board/narration/*',async route=>{const response=await route.fetch();reached=true;await gate;try{await route.fulfill({response});}catch{}finally{delivered=true;}});
  102 |   await lesson.getByRole('button',{name:'播放',exact:true}).click();await expect.poll(()=>reached).toBe(true);await f.call('/qa/whiteboard-media',{boardId:f.board.id,revoke:true},f.actor.token);release();
  103 |   await expect.poll(()=>delivered).toBe(true);await expect(lesson).toHaveCount(0);await expect(f.player).toHaveCount(0);
  104 |   expect(await page.evaluate(()=>(window as any).questionAudio.every((audio:HTMLAudioElement)=>audio.paused&&audio.currentTime===0))).toBe(true);
  105 | });
  106 | 
  107 | test('teaching notes: full JSON and Markdown include twelve saved answers while only the last history page is loaded',async({page})=>{
  108 |   const f=await fixture(page);
  109 |   for(let index=0;index<12;index++){await f.inputBox.fill('完整导出问题 '+index);await f.region.getByRole('button',{name:'发送',exact:true}).click();await expect(f.region.locator('.wb-question-answer')).toHaveCount(index+1);}
  110 |   await page.reload();await expect(f.region.locator('.wb-question-answer')).toHaveCount(2);await f.region.getByText('带走完整教学笔记',{exact:true}).click();
  111 |   const jsonPromise=page.waitForEvent('download');await f.region.getByRole('button',{name:'下载完整教学笔记 JSON',exact:true}).click();const notes=JSON.parse(readFileSync((await(await jsonPromise).path())!,'utf8'));
  112 |   expect(notes.turns).toHaveLength(12);expect(notes.turns[0].message).toBe('完整导出问题 0');expect(notes.turns[11].message).toBe('完整导出问题 11');expect(notes.original.fingerprint).toBe(f.board.fingerprint);
  113 |   const mdPromise=page.waitForEvent('download');await f.region.getByRole('button',{name:'下载完整教学笔记 Markdown',exact:true}).click();const markdown=readFileSync((await(await mdPromise).path())!,'utf8');expect(markdown).toContain('### 提问 12');expect(markdown).toContain('完整导出问题 0');expect(markdown).toContain('完整导出问题 11');
  114 |   writeFileSync(join(browserEvidence('whiteboard-questions'),'complete-notes.json'),JSON.stringify(notes,null,2));writeFileSync(join(browserEvidence('whiteboard-questions'),'complete-notes.md'),markdown);
  115 | });
  116 | 
  117 | test('teaching notes: closing the whiteboard discards a late full-note response',async({page})=>{
  118 |   const f=await fixture(page);let reached=false,delivered=false,release!:()=>void;const gate=new Promise<void>(resolve=>{release=resolve;}),downloads:string[]=[];page.on('download',download=>downloads.push(download.suggestedFilename()));
  119 |   await page.route('**/questions/notes',async route=>{const response=await route.fetch();reached=true;await gate;try{await route.fulfill({response});}catch{}finally{delivered=true;}});
  120 |   await f.region.getByText('带走完整教学笔记',{exact:true}).click();await f.region.getByRole('button',{name:'下载完整教学笔记 JSON',exact:true}).click();await expect.poll(()=>reached).toBe(true);
  121 |   await f.player.getByRole('button',{name:'关闭白板',exact:true}).click();await expect(f.player).toHaveCount(0);release();await expect.poll(()=>delivered).toBe(true);await page.waitForTimeout(250);expect(downloads).toEqual([]);
  122 | });
  123 | 
  124 | test('mobile draft: closing and reopening the reading layer preserves blocked-storage input without remounting the composer',async({page})=>{
  125 |   await page.setViewportSize({width:390,height:800});await page.addInitScript(()=>{const set=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.whiteboard.questions.v1.'))throw new DOMException('Blocked','QuotaExceededError');return set.call(this,key,value);};});
  126 |   const f=await fixture(page),message='手机未发送首部。'+ '完整条件。'.repeat(80)+'未发送尾部。';await f.inputBox.fill(message);await expect(f.region).toContainText('本机副本暂未保存');
  127 |   await page.getByRole('dialog',{name:'讲稿与笔记',exact:true}).getByRole('button',{name:'返回白板画面',exact:true}).click();await f.player.getByRole('button',{name:'讲稿与笔记',exact:true}).click();await expect(f.inputBox).toHaveValue(message);
  128 | });
  129 | 
  130 | for (const adult of [false, true]) test('supplementary private link: restores its actual answer and original sentence for ' + (adult ? 'an adult topic without a child' : 'a child guidance board'), async ({ page }) => {
  131 |   const f = await fixture(page, true, adult), originalUnit = await f.current.getAttribute('data-unit-id');
  132 |   await f.inputBox.fill('[question-structure] 请保留原句解释条件。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  133 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  134 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  135 |   await lesson.getByRole('button', { name: '分享与导出', exact: true }).click();
  136 |   const link = await lesson.getByRole('textbox', { name: '原白板私有链接', exact: true }).inputValue(), url = new URL(link);
  137 |   expect(url.searchParams.get('whiteboard')).toBe(f.board.id); expect(url.searchParams.get('question')).toBeTruthy();
  138 |   expect(url.pathname).toBe(adult ? '/studio/whiteboards' : '/studio'); expect(url.searchParams.has('token')).toBe(false);
  139 |   await page.goto(link); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  140 |   await expect(lesson.locator('.wb-current-sentence')).toHaveText('先确认计数单位。');
  141 |   expect(await page.evaluate(() => (window as any).questionAudio.every((audio: HTMLAudioElement) => audio.paused))).toBe(true);
  142 |   await lesson.getByRole('button', { name: '返回原讲解', exact: true }).click(); await expect(lesson).toHaveCount(0);
  143 |   await expect(f.current).toHaveAttribute('data-unit-id', originalUnit!); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  144 |   expect(await f.inputBox.inputValue()).toBe(''); await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  145 |   await page.screenshot({ path: join(browserEvidence('whiteboard-questions'), 'supplement-return-' + (adult ? 'adult' : 'child') + '.png') });
  146 | });
  147 | 
  148 | test('supplementary close: a late authorized sentence stays silent while the original board remains open', async ({ page }) => {
  149 |   const f = await fixture(page, true); await f.inputBox.fill('关闭补充层后保留原讲解。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  150 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1); await f.region.getByRole('button', { name: '查看补充板书与声音', exact: true }).click();
  151 |   const lesson = page.getByRole('dialog', { name: 'AI补充讲解', exact: true }); await expect(lesson).toHaveAttribute('data-original-font-status', 'ready');
  152 |   let reached = false, delivered = false, release!: () => void; const gate = new Promise<void>(resolve => { release = resolve; });
  153 |   await page.route('**/questions/*/board/narration/*', async route => { const response = await route.fetch(); reached = true; await gate; try { await route.fulfill({ response }); } catch {} finally { delivered = true; } });
  154 |   try {
  155 |     await lesson.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => reached).toBe(true);
  156 |     await lesson.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(lesson).toHaveCount(0); release(); await expect.poll(() => delivered).toBe(true);
  157 |     await expect(f.player).toBeVisible(); expect(await page.evaluate(() => (window as any).questionAudio.every((audio: HTMLAudioElement) => audio.paused && audio.currentTime === 0))).toBe(true);
> 158 |     await expect(f.region.getByRole('button', { name: '查看补充板书与声音', exact: true })).toBeFocused();
      |                                                                                    ^ Error: expect(locator).toBeFocused() failed
  159 |   } finally { release(); }
  160 | });
  161 | 
  162 | test('whiteboard questions: five intentions produce distinct original commands and retain completed history', async ({ page }) => {
  163 |   const f = await fixture(page), intentions = ['question','example','simplify','prerequisite','compare'], commands: any[] = [];
  164 |   page.on('request', request => { if (request.method() === 'POST' && request.url().endsWith('/questions')) commands.push(request.postDataJSON()); });
  165 |   for (const [index, intent] of intentions.entries()) {
  166 |     await f.region.getByRole('combobox', { name: '讲解方式', exact: true }).selectOption(intent); await f.inputBox.fill('匿名讲解方式验证 ' + intent);
  167 |     await f.region.getByRole('button', { name: '发送', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(index + 1);
  168 |   }
  169 |   expect(commands.map(command => command.intent)).toEqual(intentions); expect(new Set(commands.map(command => command.requestKey)).size).toBe(5);
  170 |   await page.reload(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(5); await expect(f.inputBox).toHaveValue('');
  171 | });
  172 | 
  173 | test('whiteboard questions: a failed answer has an explicit original-model retry and preserves the next unsent question', async ({ page }) => {
  174 |   const f = await fixture(page); await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('deepseek-v4-flash');
  175 |   await f.inputBox.fill('[question-fail-once] 请解释相同单位。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  176 |   await expect(f.region.getByRole('button', { name: '用原模型重试', exact: true })).toBeVisible();
  177 |   await f.region.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6-astra'); await f.inputBox.fill('这是下一条未发送的完整问题，保留尾部。');
  178 |   await f.region.getByRole('button', { name: '用原模型重试', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  179 |   await expect(f.region.locator('.wb-question-meta')).toContainText('deepseek-v4-flash'); await expect(f.inputBox).toHaveValue('这是下一条未发送的完整问题，保留尾部。');
  180 | });
  181 | 
  182 | test('whiteboard questions: cancelling running work blocks the late answer and the same original can be retried', async ({ page }) => {
  183 |   const f = await fixture(page); await f.inputBox.fill('[question-pause-once] 保留当前原句。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  184 |   await expect(f.region.locator('.wb-question-meta')).toContainText('正在思考'); await f.region.getByRole('button', { name: '取消回答', exact: true }).click();
  185 |   await expect(f.region.locator('.wb-question-meta')).toContainText('已取消'); await expect(f.region.locator('.wb-question-answer')).toHaveCount(0);
  186 |   await f.region.getByRole('button', { name: '用原模型重试', exact: true }).click(); await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  187 | });
  188 | 
  189 | test('whiteboard questions: a lost create response is recovered after reload without a second write', async ({ page }) => {
  190 |   const f = await fixture(page), commands: any[] = [];
  191 |   await page.route('**/api/learning/studio/whiteboards/*/questions', async route => {
  192 |     if (route.request().method() !== 'POST') { await route.continue(); return; }
  193 |     commands.push(route.request().postDataJSON()); const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed');
  194 |   });
  195 |   await f.inputBox.fill('原创建回执丢失仍保留全部内容。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  196 |   await expect.poll(() => commands.length).toBe(1); await page.reload();
  197 |   await expect(f.region.locator('.wb-question-user')).toContainText('原创建回执丢失仍保留全部内容。');
  198 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1); expect(commands).toHaveLength(1); await expect(f.inputBox).toHaveValue('');
  199 | });
  200 | 
  201 | test('whiteboard questions: unavailable local storage keeps the full input, protects closing and round trips the downloaded JSON', async ({ page }) => {
  202 |   await page.addInitScript(() => {
  203 |     const get = Storage.prototype.getItem, set = Storage.prototype.setItem;
  204 |     Storage.prototype.getItem = function(key) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'SecurityError'); return get.call(this,key); };
  205 |     Storage.prototype.setItem = function(key,value) { if (key.startsWith('studyagent.whiteboard.questions.v1.')) throw new DOMException('Blocked', 'QuotaExceededError'); return set.call(this,key,value); };
  206 |   });
  207 |   const f = await fixture(page), message = '完整输入首部。' + '条件与理由。'.repeat(180) + '完整输入尾部。';
  208 |   await f.inputBox.fill(message); await expect(f.region).toContainText('本机副本暂未保存'); await f.player.getByRole('button', { name: '关闭白板', exact: true }).click();
  209 |   await expect(f.player).toBeVisible(); await expect(f.inputBox).toHaveValue(message);
  210 |   const downloadPromise = page.waitForEvent('download'); await f.region.getByRole('button', { name: '下载完整提问副本', exact: true }).click(); const download = await downloadPromise;
  211 |   const bytes = readFileSync((await download.path())!); expect(JSON.parse(bytes.toString('utf8')).form.message).toBe(message);
  212 |   await f.player.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(f.player).toHaveCount(0);
  213 |   await page.goto(f.href); await expect(f.player).toHaveAttribute('data-original-font-status','ready'); await expect(f.inputBox).toBeEnabled();
  214 |   await f.region.getByLabel('导入完整提问副本', { exact: true }).setInputFiles({ name: 'original-question.json', mimeType: 'application/json', buffer: bytes });
  215 |   await expect(f.inputBox).toHaveValue(message);
  216 | });
  217 | 
  218 | test('whiteboard questions: duplicated documents keep separate full drafts across independent reloads', async ({ page, context }) => {
  219 |   const f = await fixture(page), second = await context.newPage(); await second.goto(f.href);
  220 |   const other = second.getByRole('region', { name: '原句提问', exact: true }).getByRole('textbox', { name: '向老师提问', exact: true }); await expect(other).toBeEnabled();
  221 |   await f.inputBox.fill('第一标签页的完整问题 A 尾部。'); await other.fill('第二标签页的完整问题 B 尾部。');
  222 |   await page.reload(); await expect(f.inputBox).toHaveValue('第一标签页的完整问题 A 尾部。');
  223 |   await second.reload(); await expect(other).toHaveValue('第二标签页的完整问题 B 尾部。'); await second.close();
  224 | });
  225 | 
  226 | for (const width of [390,768,1280]) test('whiteboard questions: the real composer, model selection and return controls remain usable at ' + width, async ({ page }) => {
  227 |   await page.setViewportSize({ width, height: 800 }); const f = await fixture(page);
  228 |   await f.inputBox.fill('窄屏完整提问，回答后返回原句。'); await f.region.getByRole('button', { name: '发送', exact: true }).click();
  229 |   await expect(f.region.locator('.wb-question-answer')).toHaveCount(1);
  230 |   for (const control of [f.inputBox, f.region.getByRole('combobox', { name: '讲解方式', exact: true }), f.region.getByRole('combobox', { name: '选择大模型', exact: true }),
  231 |     f.region.getByRole('button', { name: '发送', exact: true })]) {
  232 |     const box = await control.boundingBox(); expect(box).not.toBeNull(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  233 |   }
  234 |   await page.screenshot({ path: join(browserEvidence('whiteboard-questions'), 'question-panel-' + width + '.png') });
  235 |   await f.region.getByRole('button', { name: /回到这句/ }).click(); await expect(f.player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  236 | });
  237 | 
```