# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: reference-navigation.spec.ts >> reference navigation: a mobile drawer hands focus to the real course blueprint and returns to its menu trigger after closing
- Location: tests\e2e\reference-navigation.spec.ts:77:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - alert [ref=f2e2]
  - main [ref=f2e3]:
    - button "打开学习导航" [active] [ref=f2e4] [cursor=pointer]
    - generic [ref=f2e7]:
      - generic [ref=f2e8]:
        - generic [ref=f2e9]:
          - link "创建学习档案" [ref=f2e10] [cursor=pointer]:
            - /url: /parent/dashboard
          - combobox "学科" [ref=f2e11]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f2e12]:
          - link "教学课堂 ↗" [ref=f2e13] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f2e14] [cursor=pointer]:
            - /url: /
      - generic [ref=f2e16]:
        - generic [ref=f2e17]:
          - generic [ref=f2e18]:
            - heading "我的课程" [level=1] [ref=f2e19]
            - link "从资料创建 →" [ref=f2e20] [cursor=pointer]:
              - /url: /studio/source-courses?new=1&subject=math
            - button "＋ 创建课程" [ref=f2e21] [cursor=pointer]
          - generic [ref=f2e22]:
            - tablist "课程状态" [ref=f2e23]:
              - tab "全部" [selected] [ref=f2e24] [cursor=pointer]
              - tab "未开始" [ref=f2e25] [cursor=pointer]
              - tab "进行中" [ref=f2e26] [cursor=pointer]
              - tab "已完成" [ref=f2e27] [cursor=pointer]
            - generic [ref=f2e28]:
              - text: ⌕
              - textbox "搜索课程" [ref=f2e29]:
                - /placeholder: 搜索名称、目标、教材…
          - generic [ref=f2e30]:
            - generic [ref=f2e31]:
              - text: 课程类型
              - combobox "课程类型" [ref=f2e32]:
                - option "全部类型" [selected]
                - option "成人独立课"
                - option "小学学习课"
            - generic [ref=f2e33]:
              - text: 内容来源
              - combobox "内容来源" [ref=f2e34]:
                - option "全部来源" [selected]
                - option "自编主题课程"
                - option "已确认范围课程"
                - option "自己的资料课程"
            - generic [ref=f2e35]:
              - text: 最近学习
              - combobox "最近学习" [ref=f2e36]:
                - option "不限时间" [selected]
                - option "近7天"
                - option "近30天"
            - generic [ref=f2e37]:
              - text: 排序
              - combobox "课程排序" [ref=f2e38]:
                - option "最近学习" [selected]
                - option "最近添加"
                - option "课程名称"
          - status [ref=f2e40]: 显示 1 / 1 门课程
          - paragraph [ref=f2e41]: “已完成”指本课程讲解已读；课堂练习、项目和独立测量分别保留记录。
          - article [ref=f2e43]:
            - link "打开课程：社会学概论" [ref=f2e44] [cursor=pointer]:
              - /url: /studio/classroom?returnSubject=math
              - generic [ref=f2e45]:
                - generic [ref=f2e46]: 成人独立课
                - heading [level=2] [ref=f2e47]:
                  - text: 社会学概论
                  - emphasis [ref=f2e48]: 新
                - generic [ref=f2e49]:
                  - generic [ref=f2e50]: 来源StudyAgent 自编
                  - generic [ref=f2e51]: 课程结构5 单元 · 60 微课
                - paragraph [ref=f2e52]: 未开始
              - img "由阶梯与拱门构成的课程封面" [ref=f2e53]
              - generic "讲解已读 0 / 60" [ref=f2e73]: 0 / 60 讲
            - link "接下来 讲座 社会学想象力 开始学习 →" [ref=f2e75] [cursor=pointer]:
              - /url: /studio/classroom?lesson=soc-1-1-1&returnSubject=math
              - generic [ref=f2e76]: 接下来
              - emphasis [ref=f2e77]: 讲座
              - generic [ref=f2e78]: 社会学想象力
              - generic [ref=f2e79]: 开始学习 →
        - complementary [ref=f2e80]:
          - generic [ref=f2e81]:
            - generic [ref=f2e82]:
              - generic [ref=f2e83]: 本周
              - generic [ref=f2e84]:
                - button "上一周学习记录" [ref=f2e85] [cursor=pointer]: ‹
                - button "下一周学习记录" [disabled] [ref=f2e86]: ›
            - heading "已读 0 个微课" [level=2] [ref=f2e87]
            - paragraph [ref=f2e88]: 成人独立课已读微课的最近学习日期。
            - generic [ref=f2e89]:
              - generic [ref=f2e90]:
                - generic [ref=f2e91]: 一
                - generic [ref=f2e92]: "0"
              - generic [ref=f2e93]:
                - generic [ref=f2e94]: 二
                - generic [ref=f2e95]: "0"
              - generic [ref=f2e96]:
                - generic [ref=f2e97]: 三
                - generic [ref=f2e98]: "0"
              - generic [ref=f2e99]:
                - generic [ref=f2e100]: 四
                - generic [ref=f2e101]: "0"
              - generic [ref=f2e102]:
                - generic [ref=f2e103]: 五
                - generic [ref=f2e104]: "0"
              - generic [ref=f2e105]:
                - generic [ref=f2e106]: 六
                - generic [ref=f2e107]: "0"
              - generic [ref=f2e108]:
                - generic [ref=f2e109]: 日
                - generic [ref=f2e110]: "0"
            - link "继续成人独立课 社会学概论 社会学想象力 →" [ref=f2e111] [cursor=pointer]:
              - /url: /studio/classroom?lesson=soc-1-1-1&returnSubject=math
              - generic [ref=f2e112]: 继续成人独立课
              - generic [ref=f2e113]: 社会学概论
              - generic [ref=f2e114]: 社会学想象力 →
          - generic [ref=f2e115]:
            - heading "学习工具" [level=2] [ref=f2e116]
            - paragraph [ref=f2e117]: 把资料、安排和复盘接回课程。
            - link "资料与学案 →" [ref=f2e118] [cursor=pointer]:
              - /url: /studio?view=materials&subject=math
              - text: 资料与学案
              - generic [ref=f2e119]: →
            - link "安排学习时间 →" [ref=f2e120] [cursor=pointer]:
              - /url: /studio?view=calendar&subject=math
              - text: 安排学习时间
              - generic [ref=f2e121]: →
            - link "查看学习历史 →" [ref=f2e122] [cursor=pointer]:
              - /url: /studio?view=history&subject=math
              - text: 查看学习历史
              - generic [ref=f2e123]: →
    - dialog "课程蓝图" [ref=f2e125]:
      - generic [ref=f2e126]:
        - generic [ref=f2e127]:
          - text: COURSE BLUEPRINT
          - heading "设计这次学习" [level=2] [ref=f2e128]
        - button "关闭课程蓝图" [ref=f2e129] [cursor=pointer]: ×
      - list "创建课程步骤" [ref=f2e130]:
        - listitem [ref=f2e131]: 1 · 目标与范围
        - listitem [ref=f2e132]: 2 · 审阅后确认
      - paragraph [ref=f2e133]:
        - link "用自己的 PDF 或文字资料创建课程 →" [ref=f2e134] [cursor=pointer]:
          - /url: /studio/source-courses?new=1
      - generic [ref=f2e135]:
        - generic [ref=f2e136]:
          - generic [ref=f2e137]:
            - text: 课程名称
            - textbox "课程名称" [ref=f2e138]:
              - /placeholder: 可留空，按所选知识点命名
          - generic [ref=f2e139]:
            - text: 希望解决什么问题
            - textbox "课程学习目标" [ref=f2e140]:
              - /placeholder: 例如：先理解共同单位，再独立完成陌生情境中的分数加法
          - generic [ref=f2e141]:
            - generic [ref=f2e142]:
              - text: 每次学习预算
              - combobox "每次学习预算" [ref=f2e143]:
                - option "5 分钟"
                - option "10 分钟"
                - option "15 分钟" [selected]
                - option "20 分钟"
                - option "25 分钟"
                - option "30 分钟"
                - option "45 分钟"
                - option "60 分钟"
            - generic [ref=f2e144]:
              - generic [ref=f2e145]: 教学语言
              - generic [ref=f2e146]: 沿用已审核材料
              - generic [ref=f2e147]: 保留材料中的原语言和英文例句。
        - group "选择本次知识点 已选 0 / 0" [ref=f2e148]:
          - generic [ref=f2e149]:
            - text: 选择本次知识点
            - generic [ref=f2e150]: 已选 0 / 0
          - paragraph [ref=f2e151]: 先选择学习档案，再确认学习范围。
        - paragraph [ref=f2e152]:
          - link "先创建学习档案 →" [ref=f2e153] [cursor=pointer]:
            - /url: /parent/dashboard
        - generic [ref=f2e154]:
          - button "取消" [ref=f2e155] [cursor=pointer]
          - button "预览课程蓝图" [disabled] [ref=f2e156]
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash } from 'node:crypto';
  3  | import { browserEvidence } from './evidence';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`, evidence = browserEvidence('reference-navigation');
  5  | async function enter(page: Page, width: number) {
  6  |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  7  |   const nonce = crypto.randomUUID(), principal = 'navigation-' + nonce + '@local.test', credential = 'Nav-QA-' + nonce;
  8  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.20.' + hash[0] + '.' + hash[1];
  9  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  10 |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  11 |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
  12 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  13 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  14 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  15 |   await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  16 |   return actor;
  17 | }
  18 | for (const width of [390, 768, 1280, 1440]) test(`reference navigation: truthful empty history, actual navigation and complete compact or modal controls at ${width}`, async ({ page }) => {
  19 |   await enter(page, width);
  20 |   if (width <= 1000) await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  21 |   const sidebar = page.getByLabel('学习工作台导航', { exact: true }); await expect(sidebar).toBeVisible();
  22 |   await expect(sidebar.getByRole('region', { name: '开始学习', exact: true })).toContainText('打开课程');
  23 |   await expect(sidebar.getByRole('region', { name: '继续学习', exact: true })).toHaveCount(0);
  24 |   if (width <= 1000) {
  25 |     await expect(sidebar).toHaveAttribute('aria-modal', 'true');
  26 |     const row = sidebar.getByRole('link', { name: 'Courses', exact: true }), icon = await row.locator('svg').boundingBox(), label = await row.locator('.button-label').boundingBox();
  27 |     expect(label!.x, 'the open drawer keeps the icon and complete label in one horizontal row').toBeGreaterThan(icon!.x + icon!.width);
  28 |     expect(Math.abs(label!.y + label!.height / 2 - icon!.y - icon!.height / 2)).toBeLessThanOrEqual(4);
  29 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(true);
  30 |     await page.keyboard.press('Shift+Tab'); expect(await sidebar.evaluate(node => node.contains(document.activeElement))).toBe(true);
  31 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  32 |     await page.keyboard.press('Escape'); await expect(sidebar).toHaveCount(0);
  33 |     await expect(page.getByRole('button', { name: '打开学习导航', exact: true })).toBeFocused();
  34 |     expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  35 |     await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  36 |   } else {
  37 |     expect((await sidebar.boundingBox())!.width).toBe(240);
  38 |     await sidebar.getByRole('button', { name: '收起学习导航', exact: true }).click(); await expect(sidebar).toHaveCSS('width', '60px');
  39 |     await expect(sidebar.getByRole('link', { name: 'Courses', exact: true })).toBeVisible();
  40 |     await page.reload(); await expect(page.getByRole('button', { name: '展开学习导航', exact: true })).toBeVisible();
  41 |     await page.getByRole('button', { name: '展开学习导航', exact: true }).click();
  42 |     await page.screenshot({ path: evidence + '/navigation-' + width + '.png', fullPage: true });
  43 |   }
  44 |   await sidebar.getByRole('link', { name: 'Courses', exact: true }).click(); await expect(page.getByRole('heading', { name: '我的课程', exact: true })).toBeVisible();
  45 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  46 | });
  47 | test('reference navigation: a real saved classroom opens the exact original session and position from the course library', async ({ page }) => {
  48 |   await enter(page, 1280); await page.getByRole('button', { name: '▶ 学习', exact: true }).first().click();
  49 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  50 |   const original = new URL(page.url()).searchParams.get('session');
  51 |   await page.getByRole('button', { name: '离开课堂', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  52 |   await page.goto('/studio?view=courses'); const resume = page.getByRole('region', { name: '继续学习', exact: true }); await expect(resume).toContainText('社会学想象力');
  53 |   await resume.getByRole('link').click(); await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  54 |   expect(new URL(page.url()).searchParams.get('session')).toBe(original);
  55 | });
  56 | test('reference navigation: resizing an open drawer restores usable desktop controls and releases the original background', async ({ page }) => {
  57 |   await enter(page, 768); await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  58 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toBeVisible(); await page.setViewportSize({ width: 1280, height: 900 });
  59 |   await expect(page.getByRole('dialog', { name: '学习工作台导航', exact: true })).toHaveCount(0);
  60 |   await expect(page.getByRole('button', { name: '收起学习导航', exact: true })).toBeVisible();
  61 |   expect(await page.locator('.cl-course-layout').evaluate(node => Boolean(node.closest('[inert]')))).toBe(false);
  62 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  63 |   await page.getByRole('tab', { name: '练习', exact: true }).click(); await expect(page.getByRole('tabpanel', { name: '练习', exact: true })).toBeVisible();
  64 | });
  65 | test('reference navigation: blocked preference storage keeps current controls usable without inventing a saved preference', async ({ page }) => {
  66 |   await enter(page, 1280);
  67 |   await page.addInitScript(() => {
  68 |     const read = Storage.prototype.getItem, write = Storage.prototype.setItem;
  69 |     Storage.prototype.getItem = function (key) { if (key.startsWith('studyagent.navigation.compact.')) throw new Error('Synthetic unavailable navigation preferences'); return read.call(this, key); };
  70 |     Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.navigation.compact.')) throw new Error('Synthetic unavailable navigation preferences'); return write.call(this, key, value); };
  71 |   });
  72 |   await page.reload(); const sidebar = page.getByLabel('学习工作台导航', { exact: true });
  73 |   await sidebar.getByRole('button', { name: '收起学习导航', exact: true }).click(); await expect(sidebar).toHaveCSS('width', '60px');
  74 |   await sidebar.getByRole('button', { name: '展开学习导航', exact: true }).click(); await expect(sidebar).toHaveCSS('width', '240px');
  75 |   await page.reload(); await expect(sidebar.getByRole('button', { name: '收起学习导航', exact: true })).toBeVisible();
  76 | });
  77 | test('reference navigation: a mobile drawer hands focus to the real course blueprint and returns to its menu trigger after closing', async ({ page }) => {
  78 |   await enter(page, 390); await page.goto('/studio?view=courses'); await expect(page.getByRole('heading', { name: '我的课程', exact: true })).toBeVisible();
  79 |   const trigger = page.getByRole('button', { name: '打开学习导航', exact: true }); await trigger.click();
  80 |   await page.getByRole('dialog', { name: '学习工作台导航', exact: true }).getByRole('button', { name: '＋ 创建课程', exact: true }).click();
  81 |   const blueprint = page.getByRole('dialog', { name: '课程蓝图', exact: true }); await expect(blueprint).toBeVisible();
  82 |   await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
> 83 |   expect(await blueprint.evaluate(node => node.contains(document.activeElement))).toBe(true);
     |                                                                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  84 |   await page.keyboard.press('Tab'); expect(await blueprint.evaluate(node => node.contains(document.activeElement))).toBe(true);
  85 |   await page.keyboard.press('Escape'); await expect(blueprint).toHaveCount(0); await expect(trigger).toBeFocused();
  86 |   expect(await page.evaluate(() => document.body.style.overflow)).not.toBe('hidden');
  87 | });
  88 | 
```