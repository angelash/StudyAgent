# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: original-teaching-fonts.spec.ts >> teaching frame: moving to another scene retains already taught notes, excludes future scenes and keeps one full caption
- Location: tests\e2e\original-teaching-fonts.spec.ts:59:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

Expected: ArrayContaining ["异分母分数加法", "先建立概念"]
Received: ["STUDYAGENT / LEARNING BOARD", "EVIDENCE GROUNDED", "先建立概念", "异分母分数的份大小不同，先通分成同一分数单位，再相加份数；分母代表单位，不随份数相加。", "异分母分数的份大小不同，先通分成同一分数单位，再相加份数；分母代表单位，不随份数相加。"]

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - button "Home" [ref=f1e10] [cursor=pointer]:
          - generic [ref=f1e13]: 首页
        - button "Courses" [ref=f1e14] [cursor=pointer]:
          - generic [ref=f1e17]: 课程
        - button "Calendar" [ref=f1e18] [cursor=pointer]:
          - generic [ref=f1e21]: 学习动态
        - button "History" [ref=f1e22] [cursor=pointer]:
          - generic [ref=f1e25]: 历史
        - button "Materials" [ref=f1e26] [cursor=pointer]:
          - generic [ref=f1e29]: 资料
        - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f1e33]: AI白板
      - button "＋ 创建课程" [ref=f1e34] [cursor=pointer]
      - generic [ref=f1e35]:
        - heading "继续学习" [level=2] [ref=f1e36]
        - link "讲座社会学想象力 社会学概论" [ref=f1e37] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f1e38]: 社会学概论
      - generic [ref=f1e39]:
        - heading "近期活动" [level=2] [ref=f1e40]
        - link "白板视频「异分母分数加法」" [ref=f1e41] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_650cf1c9-d459-4b8b-bbe4-ff1cc2c98dca
      - link "返回学习首页 →" [ref=f1e43] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_6fca57e8-5da2-4dce-b5a9-f53e03f1b2fb
    - generic [ref=f1e44]:
      - generic [ref=f1e45]:
        - generic [ref=f1e46]:
          - combobox "学习档案" [ref=f1e47]:
            - option "匿名字体白板" [selected]
          - combobox "学科" [ref=f1e48]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e49]:
          - link "教学课堂 ↗" [ref=f1e50] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e51] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e52]:
        - generic [ref=f1e53]:
          - button "Craft Courses" [ref=f1e54] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e55] [cursor=pointer]
        - generic [ref=f1e56]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f1e57]
          - paragraph [ref=f1e58]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f1e59]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f1e60]
          - generic [ref=f1e61]:
            - generic [ref=f1e62]: ＋
            - generic [ref=f1e63]: 资料
            - button "Concept Explanation" [ref=f1e64] [cursor=pointer]
            - generic [ref=f1e65]: 语音
            - generic [ref=f1e68]:
              - generic [ref=f1e69]: 模型
              - combobox "选择大模型" [ref=f1e70] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f1e71] [cursor=pointer]
        - generic [ref=f1e72]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f1e73] [cursor=pointer]:
            - generic [ref=f1e74]: 可视化
            - generic [ref=f1e75]: 用图形解释异分母加法
            - generic [ref=f1e76]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f1e77] [cursor=pointer]:
            - generic [ref=f1e78]: 个性化练习
            - generic [ref=f1e79]: 从我的已知点生成练习
            - generic [ref=f1e80]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f1e81] [cursor=pointer]:
            - generic [ref=f1e82]: 主动学习
            - generic [ref=f1e83]: 看看今天最值得做什么
            - generic [ref=f1e84]: 按教育优先级排序
        - generic [ref=f1e85]:
          - heading "你的学习路径" [level=2] [ref=f1e86]
          - button "创建课程" [ref=f1e87] [cursor=pointer]
        - generic [ref=f1e88]:
          - heading "还没有课程" [level=3] [ref=f1e89]
          - paragraph [ref=f1e90]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f1e91] [cursor=pointer]
        - complementary [ref=f1e92]:
          - article [ref=f1e93]:
            - generic [ref=f1e94]:
              - generic [ref=f1e95]:
                - text: LEARNER SNAPSHOT
                - heading "匿名字体白板" [level=2] [ref=f1e96]
              - generic [ref=f1e97]: 5 年级
            - generic [ref=f1e98]:
              - strong [ref=f1e99]: "0"
              - generic [ref=f1e100]: / 1
              - generic [ref=f1e101]: 已有点有稳定证据
            - generic [ref=f1e102]:
              - generic [ref=f1e103]:
                - generic [ref=f1e104]: "1"
                - text: 已确认知识点
              - generic [ref=f1e105]:
                - generic [ref=f1e106]: "0"
                - text: 日历安排
          - article [ref=f1e107]:
            - generic [ref=f1e108]:
              - generic [ref=f1e109]: NEXT BEST ACTION
              - button "全部 →" [ref=f1e110] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f1e111] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_6fca57e8-5da2-4dce-b5a9-f53e03f1b2fb&subject=math
              - generic [ref=f1e112]: 1个已学点仍需补充证据
              - paragraph [ref=f1e113]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f1e114]:
            - generic [ref=f1e115]:
              - generic [ref=f1e116]: RECENT WHITEBOARDS
              - button "新建" [ref=f1e117] [cursor=pointer]
            - button "▶ 异分母分数加法 5 幕 · 27 秒" [ref=f1e118] [cursor=pointer]:
              - generic [ref=f1e119]: ▶
              - generic [ref=f1e120]:
                - generic [ref=f1e121]: 异分母分数加法
                - generic [ref=f1e122]: 5 幕 · 27 秒
          - article [ref=f1e123]:
            - generic [ref=f1e124]:
              - generic [ref=f1e125]: SYNC STATUS
              - button "日历 →" [ref=f1e126] [cursor=pointer]
            - paragraph [ref=f1e127]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f1e128]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f1e129]:
      - generic [ref=f1e130]:
        - generic [ref=f1e131]:
          - generic [ref=f1e132]: WHITEBOARD SESSION / 原白板
          - heading "异分母分数加法" [level=2] [ref=f1e133]
          - paragraph [ref=f1e134]: 逐句文字阅读 · 使用估计阅读时长 · 板书按完整要点呈现
        - button "关闭白板" [ref=f1e135] [cursor=pointer]: ×
      - generic [ref=f1e136]:
        - generic [ref=f1e137]:
          - generic "先建立概念" [ref=f1e139]
          - paragraph [ref=f1e140]: 异分母分数的份大小不同，先通分成同一分数单位，再相加份数；分母代表单位，不随份数相加。
          - generic [ref=f1e141]:
            - generic [ref=f1e142]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f1e143] [cursor=pointer]: "137"
          - generic [ref=f1e144]:
            - button "上一句" [ref=f1e145] [cursor=pointer]: ←
            - button "播放" [ref=f1e146] [cursor=pointer]: ▶
            - button "下一句" [ref=f1e147] [cursor=pointer]: →
            - generic [ref=f1e148]: 2 / 10 句
            - combobox "阅读方式" [ref=f1e149] [cursor=pointer]:
              - option "文字阅读（估计时长）" [selected]
            - combobox "播放速度" [ref=f1e150] [cursor=pointer]:
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
            - button "导出视频" [ref=f1e151] [cursor=pointer]
            - button "导出字幕" [ref=f1e152] [cursor=pointer]
          - status [ref=f1e153]
          - generic [ref=f1e154]:
            - button "01 异分母分数加法" [ref=f1e155] [cursor=pointer]:
              - generic [ref=f1e156]: "01"
              - text: 异分母分数加法
            - button "02 先建立概念" [active] [ref=f1e157] [cursor=pointer]:
              - generic [ref=f1e158]: "02"
              - text: 先建立概念
            - button "03 跟着步骤走" [ref=f1e159] [cursor=pointer]:
              - generic [ref=f1e160]: "03"
              - text: 跟着步骤走
            - button "04 先统一切法，再合并份数" [ref=f1e161] [cursor=pointer]:
              - generic [ref=f1e162]: "04"
              - text: 先统一切法，再合并份数
            - button "05 换一道新题验证" [ref=f1e163] [cursor=pointer]:
              - generic [ref=f1e164]: "05"
              - text: 换一道新题验证
        - complementary "完整讲稿与要点" [ref=f1e165]:
          - heading "逐句讲稿" [level=3] [ref=f1e166]
          - paragraph [ref=f1e167]: 点击一句定位。观看与续播不计作掌握。
          - list [ref=f1e168]:
            - listitem [ref=f1e169]:
              - button "这次我们从“异分母分数加法”开始，把关键关系拆成看得见的步骤。" [ref=f1e170] [cursor=pointer]
            - listitem [ref=f1e171]:
              - button "异分母分数的份大小不同，先通分成同一分数单位，再相加份数；分母代表单位，不随份数相加。" [ref=f1e172] [cursor=pointer]
            - listitem [ref=f1e173]:
              - button "现在用“计算2/3+1/4。”" [ref=f1e174] [cursor=pointer]
            - listitem [ref=f1e175]:
              - button "做一次示范。" [ref=f1e176] [cursor=pointer]
            - listitem [ref=f1e177]:
              - button "共同分母取12，2/3=8/12，1/4=3/12。" [ref=f1e178] [cursor=pointer]
            - listitem [ref=f1e179]:
              - button "8个十二分之一加3个十二分之一，得11/12。" [ref=f1e180] [cursor=pointer]
            - listitem [ref=f1e181]:
              - button "和11/12。" [ref=f1e182] [cursor=pointer]
            - listitem [ref=f1e183]:
              - button "三段中的两段不能直接和四段中的一段相加；都改写成十二分之一后，才能数总份数。" [ref=f1e184] [cursor=pointer]
            - listitem [ref=f1e185]:
              - button "看懂演示不等于掌握。" [ref=f1e186] [cursor=pointer]
            - listitem [ref=f1e187]:
              - button "收起画面后，要用不同数值的独立新题和延迟复测再核查。" [ref=f1e188] [cursor=pointer]
          - heading "完整笔记与来源" [level=3] [ref=f1e189]
          - group [ref=f1e190]:
            - generic "异分母分数加法" [ref=f1e191] [cursor=pointer]
          - group [ref=f1e192]:
            - generic "先建立概念" [ref=f1e193] [cursor=pointer]
            - paragraph [ref=f1e194]: 异分母分数的份大小不同，先通分成同一分数单位，再相加份数；分母代表单位，不随份数相加。
          - group [ref=f1e195]:
            - generic "跟着步骤走" [ref=f1e196] [cursor=pointer]
          - group [ref=f1e197]:
            - generic "先统一切法，再合并份数" [ref=f1e198] [cursor=pointer]
          - group [ref=f1e199]:
            - generic "换一道新题验证" [ref=f1e200] [cursor=pointer]
          - button "下载续播位置" [ref=f1e201] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash, randomUUID } from 'node:crypto';
  3  | import { readFileSync, writeFileSync } from 'node:fs';
  4  | import { join } from 'node:path';
  5  | import { browserEvidence } from './evidence';
  6  | 
  7  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4168') + '/api';
  8  | test.afterEach(async ({ page }) => { await page.unrouteAll({ behavior: 'wait' }); });
  9  | async function board(page: Page) {
  10 |   const key = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + key[0] + '.' + key[1], principal = 'font-fixture-' + randomUUID(), credential = 'Synthetic-fonts-only-20261027';
  11 |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  12 |   async function call(path: string, body: object, token?: string, method = 'POST') {
  13 |     const response = await fetch(api + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: JSON.stringify(body) });
  14 |     expect(response.ok, path + ' ' + response.status).toBe(true); return (await response.json()).data;
  15 |   }
  16 |   const actor = await call('/auth/register', { principal, credential }), child = (await call('/students', { nickname: '匿名字体白板', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token)).profile.id;
  17 |   await call('/students/' + child + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15 }, actor.token, 'PUT');
  18 |   const command = { studentId: child, subject: 'math', prompt: '异分母分数加法：先理解单位，再通分。', atomId: 'core:math:fractionadd' }, preview = await call('/learning/studio/whiteboards/preview', command, actor.token);
  19 |   const saved = await call('/learning/studio/whiteboards', { ...command, fingerprint: preview.fingerprint, requestKey: randomUUID() }, actor.token);
  20 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  21 |   return '/studio?student=' + child + '&subject=math&whiteboard=' + saved.id;
  22 | }
  23 | 
  24 | test('original fonts: real captured Latin and Chinese faces decode before a board is measured, played or exported', async ({ page }) => {
  25 |   const url = await board(page), requests: string[] = [];
  26 |   page.on('request', request => { if (request.resourceType() === 'font') requests.push(request.url()); });
  27 |   await page.addInitScript(() => {
  28 |     const original = CanvasRenderingContext2D.prototype.fillText;
  29 |     (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts = [];
  30 |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) {
  31 |       (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.push(this.font); return original.apply(this, args);
  32 |     };
  33 |   });
  34 |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  35 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  36 |   const loaded = await page.evaluate(() => [...new Set(Array.from(document.fonts).filter(face => face.status === 'loaded').map(face => face.family.replace(/^['"]|['"]$/g, '')))]);
  37 |   for (const family of ['Virgil', 'Xiaolai', 'Satoshi-Regular', 'Satoshi-Medium', 'Satoshi-Bold', 'MiSans']) expect(loaded).toContain(family);
  38 |   await expect.poll(() => page.evaluate(() => (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.some(font => /Virgil/.test(font) && /Xiaolai/.test(font)))).toBe(true);
  39 |   expect(requests.length).toBeGreaterThan(4); for (const request of requests) expect(new URL(request).pathname).toMatch(/^\/reference\/hyperknow\//);
  40 |   const manifest = JSON.parse(readFileSync(join(process.cwd(), 'apps/web/public/reference/hyperknow/asset-manifest.json'), 'utf8'));
  41 |   for (const request of [...new Set(requests)].slice(0, 8)) {
  42 |     const entry = manifest.files.find((entry: { publicPath: string }) => entry.publicPath === new URL(request).pathname); expect(entry).toBeTruthy();
  43 |     const response = await page.request.get(request), bytes = await response.body(); expect(response.status()).toBe(200); expect(createHash('sha256').update(bytes).digest('hex')).toBe(entry.sha256);
  44 |   }
  45 |   writeFileSync(join(browserEvidence('original-teaching-fonts'), 'actual-loaded-fonts.json'), JSON.stringify({ loaded, requests, originalFontManifest: manifest.captureFingerprint }, null, 2) + '\n');
  46 |   await page.screenshot({ path: join(browserEvidence('original-teaching-fonts'), 'actual-board-fonts.png'), fullPage: true });
  47 | });
  48 | 
  49 | test('original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board', async ({ page }) => {
  50 |   const url = await board(page); let blocked = false;
  51 |   await page.route('**/reference/hyperknow/assets/woff2/Xiaolai-*.woff2*', async route => { if (!blocked) { blocked = true; await route.abort('failed'); } else await route.continue(); });
  52 |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  53 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'error'); expect(blocked).toBe(true); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeDisabled(); await expect(dialog.getByRole('button', { name: '导出视频', exact: true })).toBeDisabled();
  54 |   await page.unrouteAll({ behavior: 'wait' }); await dialog.getByRole('button', { name: '重新准备板书字体' }).click();
  55 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  56 |   expect(page.url()).toContain(new URL(url, 'http://fixture').searchParams.get('whiteboard')!);
  57 | });
  58 | 
  59 | test('teaching frame: moving to another scene retains already taught notes, excludes future scenes and keeps one full caption', async ({ page }) => {
  60 |   const url = await board(page);
  61 |   await page.addInitScript(() => {
  62 |     const clear = CanvasRenderingContext2D.prototype.clearRect, fill = CanvasRenderingContext2D.prototype.fillText;
  63 |     const state = window as unknown as { latestTeachingFrame: string[] }; state.latestTeachingFrame = [];
  64 |     CanvasRenderingContext2D.prototype.clearRect = function (...args: Parameters<CanvasRenderingContext2D['clearRect']>) { state.latestTeachingFrame = []; return clear.apply(this, args); };
  65 |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) { state.latestTeachingFrame.push(args[0]); return fill.apply(this, args); };
  66 |   });
  67 |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  68 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  69 |   const scenes = dialog.locator('.sa-scene-strip button'), title = async (index: number) => (await scenes.nth(index).innerText()).replace(/^\d+\s*/u, '').trim();
  70 |   const first = await title(0), second = await title(1), third = await title(2);
  71 |   await scenes.nth(1).click();
> 72 |   await expect.poll(() => page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).toEqual(expect.arrayContaining([first, second]));
     |                                                                                                                              ^ Error: expect(received).toEqual(expected) // deep equality
  73 |   expect(await page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).not.toContain(third);
  74 |   const sentence = dialog.locator('.wb-current-sentence'); await expect(sentence).toHaveCount(1);
  75 |   const unit = await sentence.getAttribute('data-unit-id'); await dialog.getByRole('button', { name: '缩小白板', exact: true }).click();
  76 |   await expect(sentence).toHaveAttribute('data-unit-id', unit!); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  77 |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'cumulative-second-scene.png'), fullPage: true });
  78 | });
  79 | 
```