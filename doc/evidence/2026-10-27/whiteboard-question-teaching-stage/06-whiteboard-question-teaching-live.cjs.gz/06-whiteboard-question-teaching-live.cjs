/* Real configured providers; isolated synthetic adult original, never production storage. */
require('reflect-metadata');
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {execFileSync}=require('node:child_process'),request=require('supertest'),{NestFactory}=require('@nestjs/core');
const root=process.cwd(),directory=fs.mkdtempSync(path.join(root,'data/qa/question-teaching-live-'));
Object.assign(process.env,{NODE_ENV:'development',STUDY_STORAGE:'sqlite',STUDY_DATA_DIR:directory,STUDY_WORKER_ENABLED:'false',STUDY_SEED_FOUNDATION:'false',XIAOJIU_CHAT_ENABLED:'true'});
delete process.env.DATABASE_URL;delete process.env.E2E_SOURCE_COURSE_SNAPSHOT;
const load=name=>require(path.join(root,'apps/api/dist/apps/api/src',name+'.js'));
const {whiteboardPresentation,classroomBoardProgress}=require(path.join(root,'packages/contracts/dist'));
const receipt={at:new Date().toISOString(),scope:'One real DeepSeek V4.1 Flash structured supplementary answer and one real configured MiniMax sentence through authenticated HTTP; synthetic adult original only. Not all-model, listening, visual or teaching quality acceptance.',phases:[]};
let app;
(async()=>{try{
  const started=Date.now();app=await NestFactory.create(load('app.module').AppModule,{logger:false});app.setGlobalPrefix('api');await app.init();
  const store=app.get(load('infrastructure/in-memory-store.service').InMemoryStoreService),worker=app.get(load('modules/learning/whiteboard-question-worker.service').WhiteboardQuestionWorkerService);
  const speech=app.get(load('modules/ai/speech.service').SpeechService).capabilities();assert.equal(speech.provider,'minimax');assert.ok(speech.defaultVoice);
  async function call(method,url,body,token){let query=request(app.getHttpServer())[method]('/api'+url);if(token)query=query.set('Authorization','Bearer '+token);if(body!==undefined)query=query.send(body);const response=await query;assert.ok(response.status<300,'HTTP '+response.status+' at '+url);return response.body.data;}
  const actor=await call('post','/auth/register',{principal:'question-live-'+crypto.randomUUID()+'@local.test',credential:'Synthetic-live-only-'+crypto.randomUUID()});
  const now=new Date().toISOString(),id='live-adult-'+crypto.randomUUID(),original={id,studentId:null,subject:null,title:'匿名成人学习：比较长度',prompt:'解释为什么比较长度要统一单位',
    scenes:[{id:'comparison',kind:'concept',title:'同一尺度',narration:'比较两段长度时，先统一计量单位。',body:'用同一个计量单位表达长度，再比较数值。',bullets:['先统一计量单位'],targetAtomIds:[],durationMs:2000}],
    width:1280,height:720,durationMs:2000,fingerprint:crypto.createHash('sha256').update(id).digest('hex'),createdAt:now,updatedAt:now,kind:'ai-topic-whiteboard',ownerUserId:actor.user.id,sourceDraftId:'fixture-'+id,
    origin:{draftId:null,modelId:'deepseek-v4-flash',modelName:'DeepSeek V4.1 Flash',review:null,teacherReviewStatus:'pending',formalMeasurementEligible:false}};
  await store.transaction(()=>store.append('studioTopicWhiteboards',original));const before=JSON.stringify(original),unit=whiteboardPresentation(original).units[0],base='/learning/studio/topic-whiteboards/'+id+'/questions';
  const context=await call('get',base+'/context?fingerprint='+original.fingerprint+'&unitId='+encodeURIComponent(unit.id),undefined,actor.token);
  const turn=await call('post',base,{fingerprint:original.fingerprint,unitId:unit.id,contextVersion:context.contextVersion,modelId:'deepseek-v4-flash',intent:'compare',message:'请用两到三句中文、一个两行对比表和一个完整换算公式，讲清为什么两米和一百厘米要先统一单位。请保持简短。',requestKey:crypto.randomUUID(),bookmark:{progress:0,audioTime:null,mode:'text',voice:'',speed:1}},actor.token);
  assert.equal(await worker.runNext(),true);const completed=await call('get',base+'/'+turn.id,undefined,actor.token);
  assert.equal(completed.status,'completed');assert.equal(completed.reply.modelId,'deepseek-v4-flash');assert.ok(completed.reply.board);assert.ok(completed.reply.board.table);assert.ok(completed.reply.board.formulas.length);
  assert.equal(classroomBoardProgress(completed.reply.board,completed.reply.speech).mode,'verified');receipt.phases.push({phase:'real-structured-answer',passed:true,elapsedMs:Date.now()-started,modelId:completed.reply.modelId,result:completed.reply});
  const board=await call('get',base+'/'+turn.id+'/board',undefined,actor.token),answerUnit=whiteboardPresentation(board).units[0],audioStarted=Date.now();
  const response=await request(app.getHttpServer()).post('/api'+base+'/'+turn.id+'/board/narration/'+answerUnit.sceneId).set('Authorization','Bearer '+actor.token)
    .send({voice:speech.defaultVoice,presentationVersion:'whiteboard-speech-v1',fingerprint:board.fingerprint,replyFingerprint:board.replyFingerprint,unitId:answerUnit.id}).buffer(true)
    .parse((res,done)=>{const chunks=[];res.on('data',chunk=>chunks.push(chunk));res.on('end',()=>done(null,Buffer.concat(chunks)));});
  assert.equal(response.status,201);assert.equal(response.headers['x-whiteboard-fingerprint'],board.fingerprint);assert.equal(response.headers['x-whiteboard-unit'],answerUnit.id);assert.equal(response.body.subarray(0,4).toString(),'RIFF');
  const audioPath=path.join(directory,'answer-sentence.wav');fs.writeFileSync(audioPath,response.body);const probe=JSON.parse(execFileSync(process.env.STUDY_FFPROBE||'ffprobe',['-v','error','-show_format','-show_streams','-of','json',audioPath],{encoding:'utf8',windowsHide:true}));
  assert.ok(probe.streams.some(stream=>stream.codec_type==='audio'));assert.ok(Number(probe.format.duration)>0);
  receipt.phases.push({phase:'real-authenticated-minimax-sentence',passed:true,elapsedMs:Date.now()-audioStarted,voice:speech.defaultVoice,text:answerUnit.text,bytes:response.body.length,sha256:crypto.createHash('sha256').update(response.body).digest('hex'),durationSeconds:Number(probe.format.duration),codec:probe.streams[0].codec_name});
  assert.equal(JSON.stringify(await store.requestContext(()=>store.find('studioTopicWhiteboards',{id}))),before);receipt.passed=true;receipt.elapsedMs=Date.now()-started;
}catch(error){receipt.passed=false;receipt.failureType=error?.constructor?.name||'Error';receipt.failureCode=error?.code||null;process.exitCode=1;}
finally{await app?.close();fs.writeFileSync(path.join(directory,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({directory,passed:receipt.passed,phases:receipt.phases.map(({phase,passed,elapsedMs})=>({phase,passed,elapsedMs})),failureType:receipt.failureType,failureCode:receipt.failureCode}));}})();
