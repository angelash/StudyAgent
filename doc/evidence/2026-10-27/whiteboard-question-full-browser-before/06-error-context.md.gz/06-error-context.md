# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player
- Location: tests\e2e\topic-whiteboard.spec.ts:892:16

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('table')
Expected substring: "完整尾行条件"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('table') with timeout 15000ms
  - waiting for getByRole('table')

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - link "Home":
        - /url: /studio?view=home
        - text: 首页
      - link "Courses":
        - /url: /studio?view=courses
        - text: 课程
      - link "Calendar":
        - /url: /studio?view=calendar
        - text: 学习动态
      - link "History":
        - /url: /studio?view=history
        - text: 历史
      - link "Materials":
        - /url: /studio?view=materials
        - text: 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom
    - heading "近期活动" [level=2]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页 →":
      - /url: /learn?subject=math
  - text: WHITEBOARD STUDIO
  - heading "从一个问题开始，讲清每一步。" [level=1]
  - paragraph: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
  - link "返回学习工作台 →":
    - /url: /studio
  - complementary:
    - text: NEW BOARD
    - heading "这次想弄懂什么？" [level=2]
    - text: 学习对象
    - combobox "白板学习对象":
      - option "我自己 · 成人主题" [selected]
    - region "新建AI白板":
      - group:
        - text: 讲解主题
        - textbox "讲解主题":
          - /placeholder: 例如：为什么先统一单位，才能比较和合并？
          - text: 用匿名观察解释条件与推断
        - text: 希望弄懂什么
        - textbox "希望弄懂什么":
          - /placeholder: 想理解的区别、步骤，或一个具体困惑
          - text: 保留完整条件，说明观察、推断和替代解释的区别。
        - text: 模型
        - combobox "选择大模型":
          - option "Auto · 当前默认模型"
      - status: 已恢复此标签页的原主题与模型选择。
      - button "预检主题与范围"
      - button "生成教学稿" [disabled]
      - button "下载原主题与请求"
      - group: 查看其他本机主题
  - region "白板工作区":
    - text: SAVED BOARD
    - heading "把条件讲清楚" [level=2]
    - paragraph: AI生成 · 待内容核对 · Browser fixture · not a real model
    - button "继续阅读"
    - button "查看自己的原稿"
    - dialog "白板视频":
      - button "关闭白板": ×
      - heading "把条件讲清楚" [level=2]
      - navigation "白板视图":
        - button "缩小白板": −
        - button "重置白板视图": 100%
        - button "放大白板": +
        - group "白板页码":
          - button "上一页白板" [disabled]: ‹
          - text: 1 / 1
          - button "下一页白板" [disabled]: ›
        - group "白板工具":
          - button "分享与导出"
          - button "白板设置"
        - button "收起讲稿与笔记" [expanded]
      - button "静音"
      - main:
        - paragraph: "[whiteboard-fixture] 先核对观察。"
        - text: 播放进度（估计阅读）
        - slider "播放进度（估计阅读）": "0"
        - button "上一句" [disabled]: ←
        - button "播放": ▶
        - button "下一句": →
        - text: 1 / 6 句
        - combobox "阅读方式":
          - option "文字阅读（估计时长）"
          - option "云语音逐句播放" [selected]
        - combobox "旁白音色":
          - option "合成音轨 A" [selected]
        - combobox "播放速度":
          - option "0.5×"
          - option "0.75×"
          - option "1×" [selected]
          - option "1.25×"
          - option "1.5×"
          - option "2×"
        - text: 板书字体
        - combobox "板书字体":
          - option "手写板书" [selected]
          - option "标准板书"
        - checkbox "点阵" [checked]
        - text: 点阵
        - button "导出视频"
        - button "导出字幕"
        - status
        - button "01 先核对观察"
        - button "02 再比较条件"
        - button "03 最后保留反例"
      - separator "调整讲稿面板宽度"
      - complementary "完整讲稿与要点":
        - button "收起讲稿与笔记"
        - region "原句提问":
          - heading "一起想清楚" [level=3]
          - text: AI补充讲解
          - group: 带走完整教学笔记
          - paragraph: 哪里没听懂，就从那一句问起。
          - text: 向老师提问
          - textbox "向老师提问":
            - /placeholder: 对这句有疑问？
          - combobox "讲解方式":
            - option "问一个问题" [selected]
            - option "换个例子"
            - option "讲简单些"
            - option "补补基础"
            - option "对比理解"
          - combobox "选择大模型":
            - option "Auto · 当前默认模型"
          - button "发送" [disabled]
          - group:
            - text: 保留与恢复提问
            - button "下载完整提问副本"
            - button "查看其他本机输入"
            - text: 导入完整提问副本
            - button "导入完整提问副本"
        - heading "逐句讲稿" [level=3]
        - paragraph: 点击一句定位。观看与续播不计作掌握。
        - list:
          - listitem:
            - button "[whiteboard-fixture] 先核对观察。"
          - listitem:
            - button "保留未知条件，不把一次观察当成完整能力证明。"
          - listitem:
            - button "[whiteboard-fixture] 再比较条件。"
          - listitem:
            - button "保留未知条件，不把一次观察当成完整能力证明。"
          - listitem:
            - button "[whiteboard-fixture] 最后保留反例。"
          - listitem:
            - button "保留未知条件，不把一次观察当成完整能力证明。"
        - heading "完整笔记与来源" [level=3]
        - group:
          - text: 先核对观察
          - paragraph: 完整说明首行。完整说明尾行。
          - list:
            - listitem: 先核对观察
        - group: 再比较条件
        - group: 最后保留反例
        - paragraph: AI生成 · 待内容核对 · Browser fixture · not a real model
        - button "下载续播位置"
  - complementary "白板与候选历史":
    - heading "我的白板" [level=2]
    - button "＋ 新白板"
    - button "教学草稿" [pressed]
    - button "已保存"
    - text: 搜索我的白板
    - textbox "搜索我的白板":
      - /placeholder: 搜索主题或标题
    - button "已保存白板 · 本人主题 把条件讲清楚 Browser fixture · not a real model"
    - button "上一页" [disabled]
    - text: 1 / 1
    - button "下一页" [disabled]
```

# Test source

```ts
      |                                                    ^ Error: expect(locator).toContainText(expected) failed
```