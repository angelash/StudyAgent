# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-panels.spec.ts >> course panels: references and all activities preserve the unit outline, complete titles and keyboard focus at 768
- Location: tests\e2e\course-panels.spec.ts:21:49

# Error details

```
Error: micro-lesson titles must retain readable inline space

expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 120
Received:    48
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - link "Home" [ref=f1e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f1e13]: 首页
        - link "Courses" [ref=f1e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f1e17]: 课程
        - link "Calendar" [ref=f1e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f1e21]: 学习动态
        - link "History" [ref=f1e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f1e25]: 历史
        - link "Materials" [ref=f1e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e29]: 资料
        - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f1e33]: AI白板
      - generic [ref=f1e34]:
        - heading "继续学习" [level=2] [ref=f1e35]
        - link "讲座社会学想象力 社会学概论" [ref=f1e36] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f1e37]: 社会学概论
      - heading "近期活动" [level=2] [ref=f1e39]
      - link "返回学习首页 →" [ref=f1e41] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f1e42]:
      - complementary [ref=f1e43]:
        - link "× 退出课程" [ref=f1e44] [cursor=pointer]:
          - /url: /studio?view=courses
          - text: ×
          - generic [ref=f1e45]: 退出课程
        - img "由阶梯与拱门构成的课程封面" [ref=f1e46]
        - generic [ref=f1e66]:
          - generic [ref=f1e67]: S
          - generic [ref=f1e68]:
            - generic [ref=f1e69]: 策划自
            - generic [ref=f1e70]: StudyAgent Learning Studio
        - heading "社会学概论" [level=1] [ref=f1e71]
        - paragraph [ref=f1e72]: 从自己的生活出发，看见文化、关系和制度如何共同塑造社会。五个单元串起概念、案例、练习与一个持续推进的社区研究。
        - group [ref=f1e73]:
          - generic "显示更多" [ref=f1e74] [cursor=pointer]
        - generic [ref=f1e75]:
          - generic [ref=f1e76]: 面板
          - tablist "课程面板" [ref=f1e77]:
            - tab "单元" [ref=f1e78] [cursor=pointer]
            - tab "资料" [ref=f1e79] [cursor=pointer]
            - tab "练习" [active] [selected] [ref=f1e80] [cursor=pointer]
          - tabpanel "练习" [ref=f1e81]:
            - generic [ref=f1e82]:
              - button "社会学想象力 单元 1 · Practice" [ref=f1e83] [cursor=pointer]:
                - generic [ref=f1e84]:
                  - generic [ref=f1e85]: 社会学想象力
                  - generic [ref=f1e86]: 单元 1 · Practice
              - button "结构与能动性 单元 1 · Practice" [ref=f1e87] [cursor=pointer]:
                - generic [ref=f1e88]:
                  - generic [ref=f1e89]: 结构与能动性
                  - generic [ref=f1e90]: 单元 1 · Practice
              - button "社会事实 单元 1 · Practice" [ref=f1e91] [cursor=pointer]:
                - generic [ref=f1e92]:
                  - generic [ref=f1e93]: 社会事实
                  - generic [ref=f1e94]: 单元 1 · Practice
              - button "社会学与日常生活 单元 1 · Practice" [ref=f1e95] [cursor=pointer]:
                - generic [ref=f1e96]:
                  - generic [ref=f1e97]: 社会学与日常生活
                  - generic [ref=f1e98]: 单元 1 · Practice
              - button "功能主义 单元 1 · Practice" [ref=f1e99] [cursor=pointer]:
                - generic [ref=f1e100]:
                  - generic [ref=f1e101]: 功能主义
                  - generic [ref=f1e102]: 单元 1 · Practice
              - button "冲突论 单元 1 · Practice" [ref=f1e103] [cursor=pointer]:
                - generic [ref=f1e104]:
                  - generic [ref=f1e105]: 冲突论
                  - generic [ref=f1e106]: 单元 1 · Practice
              - button "符号互动论 单元 1 · Practice" [ref=f1e107] [cursor=pointer]:
                - generic [ref=f1e108]:
                  - generic [ref=f1e109]: 符号互动论
                  - generic [ref=f1e110]: 单元 1 · Practice
              - button "当代社会学理论 单元 1 · Practice" [ref=f1e111] [cursor=pointer]:
                - generic [ref=f1e112]:
                  - generic [ref=f1e113]: 当代社会学理论
                  - generic [ref=f1e114]: 单元 1 · Practice
              - button "问卷调查与抽样 单元 1 · Practice" [ref=f1e115] [cursor=pointer]:
                - generic [ref=f1e116]:
                  - generic [ref=f1e117]: 问卷调查与抽样
                  - generic [ref=f1e118]: 单元 1 · Practice
              - button "实验与实地研究 单元 1 · Practice" [ref=f1e119] [cursor=pointer]:
                - generic [ref=f1e120]:
                  - generic [ref=f1e121]: 实验与实地研究
                  - generic [ref=f1e122]: 单元 1 · Practice
              - button "民族志与访谈 单元 1 · Practice" [ref=f1e123] [cursor=pointer]:
                - generic [ref=f1e124]:
                  - generic [ref=f1e125]: 民族志与访谈
                  - generic [ref=f1e126]: 单元 1 · Practice
              - button "测量、因果关系与伦理 单元 1 · Practice" [ref=f1e127] [cursor=pointer]:
                - generic [ref=f1e128]:
                  - generic [ref=f1e129]: 测量、因果关系与伦理
                  - generic [ref=f1e130]: 单元 1 · Practice
              - link "研究问题与方法设计 单元 1 · Project" [ref=f1e131] [cursor=pointer]:
                - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=practices
                - generic [ref=f1e132]:
                  - generic [ref=f1e133]: 研究问题与方法设计
                  - generic [ref=f1e134]: 单元 1 · Project
              - button "社会学视角综合核查 单元 1 · Unit Check" [ref=f1e135] [cursor=pointer]:
                - generic [ref=f1e136]:
                  - generic [ref=f1e137]: 社会学视角综合核查
                  - generic [ref=f1e138]: 单元 1 · Unit Check
              - button "规范与价值观 单元 2 · Practice" [ref=f1e139] [cursor=pointer]:
                - generic [ref=f1e140]:
                  - generic [ref=f1e141]: 规范与价值观
                  - generic [ref=f1e142]: 单元 2 · Practice
              - button "符号与语言 单元 2 · Practice" [ref=f1e143] [cursor=pointer]:
                - generic [ref=f1e144]:
                  - generic [ref=f1e145]: 符号与语言
                  - generic [ref=f1e146]: 单元 2 · Practice
              - button "亚文化与反文化 单元 2 · Practice" [ref=f1e147] [cursor=pointer]:
                - generic [ref=f1e148]:
                  - generic [ref=f1e149]: 亚文化与反文化
                  - generic [ref=f1e150]: 单元 2 · Practice
              - button "文化资本与变迁 单元 2 · Practice" [ref=f1e151] [cursor=pointer]:
                - generic [ref=f1e152]:
                  - generic [ref=f1e153]: 文化资本与变迁
                  - generic [ref=f1e154]: 单元 2 · Practice
              - button "社会化主体 单元 2 · Practice" [ref=f1e155] [cursor=pointer]:
                - generic [ref=f1e156]:
                  - generic [ref=f1e157]: 社会化主体
                  - generic [ref=f1e158]: 单元 2 · Practice
              - button "生命历程中的社会化 单元 2 · Practice" [ref=f1e159] [cursor=pointer]:
                - generic [ref=f1e160]:
                  - generic [ref=f1e161]: 生命历程中的社会化
                  - generic [ref=f1e162]: 单元 2 · Practice
              - button "角色与身份 单元 2 · Practice" [ref=f1e163] [cursor=pointer]:
                - generic [ref=f1e164]:
                  - generic [ref=f1e165]: 角色与身份
                  - generic [ref=f1e166]: 单元 2 · Practice
              - button "自我的呈现 单元 2 · Practice" [ref=f1e167] [cursor=pointer]:
                - generic [ref=f1e168]:
                  - generic [ref=f1e169]: 自我的呈现
                  - generic [ref=f1e170]: 单元 2 · Practice
              - button "首属群体与次属群体 单元 2 · Practice" [ref=f1e171] [cursor=pointer]:
                - generic [ref=f1e172]:
                  - generic [ref=f1e173]: 首属群体与次属群体
                  - generic [ref=f1e174]: 单元 2 · Practice
              - button "组织与官僚制 单元 2 · Practice" [ref=f1e175] [cursor=pointer]:
                - generic [ref=f1e176]:
                  - generic [ref=f1e177]: 组织与官僚制
                  - generic [ref=f1e178]: 单元 2 · Practice
              - button "社会网络 单元 2 · Practice" [ref=f1e179] [cursor=pointer]:
                - generic [ref=f1e180]:
                  - generic [ref=f1e181]: 社会网络
                  - generic [ref=f1e182]: 单元 2 · Practice
              - button "社会资本 单元 2 · Practice" [ref=f1e183] [cursor=pointer]:
                - generic [ref=f1e184]:
                  - generic [ref=f1e185]: 社会资本
                  - generic [ref=f1e186]: 单元 2 · Practice
              - link "文化与互动观察笔记 单元 2 · Project" [ref=f1e187] [cursor=pointer]:
                - /url: /studio/projects?unitId=soc-u2&returnUnit=1&returnPanel=practices
                - generic [ref=f1e188]:
                  - generic [ref=f1e189]: 文化与互动观察笔记
                  - generic [ref=f1e190]: 单元 2 · Project
              - button "文化与自我综合核查 单元 2 · Unit Check" [ref=f1e191] [cursor=pointer]:
                - generic [ref=f1e192]:
                  - generic [ref=f1e193]: 文化与自我综合核查
                  - generic [ref=f1e194]: 单元 2 · Unit Check
              - button "社会分层体系 单元 3 · Practice" [ref=f1e195] [cursor=pointer]:
                - generic [ref=f1e196]:
                  - generic [ref=f1e197]: 社会分层体系
                  - generic [ref=f1e198]: 单元 3 · Practice
              - button "现代社会中的阶级 单元 3 · Practice" [ref=f1e199] [cursor=pointer]:
                - generic [ref=f1e200]:
                  - generic [ref=f1e201]: 现代社会中的阶级
                  - generic [ref=f1e202]: 单元 3 · Practice
              - button "社会流动性 单元 3 · Practice" [ref=f1e203] [cursor=pointer]:
                - generic [ref=f1e204]:
                  - generic [ref=f1e205]: 社会流动性
                  - generic [ref=f1e206]: 单元 3 · Practice
              - button "贫困与生活机会 单元 3 · Practice" [ref=f1e207] [cursor=pointer]:
                - generic [ref=f1e208]:
                  - generic [ref=f1e209]: 贫困与生活机会
                  - generic [ref=f1e210]: 单元 3 · Practice
              - button "种族的社会建构 单元 3 · Practice" [ref=f1e211] [cursor=pointer]:
                - generic [ref=f1e212]:
                  - generic [ref=f1e213]: 种族的社会建构
                  - generic [ref=f1e214]: 单元 3 · Practice
              - button "偏见与歧视 单元 3 · Practice" [ref=f1e215] [cursor=pointer]:
                - generic [ref=f1e216]:
                  - generic [ref=f1e217]: 偏见与歧视
                  - generic [ref=f1e218]: 单元 3 · Practice
              - button "隔离 单元 3 · Practice" [ref=f1e219] [cursor=pointer]:
                - generic [ref=f1e220]:
                  - generic [ref=f1e221]: 隔离
                  - generic [ref=f1e222]: 单元 3 · Practice
              - button "结构性不平等 单元 3 · Practice" [ref=f1e223] [cursor=pointer]:
                - generic [ref=f1e224]:
                  - generic [ref=f1e225]: 结构性不平等
                  - generic [ref=f1e226]: 单元 3 · Practice
              - button "性别作为一种社会结构 单元 3 · Practice" [ref=f1e227] [cursor=pointer]:
                - generic [ref=f1e228]:
                  - generic [ref=f1e229]: 性别作为一种社会结构
                  - generic [ref=f1e230]: 单元 3 · Practice
              - button "性别社会化 单元 3 · Practice" [ref=f1e231] [cursor=pointer]:
                - generic [ref=f1e232]:
                  - generic [ref=f1e233]: 性别社会化
                  - generic [ref=f1e234]: 单元 3 · Practice
              - button "工作、家庭与性别差异 单元 3 · Practice" [ref=f1e235] [cursor=pointer]:
                - generic [ref=f1e236]:
                  - generic [ref=f1e237]: 工作、家庭与性别差异
                  - generic [ref=f1e238]: 单元 3 · Practice
              - button "性行为与社会 单元 3 · Practice" [ref=f1e239] [cursor=pointer]:
                - generic [ref=f1e240]:
                  - generic [ref=f1e241]: 性行为与社会
                  - generic [ref=f1e242]: 单元 3 · Practice
              - link "社区资源与障碍地图 单元 3 · Project" [ref=f1e243] [cursor=pointer]:
                - /url: /studio/projects?unitId=soc-u3&returnUnit=2&returnPanel=practices
                - generic [ref=f1e244]:
                  - generic [ref=f1e245]: 社区资源与障碍地图
                  - generic [ref=f1e246]: 单元 3 · Project
              - button "不平等综合核查 单元 3 · Unit Check" [ref=f1e247] [cursor=pointer]:
                - generic [ref=f1e248]:
                  - generic [ref=f1e249]: 不平等综合核查
                  - generic [ref=f1e250]: 单元 3 · Unit Check
              - button "家庭形式 单元 4 · Practice" [ref=f1e251] [cursor=pointer]:
                - generic [ref=f1e252]:
                  - generic [ref=f1e253]: 家庭形式
                  - generic [ref=f1e254]: 单元 4 · Practice
              - button "家庭变迁 单元 4 · Practice" [ref=f1e255] [cursor=pointer]:
                - generic [ref=f1e256]:
                  - generic [ref=f1e257]: 家庭变迁
                  - generic [ref=f1e258]: 单元 4 · Practice
              - button "学校教育与文凭主义 单元 4 · Practice" [ref=f1e259] [cursor=pointer]:
                - generic [ref=f1e260]:
                  - generic [ref=f1e261]: 学校教育与文凭主义
                  - generic [ref=f1e262]: 单元 4 · Practice
              - button "教育与不平等的再生产 单元 4 · Practice" [ref=f1e263] [cursor=pointer]:
                - generic [ref=f1e264]:
                  - generic [ref=f1e265]: 教育与不平等的再生产
                  - generic [ref=f1e266]: 单元 4 · Practice
              - button "劳动力市场 单元 4 · Practice" [ref=f1e267] [cursor=pointer]:
                - generic [ref=f1e268]:
                  - generic [ref=f1e269]: 劳动力市场
                  - generic [ref=f1e270]: 单元 4 · Practice
              - button "职场变迁 单元 4 · Practice" [ref=f1e271] [cursor=pointer]:
                - generic [ref=f1e272]:
                  - generic [ref=f1e273]: 职场变迁
                  - generic [ref=f1e274]: 单元 4 · Practice
              - button "消费 单元 4 · Practice" [ref=f1e275] [cursor=pointer]:
                - generic [ref=f1e276]:
                  - generic [ref=f1e277]: 消费
                  - generic [ref=f1e278]: 单元 4 · Practice
              - button "资本主义与全球化 单元 4 · Practice" [ref=f1e279] [cursor=pointer]:
                - generic [ref=f1e280]:
                  - generic [ref=f1e281]: 资本主义与全球化
                  - generic [ref=f1e282]: 单元 4 · Practice
              - button "宗教与社会 单元 4 · Practice" [ref=f1e283] [cursor=pointer]:
                - generic [ref=f1e284]:
                  - generic [ref=f1e285]: 宗教与社会
                  - generic [ref=f1e286]: 单元 4 · Practice
              - button "世俗化 单元 4 · Practice" [ref=f1e287] [cursor=pointer]:
                - generic [ref=f1e288]:
                  - generic [ref=f1e289]: 世俗化
                  - generic [ref=f1e290]: 单元 4 · Practice
              - button "媒体与技术 单元 4 · Practice" [ref=f1e291] [cursor=pointer]:
                - generic [ref=f1e292]:
                  - generic [ref=f1e293]: 媒体与技术
                  - generic [ref=f1e294]: 单元 4 · Practice
              - button "健康差异 单元 4 · Practice" [ref=f1e295] [cursor=pointer]:
                - generic [ref=f1e296]:
                  - generic [ref=f1e297]: 健康差异
                  - generic [ref=f1e298]: 单元 4 · Practice
              - link "制度影响分析 单元 4 · Project" [ref=f1e299] [cursor=pointer]:
                - /url: /studio/projects?unitId=soc-u4&returnUnit=3&returnPanel=practices
                - generic [ref=f1e300]:
                  - generic [ref=f1e301]: 制度影响分析
                  - generic [ref=f1e302]: 单元 4 · Project
              - button "制度综合核查 单元 4 · Unit Check" [ref=f1e303] [cursor=pointer]:
                - generic [ref=f1e304]:
                  - generic [ref=f1e305]: 制度综合核查
                  - generic [ref=f1e306]: 单元 4 · Unit Check
              - button "定义越轨 单元 5 · Practice" [ref=f1e307] [cursor=pointer]:
                - generic [ref=f1e308]:
                  - generic [ref=f1e309]: 定义越轨
                  - generic [ref=f1e310]: 单元 5 · Practice
              - button "偏离理论 单元 5 · Practice" [ref=f1e311] [cursor=pointer]:
                - generic [ref=f1e312]:
                  - generic [ref=f1e313]: 偏离理论
                  - generic [ref=f1e314]: 单元 5 · Practice
              - button "犯罪 单元 5 · Practice" [ref=f1e315] [cursor=pointer]:
                - generic [ref=f1e316]:
                  - generic [ref=f1e317]: 犯罪
                  - generic [ref=f1e318]: 单元 5 · Practice
              - button "惩罚与司法系统 单元 5 · Practice" [ref=f1e319] [cursor=pointer]:
                - generic [ref=f1e320]:
                  - generic [ref=f1e321]: 惩罚与司法系统
                  - generic [ref=f1e322]: 单元 5 · Practice
              - button "人口统计学 单元 5 · Practice" [ref=f1e323] [cursor=pointer]:
                - generic [ref=f1e324]:
                  - generic [ref=f1e325]: 人口统计学
                  - generic [ref=f1e326]: 单元 5 · Practice
              - button "人口迁移 单元 5 · Practice" [ref=f1e327] [cursor=pointer]:
                - generic [ref=f1e328]:
                  - generic [ref=f1e329]: 人口迁移
                  - generic [ref=f1e330]: 单元 5 · Practice
              - button "老龄化社会 单元 5 · Practice" [ref=f1e331] [cursor=pointer]:
                - generic [ref=f1e332]:
                  - generic [ref=f1e333]: 老龄化社会
                  - generic [ref=f1e334]: 单元 5 · Practice
              - button "城市化与社区 单元 5 · Practice" [ref=f1e335] [cursor=pointer]:
                - generic [ref=f1e336]:
                  - generic [ref=f1e337]: 城市化与社区
                  - generic [ref=f1e338]: 单元 5 · Practice
              - button "社会运动 单元 5 · Practice" [ref=f1e339] [cursor=pointer]:
                - generic [ref=f1e340]:
                  - generic [ref=f1e341]: 社会运动
                  - generic [ref=f1e342]: 单元 5 · Practice
              - button "集体行动 单元 5 · Practice" [ref=f1e343] [cursor=pointer]:
                - generic [ref=f1e344]:
                  - generic [ref=f1e345]: 集体行动
                  - generic [ref=f1e346]: 单元 5 · Practice
              - button "技术与社会变迁 单元 5 · Practice" [ref=f1e347] [cursor=pointer]:
                - generic [ref=f1e348]:
                  - generic [ref=f1e349]: 技术与社会变迁
                  - generic [ref=f1e350]: 单元 5 · Practice
              - button "环境与社会的未来 单元 5 · Practice" [ref=f1e351] [cursor=pointer]:
                - generic [ref=f1e352]:
                  - generic [ref=f1e353]: 环境与社会的未来
                  - generic [ref=f1e354]: 单元 5 · Practice
              - link "变革提案与最终报告 单元 5 · Project" [ref=f1e355] [cursor=pointer]:
                - /url: /studio/projects?unitId=soc-u5&returnUnit=4&returnPanel=practices
                - generic [ref=f1e356]:
                  - generic [ref=f1e357]: 变革提案与最终报告
                  - generic [ref=f1e358]: 单元 5 · Project
              - button "越轨与社会变迁综合核查 单元 5 · Unit Check" [ref=f1e359] [cursor=pointer]:
                - generic [ref=f1e360]:
                  - generic [ref=f1e361]: 越轨与社会变迁综合核查
                  - generic [ref=f1e362]: 单元 5 · Unit Check
      - generic [ref=f1e363]:
        - generic [ref=f1e364]:
          - generic [ref=f1e365]: 第 1 单元，共 5 单元
          - heading "单元 1：社会学视角" [level=2] [ref=f1e366]
          - paragraph [ref=f1e367]: 把个人经验放回社会背景，比较理论解释并设计可检验的研究。
        - link "▤ 把自己的资料带进课堂 PDF、页级阅读、个性化学案与白板 ↗" [ref=f1e368] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e369]: ▤
          - generic [ref=f1e370]:
            - generic [ref=f1e371]: 把自己的资料带进课堂
            - generic [ref=f1e372]: PDF、页级阅读、个性化学案与白板
          - generic [ref=f1e373]: ↗
        - generic [ref=f1e374]:
          - generic [ref=f1e375]:
            - generic "讲解已读" [ref=f1e376]: ✓
            - text: 讲解已读
          - generic [ref=f1e377]:
            - generic "已接触" [ref=f1e378]
            - text: 已接触
          - generic [ref=f1e379]:
            - generic "未开始" [ref=f1e380]
            - text: 未开始
          - generic [ref=f1e381]: ▣ Project
          - generic [ref=f1e382]: ♙ Exam
        - generic [ref=f1e383]:
          - generic [ref=f1e384]:
            - button "未开始" [ref=f1e385] [cursor=pointer]
            - button "未开始" [ref=f1e387] [cursor=pointer]
            - button "未开始" [ref=f1e389] [cursor=pointer]
            - button "未开始" [ref=f1e391] [cursor=pointer]
            - button "未开始" [ref=f1e393] [cursor=pointer]
            - button "未开始" [ref=f1e395] [cursor=pointer]
            - button "未开始" [ref=f1e397] [cursor=pointer]
            - button "未开始" [ref=f1e399] [cursor=pointer]
            - button "未开始" [ref=f1e401] [cursor=pointer]
            - button "未开始" [ref=f1e403] [cursor=pointer]
            - button "未开始" [ref=f1e405] [cursor=pointer]
            - button "未开始" [ref=f1e407] [cursor=pointer]
            - link "▣" [ref=f1e409] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=practices
            - button "♙" [ref=f1e410] [cursor=pointer]
          - button "▶ 下一步：社会学想象力 ›" [ref=f1e411] [cursor=pointer]:
            - text: ▶
            - generic [ref=f1e412]: 下一步：社会学想象力
            - text: ›
        - group "本单元学习进程" [ref=f1e413]:
          - generic "学习进程 · 本单元" [ref=f1e414] [cursor=pointer]
        - generic [ref=f1e415]:
          - article [ref=f1e416]:
            - button "讲次 1：社会学思考" [expanded] [ref=f1e418] [cursor=pointer]
            - paragraph [ref=f1e419]: 围绕社会学思考，通过四段微课完成概念辨析与情境应用。
            - generic [ref=f1e420]:
              - generic [ref=f1e421]:
                - generic [ref=f1e422]:
                  - text: 社会学想象力
                  - button "查看学习目标：社会学想象力" [ref=f1e423] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e424] [cursor=pointer]
                - button "♧ 练习" [ref=f1e425] [cursor=pointer]
              - generic [ref=f1e426]:
                - generic [ref=f1e427]:
                  - text: 结构与能动性
                  - button "查看学习目标：结构与能动性" [ref=f1e428] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e429] [cursor=pointer]
                - button "♧ 练习" [ref=f1e430] [cursor=pointer]
              - generic [ref=f1e431]:
                - generic [ref=f1e432]:
                  - text: 社会事实
                  - button "查看学习目标：社会事实" [ref=f1e433] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e434] [cursor=pointer]
                - button "♧ 练习" [ref=f1e435] [cursor=pointer]
              - generic [ref=f1e436]:
                - generic [ref=f1e437]:
                  - text: 社会学与日常生活
                  - button "查看学习目标：社会学与日常生活" [ref=f1e438] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e439] [cursor=pointer]
                - button "♧ 练习" [ref=f1e440] [cursor=pointer]
          - article [ref=f1e441]:
            - button "讲次 2：理论传统" [ref=f1e443] [cursor=pointer]
            - paragraph [ref=f1e444]: 围绕理论传统，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e445]:
            - button "讲次 3：研究方法" [ref=f1e447] [cursor=pointer]
            - paragraph [ref=f1e448]: 围绕研究方法，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e449]:
            - generic [ref=f1e450]: PROJECT · 1 / 5
            - heading "研究问题与方法设计" [level=3] [ref=f1e451]
            - paragraph [ref=f1e452]: 选择一个社区现象，写出研究问题、调查对象、方法与保护参与者的办法。
            - link "开始项目 →" [ref=f1e453] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=practices
          - article [ref=f1e454]:
            - text: UNIT CHECK
            - heading "社会学视角综合核查" [level=3] [ref=f1e455]
            - paragraph [ref=f1e456]: 覆盖本单元的 12 个主题，12 道新情境题保留首次作答、跳过与提示记录。
            - button "Start →" [ref=f1e457] [cursor=pointer]
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { createHash } from 'node:crypto';
  3  | import { browserEvidence } from './evidence';
  4  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  5  | const evidence = browserEvidence('course-panels');
  6  | async function enter(page: Page, width = 1280) {
  7  |   await page.setViewportSize({ width, height: width === 390 ? 844 : 900 });
  8  |   const nonce = crypto.randomUUID(), principal = 'course-panel-' + nonce + '@local.test', credential = 'Panel-QA-' + nonce;
  9  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  10 |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  11 |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': address }, body: JSON.stringify({ principal, credential }) });
  12 |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  13 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  14 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  15 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  16 |   await page.goto('/studio/classroom?unit=0&panel=units');
  17 |   await expect(page.locator('.cl-lecture')).toHaveCount(5);
  18 |   const read = async (path: string) => { const response = await fetch(api + path, { headers: { Authorization: 'Bearer ' + actor.token, 'X-Forwarded-For': address } }); expect(response.ok).toBe(true); return (await response.json()).data; };
  19 |   return { read };
  20 | }
  21 | for (const width of [390, 768, 1280, 1440]) test(`course panels: references and all activities preserve the unit outline, complete titles and keyboard focus at ${width}`, async ({ page }) => {
  22 |   await enter(page, width);
  23 |   const first = page.locator('.cl-lecture').first(); await expect(first.getByRole('button').first()).toHaveAttribute('aria-expanded', 'true');
  24 |   const units = page.getByRole('tab', { name: '单元', exact: true }); await units.focus(); await page.keyboard.press('ArrowRight');
  25 |   await expect(page.getByRole('tab', { name: '资料', exact: true })).toBeFocused();
  26 |   await expect(page.getByRole('tabpanel', { name: '资料', exact: true })).toContainText('延伸阅读');
  27 |   await expect(page.locator('.cl-lecture')).toHaveCount(5); await expect(first.getByRole('button').first()).toHaveAttribute('aria-expanded', 'true');
  28 |   await page.keyboard.press('End'); await expect(page.getByRole('tab', { name: '练习', exact: true })).toBeFocused();
  29 |   const practices = page.getByRole('tabpanel', { name: '练习', exact: true }); await expect(practices.locator('.cl-panel-activity')).toHaveCount(70);
  30 |   await expect(practices).toContainText('单元 5 · Unit Check');
  31 |   await expect(page.locator('.cl-lecture')).toHaveCount(5);
  32 |   const titleBoxes = await page.locator('.cl-microlessons .ws-micro-title').evaluateAll(nodes => nodes.map(node => node.getBoundingClientRect().width));
> 33 |   for (const titleWidth of titleBoxes) expect(titleWidth, 'micro-lesson titles must retain readable inline space').toBeGreaterThanOrEqual(120);
     |                                                                                                                    ^ Error: micro-lesson titles must retain readable inline space
  34 |   const last = practices.locator('.cl-panel-activity').last(); await last.scrollIntoViewIfNeeded();
  35 |   const box = await last.boundingBox(); expect(box!.x).toBeGreaterThanOrEqual(0); expect(box!.x + box!.width).toBeLessThanOrEqual(width);
  36 |   await page.screenshot({ path: evidence + '/activities-' + width + '.png', fullPage: true });
  37 |   await page.reload(); await expect(page.getByRole('tab', { name: '练习', exact: true })).toHaveAttribute('aria-selected', 'true');
  38 |   await expect(page.locator('.cl-lecture')).toHaveCount(5);
  39 | });
  40 | test('course panels: a cross-unit practice returns to its original panel and reopens the exact first answer after refresh', async ({ page }) => {
  41 |   const { read } = await enter(page), catalog = await read('/learning/classroom/catalog'), lesson = catalog.course.units[1].lectures[0].lessons[0];
  42 |   await page.getByRole('tab', { name: '练习', exact: true }).click();
  43 |   const entry = () => page.getByRole('tabpanel', { name: '练习', exact: true }).getByRole('button').filter({ hasText: lesson.title }).first();
  44 |   await entry().click(); await expect(page.getByRole('button', { name: 'Check →', exact: true })).toBeVisible();
  45 |   const original = new URL(page.url()).searchParams.get('session')!;
  46 |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →', exact: true }).click();
  47 |   await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  48 |   const saved = await read('/learning/classroom/sessions/' + original); expect(saved.answers).toHaveLength(1);
  49 |   await page.getByRole('button', { name: '关闭独立练习', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  50 |   await expect(page.getByRole('tab', { name: '练习', exact: true })).toHaveAttribute('aria-selected', 'true');
  51 |   await expect(page).toHaveURL(/unit=1/); await page.reload(); await entry().click();
  52 |   await expect(page.getByRole('button', { name: '第2题', exact: true })).toHaveAttribute('aria-current', 'step');
  53 |   expect(new URL(page.url()).searchParams.get('session')).toBe(original);
  54 |   await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  55 |   expect((await read('/learning/classroom/sessions/' + original)).answers).toEqual(saved.answers);
  56 | });
  57 | test('course panels: the actual cross-unit project returns to the same course panel and target unit', async ({ page }) => {
  58 |   const { read } = await enter(page), catalog = await read('/learning/classroom/catalog'), unit = catalog.course.units[2];
  59 |   await page.getByRole('tab', { name: '练习', exact: true }).click();
  60 |   await page.getByRole('tabpanel', { name: '练习', exact: true }).getByRole('link').filter({ hasText: unit.project.title }).click();
  61 |   await expect(page).toHaveURL(/\/studio\/projects\?/); expect(new URL(page.url()).searchParams.get('unitId')).toBe(unit.id);
  62 |   await page.getByRole('link', { name: '‹ 返回课程', exact: true }).click();
  63 |   await expect(page.getByRole('tab', { name: '练习', exact: true })).toHaveAttribute('aria-selected', 'true');
  64 |   expect(new URL(page.url()).searchParams.get('unit')).toBe('2');
  65 |   await expect(page.locator('.cl-unit-heading')).toContainText(unit.title);
  66 | });
  67 | test('course panels: the actual cross-unit check keeps its unit, original session and unanswered return after refresh', async ({ page }) => {
  68 |   const { read } = await enter(page), catalog = await read('/learning/classroom/catalog'), unit = catalog.course.units[3];
  69 |   await page.getByRole('tab', { name: '练习', exact: true }).click();
  70 |   const entry = () => page.getByRole('tabpanel', { name: '练习', exact: true }).getByRole('button').filter({ hasText: unit.title + '综合核查' });
  71 |   await entry().click(); await expect(page.getByRole('button', { name: 'Check →', exact: true })).toBeVisible();
  72 |   const original = new URL(page.url()).searchParams.get('session')!, row = await read('/learning/classroom/sessions/' + original);
  73 |   expect(row.lessonId).toBe('unit-exam:' + unit.id); expect(row.answers).toHaveLength(0);
  74 |   await page.getByRole('button', { name: '关闭独立练习', exact: true }).click(); await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  75 |   await expect(page.getByRole('tab', { name: '练习', exact: true })).toHaveAttribute('aria-selected', 'true');
  76 |   expect(new URL(page.url()).searchParams.get('unit')).toBe('3'); await page.reload(); await entry().click();
  77 |   await expect(page.getByRole('button', { name: '第1题', exact: true })).toHaveAttribute('aria-current', 'step');
  78 |   expect(new URL(page.url()).searchParams.get('session')).toBe(original); expect((await read('/learning/classroom/sessions/' + original)).answers).toEqual([]);
  79 | });
  80 | 
```