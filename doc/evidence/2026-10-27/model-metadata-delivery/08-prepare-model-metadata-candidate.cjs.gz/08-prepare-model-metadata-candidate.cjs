const fs = require('node:fs'), path = require('node:path'), zlib = require('node:zlib'), assert = require('node:assert/strict');
const { createHash } = require('node:crypto'), { execFileSync } = require('node:child_process');
const root = process.cwd(), branch = path.resolve(root, '../StudyAgent-model-qualification'), head = '10b0adac8de1344cf27654472ce49967e8f80d86', run = 40443714547;
const read = file => JSON.parse(fs.readFileSync(file, 'utf8')), hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const git = (args, cwd = root) => execFileSync('git', args, { cwd, encoding: 'utf8', windowsHide: true }).trim();
const inputFile = 'doc/evidence/2026-10-27/model-metadata-final-full-local/receipt.json', input = read(path.join(branch, inputFile));
assert.equal(input.applicationRevision, head); assert.equal(input.schemaVersion, 20); assert.equal(input.api.passed, 1456); assert.equal(input.api.environmentSkipped, 60); assert.equal(input.api.failed, 0);
assert.equal(input.models.passed, 21); assert.equal(input.models.failed, 1); assert.equal(input.models.allPassed, false); assert.equal(input.models.knownFailedId, 'claude-opus-5'); assert.equal(Object.keys(input.compiledSha256).length, 363);
assert.equal(git(['status', '--porcelain'], branch), ''); const deliveryHead = git(['rev-parse', 'HEAD'], branch);
git(['merge-base', '--is-ancestor', head, deliveryHead], branch);
assert(git(['diff', '--name-only', head, deliveryHead], branch).split(/\r?\n/).filter(Boolean).every(file => file.startsWith('doc/')));
for (const [file, expected] of Object.entries(input.sourceSha256)) assert.equal(hash(path.join(branch, file)), expected, 'Source changed: ' + file);
for (const [file, expected] of Object.entries(input.compiledSha256)) assert.equal(hash(path.join(branch, file)), expected, 'Compiled input changed: ' + file);
for (const [file, expected] of Object.entries(input.qaWeb.sourceSha256)) assert.equal(hash(path.join(branch, 'data/qa/experience-web', file)), expected, 'Actual QA Web changed: ' + file);
function browser(file) {
  const report = read(file), cases = []; const walk = suite => { for (const spec of suite.specs || []) cases.push(...spec.tests); for (const child of suite.suites || []) walk(child); }; report.suites.forEach(walk);
  assert.deepEqual([report.stats.expected, report.stats.unexpected, report.stats.flaky, report.stats.skipped, report.errors.length, cases.length], [365, 0, 0, 0, 0, 365]);
  assert(cases.every(test => test.results.length === 1 && test.results[0].status === 'passed'));
}
const local = path.join(branch, input.browser.source), remote = path.join(branch, 'data/qa/model-metadata-ci-40443714547-artifacts/data/qa/source-course-full-browser.json');
browser(local); browser(remote); assert.equal(hash(local), input.browser.sha256);
const api = read(path.join(branch, input.api.source)); assert(api.success && api.numPassedTests === 1456 && api.numPendingTests === 60 && api.numFailedTests === 0); assert.equal(hash(path.join(branch, input.api.source)), input.api.sha256);
const ci = JSON.parse(execFileSync('gh', ['run', 'view', String(run), '--json', 'status,conclusion,headSha,jobs'], { encoding: 'utf8', windowsHide: true }));
assert(ci.status === 'completed' && ci.conclusion === 'success' && ci.headSha === head && ci.jobs.length === 3 && ci.jobs.every(job => job.status === 'completed' && job.conclusion === 'success'));
const latest = read('data/qa/model-metadata-release-latest.json'), release = path.resolve(root, latest.folder), before = read(path.join(release, 'deployment-before.json'));
assert(release.startsWith(path.join(root, 'output/daemon/release-backups') + path.sep) && fs.realpathSync(release).toLowerCase() === release.toLowerCase());
assert.equal(git(['rev-parse', 'HEAD']), before.revision); assert(before.revision.startsWith('a3f8b3d')); assert.equal(before.oldWebBuildId, 'AtnQOxOLr47cjIP2lS6UN');
for (const [file, expected] of Object.entries(before.protectedFiles)) assert.equal(hash(file), expected, 'Protected configuration changed');
assert.equal(hash('.env'), hash(path.join(release, 'config/.env')));
for (const file of read(path.join(release, 'build-files.json'))) { assert.equal(hash(file.path), file.sha256, 'Original build changed'); assert.equal(hash(path.join(release, 'build', file.path)), file.sha256, 'Rollback copy changed'); }
const realModelsFile=path.join(branch,input.models.source),realModels=read(realModelsFile);assert.equal(hash(realModelsFile),input.models.sha256);assert(realModels.status==='complete'&&realModels.passed===false&&realModels.modelCount===22&&realModels.passedCount===21&&realModels.failedCount===1);assert.equal(realModels.models.find(row=>row.status==='failed').id,'claude-opus-5');
const modelArtifact='data/qa/model-metadata-real-models-original.json.gz';fs.writeFileSync(modelArtifact,zlib.gzipSync(fs.readFileSync(realModelsFile)),{flag:'wx'});
const artifact = 'data/qa/model-metadata-ci-40443714547-browser-original.json.gz'; fs.writeFileSync(artifact, zlib.gzipSync(fs.readFileSync(remote)), { flag: 'wx' });
const candidate = { status: 'ready-for-release', at: new Date().toISOString(), head, deliveryHead, applicationRevision: head, apiRevision: input.apiRevision, schemaVersion: 20,
  ciRun: run, verifiedZeroRetries: true, apiLocalPassed: 1456, apiLocalFailed: 0, apiEnvironmentSkipped: 60, localPostgresCases: null, remotePostgresJobSucceeded: true, realModelsPassed: 21, realModelsFailed: 1, allModelsPassed: false,
  localBrowserCases: 365, remoteBrowserCases: 365, inputReceipt: inputFile, inputReceiptSha256: hash(path.join(branch, inputFile)),
  browserArtifact: artifact, browserArtifactSha256: hash(artifact), originalBrowserSha256: hash(remote), localBrowserSha256: hash(local),
  compiledSha256: input.compiledSha256, formatOnlyCompiledDifferences: [], modelArtifact, modelArtifactSha256: hash(modelArtifact), originalModelsSha256: hash(realModelsFile) };
fs.writeFileSync(path.join(release, 'candidate.json'), JSON.stringify(candidate, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: candidate.status, ciHead: head, deliveryHead, localBrowser: 365, remoteBrowser: 365, compiledFiles: 363, localApi: 1456, realModelsPassed: 21, realModelsFailed: 1 }));
