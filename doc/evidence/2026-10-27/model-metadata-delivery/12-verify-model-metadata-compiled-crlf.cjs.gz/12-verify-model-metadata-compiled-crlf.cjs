const fs = require('node:fs'), path = require('node:path'), { createHash } = require('node:crypto'), assert = require('node:assert/strict');
const root = process.cwd(), branch = path.resolve(root, '../StudyAgent-model-qualification');
const latest = JSON.parse(fs.readFileSync('data/qa/model-metadata-release-latest.json', 'utf8')), release = path.resolve(root, latest.folder);
assert(release.startsWith(path.join(root, 'output/daemon/release-backups') + path.sep));
assert.equal(fs.realpathSync(release).toLowerCase(), release.toLowerCase());
const candidatePath = path.join(release, 'candidate.json'), candidate = JSON.parse(fs.readFileSync(candidatePath, 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const changes = Object.entries(candidate.compiledSha256).filter(([file, digest]) => sha(fs.readFileSync(path.join(root, file))) !== digest).map(([file]) => file);
assert.deepEqual(changes, ['apps/api/dist/apps/api/src/infrastructure/rate-limit-repository.js']);
const file = changes[0], original = fs.readFileSync(path.join(branch, file)), actual = fs.readFileSync(path.join(root, file));
assert.equal(sha(original), candidate.compiledSha256[file]);
const normalize = bytes => bytes.toString('utf8').replace(/\r\n/g, '\n');
assert.notDeepEqual(original, actual); assert.equal(normalize(original), normalize(actual));
const sourceFile = 'apps/api/src/infrastructure/rate-limit-repository.ts';
assert.equal(normalize(fs.readFileSync(path.join(root, sourceFile))), normalize(fs.readFileSync(path.join(branch, sourceFile))));
const row = { file, expectedSha256: sha(original), actualSha256: sha(actual), lfSha256: sha(Buffer.from(normalize(actual))),
  expectedCrlfCount: (original.toString('utf8').match(/\r\n/g) ?? []).length,
  actualCrlfCount: (actual.toString('utf8').match(/\r\n/g) ?? []).length, sourceFile,
  sourceNormalizedSha256: sha(Buffer.from(normalize(fs.readFileSync(path.join(root, sourceFile))))) };
fs.copyFileSync(candidatePath, path.join(release, 'candidate-strict-before-format-observation.json'), fs.constants.COPYFILE_EXCL);
fs.writeFileSync(path.join(release, 'compiled-crlf-observation.json'), JSON.stringify({ at: new Date().toISOString(), passed: true,
  exactRawMatches: 362, onlyDifference: row, originalStrictCheck: 'data/qa/model-metadata-runtime-check-first.log',
  scope: 'All363 complete compiled inputs checked. Only this exact file has four CRLF differences; source and complete normalized bytes match. Frozen candidate and original reports unchanged.' }, null, 2) + '\n', { flag: 'wx' });
candidate.formatOnlyCompiledDifferences = [row]; fs.writeFileSync(candidatePath, JSON.stringify(candidate, null, 2) + '\n');
console.log(JSON.stringify({ passed: true, exactRawMatches: 362, formatOnly: row }));
