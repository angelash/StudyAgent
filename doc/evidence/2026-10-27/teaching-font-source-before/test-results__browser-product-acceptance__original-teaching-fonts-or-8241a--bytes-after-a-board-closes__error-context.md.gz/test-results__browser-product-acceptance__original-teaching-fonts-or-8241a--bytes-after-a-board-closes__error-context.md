# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: original-teaching-fonts.spec.ts >> original fonts: captured math faces stay isolated and the real formula editor decodes its own local font bytes after a board closes
- Location: tests\e2e\original-teaching-fonts.spec.ts:97:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f3e1]:
  - main [ref=f3e2]:
    - generic [ref=f3e3]:
      - link "学习观察室" [ref=f3e4] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f3e5]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f3e6]:
        - link "学习首页" [ref=f3e7] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_c4d6f5c1-ae36-41e0-8f2e-974def05b56c
        - link "学习工作台" [ref=f3e8] [cursor=pointer]:
          - /url: /studio?subject=math&student=student_c4d6f5c1-ae36-41e0-8f2e-974def05b56c
        - link "家长空间" [ref=f3e9] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math&studentId=student_c4d6f5c1-ae36-41e0-8f2e-974def05b56c
        - link "知识诊断" [ref=f3e10] [cursor=pointer]:
          - /url: /student/assessment?subject=math&studentId=student_c4d6f5c1-ae36-41e0-8f2e-974def05b56c
        - link "今日学习" [ref=f3e11] [cursor=pointer]:
          - /url: /student/today?subject=math&studentId=student_c4d6f5c1-ae36-41e0-8f2e-974def05b56c
        - link "题卷资料" [ref=f3e12] [cursor=pointer]:
          - /url: /library?subject=math&studentId=student_c4d6f5c1-ae36-41e0-8f2e-974def05b56c
      - generic [ref=f3e13]:
        - link "资料管理" [ref=f3e14] [cursor=pointer]:
          - /url: /parent/data
        - button "退出" [ref=f3e15] [cursor=pointer]
    - generic [ref=f3e16]:
      - complementary [ref=f3e17]:
        - text: LEARNING / INSIGHT
        - heading [level=1] [ref=f3e18]:
          - text: 把知识
          - emphasis [ref=f3e19]: 学扎实。
        - paragraph [ref=f3e20]: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
        - list [ref=f3e21]:
          - listitem [ref=f3e22]:
            - generic [ref=f3e23]: "01"
            - text: 确认学习进度
          - listitem [ref=f3e24]:
            - generic [ref=f3e25]: "02"
            - text: 完成一组评测
          - listitem [ref=f3e26]:
            - generic [ref=f3e27]: "03"
            - text: 看懂知识与原因
          - listitem [ref=f3e28]:
            - generic [ref=f3e29]: "04"
            - text: 指导、复测与复盘
        - generic [ref=f3e30]:
          - generic [ref=f3e31]: 匿
          - generic [ref=f3e32]:
            - strong [ref=f3e33]: 匿名字体输入
            - generic [ref=f3e34]: 3年级 · 数学
        - button "返回学习进度与历史" [ref=f3e35] [cursor=pointer]
      - generic [ref=f3e36]:
        - generic [ref=f3e37]:
          - text: 02 / 一次只看一步
          - generic [ref=f3e38]:
            - heading "合成输入验收" [level=2] [ref=f3e39]
            - generic [ref=f3e40]: 1 / 4
          - paragraph [ref=f3e41]: 先独立想一想。暂时不会也可以如实记录。
        - progressbar "评测进度" [ref=f3e42]
        - generic [ref=f3e43]:
          - generic [ref=f3e44]:
            - generic [ref=f3e45]: 第1小组
            - generic [ref=f3e46]: 尚未填写
          - group "本题作答" [ref=f3e47]:
            - generic [ref=f3e49]:
              - generic [ref=f3e50]: 合成题型验收 formula_blank · 4
              - generic [ref=f3e52]:
                - strong [ref=f3e54]: 输入算式
                - generic [ref=f3e55]:
                  - generic "算式或公式答案" [active] [ref=f3e56]:
                    - generic [ref=f3e57]:
                      - textbox "算式或公式答案"
                      - generic [ref=f3e58]:
                        - generic [ref=f3e62]:
                          - text: (
                          - generic [ref=f3e66]:
                            - generic [ref=f3e67]:
                              - text: "y"
                              - generic [ref=f3e68]: "3"
                            - generic [ref=f3e74]:
                              - text: 1 +
                              - generic [ref=f3e75]:
                                - generic [ref=f3e76]: √
                                - generic [ref=f3e80]:
                                  - text: x
                                  - generic [ref=f3e81]: "2"
                                  - text: + 1
                          - text: )
                        - generic [ref=f3e93]:
                          - button [ref=f3e94] [cursor=pointer]:
                            - img "Toggle Virtual Keyboard" [ref=f3e95]
                            - text: Toggle Virtual Keyboard
                          - button [ref=f3e97] [cursor=pointer]:
                            - img "Menu" [ref=f3e98]
                            - text: Menu
                      - generic [ref=f3e100]:
                        - status
                  - generic [ref=f3e101]:
                    - text: LaTeX：
                    - code [ref=f3e102]: \square
          - generic [ref=f3e103]:
            - button "给我一点提示" [ref=f3e104] [cursor=pointer]
            - generic [ref=f3e105]:
              - button "暂时不会" [ref=f3e106] [cursor=pointer]
              - button "提交，下一步 →" [ref=f3e107] [cursor=pointer]
          - button "题目显示不清或有问题，先跳过" [ref=f3e108] [cursor=pointer]
        - generic [ref=f3e109]:
          - button "保存草稿，休息一下" [ref=f3e110] [cursor=pointer]
          - button "提前结束本组" [ref=f3e111] [cursor=pointer]
          - button "刷新当前状态" [ref=f3e112] [cursor=pointer]
        - paragraph [ref=f3e113]: 首次提交会保留为测量证据；提示记录会单独计入。随时可以离开，回来继续。
    - button "打开学习观察助教" [ref=f3e115] [cursor=pointer]: "?"
  - alert [ref=f3e116]
```

# Test source

```ts
  16  |   const actor = await call('/auth/register', { principal, credential }), child = (await call('/students', { nickname: '匿名字体白板', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token)).profile.id;
  17  |   await call('/students/' + child + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15 }, actor.token, 'PUT');
  18  |   const command = { studentId: child, subject: 'math', prompt: '异分母分数加法：先理解单位，再通分。', atomId: 'core:math:fractionadd' }, preview = await call('/learning/studio/whiteboards/preview', command, actor.token);
  19  |   const saved = await call('/learning/studio/whiteboards', { ...command, fingerprint: preview.fingerprint, requestKey: randomUUID() }, actor.token);
  20  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  21  |   return '/studio?student=' + child + '&subject=math&whiteboard=' + saved.id;
  22  | }
  23  | 
  24  | test('original fonts: real captured Latin and Chinese faces decode before a board is measured, played or exported', async ({ page }) => {
  25  |   const url = await board(page), requests: string[] = [];
  26  |   page.on('request', request => { if (request.resourceType() === 'font') requests.push(request.url()); });
  27  |   await page.addInitScript(() => {
  28  |     const original = CanvasRenderingContext2D.prototype.fillText;
  29  |     (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts = [];
  30  |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) {
  31  |       (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.push(this.font); return original.apply(this, args);
  32  |     };
  33  |   });
  34  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  35  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  36  |   const loaded = await page.evaluate(() => [...new Set(Array.from(document.fonts).filter(face => face.status === 'loaded').map(face => face.family.replace(/^['"]|['"]$/g, '')))]);
  37  |   for (const family of ['Virgil', 'Xiaolai', 'Satoshi-Regular', 'Satoshi-Medium', 'Satoshi-Bold', 'MiSans']) expect(loaded).toContain(family);
  38  |   await expect.poll(() => page.evaluate(() => (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.some(font => /Virgil/.test(font) && /Xiaolai/.test(font)))).toBe(true);
  39  |   expect(requests.length).toBeGreaterThan(4); for (const request of requests) expect(new URL(request).pathname).toMatch(/^\/reference\/hyperknow\//);
  40  |   const manifest = JSON.parse(readFileSync(join(process.cwd(), 'apps/web/public/reference/hyperknow/asset-manifest.json'), 'utf8'));
  41  |   for (const request of [...new Set(requests)].slice(0, 8)) {
  42  |     const entry = manifest.files.find((entry: { publicPath: string }) => entry.publicPath === new URL(request).pathname); expect(entry).toBeTruthy();
  43  |     const response = await page.request.get(request), bytes = await response.body(); expect(response.status()).toBe(200); expect(createHash('sha256').update(bytes).digest('hex')).toBe(entry.sha256);
  44  |   }
  45  |   writeFileSync(join(browserEvidence('original-teaching-fonts'), 'actual-loaded-fonts.json'), JSON.stringify({ loaded, requests, originalFontManifest: manifest.captureFingerprint }, null, 2) + '\n');
  46  |   await page.screenshot({ path: join(browserEvidence('original-teaching-fonts'), 'actual-board-fonts.png'), fullPage: true });
  47  | });
  48  | 
  49  | test('original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board', async ({ page }) => {
  50  |   const url = await board(page); let blocked = false;
  51  |   await page.route('**/reference/hyperknow/assets/woff2/Xiaolai-*.woff2*', async route => { if (!blocked) { blocked = true; await route.abort('failed'); } else await route.continue(); });
  52  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  53  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'error'); expect(blocked).toBe(true); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeDisabled(); await expect(dialog.getByRole('button', { name: '导出视频', exact: true })).toBeDisabled();
  54  |   await page.unrouteAll({ behavior: 'wait' }); await dialog.getByRole('button', { name: '重新准备板书字体' }).click();
  55  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  56  |   expect(page.url()).toContain(new URL(url, 'http://fixture').searchParams.get('whiteboard')!);
  57  | });
  58  | 
  59  | test('teaching frame: moving to another scene retains already taught notes, excludes future scenes and keeps one full caption', async ({ page }) => {
  60  |   const url = await board(page);
  61  |   await page.addInitScript(() => {
  62  |     const clear = CanvasRenderingContext2D.prototype.clearRect, fill = CanvasRenderingContext2D.prototype.fillText;
  63  |     const state = window as unknown as { latestTeachingFrame: string[] }; state.latestTeachingFrame = [];
  64  |     CanvasRenderingContext2D.prototype.clearRect = function (...args: Parameters<CanvasRenderingContext2D['clearRect']>) { state.latestTeachingFrame = []; return clear.apply(this, args); };
  65  |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) { state.latestTeachingFrame.push(args[0]); return fill.apply(this, args); };
  66  |   });
  67  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  68  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  69  |   const scenes = dialog.locator('.sa-scene-strip button'), title = async (index: number) => (await scenes.nth(index).innerText()).replace(/^\d+\s*/u, '').trim();
  70  |   const first = await title(0), second = await title(1), third = await title(2);
  71  |   await scenes.nth(1).click();
  72  |   await expect.poll(() => page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).toEqual(expect.arrayContaining([first, second]));
  73  |   expect(await page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).not.toContain(third);
  74  |   const sentence = dialog.locator('.wb-current-sentence'); await expect(sentence).toHaveCount(1);
  75  |   const unit = await sentence.getAttribute('data-unit-id'); await dialog.getByRole('button', { name: '缩小白板', exact: true }).click();
  76  |   await expect(sentence).toHaveAttribute('data-unit-id', unit!); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  77  |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'cumulative-second-scene.png') });
  78  | });
  79  | 
  80  | for (const width of [390, 768, 1280]) test('teaching shell: actual original chrome, font switch and return fit ' + width, async ({ page }) => {
  81  |   await page.setViewportSize({ width, height: 800 }); const url = await board(page);
  82  |   const styles = () => page.evaluate(() => { const style = getComputedStyle(document.body); return { font: style.fontFamily, color: style.color, background: style.backgroundColor }; });
  83  |   const before = await styles(); await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  84  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  85  |   expect(await dialog.evaluate(element => { const bounds = element.getBoundingClientRect(); return { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height }; })).toEqual({ x: 0, y: 0, width, height: 800 });
  86  |   const sentence = dialog.locator('.wb-current-sentence'), unit = await sentence.getAttribute('data-unit-id');
  87  |   await dialog.getByRole('combobox', { name: '板书字体', exact: true }).selectOption('standard');
  88  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(sentence).toHaveAttribute('data-unit-id', unit!);
  89  |   await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  90  |   const overflow = await dialog.evaluate(element => element.scrollWidth - element.clientWidth); expect(overflow).toBeLessThanOrEqual(1);
  91  |   await dialog.getByRole('combobox', { name: '板书字体', exact: true }).selectOption('handwriting'); await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  92  |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'original-shell-' + width + '.png') });
  93  |   await dialog.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(dialog).toHaveCount(0);
  94  |   await page.goto('/learn'); expect(await styles()).toEqual(before);
  95  | });
  96  | 
  97  | test('original fonts: captured math faces stay isolated and the real formula editor decodes its own local font bytes after a board closes', async ({ page }) => {
  98  |   await page.goto(await board(page)); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  99  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  100 |   const captured = await page.evaluate(() => {
  101 |     const link = document.querySelector<HTMLLinkElement>('link[data-original-teaching-fonts]');
  102 |     return Array.from(link!.sheet!.cssRules).filter(rule => rule instanceof CSSFontFaceRule).map(rule => (rule as CSSFontFaceRule).style.getPropertyValue('font-family').replace(/^['"]|['"]$/g,''));
  103 |   });
  104 |   expect(captured.filter(family => family.startsWith('HKOriginal-KaTeX_')).length).toBeGreaterThan(0);
  105 |   expect(captured.filter(family => family.startsWith('KaTeX_'))).toEqual([]);
  106 |   await dialog.getByRole('button', { name: '关闭白板', exact: true }).click();
  107 |   const principal='answer-font-'+randomUUID()+'@local.test',credential='Synthetic-math-font-only-20261027',address='198.19.223.131';
  108 |   async function call(path:string,body:object,token?:string) { const response=await fetch(api+path,{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':address,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});expect(response.ok,path+' '+response.status).toBe(true);return(await response.json()).data; }
  109 |   const actor=await call('/auth/register',{principal,credential}),student=(await call('/students',{nickname:'匿名字体输入',grade:3,preferredSessionMinutes:15,defaultVersionMap:{math:'',chinese:'',english:''}},actor.token)).profile;
  110 |   const fixture=await call('/qa/answer-journeys',{studentId:student.id,mode:'formula_blank',kind:'diagnostic'},actor.token);
  111 |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  112 |   const requests:Array<{url:string;status:number}>=[];
  113 |   page.on('response',response=>{if(new URL(response.url()).pathname.startsWith('/vendor/mathlive/fonts/'))requests.push({url:response.url(),status:response.status()});});
  114 |   await page.goto(fixture.href);const field=page.locator('math-field').first();await expect(field).toBeVisible();await field.click();
  115 |   await field.evaluate(element=>(element as any).setValue('\\left(\\frac{1+\\sqrt{x^2+1}}{y^3}\\right)'));
> 116 |   await expect.poll(()=>requests.length).toBeGreaterThan(0);await page.evaluate(()=>document.fonts.ready);
      |                                          ^ Error: expect(received).toBeGreaterThan(expected)
  117 |   expect(requests.every(request=>request.status===200)).toBe(true);
  118 |   const loaded=await page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded'&&/KaTeX_/.test(face.family)&&!face.family.includes('HKOriginal-')).map(face=>face.family));
  119 |   expect(loaded.length).toBeGreaterThan(0);
  120 |   const response=await page.request.get('/vendor/mathlive/manifest.json');expect(response.status()).toBe(200);const manifest=await response.json();expect(manifest.files).toHaveLength(20);
  121 |   for(const file of manifest.files){const font=await page.request.get('/vendor/mathlive/'+file.path),bytes=await font.body();expect(font.status()).toBe(200);expect(bytes.length).toBe(file.size);expect(createHash('sha256').update(bytes).digest('hex')).toBe(file.sha256);}
  122 |   const directory=browserEvidence('original-math-font-isolation');writeFileSync(join(directory,'actual-math-editor-fonts.json'),JSON.stringify({capturedMathAliases:captured.filter(family=>family.startsWith('HKOriginal-KaTeX_')),requests,loaded,manifest},null,2)+'\n');await field.screenshot({path:join(directory,'actual-tall-formula.png')});
  123 | });
  124 | 
```