/* Read credentials only for the existing dedicated loopback QA cluster; isolated schemas. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{randomUUID}=require('node:crypto'),{Pool}=require('pg');
const {DomainDatabase}=require(path.resolve('apps/api/dist/apps/api/src/infrastructure/domain-database.js'));
const config=JSON.parse(fs.readFileSync(path.resolve('../StudyAgent/data/qa/postgres/credentials.json'),'utf8'));
assert.equal(config.purpose,'StudyAgent isolated QA cluster');assert.equal(config.port,15439);assert.equal(config.database,'study_agent_qa');assert.equal(config.appUser,'study_agent_app');
const location=new URL('postgresql://127.0.0.1:'+config.port+'/'+config.database);location.username=config.appUser;location.password=config.appPassword;
const pool=new Pool({connectionString:location.toString(),connectionTimeoutMillis:5000}),schemas=[],checks=[];
async function scoped(){const schema='study_qa_question_'+randomUUID().replaceAll('-','');await pool.query('CREATE SCHEMA "'+schema+'"');schemas.push(schema);const url=new URL(location);url.searchParams.set('options','-c search_path='+schema);return{schema,url:url.toString()};}
(async()=>{try{
  const role=(await pool.query('SELECT current_database() AS db, current_user AS role, rolsuper FROM pg_roles WHERE rolname=current_user')).rows[0];assert.equal(role.db,'study_agent_qa');assert.equal(role.role,'study_agent_app');assert.equal(role.rolsuper,false);
  const {schema,url}=await scoped();let db=new DomainDatabase(url);await db.open();const live=JSON.parse(fs.readFileSync('data/qa/question-teaching-live-hUcJVR/receipt.json','utf8'));
  const state={whiteboardQuestionTurns:[{id:'native-question',ownerUserId:'synthetic-owner',requestKey:'original-request',boardKind:'topic',boardId:'synthetic-original',studentId:null,
    position:{sentenceText:'比较长度先统一单位。',bookmark:{progress:.4,audioTime:.7,camera:{zoom:1.5,x:20,y:60,follow:false}}},reply:live.phases[0].result}],diagnosticResponses:[{id:'first-answer',originalText:'原首答不被改写。'}]};
  try{
    await db.commit(await db.read(),state);const before=await db.read();await assert.rejects(db.commit(before,{...state,whiteboardQuestionTurns:[...state.whiteboardQuestionTurns,{...state.whiteboardQuestionTurns[0],id:'duplicate'}]}));assert.deepEqual((await db.read()).state,state);
    checks.push({name:'native-owner-request-constraint-with-full-structured-answer',passed:true});await db.close();db=new DomainDatabase(url);await db.open();assert.deepEqual((await db.read()).state,state);checks.push({name:'native-cold-reopen-retains-board-speech-camera-and-first-answer',passed:true});
  }finally{await db.close();}
  const raw=new Pool({connectionString:url});try{await raw.query('DROP INDEX whiteboard_question_request');await raw.query('DELETE FROM schema_migrations WHERE version>=19');}finally{await raw.end();}
  db=new DomainDatabase(url);await db.open();try{assert.deepEqual((await db.read()).state,state);}finally{await db.close();}
  const inspect=new Pool({connectionString:url});try{assert.equal(Number((await inspect.query('SELECT MAX(version) AS version FROM schema_migrations')).rows[0].version),19);assert.equal((await inspect.query('SELECT indexname FROM pg_indexes WHERE schemaname=$1 AND indexname=$2',[schema,'whiteboard_question_request'])).rowCount,1);}finally{await inspect.end();}
  checks.push({name:'actual-schema18-to19-retains-full-structured-answer',passed:true});
}catch(error){process.exitCode=1;checks.push({name:'native-postgres-stage',passed:false,errorType:error?.constructor?.name});}
finally{for(const schema of schemas){assert.match(schema,/^study_qa_question_[a-f0-9]{32}$/);await pool.query('DROP SCHEMA "'+schema+'" CASCADE');}await pool.end();const receipt={at:new Date().toISOString(),scope:'Existing dedicated PostgreSQL QA cluster with a non-superuser app role; private schemas removed afterwards. Domain storage checks, not HTTP or native dump/restore acceptance.',checks,passed:checks.length===3&&checks.every(check=>check.passed)};fs.writeFileSync('data/qa/whiteboard-question-teaching-postgres-stage.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));}})();
