# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: assistant-whiteboards.spec.ts >> source whiteboard: unavailable storage blocks unsaved switching and creation until the complete original command is downloaded
- Location: tests\e2e\assistant-whiteboards.spec.ts:203:5

# Error details

```
TypeError: Cannot read properties of undefined (reading 'key')
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - generic [ref=f1e5]:
        - generic [ref=f1e6]:
          - link "StudyAgent 学习工作台" [ref=f1e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f1e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f1e11] [cursor=pointer]
        - generic [ref=f1e14]:
          - navigation "工作台主要入口" [ref=f1e15]:
            - button "Home" [ref=f1e16] [cursor=pointer]:
              - generic [ref=f1e19]: 首页
            - button "Courses" [ref=f1e20] [cursor=pointer]:
              - generic [ref=f1e23]: 课程
            - button "Calendar" [ref=f1e24] [cursor=pointer]:
              - generic [ref=f1e27]: 学习动态
            - button "History" [ref=f1e28] [cursor=pointer]:
              - generic [ref=f1e31]: 历史
            - button "Materials" [ref=f1e32] [cursor=pointer]:
              - generic [ref=f1e35]: 资料
            - link "AI Whiteboards" [ref=f1e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f1e39]: AI白板
          - button "＋ 创建课程" [ref=f1e40] [cursor=pointer]
          - generic [ref=f1e41]:
            - region "开始学习" [ref=f1e42]:
              - heading "开始学习" [level=3] [ref=f1e44]
              - link "打开课程 从一节适合自己的课开始。" [ref=f1e45] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f1e46]: 打开课程
                - generic [ref=f1e47]: 从一节适合自己的课开始。
            - generic [ref=f1e48]:
              - heading "近期活动" [level=3] [ref=f1e50]
              - paragraph [ref=f1e52]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f1e54] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f1e55]:
      - generic [ref=f1e56]:
        - generic [ref=f1e57]:
          - generic [ref=f1e58]: 独立学习
          - link "创建学习档案" [ref=f1e59] [cursor=pointer]:
            - /url: /parent/dashboard
        - generic [ref=f1e60]:
          - link "教学课堂 ↗" [ref=f1e61] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e62] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e63]:
        - generic [ref=f1e64]:
          - button "Craft Courses" [ref=f1e65] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e66] [cursor=pointer]
        - generic [ref=f1e67]:
          - heading "Time for flashcards?" [level=1] [ref=f1e69]
          - region "学习工作台助教" [ref=f1e70]:
            - generic [ref=f1e71]:
              - generic [ref=f1e72]:
                - generic [ref=f1e73]: 当前学习对话
                - button "查找历史" [ref=f1e74] [cursor=pointer]
                - button "我的笔记" [ref=f1e75] [cursor=pointer]
                - button "对话白板" [ref=f1e76] [cursor=pointer]
              - generic [ref=f1e77]:
                - generic [ref=f1e78]:
                  - text: 当前会话关键词
                  - textbox "检索当前对话" [ref=f1e79]
                - button "查找这段对话" [disabled] [ref=f1e80]
              - log "当前学习对话" [ref=f1e81]:
                - article [ref=f1e82]:
                  - strong [ref=f1e83]: 我
                  - paragraph [ref=f1e84]: "[cite-course] 请解释个人困扰与公共议题的条件，并保留反例。"
                  - button "整理为笔记" [ref=f1e85] [cursor=pointer]
                  - button "整理为白板" [ref=f1e86] [cursor=pointer]
                - article [ref=f1e87]:
                  - strong [ref=f1e88]: 学习助教
                  - paragraph [ref=f1e89]: 先列出已有条件，再说明卡住的一步。用一个独立新例子核查，不凭一次表现确定原因。
                  - navigation "本次回答的教学出处" [ref=f1e90]:
                    - link "社会学想象力 · 本节课导航" [ref=f1e91] [cursor=pointer]:
                      - /url: /studio?view=home&mode=instant&assistantSourceSession=assistant_session_655ce88a-072b-4a3a-bdd7-0d2aa2ee2011&assistantSourceKey=lecture-1-1&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=6aa6d782f5a7241ac0783cc587f9e1301947df9005730b6a30d481adbe6b6091&assistantSourceMessage=assistant_message_f924d9e3-85ab-4d7f-aa6b-48766f14f47a
                      - text: ↗ 社会学想象力 · 本节课导航
                  - generic [ref=f1e92]: Synthetic assistant · deepseek-v4-flash · 小九AI建议
                  - button "整理为笔记" [ref=f1e93] [cursor=pointer]
                  - button "整理为白板" [ref=f1e94] [cursor=pointer]
              - region "提问任务" [ref=f1e95]:
                - generic [ref=f1e96]:
                  - status [ref=f1e97]: 回答已保存
                  - generic [ref=f1e98]: DeepSeek V4.1 Flash
                - group [ref=f1e99]:
                  - generic "原问题与记录" [ref=f1e100] [cursor=pointer]
              - group [ref=f1e101]:
                - generic "提问记录（已读取 1 条）" [ref=f1e102] [cursor=pointer]
              - generic [ref=f1e103]:
                - generic [ref=f1e104]:
                  - region "当前讲座上下文" [ref=f1e105]:
                    - generic [aria-hidden] [ref=f1e106]: ▣
                    - generic [ref=f1e107]:
                      - strong [ref=f1e108]: 社会学思考
                      - generic [ref=f1e109]:
                        - generic [ref=f1e110]: U1·L1
                        - generic [ref=f1e111]: 社会学概论
                    - button "移除讲座上下文" [ref=f1e112] [cursor=pointer]: ×
                  - link "返回本讲 ↗" [ref=f1e113] [cursor=pointer]:
                    - /url: /studio/classroom?unit=0&panel=units&lecture=soc-u1-l1&lectureVersion=6aa6d782f5a7241ac0783cc587f9e1301947df9005730b6a30d481adbe6b6091
                  - generic [ref=f1e114]:
                    - generic [ref=f1e115]: 想一起看看什么
                    - textbox "想一起看看什么" [ref=f1e116]:
                      - /placeholder: 问一个概念，或告诉我你想理清的问题…
                  - generic [ref=f1e117]:
                    - generic [ref=f1e118]:
                      - button "打开学习资料" [ref=f1e119] [cursor=pointer]: ＋
                      - button "Tools" [ref=f1e120] [cursor=pointer]:
                        - generic [aria-hidden] [ref=f1e121]: ☷
                    - generic [ref=f1e123]:
                      - generic [ref=f1e124]:
                        - generic [ref=f1e125]:
                          - generic [ref=f1e126]: 模型
                          - combobox "选择大模型" [ref=f1e127] [cursor=pointer]:
                            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                            - option "GPT-6.1 Sol"
                            - option "GPT-6 Astra"
                            - option "GPT-6 Luna"
                            - option "Grok-4.7"
                            - option "GLM-5.3 Flash"
                            - option "DeepSeek V4.1 Flash · 默认" [selected]
                            - option "Claude Opus 5.5"
                            - option "Claude Sonnet 5"
                            - option "GPT-6 Sol"
                            - option "GPT-5.6 Sol"
                            - option "GPT-5.6 Terra"
                            - option "GPT-5.6 Luna"
                            - option "GPT-5.5"
                            - option "Grok-4.6"
                            - option "GLM-5.2"
                            - option "GLM-5.3"
                            - option "Claude Opus 5"
                            - option "Claude Fable 5.1"
                            - option "MiMo V2.6 Pro"
                            - option "MiMo V2.6 Flash"
                            - option "MiMo V2.6 Pro Ultraspeed"
                            - option "Qwen3.8 Max"
                        - group [ref=f1e128]:
                          - generic "模型文字检查说明" [ref=f1e129] [cursor=pointer]: ⓘ
                      - button "发送学习问题" [disabled] [ref=f1e130]: ↑
                - generic [ref=f1e132]:
                  - generic [ref=f1e133]:
                    - button "Concept Explanation" [ref=f1e134] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e135]: ⌕
                      - text: Concept Explanation
                    - button "Personal Study Materials Generation" [ref=f1e136] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e137]: ▤
                      - text: Personal Study Materials Generation
                    - button "Long-files Digestion" [ref=f1e138] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e139]: ▱
                      - text: Long-files Digestion
                  - generic [ref=f1e140]:
                    - button "Problem Solving" [ref=f1e141] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f1e142]: ♧
                      - text: Problem Solving
                    - link "Visualization" [ref=f1e143] [cursor=pointer]:
                      - /url: /studio/whiteboards
                      - generic [aria-hidden] [ref=f1e144]: ▦
                      - text: Visualization
              - button "下载提问副本" [ref=f1e145] [cursor=pointer]
  - dialog "对话教学白板" [ref=f1e148]:
    - banner [ref=f1e149]:
      - generic [ref=f1e150]:
        - text: CONVERSATION TO CLASSROOM
        - heading "把这次解释，讲清楚。" [level=2] [ref=f1e151]
        - paragraph [ref=f1e152]: 提炼为板书，保留原文与每一幕的依据。
      - button "关闭对话白板" [ref=f1e153] [cursor=pointer]: 关闭
    - navigation [ref=f1e154]:
      - button "选择原消息" [pressed] [ref=f1e155] [cursor=pointer]
      - button "我的对话白板" [ref=f1e156] [cursor=pointer]
      - button "下载完整本机草稿" [ref=f1e157] [cursor=pointer]
    - group [ref=f1e158]:
      - generic "本机保留草稿（0）" [ref=f1e159] [cursor=pointer]
      - paragraph [ref=f1e160]: 每个标签页分别保留，打开副本前会保留当前选择。
      - generic [ref=f1e161]:
        - button "另起一份白板草稿" [ref=f1e162] [cursor=pointer]
        - button "读取最新本机草稿" [ref=f1e163] [cursor=pointer]
      - list
    - status [ref=f1e164]: 本机保存暂不可用，关闭前请下载完整本机草稿与原请求。
    - status [ref=f1e165]: 原教学草稿与任务已保存。打开草稿核对逐幕来源、图片和讲稿后，再明确采用。
    - generic [ref=f1e166]:
      - generic [ref=f1e167]:
        - text: 搜索原消息
        - textbox "搜索原消息" [ref=f1e168]
      - button "搜索" [disabled] [ref=f1e169]
      - button "恢复最近消息" [ref=f1e170] [cursor=pointer]
    - group "选择原消息（1/20）" [ref=f1e171]:
      - generic [ref=f1e173]:
        - generic [ref=f1e174]:
          - checkbox "原问题 [cite-course] 请解释个人困扰与公共议题的条件，并保留反例。 本人消息" [ref=f1e175]
          - generic [ref=f1e176]:
            - strong [ref=f1e177]: 原问题
            - generic [ref=f1e178]: "[cite-course] 请解释个人困扰与公共议题的条件，并保留反例。"
            - text: 本人消息
        - generic [ref=f1e179]:
          - checkbox "助教原回答 先列出已有条件，再说明卡住的一步。用一个独立新例子核查，不凭一次表现确定原因。 Synthetic assistant · deepseek-v4-flash" [checked] [ref=f1e180]
          - generic [ref=f1e181]:
            - strong [ref=f1e182]: 助教原回答
            - generic [ref=f1e183]: 先列出已有条件，再说明卡住的一步。用一个独立新例子核查，不凭一次表现确定原因。
            - text: Synthetic assistant · deepseek-v4-flash
      - generic [ref=f1e184]:
        - checkbox "同时包含回答关联的原问题" [ref=f1e185]
        - text: 同时包含回答关联的原问题
      - generic [ref=f1e186]:
        - text: 教学目标
        - textbox "白板教学目标" [ref=f1e187]: 存储失败也必须完整保留的目标。
      - generic [ref=f1e188]:
        - generic [ref=f1e189]:
          - generic [ref=f1e190]: 模型
          - combobox "选择大模型" [ref=f1e191] [cursor=pointer]:
            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
            - option "GPT-6.1 Sol"
            - option "GPT-6 Astra"
            - option "GPT-6 Luna"
            - option "Grok-4.7"
            - option "GLM-5.3 Flash"
            - option "DeepSeek V4.1 Flash · 默认" [selected]
            - option "Claude Opus 5.5"
            - option "Claude Sonnet 5"
            - option "GPT-6 Sol"
            - option "GPT-5.6 Sol"
            - option "GPT-5.6 Terra"
            - option "GPT-5.6 Luna"
            - option "GPT-5.5"
            - option "Grok-4.6"
            - option "GLM-5.2"
            - option "GLM-5.3"
            - option "Claude Opus 5"
            - option "Claude Fable 5.1"
            - option "MiMo V2.6 Pro"
            - option "MiMo V2.6 Flash"
            - option "MiMo V2.6 Pro Ultraspeed"
            - option "Qwen3.8 Max"
        - generic [ref=f1e192]: 尚未进行文字检查
        - paragraph [ref=f1e194]:
          - generic [ref=f1e195]: DeepSeek V4.1 Flash
          - generic [ref=f1e196]: DeepSeek V4 Flash
      - generic [ref=f1e197]:
        - checkbox "我已核对原教学版本，允许使用旧来源" [ref=f1e198]
        - text: 我已核对原教学版本，允许使用旧来源
    - generic [ref=f1e199]:
      - button "核对完整来源" [ref=f1e200] [cursor=pointer]
      - button "生成教学草稿" [ref=f1e201] [cursor=pointer]
    - complementary [ref=f1e202]:
      - paragraph [ref=f1e203]: 3033/18000字符 · 固定模型：DeepSeek V4.1 Flash
      - paragraph [ref=f1e204]: 原教学年级：未指定 · 学生档案年级：未指定
      - group [ref=f1e205]:
        - generic "完整原对话与教学来源（1条）" [ref=f1e206] [cursor=pointer]
    - link "打开教学草稿 →" [ref=f1e207] [cursor=pointer]:
      - /url: /studio/whiteboards?draft=topic_draft_3e278611-bc7f-415b-bf1d-65a49e8fbcc7
    - paragraph [ref=f1e208]: 原稿、来源及编辑稿分别保留。生成和阅读不计为知识掌握。
```

# Test source

```ts
  113 |   await page.goto('/student/login'); await page.getByLabel('一次性学习码').fill(code.code); const login = page.waitForResponse(r => r.url().endsWith('/api/auth/learning-code') && r.request().method() === 'POST'); await page.getByRole('button', { name: '进入我的学习 →', exact: true }).click(); const learner = (await (await login).json()).data; await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  114 |   const open = page.waitForResponse(r => r.url().endsWith('/api/ai/assistant/sessions') && r.request().method() === 'POST'); await page.goto(course.href); const session = (await (await open).json()).data;
  115 |   const context = await call(learner, '/ai/assistant/sessions/' + session.id + '/context'), turn = await call(learner, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 保留比较条件和检查依据。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  116 |   await expect.poll(async () => (await call(learner, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed'); const message = (await call(learner, '/ai/assistant/sessions/' + session.id + '/messages/page')).messages.find((m: any) => m.sender === 'assistant');
  117 |   await page.reload(); await enter(page, message); await create(page); await panel(page).getByRole('link', { name: '打开教学草稿 →', exact: true }).click(); await expect(page.locator('.tw-generation-state')).toHaveText('待你核对');
  118 |   const id = new URL(page.url()).searchParams.get('draft'), path = '/learning/studio/topic-whiteboards/drafts/' + id, before = await call(learner, path), local = '暂停评测前保留的完整本机说明。'; await page.getByLabel('讲解概要').fill(local);
  119 |   const formal = await call(f.actor, '/diagnostics/sessions', { studentId: student.id, subject: 'math', intent: 'baseline', targetAtomIds: ['atomic:math:averagecount'], includePrerequisites: false, maxItems: 4 });
  120 |   const active = await call(f.actor, '/diagnostics/sessions/' + formal.id); await call(f.actor, '/diagnostics/sessions/' + formal.id + '/state', { action: 'pause', expectedRevision: active.revision, requestKey: crypto.randomUUID(), reason: '暂停匿名来源白板保护检查，不产生测量结论' });
  121 |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); const block = page.getByRole('complementary', { name: '当前评测保护' }); await expect(block.getByRole('link', { name: '进入原评测', exact: true })).toHaveAttribute('href', '/student/assessment?session=' + formal.id);
  122 |   await expect(page.getByRole('button', { name: '保存完整改稿', exact: true })).toBeDisabled(); await expect(page.getByLabel('讲解概要')).toHaveValue(local); expect((await call(learner, path)).revision).toBe(before.revision);
  123 |   const paused = await call(f.actor, '/diagnostics/sessions/' + formal.id); await call(f.actor, '/diagnostics/sessions/' + formal.id + '/state', { action: 'abort', expectedRevision: paused.revision, requestKey: crypto.randomUUID(), reason: '结束隔离保护检查，不形成测量结果' });
  124 |   await expect(page.getByRole('button', { name: '保存完整改稿', exact: true })).toBeDisabled(); await block.getByRole('button', { name: '重新核对白板权限', exact: true }).click(); await expect(block).toHaveCount(0);
  125 |   expect((await call(learner, path)).revision).toBe(before.revision); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  126 |   await expect.poll(async () => (await call(learner, path)).content.description).toBe(local); await page.screenshot({ path: evidence + '/paused-source-guard-resumed.png' });
  127 | });
  128 | test('source whiteboard: actual private PNG generation, original editing, adoption and sentence narration use the existing classroom', async ({ page }) => {
  129 |   test.setTimeout(180000); const f = await fixture(page);
  130 |   await page.route('**/api/learning/studio/overview?*', async route => {
  131 |     const response = await route.fetch(); if (!response.ok()) return route.fulfill({ response });
  132 |     const payload = await response.json(); payload.data.narrationAvailable = true; payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [{ id: 'fixture-a', label: '受控匿名音轨' }] };
  133 |     await route.fulfill({ response, json: payload });
  134 |   });
  135 |   await enter(page, f.message); await create(page); await panel(page).getByRole('link', { name: '打开教学草稿 →', exact: true }).click(); await expect(page.locator('.tw-generation-state')).toHaveText('待你核对');
  136 |   const pane = page.getByRole('region', { name: '白板配图工作区' }); await pane.getByLabel('希望图片说明什么').fill('用两个有交集的圆说明整体与单位的比较关系。');
  137 |   await pane.getByRole('button', { name: '预检配图范围', exact: true }).click(); await expect(pane).toContainText('本人原对话 · 原教学年级：未指定'); await pane.getByRole('button', { name: '生成参考图', exact: true }).click();
  138 |   const reader = pane.getByRole('button', { name: '放大参考图：明确整体', exact: true }); await expect(reader).toBeVisible({ timeout: 30000 }); await reader.click(); await expect(page.locator('.cl-figure-reader-sheet img')).toBeVisible(); await page.keyboard.press('Escape');
  139 |   await pane.getByRole('button', { name: '以原图继续修订', exact: true }).click(); await pane.getByLabel('具体修改').fill('保留两个圆，去掉顶部标题并保留完整标签。'); await pane.getByRole('button', { name: '预检配图范围', exact: true }).click(); await pane.getByRole('button', { name: '生成修订图片', exact: true }).click();
  140 |   await expect(reader).toBeVisible({ timeout: 30000 }); await pane.getByRole('checkbox', { name: '我已阅读图片，并核对本次要使用的标签和关系。' }).check(); await pane.getByRole('button', { name: '选入当前完整稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  141 |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check(); await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  142 |   const player = page.getByRole('dialog', { name: '白板视频' }); await expect(player.getByRole('button', { name: '放大参考图：明确整体', exact: true }).first()).toBeVisible();
  143 |   const speech = page.waitForResponse(r => /\/topic-whiteboards\/[^/]+\/narration\//.test(r.url())); await player.getByRole('button', { name: '播放', exact: true }).click(); const audio = await speech; expect(audio.status()).toBe(201); expect(audio.headers()['content-type']).toMatch(/^audio\//); await player.getByRole('button', { name: '暂停', exact: true }).click();
  144 |   await page.screenshot({ path: evidence + '/private-source-image-and-narration.png' });
  145 | });
  146 | test('source whiteboard: a creation that never reached the server retries only the complete original command', async ({ page }) => {
  147 |   test.setTimeout(150000); const f = await fixture(page); let first: any, second: any;
  148 |   await page.route('**/api/ai/assistant/sessions/*/artifacts/whiteboards', async route => { if (route.request().method() !== 'POST') return route.continue(); first = route.request().postDataJSON(); await route.abort('failed'); });
  149 |   await enter(page, f.message); await panel(page).getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(panel(page).getByRole('button', { name: '生成教学草稿', exact: true })).toBeEnabled(); await panel(page).getByRole('button', { name: '生成教学草稿', exact: true }).click(); await expect(panel(page).getByRole('alert')).toBeVisible();
  150 |   expect((await call(f.actor, f.base)).items).toHaveLength(0); await page.unroute('**/api/ai/assistant/sessions/*/artifacts/whiteboards');
  151 |   page.on('request', r => { if (r.method() === 'POST' && new URL(r.url()).pathname.endsWith('/artifacts/whiteboards')) second = r.postDataJSON(); });
  152 |   await panel(page).getByRole('button', { name: '核对原请求', exact: true }).click(); await expect(panel(page).getByRole('button', { name: '用原请求重试', exact: true })).toBeEnabled();
  153 |   await panel(page).getByRole('button', { name: '用原请求重试', exact: true }).click(); await expect(panel(page).getByRole('link', { name: '打开教学草稿 →', exact: true })).toBeVisible(); expect(second).toEqual(first); expect((await call(f.actor, f.base)).items).toHaveLength(1);
  154 | });
  155 | 
  156 | 
  157 | test('source whiteboard: two duplicated documents retain independent full selections across reload', async ({ page }) => {
  158 |   test.setTimeout(180000); const f = await fixture(page); await enter(page, f.message);
  159 |   await panel(page).getByLabel('白板教学目标').fill('甲页保留全部条件与反例。');
  160 |   const firstSlot = await page.evaluate(() => sessionStorage.getItem('studyagent.topic-whiteboard.document-slot'));
  161 |   const inherited = await page.evaluate(() => Object.fromEntries(Object.entries(sessionStorage))), other = await page.context().newPage();
  162 |   await other.addInitScript(values => { if (!sessionStorage.getItem('source-copy-test-initialized')) { for (const [key, value] of Object.entries(values)) sessionStorage.setItem(key, value); sessionStorage.setItem('source-copy-test-initialized', 'yes'); } }, inherited);
  163 |   try {
  164 |     await other.goto(f.href); await expect(other.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(other, f.message);
  165 |     await expect(panel(other).getByLabel('白板教学目标')).toHaveValue('甲页保留全部条件与反例。');
  166 |     const otherSlot = await other.evaluate(() => sessionStorage.getItem('studyagent.topic-whiteboard.document-slot')); expect(otherSlot).not.toBe(firstSlot);
  167 |     await panel(other).getByLabel('白板教学目标').fill('乙页独立核查，原甲页不覆盖。');
  168 |     await panel(page).getByLabel('白板教学目标').fill('甲页更新后的完整原稿。');
  169 |     expect((await localCache(other, f.key)).form.objective).toBe('乙页独立核查，原甲页不覆盖。');
  170 |     await page.reload(); await enter(page, f.message); await expect(panel(page).getByLabel('白板教学目标')).toHaveValue('甲页更新后的完整原稿。');
  171 |     await other.reload(); await enter(other, f.message); await expect(panel(other).getByLabel('白板教学目标')).toHaveValue('乙页独立核查，原甲页不覆盖。');
  172 |     await panel(page).locator('.assistant-whiteboard-local-copies>summary').click(); await panel(page).getByRole('button', { name: '读取最新本机草稿', exact: true }).click();
  173 |     await expect(panel(page).locator('.assistant-whiteboard-local-copies')).toContainText('乙页独立核查，原甲页不覆盖。');
  174 |     await page.screenshot({ path: evidence + '/independent-document-copies.png' }); expect((await call(f.actor, f.base)).items).toHaveLength(0);
  175 |   } finally { await other.close(); }
  176 | });
  177 | 
  178 | test('source whiteboard: multiple unfinished drafts keep an original pending creation when switching explicitly', async ({ page }) => {
  179 |   test.setTimeout(150000); const f = await fixture(page); await enter(page, f.message); const dialog = panel(page);
  180 |   await dialog.getByLabel('白板教学目标').fill('原请求的完整教学目标。');
  181 |   await page.route('**/api/ai/assistant/sessions/*/artifacts/whiteboards', async route => route.request().method() === 'POST' ? route.abort('failed') : route.continue());
  182 |   await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '生成教学草稿', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '生成教学草稿', exact: true }).click(); await expect(dialog.getByRole('alert')).toBeVisible();
  183 |   const original = await localCache(page, f.key); expect(original.pending).toBeTruthy();
  184 |   await dialog.locator('.assistant-whiteboard-local-copies>summary').click(); await dialog.getByRole('button', { name: '另起一份白板草稿', exact: true }).click();
  185 |   await dialog.getByLabel('白板教学目标').fill('第二份尚未完成的目标。');
  186 |   const copies = dialog.locator('.assistant-whiteboard-local-copies'); await copies.getByRole('button', { name: /原请求的完整教学目标/ }).click();
  187 |   await expect(dialog.getByLabel('白板教学目标')).toHaveValue('原请求的完整教学目标。'); expect((await localCache(page, f.key)).pending).toEqual(original.pending);
  188 |   await expect(dialog.getByRole('button', { name: '用原请求重试', exact: true })).toHaveCount(0); expect((await call(f.actor, f.base)).items).toHaveLength(0);
  189 |   await page.unroute('**/api/ai/assistant/sessions/*/artifacts/whiteboards'); await dialog.getByRole('button', { name: '核对原请求', exact: true }).click(); await dialog.getByRole('button', { name: '用原请求重试', exact: true }).click();
  190 |   await expect(dialog.getByRole('link', { name: '打开教学草稿 →', exact: true })).toBeVisible();
  191 |   await copies.getByRole('button', { name: /第二份尚未完成的目标/ }).click(); await expect(dialog.getByLabel('白板教学目标')).toHaveValue('第二份尚未完成的目标。'); expect((await call(f.actor, f.base)).items).toHaveLength(1);
  192 | });
  193 | 
  194 | test('source whiteboard: a valid legacy source cache is restored without changing its original bytes', async ({ page }) => {
  195 |   test.setTimeout(120000); const f = await fixture(page);
  196 |   const legacy = { version: 1, ownerId: f.actor.user.id, sessionId: f.session.id, form: { selection: { messageIds: [f.message.id], includeLinkedQuestions: true }, objective: '旧版完整目标与确认分别保留。', modelId: 'deepseek-v4-flash', acknowledgeHistoricalSource: true }, pending: null, archived: [], draftId: null }, raw = JSON.stringify(legacy);
  197 |   await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), { key: f.key, raw }); await enter(page, f.message);
  198 |   await expect(panel(page).getByLabel('白板教学目标')).toHaveValue(legacy.form.objective); await expect(panel(page).getByLabel('我已核对原教学版本，允许使用旧来源')).toBeChecked();
  199 |   await panel(page).getByLabel('白板教学目标').fill('只修改本页独立副本。'); expect(await page.evaluate(key => localStorage.getItem(key), f.key)).toBe(raw);
  200 |   await page.reload(); await enter(page, f.message); await expect(panel(page).getByLabel('白板教学目标')).toHaveValue('只修改本页独立副本。'); expect(await page.evaluate(key => localStorage.getItem(key), f.key)).toBe(raw);
  201 | });
  202 | 
  203 | test('source whiteboard: unavailable storage blocks unsaved switching and creation until the complete original command is downloaded', async ({ page }) => {
  204 |   test.setTimeout(150000); const f = await fixture(page); await enter(page, f.message); const dialog = panel(page);
  205 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function(key, value) { if (key.startsWith('studyagent.assistant.whiteboards.v1.')) throw new DOMException('Owned QA full storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  206 |   await dialog.getByLabel('白板教学目标').fill('存储失败也必须完整保留的目标。'); await dialog.locator('.assistant-whiteboard-local-copies>summary').click(); await dialog.getByRole('button', { name: '另起一份白板草稿', exact: true }).click(); await expect(dialog.getByLabel('白板教学目标')).toHaveValue('存储失败也必须完整保留的目标。');
  207 |   let posts = 0; page.on('request', r => { if (r.method() === 'POST' && new URL(r.url()).pathname.endsWith('/artifacts/whiteboards')) posts++; });
  208 |   await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '生成教学草稿', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '生成教学草稿', exact: true }).click();
  209 |   await expect(dialog).toContainText('完整原请求尚未写入本机'); expect(posts).toBe(0);
  210 |   await dialog.getByRole('button', { name: '核对原请求', exact: true }).click(); const download = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载完整本机草稿', exact: true }).click();
  211 |   const file = await download, copy = JSON.parse(await readFile((await file.path())!, 'utf8')); expect(copy.pending.requestKey).toBeTruthy(); expect(copy.form.objective).toBe('存储失败也必须完整保留的目标。');
  212 |   await dialog.getByRole('button', { name: '用原请求重试', exact: true }).click(); await expect(dialog.getByRole('link', { name: '打开教学草稿 →', exact: true })).toBeVisible(); expect(posts).toBe(1);
> 213 |   const saved = (await call(f.actor, f.base)).items; expect(saved).toHaveLength(1); expect((await call(f.actor, '/learning/studio/topic-whiteboards/drafts/' + saved[0].id)).receipt.key).toBe(copy.pending.requestKey);
      |                                                                                                                                                                                      ^ TypeError: Cannot read properties of undefined (reading 'key')
  214 | });
  215 | 
  216 | test('source whiteboard: the complete over-budget source stays visible and reducing the selection requires a new preflight', async ({ page }) => {
  217 |   test.setTimeout(150000); const f = await fixture(page), seeded = await call(f.actor, '/qa/assistant/seed-history', { sessionId: f.session.id, count: 6, marker: '完整预算末尾_MARKER', longSource: true });
  218 |   await page.reload(); await enter(page, f.message); const dialog = panel(page);
  219 |   for (const id of seeded.ids) await dialog.locator('.assistant-notes-message').filter({ has: page.locator('input') }).filter({ hasText: '匿名历史第' + seeded.ids.indexOf(id) + '条' }).getByRole('checkbox').check();
  220 |   await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.locator('.tw-source-context')).toContainText('完整预算末尾_MARKER'); await expect(dialog.getByRole('button', { name: '生成教学草稿', exact: true })).toBeDisabled();
  221 |   const before = await localCache(page, f.key); expect(before.form.selection.messageIds).toHaveLength(7); await dialog.locator('.tw-source-original>summary').click(); await expect(dialog.locator('.tw-source-original section')).toHaveCount(7);
  222 |   for (let index = 0; index < seeded.ids.length; index++) await dialog.locator('.assistant-notes-message').filter({ hasText: '匿名历史第' + index + '条' }).getByRole('checkbox').uncheck();
  223 |   await expect(dialog.locator('.tw-source-context')).toHaveCount(0); await expect(dialog.getByRole('button', { name: '生成教学草稿', exact: true })).toBeDisabled(); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '生成教学草稿', exact: true })).toBeEnabled(); expect((await call(f.actor, f.base)).items).toHaveLength(0);
  224 | });
  225 | 
  226 | test('source whiteboard: closing during a late original preflight cannot populate the reopened selection', async ({ page }) => {
  227 |   test.setTimeout(150000); const f = await fixture(page); let release!: () => void, entered!: () => void;
  228 |   const held = new Promise<void>(resolve => { release = resolve; }), ready = new Promise<void>(resolve => { entered = resolve; });
  229 |   await page.route('**/api/ai/assistant/sessions/*/artifacts/whiteboards/preflight', async route => { const response = await route.fetch(); entered(); await held; try { await route.fulfill({ response }); } catch { /* Closed panel aborted its private response. */ } });
  230 |   try {
  231 |     await enter(page, f.message); await panel(page).getByRole('button', { name: '核对完整来源', exact: true }).click(); await ready; await page.keyboard.press('Escape'); await expect(panel(page)).toHaveCount(0); await enter(page, f.message); await panel(page).getByLabel('白板教学目标').fill('重新打开后自己的新目标。'); release();
  232 |     await page.unroute('**/api/ai/assistant/sessions/*/artifacts/whiteboards/preflight'); await expect(panel(page).locator('.tw-source-context')).toHaveCount(0); await expect(panel(page).getByRole('button', { name: '生成教学草稿', exact: true })).toBeDisabled();
  233 |     await panel(page).getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(panel(page).getByRole('button', { name: '生成教学草稿', exact: true })).toBeEnabled(); expect((await call(f.actor, f.base)).items).toHaveLength(0);
  234 |   } finally { release?.(); }
  235 | });
  236 | 
```