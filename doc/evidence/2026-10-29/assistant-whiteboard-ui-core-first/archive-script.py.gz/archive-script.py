from pathlib import Path
import json,hashlib,gzip,subprocess,re,shutil
r=Path.cwd();out=r/'doc/evidence/2026-10-29/assistant-whiteboard-ui-core-first';out.mkdir(parents=True,exist_ok=False);files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,name=None):
 raw=p.read_bytes()
 if p.suffix not in ['.png','.zip']:assert not re.search(rb'Bearer [A-Za-z0-9._-]{24,}|postgres(?:ql)?://[^\s:]+:(?!local_ci_)[^\s@]+@',raw),str(p)
 target=out/((name or p.relative_to(r).as_posix())+('' if p.suffix=='.png' else '.gz'));target.parent.mkdir(parents=True,exist_ok=True)
 packed=raw if p.suffix=='.png' else gzip.compress(raw,mtime=0);target.write_bytes(packed);files[target.relative_to(out).as_posix()]={'sha256':sha(packed),'originalSha256':sha(raw),'originalBytes':len(raw)}
runs={};traces=[]
for name in ['source-ui-browser-first','source-ui-browser-second','source-ui-notes-regression-first','source-ui-topic-regression-first']:
 p=r/'data/qa'/(name+'.json');d=json.loads(p.read_text(encoding='utf-8'));runs[name]=d['stats'];save(p);save(r/'data/qa'/(name+'.log'))
 def walk(s):
  for spec in s.get('specs',[]):
   for t in spec.get('tests',[]):
    for result in t.get('results',[]):
     assert result.get('retry',0)==0
     for a in result.get('attachments',[]):
      if a.get('contentType')=='image/png':save(Path(a['path']))
      if a.get('contentType')=='application/zip':
       p=Path(a['path']);traces.append({'path':p.relative_to(r).as_posix(),'sha256':sha(p.read_bytes()),'published':False})
  for child in s.get('suites',[]):walk(child)
 for s in d['suites']:walk(s)
assert (runs['source-ui-browser-first']['expected'],runs['source-ui-browser-first']['unexpected'])==(4,4)
for name,count in [('source-ui-browser-second',8),('source-ui-notes-regression-first',25),('source-ui-topic-regression-first',24)]:
 s=runs[name];assert s['expected']==count and all(s[k]==0 for k in ['unexpected','skipped','flaky'])
for folder in ['source-ui-browser-first-inputs','source-ui-browser-second-inputs']:
 for p in sorted((r/'data/qa'/folder).rglob('*')):
  if p.is_file():save(p)
for p in sorted((r/'data/qa/browser-evidence').rglob('*.png')):save(p)
for name in ['source-ui-contracts-first.log','source-ui-config-first.log','source-ui-types-first.log','source-ui-types-second.log','source-ui-backend-inheritance-first.json','source-ui-doc-links-first.log']:save(r/'data/qa'/name)
for folder in ['source-ui-web-first','source-ui-web-second']:
 save(r/'data/qa'/folder/'.build-context.json');save(r/'data/qa'/folder/'.next/BUILD_ID')
manifest=json.loads((r/'data/qa/source-ui-browser-second-inputs/manifest.json').read_text(encoding='utf-8'));assert all(sha((r/n).read_bytes())==h for n,h in manifest.items())
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
for n in sorted(set(n for n in paths if n.startswith(('apps/','packages/','scripts/','tests/')))):save(r/n,'final-inputs/'+n)
save(Path(__file__),'archive-script.py')
receipt={'passed':True,'designBeforeImplementation':'62a9840a','backendBase':'5cb3b0be646f11457ec1b339a81505e8c9cacb1b','runs':runs,
 'originalRetries':0,'changedInputHashes':{'checked':len(manifest),'changed':[]},'backendRuntimeInheritance':{'javaScriptFiles':397,'changedFrom1790Gate':[]},
 'implemented':['Assistant message and session entry,strict current model selection,complete source preflight,source-grade/profile distinction and original create receipt recovery.',
 'Bounded source panel,owner/session local cache,explicit original request replay,unknown-owner bytes retained,readonly original-message return without replacing assistant input.',
 'Existing editor dispatches source/v1 schemas,per-scene sourced/supplementary/message/reference/explanation edits retain original draft and model review.',
 'Four-width actualHTTP generation/review/edit/adoption/player journey,private source-free player DTO and close returning to exact source draft.',
 'Source model browser fixture uses actual tasks and validators with only upstream capability/output controlled; production backend runtime397JS files remain identical to the independent1790API gate.'],
 'retainedFailure':'First8 original attempts:4passed/4test locator failures due to two grade paragraphs. Exact sources/reports/logs/screenshots kept. Mobile screenshot also revealed wrapped close button and an oversized objective field; separately repaired in a fresh Web directory. No retries,timeouts or product limits loosened.',
 'rawTracesLocalOnly':traces,'limits':['25 includes source8 and note17;24 ordinary topic is independent. Counts overlap with prior8 and are not summed.',
 'C3 core journeys only:more source-specific current-assessment resume,image/voice journeys,failed edit command retention,normalization and local multi-draft recovery remain to finish.',
 'No complete491-browser gate,exact source CI or production source/schema23 delivery. Notes release2818 CI is separate.',
 'Owned synthetic fixtures only;no new live providers,real learner evidence,pixel/audio/teacher or whole-product completion claim.'],'files':files}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'passed':True,'files':len(files),'runs':{k:{x:v[x] for x in ['expected','unexpected','skipped','flaky']} for k,v in runs.items()}}))
