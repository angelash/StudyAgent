from pathlib import Path
import json,hashlib,gzip,subprocess,re
root=Path.cwd();out=root/'doc/evidence/2026-10-29/assistant-whiteboard-source-lifecycle-first';out.mkdir(parents=True,exist_ok=False)
files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,name=None):
 raw=p.read_bytes()
 assert not re.search(rb'Bearer [A-Za-z0-9._-]{24,}|postgres(?:ql)?://[^\s:]+:(?!local_ci_)[^\s@]+@',raw),str(p)
 target=out/((name or p.relative_to(root).as_posix())+'.gz');target.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(raw,mtime=0);target.write_bytes(packed)
 files[target.relative_to(out).as_posix()]={'sha256':sha(packed),'originalSha256':sha(raw),'originalBytes':len(raw)}
qa=root/'data/qa';attempts={}
for prefix in ['source-authority','source-native','source-media']:
 for p in sorted(qa.glob(prefix+'*')):
  if p.is_file() and p.suffix in ['.log','.json','.ts']:save(p)
  elif p.is_dir():
   for child in sorted(p.rglob('*')):
    if child.is_file():save(child)
for name in ['source-authority-first','source-authority-second','source-authority-third','source-authority-postgres-first','source-authority-postgres-second','source-native-postgres-first','source-media-postgres-first','source-media-sqlite-first']:
 d=json.loads((qa/(name+'.json')).read_text(encoding='utf-8'));attempts[name]={k:d[k] for k in ['numPassedTests','numFailedTests','numPendingTests']}
assert attempts['source-media-postgres-first']=={'numPassedTests':114,'numFailedTests':0,'numPendingTests':2}
assert attempts['source-media-sqlite-first']=={'numPassedTests':23,'numFailedTests':0,'numPendingTests':0}
frozen=json.loads((qa/'source-media-postgres-first-inputs/manifest.json').read_text(encoding='utf-8'))
assert all(sha((root/n).read_bytes())==v for n,v in frozen.items())
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
for n in sorted(set(n for n in changed if n.startswith(('apps/','packages/','scripts/','.github/')))):save(root/n,'final-inputs/'+n)
runner=(root/'scripts/qa/run-assistant-whiteboard-source-lifecycle.cjs').read_text(encoding='utf-8')
tests=re.findall(r"'((?:modules|infrastructure)/[^']+\.test\.ts)'",runner)
for n in tests:save(root/'apps/api/src'/n,'final-tests/'+n)
save(Path(__file__),'archive-script.py')
receipt={'passed':True,'designBeforeImplementation':['3e53a7bd8288eb567f08c3ff7e6ff22383fba1a4','cbeae243'],'attempts':attempts,
 'finalFrozenChangedInputs':{'checked':len(frozen),'changed':[]},
 'scope':'Actual local PostgreSQL 17-file matrix:114passed/2 deliberately SQLite-only v1 cases skipped. Separate actual SQLite source lifecycle:23/23passed. Counts overlap and are not summed.',
 'implemented':['Atomic source draft/task/creation receipts; original model writing/review checkpoint, explicit cancel/retry, strict mapped editing and private adoption.',
 'Original login/current source/student assessment fencing for text,image generation/edit/adoption and narration; late result rejection after logout/source change/binding/assessment.',
 'Actual learner image generation/edit/adoption and private PNG reads; image prompt excludes raw origin and scene mappings; two actual application instances retain one source draft/task/adopted board.',
 'Shared semantic startup/native validation refuses unknown protocols,cross-owner publication,missing private marker and changed manuscript,including recomputed malicious bundle manifests.',
 'Actual SQLite/PostgreSQL stopped backup,cold restore,relogin,original creation/adoption receipts and source/player readback; latest author/child deletion ledgers prevent private source resurrection while another author board remains.'],
 'retainedFailures':['Authority first52/2:synthetic independent child context invalid; repaired with real grade9 course and unchanged grade4 profile.',
 'PGfirst101/1/2:the supposed second session reused the same independent scope; fixture-only real distinct lecture session repaired,PGsecond102/0/2.',
 'Initial type diagnostics retained separately; native first prepared-union diagnostics and media first mocked image type diagnostics have their exact relevant source copies. No business budgets,timeouts or retries weakened.'],
 'limits':['Intermediate authority-second54-pass complete input snapshot was not frozen; do not claim it was.',
 'Archived snapshots cover changed source/tests,not every historical transitive build dependency; current complete API/browser frozen gate remains required.',
 'Native PG offline verification proves dump/file bytes and TOC; semantic refusal is exercised after actual native import while target remains guarded.',
 'Providers are controlled synthetic fixtures with existing owned PNG/audio bytes; no new live model,image,TTS or production learning evidence.',
 'C3 specification committed62a9840a but actual front-end source selection/mapping remains pending; full API/browser/exactCI/main delivery not established for this candidate.',
 'Overall105/M1-M7/original72 remains active; no pixel/audio/teacher or real learning outcome completion claim.'], 'files':files}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':True,'files':len(files),'attempts':attempts}))
