// Private operational verifier: generated owner only, no original credential or real learner evidence.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process'),{DatabaseSync}=require('node:sqlite');
const root=process.cwd(),latest=JSON.parse(fs.readFileSync('data/qa/source-teaching-release-latest.json','utf8')),release=path.resolve(root,latest.folder),base=path.join(root,'output/daemon/release-backups');
if(!release.startsWith(base+path.sep)||fs.realpathSync(release).toLowerCase()!==release.toLowerCase())throw Error('Unexpected release folder');
const before=JSON.parse(fs.readFileSync(path.join(release,'deployment-before.json'),'utf8'));
const controls=JSON.parse(fs.readFileSync(path.join(release,'protected-records-before.json'),'utf8'));
const original=JSON.parse(fs.readFileSync(path.join(release,'original-record-hashes-private.json'),'utf8'));
const reference=JSON.parse(fs.readFileSync('data/qa/source-teaching-reference-compiled-first.json','utf8'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),sha=p=>hash(fs.readFileSync(p)),names=['study-agent-api','study-agent-web','study-agent-health'];
const api='http://127.0.0.1:4217/api',output=path.join(release,'runtime-source-teaching-first.json');
if(fs.existsSync(output))throw Error('Original runtime report already exists');
const result={at:new Date().toISOString(),passed:false,sourceRevision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),
 buildId:fs.readFileSync('apps/web/.next/BUILD_ID','utf8').trim(),checks:[],protectedCollections:[],compiled:[],figures:[],guardians:[],syntheticAuth:null};
let syntheticActorId=null,syntheticReceiptId=null;
function protectedState(exact){const db=new DatabaseSync('data/study-agent.sqlite3',{readOnly:true});try{
 if(db.prepare('PRAGMA quick_check').get().quick_check!=='ok'||db.prepare('SELECT MAX(version) version FROM schema_migrations').get().version!==23)throw Error('Actual schema23 database identity differs');
 if(db.prepare('SELECT state FROM study_restore_guard WHERE id=1').get().state!=='ready-schema23')throw Error('Unexpected schema23 minimum reader marker');
 const checked=[];let originalRecordCount=0;
 for(const[name,control]of Object.entries(controls.collections)){
  const rows=db.prepare('SELECT record_id,body FROM domain_records WHERE collection=? ORDER BY record_id').all(name);
  if(exact&&(rows.length!==control.count||hash(JSON.stringify(rows))!==control.sha256))throw Error('Original collection differs: '+name);
  const actual=new Map(rows.map(row=>[row.record_id,hash(row.body)]));
  for(const[id,expected]of Object.entries(original[name])){if(actual.get(id)!==expected)throw Error('An original persisted record changed: '+name);originalRecordCount++}
  checked.push({name,originalCount:control.count,actualCount:rows.length,originalRecordsUnchanged:true});
 }
 const additions=[];
 for(const row of db.prepare('SELECT collection,record_id,body FROM domain_records ORDER BY collection,record_id').all()){
  if(original[row.collection]?.[row.record_id])continue;
  const body=JSON.parse(row.body);
  if(exact)throw Error('Unexpected additional original-state record: '+row.collection);
  const allowed=row.collection==='privacyRequests'&&body.id===syntheticReceiptId&&body.actorId===syntheticActorId&&body.kind==='account_delete'
    ||row.collection==='events'&&body.eventName==='privacy.deletion_completed'&&body.payload?.receiptId===syntheticReceiptId;
  if(!allowed)throw Error('Unexpected non-synthetic additional record: '+row.collection);
  additions.push({collection:row.collection,kind:row.collection==='events'?'privacy.deletion_completed':'account_delete'});
 }
 const course=JSON.parse(db.prepare("SELECT body FROM domain_records WHERE collection='studioCourses' AND record_id=?").get('studio_course_b898dd14-1862-4051-b1af-fd35ee63a030').body);
 const profile=JSON.parse(db.prepare("SELECT body FROM domain_records WHERE collection='students' AND record_id=?").get(course.studentId).body);
 if(course.subject!=='chemistry'||course.grade!==9||profile.grade!==4||course.units.length!==7)throw Error('Original course/profile scope differs');
 return{checked,course,profileGrade:profile.grade,originalRecordCount,additions};
}finally{db.close()}}
async function status(url,expected){const r=await fetch(url,{signal:AbortSignal.timeout(15000)});result.checks.push({target:url,status:r.status,expected});if(r.status!==expected)throw Error('HTTP differs: '+url);return r;}
async function authCall(method,route,body,actor,expected){const r=await fetch(api+route,{method,headers:{'Content-Type':'application/json',...(actor?{Authorization:'Bearer '+actor.token}:{})},
 ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(15000)});const value=await r.json();
 result.checks.push({target:route.replace(/assistant_session_[^/]+/g,'[synthetic-session]'),status:r.status,expected,ownedSyntheticActor:true});
 if(r.status!==expected)throw Error('Owned auth check differs: '+route);return value.data;}
async function syntheticAuth(){
 const principal='qa-source-teaching-'+crypto.randomUUID()+'@local.test',credential='Owned-source-teaching-'+crypto.randomUUID();let actor,deleted=false;
 try{
  actor=await authCall('POST','/auth/register',{principal,credential},null,201);syntheticActorId=actor.user.id;
  actor=await authCall('POST','/auth/login',{principal,credential},null,201);await authCall('GET','/auth/me',undefined,actor,200);
  const session=await authCall('POST','/ai/assistant/sessions',{userRole:'parent',studentId:null,subject:null,pageContext:'studio'},actor,201),route='/ai/assistant/sessions/'+session.id+'/artifacts';
  for(const kind of ['notes','whiteboards']){const list=await authCall('GET',route+'/'+kind,undefined,actor,200);if(list.items.length)throw Error('Synthetic account has nonempty private artifact list')}
  const command={selection:{messageIds:[],includeLinkedQuestions:false},objective:'仅核对匿名账户权限，未生成教学或学习证据。'};
  await authCall('POST',route+'/preflight',{...command,kind:'verbatim_note'},actor,400);
  await authCall('POST',route+'/whiteboards/preflight',command,actor,400);
  await authCall('POST',route+'/practice/preflight',{...command,audience:{kind:'adult'}},actor,400);
  await authCall('POST',route+'/practice/preflight',{...command,selection:{messageIds:['unavailable-original'],includeLinkedQuestions:false},audience:{kind:'adult'}},actor,404);
  const preview=await authCall('GET','/privacy/account/deletion-preview',undefined,actor,200);
  const receipt=await authCall('POST','/privacy/account/delete',{credential,confirmation:preview.confirmation,fingerprint:preview.fingerprint,requestKey:crypto.randomUUID()},actor,201);
  syntheticReceiptId=receipt.id;deleted=true;await authCall('GET','/auth/me',undefined,actor,401);
  result.syntheticAuth={passed:true,accountDeleted:true,privateNotesList:true,privateSourceWhiteboardList:true,invalidAndUnavailableSourceRejected:true,createdLearnerEvidence:false,providerCalls:0};
 }finally{
  if(actor&&!deleted){try{const preview=await authCall('GET','/privacy/account/deletion-preview',undefined,actor,200);
   const receipt=await authCall('POST','/privacy/account/delete',{credential,confirmation:preview.confirmation,fingerprint:preview.fingerprint,requestKey:crypto.randomUUID()},actor,201);
   syntheticReceiptId=receipt.id;result.syntheticAuth={passed:false,accountDeleted:true,createdLearnerEvidence:false,providerCalls:0};
  }catch{result.syntheticAuth={passed:false,accountDeleted:false,cleanupRequired:true}}}
 }
}
function jsFiles(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?jsFiles(path.join(dir,e.name)):e.isFile()&&e.name.endsWith('.js')?[path.join(dir,e.name)]:[])}
function guardians(){const all=JSON.parse(execFileSync(process.env.ComSpec||'cmd.exe',['/d','/s','/c','pm2 jlist'],{encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024}));
 const rows=all.filter(p=>names.includes(p.name));if(rows.length!==3||rows.some(p=>p.pm2_env.status!=='online'||path.resolve(p.pm2_env.pm_cwd).toLowerCase()!==root.toLowerCase()))throw Error('Guardian state differs');
 return rows.map(p=>({name:p.name,pid:p.pid,restarts:p.pm2_env.restart_time})).sort((a,b)=>a.name.localeCompare(b.name))}
(async()=>{try{
 if(result.sourceRevision!==latest.ciHead||reference.referenceSource!==latest.ciHead||result.buildId===before.oldWebBuildId)throw Error('Actual source teaching build identity differs');
 for(const[name,value]of Object.entries(before.protectedFiles))if(sha(name)!==value)throw Error('Protected configuration differs');if(sha('.env')!==before.privateEnvSha256)throw Error('Private environment differs');
 const initial=protectedState(true);result.protectedCollections=initial.checked;result.originalRecordCount=initial.originalRecordCount;
 result.course={id:initial.course.id,grade:initial.course.grade,profileGrade:initial.profileGrade,units:7};
 const teaching=require(path.join(root,'apps/api/dist/apps/api/src/modules/ai/assistant-teaching-content.js'));
 result.unitTeaching=initial.course.units.map(unit=>{const c=teaching.primaryUnitTeachingCatalog(initial.course,unit.id),figures=c.parts.flatMap(part=>part.blocks).filter(block=>block.kind==='figure');
  if(c.parts.length!==32||figures.length!==4)throw Error('Original unit teaching projection differs');return{parts:c.parts.length,figures:figures.length}});
 const actualPaths=['apps/api/dist','packages/contracts/dist','packages/config/dist'].flatMap(jsFiles).map(p=>p.replaceAll('\\','/')).sort();
 if(JSON.stringify(actualPaths)!==JSON.stringify(Object.keys(reference.files).sort()))throw Error('Compiled runtime file set differs');
 for(const[name,expected]of Object.entries(reference.files)){const actual=sha(name);if(actual!==expected.sha256)throw Error('Compiled runtime differs: '+name);result.compiled.push({path:name,sha256:actual})}
 for(const[url,expected]of [['http://127.0.0.1:3217/api/ready',200],[api+'/ready',200],['https://study-agent.iepose.cn/api/ready',200],
  ['http://127.0.0.1:3217/parent/login',200],['http://127.0.0.1:3217/_next/static/'+result.buildId+'/_buildManifest.js',200],
  ['https://study-agent.iepose.cn/_next/static/'+result.buildId+'/_buildManifest.js',200],[api+'/ai/models',401],[api+'/learning/studio/overview',401],
  [api+'/ai/assistant/sessions/unknown/artifacts/whiteboards',401]])await status(url,expected);
 const manifest=JSON.parse(fs.readFileSync('resources/curriculum/chemistry-tutorial-figures-v2.json','utf8'));
 for(const figure of manifest.figures){const response=await status('http://127.0.0.1:3217'+figure.href,200);if(hash(Buffer.from(await response.arrayBuffer()))!==figure.sha256||sha('apps/web/public'+figure.href)!==figure.sha256)throw Error('Original chemistry figure differs');result.figures.push({code:figure.code,sha256:figure.sha256})}
 const chunks=jsFiles('apps/web/.next/static/chunks').map(p=>fs.readFileSync(p,'utf8'));
 for(const marker of ['assistant-notes-sheet','assistant-whiteboards-sheet','assistant-whiteboard-local-copies'])if(!chunks.some(text=>text.includes(marker)))throw Error('New Web source entry missing: '+marker);
 result.webMarkers=['assistant-notes-sheet','assistant-whiteboards-sheet','assistant-whiteboard-local-copies'];
 await syntheticAuth();const final=protectedState(false);result.originalRecordsAfterCleanupUnchanged=true;result.syntheticAdditions=final.additions;
 for(let i=0;i<3;i++){if(i)await new Promise(resolve=>setTimeout(resolve,30000));const current=guardians();if(i&&JSON.stringify(current)!==JSON.stringify(result.guardians[0].processes))throw Error('Guardian restarted during observation');
  result.guardians.push({at:new Date().toISOString(),processes:current});await status(api+'/ready',200);await status('https://study-agent.iepose.cn/api/ready',200)}
 result.passed=true;result.limits=['Synthetic auth/owner lists/input rejection/deletion only; no original user credential login or live generation.',
  'Original persisted records, grade9 course vs profile4, seven32-part units and28 figure hashes preserved.',
  'Stopped consistent database plus referenced runtime files/compiled/config backup only; no full research archive or full restore rehearsal.',
  'Schema23/source whiteboard and D1 preflight delivery only; D2-D4, exact pixels/DPR, actual audio, teacher and long-term learner outcomes remain separate.'];
}catch(error){result.error=error.message;process.exitCode=1}finally{fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({passed:result.passed,buildId:result.buildId,originalRecords:result.originalRecordCount,collections:result.protectedCollections.length,
  compiled:result.compiled.length,figures:result.figures.length,checks:result.checks.length,syntheticAuth:result.syntheticAuth,error:result.error??null}))}})().catch(error=>{console.error(error.message);process.exitCode=1});
