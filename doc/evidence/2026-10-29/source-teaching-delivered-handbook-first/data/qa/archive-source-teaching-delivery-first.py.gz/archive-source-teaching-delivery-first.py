from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re, shutil

root = Path.cwd()
latest = json.loads((root / 'data/qa/source-teaching-release-latest.json').read_text(encoding='utf-8'))
release = root / latest['folder']
runtime = json.loads((release / 'runtime-source-teaching-first.json').read_text(encoding='utf-8'))
if runtime.get('passed') is not True:
    raise RuntimeError('Actual runtime must pass before delivery archive')
folder = root / 'doc/evidence/2026-10-29/source-teaching-main-delivery-first'
folder.mkdir(parents=True, exist_ok=False)
ci_source = Path('[production-worktree]-practice-source/doc/evidence/2026-10-29/source-teaching-exact-ci-first')
ci_target = root / 'doc/evidence/2026-10-29/source-teaching-exact-ci-first'
shutil.copytree(ci_source, ci_target)
paths = [release / 'runtime-source-teaching-first.json', release / 'backup-verified.json',
         release / 'build-files.json', release / 'deployment-target.json']
paths += [root / ('data/qa/' + name) for name in [
    'source-teaching-release-verify-only-first.log', 'source-teaching-release-stop-backup-merge-first.log',
    'source-teaching-main-build-first.log', 'source-teaching-main-start-first.log', 'source-teaching-runtime-first.log',
    'source-teaching-reference-compiled-first.json', 'deliver-source-teaching-prepare.cjs',
    'verify-source-teaching-runtime-first.cjs', 'rollback-source-teaching-before-migration.cjs']]
files = []
for source in paths:
    raw = source.read_bytes()
    text = raw.decode('utf-8-sig')
    public = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text).replace('[local-user]', '[local-user]')
    public = public.replace(str(root), '[production-worktree]').replace(root.as_posix(), '[production-worktree]')
    data = public.encode('utf-8')
    if re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY|\bgh[pousr]_[A-Za-z0-9]{30,}|\bsk-[A-Za-z0-9_-]{30,}', data):
        raise RuntimeError('Potential secret in selected public delivery artifact')
    relative = source.relative_to(root).as_posix()
    target = folder / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0))
    if gzip.decompress(target.read_bytes()) != data:
        raise RuntimeError('Archive readback differs')
    files.append({'source': relative, 'archive': target.relative_to(folder).as_posix(),
                  'originalSha256': hashlib.sha256(raw).hexdigest(), 'originalBytes': len(raw),
                  'publishedSha256': hashlib.sha256(data).hexdigest(), 'publishedBytes': len(data),
                  'redacted': raw != data})
receipt = {'at': datetime.now(timezone.utc).isoformat(), 'passed': True,
           'sourceRevision': runtime['sourceRevision'], 'webBuildId': runtime['buildId'],
           'ciRun': latest['ciRun'], 'ciReceipt': '../source-teaching-exact-ci-first/receipt.json',
           'originalRecordCount': runtime['originalRecordCount'],
           'protectedCollections': len(runtime['protectedCollections']), 'compiledRuntimeFiles': len(runtime['compiled']),
           'httpChecks': len(runtime['checks']), 'figures': len(runtime['figures']), 'course': runtime['course'],
           'unitTeaching': runtime['unitTeaching'], 'syntheticAuth': runtime['syntheticAuth'],
           'originalRecordsAfterCleanupUnchanged': runtime['originalRecordsAfterCleanupUnchanged'],
           'guardianObservations': len(runtime['guardians']), 'privateConfigurationUnchanged': True,
           'backup': json.loads((release / 'backup-verified.json').read_text(encoding='utf-8')),
           'redaction': 'Raw originals remain local. Published text strips ANSI, local Windows username and production checkout path. Private environment/config copies, original record-ID hashes and database remain excluded.',
           'secretScanFindings': [], 'limits': runtime['limits'], 'files': files}
(folder / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: receipt[key] for key in ['passed', 'sourceRevision', 'webBuildId', 'originalRecordCount',
                                             'protectedCollections', 'compiledRuntimeFiles', 'httpChecks', 'figures', 'guardianObservations']}))
