from pathlib import Path
import datetime, gzip, hashlib, json, re, subprocess

r = Path(__file__).resolve().parents[2]
prefix = 'data/qa/source-ui-complete-browser-first'
report = json.loads((r / (prefix + '.json')).read_text(encoding='utf-8'))
process = json.loads((r / (prefix + '-process-result.json')).read_text(encoding='utf-8'))
check = json.loads((r / (prefix + '-inputs-verification.log')).read_text(encoding='utf-8'))
assert process['testExit'] == process['verificationExit'] == 0 and process['reportPresent']
assert not check['changed']
assert report['stats']['expected'] == 501
assert all(report['stats'][key] == 0 for key in ['unexpected', 'skipped', 'flaky'])

def specs(suite):
    yield from suite.get('specs', [])
    for child in suite.get('suites', []):
        yield from specs(child)

attempts = 0
traces = []
for suite in report['suites']:
    for spec in specs(suite):
        for test in spec['tests']:
            assert len(test['results']) == 1
            for result in test['results']:
                attempts += 1
                assert result['status'] == 'passed' and result.get('retry', 0) == 0
                for item in result.get('attachments', []):
                    if item.get('path', '').endswith('.zip'):
                        p = Path(item['path'])
                        p = p if p.is_absolute() else r / p
                        if p.is_file():
                            traces.append({'path': p.resolve().relative_to(r).as_posix(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'published': False})
assert attempts == 501

out = r / 'doc/evidence/2026-10-29/assistant-whiteboard-ui-complete-browser-first'
assert not out.exists()
out.mkdir(parents=True)
names = [prefix + suffix for suffix in ['.json', '.log', '-inputs.json', '-inputs-verification.log', '-process-result.json', '-managed-out.log', '-managed-error.log', '-list.log']]
names += ['data/qa/run-managed-source-ui-complete-browser-first.cjs', 'data/qa/freeze-source-ui-complete-browser-first.py', 'data/qa/archive-source-ui-complete-browser-first.py', 'data/qa/source-local-web-first/.build-context.json', 'data/qa/source-local-web-first/.next/BUILD_ID']
run = 'source-ui-complete-browser-first-' + hashlib.sha256((prefix + '.json').encode()).hexdigest()[:10]
evidence = r / 'data/qa/browser-evidence' / run
assert evidence.is_dir()
names += [p.relative_to(r).as_posix() for p in evidence.rglob('*') if p.is_file() and p.suffix != '.zip']
files = []
for name in sorted(set(names)):
    p = r / name
    b = p.read_bytes()
    if p.suffix in ['.json', '.log', '.py', '.cjs', '.md', '.html', '.txt', '.srt', '.vtt']:
        text = b.decode('utf-8', errors='replace')
        assert not re.search(r'gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9_-]{25,}|Bearer\s+[A-Za-z0-9._-]{50,}', text), 'Sensitive token candidate: ' + name
    q = out / (name + '.gz')
    q.parent.mkdir(parents=True, exist_ok=True)
    q.write_bytes(gzip.compress(b, mtime=0))
    assert gzip.decompress(q.read_bytes()) == b
    files.append({'source': name, 'archive': q.relative_to(out).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
receipt = {
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'passed': True,
    'sourceImplementation': 'c9cf9282', 'docsHeadAtArchive': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=r, text=True).strip(),
    'scope': 'Integrated source-whiteboard C2/C3, local multi-draft recovery and released notes. Excludes isolated D1 practice implementation.',
    'browser': report['stats'], 'originalAttempts': attempts, 'retries': 0, 'process': process, 'inputCheck': check,
    'buildContext': json.loads((r / 'data/qa/source-local-web-first/.build-context.json').read_text(encoding='utf-8')),
    'rawTracesLocalOnly': traces, 'files': files,
    'limitations': ['Current API1790/74 and specialist PG114/2,SQLite23 are separate overlapping runs, not added.', 'Precise source remote CI and actual schema23 production delivery still pending.', 'No new live model/image/TTS calls, real listening, exact pixel/DPR parity, teacher review or real learner outcome claim.', 'Original72,M1-M7 and overall product goal remain active.'],
}
(out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'passed': True, 'attempts': attempts, 'frozenInputs': check['checked'], 'archivedFiles': len(files), 'run': run}))
