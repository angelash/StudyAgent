# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom.spec.ts >> board notes reveal whole items and subtitle advances only at spoken sentence boundaries
- Location: tests\e2e\classroom.spec.ts:160:5

# Error details

```
TimeoutError: locator.fill: Timeout 15000ms exceeded.
Call log:
  - waiting for getByLabel('登录账号')
    - locator resolved to <input disabled value="" required="" minlength="3" maxlength="254" placeholder="账号或邮箱" autocomplete="username"/>
    - fill("classroom-1793203256275-97381@local.test")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not enabled
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not enabled
    - retrying fill action
      - waiting 100ms
    29 × waiting for element to be visible, enabled and editable
       - element is not enabled
     - retrying fill action
       - waiting 500ms

```

# Page snapshot

```yaml
- main [ref=e2]:
  - complementary [ref=e3]:
    - link "学 学习观察室" [ref=e4] [cursor=pointer]:
      - /url: /
      - generic [ref=e5]: 学
      - text: 学习观察室
    - generic [ref=e6]:
      - generic [ref=e7]: FAMILY / 每一步，都看得见
      - heading [level=1] [ref=e8]:
        - text: 先看见孩子，
        - emphasis [ref=e9]: 怎样学会。
      - paragraph [ref=e10]: 从一个具体知识点开始，找到卡住的一步，再通过新题和时间，看看是否真的留下来。
    - link "孩子自己来学习？使用学习码进入 ↗" [ref=e11] [cursor=pointer]:
      - /url: /student/login
  - generic [ref=e12]:
    - generic [ref=e13]: 家长与教师入口
    - heading "继续孩子的学习旅程。" [level=2] [ref=e14]
    - paragraph [ref=e15]: 登录后查看孩子的知识证据、指导计划和复测记录。
    - generic [ref=e16]:
      - generic [ref=e17]:
        - text: 登录账号
        - textbox "登录账号" [disabled] [ref=e18]:
          - /placeholder: 账号或邮箱
      - generic [ref=e19]:
        - text: 密码
        - textbox "密码" [disabled] [ref=e20]:
          - /placeholder: 至少 10 个字符
      - button "登录，查看学习记录 →" [disabled] [ref=e21]
    - button "首次使用，创建家长账号" [disabled] [ref=e22]
    - paragraph [ref=e23]: 教师与教研权限由管理员配置。孩子使用家长生成的一次性学习码。
```

# Test source

```ts
  1   | import { syntheticFamilyHeaders } from './synthetic-family';
  2   | import { browserEvidence } from './evidence';
  3   | import { expect, test } from '@playwright/test';
  4   | import { mkdirSync } from 'node:fs';
  5   | 
  6   | const apiUrl = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`;
  7   | const evidenceDirectory = browserEvidence('classroom');
  8   | async function login(page: import('@playwright/test').Page) {
  9   |   const suffix = Date.now() + '-' + Math.floor(Math.random() * 100000), principal = 'classroom-' + suffix + '@local.test', credential = 'Classroom-' + suffix;
  10  |   const registered = await fetch(apiUrl + '/api/auth/register', { method: 'POST', headers: await syntheticFamilyHeaders(page), body: JSON.stringify({ principal, credential }) });
  11  |   expect(registered.status).toBe(201);
> 12  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
      |                                                                   ^ TimeoutError: locator.fill: Timeout 15000ms exceeded.
  13  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  | }
  15  | 
  16  | function wav(seconds = 0.6) {
  17  |   const samples = Math.floor(seconds * 16000), bytes = Buffer.alloc(44 + samples * 2);
  18  |   bytes.write('RIFF'); bytes.writeUInt32LE(bytes.length - 8, 4); bytes.write('WAVE', 8); bytes.write('fmt ', 12);
  19  |   bytes.writeUInt32LE(16, 16); bytes.writeUInt16LE(1, 20); bytes.writeUInt16LE(1, 22); bytes.writeUInt32LE(16000, 24);
  20  |   bytes.writeUInt32LE(32000, 28); bytes.writeUInt16LE(2, 32); bytes.writeUInt16LE(16, 34); bytes.write('data', 36); bytes.writeUInt32LE(samples * 2, 40);
  21  |   for (let i = 0; i < samples; i++) bytes.writeInt16LE(Math.round(800 * Math.sin(i * 2 * Math.PI * 440 / 16000)), 44 + i * 2);
  22  |   return bytes;
  23  | }
  24  | 
  25  | test('course classroom supports teaching, executable examples, learning checks and durable resume', async ({ page }) => {
  26  |   test.setTimeout(120000); const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  27  |   await page.setViewportSize({ width: 1440, height: 1000 }); await login(page); await page.goto('/studio/classroom');
  28  |   await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  29  |   await expect(page.locator('.cl-unit-nav button')).toHaveCount(5); await expect(page.locator('.cl-lecture')).toHaveCount(5);
  30  |   if (!process.env.CI) { mkdirSync(evidenceDirectory, { recursive: true }); await page.screenshot({ path: evidenceDirectory + '/classroom-course.png', fullPage: true }); }
  31  |   await page.getByRole('button', { name: '▶ 学习', exact: true }).first().click();
  32  |   await expect(page.getByRole('dialog', { name: '课堂新手引导' })).toBeVisible(); await page.getByRole('button', { name: '跳过', exact: true }).click();
  33  |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  34  |   await expect(page.getByRole('img', { name: '个人处境与社会条件的交汇' })).toBeVisible();
  35  |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  36  |   await expect(page.getByLabel('实验代码')).toBeVisible(); await page.getByRole('button', { name: '▶ 运行代码' }).click();
  37  |   await expect(page.getByRole('log', { name: '代码运行结果' })).toContainText('甲地区: 20.0%');
  38  |   await page.getByLabel('实验代码').fill('console.log(typeof document); console.log(typeof window);');
  39  |   await page.getByRole('button', { name: '▶ 运行代码' }).click(); await expect(page.getByRole('log')).toContainText('undefined');
  40  |   await page.getByLabel('实验代码').fill('while (true) {}'); await page.getByRole('button', { name: '▶ 运行代码' }).click();
  41  |   await expect(page.getByRole('log')).toContainText('运行超过 2 秒');
  42  |   await page.getByLabel('实验代码').fill('fetch("https://example.com").catch(() => console.log("network-blocked"));');
  43  |   await page.getByRole('button', { name: '▶ 运行代码' }).click();
  44  |   await expect(page.getByRole('log')).toContainText(/运行完成|network-blocked/);
  45  |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-board.png', fullPage: true });
  46  |   await page.getByRole('button', { name: '课堂设置', exact: true }).click();
  47  |   await expect(page.getByRole('dialog', { name: '课堂设置' })).toBeVisible(); await page.getByRole('button', { name: '1.5×', exact: true }).click();
  48  |   await page.getByRole('switch', { name: /Background dots/ }).click();
  49  |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-settings.png', fullPage: true });
  50  |   await page.getByRole('button', { name: '关闭课堂设置' }).click();
  51  |   await page.getByRole('tab', { name: '课堂练习' }).click(); await page.locator('.cl-practice-options input[type=radio]').first().check();
  52  |   await page.getByRole('button', { name: '先给我一个提示' }).click(); await page.getByRole('button', { name: 'Check →' }).click();
  53  |   await expect(page.locator('.cl-answer-feedback')).toContainText('使用过提示');
  54  |   const receipt = await page.locator('.cl-answer-feedback').innerText();
  55  |   await page.getByRole('tab', { name: '单元项目' }).click(); await page.getByLabel('我的项目草稿').fill('匿名案例：社区图书馆如何组织排队。需要核查不同规则与资源条件。');
  56  |   await page.getByRole('button', { name: '保存项目草稿' }).click(); await expect(page.getByText('草稿已保存，重新打开仍可继续。')).toBeVisible();
  57  |   await page.reload(); await expect(page.getByText('2 / 8', { exact: true })).toHaveCount(0);
  58  |   await expect(page.locator('.cl-session-navigation')).toContainText('3 / 8');
  59  |   await page.getByRole('tab', { name: '课堂练习' }).click(); await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toHaveText(receipt, { useInnerText: true });
  60  |   await page.getByRole('tab', { name: '单元项目' }).click(); await expect(page.getByLabel('我的项目草稿')).toHaveValue(/社区图书馆/);
  61  |   const notes = page.waitForEvent('download'); await page.getByRole('button', { name: '导出课堂笔记' }).click(); expect((await notes).suggestedFilename()).toMatch(/\.md$/);
  62  |   await page.setViewportSize({ width: 390, height: 844 }); await page.getByRole('button', { name: '对话与练习', exact: true }).click();
  63  |   await expect(page.getByLabel('我的项目草稿')).toBeVisible();
  64  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  65  |   await page.getByRole('button', { name: '白板', exact: true }).click();
  66  |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-mobile.png', fullPage: true });
  67  |   await page.getByRole('button', { name: '离开课堂', exact: true }).click(); await page.getByRole('button', { name: '保存并离开' }).click();
  68  |   await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  69  |   expect(errors).toEqual([]);
  70  | });
  71  | 
  72  | test('audio playback ends drive teaching progress and pause prevents later automatic advancement', async ({ page }) => {
  73  |   test.setTimeout(90000); await login(page);
  74  |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  75  |   const withTestAudio = async (route: import('@playwright/test').Route) => {
  76  |     const response = await route.fetch(), body = await response.json();
  77  |     body.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture', voices: [{ id: 'fixture', label: '合成测试音轨' }] };
  78  |     await route.fulfill({ response, json: body });
  79  |   };
  80  |   await page.route('**/api/learning/classroom/sessions', withTestAudio);
  81  |   await page.route('**/api/learning/classroom/sessions/*', withTestAudio);
  82  |   let audioRequests = 0;
  83  |   await page.route('**/api/learning/classroom/sessions/*/narration/*', async route => { audioRequests++; await route.fulfill({ contentType: 'audio/wav', body: wav() }); });
  84  |   await page.goto('/studio/classroom?lesson=soc-1-1-1'); await expect(page.getByRole('button', { name: '▶ 开始学习' })).toBeVisible();
  85  |   await page.getByRole('button', { name: '▶ 开始学习' }).click(); await expect(page.locator('.cl-session-navigation')).not.toContainText('1 / 8');
  86  |   await page.getByRole('button', { name: '暂停讲解' }).click();
  87  |   await expect(page.getByRole('button', { name: '继续讲解' })).toBeVisible();
  88  |   const cursor = await page.locator('.cl-session-navigation').innerText();
  89  |   await page.waitForTimeout(1200); expect(await page.locator('.cl-session-navigation').innerText()).toBe(cursor);
  90  |   expect(audioRequests).toBeGreaterThan(0);
  91  |   for (let step = 0; step < 8; step++) {
  92  |     const before = await page.locator('.cl-session-navigation').innerText(); if (before.includes('7 / 8')) break;
  93  |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  94  |     await expect(page.locator('.cl-session-navigation')).not.toHaveText(before, { useInnerText: true });
  95  |   }
  96  |   await page.getByRole('button', { name: '继续讲解' }).click();
  97  |   await expect(page.getByRole('tab', { name: '课堂练习' })).toHaveAttribute('aria-selected', 'true');
  98  |   await expect(page.getByRole('button', { name: '继续讲解' })).toBeVisible();
  99  |   await expect(page.locator('.cl-session-navigation')).toContainText('7 / 8');
  100 |   await page.locator('.cl-practice-options input[type=radio]').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  101 |   await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  102 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  103 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  104 |   await expect(page.getByRole('dialog', { name: '课堂学习里程碑' })).toBeVisible();
  105 | });
  106 | 
  107 | test('question replies add safe board notes with page links, export and restored session rendering', async ({ page }) => {
  108 |   test.setTimeout(90000); await page.setViewportSize({ width: 1552, height: 1199 }); await login(page);
  109 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  110 |   const board = { title: '把困惑拆成可核查的问题', points: ['比较不同条件，再找相同处境中的反例。', '<img src=x onerror="window.boardExecuted=true">'],
  111 |     page: 0, diagram: { kind: 'flow', title: '核查路线', labels: ['观察处境', '比较条件', '寻找反例'] } };
  112 |   let messages: unknown[] | undefined;
```