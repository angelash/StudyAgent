# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player
- Location: tests\e2e\topic-whiteboard.spec.ts:45:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: '白板视频' })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('dialog', { name: '白板视频' }) with timeout 15000ms
  - waiting for getByRole('dialog', { name: '白板视频' })

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - link "Home":
        - /url: /studio?view=home
        - text: 首页
      - link "Courses":
        - /url: /studio?view=courses
        - text: 课程
      - link "Calendar":
        - /url: /studio?view=calendar
        - text: 学习动态
      - link "History":
        - /url: /studio?view=history
        - text: 历史
      - link "Materials":
        - /url: /studio?view=materials
        - text: 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom
    - heading "近期活动" [level=2]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页 →":
      - /url: /learn?subject=math
  - text: WHITEBOARD STUDIO
  - heading "从一个问题开始，讲清每一步。" [level=1]
  - paragraph: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
  - link "返回学习工作台 →":
    - /url: /studio
  - status:
    - text: 当前输入未能存到本机，请先保存或下载完整副本后再离开。
    - button "收起提示"
  - complementary:
    - text: NEW BOARD
    - heading "这次想弄懂什么？" [level=2]
    - text: 学习对象
    - combobox "白板学习对象":
      - option "我自己 · 成人主题" [selected]
    - region "新建AI白板":
      - group:
        - text: 讲解主题
        - textbox "讲解主题":
          - /placeholder: 例如：为什么先统一单位，才能比较和合并？
          - text: 用匿名观察解释条件与推断
        - text: 希望弄懂什么
        - textbox "希望弄懂什么":
          - /placeholder: 想理解的区别、步骤，或一个具体困惑
          - text: 保留完整条件，说明观察、推断和替代解释的区别。
        - text: 模型
        - combobox "选择大模型":
          - option "Auto · 当前默认模型"
      - status: 已恢复此标签页的原主题与模型选择。
      - button "预检主题与范围"
      - button "生成教学稿" [disabled]
      - button "下载原主题与请求"
      - group: 查看其他本机主题
  - region "白板工作区":
    - article:
      - text: 已保存白板
      - heading "把条件讲清楚" [level=2]
      - paragraph: Browser fixture · not a real model · 本人成人主题
      - status: 已保存白板
      - button "打开已保存白板"
      - button "下载原稿与请求"
      - status: 白板已保存，仍标记为AI生成、待内容核对。
      - group: 查看其他本机操作
      - heading "AI 复核 · 针对旧稿，尚未复核当前修改" [level=3]
      - paragraph: 这不是教师审核，也不代表孩子已掌握。
      - region "完整白板改稿":
        - heading "完整教学稿" [level=2]
        - paragraph: 与所用基线一致 · 本机草稿已保留
        - button "下载完整改稿"
        - status: 已恢复这份候选的完整本机改稿；请核对服务器版本后继续。
        - group: 查看其他本机改稿
        - group:
          - text: 白板标题
          - textbox "白板标题" [disabled]: 把条件讲清楚
          - text: 讲解概要
          - textbox "讲解概要" [disabled]: 保留这段完整的本机修订说明。
          - group:
            - text: 1. 先核对观察 这一幕的结构
            - combobox "这一幕的结构" [disabled]:
              - option "开场" [disabled] [selected]
              - option "概念" [disabled]
              - option "步骤" [disabled]
              - option "自我检验" [disabled]
            - text: 分幕标题
            - textbox "分幕标题" [disabled]: 先核对观察
            - text: 完整旁白
            - textbox "完整旁白" [disabled]: "[whiteboard-fixture] 先核对观察。 保留未知条件，不把一次观察当成完整能力证明。"
            - text: 板书正文
            - textbox "板书正文" [disabled]: 完整说明首行。完整说明尾行。
            - heading "完整要点" [level=3]
            - paragraph: 每条要点应逐字出现在本幕旁白中。
            - text: 要点 1
            - textbox "要点 1" [disabled]: 先核对观察
            - button "移除此要点" [disabled]
            - button "添加要点" [disabled]
            - text: 对照展示
            - combobox "对照展示" [disabled]:
              - option "文字讲解" [disabled] [selected]
              - option "对照表" [disabled]
              - option "公式" [disabled]
          - group: 2. 再比较条件
          - group: 3. 最后保留反例
        - button "保存完整改稿" [disabled]
      - group: 阅读AI最初原稿
      - button "查看完整修改历史"
  - complementary "白板与候选历史":
    - heading "我的白板" [level=2]
    - button "＋ 新白板"
    - button "教学草稿" [pressed]
    - button "已保存"
    - text: 搜索我的白板
    - textbox "搜索我的白板":
      - /placeholder: 搜索主题或标题
    - button "已保存白板 · 本人主题 把条件讲清楚 Browser fixture · not a real model"
    - button "上一页" [disabled]
    - text: 1 / 1
    - button "下一页" [disabled]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { createHash, randomUUID } from 'node:crypto';
  3   | import { readFileSync } from 'node:fs';
  4   | import { browserEvidence } from './evidence';
  5   | import { join } from 'node:path';
  6   | 
  7   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107'), base = '/learning/studio/topic-whiteboards';
  8   | // Complete in-flight overview/media routes before Playwright disposes their API responses.
  9   | test.afterEach(async ({ page }) => { await page.unrouteAll({ behavior: 'wait' }); });
  10  | async function fixture(page: Page, child = false) {
  11  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  12  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  13  |   const principal = 'topic-browser-' + randomUUID() + '@local.test', credential = 'Topic-Browser-Only-20261026';
  14  |   let token = '';
  15  |   async function call(path: string, body?: unknown, method = 'POST') {
  16  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) },
  17  |       ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  18  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
  19  |   }
  20  |   const actor = await call('/auth/register', { principal, credential }); token = actor.token;
  21  |   let studentId: string | null = null;
  22  |   if (child) {
  23  |     const created = await call('/students', { nickname: '匿名AI白板学习者', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }); studentId = created.profile.id;
  24  |     await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null,
  25  |       textbookVersion: '匿名已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  26  |   }
  27  |   await page.route('**/api/learning/studio/overview?*', async route => {
  28  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
  29  |     const payload = await response.json(); payload.data.narrationAvailable = true; payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [{ id: 'fixture-a', label: '合成音轨 A' }] };
  30  |     await route.fulfill({ response, json: payload });
  31  |   });
  32  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  33  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  34  |   await page.goto('/studio/whiteboards'); await expect(page.getByLabel('讲解主题')).toBeVisible();
  35  |   await expect(page.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');
  36  |   return { actor, call, studentId };
  37  | }
  38  | async function generate(page: Page, topic = '用匿名观察解释条件与推断') {
  39  |   await page.getByLabel('讲解主题').fill(topic); await page.getByLabel('希望弄懂什么').fill('保留完整条件，说明观察、推断和替代解释的区别。');
  40  |   await page.getByRole('button', { name: '预检主题与范围', exact: true }).click(); await expect(page.getByRole('button', { name: '生成教学稿', exact: true })).toBeEnabled();
  41  |   await page.getByRole('button', { name: '生成教学稿', exact: true }).click();
  42  | }
  43  | async function ready(page: Page) { await expect(page.locator('.tw-generation-state')).toHaveText('待你核对', { timeout: 25000 }); await expect(page.getByLabel('白板标题')).toBeVisible(); }
  44  | 
  45  | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  46  |   const f = await fixture(page); let dropped = true;
  47  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  48  |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  49  |   });
  50  |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  51  |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  52  |   const id = new URL(page.url()).searchParams.get('draft')!;
  53  |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  54  |   let editDropped = true, editWrites = 0;
  55  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  56  |     editWrites++;
  57  |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  58  |   });
  59  |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  60  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  61  |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  62  |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  63  |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  64  |   expect(editWrites).toBe(1);
  65  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  66  |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  67  |   let confirmationDropped = true, confirmationWrites = 0;
  68  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  69  |     confirmationWrites++;
  70  |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  71  |   });
  72  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  73  |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
> 74  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
      |                                                                                                                                      ^ Error: expect(locator).toBeVisible() failed
  75  |   expect(confirmationWrites).toBe(1);
  76  |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
  77  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
  78  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  79  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  80  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  81  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  82  | });
  83  | 
  84  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  85  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  86  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  87  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  88  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  89  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  90  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  91  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  92  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  93  | });
  94  | 
  95  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  96  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  97  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  98  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  99  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  100 |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  101 |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  102 |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  103 |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  104 | });
  105 | 
  106 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  107 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  108 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  109 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  110 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  111 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  112 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  113 | });
  114 | 
  115 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  116 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  117 |   try {
  118 |     await second.goto(href); await ready(second);
  119 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  120 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  121 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  122 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  123 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
  124 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  125 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  126 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  127 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  128 |   } finally { await second.close(); }
  129 | });
  130 | 
  131 | test('uncached original topic cannot disappear on a scope change until its complete input is downloaded', async ({ page }) => {
  132 |   const f = await fixture(page, true);
  133 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  134 |     if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value);
  135 |   }; });
  136 |   await page.getByLabel('讲解主题').fill('尚未生成也不能丢失的匿名主题');
  137 |   await page.getByLabel('希望弄懂什么').fill('保留我的完整教学目标。');
  138 |   await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  139 |   await expect(page.getByLabel('白板学习对象')).toHaveValue('');
  140 |   await expect(page.getByLabel('讲解主题')).toHaveValue('尚未生成也不能丢失的匿名主题');
  141 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载原主题与请求', exact: true }).click();
  142 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8'));
  143 |   expect(copy.form).toMatchObject({ prompt: '尚未生成也不能丢失的匿名主题', objective: '保留我的完整教学目标。' });
  144 |   await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  145 |   await expect(page.getByLabel('白板学习对象')).toHaveValue(f.studentId!);
  146 | });
  147 | 
  148 | test('another explicit local manuscript cannot replace uncached dirty input until the current complete copy is downloaded', async ({ page }) => {
  149 |   await fixture(page); await generate(page); await ready(page);
  150 |   await page.getByLabel('讲解概要').fill('第一份可恢复的完整本机改稿。');
  151 |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.description))).toContain('第一份可恢复的完整本机改稿。');
  152 |   await page.reload(); await ready(page);
  153 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  154 |     if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value);
  155 |   }; });
  156 |   await page.getByLabel('讲解概要').fill('尚无本机缓存的第二份完整改稿。');
  157 |   await page.getByText('查看其他本机改稿', { exact: true }).click();
  158 |   const restore = page.getByRole('button', { name: '恢复这份本机改稿', exact: true }).first(); await expect(restore).toBeDisabled();
  159 |   await expect(page.getByLabel('讲解概要')).toHaveValue('尚无本机缓存的第二份完整改稿。');
  160 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  161 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('尚无本机缓存的第二份完整改稿。');
  162 |   await expect(restore).toBeEnabled(); await restore.click();
  163 |   await expect(page.getByLabel('讲解概要')).toHaveValue('第一份可恢复的完整本机改稿。');
  164 | });
  165 | 
  166 | test('recovery: an uncached original cancellation survives object changes until its exact command is downloaded', async ({ page }) => {
  167 |   await fixture(page); await generate(page, '匿名观察 [topic-pause-once]');
  168 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  169 |     if (key.startsWith('studyagent.topic-whiteboard.command.')) throw new DOMException('Synthetic unavailable command storage', 'QuotaExceededError'); return original.call(this, key, value);
  170 |   }; });
  171 |   let writes = 0;
  172 |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/cancel', async route => {
  173 |     writes++; expect((await route.fetch()).status()).toBe(201); await route.abort('failed');
  174 |   });
```