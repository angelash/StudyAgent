# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-project.spec.ts >> a published source course opens one real project, completes all frozen stages and returns to its original course
- Location: tests\e2e\source-course-project.spec.ts:40:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.cl-answer-feedback')
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.cl-answer-feedback') with timeout 15000ms
  - waiting for locator('.cl-answer-feedback')

```

```yaml
- alert: 教学课堂 · StudyAgent
- main:
  - region "教学白板":
    - button "离开课堂"
    - button "区分事实与解释 断点已同步": 区分事实与解释
    - button "缩小白板": −
    - button "重置缩放": 100%
    - button "放大白板": ＋
    - button "上一页白板": ‹
    - text: 2 / 2
    - button "下一页白板" [disabled]: ›
    - button "补一张讲解图": 配图
    - button "导出课堂笔记"
    - button "课堂设置"
    - button "切换对话面板"
    - heading "核查一个常见误区" [level=2]
    - list:
      - listitem: ·结果不同
      - listitem: ·仍需比较原因
    - heading "停下来，检查理解" [level=2]
    - list:
      - listitem: ·先保留自己的判断
      - listitem: ·提示与首次答案分别记录
    - heading "迁移与总结" [level=2]
    - list:
      - listitem: ·保留观察
      - listitem: ·核查替代解释
    - button "开启讲解声音" [disabled]
    - paragraph: 保留依据、替代解释与局限。
  - separator "调整对话面板宽度"
  - complementary:
    - text: Chat history
    - button "隐藏对话面板"
    - tablist "课堂内容":
      - tab "讲解与插问"
      - tab "课堂练习" [selected]
      - tab "单元项目"
    - button "展开独立练习 ↗"
    - region "课堂练习复盘":
      - navigation "课堂练习进度":
        - button "第1题": "1"
        - button "第2题": "2"
        - button "本次复盘"
      - text: PRACTICE / 本次记录
      - heading "先看清这次，再决定下一步。" [level=2]
      - paragraph: 以下只汇总本组首次作答。提示、跳过和答错分别保留，不由正确率直接判断稳定掌握。
      - term: 已记录
      - definition: 2/2
      - term: 独立答对
      - definition: "0"
      - term: 答错
      - definition: "1"
      - term: 跳过
      - definition: "0"
      - term: 不会
      - definition: "0"
      - term: 使用帮助
      - definition: "1"
      - paragraph: “使用帮助”可能与答对、答错、跳过或不会重合。回看和重新选择不会覆盖首次提交。
      - heading "先复盘这些题" [level=3]
      - list:
        - listitem:
          - text: 第1题 · 辅助答对
          - heading "怎样区分观察与解释？" [level=4]
          - paragraph: 保留观察和替代解释，补充可区分的证据。
          - button "回看第1题"
        - listitem:
          - text: 第2题 · 答错
          - heading "哪一种做法能区分两种解释？" [level=4]
          - paragraph: 保留观察和替代解释，补充可区分的证据。
          - button "回看第2题"
      - button "返回课程，安排下一步"
      - button "回看全部题目"
    - button "‹ 上一步"
    - text: 6 / 6
    - button "下一步 ›"
    - button "下一课 →"
    - group "调整讲法":
      - button "提问" [pressed]
      - button "换个例子"
      - button "说简单点"
      - button "补先修"
      - button "比较讲法"
    - textbox "向课堂老师提问":
      - /placeholder: Ask a question…
    - button "语音提问": ♩
    - button "继续讲解": ▷
    - button "停止课堂讲解": ■
    - combobox "选择大模型":
      - option "Auto · 当前默认模型"
```

# Test source

```ts
  1   | import {test,expect,type Page} from '@playwright/test';
  2   | import {browserEvidence} from './evidence';
  3   | const api='http://localhost:'+(process.env.E2E_API_PORT??4107)+'/api',evidence=browserEvidence('source-project');let address=0;
  4   | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok,method+' '+path+' -> '+response.status).toBe(true);return(await response.json()).data;}
  5   | async function course(actor:any){
  6   |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'匿名观察原文',sections:['匿名阅览室在两个周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'从来源到自己的作品',goal:'以来源和条件比较替代解释，并设计自己的新情境。',language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});
  7   |   let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');return call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});
  8   | }
  9   | async function enter(page:Page){
  10  |   page.on('dialog',dialog=>void dialog.accept());const suffix=crypto.randomUUID(),principal='source-project-'+suffix+'@local.test',credential='Source-project-'+suffix,response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.22.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  11  |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);const row=await course(actor);await page.goto('/studio/source-courses?course='+row.id);return{actor,row};
  12  | }
  13  | async function finishReading(page:Page,actor:any){
  14  |   await expect(page.locator('.cl-session-navigation')).toBeVisible();
  15  |   const sessionId=new URL(page.url()).searchParams.get('session')!,session=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);
  16  |   for(let step=0;step<session.lesson.steps.length;step++){
  17  |     await expect(page.locator('.cl-session-navigation')).toContainText((step+1)+' / '+session.lesson.steps.length);
  18  |     await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  19  |   }
  20  |   await expect(page.getByRole('dialog',{name:'课堂学习里程碑',exact:true})).toBeVisible();
  21  |   await page.getByRole('button',{name:'去检查理解 →',exact:true}).click();
  22  |   return session;
  23  | }
  24  | async function finishQuestions(page:Page,session:any){
  25  |   for(let index=0;index<session.lesson.questions.length;index++){
  26  |     await page.getByRole('button',{name:'第'+(index+1)+'题',exact:true}).click();
  27  |     if(index%3===2)await page.getByRole('button',{name:'Skip',exact:true}).click();
  28  |     else{
  29  |       if(index===0){await page.getByRole('button',{name:'先给我一个提示',exact:true}).click();await expect(page.locator('.cl-hint')).toHaveCount(1);}
  30  |       await page.locator('.cl-practice-options label').first().click();await page.getByRole('button',{name:'Check →',exact:true}).click();
  31  |     }
> 32  |     await expect(page.locator('.cl-answer-feedback')).toBeVisible();
      |                                                       ^ Error: expect(locator).toBeVisible() failed
  33  |   }
  34  | }
  35  | async function leaveClassroom(page:Page,standalone=false){
  36  |   await page.getByRole('button',{name:standalone?'关闭独立练习':'离开课堂',exact:true}).click();
  37  |   await page.getByRole('button',{name:'保存并离开',exact:true}).click();
  38  | }
  39  | 
  40  | test('a published source course opens one real project, completes all frozen stages and returns to its original course',async({page})=>{
  41  |   test.setTimeout(180000);const{actor,row}=await enter(page);await expect(page.getByLabel('资料课程项目',{exact:true})).toContainText('尚未设置独立单元核查');expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(0);
  42  |   expect(row.lessons).toHaveLength(2);
  43  |   for(let index=0;index<row.lessons.length;index++){
  44  |     const card=page.locator('.sc-lesson').nth(index);await card.getByRole('link',{name:'开始讲解 →',exact:true}).click();
  45  |     const session=await finishReading(page,actor);await finishQuestions(page,session);await leaveClassroom(page);
  46  |     await expect(card.getByLabel('讲解与练习记录',{exact:true})).toContainText('讲解已读');
  47  |     await expect(card.getByLabel('讲解与练习记录',{exact:true})).toContainText('已作答 2/2');
  48  |   }
  49  |   const completed=await call(actor,'GET','/learning/source-courses/'+row.id);
  50  |   expect(completed.journey.lessons.every((item:any)=>item.reading.state==='read'&&item.practice.summary.complete)).toBe(true);
  51  |   expect(completed.journey.unitCheck).toBe('not_configured');
  52  |   await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('button',{name:'开始这个项目 →',exact:true})).toBeEnabled();expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(0);await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('STEP 1 OF 5');const projectId=new URL(page.url()).searchParams.get('project')!;
  53  |   let project=await call(actor,'GET','/learning/projects/'+projectId);expect(project.sourceCourseId).toBe(row.id);expect(project.definition.sourceCourse.objectives).toHaveLength(2);
  54  |   for(let index=0;index<project.definition.stages.length;index++){
  55  |     const stage=project.definition.stages[index];await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText(stage.title);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  56  |     for(const field of stage.fields){await page.getByRole('textbox',{name:field.label,exact:true}).fill('匿名来源与新情境的过程、适用条件和待核查边界：'+field.id);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();}
  57  |     await page.getByRole('button',{name:'下一步 ›',exact:true}).click();for(const criterion of await page.locator('.pj-reflection .pj-ratings fieldset').all()){await criterion.getByRole('radio').nth(1).check();await criterion.locator('textarea').fill('当前作品保留初步依据，仍需要比较条件和反例。');}
  58  |     await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.getByRole('button',{name:new RegExp('已提交 '+(index+1)+'/3')})).toBeVisible();if(index<2)await page.getByRole('button',{name:'下一阶段 ›',exact:true}).click();
  59  |   }
  60  |   project=await call(actor,'GET','/learning/projects/'+projectId);expect(project.submissions).toHaveLength(3);expect(project.reviews).toHaveLength(0);await page.reload();await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();await expect(page).toHaveURL(new RegExp('course='+row.id));await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toBeVisible();expect(new URL(page.url()).searchParams.get('project')).toBe(projectId);expect((await call(actor,'GET','/learning/source-courses/'+row.id)).formalMeasurementEligible).toBe(false);
  61  | });
  62  | 
  63  | test('a project URL bound to another source course clears the old work instead of silently changing the course',async({page})=>{
  64  |   const{actor,row}=await enter(page);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('原资料课程的独立本机稿');const url=new URL(page.url()),other=await course(actor);url.searchParams.set('sourceCourseId',other.id);await page.goto(url.toString());await expect(page.getByText('项目与当前课程入口不一致，请返回课程重新进入。',{exact:true})).toBeVisible();await expect(page.locator('.pj-artifact')).toHaveCount(0);expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(1);expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+other.id)).projects).toHaveLength(0);
  65  | });
  66  | 
  67  | for(const width of [390,768,1440])test('source-course project entry and frozen objectives fit at '+width,async({page})=>{
  68  |   await page.setViewportSize({width,height:1000});await enter(page);await expect(page.getByRole('link',{name:'打开资料应用项目 →',exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.getByText('冻结课程目标与原文位置',{exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/source-project-'+width+'.png',fullPage:true});
  69  | });
  70  | 
  71  | test('source reading, assisted practice and project draft return to their exact saved objects in one continuous journey',async({page})=>{
  72  |   test.setTimeout(90000);const{actor,row}=await enter(page),first=page.locator('.sc-lesson').first();await first.getByRole('link',{name:'开始讲解 →',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('1 / 6');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 6');const sessionId=new URL(page.url()).searchParams.get('session')!;
  73  |   await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await expect(first.getByLabel('讲解与练习记录',{exact:true})).toContainText('讲解进行中');
  74  |   await first.getByRole('link',{name:'进入课堂练习',exact:true}).click();await expect(page.locator('.cl-practice-options label')).toHaveCount(4);expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);await page.getByRole('button',{name:'先给我一个提示',exact:true}).click();await expect(page.locator('.cl-hint')).toHaveCount(1);await page.locator('.cl-practice-options label').first().click();await page.getByRole('button',{name:'Check →',exact:true}).click();await expect(page.locator('.cl-answer-feedback')).toContainText('使用过提示');await page.getByRole('button',{name:'关闭独立练习',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await expect(first.getByLabel('讲解与练习记录',{exact:true})).toContainText('已作答 1/2');await expect(first.getByLabel('讲解与练习记录',{exact:true})).toContainText('独立首答正确 0 · 使用帮助 1');
  75  |   await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('来源课程项目的保存稿');await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.getByText('草稿和自评准备已保存。',{exact:true})).toBeVisible();const projectId=new URL(page.url()).searchParams.get('project')!;await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();
  76  |   const records=page.getByLabel('我的资料项目记录',{exact:true});await records.locator('summary').click();await expect(records).toContainText('已保存内容 1/3');await records.getByRole('link',{name:'继续这份项目 →',exact:true}).click();await expect(page.getByRole('textbox',{name:'我准备核查的主张',exact:true})).toHaveValue('来源课程项目的保存稿');expect(new URL(page.url()).searchParams.get('project')).toBe(projectId);await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();
  77  |   await first.getByRole('link',{name:'继续讲解 →',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 6');expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await first.getByRole('link',{name:'进入课堂练习',exact:true}).click();await expect(page.locator('.cl-practice-prompt>small')).toContainText('2 / 2');expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);const current=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(current.answers).toHaveLength(1);expect((await call(actor,'GET','/learning/source-courses/'+row.id)).formalMeasurementEligible).toBe(false);
  78  | });
  79  | 
  80  | test('returning from a course restores the personal project step and mode while an explicit URL takes priority',async({page})=>{
  81  |   await enter(page);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('准备核查一个有条件的解释');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'原文位置与依据',exact:true}).fill('匿名来源第1段，保留适用条件');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('整理证据与附件');await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('整理证据与附件');
  82  |   await page.getByRole('button',{name:'完整作品',exact:true}).click();await page.getByRole('link',{name:'‹ 返回课程',exact:true}).click();await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.locator('.pj-stage-heading')).toBeVisible();await expect(page.getByRole('textbox',{name:'我准备核查的主张',exact:true})).toHaveValue('准备核查一个有条件的解释');const url=new URL(page.url());url.searchParams.set('step','intro');url.searchParams.delete('view');await page.goto(url.toString());await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('STEP 1 OF 5');
  83  | });
  84  | 
  85  | test('adult course journey keeps reading, unit check and project separate and resumes the same saved classroom',async({page})=>{
  86  |   await enter(page);await page.goto('/studio/classroom?unit=0&panel=units');const journey=page.getByLabel('本单元学习进程',{exact:true});await journey.locator('summary').click();await expect(journey).toContainText('社会学视角综合核查');const first=journey.locator('ol>li').first();await first.getByRole('button',{name:'开始讲解',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');const sessionId=new URL(page.url()).searchParams.get('session')!;await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await journey.locator('summary').click();await expect(first).toContainText('讲解进行中');await first.getByRole('button',{name:'继续讲解',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);
  87  | });
  88  | 
  89  | test('an entire adult unit retains every lesson, complete practice, unit check and all project submissions as separate facts',async({page})=>{
  90  |   test.setTimeout(300000);const{actor}=await enter(page),catalog=await call(actor,'GET','/learning/classroom/catalog'),unit=catalog.course.units[0],lessons=unit.lectures.flatMap((lecture:any)=>lecture.lessons);
  91  |   const journey=page.getByLabel('本单元学习进程',{exact:true});
  92  |   for(let index=0;index<lessons.length;index++){
  93  |     await page.goto('/studio/classroom?unit=0&panel=units');await journey.locator('summary').click();
  94  |     await journey.locator('ol>li').nth(index).getByRole('button',{name:'开始讲解',exact:true}).click();
  95  |     const session=await finishReading(page,actor);await finishQuestions(page,session);await leaveClassroom(page);
  96  |   }
  97  |   await journey.locator('summary').click();await journey.locator('ol>li').last().getByRole('button',{name:'开始练习',exact:true}).click();
  98  |   await expect(page.locator('.cl-practice-options label').first()).toBeVisible();
  99  |   const checkId=new URL(page.url()).searchParams.get('session')!,check=await call(actor,'GET','/learning/classroom/sessions/'+checkId);
  100 |   await finishQuestions(page,check);await leaveClassroom(page,true);await journey.locator('summary').click();
  101 |   await journey.getByRole('link',{name:'开始项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();
  102 |   await expect(page.getByRole('region',{name:'当前项目步骤'})).toBeVisible();const projectId=new URL(page.url()).searchParams.get('project')!,project=await call(actor,'GET','/learning/projects/'+projectId);
  103 |   for(let index=0;index<project.definition.stages.length;index++){
  104 |     const stage=project.definition.stages[index];await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText(stage.title);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  105 |     for(const field of stage.fields){await page.getByRole('textbox',{name:field.label,exact:true}).fill('合成整单元旅程作品，保留比较条件与未核查解释：'+field.id);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();}
  106 |     await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  107 |     for(const criterion of await page.locator('.pj-reflection .pj-ratings fieldset').all()){await criterion.getByRole('radio').nth(1).check();await criterion.locator('textarea').fill('这是合成操作测试中的自评，仍需要真实教师核查。');}
  108 |     await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.getByRole('button',{name:new RegExp('已提交 '+(index+1)+'/3')})).toBeVisible();
  109 |     if(index<project.definition.stages.length-1)await page.getByRole('button',{name:'下一阶段 ›',exact:true}).click();
  110 |   }
  111 |   await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();await expect(page).toHaveURL(/unit=0/);await journey.locator('summary').click();
  112 |   const final=await call(actor,'GET','/learning/classroom/catalog'),ids=lessons.map((lesson:any)=>lesson.id),activities=final.lessonActivities.filter((item:any)=>ids.includes(item.lessonId));
  113 |   expect(activities).toHaveLength(lessons.length);expect(activities.every((item:any)=>item.reading.state==='read'&&item.practice.summary.complete)).toBe(true);
  114 |   expect(final.lessonActivities.find((item:any)=>item.lessonId==='unit-exam:'+unit.id).practice.summary.complete).toBe(true);
  115 |   expect(final.projectActivities.find((item:any)=>item.projectId===projectId)).toMatchObject({submittedStages:3,reviewedStages:0,readyStages:0});
  116 |   await expect(journey).toContainText('已提交 3/3');await expect(journey).toContainText('最新提交已有人工复核 0/3');
  117 |   await page.reload();await journey.locator('summary').click();await expect(journey).toContainText('已提交 3/3');
  118 | });
  119 | 
```