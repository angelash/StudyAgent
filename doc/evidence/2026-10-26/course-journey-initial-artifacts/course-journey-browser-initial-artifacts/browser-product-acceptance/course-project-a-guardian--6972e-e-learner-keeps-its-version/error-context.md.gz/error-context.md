# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-project.spec.ts >> a guardian reviews a learner submission in the curriculum project workspace and the learner keeps its version
- Location: tests\e2e\course-project.spec.ts:52:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '完整作品', exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - alert [ref=f2e2]: 课程项目 · StudyAgent
  - main [ref=f2e3]:
    - generic [ref=f2e4]:
      - link "‹ 返回课程" [ref=f2e5] [cursor=pointer]:
        - /url: /studio?view=courses&course=studio_course_8fe7d4c1-0662-4ce2-be54-f09a45499cd6&unit=unit%3A1%3A%E6%95%B0%E4%B8%8E%E8%BF%90%E7%AE%97&panel=outline
      - generic [ref=f2e6]: LEARNING STUDIO / PROJECT
      - button "导出项目" [ref=f2e7] [cursor=pointer]
    - generic [ref=f2e8]:
      - complementary [ref=f2e9]:
        - text: COURSE PROJECT
        - heading "数与运算 · 情境迁移任务" [level=1] [ref=f2e10]
        - paragraph [ref=f2e11]: 在不同于讲解例题的真实情境中运用数与运算的关键关系，并说明依据。
        - generic [ref=f2e12]:
          - text: 分阶段完成作品
          - generic [ref=f2e13]: 1/3
        - navigation "项目阶段" [ref=f2e14]:
          - button "✓ 在新情境中尝试 已有提交，可继续修订" [ref=f2e15] [cursor=pointer]:
            - generic [ref=f2e16]: ✓
            - generic [ref=f2e17]:
              - text: 在新情境中尝试
              - generic [ref=f2e18]: 已有提交，可继续修订
          - button "02 解释理由与依据 等待开始" [ref=f2e19] [cursor=pointer]:
            - generic [ref=f2e20]: "02"
            - generic [ref=f2e21]:
              - text: 解释理由与依据
              - generic [ref=f2e22]: 等待开始
          - button "03 核查并准备下一次尝试 等待开始" [ref=f2e23] [cursor=pointer]:
            - generic [ref=f2e24]: "03"
            - generic [ref=f2e25]:
              - text: 核查并准备下一次尝试
              - generic [ref=f2e26]: 等待开始
        - paragraph [ref=f2e27]: 提交与自评记录本次作品。AI 建议帮助修改，知识掌握仍需独立核查。
        - group [ref=f2e28]:
          - generic "项目版本与内容来源" [ref=f2e29] [cursor=pointer]
        - group [ref=f2e30]:
          - generic "可查看的项目记录" [ref=f2e31] [cursor=pointer]
      - generic [ref=f2e32]:
        - button "逐步学习这个项目 →" [ref=f2e33] [cursor=pointer]
        - generic [ref=f2e34]:
          - generic [ref=f2e35]:
            - generic [ref=f2e36]: STAGE 1 / 3
            - heading "在新情境中尝试" [level=2] [ref=f2e37]
            - paragraph [ref=f2e38]: 围绕“数与运算”串联概念理解、独立执行与迁移验证。
          - status [ref=f2e39]: 已保存至服务器
        - paragraph [ref=f2e40]: 正在查看学习者项目。产物由学习者修订；请在提交历史中选择版本进行复核。
        - group "阶段产物" [ref=f2e41]:
          - generic [ref=f2e43]:
            - generic [ref=f2e44]: 我的新情境
            - generic [ref=f2e45]: 描述一个与课程不同但需要同样知识的例子。
            - textbox "我的新情境" [disabled] [ref=f2e46]: 匿名新情境：保留步骤并说明共同单位。
          - generic [ref=f2e47]:
            - generic [ref=f2e48]: 我的做法或作品
            - generic [ref=f2e49]: 保留你的过程，可以分行写步骤。
            - textbox "我的做法或作品" [disabled] [ref=f2e50]: 匿名新情境：保留步骤并说明共同单位。
        - generic [ref=f2e51]:
          - region "项目文件附件" [ref=f2e52]:
            - generic [ref=f2e54]:
              - text: FILES & ARTIFACTS
              - heading "保留作品的真实文件" [level=3] [ref=f2e55]
            - paragraph [ref=f2e56]: 图片、PDF、UTF-8文字/代码、录音与Office原件，每份最多20MiB。文件就绪后，选择加入当前阶段，再保存或提交。
            - generic [ref=f2e57]: 还没有项目文件。文字草稿可以随时保存。
          - region "项目证据" [ref=f2e58]:
            - generic [ref=f2e59]:
              - generic [ref=f2e60]:
                - text: EVIDENCE
                - heading "保留可以核查的依据" [level=3] [ref=f2e61]
              - button "＋ 添加证据" [disabled] [ref=f2e62]
            - paragraph [ref=f2e63]: 记录匿名观察、资料摘录或来源链接。链接用于引用，平台不会自动读取。
            - generic [ref=f2e64]: 还没有证据记录。可以先写草稿，再补充依据。
        - group [ref=f2e66]:
          - generic "RUBRIC 按量规检查自己的作品" [ref=f2e67] [cursor=pointer]
          - paragraph [ref=f2e68]: 逐项选择符合当前产物的描述，并给出依据。保存草稿会同时保存这些准备；阶段提交时冻结自评。
          - generic [ref=f2e69]:
            - group "过程与作品" [ref=f2e70]:
              - generic [ref=f2e72]:
                - generic [ref=f2e73] [cursor=pointer]:
                  - radio "0 还未形成过程" [disabled] [ref=f2e74]
                  - generic [ref=f2e75]: "0"
                  - generic [ref=f2e76]: 还未形成过程
                - generic [ref=f2e77] [cursor=pointer]:
                  - radio "1 有部分尝试" [checked] [disabled] [ref=f2e78]
                  - generic [ref=f2e79]: "1"
                  - generic [ref=f2e80]: 有部分尝试
                - generic [ref=f2e81] [cursor=pointer]:
                  - radio "2 过程完整，条件清楚" [disabled] [ref=f2e82]
                  - generic [ref=f2e83]: "2"
                  - generic [ref=f2e84]: 过程完整，条件清楚
                - generic [ref=f2e85] [cursor=pointer]:
                  - radio "3 比较方法并检查适用条件" [disabled] [ref=f2e86]
                  - generic [ref=f2e87]: "3"
                  - generic [ref=f2e88]: 比较方法并检查适用条件
              - generic [ref=f2e89]:
                - text: 过程与作品的具体依据
                - textbox "自评过程与作品的具体依据" [disabled] [ref=f2e90]:
                  - /placeholder: 指出作品中的哪一处支持这个选择，也可以如实写还缺什么。
                  - text: 有过程记录，核查方式待补充。
            - group "理由与核查" [ref=f2e91]:
              - generic [ref=f2e93]:
                - generic [ref=f2e94] [cursor=pointer]:
                  - radio "0 还未说明理由" [disabled] [ref=f2e95]
                  - generic [ref=f2e96]: "0"
                  - generic [ref=f2e97]: 还未说明理由
                - generic [ref=f2e98] [cursor=pointer]:
                  - radio "1 有理由但依据不清" [checked] [disabled] [ref=f2e99]
                  - generic [ref=f2e100]: "1"
                  - generic [ref=f2e101]: 有理由但依据不清
                - generic [ref=f2e102] [cursor=pointer]:
                  - radio "2 知识与步骤对应，有检查" [disabled] [ref=f2e103]
                  - generic [ref=f2e104]: "2"
                  - generic [ref=f2e105]: 知识与步骤对应，有检查
                - generic [ref=f2e106] [cursor=pointer]:
                  - radio "3 用反例或另一种方法验证" [disabled] [ref=f2e107]
                  - generic [ref=f2e108]: "3"
                  - generic [ref=f2e109]: 用反例或另一种方法验证
              - generic [ref=f2e110]:
                - text: 理由与核查的具体依据
                - textbox "自评理由与核查的具体依据" [disabled] [ref=f2e111]:
                  - /placeholder: 指出作品中的哪一处支持这个选择，也可以如实写还缺什么。
                  - text: 有过程记录，核查方式待补充。
            - group "帮助与下一步" [ref=f2e112]:
              - generic [ref=f2e114]:
                - generic [ref=f2e115] [cursor=pointer]:
                  - radio "0 还未记录" [disabled] [ref=f2e116]
                  - generic [ref=f2e117]: "0"
                  - generic [ref=f2e118]: 还未记录
                - generic [ref=f2e119] [cursor=pointer]:
                  - radio "1 知道哪里需要帮助" [checked] [disabled] [ref=f2e120]
                  - generic [ref=f2e121]: "1"
                  - generic [ref=f2e122]: 知道哪里需要帮助
                - generic [ref=f2e123] [cursor=pointer]:
                  - radio "2 明确帮助和下一次尝试" [disabled] [ref=f2e124]
                  - generic [ref=f2e125]: "2"
                  - generic [ref=f2e126]: 明确帮助和下一次尝试
                - generic [ref=f2e127] [cursor=pointer]:
                  - radio "3 提出能检验独立完成的新情境" [disabled] [ref=f2e128]
                  - generic [ref=f2e129]: "3"
                  - generic [ref=f2e130]: 提出能检验独立完成的新情境
              - generic [ref=f2e131]:
                - text: 帮助与下一步的具体依据
                - textbox "自评帮助与下一步的具体依据" [disabled] [ref=f2e132]:
                  - /placeholder: 指出作品中的哪一处支持这个选择，也可以如实写还缺什么。
                  - text: 有过程记录，核查方式待补充。
          - generic [ref=f2e133]:
            - text: 这次修订改变了什么
            - generic [ref=f2e134]: 再次提交时必填；说明如何回应之前的问题或反馈。
            - textbox "这次修订改变了什么 再次提交时必填；说明如何回应之前的问题或反馈。" [disabled] [ref=f2e135]
        - region "项目 AI 建议" [ref=f2e137]:
          - generic [ref=f2e139]:
            - text: AI FEEDBACK
            - heading "让助教帮你寻找证据缺口" [level=3] [ref=f2e140]
          - paragraph [ref=f2e141]: 建议针对已保存的阶段草稿，不替代你的判断和人工复核。
          - generic [ref=f2e142]:
            - generic [ref=f2e143]:
              - generic [ref=f2e144]: 模型
              - combobox "选择大模型" [ref=f2e145] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - paragraph [ref=f2e146]:
              - generic [ref=f2e147]: DeepSeek V4.1 Flash
              - generic [ref=f2e148]: DeepSeek V4 Flash
          - generic [ref=f2e149]:
            - paragraph [ref=f2e150]: 本次只分析已保存文字、证据和文件说明，尚未读取附件内容。
            - group [ref=f2e151]:
              - generic "选择建议范围" [ref=f2e152] [cursor=pointer]
            - button "分析已保存草稿" [disabled] [ref=f2e153]
        - region "阶段提交历史" [ref=f2e154]:
          - generic [ref=f2e156]:
            - text: VERSIONS
            - heading "每次提交都有迹可循" [level=3] [ref=f2e157]
          - button "提交 v1 首次提交 2026/10/26 00:53:53 · 1 条人工复核 查看 →" [ref=f2e158] [cursor=pointer]:
            - generic [ref=f2e159]: 提交 v1
            - generic [ref=f2e160]:
              - text: 首次提交
              - generic [ref=f2e161]: 2026/10/26 00:53:53 · 1 条人工复核
            - generic [ref=f2e162]: 查看 →
        - generic [ref=f2e163]:
          - button "保存阶段草稿" [disabled] [ref=f2e164]
          - button "提交修订版本 →" [disabled] [ref=f2e165]
          - button "下一阶段 ›" [ref=f2e166] [cursor=pointer]
      - complementary [ref=f2e167]:
        - text: PROJECT NOTEBOOK
        - heading "把学习连起来" [level=2] [ref=f2e168]
        - paragraph [ref=f2e169]: 参考此前提交的产物，说明它与当前问题的联系。
        - group [ref=f2e170]:
          - generic "01 数与运算 · 情境迁移任务" [ref=f2e171] [cursor=pointer]:
            - generic [ref=f2e172]: "01"
            - text: 数与运算 · 情境迁移任务
        - paragraph [ref=f2e173]: 只记录匿名情境；不上传真实姓名、联系方式或未经同意的个人资料。
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { mkdirSync } from 'node:fs';
  3  | const api=`http://localhost:${process.env.E2E_API_PORT??'4107'}/api`;
  4  | async function login(page:Page) {
  5  |   const suffix=Date.now()+'-'+Math.floor(Math.random()*100000),principal='projects-'+suffix+'@local.test',credential='Projects-'+suffix;
  6  |   const response=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  7  |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);return actor;
  8  | }
  9  | async function capture(page:Page,name:string){if(!process.env.E2E_PROJECT_SNAPSHOT)return;mkdirSync('data/qa/course-projects',{recursive:true});await page.evaluate(()=>window.scrollTo(0,0));await page.locator('.pj-dialog').evaluateAll(elements=>elements.forEach(element=>element.scrollTop=0));await page.screenshot({path:`data/qa/course-projects/${name}.png`,fullPage:true});}
  10 | async function selfAssess(page:Page) {
  11 |   const rubric=page.locator('.pj-reflection');if(!await rubric.getAttribute('open'))await rubric.locator('summary').click();
  12 |   const fields=rubric.locator('.pj-ratings fieldset');for(let index=0;index<await fields.count();index++){
  13 |     await fields.nth(index).getByRole('radio').nth(1).check();await fields.nth(index).getByRole('textbox').fill('具体依据：保留了观察记录，另一种解释仍需要比较。');
  14 |   }
  15 | }
  16 | test('project stages save artifacts, evidence and self-assessment; immutable submissions remain available after revisions',async({page})=>{
  17 |   test.setTimeout(90000);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await login(page);
  18 |   await page.goto('/studio/classroom?unit=0&panel=units&q=社会');await page.getByRole('link',{name:'开始项目 →',exact:true}).click();
  19 |   await expect(page.getByRole('button',{name:'开始这个项目 →'})).toBeVisible();
  20 |   await page.getByRole('button',{name:'开始这个项目 →'}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.locator('.pj-stage-heading')).toContainText('界定研究问题');
  21 |   await page.getByLabel('匿名情境与已知观察').fill('匿名社区观察：周末阅览室有排队，工作日有空位。');await page.getByLabel('可以研究的问题').fill('比较开放时间与使用条件，解释两个时段的差别。');
  22 |   await page.getByRole('button',{name:'＋ 添加证据'}).click();await page.getByLabel('证据名称').fill('分时段观察记录');await page.getByLabel('观察或摘录').fill('两个周末和两个工作日各观察一次，仍缺少晚间记录。');await page.getByLabel('来源链接（可选）').fill('https://example.org/research');
  23 |   await selfAssess(page);await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.locator('.pj-notice')).toContainText('已保存');
  24 |   await page.reload();await expect(page.getByLabel('匿名情境与已知观察')).toHaveValue('匿名社区观察：周末阅览室有排队，工作日有空位。');await expect(page.getByLabel('证据名称')).toHaveValue('分时段观察记录');
  25 |   await expect(page.locator('.pj-ratings input:checked')).toHaveCount(4);
  26 |   await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.locator('.pj-history-row')).toHaveCount(1);
  27 |   await page.getByLabel('匿名情境与已知观察').fill('修订观察：补充晚间时段，区分使用规则和个人选择。');await page.getByLabel('这次修订改变了什么').fill('补充晚间观察，检查时间安排的替代解释。');
  28 |   await page.getByRole('button',{name:'提交修订版本 →'}).click();await expect(page.locator('.pj-history-row')).toHaveCount(2);
  29 |   await page.locator('.pj-history-row').filter({hasText:'提交 v1'}).click();const dialog=page.getByRole('dialog',{name:'项目提交版本'});await expect(dialog).toContainText('周末阅览室有排队');await expect(dialog).not.toContainText('修订观察');await expect(dialog).toContainText('还没有人工复核');await capture(page,'submission-v1');await dialog.getByRole('button',{name:'关闭提交版本'}).click();
  30 |   for(const width of [1440,768,390]){await page.setViewportSize({width,height:960});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await capture(page,'project-'+width);}
  31 |   await page.getByRole('button',{name:'下一阶段 ›'}).click();await expect(page.locator('.pj-stage-heading')).toContainText('比较机制与设计方法');await page.reload();await expect(page.locator('.pj-stage-heading')).toContainText('比较机制与设计方法');
  32 |   await page.getByRole('link',{name:'‹ 返回课程'}).click();await expect(page).toHaveURL(/\/studio\/classroom/);expect(new URL(page.url()).searchParams.get('panel')).toBe('units');expect(errors).toEqual([]);
  33 | });
  34 | test('a lost save response replays the same request; a stale page preserves local input and can recover',async({page})=>{
  35 |   test.setTimeout(90000);const actor=await login(page);await page.goto('/studio/projects?unitId=soc-u2');await page.getByRole('button',{name:'开始这个项目 →'}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();
  36 |   await page.getByLabel('与前一单元问题的联系').fill('本地输入：保留研究问题');const keys:string[]=[];let lost=false;
  37 |   await page.route('**/api/learning/projects/*',async route=>{if(route.request().method()!=='PATCH'){await route.continue();return;}keys.push(route.request().postDataJSON().requestKey);if(!lost){lost=true;const response=await route.fetch();expect(response.status()).toBe(200);await route.abort('failed');}else await route.continue();});
  38 |   await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.locator('.pj-notice')).toContainText('已保存');await expect(page.getByLabel('与前一单元问题的联系')).toHaveValue('本地输入：保留研究问题');expect(keys).toHaveLength(1); // The actor receipt confirms success without a second write.
  39 |   const projectId=new URL(page.url()).searchParams.get('project')!,headers={authorization:'Bearer '+actor.token,'content-type':'application/json'};
  40 |   const read=await fetch(api+'/learning/projects/'+projectId,{headers});const row=(await read.json()).data;
  41 |   const external=await fetch(api+'/learning/projects/'+projectId,{method:'PATCH',headers,body:JSON.stringify({expectedRevision:row.revision,requestKey:crypto.randomUUID(),stageId:row.currentStageId,artifact:{values:{link:'另一个页面保存的版本'},evidence:[]}})});expect(external.status).toBe(200);
  42 |   await page.getByLabel('与前一单元问题的联系').fill('冲突时必须保留的本地文字');await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.locator('.pj-error')).toContainText('其他页面更新');await expect(page.getByLabel('与前一单元问题的联系')).toHaveValue('冲突时必须保留的本地文字');
  43 |   const download=page.waitForEvent('download');await page.getByRole('button',{name:'保留本地副本并读取已保存版本'}).click();expect((await download).suggestedFilename()).toContain('草稿');await expect(page.getByLabel('与前一单元问题的联系')).toHaveValue('另一个页面保存的版本');await expect(page.locator('.pj-save-state')).toContainText('已保存');
  44 | });
  45 | test('unsaved-stage navigation asks to preserve work and unavailable AI leaves the saved artifact usable',async({page})=>{
  46 |   await login(page);await page.goto('/studio/projects?unitId=soc-u3');await page.getByRole('button',{name:'开始这个项目 →'}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await page.getByLabel('文字地图或资源表').fill('待保存的资源与进入条件');
  47 |   await page.getByRole('button',{name:/比较分层机制/}).click();const confirm=page.getByRole('dialog',{name:'保留项目修改'});await expect(confirm).toBeVisible();await confirm.getByRole('button',{name:'继续编辑'}).click();await expect(page.getByLabel('文字地图或资源表')).toHaveValue('待保存的资源与进入条件');
  48 |   await page.getByRole('button',{name:/比较分层机制/}).click();await confirm.getByRole('button',{name:'保存并继续'}).click();await expect(page.locator('.pj-stage-heading')).toContainText('比较分层机制');
  49 |   await page.getByRole('button',{name:/绘制资源与障碍地图/}).click();await expect(page.getByLabel('文字地图或资源表')).toHaveValue('待保存的资源与进入条件');
  50 |   await page.getByRole('button',{name:'分析已保存草稿'}).click();await expect(page.locator('.pj-error')).toBeVisible();await expect(page.getByLabel('文字地图或资源表')).toHaveValue('待保存的资源与进入条件');await page.getByRole('button',{name:'读取已保存版本',exact:true}).click();await expect(page.locator('.pj-error')).toHaveCount(0);await expect(page.getByRole('button',{name:'保存阶段草稿',exact:true})).toBeEnabled();
  51 | });
  52 | test('a guardian reviews a learner submission in the curriculum project workspace and the learner keeps its version',async({page})=>{
  53 |   test.setTimeout(90000);const actor=await login(page),headers={'content-type':'application/json',authorization:'Bearer '+actor.token};
  54 |   async function call(path:string,body:object,token=actor.token,method='POST'){const response=await fetch(api+path,{method,headers:{...headers,authorization:'Bearer '+token},body:JSON.stringify(body)});expect(response.status).toBe(method==='PUT'?200:201);return(await response.json()).data;}
  55 |   const studentId=(await call('/students',{nickname:'项目复核测试',grade:5,preferredSessionMinutes:15,defaultVersionMap:{math:'common',chinese:'common',english:'common'}})).profile.id;
  56 |   await call(`/students/${studentId}/learning-scope`,{subject:'math',grade:5,term:'upper',textbookVolumeId:null,textbookVersion:'项目测试范围',learnedAtomIds:['core:math:fractionadd'],currentAtomId:'core:math:fractionadd',minutesPerSession:15,progressMode:'knowledge',selectedLessonIds:[]},actor.token,'PUT');
  57 |   const preview=await call('/learning/studio/courses/preview',{studentId,subject:'math',title:'项目与核查'}),course=await call('/learning/studio/courses',{studentId,subject:'math',title:'项目与核查',objective:preview.objective,previewFingerprint:preview.fingerprint,requestKey:crypto.randomUUID()});
  58 |   const access=await call(`/students/${studentId}/learning-access`,{enabled:true,expectedVersion:0,requestKey:crypto.randomUUID(),reason:'测试孩子项目保存与人工复核'}),code=await call(`/students/${studentId}/learning-access/codes`,{expectedVersion:access.version,requestKey:crypto.randomUUID()});
  59 |   const learner=await call('/auth/learning-code',{code:code.code}),project=await call('/learning/projects',{studioCourseId:course.id,unitId:course.units[0].id},learner.token);
  60 |   const stage=project.definition.stages[0],ratings=project.definition.rubric.map((criterion:{id:string})=>({criterionId:criterion.id,level:1,evidence:'有过程记录，核查方式待补充。'}));
  61 |   const submitted=await call('/learning/projects/'+project.id+'/submissions',{expectedRevision:0,requestKey:crypto.randomUUID(),stageId:stage.id,artifact:{values:Object.fromEntries(stage.fields.map((field:{id:string})=>[field.id,'匿名新情境：保留步骤并说明共同单位。'])),evidence:[]},selfRatings:ratings,revisionNote:''},learner.token);
  62 |   await page.goto('/studio/projects?'+new URLSearchParams({studioCourseId:course.id,project:project.id,unitId:course.units[0].id,view:'complete'}));await expect(page.getByText('正在查看学习者项目。',{exact:false})).toBeVisible();await expect(page.getByRole('button',{name:'保存阶段草稿',exact:true})).toBeDisabled();await page.locator('.pj-history-row').click();
  63 |   const dialog=page.getByRole('dialog',{name:'项目提交版本'});for(const field of await dialog.locator('.pj-ratings fieldset').all()){await field.getByRole('radio').nth(2).check();await field.getByRole('textbox').fill('作品保留了步骤；建议再比较另一种核查方法。');}
  64 |   await dialog.getByLabel('具体反馈与下一步').fill('保留当前过程，下次补充独立检查结果。');await dialog.getByRole('button',{name:'保存人工复核'}).click();await expect(dialog).toContainText('保留当前过程，下次补充独立检查结果。');await capture(page,'guardian-review');
  65 |   const response=await fetch(api+'/learning/projects/'+project.id,{headers:{authorization:'Bearer '+learner.token}});const restored=(await response.json()).data;expect(restored.reviews).toHaveLength(1);expect(restored.reviews[0].reviewerRole).toBe('parent');expect(restored.submissions).toEqual(submitted.submissions);
  66 |   await dialog.getByRole('button',{name:'关闭提交版本'}).click();await page.goto('/studio?'+new URLSearchParams({view:'courses',course:course.id,student:studentId,subject:'math'}));
> 67 |   await page.getByRole('link',{name:'打开项目 →',exact:true}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.getByText('正在查看学习者项目。',{exact:false})).toBeVisible();await expect(page.locator('.pj-history-row')).toHaveCount(1);
     |                                                                                                                           ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  68 | });
  69 | test('all five adult projects complete their three stages and can cite earlier immutable artifacts',async({page})=>{
  70 |   test.setTimeout(180000);await login(page);
  71 |   for(let unit=1;unit<=5;unit++){
  72 |     await page.goto('/studio/projects?unitId=soc-u'+unit);await page.getByRole('button',{name:'开始这个项目 →'}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();
  73 |     for(let phase=0;phase<3;phase++){
  74 |       await expect(page.locator('.pj-stage-heading')).toContainText(`STAGE ${phase+1} / 3`);await expect(page.locator('.pj-artifact textarea')).toHaveCount(2);
  75 |       for(const field of await page.locator('.pj-artifact textarea').all())await field.fill(`匿名研究产物，单元${unit}阶段${phase+1}：记录观察条件、概念联系、替代解释和需要核查的限制。`);
  76 |       if(unit>1&&phase===0){const reference=page.locator('.pj-reference>details').first();await reference.locator('summary').click();await reference.getByRole('button',{name:'引用此版本摘录',exact:true}).first().click();await expect(page.getByLabel('证据名称')).toHaveValue(/摘录/);}
  77 |       await selfAssess(page);await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.locator('.pj-history-row')).toHaveCount(1);
  78 |       if(phase<2)await page.getByRole('button',{name:'下一阶段 ›'}).click();
  79 |     }
  80 |     await page.reload();await expect(page.locator('.pj-route-label')).toContainText('3/3');await expect(page.locator('.pj-history-row')).toHaveCount(1);await expect(page.locator('.pj-artifact textarea').first()).toHaveValue(new RegExp(`单元${unit}阶段3`));
  81 |   }
  82 | });
  83 | 
```