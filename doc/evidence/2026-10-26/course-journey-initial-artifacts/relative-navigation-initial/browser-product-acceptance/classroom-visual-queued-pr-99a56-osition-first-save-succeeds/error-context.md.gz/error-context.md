# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-visual.spec.ts >> queued previous clicks use each confirmed position, first save succeeds
- Location: tests\e2e\classroom-visual.spec.ts:27:41

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
    2,
-   1,
+   2,
  ]
```

# Page snapshot

```yaml
- generic:
  - alert [ref=f1e1]
  - main [ref=f1e2]:
    - region "教学白板" [ref=f1e3]:
      - generic [ref=f1e4]:
        - button "离开课堂" [ref=f1e5] [cursor=pointer]
        - button [ref=f1e8] [cursor=pointer]:
          - text: 社会学想象力
          - generic "断点已同步" [ref=f1e9]
      - generic [ref=f1e12]:
        - button "缩小白板" [ref=f1e13] [cursor=pointer]: −
        - button "重置缩放" [ref=f1e14] [cursor=pointer]: 100%
        - button "放大白板" [ref=f1e15] [cursor=pointer]: ＋
        - button "上一页白板" [disabled] [ref=f1e17]: ‹
        - generic [ref=f1e18]: 1 / 2
        - button "下一页白板" [ref=f1e19] [cursor=pointer]: ›
        - button "补一张讲解图" [ref=f1e21] [cursor=pointer]:
          - generic [aria-hidden] [ref=f1e22]: ▧
          - text: 配图
        - button "导出课堂笔记" [ref=f1e23] [cursor=pointer]
        - button "课堂设置" [ref=f1e26] [cursor=pointer]
        - button "切换对话面板" [ref=f1e29] [cursor=pointer]
      - generic [ref=f1e33]:
        - generic [ref=f1e34]:
          - heading "本节课导航" [level=2] [ref=f1e35]
          - list [ref=f1e36]:
            - listitem [ref=f1e37]: ·概念是什么？
            - listitem [ref=f1e38]: ·怎样解释生活？
            - listitem [ref=f1e39]: ·用什么证据核查？
        - generic [ref=f1e40]:
          - heading "社会学想象力" [level=2] [ref=f1e41]
          - list [ref=f1e42]:
            - listitem [ref=f1e43]: ·传记：个人经历与选择
            - listitem [ref=f1e44]: ·历史：时代、制度与社会条件
            - listitem [ref=f1e45]: ·交汇点：把个人处境放回社会背景
          - figure "传记与历史的交汇点 · 社会学想象力" [ref=f1e46]:
            - button "放大图片：传记与历史的交汇点 · 社会学想象力" [ref=f1e47] [cursor=pointer]:
              - img "个人处境与社会条件的交汇" [ref=f1e48]
              - generic [aria-hidden] [ref=f1e49]: ↗
        - generic [ref=f1e51]:
          - heading "先看问题的规模" [level=2] [ref=f1e52]
          - list [ref=f1e53]:
            - listitem [ref=f1e54]: ·个体处境：检查经历与求职过程
          - region "代码实验" [ref=f1e55]:
            - generic [ref=f1e56]:
              - generic [ref=f1e57]: JavaScript · 浏览器隔离计算
              - button "重置" [ref=f1e58] [cursor=pointer]
              - button "停止运行" [disabled] [ref=f1e59]
              - button "▶ 运行代码" [ref=f1e60] [cursor=pointer]
            - generic [ref=f1e61]:
              - generic [ref=f1e62]: 实验代码
              - textbox "实验代码" [ref=f1e63]: "const groups = [{name: \"甲地区\", unemployed: 20, population: 100}, {name: \"乙地区\", unemployed: 40, population: 1000}]; for (const g of groups) console.log(g.name + \": \" + (g.unemployed / g.population * 100).toFixed(1) + \"%\");"
            - generic [ref=f1e64]:
              - generic [ref=f1e65]: 程序输入 · 每行一项
              - textbox "程序输入" [ref=f1e66]:
                - /placeholder: 用 readLine() 逐行读取，结束时返回 null；input 是只读的输入行数组。
            - generic [ref=f1e67]:
              - status [ref=f1e68]: 草稿已保存
              - button "保存代码草稿" [ref=f1e69] [cursor=pointer]
              - button "导出我的实验草稿" [ref=f1e70] [cursor=pointer]
            - status [ref=f1e71]: 尚未运行
            - log "代码运行结果" [ref=f1e72]: 修改参数，再运行看看结果。
            - generic [ref=f1e73]: 修改会保存为你的实验草稿；输入可用 readLine() 逐行读取。也可以导出代码和输入，稍后继续。
      - generic [ref=f1e74]:
        - button "开启讲解声音" [disabled] [ref=f1e75]
        - paragraph [ref=f1e78]: 一个人找不到工作时，可以调查技能和求职过程；同一产业大量岗位一起消失时，
    - separator "调整对话面板宽度" [ref=f1e79]
    - complementary [ref=f1e80]:
      - generic [ref=f1e81]:
        - generic [ref=f1e82]: Chat history
        - button "隐藏对话面板" [ref=f1e85] [cursor=pointer]
      - tablist "课堂内容" [ref=f1e88]:
        - tab "讲解与插问" [selected] [ref=f1e89] [cursor=pointer]
        - tab "课堂练习" [ref=f1e90] [cursor=pointer]
        - tab "单元项目" [ref=f1e91] [cursor=pointer]
      - generic "课堂对话历史" [ref=f1e92]:
        - article [ref=f1e93]:
          - text: 02:20
          - paragraph [ref=f1e94]: 今天一起研究“社会学想象力”。
          - paragraph [ref=f1e95]: 先记住三个问题：这个概念指什么？
          - paragraph [ref=f1e96]: 它怎样解释具体生活？
          - paragraph [ref=f1e97]: 什么证据能帮助我们判断解释是否站得住？
          - button "♧ 本节课导航" [ref=f1e98] [cursor=pointer]
        - article [ref=f1e99]:
          - text: TEACHER
          - paragraph [ref=f1e100]: 米尔斯把个人的生活历程与时代、制度联系起来。
          - paragraph [ref=f1e101]: 分析时同时追问个人处境和处境形成的社会条件。
          - button "♧ 社会学想象力" [ref=f1e102] [cursor=pointer]
        - article [ref=f1e103]:
          - text: TEACHER
          - paragraph [ref=f1e104]: 一个人找不到工作时，可以调查技能和求职过程；同一产业大量岗位一起消失时，
          - button "♧ 先看问题的规模" [ref=f1e105] [cursor=pointer]
        - article [ref=f1e106]:
          - text: TEACHER
          - paragraph [ref=f1e107]: 同一地区多家工厂关闭，许多有经验的工人同时失业。
          - paragraph [ref=f1e108]: 个人技能可能相关，但岗位整体消失需要结构层面的解释。
          - button "♧ 把概念放进生活" [ref=f1e109] [cursor=pointer]
        - status [ref=f1e110]: ••• Paused
      - generic [ref=f1e111]:
        - button "‹ 上一步" [active] [ref=f1e112] [cursor=pointer]
        - generic [ref=f1e113]: 3 / 8
        - button "下一步 ›" [ref=f1e114] [cursor=pointer]
      - generic [ref=f1e115]:
        - group "调整讲法" [ref=f1e116]:
          - button "提问" [pressed] [ref=f1e117] [cursor=pointer]
          - button "换个例子" [ref=f1e118] [cursor=pointer]
          - button "说简单点" [ref=f1e119] [cursor=pointer]
          - button "补先修" [ref=f1e120] [cursor=pointer]
          - button "比较讲法" [ref=f1e121] [cursor=pointer]
        - generic [ref=f1e122]:
          - textbox "向课堂老师提问" [ref=f1e123]:
            - /placeholder: Ask a question…
          - button "语音提问" [ref=f1e124] [cursor=pointer]: ♩
          - button "继续讲解" [ref=f1e125] [cursor=pointer]: ▷
          - button "停止课堂讲解" [ref=f1e126] [cursor=pointer]: ■
        - combobox "选择大模型" [ref=f1e129] [cursor=pointer]:
          - option "Auto · 当前默认模型"
          - option "GPT-6.1 Sol"
          - option "GPT-6 Astra"
          - option "GPT-6 Luna"
          - option "Grok-4.7"
          - option "GLM-5.3 Flash"
          - option "DeepSeek V4.1 Flash · 默认" [selected]
          - option "Claude Opus 5.5"
          - option "Claude Sonnet 5"
          - option "GPT-6 Sol"
          - option "GPT-5.6 Sol"
          - option "GPT-5.6 Terra"
          - option "GPT-5.6 Luna"
          - option "GPT-5.5"
          - option "Grok-4.6"
          - option "GLM-5.2"
          - option "GLM-5.3"
          - option "Claude Opus 5"
          - option "Claude Fable 5.1"
          - option "MiMo V2.6 Pro"
          - option "MiMo V2.6 Flash"
          - option "MiMo V2.6 Pro Ultraspeed"
          - option "Qwen3.8 Max"
    - text: · · · · · · · · · · ·
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { browserEvidence } from './evidence';
  3   | const api = `http://localhost:${process.env.E2E_API_PORT ?? 4107}`, evidence = browserEvidence('classroom-visual');
  4   | let fixtureAddress = 0;
  5   | async function enter(page: Page) {
  6   |     const suffix = Date.now() + '-' + Math.floor(Math.random() * 100000), principal = 'visual-' + suffix + '@local.test', credential = 'Visual-only-' + suffix;
  7   |     // Only the isolated loopback fixture trusts this header. Each new QA learner gets its own registration bucket.
  8   |     const registered=await fetch(api + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-forwarded-for': '127.22.0.' + (++fixtureAddress) }, body: JSON.stringify({ principal, credential }) });
  9   |     expect(registered.status).toBe(201);const actor=(await registered.json()).data;
  10  |     await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  11  |     await page.goto('/parent/login');
  12  |     await page.getByLabel('登录账号').fill(principal);
  13  |     await page.getByLabel('密码').fill(credential);
  14  |     await page.getByRole('button', { name: '登录，查看学习记录 →' }).click();
  15  |     await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  16  |     await page.goto('/studio/classroom?lesson=soc-1-1-1');
  17  |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  18  |     await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  19  |     return actor;
  20  | }
  21  | const panel = (page: Page) => page.getByRole('dialog', { name: '当前讲解参考图', exact: true });
  22  | async function open(page: Page) { await page.getByRole('button', { name: '补一张讲解图', exact: true }).click(); await expect(panel(page)).toBeVisible(); }
  23  | async function generate(page: Page, requirements: string) { await panel(page).getByLabel('参考图补充要求').fill(requirements); await panel(page).getByRole('button', { name: /^(生成讲解参考图|再生成一版)$/ }).click(); }
  24  | async function ready(page: Page) { await expect(panel(page).getByRole('button', { name: '选作当前环节参考', exact: true }).last()).toBeVisible({ timeout: 45000 }); }
  25  | async function close(page: Page) { await panel(page).getByRole('button', { name: '关闭讲解参考图', exact: true }).click(); await expect(panel(page)).toHaveCount(0); }
  26  | 
  27  | for(const failFirst of [false,true])test('queued previous clicks use each confirmed position, first save '+(failFirst?'fails':'succeeds'),async({page})=>{
  28  |     const actor=await enter(page);for(const step of [3,4]){await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText(step+' / 8');}
  29  |     const sessionId=new URL(page.url()).searchParams.get('session')!,patches:any[]=[];let entered!:()=>void,release!:()=>void;
  30  |     const arrived=new Promise<void>(resolve=>entered=resolve),gate=new Promise<void>(resolve=>release=resolve);
  31  |     await page.route('**/api/learning/classroom/sessions/*',async route=>{
  32  |         if(route.request().method()!=='PATCH'){await route.continue();return;}
  33  |         const body=route.request().postDataJSON();patches.push(body);
  34  |         if(patches.length===1){entered();await gate;if(failFirst){await route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({error:{message:'合成首个保存失败'}})});return;}}
  35  |         await route.continue();
  36  |     });
  37  |     try{
  38  |         await page.getByRole('button',{name:'‹ 上一步',exact:true}).click();await arrived;
  39  |         await page.getByRole('button',{name:'‹ 上一步',exact:true}).click();release();await expect.poll(()=>patches.length).toBe(2);
> 40  |         expect(patches.map(body=>body.cursor)).toEqual(failFirst?[2,2]:[2,1]);
      |                                                ^ Error: expect(received).toEqual(expected) // deep equality
  41  |         await expect(page.locator('.cl-session-navigation')).toContainText((failFirst?3:2)+' / 8');
  42  |         const response=await fetch(api+'/api/learning/classroom/sessions/'+sessionId,{headers:{Authorization:'Bearer '+actor.token}});expect(response.status).toBe(200);expect((await response.json()).data.cursor).toBe(failFirst?2:1);
  43  |     }finally{release();await page.unroute('**/api/learning/classroom/sessions/*');}
  44  | });
  45  | test('classroom image survives navigation, binds its original node, enlarges and exports offline notes at three widths', async ({ page }) => {
  46  |     test.setTimeout(120000);
  47  |     const errors: string[] = [];
  48  |     page.on('pageerror', error => errors.push(error.message));
  49  |     await page.setViewportSize({ width: 1440, height: 1000 });
  50  |     await enter(page);
  51  |     await open(page);
  52  |     await generate(page, '[image-pause-once] 匿名生活场景，减少图内文字。');
  53  |     await expect(panel(page).locator('.cl-visual-candidate')).toHaveCount(1);
  54  |     await close(page);
  55  |     for (let i = 0; i < 2; i++)
  56  |         await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  57  |     await expect(page.locator('.cl-session-navigation')).toContainText('4 / 8');
  58  |     await page.reload();
  59  |     await expect(page.locator('.cl-session-navigation')).toContainText('4 / 8');
  60  |     await expect(page.locator('.cl-board-step .cl-generated-figure')).toHaveCount(0);
  61  |     for (let i = 0; i < 2; i++)
  62  |         await page.getByRole('button', { name: '‹ 上一步', exact: true }).click();
  63  |     await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');
  64  |     await open(page);
  65  |     await ready(page);
  66  |     for (const width of [1440, 768, 390]) {
  67  |         await page.setViewportSize({ width, height: width === 390 ? 844 : 1000 });
  68  |         await expect(panel(page).locator('.cl-generated-open img')).toBeVisible();
  69  |         expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  70  |         const box = await panel(page).boundingBox();
  71  |         expect(box!.x).toBeGreaterThanOrEqual(0);
  72  |         expect(box!.x + box!.width).toBeLessThanOrEqual(width + 1);
  73  |         if (!process.env.CI)
  74  |             await page.screenshot({ path: evidence + '/candidate-' + width + '.png', fullPage: true });
  75  |         await panel(page).getByRole('button', { name: '选作当前环节参考', exact: true }).scrollIntoViewIfNeeded();
  76  |         await expect(panel(page).getByRole('button', { name: '关闭讲解参考图', exact: true })).toBeVisible();
  77  |         if (!process.env.CI)
  78  |             await page.screenshot({ path: evidence + '/candidate-actions-' + width + '.png', fullPage: true });
  79  |         await panel(page).evaluate(element => { element.scrollTop = 0; });
  80  |     }
  81  |     const enlarge = panel(page).getByRole('button', { name: /放大参考图/ });
  82  |     await enlarge.click();
  83  |     await expect(page.getByRole('dialog', { name: '讲解参考图大图', exact: true })).toBeVisible();
  84  |     await page.keyboard.press('Escape');
  85  |     await expect(enlarge).toBeFocused();
  86  |     await expect(panel(page)).toBeVisible();
  87  |     await panel(page).getByRole('button', { name: '选作当前环节参考', exact: true }).click();
  88  |     await expect(panel(page).getByRole('button', { name: '暂不使用这张图', exact: true })).toBeVisible();
  89  |     await close(page);
  90  |     await expect(page.getByRole('button', { name: '补一张讲解图', exact: true })).toBeFocused();
  91  |     const selected = page.locator('.cl-board-step[data-current="true"] .cl-generated-figure');
  92  |     await expect(selected).toHaveCount(1);
  93  |     await expect(selected.locator('img')).toBeVisible();
  94  |     if (!process.env.CI)
  95  |         await page.screenshot({ path: evidence + '/selected-mobile.png', fullPage: true });
  96  |     await page.setViewportSize({ width: 1440, height: 1000 });
  97  |     const download = page.waitForEvent('download');
  98  |     await page.getByRole('button', { name: '导出课堂笔记', exact: true }).click();
  99  |     const file = await download;
  100 |     expect(file.suggestedFilename()).toMatch(/含参考图\.html$/);
  101 |     const stream = await file.createReadStream();
  102 |     let html = '';
  103 |     for await (const chunk of stream!)
  104 |         html += chunk.toString();
  105 |     expect(html).toContain('data:image/png;base64,');
  106 |     expect(html).toContain('标注仍需核对');
  107 |     expect(html).not.toMatch(/src="blob:/);
  108 |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  109 |     await expect(page.locator('.cl-board-step[data-current="true"] .cl-generated-figure')).toHaveCount(0);
  110 |     await expect(page.locator('.cl-board-step .cl-generated-figure')).toHaveCount(1);
  111 |     await page.getByRole('button', { name: '‹ 上一步', exact: true }).click();
  112 |     await open(page);
  113 |     await panel(page).getByRole('button', { name: '删除这个版本', exact: true }).click();
  114 |     await expect(panel(page).locator('.cl-visual-candidate')).toHaveCount(0);
  115 |     await close(page);
  116 |     await expect(page.locator('.cl-board-step .cl-generated-figure')).toHaveCount(0);
  117 |     expect(errors).toEqual([]);
  118 | });
  119 | test('failed and cancelled classroom image tasks retry their saved version', async ({ page }) => {
  120 |     test.setTimeout(120000);
  121 |     await enter(page);
  122 |     await open(page);
  123 |     await generate(page, '[image-fail-once] 失败恢复验证。');
  124 |     await expect(panel(page).getByText('生成未完成', { exact: true })).toBeVisible();
  125 |     await panel(page).getByRole('button', { name: '重试图片任务', exact: true }).click();
  126 |     await ready(page);
  127 |     await expect(panel(page).locator('.cl-visual-candidate')).toHaveCount(1);
  128 |     await generate(page, '[image-pause-once] 取消恢复验证。');
  129 |     await expect(panel(page).locator('.cl-visual-candidate')).toHaveCount(2);
  130 |     await panel(page).getByRole('button', { name: '取消生成', exact: true }).click();
  131 |     await expect(panel(page).getByText('生成已取消', { exact: true })).toBeVisible();
  132 |     await page.reload();
  133 |     await open(page);
  134 |     await expect(panel(page).getByText('生成已取消', { exact: true })).toBeVisible();
  135 |     await panel(page).getByRole('button', { name: '重试图片任务', exact: true }).click();
  136 |     await expect(panel(page).getByRole('button', { name: '选作当前环节参考', exact: true })).toHaveCount(2, { timeout: 45000 });
  137 |     await expect(panel(page).locator('.cl-visual-candidate')).toHaveCount(2);
  138 | });
  139 | test('lost image creation acknowledgement recovers the single saved task', async ({ page }) => {
  140 |     test.setTimeout(90000);
```