# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-project.spec.ts >> an entire adult unit retains every lesson, complete practice, unit check and all project submissions as separate facts
- Location: tests\e2e\source-course-project.spec.ts:88:5

# Error details

```
Error: GET /learning/classroom/sessions/null -> 404

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [active]:
  - alert [ref=f2e1]
  - main [ref=f2e2]:
    - region "教学白板" [ref=f2e3]:
      - generic [ref=f2e4]:
        - button "离开课堂" [ref=f2e5] [cursor=pointer]
        - button [ref=f2e8] [cursor=pointer]:
          - text: 社会学想象力
          - generic "断点已同步" [ref=f2e9]
      - generic [ref=f2e12]:
        - button "缩小白板" [ref=f2e13] [cursor=pointer]: −
        - button "重置缩放" [ref=f2e14] [cursor=pointer]: 100%
        - button "放大白板" [ref=f2e15] [cursor=pointer]: ＋
        - button "上一页白板" [disabled] [ref=f2e17]: ‹
        - generic [ref=f2e18]: 1 / 1
        - button "下一页白板" [disabled] [ref=f2e19]: ›
        - button "补一张讲解图" [disabled] [ref=f2e21]:
          - generic [aria-hidden] [ref=f2e22]: ▧
          - text: 配图
        - button "导出课堂笔记" [ref=f2e23] [cursor=pointer]
        - button "课堂设置" [ref=f2e26] [cursor=pointer]
        - button "切换对话面板" [ref=f2e29] [cursor=pointer]
      - generic [ref=f2e34]:
        - generic [ref=f2e35]: WELCOME TO YOUR WHITEBOARD
        - heading "社会学想象力" [level=1] [ref=f2e36]
        - paragraph [ref=f2e37]: 能在新情境中区分关于“社会学想象力”的解释，并指出需要进一步核查的证据。
        - button "▶ 开始学习" [ref=f2e38] [cursor=pointer]
        - generic [ref=f2e39]: 概念 · 生活案例 · 误区辨析 · 新情境检查
      - generic [ref=f2e40]:
        - button "开启讲解声音" [disabled] [ref=f2e41]
        - paragraph [ref=f2e44]: 准备好后，点击 ▶ 开始。
    - separator "调整对话面板宽度" [ref=f2e45]
    - complementary [ref=f2e46]:
      - generic [ref=f2e47]:
        - generic [ref=f2e48]: Chat history
        - button "隐藏对话面板" [ref=f2e51] [cursor=pointer]
      - tablist "课堂内容" [ref=f2e54]:
        - tab "讲解与插问" [selected] [ref=f2e55] [cursor=pointer]
        - tab "课堂练习" [ref=f2e56] [cursor=pointer]
        - tab "单元项目" [ref=f2e57] [cursor=pointer]
      - generic "课堂对话历史" [ref=f2e58]:
        - generic [ref=f2e59]:
          - text: SESSION OUTLINE
          - heading "社会学想象力" [level=2] [ref=f2e60]
          - paragraph [ref=f2e61]: 能在新情境中区分关于“社会学想象力”的解释，并指出需要进一步核查的证据。
          - list [ref=f2e62]:
            - listitem [ref=f2e63]: 本节课导航
            - listitem [ref=f2e64]: 社会学想象力
            - listitem [ref=f2e65]: 先看问题的规模
            - listitem [ref=f2e66]: 把概念放进生活
            - listitem [ref=f2e67]: 行动仍然有位置
            - listitem [ref=f2e68]: 一个常见的误区
            - listitem [ref=f2e69]: 停下来，检查理解
            - listitem [ref=f2e70]: 带到一个新情境
        - status [ref=f2e71]: ••• Paused
      - generic [ref=f2e72]:
        - button "‹ 上一步" [disabled] [ref=f2e73]
        - generic [ref=f2e74]: 1 / 8
        - button "下一步 ›" [ref=f2e75] [cursor=pointer]
      - generic [ref=f2e76]:
        - group "调整讲法" [ref=f2e77]:
          - button "提问" [pressed] [ref=f2e78] [cursor=pointer]
          - button "换个例子" [ref=f2e79] [cursor=pointer]
          - button "说简单点" [ref=f2e80] [cursor=pointer]
          - button "补先修" [ref=f2e81] [cursor=pointer]
          - button "比较讲法" [ref=f2e82] [cursor=pointer]
        - generic [ref=f2e83]:
          - textbox "向课堂老师提问" [ref=f2e84]:
            - /placeholder: Ask a question…
          - button "语音提问" [ref=f2e85] [cursor=pointer]: ♩
          - button "继续讲解" [ref=f2e86] [cursor=pointer]: ▷
          - button "停止课堂讲解" [ref=f2e87] [cursor=pointer]: ■
        - combobox "选择大模型" [ref=f2e90] [cursor=pointer]:
          - option "Auto · 当前默认模型"
          - option "GPT-6.1 Sol"
          - option "GPT-6 Astra"
          - option "GPT-6 Luna"
          - option "Grok-4.7"
          - option "GLM-5.3 Flash"
          - option "DeepSeek V4.1 Flash · 默认" [selected]
          - option "Claude Opus 5.5"
          - option "Claude Sonnet 5"
          - option "GPT-6 Sol"
          - option "GPT-5.6 Sol"
          - option "GPT-5.6 Terra"
          - option "GPT-5.6 Luna"
          - option "GPT-5.5"
          - option "Grok-4.6"
          - option "GLM-5.2"
          - option "GLM-5.3"
          - option "Claude Opus 5"
          - option "Claude Fable 5.1"
          - option "MiMo V2.6 Pro"
          - option "MiMo V2.6 Flash"
          - option "MiMo V2.6 Pro Ultraspeed"
          - option "Qwen3.8 Max"
```

# Test source

```ts
  1   | import {test,expect,type Page} from '@playwright/test';
  2   | import {browserEvidence} from './evidence';
  3   | const api='http://localhost:'+(process.env.E2E_API_PORT??4107)+'/api',evidence=browserEvidence('source-project');let address=0;
> 4   | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok,method+' '+path+' -> '+response.status).toBe(true);return(await response.json()).data;}
      |                                                                                                                                                                                                                                                                                                                      ^ Error: GET /learning/classroom/sessions/null -> 404
  5   | async function course(actor:any){
  6   |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'匿名观察原文',sections:['匿名阅览室在两个周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'从来源到自己的作品',goal:'以来源和条件比较替代解释，并设计自己的新情境。',language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});
  7   |   let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');return call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});
  8   | }
  9   | async function enter(page:Page){
  10  |   page.on('dialog',dialog=>void dialog.accept());const suffix=crypto.randomUUID(),principal='source-project-'+suffix+'@local.test',credential='Source-project-'+suffix,response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.22.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  11  |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);const row=await course(actor);await page.goto('/studio/source-courses?course='+row.id);return{actor,row};
  12  | }
  13  | async function finishReading(page:Page,actor:any){
  14  |   const sessionId=new URL(page.url()).searchParams.get('session')!,session=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);
  15  |   for(let step=0;step<session.lesson.steps.length;step++){
  16  |     await expect(page.locator('.cl-session-navigation')).toContainText((step+1)+' / '+session.lesson.steps.length);
  17  |     await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  18  |   }
  19  |   await expect(page.getByRole('dialog',{name:'课堂学习里程碑',exact:true})).toBeVisible();
  20  |   await page.getByRole('button',{name:'去检查理解 →',exact:true}).click();
  21  |   return session;
  22  | }
  23  | async function finishQuestions(page:Page,session:any){
  24  |   for(let index=0;index<session.lesson.questions.length;index++){
  25  |     await page.getByRole('button',{name:'第'+(index+1)+'题',exact:true}).click();
  26  |     if(index%3===2)await page.getByRole('button',{name:'Skip',exact:true}).click();
  27  |     else{
  28  |       if(index===0){await page.getByRole('button',{name:'先给我一个提示',exact:true}).click();await expect(page.locator('.cl-hint')).toHaveCount(1);}
  29  |       await page.locator('.cl-practice-options label').first().click();await page.getByRole('button',{name:'Check →',exact:true}).click();
  30  |     }
  31  |     await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  32  |   }
  33  | }
  34  | async function leaveClassroom(page:Page,standalone=false){
  35  |   await page.getByRole('button',{name:standalone?'关闭独立练习':'离开课堂',exact:true}).click();
  36  |   await page.getByRole('button',{name:'保存并离开',exact:true}).click();
  37  | }
  38  | 
  39  | test('a published source course opens one real project, completes all frozen stages and returns to its original course',async({page})=>{
  40  |   test.setTimeout(180000);const{actor,row}=await enter(page);await expect(page.getByLabel('资料课程项目',{exact:true})).toContainText('尚未设置独立单元核查');expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(0);
  41  |   expect(row.lessons).toHaveLength(2);
  42  |   for(let index=0;index<row.lessons.length;index++){
  43  |     const card=page.locator('.sc-lesson').nth(index);await card.getByRole('link',{name:'开始讲解 →',exact:true}).click();
  44  |     const session=await finishReading(page,actor);await finishQuestions(page,session);await leaveClassroom(page);
  45  |     await expect(card.getByLabel('讲解与练习记录',{exact:true})).toContainText('讲解已读');
  46  |     await expect(card.getByLabel('讲解与练习记录',{exact:true})).toContainText('已作答 2/2');
  47  |   }
  48  |   const completed=await call(actor,'GET','/learning/source-courses/'+row.id);
  49  |   expect(completed.journey.lessons.every((item:any)=>item.reading.state==='read'&&item.practice.summary.complete)).toBe(true);
  50  |   expect(completed.journey.unitCheck).toBe('not_configured');
  51  |   await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('button',{name:'开始这个项目 →',exact:true})).toBeEnabled();expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(0);await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('STEP 1 OF 5');const projectId=new URL(page.url()).searchParams.get('project')!;
  52  |   let project=await call(actor,'GET','/learning/projects/'+projectId);expect(project.sourceCourseId).toBe(row.id);expect(project.definition.sourceCourse.objectives).toHaveLength(2);
  53  |   for(let index=0;index<project.definition.stages.length;index++){
  54  |     const stage=project.definition.stages[index];await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText(stage.title);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  55  |     for(const field of stage.fields){await page.getByRole('textbox',{name:field.label,exact:true}).fill('匿名来源与新情境的过程、适用条件和待核查边界：'+field.id);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();}
  56  |     await page.getByRole('button',{name:'下一步 ›',exact:true}).click();for(const criterion of await page.locator('.pj-reflection .pj-ratings fieldset').all()){await criterion.getByRole('radio').nth(1).check();await criterion.locator('textarea').fill('当前作品保留初步依据，仍需要比较条件和反例。');}
  57  |     await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.getByRole('button',{name:new RegExp('已提交 '+(index+1)+'/3')})).toBeVisible();if(index<2)await page.getByRole('button',{name:'下一阶段 ›',exact:true}).click();
  58  |   }
  59  |   project=await call(actor,'GET','/learning/projects/'+projectId);expect(project.submissions).toHaveLength(3);expect(project.reviews).toHaveLength(0);await page.reload();await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();await expect(page).toHaveURL(new RegExp('course='+row.id));await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toBeVisible();expect(new URL(page.url()).searchParams.get('project')).toBe(projectId);expect((await call(actor,'GET','/learning/source-courses/'+row.id)).formalMeasurementEligible).toBe(false);
  60  | });
  61  | 
  62  | test('a project URL bound to another source course clears the old work instead of silently changing the course',async({page})=>{
  63  |   const{actor,row}=await enter(page);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('原资料课程的独立本机稿');const url=new URL(page.url()),other=await course(actor);url.searchParams.set('sourceCourseId',other.id);await page.goto(url.toString());await expect(page.getByText('项目与当前课程入口不一致，请返回课程重新进入。',{exact:true})).toBeVisible();await expect(page.locator('.pj-artifact')).toHaveCount(0);expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(1);expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+other.id)).projects).toHaveLength(0);
  64  | });
  65  | 
  66  | for(const width of [390,768,1440])test('source-course project entry and frozen objectives fit at '+width,async({page})=>{
  67  |   await page.setViewportSize({width,height:1000});await enter(page);await expect(page.getByRole('link',{name:'打开资料应用项目 →',exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.getByText('冻结课程目标与原文位置',{exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/source-project-'+width+'.png',fullPage:true});
  68  | });
  69  | 
  70  | test('source reading, assisted practice and project draft return to their exact saved objects in one continuous journey',async({page})=>{
  71  |   test.setTimeout(90000);const{actor,row}=await enter(page),first=page.locator('.sc-lesson').first();await first.getByRole('link',{name:'开始讲解 →',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('1 / 6');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 6');const sessionId=new URL(page.url()).searchParams.get('session')!;
  72  |   await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await expect(first.getByLabel('讲解与练习记录',{exact:true})).toContainText('讲解进行中');
  73  |   await first.getByRole('link',{name:'进入课堂练习',exact:true}).click();await expect(page.locator('.cl-practice-options label')).toHaveCount(4);expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);await page.getByRole('button',{name:'先给我一个提示',exact:true}).click();await expect(page.locator('.cl-hint')).toHaveCount(1);await page.locator('.cl-practice-options label').first().click();await page.getByRole('button',{name:'Check →',exact:true}).click();await expect(page.locator('.cl-answer-feedback')).toContainText('使用过提示');await page.getByRole('button',{name:'关闭独立练习',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await expect(first.getByLabel('讲解与练习记录',{exact:true})).toContainText('已作答 1/2');await expect(first.getByLabel('讲解与练习记录',{exact:true})).toContainText('独立首答正确 0 · 使用帮助 1');
  74  |   await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('来源课程项目的保存稿');await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.getByText('草稿和自评准备已保存。',{exact:true})).toBeVisible();const projectId=new URL(page.url()).searchParams.get('project')!;await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();
  75  |   const records=page.getByLabel('我的资料项目记录',{exact:true});await records.locator('summary').click();await expect(records).toContainText('已保存内容 1/3');await records.getByRole('link',{name:'继续这份项目 →',exact:true}).click();await expect(page.getByRole('textbox',{name:'我准备核查的主张',exact:true})).toHaveValue('来源课程项目的保存稿');expect(new URL(page.url()).searchParams.get('project')).toBe(projectId);await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();
  76  |   await first.getByRole('link',{name:'继续讲解 →',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 6');expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await first.getByRole('link',{name:'进入课堂练习',exact:true}).click();await expect(page.locator('.cl-practice-prompt>small')).toContainText('2 / 2');expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);const current=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(current.answers).toHaveLength(1);expect((await call(actor,'GET','/learning/source-courses/'+row.id)).formalMeasurementEligible).toBe(false);
  77  | });
  78  | 
  79  | test('returning from a course restores the personal project step and mode while an explicit URL takes priority',async({page})=>{
  80  |   await enter(page);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('准备核查一个有条件的解释');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'原文位置与依据',exact:true}).fill('匿名来源第1段，保留适用条件');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('整理证据与附件');await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('整理证据与附件');
  81  |   await page.getByRole('button',{name:'完整作品',exact:true}).click();await page.getByRole('link',{name:'‹ 返回课程',exact:true}).click();await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.locator('.pj-stage-heading')).toBeVisible();await expect(page.getByRole('textbox',{name:'我准备核查的主张',exact:true})).toHaveValue('准备核查一个有条件的解释');const url=new URL(page.url());url.searchParams.set('step','intro');url.searchParams.delete('view');await page.goto(url.toString());await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('STEP 1 OF 5');
  82  | });
  83  | 
  84  | test('adult course journey keeps reading, unit check and project separate and resumes the same saved classroom',async({page})=>{
  85  |   await enter(page);await page.goto('/studio/classroom?unit=0&panel=units');const journey=page.getByLabel('本单元学习进程',{exact:true});await journey.locator('summary').click();await expect(journey).toContainText('社会学视角综合核查');const first=journey.locator('ol>li').first();await first.getByRole('button',{name:'开始讲解',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');const sessionId=new URL(page.url()).searchParams.get('session')!;await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await journey.locator('summary').click();await expect(first).toContainText('讲解进行中');await first.getByRole('button',{name:'继续讲解',exact:true}).click();await expect(page.locator('.cl-session-navigation')).toContainText('2 / 8');expect(new URL(page.url()).searchParams.get('session')).toBe(sessionId);
  86  | });
  87  | 
  88  | test('an entire adult unit retains every lesson, complete practice, unit check and all project submissions as separate facts',async({page})=>{
  89  |   test.setTimeout(300000);const{actor}=await enter(page),catalog=await call(actor,'GET','/learning/classroom/catalog'),unit=catalog.course.units[0],lessons=unit.lectures.flatMap((lecture:any)=>lecture.lessons);
  90  |   const journey=page.getByLabel('本单元学习进程',{exact:true});
  91  |   for(let index=0;index<lessons.length;index++){
  92  |     await page.goto('/studio/classroom?unit=0&panel=units');await journey.locator('summary').click();
  93  |     await journey.locator('ol>li').nth(index).getByRole('button',{name:'开始讲解',exact:true}).click();
  94  |     const session=await finishReading(page,actor);await finishQuestions(page,session);await leaveClassroom(page);
  95  |   }
  96  |   await journey.locator('summary').click();await journey.locator('ol>li').last().getByRole('button',{name:'开始练习',exact:true}).click();
  97  |   await expect(page.locator('.cl-practice-options label').first()).toBeVisible();
  98  |   const checkId=new URL(page.url()).searchParams.get('session')!,check=await call(actor,'GET','/learning/classroom/sessions/'+checkId);
  99  |   await finishQuestions(page,check);await leaveClassroom(page,true);await journey.locator('summary').click();
  100 |   await journey.getByRole('link',{name:'开始项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();
  101 |   await expect(page.getByRole('region',{name:'当前项目步骤'})).toBeVisible();const projectId=new URL(page.url()).searchParams.get('project')!,project=await call(actor,'GET','/learning/projects/'+projectId);
  102 |   for(let index=0;index<project.definition.stages.length;index++){
  103 |     const stage=project.definition.stages[index];await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText(stage.title);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  104 |     for(const field of stage.fields){await page.getByRole('textbox',{name:field.label,exact:true}).fill('合成整单元旅程作品，保留比较条件与未核查解释：'+field.id);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();}
```