# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-project.spec.ts >> a published source course opens one real project, completes all frozen stages and returns to its original course
- Location: tests\e2e\source-course-project.spec.ts:13:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]: 课程项目 · StudyAgent
  - main [ref=f1e3]:
    - generic [ref=f1e5]:
      - generic [ref=f1e6]:
        - button "关闭项目教学" [ref=f1e7] [cursor=pointer]: ×
        - navigation "项目教学步骤" [ref=f1e8]:
          - button "第1步：项目导向" [ref=f1e9] [cursor=pointer]
          - button "第2步：我准备核查的主张" [ref=f1e10] [cursor=pointer]
          - button "第3步：原文位置与依据" [ref=f1e11] [cursor=pointer]
          - button "第4步：整理证据与附件" [ref=f1e12] [cursor=pointer]
          - button "第5步：自评与提交" [ref=f1e13] [cursor=pointer]
        - button "已提交 0/3 · 人工复核 0/3" [ref=f1e14] [cursor=pointer]
        - button "项目朗读设置" [ref=f1e15] [cursor=pointer]: ♫
        - button "○ 助教" [ref=f1e16] [cursor=pointer]
        - button "完整作品" [ref=f1e17] [cursor=pointer]
      - region "当前项目步骤" [ref=f1e18]:
        - generic [ref=f1e19]:
          - combobox "项目阶段" [ref=f1e20]:
            - option "整理主张与原文来源" [selected]
            - option "在新情境中应用并比较"
            - option "复核局限并计划后续验证"
          - generic [ref=f1e21]: · STEP 1 OF 5
        - generic [ref=f1e22]:
          - heading "项目导向" [active] [level=2] [ref=f1e23]
          - button "▷ 朗读本步骤" [disabled] [ref=f1e24]
        - paragraph [ref=f1e25]: 整理主张与原文来源。从课程目标出发，区分原文陈述、自己的理解和仍待核查的解释。
        - text: 当前没有启用语音，可以继续阅读和完成作品。
      - generic [ref=f1e26]:
        - button "‹ 上一步" [disabled] [ref=f1e27]
        - generic [ref=f1e28]: 1 / 5
        - button "下一步 ›" [ref=f1e29] [cursor=pointer]
      - button "保存阶段草稿" [ref=f1e31] [cursor=pointer]
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {browserEvidence} from './evidence';
  3  | const api='http://localhost:'+(process.env.E2E_API_PORT??4107)+'/api',evidence=browserEvidence('source-project');let address=0;
> 4  | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok).toBe(true);return(await response.json()).data;}
     |                                                                                                                                                                                                                                                                               ^ Error: expect(received).toBe(expected) // Object.is equality
  5  | async function course(actor:any){
  6  |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'匿名观察原文',sections:['匿名阅览室在两个周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'从来源到自己的作品',goal:'以来源和条件比较替代解释，并设计自己的新情境。',language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});
  7  |   let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');return call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});
  8  | }
  9  | async function enter(page:Page){
  10 |   page.on('dialog',dialog=>void dialog.accept());const suffix=crypto.randomUUID(),principal='source-project-'+suffix+'@local.test',credential='Source-project-'+suffix,response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.22.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  11 |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);const row=await course(actor);await page.goto('/studio/source-courses?course='+row.id);return{actor,row};
  12 | }
  13 | test('a published source course opens one real project, completes all frozen stages and returns to its original course',async({page})=>{
  14 |   test.setTimeout(90000);const{actor,row}=await enter(page);await expect(page.getByLabel('资料课程项目',{exact:true})).toContainText('尚未设置独立单元核查');expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(0);
  15 |   await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('button',{name:'开始这个项目 →',exact:true})).toBeEnabled();expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(0);await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();const projectId=new URL(page.url()).searchParams.get('project')!;
  16 |   let project=await call(actor,'GET','/learning/projects/'+projectId);expect(project.sourceCourseId).toBe(row.id);expect(project.definition.sourceCourse.objectives).toHaveLength(2);
  17 |   for(let index=0;index<project.definition.stages.length;index++){
  18 |     const stage=project.definition.stages[index];await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText(stage.title);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  19 |     for(const field of stage.fields){await page.getByRole('textbox',{name:field.label,exact:true}).fill('匿名来源与新情境的过程、适用条件和待核查边界：'+field.id);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();}
  20 |     await page.getByRole('button',{name:'下一步 ›',exact:true}).click();for(const criterion of await page.locator('.pj-reflection .pj-ratings fieldset').all()){await criterion.getByRole('radio').nth(1).check();await criterion.locator('textarea').fill('当前作品保留初步依据，仍需要比较条件和反例。');}
  21 |     await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.getByRole('button',{name:new RegExp('已提交 '+(index+1)+'/3')})).toBeVisible();if(index<2)await page.getByRole('button',{name:'下一阶段 ›',exact:true}).click();
  22 |   }
  23 |   project=await call(actor,'GET','/learning/projects/'+projectId);expect(project.submissions).toHaveLength(3);expect(project.reviews).toHaveLength(0);await page.reload();await page.getByRole('button',{name:'关闭项目教学',exact:true}).click();await expect(page).toHaveURL(new RegExp('course='+row.id));await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toBeVisible();expect(new URL(page.url()).searchParams.get('project')).toBe(projectId);expect((await call(actor,'GET','/learning/source-courses/'+row.id)).formalMeasurementEligible).toBe(false);
  24 | });
  25 | 
  26 | test('a project URL bound to another source course clears the old work instead of silently changing the course',async({page})=>{
  27 |   const{actor,row}=await enter(page);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByRole('textbox',{name:'我准备核查的主张',exact:true}).fill('原资料课程的独立本机稿');const url=new URL(page.url()),other=await course(actor);url.searchParams.set('sourceCourseId',other.id);await page.goto(url.toString());await expect(page.getByText('项目与当前课程入口不一致，请返回课程重新进入。',{exact:true})).toBeVisible();await expect(page.locator('.pj-artifact')).toHaveCount(0);expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+row.id)).projects).toHaveLength(1);expect((await call(actor,'GET','/learning/projects/catalog?sourceCourseId='+other.id)).projects).toHaveLength(0);
  28 | });
  29 | 
  30 | for(const width of [390,768,1440])test('source-course project entry and frozen objectives fit at '+width,async({page})=>{
  31 |   await page.setViewportSize({width,height:1000});await enter(page);await expect(page.getByRole('link',{name:'打开资料应用项目 →',exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await page.getByRole('link',{name:'打开资料应用项目 →',exact:true}).click();await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.getByText('冻结课程目标与原文位置',{exact:true})).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/source-project-'+width+'.png',fullPage:true});
  32 | });
  33 | 
```