# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-lifecycle.spec.ts >> edit and publish a revision, then explicitly resume the old version at its frozen line
- Location: tests\e2e\source-course-lifecycle.spec.ts:15:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('dialog', { name: '创建课程修订稿' })
Expected: 0
Received: 1
Timeout:  15000ms

Call log:
  - Expect "toHaveCount" getByRole('dialog', { name: '创建课程修订稿' }) with timeout 15000ms
  - waiting for getByRole('dialog', { name: '创建课程修订稿' })
    33 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - alert [ref=f2e2]
  - main [ref=f2e3]:
    - complementary "学习工作台导航" [ref=f2e4]:
      - link "StudyAgent" [ref=f2e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f2e9]:
        - link "Home" [ref=f2e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f2e13]: 首页
        - link "Courses" [ref=f2e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f2e17]: 课程
        - link "Calendar" [ref=f2e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f2e21]: 学习动态
        - link "History" [ref=f2e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f2e25]: 历史
        - link "Materials" [ref=f2e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f2e29]: 资料
      - generic [ref=f2e30]:
        - heading "继续学习" [level=2] [ref=f2e31]
        - link "讲座社会学想象力 社会学概论" [ref=f2e32] [cursor=pointer]:
          - /url: /studio/classroom
          - text: 讲座社会学想象力
          - generic [ref=f2e33]: 社会学概论
      - generic [ref=f2e34]:
        - heading "近期活动" [level=2] [ref=f2e35]
        - paragraph [ref=f2e36]: 开始学习后，活动会出现在这里。
      - link "返回学习首页 →" [ref=f2e38] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f2e39]:
      - generic [ref=f2e40]:
        - generic [ref=f2e41]:
          - link "‹ 返回我的课程" [ref=f2e42] [cursor=pointer]:
            - /url: /studio?view=courses
          - text: SOURCE TO COURSE
          - heading "看懂资源与条件" [level=1] [ref=f2e43]
          - paragraph [ref=f2e44]: 用相同条件比较观察与替代解释。
        - button "＋ 从资料创建课程" [disabled] [ref=f2e45]
      - generic [ref=f2e46]:
        - generic [ref=f2e47]: 等待你审阅
        - generic [ref=f2e48]: Browser fixture · not a real model · 中文讲解 · 每次预算 15 分钟
        - generic [ref=f2e49]: 内容待核查 · 不作为正式能力测量
      - region "课程版本与变更" [ref=f2e50]:
        - generic [ref=f2e51]:
          - generic [ref=f2e52]:
            - text: COURSE VERSIONS
            - heading "第 1 版 正在使用" [level=2] [ref=f2e53]
          - generic [ref=f2e54]:
            - button "创建修订稿" [disabled] [ref=f2e55]
            - button "归档课程" [disabled] [ref=f2e56]
            - button "撤回此版本" [disabled] [ref=f2e57]
        - paragraph [ref=f2e58]:
          - link "继续第 1 版的原课堂 →" [ref=f2e59] [cursor=pointer]:
            - /url: /studio/classroom?sourceCourseId=source_course_02e958e8-46f5-4cfa-9749-edc4b54f8bfd&lesson=source%3Asource_course_02e958e8-46f5-4cfa-9749-edc4b54f8bfd%3A1&tab=history&session=classroom_9f228443-c6ee-4202-88a7-de4d4e8ed713
        - dialog "创建课程修订稿" [ref=f2e61]:
          - generic [ref=f2e62]:
            - heading "从第 1 版创建修订稿" [level=2] [ref=f2e63]
            - button "关闭修订确认" [disabled] [ref=f2e64]: ×
          - paragraph [ref=f2e65]: 复制现有教学稿、题目和来源，进入完整编辑。原课程继续保留；发布修订时会再次展示对旧版的影响。
          - paragraph [ref=f2e66]: 教学稿包含题目答案，将保留作者接触事实。此操作不会重新调用模型。
          - generic [ref=f2e67]:
            - button "停止等待" [ref=f2e68] [cursor=pointer]
            - button "继续使用原版" [disabled] [ref=f2e69]
            - button "创建并编辑修订稿" [disabled] [ref=f2e70]
      - region "课程版本与变更" [ref=f2e71]:
        - generic [ref=f2e72]:
          - generic [ref=f2e73]:
            - text: COURSE VERSIONS
            - heading "第 2 版 待审修订" [level=2] [ref=f2e74]
          - generic [ref=f2e75]:
            - button "发布此修订" [disabled] [ref=f2e76]
            - button "放弃此修订稿" [disabled] [ref=f2e77]
        - paragraph [ref=f2e78]: 从已发布课程复制教学稿；保留原生成来历 · 2026/10/26 04:07:55
        - paragraph [ref=f2e79]: 此修订来自现有教学稿，已有生成与复核来历随稿保留；复制没有重新调用模型，内容仍待人工核查。
        - group [ref=f2e80]:
          - generic "版本历史 · 2 个版本" [ref=f2e81] [cursor=pointer]
      - group [ref=f2e82]:
        - generic "查看原始生成目标与模型" [ref=f2e83] [cursor=pointer]
      - generic [ref=f2e84]:
        - form "完整教学稿编辑器" [ref=f2e86]:
          - generic [ref=f2e87]:
            - generic [ref=f2e88]:
              - text: TEACHING MANUSCRIPT
              - heading "逐段核对，再交给课堂。" [level=2] [ref=f2e89]
              - paragraph [ref=f2e90]: 这里显示练习答案，供你编写与核查。修改和确认不会替代教师审核。
            - status [ref=f2e91]: 与打开时的稿件一致
          - group [ref=f2e92]:
            - generic "查看生成稿复核记录（2课）" [ref=f2e93] [cursor=pointer]
          - group [ref=f2e94]:
            - generic [ref=f2e95]:
              - generic [ref=f2e96]:
                - text: 教学稿课程名称
                - generic [ref=f2e97]: 7/180
              - textbox "教学稿课程名称" [ref=f2e98]: 看懂资源与条件
            - generic [ref=f2e99]:
              - generic [ref=f2e100]:
                - text: 课程概览
                - generic [ref=f2e101]: 22/700
              - textbox "课程概览" [ref=f2e102]: 从匿名观察出发，比较条件并寻找可区分的证据。
          - generic [ref=f2e103]:
            - generic [ref=f2e104]:
              - text: 正在编辑的课时
              - combobox "教学稿课时" [ref=f2e105]:
                - option "1. 区分事实与解释" [selected]
                - option "2. 比较替代解释"
            - tablist "教学稿环节" [ref=f2e106]:
              - tab "讲解与板书" [selected] [ref=f2e107] [cursor=pointer]
              - tab "例子与误区" [ref=f2e108] [cursor=pointer]
              - tab "练习与答案" [ref=f2e109] [cursor=pointer]
              - tab "来源引用" [ref=f2e110] [cursor=pointer]
          - tabpanel "讲解与板书" [ref=f2e111]:
            - generic [ref=f2e112]:
              - generic [ref=f2e113]:
                - text: 教学稿课时标题
                - generic [ref=f2e114]: 7/100
              - textbox "教学稿课时标题" [ref=f2e115]: 区分事实与解释
            - generic [ref=f2e116]:
              - generic [ref=f2e117]:
                - text: 教学稿课时目标
                - generic [ref=f2e118]: 15/350
              - textbox "教学稿课时目标" [ref=f2e119]: 把观察、推断与待验证条件分开。
            - generic [ref=f2e120]:
              - generic [ref=f2e121]:
                - text: 开场讲解
                - generic [ref=f2e122]: 24/400
              - textbox "开场讲解" [ref=f2e123]: 今天从匿名记录开始，保留事实和还不能判断的问题。
            - generic [ref=f2e124]:
              - generic [ref=f2e125]:
                - text: 概念讲解
                - generic [ref=f2e126]: 32/900
              - textbox "概念讲解" [ref=f2e127]: 观察描述具体发生的事情。解释提出可能的机制，还要与其他解释比较。
            - generic [ref=f2e128]:
              - generic [ref=f2e129]:
                - text: 概念板书
                - generic [ref=f2e130]: 2 条
              - textbox "概念板书" [ref=f2e131]: 先记录实际观察 再比较可能机制
              - generic [ref=f2e132]: 每行一条，共2～5条，每条最多80字。
            - generic [ref=f2e133]:
              - generic [ref=f2e134]:
                - text: 迁移讲解
                - generic [ref=f2e135]: 21/500
              - textbox "迁移讲解" [ref=f2e136]: 换一个新场景，写出可以区分两种解释的观察。
            - generic [ref=f2e137]:
              - generic [ref=f2e138]:
                - text: 总结讲解
                - generic [ref=f2e139]: 13/300
              - textbox "总结讲解" [ref=f2e140]: 保留依据、替代解释与局限。
            - generic [ref=f2e141]:
              - generic [ref=f2e142]:
                - text: 总结板书
                - generic [ref=f2e143]: 2 条
              - textbox "总结板书" [ref=f2e144]: 保留观察 核查替代解释
              - generic [ref=f2e145]: 每行一条，共2～4条，每条最多80字。
          - generic [ref=f2e146]:
            - generic [ref=f2e147]:
              - generic [ref=f2e148]: 保存后重新审阅，确认仍是独立一步。
              - generic [ref=f2e149]: 内容核查中 · 不作为正式能力测量
            - generic [ref=f2e150]:
              - button "导出本地编辑稿" [ref=f2e151] [cursor=pointer]
              - button "返回蓝图" [ref=f2e152] [cursor=pointer]
              - button "保存教学内容" [ref=f2e153] [cursor=pointer]
        - complementary [ref=f2e154]:
          - generic [ref=f2e155]:
            - text: LEARN WITH THE SOURCE
            - heading "回到原文核查" [level=2] [ref=f2e156]
          - generic [ref=f2e157]:
            - text: 课程引用的页或段
            - combobox "课程引用来源" [ref=f2e158]:
              - option "匿名记录 · 第1段" [selected]
          - article [ref=f2e159]:
            - generic [ref=f2e160]:
              - text: FROZEN SOURCE
              - heading "匿名记录 · 第1段" [level=3] [ref=f2e161]
              - paragraph [ref=f2e162]: 课程保存的正文版本 b4bb15e95453 · 正文来源已保留
            - generic [ref=f2e163]: 匿名阅览室在周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {browserEvidence} from './evidence';
  3  | const api=`http://localhost:${process.env.E2E_API_PORT??4107}/api`,evidence=browserEvidence('course-lifecycle');let address=0;
  4  | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok).toBe(true);return(await response.json()).data;}
  5  | async function enter(page:Page){const id=Date.now()+'-'+Math.floor(Math.random()*100000),principal='versions-'+id+'@local.test',credential='Versions-'+id;
  6  |   const response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.3.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  7  |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  8  |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'匿名记录',sections:['匿名阅览室在周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'从观察到验证',goal:'用相同条件比较观察与替代解释。',language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});
  9  |   let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');row=await call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});await page.goto('/studio/source-courses?course='+row.id);await expect(page.getByRole('button',{name:'创建修订稿',exact:true})).toBeVisible();return{actor,row};
  10 | }
> 11 | async function fork(page:Page){await page.getByRole('button',{name:'创建修订稿',exact:true}).click();const dialog=page.getByRole('dialog',{name:'创建课程修订稿'});await dialog.getByRole('button',{name:'创建并编辑修订稿',exact:true}).click();await expect(page.getByLabel('概念讲解',{exact:true})).toBeVisible();await expect(dialog).toHaveCount(0);await expect(page.getByRole('region',{name:'课程版本与变更',exact:true})).toHaveCount(1);}
     |                                                                                                                                                                                                                                                                                                                    ^ Error: expect(locator).toHaveCount(expected) failed
  12 | async function save(page:Page){await page.getByRole('button',{name:'保存教学内容',exact:true}).click();await expect(page.getByLabel('概念讲解',{exact:true})).toHaveCount(0);}
  13 | const modal=(page:Page)=>page.getByRole('dialog',{name:'课程变更影响预览'});
  14 | 
  15 | test('edit and publish a revision, then explicitly resume the old version at its frozen line',async({page})=>{
  16 |   test.setTimeout(90000);const{actor,row}=await enter(page),old=await call(actor,'POST','/learning/classroom/sessions',{sourceCourseId:row.id,lessonId:row.lessons[0].id}),units=old.presentation.tracks[old.lesson.steps[1].id].units;
  17 |   await call(actor,'PATCH','/learning/classroom/sessions/'+old.id,{expectedRevision:old.revision,cursor:1,revealed:2,sentenceCursor:0,presentationVersion:old.presentation.version,unitId:units[0].id,projectDraft:'原版课堂草稿'});await page.reload();
  18 |   await fork(page);const newId=new URL(page.url()).searchParams.get('course')!;expect(newId).not.toBe(row.id);await page.getByLabel('概念讲解',{exact:true}).fill('修订后新增的概念说明。'+await page.getByLabel('概念讲解',{exact:true}).inputValue());await save(page);
  19 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await expect(modal(page)).toContainText('1 份课堂记录');await modal(page).getByRole('button',{name:'取消变更',exact:true}).click();expect((await call(actor,'GET','/learning/source-courses/'+row.id)).status).toBe('active');
  20 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('补充具体概念说明');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');
  21 |   await page.getByText('版本历史 · 2 个版本',{exact:true}).click();await page.getByRole('button',{name:'查看第 1 版',exact:true}).click();await expect(page.locator('.sc-course-meta')).toContainText('已归档');await page.getByRole('link',{name:'继续第 1 版的原课堂 →',exact:true}).click();await expect(page.locator('.cl-subtitle')).toHaveText(units[0].text);await expect(page).toHaveURL(new RegExp('session='+old.id));
  22 |   const historical=await call(actor,'GET','/learning/classroom/sessions/'+old.id);expect(historical.projectDraft).toBe('原版课堂草稿');expect(historical.lesson.steps[1].narration).not.toContain('修订后新增');
  23 | });
  24 | 
  25 | test('lost revision creation receipts survive refresh and recover the same draft with the original command',async({page})=>{
  26 |   test.setTimeout(90000);const{actor,row}=await enter(page),keys:string[]=[];let lost=false;
  27 |   await page.route('**/api/learning/source-courses/*/revisions',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!lost){lost=true;await route.fetch();await route.abort('connectionreset');}else await route.continue();});
  28 |   await page.getByRole('button',{name:'创建修订稿',exact:true}).click();await page.getByRole('button',{name:'创建并编辑修订稿',exact:true}).click();await expect(page.getByRole('dialog',{name:'创建课程修订稿'}).getByRole('button',{name:'找回上次课程操作',exact:true})).toBeVisible();
  29 |   await page.reload();await page.getByRole('button',{name:'找回上次课程操作',exact:true}).click();await expect(page.getByLabel('概念讲解',{exact:true})).toBeVisible();expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);const rows=await call(actor,'GET','/learning/source-courses');expect(rows.filter((item:any)=>item.versioning?.parentCourseId===row.id)).toHaveLength(1);
  30 | });
  31 | 
  32 | test('archive, withdrawal reasons, restore, keyboard cancellation and responsive impact previews use real saved states',async({page})=>{
  33 |   test.setTimeout(90000);const{actor,row}=await enter(page),errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  34 |   const archive=page.getByRole('button',{name:'归档课程',exact:true});await archive.focus();await page.keyboard.press('Enter');await expect(modal(page)).toBeVisible();
  35 |   for(let index=0;index<10;index++){await page.keyboard.press('Tab');expect(await page.evaluate(()=>Boolean(document.activeElement?.closest('[role="dialog"][aria-label="课程变更影响预览"]')))).toBe(true);}
  36 |   for(const width of [1440,768,390]){await page.setViewportSize({width,height:960});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/impact-'+width+'.png',fullPage:true});}
  37 |   await page.keyboard.press('Escape');await expect(modal(page)).toHaveCount(0);await expect(archive).toBeFocused();expect((await call(actor,'GET','/learning/source-courses/'+row.id)).status).toBe('active');
  38 |   await page.getByRole('button',{name:'撤回此版本',exact:true}).click();await expect(modal(page).getByRole('button',{name:'确认撤回此版本',exact:true})).toBeDisabled();await modal(page).getByLabel('课程版本变更原因').fill('需要核查例子条件');await modal(page).getByRole('button',{name:'确认撤回此版本',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-version-reason')).toContainText('需要核查例子条件');await page.reload();await expect(page.locator('.sc-lifecycle h2')).toContainText('已撤回');
  39 |   await page.getByRole('button',{name:'恢复使用此版本',exact:true}).click();await modal(page).getByRole('button',{name:'确认恢复使用此版本',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');expect(errors).toEqual([]);
  40 | });
  41 | 
  42 | test('a lost publication reply recovers after refresh without another publication or another lesson version',async({page})=>{
  43 |   test.setTimeout(90000);const{actor}=await enter(page);await fork(page);await save(page);const id=new URL(page.url()).searchParams.get('course')!,keys:string[]=[];let lost=false;
  44 |   await page.route('**/api/learning/source-courses/*/lifecycle',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!lost){lost=true;await route.fetch();await route.abort('connectionreset');}else await route.continue();});
  45 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('已核对当前讲解内容');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page).getByRole('button',{name:'找回上次课程操作',exact:true})).toBeVisible();
  46 |   await page.reload();await page.getByRole('button',{name:'找回上次课程操作',exact:true}).click();await expect(page.locator('.sc-lifecycle-pending')).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);
  47 |   const row=await call(actor,'GET','/learning/source-courses/'+id);expect(row.versioning.events.filter((event:any)=>event.action==='publish'&&event.toStatus==='active')).toHaveLength(1);
  48 | });
  49 | 
  50 | test('a stale publication preview reads the actual saved version before a new explicit confirmation',async({page})=>{
  51 |   test.setTimeout(90000);const{actor}=await enter(page);await fork(page);await save(page);const id=new URL(page.url()).searchParams.get('course')!;
  52 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();const current=await call(actor,'GET','/learning/source-courses/'+id);await call(actor,'PATCH','/learning/source-courses/'+id,{expectedRevision:current.revision,requestKey:crypto.randomUUID(),title:'另一页保存的修订标题',goal:current.input.goal,lessons:current.lessons.map((lesson:any)=>({id:lesson.id,title:lesson.title,objective:lesson.objective}))});
  53 |   await modal(page).getByLabel('课程版本变更原因').fill('发布已核对的内容');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page).getByRole('alert')).toContainText('重新预览');await modal(page).getByRole('button',{name:'读取已保存的课程版本',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.getByRole('heading',{name:'另一页保存的修订标题',exact:true})).toBeVisible();
  54 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('重新预览后确认发布');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');
  55 | });
  56 | 
  57 | test('stopping a lost publication wait preserves the committed command and ignores its late reply',async({page})=>{
  58 |   test.setTimeout(90000);const{actor}=await enter(page);await fork(page);await save(page);const id=new URL(page.url()).searchParams.get('course')!;let release!:()=>void,arrived!:()=>void,heldOnce=false;
  59 |   const held=new Promise<void>(resolve=>{release=resolve;}),arrival=new Promise<void>(resolve=>{arrived=resolve;});
  60 |   await page.route('**/api/learning/source-courses/*/lifecycle',async route=>{const response=await route.fetch();if(!heldOnce){heldOnce=true;arrived();await held;}try{await route.fulfill({response});}catch{/* Client explicitly stopped waiting. */}});
  61 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('保留有界的恢复行为');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await arrival;
  62 |   await modal(page).getByRole('button',{name:'停止等待',exact:true}).click();await expect(modal(page).getByRole('alert')).toContainText('可能已经保存');release();await modal(page).getByRole('button',{name:'找回上次课程操作',exact:true}).click();await expect(modal(page)).toHaveCount(0);
  63 |   await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');const row=await call(actor,'GET','/learning/source-courses/'+id);expect(row.versioning.events.filter((event:any)=>event.action==='publish'&&event.toStatus==='active')).toHaveLength(1);
  64 | });
  65 | 
```