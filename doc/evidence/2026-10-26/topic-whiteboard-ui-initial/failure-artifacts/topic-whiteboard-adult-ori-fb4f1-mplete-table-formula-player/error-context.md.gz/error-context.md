# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player
- Location: tests\e2e\topic-whiteboard.spec.ts:43:5

# Error details

```
Error: locator.click: Error: strict mode violation: getByLabel('完整讲稿与要点').locator('details').nth(2).locator('summary') resolved to 2 elements:
    1) <summary>最后保留反例</summary> aka locator('summary').filter({ hasText: '最后保留反例' })
    2) <summary>可复制的公式原文</summary> aka getByText('可复制的公式原文')

Call log:
  - waiting for getByLabel('完整讲稿与要点').locator('details').nth(2).locator('summary')

```

# Page snapshot

```yaml
- generic [ref=f4e1]:
  - alert [ref=f4e2]
  - main [ref=f4e3]:
    - complementary "学习工作台导航" [ref=f4e4]:
      - link "StudyAgent" [ref=f4e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f4e9]:
        - link "Home" [ref=f4e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f4e13]: 首页
        - link "Courses" [ref=f4e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f4e17]: 课程
        - link "Calendar" [ref=f4e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f4e21]: 学习动态
        - link "History" [ref=f4e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f4e25]: 历史
        - link "Materials" [ref=f4e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f4e29]: 资料
        - link "AI Whiteboards" [ref=f4e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f4e33]: AI白板
      - generic [ref=f4e34]:
        - heading "继续学习" [level=2] [ref=f4e35]
        - link "讲座社会学想象力 社会学概论" [ref=f4e36] [cursor=pointer]:
          - /url: /studio/classroom
          - text: 讲座社会学想象力
          - generic [ref=f4e37]: 社会学概论
      - generic [ref=f4e38]:
        - heading "近期活动" [level=2] [ref=f4e39]
        - paragraph [ref=f4e40]: 开始学习后，活动会出现在这里。
      - link "返回学习首页 →" [ref=f4e42] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f4e43]:
      - generic [ref=f4e44]:
        - generic [ref=f4e45]:
          - text: WHITEBOARD STUDIO
          - heading "从一个问题开始，讲清每一步。" [level=1] [ref=f4e46]
          - paragraph [ref=f4e47]: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
        - link "返回学习工作台 →" [ref=f4e48] [cursor=pointer]:
          - /url: /studio
      - generic [ref=f4e49]:
        - complementary [ref=f4e50]:
          - generic [ref=f4e51]:
            - text: NEW BOARD
            - heading "这次想弄懂什么？" [level=2] [ref=f4e52]
          - generic [ref=f4e53]:
            - text: 学习对象
            - combobox "白板学习对象" [ref=f4e54]:
              - option "我自己 · 成人主题" [selected]
          - region "新建AI白板" [ref=f4e55]:
            - group [ref=f4e56]:
              - generic [ref=f4e57]:
                - text: 讲解主题
                - textbox "讲解主题" [ref=f4e58]:
                  - /placeholder: 例如：为什么先统一单位，才能比较和合并？
                  - text: 用匿名观察解释条件与推断
              - generic [ref=f4e59]:
                - text: 希望弄懂什么
                - textbox "希望弄懂什么" [ref=f4e60]:
                  - /placeholder: 想理解的区别、步骤，或一个具体困惑
                  - text: 保留完整条件，说明观察、推断和替代解释的区别。
              - generic [ref=f4e62]:
                - generic [ref=f4e63]: 模型
                - combobox "选择大模型" [ref=f4e64] [cursor=pointer]:
                  - option "Auto · 当前默认模型"
                  - option "GPT-6.1 Sol"
                  - option "GPT-6 Astra"
                  - option "GPT-6 Luna"
                  - option "Grok-4.7"
                  - option "GLM-5.3 Flash"
                  - option "DeepSeek V4.1 Flash · 默认" [selected]
                  - option "Claude Opus 5.5"
                  - option "Claude Sonnet 5"
                  - option "GPT-6 Sol"
                  - option "GPT-5.6 Sol"
                  - option "GPT-5.6 Terra"
                  - option "GPT-5.6 Luna"
                  - option "GPT-5.5"
                  - option "Grok-4.6"
                  - option "GLM-5.2"
                  - option "GLM-5.3"
                  - option "Claude Opus 5"
                  - option "Claude Fable 5.1"
                  - option "MiMo V2.6 Pro"
                  - option "MiMo V2.6 Flash"
                  - option "MiMo V2.6 Pro Ultraspeed"
                  - option "Qwen3.8 Max"
            - status [ref=f4e65]: 已恢复此范围的原主题与模型选择。
            - generic [ref=f4e66]:
              - button "预检主题与范围" [ref=f4e67] [cursor=pointer]
              - button "生成教学稿" [disabled] [ref=f4e68]
            - button "下载原主题与请求" [ref=f4e69] [cursor=pointer]
        - region "白板工作区" [ref=f4e70]:
          - generic [ref=f4e71]:
            - text: SAVED BOARD
            - heading "把条件讲清楚" [level=2] [ref=f4e72]
            - paragraph [ref=f4e73]: AI生成 · 待内容核对 · Browser fixture · not a real model
            - button "继续阅读" [ref=f4e74] [cursor=pointer]
            - button "查看自己的原稿" [ref=f4e75] [cursor=pointer]
          - dialog "白板视频" [ref=f4e76]:
            - generic [ref=f4e77]:
              - generic [ref=f4e78]:
                - generic [ref=f4e79]: WHITEBOARD SESSION / 原白板
                - heading "把条件讲清楚" [level=2] [ref=f4e80]
                - paragraph [ref=f4e81]: 逐句云语音 · 实际音轨结束后继续 · 板书按完整要点呈现
                - paragraph [ref=f4e82]: AI生成 · 待内容核对 · Browser fixture · not a real model
              - button "关闭白板" [ref=f4e83] [cursor=pointer]: ×
            - generic [ref=f4e84]:
              - generic [ref=f4e85]:
                - generic "先核对观察" [ref=f4e87]
                - paragraph [ref=f4e88]: "[whiteboard-fixture] 先核对观察。"
                - generic [ref=f4e89]:
                  - generic [ref=f4e90]: 播放进度（估计阅读）
                  - slider "播放进度（估计阅读）" [ref=f4e91] [cursor=pointer]: "0"
                - generic [ref=f4e92]:
                  - button "上一句" [disabled] [ref=f4e93]: ←
                  - button "播放" [ref=f4e94] [cursor=pointer]: ▶
                  - button "下一句" [ref=f4e95] [cursor=pointer]: →
                  - generic [ref=f4e96]: 1 / 6 句
                  - combobox "阅读方式" [ref=f4e97] [cursor=pointer]:
                    - option "文字阅读（估计时长）"
                    - option "云语音逐句播放" [selected]
                  - combobox "旁白音色" [ref=f4e98] [cursor=pointer]:
                    - option "合成音轨 A" [selected]
                  - combobox "播放速度" [ref=f4e99] [cursor=pointer]:
                    - option "0.75×"
                    - option "1×" [selected]
                    - option "1.25×"
                  - button "导出视频" [ref=f4e100] [cursor=pointer]
                  - button "导出字幕" [ref=f4e101] [cursor=pointer]
                - status [ref=f4e102]
                - generic [ref=f4e103]:
                  - button "01 先核对观察" [ref=f4e104] [cursor=pointer]:
                    - generic [ref=f4e105]: "01"
                    - text: 先核对观察
                  - button "02 再比较条件" [ref=f4e106] [cursor=pointer]:
                    - generic [ref=f4e107]: "02"
                    - text: 再比较条件
                  - button "03 最后保留反例" [ref=f4e108] [cursor=pointer]:
                    - generic [ref=f4e109]: "03"
                    - text: 最后保留反例
              - complementary "完整讲稿与要点" [ref=f4e110]:
                - heading "逐句讲稿" [level=3] [ref=f4e111]
                - paragraph [ref=f4e112]: 点击一句定位。观看与续播不计作掌握。
                - list [ref=f4e113]:
                  - listitem [ref=f4e114]:
                    - button "[whiteboard-fixture] 先核对观察。" [ref=f4e115] [cursor=pointer]
                  - listitem [ref=f4e116]:
                    - button "保留未知条件，不把一次观察当成完整能力证明。" [ref=f4e117] [cursor=pointer]
                  - listitem [ref=f4e118]:
                    - button "[whiteboard-fixture] 再比较条件。" [ref=f4e119] [cursor=pointer]
                  - listitem [ref=f4e120]:
                    - button "保留未知条件，不把一次观察当成完整能力证明。" [ref=f4e121] [cursor=pointer]
                  - listitem [ref=f4e122]:
                    - button "[whiteboard-fixture] 最后保留反例。" [ref=f4e123] [cursor=pointer]
                  - listitem [ref=f4e124]:
                    - button "保留未知条件，不把一次观察当成完整能力证明。" [ref=f4e125] [cursor=pointer]
                - heading "完整笔记与来源" [level=3] [ref=f4e126]
                - group [ref=f4e127]:
                  - generic "先核对观察" [ref=f4e128] [cursor=pointer]
                  - paragraph [ref=f4e129]: 完整说明首行。完整说明尾行。
                  - list [ref=f4e130]:
                    - listitem [ref=f4e131]: 先核对观察
                - group [ref=f4e132]:
                  - generic "再比较条件" [active] [ref=f4e133] [cursor=pointer]
                  - paragraph [ref=f4e134]: 完整说明首行。完整说明尾行。
                  - list [ref=f4e135]:
                    - listitem [ref=f4e136]: 再比较条件
                  - generic "完整对照表" [ref=f4e137]:
                    - table [ref=f4e138]:
                      - rowgroup [ref=f4e139]:
                        - row [ref=f4e140]:
                          - columnheader "已有观察" [ref=f4e141]
                          - columnheader "适用条件" [ref=f4e142]
                      - rowgroup [ref=f4e143]:
                        - row [ref=f4e144]:
                          - cell "周末排队" [ref=f4e145]
                          - cell "开放时间相同" [ref=f4e146]
                        - row [ref=f4e147]:
                          - cell "工作日空位" [ref=f4e148]
                          - cell "完整尾行条件" [ref=f4e149]
                - group [ref=f4e150]:
                  - generic "最后保留反例" [ref=f4e151] [cursor=pointer]
                - button "下载续播位置" [ref=f4e152] [cursor=pointer]
        - complementary "白板与候选历史" [ref=f4e153]:
          - generic [ref=f4e154]:
            - heading "我的白板" [level=2] [ref=f4e155]
            - button "＋ 新白板" [ref=f4e156] [cursor=pointer]
          - generic [ref=f4e157]:
            - button "教学草稿" [pressed] [ref=f4e158] [cursor=pointer]
            - button "已保存" [ref=f4e159] [cursor=pointer]
          - generic [ref=f4e160]:
            - generic [ref=f4e161]: 搜索我的白板
            - textbox "搜索我的白板" [ref=f4e162]:
              - /placeholder: 搜索主题或标题
          - button "已保存白板 · 本人主题 把条件讲清楚 Browser fixture · not a real model" [ref=f4e163] [cursor=pointer]:
            - generic [ref=f4e164]: 已保存白板 · 本人主题
            - generic [ref=f4e165]: 把条件讲清楚
            - generic [ref=f4e166]: Browser fixture · not a real model
          - generic [ref=f4e167]:
            - button "上一页" [disabled] [ref=f4e168]
            - generic [ref=f4e169]: 1 / 1
            - button "下一页" [disabled] [ref=f4e170]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { createHash, randomUUID } from 'node:crypto';
  3   | import { readFileSync } from 'node:fs';
  4   | import { browserEvidence } from './evidence';
  5   | import { join } from 'node:path';
  6   | 
  7   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107'), base = '/learning/studio/topic-whiteboards';
  8   | async function fixture(page: Page, child = false) {
  9   |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  10  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  11  |   const principal = 'topic-browser-' + randomUUID() + '@local.test', credential = 'Topic-Browser-Only-20261026';
  12  |   let token = '';
  13  |   async function call(path: string, body?: unknown, method = 'POST') {
  14  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) },
  15  |       ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  16  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
  17  |   }
  18  |   const actor = await call('/auth/register', { principal, credential }); token = actor.token;
  19  |   let studentId: string | null = null;
  20  |   if (child) {
  21  |     const created = await call('/students', { nickname: '匿名AI白板学习者', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }); studentId = created.profile.id;
  22  |     await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null,
  23  |       textbookVersion: '匿名已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  24  |   }
  25  |   await page.route('**/api/learning/studio/overview?*', async route => {
  26  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
  27  |     const payload = await response.json(); payload.data.narrationAvailable = true; payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [{ id: 'fixture-a', label: '合成音轨 A' }] };
  28  |     await route.fulfill({ response, json: payload });
  29  |   });
  30  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  31  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  32  |   await page.goto('/studio/whiteboards'); await expect(page.getByLabel('讲解主题')).toBeVisible();
  33  |   await expect(page.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');
  34  |   return { actor, call, studentId };
  35  | }
  36  | async function generate(page: Page, topic = '用匿名观察解释条件与推断') {
  37  |   await page.getByLabel('讲解主题').fill(topic); await page.getByLabel('希望弄懂什么').fill('保留完整条件，说明观察、推断和替代解释的区别。');
  38  |   await page.getByRole('button', { name: '预检主题与范围', exact: true }).click(); await expect(page.getByRole('button', { name: '生成教学稿', exact: true })).toBeEnabled();
  39  |   await page.getByRole('button', { name: '生成教学稿', exact: true }).click();
  40  | }
  41  | async function ready(page: Page) { await expect(page.locator('.tw-generation-state')).toHaveText('待你核对', { timeout: 25000 }); await expect(page.getByLabel('白板标题')).toBeVisible(); }
  42  | 
  43  | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  44  |   const f = await fixture(page); let dropped = true;
  45  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  46  |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  47  |   });
  48  |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  49  |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  50  |   const id = new URL(page.url()).searchParams.get('draft')!;
  51  |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  52  |   let editDropped = true;
  53  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  54  |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  55  |   });
  56  |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  57  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  58  |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  59  |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  60  |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  61  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  62  |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  63  |   let confirmationDropped = true;
  64  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  65  |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  66  |   });
  67  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  68  |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
  69  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  70  |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
  71  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
> 72  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator('summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
      |                                                                                 ^ Error: locator.click: Error: strict mode violation: getByLabel('完整讲稿与要点').locator('details').nth(2).locator('summary') resolved to 2 elements:
  73  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  74  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  75  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  76  | });
  77  | 
  78  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  79  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  80  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  81  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  82  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  83  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  84  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  85  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  86  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  87  | });
  88  | 
  89  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  90  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  91  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  92  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  93  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  94  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  95  |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  96  |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  97  |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  98  | });
  99  | 
  100 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  101 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  102 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  103 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  104 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  105 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  106 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  107 | });
  108 | 
  109 | for (const width of [390, 768, 1440]) test('explicit child goals, adult separation and complete edit controls fit at ' + width, async ({ page }) => {
  110 |   const f = await fixture(page, true); await page.setViewportSize({ width, height: 1000 }); await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  111 |   await expect(page.locator('.tw-goals input')).toHaveCount(1); await page.locator('.tw-goals input').check(); await generate(page, '在相同整体下解释分数单位'); await ready(page);
  112 |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view.studentId).toBe(f.studentId); expect(view.audience.atomIds).toEqual(['core:math:fractionadd']);
  113 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  114 |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'child-editor-' + width + '.png'), fullPage: true });
  115 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  116 |   await expect(page.locator('.wb-current-sentence')).toContainText('先核对观察'); expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  117 |   await page.getByRole('button', { name: '关闭白板', exact: true }).click();
  118 | });
  119 | 
```