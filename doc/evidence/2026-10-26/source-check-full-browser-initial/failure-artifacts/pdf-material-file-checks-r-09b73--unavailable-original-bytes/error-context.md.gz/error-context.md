# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: pdf-material.spec.ts >> file checks recover lost acknowledgments, regenerate missing pages and honestly report unavailable original bytes
- Location: tests\e2e\pdf-material.spec.ts:30:5

# Error details

```
Error: ENOENT: no such file or directory, open 'F:\workspace\github\StudyAgent-source-checks\data\qa\source-course-browser-1792957358385-76532\studio-materials\9d610267e5f3bea646ab0061e5dfd8c7957cc6bcc912a6f3db7013f6fd1c4142.pdf'
```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - complementary "学习工作台导航" [ref=f3e4]:
      - link "StudyAgent" [ref=f3e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f3e9]:
        - link "Home" [ref=f3e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f3e13]: 首页
        - link "Courses" [ref=f3e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f3e17]: 课程
        - link "Calendar" [ref=f3e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f3e21]: 学习动态
        - link "History" [ref=f3e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f3e25]: 历史
        - link "Materials" [ref=f3e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f3e29]: 资料
    - generic [ref=f3e30]:
      - generic [ref=f3e31]:
        - generic [ref=f3e32]:
          - link "‹ 返回我的课程" [ref=f3e33] [cursor=pointer]:
            - /url: /studio?view=courses
          - text: SOURCE TO COURSE
          - heading "让资料成为一条学习路线。" [level=1] [ref=f3e34]
          - paragraph [ref=f3e35]: 选中真正需要的原页，先审阅讲解，再开始学习。
        - button "＋ 从资料创建课程" [ref=f3e36] [cursor=pointer]
      - generic [ref=f3e37]:
        - generic [ref=f3e38]:
          - text: 学习对象
          - combobox "资料课程学习对象" [ref=f3e39]:
            - option "我自己 · 私人资料" [selected]
        - generic [ref=f3e40]: 不用创建儿童档案，私人资料保存在当前账号。
      - generic [ref=f3e41]:
        - generic [ref=f3e42]:
          - generic [ref=f3e43]:
            - generic [ref=f3e44]:
              - text: 01 · SOURCE MATERIALS
              - heading "选择原页与正文" [level=2] [ref=f3e45]
            - generic [ref=f3e46]:
              - button "粘贴文字" [ref=f3e47] [cursor=pointer]
              - button "导入文字文件" [ref=f3e48] [cursor=pointer]
          - region "PDF原件上传" [ref=f3e49]:
            - generic [ref=f3e50]:
              - generic [ref=f3e51]:
                - text: 让整章资料可靠地保存下来。
                - paragraph [ref=f3e52]: 最多50MB、120页。上传与正文识别分别保存进度，离开后可以回来继续。
              - button "上传 PDF" [ref=f3e53] [cursor=pointer]
          - paragraph [ref=f3e54]: 本次最多120页/段、180000字。较长资料先整理原文片段，再逐课编写；提交前会核对完整范围和预算。
          - group [ref=f3e55]:
            - generic "PDF repairable-original 3页 · 可选正文" [ref=f3e56] [cursor=pointer]:
              - generic [ref=f3e57]: PDF
              - generic [ref=f3e58]: repairable-original
              - generic [ref=f3e59]: 3页 · 可选正文
            - region "repairable-original处理进度" [ref=f3e60]:
              - generic [ref=f3e61]:
                - generic [ref=f3e62]: 正文处理已完成
                - generic [ref=f3e63]: 3 / 3 页
              - progressbar "PDF页级处理进度" [ref=f3e64]
              - paragraph [ref=f3e65]: 识别结果仍需结合原页核对。
              - group [ref=f3e66]:
                - generic "查看已保存页与识别情况" [ref=f3e67] [cursor=pointer]
              - region "repairable-original文件核对" [ref=f3e68]:
                - generic [ref=f3e69]:
                  - generic [ref=f3e70]:
                    - text: 原件与原页
                    - paragraph [ref=f3e71]: 上次检查：2026/10/26 03:54:13
                  - button "检查原件与原页" [disabled] [ref=f3e72]
                - status [ref=f3e73]:
                  - generic [ref=f3e74]: 原件 · 校验不符
                  - generic [ref=f3e75]: 3 / 3 页图可用
                - group [ref=f3e76]:
                  - generic "查看逐页文件状态" [ref=f3e77] [cursor=pointer]
                - paragraph [ref=f3e78]: 原始文件校验不符，可以用同一PDF恢复原件；重新生成原页不能修复原件。
                - region "恢复PDF原件" [ref=f3e79]:
                  - generic [ref=f3e80]:
                    - generic [ref=f3e81]: 恢复原件
                    - status [ref=f3e82]: 等待恢复
                  - paragraph [ref=f3e83]: 选择当时的同一PDF，核对内容后恢复原件。已保存的正文、课程和审核结果继续保留；原页图可以在恢复后另行检查。
                  - status [ref=f3e84]: 原件恢复已保存，离开后仍可回来查看进度。
                  - paragraph [ref=f3e85]: 正在等待或执行文件核验。刷新页面可以读取同一任务。
                  - generic [ref=f3e86]:
                    - button "取消这次恢复" [ref=f3e87] [cursor=pointer]
                    - button "读取恢复进度" [ref=f3e88] [cursor=pointer]
            - region "批量选择资料范围" [ref=f3e89]:
              - generic [ref=f3e90]:
                - generic [ref=f3e91]:
                  - text: 从第
                  - spinbutton "资料起始页" [ref=f3e92]: "1"
                  - text: 页
                - generic [ref=f3e93]:
                  - text: 到第
                  - spinbutton "资料结束页" [ref=f3e94]: "3"
                  - text: 页
                - button "选择页范围" [ref=f3e95] [cursor=pointer]
              - generic [ref=f3e96]:
                - button "选择全部可读页" [ref=f3e97] [cursor=pointer]
                - button "取消本资料选择" [ref=f3e98] [cursor=pointer]
            - generic [ref=f3e99]:
              - generic [ref=f3e100]:
                - generic [ref=f3e101] [cursor=pointer]:
                  - checkbox "选择 repairable-original 第1页" [ref=f3e102]
                  - generic [ref=f3e103]: 第1页
                  - generic [ref=f3e104]: 65字
                - button "核对正文与原页" [ref=f3e105] [cursor=pointer]
              - generic [ref=f3e106]:
                - generic [ref=f3e107] [cursor=pointer]:
                  - checkbox "选择 repairable-original 第2页" [ref=f3e108]
                  - generic [ref=f3e109]: 第2页
                  - generic [ref=f3e110]: 65字
                - button "核对正文与原页" [ref=f3e111] [cursor=pointer]
              - generic [ref=f3e112]:
                - generic [ref=f3e113] [cursor=pointer]:
                  - checkbox "选择 repairable-original 第3页" [ref=f3e114]
                  - generic [ref=f3e115]: 第3页
                  - generic [ref=f3e116]: 65字
                - button "核对正文与原页" [ref=f3e117] [cursor=pointer]
          - generic [ref=f3e118]:
            - generic [ref=f3e119]: 已选 0 页/段
            - generic [ref=f3e120]: 0 / 180,000 字
        - generic [ref=f3e121]:
          - text: 02 · LEARNING GOAL
          - heading "想从中学会什么？" [level=2] [ref=f3e122]
          - generic [ref=f3e123]:
            - text: 课程名称
            - textbox "课程名称" [ref=f3e124]:
              - /placeholder: 例如：从社区观察理解社会学
          - generic [ref=f3e125]:
            - text: 学习目标
            - textbox "学习目标" [ref=f3e126]:
              - /placeholder: 写清想理解、解释或做到什么。
          - generic [ref=f3e127]:
            - generic [ref=f3e128]:
              - text: 讲解语言
              - combobox "讲解语言" [ref=f3e129]:
                - option "沿用来源语言" [selected]
                - option "中文"
                - option "English"
            - generic [ref=f3e130]:
              - text: 每次学习预算
              - combobox "每次学习预算" [ref=f3e131]:
                - option "5 分钟"
                - option "10 分钟"
                - option "15 分钟" [selected]
                - option "20 分钟"
                - option "30 分钟"
                - option "45 分钟"
                - option "60 分钟"
          - paragraph [ref=f3e132]: 预算用于编排短课，实际耗时以自己的学习节奏为准。
          - generic [ref=f3e133]:
            - generic [ref=f3e134]:
              - generic [ref=f3e135]: 模型
              - combobox "选择大模型" [ref=f3e136] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - paragraph [ref=f3e137]:
              - generic [ref=f3e138]: DeepSeek V4.1 Flash
              - generic [ref=f3e139]: DeepSeek V4 Flash
          - generic [ref=f3e140]:
            - text: 先生成候选，再由你确认。
            - paragraph [ref=f3e141]: 模型只读取所选正文。课程保留来源引用与版本；生成题用于学习反馈，内容仍需核查。
          - button "生成课程蓝图 →" [disabled] [ref=f3e142]
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {browserEvidence} from './evidence';
  3  | import {DatabaseSync} from 'node:sqlite';
  4  | import {readFileSync,unlinkSync,writeFileSync} from 'node:fs';
  5  | import {join,resolve,sep} from 'node:path';
  6  | const api=`http://localhost:${process.env.E2E_API_PORT??'4107'}/api`;let address=0;
  7  | async function login(page:Page){const id=Date.now()+'-'+Math.floor(Math.random()*100000),principal='pdf-'+id+'@local.test',credential='Pdf-'+id;const response=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json','x-forwarded-for':'127.28.0.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);await page.goto('/studio/source-courses?new=1');return actor;}
  8  | function pdf(pages:number,padding=0){const objects=['<< /Type /Catalog /Pages 2 0 R >>',`<< /Type /Pages /Kids [${Array.from({length:pages},(_,index)=>(4+index*2)+' 0 R').join(' ')}] /Count ${pages} >>`,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];for(let page=1;page<=pages;page++){const stream=`BT /F1 13 Tf 40 740 Td (Page ${page}. Preserve original conditions and compare counterexamples.) Tj ET`;objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents ${5+(page-1)*2} 0 R >>`,`<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`);}if(padding)objects.push(`<< /Length ${padding} >>\nstream\n${'A'.repeat(padding)}\nendstream`);let content='%PDF-1.4\n';const offsets=[0];objects.forEach((object,index)=>{offsets.push(Buffer.byteLength(content));content+=`${index+1} 0 obj\n${object}\nendobj\n`;});const xref=Buffer.byteLength(content);content+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n${offsets.slice(1).map(offset=>String(offset).padStart(10,'0')+' 00000 n ').join('\n')}\ntrailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;return Buffer.from(content);}
  9  | async function capture(page:Page,name:string){if(process.env.E2E_SOURCE_COURSE_SNAPSHOT)await page.screenshot({path:browserEvidence('long-pdf')+'/'+name+'.png',fullPage:true});}
  10 | 
  11 | test('interrupted PDF chunks survive reload, a lost completion acknowledgment recovers one material and its later pages load lazily',async({page})=>{
  12 |  test.setTimeout(150000);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await login(page);const bytes=pdf(31,5*1024*1024),file={name:'anonymous-long-source.pdf',mimeType:'application/pdf',buffer:bytes};let starts=0,firstChunk=0,failed=false,lost=false;
  13 |  page.on('request',request=>{const path=new URL(request.url()).pathname;if(path==='/api/learning/material-uploads'&&request.method()==='POST')starts++;if(path.match(/material-uploads\/[^/]+\/chunks\/0$/))firstChunk++;});
  14 |  await page.route('**/api/learning/material-uploads/*/chunks/1',async route=>{if(!failed){failed=true;await route.abort('failed');}else await route.continue();});await page.getByLabel('上传资料 PDF',{exact:true}).setInputFiles(file);const uploader=page.getByRole('region',{name:'PDF原件上传'});await expect(uploader.getByRole('alert')).toContainText('暂时无法连接');await expect(uploader).toContainText('4.0 MB');await page.reload();await expect(uploader).toContainText('选择同一文件继续');
  15 |  await page.route('**/api/learning/material-uploads/*/complete',async route=>{if(!lost){lost=true;expect((await route.fetch()).status()).toBe(201);await route.abort('failed');}else await route.continue();});await page.getByLabel('上传资料 PDF',{exact:true}).setInputFiles(file);await expect(page.getByRole('checkbox')).toHaveCount(31,{timeout:60000});await expect(page.getByRole('checkbox').last()).toBeEnabled();await expect(uploader.getByRole('alert')).toHaveCount(0);expect(starts).toBe(1);expect(firstChunk).toBe(1);
  16 |  const material=page.locator('.sc-material');await material.getByLabel('资料起始页',{exact:true}).fill('29');await material.getByLabel('资料结束页',{exact:true}).fill('31');await material.getByRole('button',{name:'选择页范围',exact:true}).click();await expect(page.locator('.sc-source-budget')).toContainText('已选 3 页/段');
  17 |  await material.getByRole('button',{name:'核对正文与原页',exact:true}).last().click();const preview=page.getByRole('dialog',{name:'核对资料原页'});await expect(preview.locator('pre')).toContainText('Page 31.');await preview.getByText('查看原始 PDF 页面',{exact:true}).click();await expect(preview.locator('img')).toBeVisible();expect(await preview.locator('img').evaluate(image=>(image as HTMLImageElement).naturalWidth)).toBeGreaterThan(100);await preview.getByRole('button',{name:'关闭资料原页'}).click();
  18 |  for(const width of [1440,768,390]){await page.setViewportSize({width,height:960});await material.scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await capture(page,'source-'+width);}expect(errors).toEqual([]);
  19 | });
  20 | 
  21 | test('page processing cancellation retains its checkpoint and retry restores the task instead of publishing the cancelled attempt',async({page})=>{
  22 |  test.setTimeout(120000);await login(page);await page.getByLabel('上传资料 PDF',{exact:true}).setInputFiles({name:'[pause-page-once] resume-original.pdf',mimeType:'application/pdf',buffer:pdf(40)});const progress=page.locator('.sc-pdf-processing');await expect(progress.getByRole('progressbar',{name:'PDF页级处理进度'})).toHaveAttribute('value','2',{timeout:60000});await capture(page,'checkpoint');await progress.getByRole('button',{name:'停止这次处理',exact:true}).click();await expect(progress).toContainText('已停止，保留原件和已保存页',{timeout:30000});await expect(page.getByRole('checkbox')).toHaveCount(0);await page.reload();await expect(progress.getByRole('button',{name:'重试资料处理',exact:true})).toBeEnabled();await progress.getByRole('button',{name:'重试资料处理',exact:true}).click();await expect(page.getByRole('checkbox')).toHaveCount(40,{timeout:60000});await expect(page.getByRole('checkbox').last()).toBeEnabled();await progress.locator('summary').click();await expect(progress).toContainText('已恢复');
  23 | });
  24 | 
  25 | 
  26 | test('the PDF workbench uses the same long upload and loads current-page text and structures without fetching the whole book',async({page})=>{
  27 |  test.setTimeout(120000);let catalogInspected=false;await page.route('**/api/learning/studio/overview?*',async route=>{const response=await route.fetch(),payload=(await response.json()).data;if(payload.materials.some((material:any)=>material.pages.length)){expect(payload.materials.every((material:any)=>material.pages.every((page:any)=>page.text===''&&page.textCharacters!==undefined&&!page.blocks))).toBe(true);catalogInspected=true;}await route.fulfill({response});});const actor=await login(page),created=await fetch(api+'/students',{method:'POST',headers:{authorization:'Bearer '+actor.token,'content-type':'application/json'},body:JSON.stringify({nickname:'原页核对',grade:4,preferredSessionMinutes:15,defaultVersionMap:{math:'',chinese:'',english:''}})});expect(created.status).toBe(201);const student=(await created.json()).data.profile;await page.goto('/studio?'+new URLSearchParams({view:'materials',student:student.id,subject:'math'}));await expect(page.getByRole('heading',{name:'把 PDF 变成逐页课堂。',exact:true})).toBeVisible();await page.getByLabel('上传资料 PDF',{exact:true}).setInputFiles({name:'workbench-original.pdf',mimeType:'application/pdf',buffer:pdf(41)});await expect(page.locator('.sa-pdf-pages button')).toHaveCount(41,{timeout:60000});await page.locator('.sa-pdf-pages button').last().click();await page.getByRole('button',{name:'文字层',exact:true}).click();await expect(page.locator('.sa-pdf-paper')).toContainText('Page 41.');await page.getByRole('button',{name:'结构恢复',exact:true}).click();await expect(page.locator('.sa-pdf-structured')).toContainText('Page 41.');expect(catalogInspected).toBe(true);const files=page.locator('.sc-material-files');await files.getByRole('button',{name:'检查原件与原页',exact:true}).click();await expect(files).toContainText('41 / 41 页图可用');await capture(page,'workbench');
  28 | });
  29 | 
  30 | test('file checks recover lost acknowledgments, regenerate missing pages and honestly report unavailable original bytes',async({page})=>{
  31 |  test.setTimeout(120000);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));const actor=await login(page);
  32 |  await page.getByLabel('上传资料 PDF',{exact:true}).setInputFiles({name:'repairable-original.pdf',mimeType:'application/pdf',buffer:pdf(3)});await expect(page.getByRole('checkbox')).toHaveCount(3,{timeout:60000});await expect(page.getByRole('checkbox').last()).toBeEnabled();
  33 |  const listed=(await(await fetch(api+'/learning/source-courses/materials',{headers:{authorization:'Bearer '+actor.token}})).json()).data;expect(listed).toHaveLength(1);const material=listed[0].material,check=page.getByRole('region',{name:material.title+'文件核对',exact:true});await expect(check).toContainText('尚未核对文件');
  34 |  // This fault injection is restricted to the explicitly isolated browser server's own SQLite root.
  35 |  const root=resolve(process.env.E2E_DATA_DIR??'');expect(root.startsWith(resolve('data/qa')+sep)).toBe(true);const db=new DatabaseSync(join(root,'study-agent.sqlite3'),{readOnly:true});let row:any;
  36 |  try{row=JSON.parse((db.prepare('SELECT body FROM domain_records WHERE collection=? AND record_id=?').get('studioSourceMaterials',material.id) as {body:string}).body);}finally{db.close();}
  37 |  expect(row.ownerUserId).toBe(actor.user.id);expect(row.sha256).toMatch(/^[a-f0-9]{64}$/);const missing=row.pageFiles.find((file:any)=>file.page===2);expect(missing.name).toMatch(/^study-pdf-structure-v[1-9]\d*\/page-2\.png$/);
  38 |  const target=resolve(root,'studio-materials','processed',row.sha256,missing.name);expect(target.startsWith(resolve(root,'studio-materials','processed',row.sha256)+sep)).toBe(true);unlinkSync(target);
  39 |  let lost=false;const keys:string[]=[];let saved:any;await page.route('**/api/learning/source-courses/materials/*/files/check',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!lost){lost=true;const response=await route.fetch();expect(response.status()).toBe(201);saved=(await response.json()).data;await route.abort('failed');}else await route.continue();});
  40 |  await check.getByRole('button',{name:'检查原件与原页',exact:true}).focus();await page.keyboard.press('Enter');await expect(check.getByRole('alert')).toContainText('暂时无法连接');await check.getByRole('button',{name:'重试这次检查',exact:true}).click();await expect(check).toContainText('1页需要处理');expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);
  41 |  const report=(await(await fetch(api+'/learning/source-courses/materials/'+material.id+'/files',{headers:{authorization:'Bearer '+actor.token}})).json()).data;expect(report.checkedAt).toBe(saved.checkedAt);await check.getByRole('button',{name:'重新生成原页',exact:true}).click();await expect(check).toContainText('尚未核对文件',{timeout:60000});await expect(page.getByRole('checkbox').last()).toBeEnabled({timeout:60000});await expect(check.getByRole('button',{name:'检查原件与原页',exact:true})).toBeEnabled();await check.getByRole('button',{name:'检查原件与原页',exact:true}).click();await expect(check).toContainText('3 / 3 页图可用');expect(readFileSync(target).subarray(1,4).toString()).toBe('PNG');
  42 |  await check.getByText('查看逐页文件状态',{exact:true}).click();for(const width of [1440,390]){await page.setViewportSize({width,height:960});await check.scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await capture(page,'file-check-'+width);}
  43 |  await page.reload();await expect(check).toContainText('3 / 3 页图可用');const original=join(root,'studio-materials',row.sha256+'.pdf');unlinkSync(original);await check.getByRole('button',{name:'检查原件与原页',exact:true}).click();await expect(check).toContainText('原始文件已缺失');
  44 |  const repair=check.getByRole('region',{name:'恢复PDF原件',exact:true});await repair.getByRole('button',{name:'选择同一PDF恢复',exact:true}).focus();await page.keyboard.press('Enter');
  45 |  const wrong=Buffer.from(pdf(3));wrong[wrong.length-1]=wrong[wrong.length-1]===65?66:65;await expect(repair.getByRole('button',{name:'选择同一PDF恢复',exact:true})).toBeEnabled();await repair.getByLabel('选择用于恢复的原始PDF',{exact:true}).setInputFiles({name:'same-name.pdf',mimeType:'application/pdf',buffer:wrong});await expect(repair.getByRole('alert')).toContainText('内容与原资料不同');
  46 |  let repairLost=false;await page.route('**/api/learning/source-courses/materials/*/repairs',async route=>{if(route.request().method()==='POST'&&!repairLost){repairLost=true;expect((await route.fetch()).status()).toBe(201);await route.abort('failed');}else await route.continue();});
  47 |  await expect(repair.getByRole('button',{name:'选择同一PDF恢复',exact:true})).toBeEnabled();await repair.getByLabel('选择用于恢复的原始PDF',{exact:true}).setInputFiles({name:'repairable-original.pdf',mimeType:'application/pdf',buffer:pdf(3)});await expect(repair).toContainText('原件已恢复',{timeout:30000});expect(readFileSync(original).equals(pdf(3))).toBe(true);
  48 |  await page.reload();await expect(repair).toContainText('原件已恢复');const repaired=(await(await fetch(api+'/learning/source-courses/materials/'+material.id+'/repairs',{headers:{authorization:'Bearer '+actor.token}})).json()).data;expect(repaired).toHaveLength(1);expect(repaired[0].status).toBe('completed');
  49 |  await repair.getByRole('button',{name:'重新检查文件',exact:true}).click();await expect(check).toContainText('原件 · 校验通过');
  50 |  writeFileSync(original,'intentionally corrupt isolated original');await check.getByRole('button',{name:'检查原件与原页',exact:true}).click();await expect(check).toContainText('原始文件校验不符');await expect(check.getByRole('button',{name:'重新生成原页',exact:true})).toHaveCount(0);
> 51 |  await expect(repair.getByRole('button',{name:'选择同一PDF恢复',exact:true})).toBeEnabled();await repair.getByLabel('选择用于恢复的原始PDF',{exact:true}).setInputFiles({name:'repairable-original.pdf',mimeType:'application/pdf',buffer:pdf(3)});await expect.poll(()=>readFileSync(original).equals(pdf(3)),{timeout:30000}).toBe(true);await expect(repair).toContainText('原件已恢复');
     |                                                                                                                                                                                                                                                                       ^ Error: ENOENT: no such file or directory, open 'F:\workspace\github\StudyAgent-source-checks\data\qa\source-course-browser-1792957358385-76532\studio-materials\9d610267e5f3bea646ab0061e5dfd8c7957cc6bcc912a6f3db7013f6fd1c4142.pdf'
  52 |  for(const width of [1440,768,390]){await page.setViewportSize({width,height:960});await repair.scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await capture(page,'original-repair-'+width);}expect(errors).toEqual([]);
  53 | });
  54 | 
  55 | test('the original PDF workbench repairs and cancels through the same persistent flow',async({page})=>{
  56 |  test.setTimeout(120000);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));const actor=await login(page);
  57 |  const created=await fetch(api+'/students',{method:'POST',headers:{authorization:'Bearer '+actor.token,'content-type':'application/json'},body:JSON.stringify({nickname:'原件恢复工作台',grade:4,preferredSessionMinutes:15,defaultVersionMap:{math:'',chinese:'',english:''}})});expect(created.status).toBe(201);const student=(await created.json()).data.profile;
  58 |  await page.goto('/studio?'+new URLSearchParams({view:'materials',student:student.id,subject:'math'}));await page.getByLabel('上传资料 PDF',{exact:true}).setInputFiles({name:'[pause-repair-once]-original.pdf',mimeType:'application/pdf',buffer:pdf(4)});await expect(page.locator('.sa-pdf-pages button')).toHaveCount(4,{timeout:60000});
  59 |  const listed=(await(await fetch(api+'/learning/source-courses/materials?'+new URLSearchParams({studentId:student.id,subject:'math'}),{headers:{authorization:'Bearer '+actor.token}})).json()).data,material=listed[0].material;
  60 |  const root=resolve(process.env.E2E_DATA_DIR??'');expect(root.startsWith(resolve('data/qa')+sep)).toBe(true);expect(material.sha256).toMatch(/^[a-f0-9]{64}$/);const file=join(root,'studio-materials',material.sha256+'.pdf');writeFileSync(file,'damaged isolated workbench original');
  61 |  const check=page.getByRole('region',{name:material.title+'文件核对',exact:true});await check.getByRole('button',{name:'检查原件与原页',exact:true}).click();await expect(check).toContainText('原始文件校验不符');
  62 |  const repair=check.getByRole('region',{name:'恢复PDF原件',exact:true});await expect(repair.getByRole('button',{name:'选择同一PDF恢复',exact:true})).toBeEnabled();await repair.getByLabel('选择用于恢复的原始PDF',{exact:true}).setInputFiles({name:'[pause-repair-once]-original.pdf',mimeType:'application/pdf',buffer:pdf(4)});await expect(repair).toContainText('正在恢复并核验原件',{timeout:15000});
  63 |  await repair.getByRole('button',{name:'取消这次恢复',exact:true}).click();await expect(repair).toContainText('这次恢复已取消',{timeout:30000});expect(readFileSync(file,'utf8')).toBe('damaged isolated workbench original');
  64 |  await page.reload();await expect(repair).toContainText('这次恢复已取消');await expect(repair.getByRole('button',{name:'选择同一PDF恢复',exact:true})).toBeEnabled();await repair.getByLabel('选择用于恢复的原始PDF',{exact:true}).setInputFiles({name:'[pause-repair-once]-original.pdf',mimeType:'application/pdf',buffer:pdf(4)});await expect(repair).toContainText('原件已恢复',{timeout:30000});expect(readFileSync(file).equals(pdf(4))).toBe(true);
  65 |  await repair.getByRole('button',{name:'重新检查文件',exact:true}).click();await expect(check).toContainText('原件 · 校验通过');
  66 |  const repairs=(await(await fetch(api+'/learning/source-courses/materials/'+material.id+'/repairs',{headers:{authorization:'Bearer '+actor.token}})).json()).data;expect(repairs).toHaveLength(2);expect(repairs.map((row:any)=>row.status)).toEqual(['completed','cancelled']);await capture(page,'original-workbench-repaired');expect(errors).toEqual([]);
  67 | });
  68 | 
```