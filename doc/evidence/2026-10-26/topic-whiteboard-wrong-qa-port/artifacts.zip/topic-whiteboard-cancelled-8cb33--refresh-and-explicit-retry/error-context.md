# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> cancelled and failed review generations retain the original selected model through refresh and explicit retry
- Location: tests\e2e\topic-whiteboard.spec.ts:84:5

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/learn(?:\?|$)/
Received string:  "http://localhost:3147/parent/login"
Timeout: 15000ms

Call log:
  - Expect "toHaveURL" with timeout 15000ms
    33 × locator resolved to <html lang="zh-CN">…</html>
       - unexpected value "http://localhost:3147/parent/login"

```

```yaml
- alert "身份确认未完成":
  - paragraph:
    - strong: 暂时无法确认登录状态
    - text: 请检查网络后重试。已保存的学习记录会保留。
  - button "重新确认登录"
- main:
  - complementary:
    - link "学 学习观察室":
      - /url: /
    - text: FAMILY / 每一步，都看得见
    - heading "先看见孩子， 怎样学会。" [level=1]:
      - text: 先看见孩子，
      - emphasis: 怎样学会。
    - paragraph: 从一个具体知识点开始，找到卡住的一步，再通过新题和时间，看看是否真的留下来。
    - link "孩子自己来学习？使用学习码进入 ↗":
      - /url: /student/login
  - text: 家长与教师入口
  - heading "继续孩子的学习旅程。" [level=2]
  - paragraph: 登录后查看孩子的知识证据、指导计划和复测记录。
  - text: 登录账号
  - textbox "登录账号":
    - /placeholder: 账号或邮箱
    - text: topic-browser-1de73643-0c91-4802-8bb6-de5b8cb9057a@local.test
  - text: 密码
  - textbox "密码":
    - /placeholder: 至少 10 个字符
    - text: Topic-Browser-Only-20261026
  - alert: 暂时无法连接学习服务，请检查网络后重试。已保存的数据会保留。
  - button "登录，查看学习记录 →"
  - button "首次使用，创建家长账号"
  - paragraph: 教师与教研权限由管理员配置。孩子使用家长生成的一次性学习码。
- alert
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { createHash, randomUUID } from 'node:crypto';
  3   | import { readFileSync } from 'node:fs';
  4   | import { browserEvidence } from './evidence';
  5   | import { join } from 'node:path';
  6   | 
  7   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107'), base = '/learning/studio/topic-whiteboards';
  8   | // Complete in-flight overview/media routes before Playwright disposes their API responses.
  9   | test.afterEach(async ({ page }) => { await page.unrouteAll({ behavior: 'wait' }); });
  10  | async function fixture(page: Page, child = false) {
  11  |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  12  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  13  |   const principal = 'topic-browser-' + randomUUID() + '@local.test', credential = 'Topic-Browser-Only-20261026';
  14  |   let token = '';
  15  |   async function call(path: string, body?: unknown, method = 'POST') {
  16  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) },
  17  |       ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  18  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
  19  |   }
  20  |   const actor = await call('/auth/register', { principal, credential }); token = actor.token;
  21  |   let studentId: string | null = null;
  22  |   if (child) {
  23  |     const created = await call('/students', { nickname: '匿名AI白板学习者', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }); studentId = created.profile.id;
  24  |     await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null,
  25  |       textbookVersion: '匿名已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  26  |   }
  27  |   await page.route('**/api/learning/studio/overview?*', async route => {
  28  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
  29  |     const payload = await response.json(); payload.data.narrationAvailable = true; payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [{ id: 'fixture-a', label: '合成音轨 A' }] };
  30  |     await route.fulfill({ response, json: payload });
  31  |   });
  32  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
> 33  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
      |                                                                                       ^ Error: expect(page).toHaveURL(expected) failed
  34  |   await page.goto('/studio/whiteboards'); await expect(page.getByLabel('讲解主题')).toBeVisible();
  35  |   await expect(page.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');
  36  |   return { actor, call, studentId };
  37  | }
  38  | async function generate(page: Page, topic = '用匿名观察解释条件与推断') {
  39  |   await page.getByLabel('讲解主题').fill(topic); await page.getByLabel('希望弄懂什么').fill('保留完整条件，说明观察、推断和替代解释的区别。');
  40  |   await page.getByRole('button', { name: '预检主题与范围', exact: true }).click(); await expect(page.getByRole('button', { name: '生成教学稿', exact: true })).toBeEnabled();
  41  |   await page.getByRole('button', { name: '生成教学稿', exact: true }).click();
  42  | }
  43  | async function ready(page: Page) { await expect(page.locator('.tw-generation-state')).toHaveText('待你核对', { timeout: 25000 }); await expect(page.getByLabel('白板标题')).toBeVisible(); }
  44  | 
  45  | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  46  |   const f = await fixture(page); let dropped = true;
  47  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  48  |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  49  |   });
  50  |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  51  |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  52  |   const id = new URL(page.url()).searchParams.get('draft')!;
  53  |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  54  |   let editDropped = true, editWrites = 0;
  55  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  56  |     editWrites++;
  57  |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  58  |   });
  59  |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  60  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  61  |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  62  |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  63  |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  64  |   expect(editWrites).toBe(1);
  65  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  66  |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  67  |   let confirmationDropped = true, confirmationWrites = 0;
  68  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  69  |     confirmationWrites++;
  70  |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  71  |   });
  72  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  73  |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
  74  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  75  |   expect(confirmationWrites).toBe(1);
  76  |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
  77  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
  78  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  79  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  80  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  81  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  82  | });
  83  | 
  84  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  85  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  86  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  87  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  88  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  89  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  90  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  91  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  92  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  93  | });
  94  | 
  95  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  96  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  97  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  98  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  99  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  100 |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  101 |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  102 |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  103 |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  104 | });
  105 | 
  106 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  107 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  108 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  109 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  110 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  111 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  112 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  113 | });
  114 | 
  115 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  116 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  117 |   try {
  118 |     await second.goto(href); await ready(second);
  119 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  120 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  121 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  122 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  123 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
  124 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  125 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  126 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  127 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  128 |   } finally { await second.close(); }
  129 | });
  130 | 
  131 | test('uncached original topic cannot disappear on a scope change until its complete input is downloaded', async ({ page }) => {
  132 |   const f = await fixture(page, true);
  133 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
```