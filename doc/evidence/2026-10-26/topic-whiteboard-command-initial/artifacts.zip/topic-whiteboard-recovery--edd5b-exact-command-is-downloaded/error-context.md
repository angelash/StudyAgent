# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> recovery: an uncached original cancellation survives object changes until its exact command is downloaded
- Location: tests\e2e\topic-whiteboard.spec.ts:166:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.tw-candidate')
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.tw-candidate') with timeout 15000ms
  - waiting for locator('.tw-candidate')

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - link "Home":
        - /url: /studio?view=home
        - text: 首页
      - link "Courses":
        - /url: /studio?view=courses
        - text: 课程
      - link "Calendar":
        - /url: /studio?view=calendar
        - text: 学习动态
      - link "History":
        - /url: /studio?view=history
        - text: 历史
      - link "Materials":
        - /url: /studio?view=materials
        - text: 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom
    - heading "近期活动" [level=2]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页 →":
      - /url: /learn?subject=math
  - text: WHITEBOARD STUDIO
  - heading "从一个问题开始，讲清每一步。" [level=1]
  - paragraph: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
  - link "返回学习工作台 →":
    - /url: /studio
  - complementary:
    - text: NEW BOARD
    - heading "这次想弄懂什么？" [level=2]
    - text: 学习对象
    - combobox "白板学习对象":
      - option "我自己 · 成人主题" [selected]
    - region "新建AI白板":
      - group:
        - text: 讲解主题
        - textbox "讲解主题":
          - /placeholder: 例如：为什么先统一单位，才能比较和合并？
          - text: 匿名观察 [topic-pause-once]
        - text: 希望弄懂什么
        - textbox "希望弄懂什么":
          - /placeholder: 想理解的区别、步骤，或一个具体困惑
          - text: 保留完整条件，说明观察、推断和替代解释的区别。
        - text: 模型
        - combobox "选择大模型":
          - option "Auto · 当前默认模型"
      - button "预检主题与范围"
      - button "生成教学稿" [disabled]
      - button "下载原主题与请求"
      - group: 查看其他本机主题
  - region "白板工作区":
    - heading "让知识有条理地展开。" [level=2]
    - paragraph: 概念、步骤、对照表与公式，保留完整讲稿。生成后你可以修改和核对，再开始逐句播放。
    - text: 成人主题无需建立孩子档案。孩子白板只使用明确选择的已学知识点。
  - complementary "白板与候选历史":
    - heading "我的白板" [level=2]
    - button "＋ 新白板"
    - button "教学草稿" [pressed]
    - button "已保存"
    - text: 搜索我的白板
    - textbox "搜索我的白板":
      - /placeholder: 搜索主题或标题
    - button "已取消 · 本人主题 匿名观察 [topic-pause-once] DeepSeek V4.1 Flash"
    - button "上一页" [disabled]
    - text: 1 / 1
    - button "下一页" [disabled]
```

# Test source

```ts
  77  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
  78  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  79  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  80  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  81  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  82  | });
  83  | 
  84  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  85  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  86  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  87  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  88  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  89  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  90  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  91  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  92  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  93  | });
  94  | 
  95  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  96  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  97  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  98  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  99  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  100 |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  101 |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  102 |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  103 |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  104 | });
  105 | 
  106 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  107 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  108 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  109 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  110 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  111 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  112 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  113 | });
  114 | 
  115 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  116 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  117 |   try {
  118 |     await second.goto(href); await ready(second);
  119 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  120 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  121 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  122 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  123 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
  124 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  125 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  126 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  127 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  128 |   } finally { await second.close(); }
  129 | });
  130 | 
  131 | test('uncached original topic cannot disappear on a scope change until its complete input is downloaded', async ({ page }) => {
  132 |   const f = await fixture(page, true);
  133 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  134 |     if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value);
  135 |   }; });
  136 |   await page.getByLabel('讲解主题').fill('尚未生成也不能丢失的匿名主题');
  137 |   await page.getByLabel('希望弄懂什么').fill('保留我的完整教学目标。');
  138 |   await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  139 |   await expect(page.getByLabel('白板学习对象')).toHaveValue('');
  140 |   await expect(page.getByLabel('讲解主题')).toHaveValue('尚未生成也不能丢失的匿名主题');
  141 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载原主题与请求', exact: true }).click();
  142 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8'));
  143 |   expect(copy.form).toMatchObject({ prompt: '尚未生成也不能丢失的匿名主题', objective: '保留我的完整教学目标。' });
  144 |   await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  145 |   await expect(page.getByLabel('白板学习对象')).toHaveValue(f.studentId!);
  146 | });
  147 | 
  148 | test('another explicit local manuscript cannot replace uncached dirty input until the current complete copy is downloaded', async ({ page }) => {
  149 |   await fixture(page); await generate(page); await ready(page);
  150 |   await page.getByLabel('讲解概要').fill('第一份可恢复的完整本机改稿。');
  151 |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.description))).toContain('第一份可恢复的完整本机改稿。');
  152 |   await page.reload(); await ready(page);
  153 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  154 |     if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value);
  155 |   }; });
  156 |   await page.getByLabel('讲解概要').fill('尚无本机缓存的第二份完整改稿。');
  157 |   await page.getByText('查看其他本机改稿', { exact: true }).click();
  158 |   const restore = page.getByRole('button', { name: '恢复这份本机改稿', exact: true }).first(); await expect(restore).toBeDisabled();
  159 |   await expect(page.getByLabel('讲解概要')).toHaveValue('尚无本机缓存的第二份完整改稿。');
  160 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  161 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('尚无本机缓存的第二份完整改稿。');
  162 |   await expect(restore).toBeEnabled(); await restore.click();
  163 |   await expect(page.getByLabel('讲解概要')).toHaveValue('第一份可恢复的完整本机改稿。');
  164 | });
  165 | 
  166 | test('recovery: an uncached original cancellation survives object changes until its exact command is downloaded', async ({ page }) => {
  167 |   await fixture(page); await generate(page, '匿名观察 [topic-pause-once]');
  168 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  169 |     if (key.startsWith('studyagent.topic-whiteboard.command.')) throw new DOMException('Synthetic unavailable command storage', 'QuotaExceededError'); return original.call(this, key, value);
  170 |   }; });
  171 |   let writes = 0;
  172 |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/cancel', async route => {
  173 |     writes++; expect((await route.fetch()).status()).toBe(201); await route.abort('failed');
  174 |   });
  175 |   await page.getByRole('button', { name: '取消生成', exact: true }).click();
  176 |   await expect(page.getByRole('button', { name: '恢复原取消请求', exact: true })).toBeEnabled();
> 177 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.locator('.tw-candidate')).toBeVisible();
      |                                                                                                                       ^ Error: expect(locator).toBeVisible() failed
  178 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载原稿与请求', exact: true }).click();
  179 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8'));
  180 |   expect(copy.pending.action).toBe('cancel'); expect(copy.pending.body.requestKey).toBeTruthy(); expect(writes).toBe(1);
  181 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.locator('.tw-candidate')).toHaveCount(0);
  182 | });
  183 | 
  184 | test('topic-slot: two real tabs keep their own complete incomplete edits after either tab reloads', async ({ page }) => {
  185 |   await fixture(page); await generate(page); await ready(page); const second = await page.context().newPage();
  186 |   try {
  187 |     await second.goto(page.url()); await ready(second);
  188 |     await page.getByLabel('讲解概要').fill('第一标签页尚未保存的完整稿。');
  189 |     const copies = () => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.description));
  190 |     await expect.poll(copies).toContain('第一标签页尚未保存的完整稿。');
  191 |     await second.getByLabel('讲解概要').fill('第二标签页的另一份完整稿。'); await expect.poll(copies).toContain('第二标签页的另一份完整稿。');
  192 |     await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('第一标签页尚未保存的完整稿。');
  193 |     await second.reload(); await ready(second); await expect(second.getByLabel('讲解概要')).toHaveValue('第二标签页的另一份完整稿。');
  194 |   } finally { await second.close(); }
  195 | });
  196 | 
  197 | for (const width of [390, 768, 1440]) test('explicit child goals, adult separation and complete edit controls fit at ' + width, async ({ page }) => {
  198 |   const f = await fixture(page, true); await page.setViewportSize({ width, height: 1000 }); await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  199 |   await expect(page.locator('.tw-goals input')).toHaveCount(1); await page.locator('.tw-goals input').check(); await generate(page, '在相同整体下解释分数单位'); await ready(page);
  200 |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view.studentId).toBe(f.studentId); expect(view.audience.atomIds).toEqual(['core:math:fractionadd']);
  201 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  202 |   await page.evaluate(() => window.scrollTo(0, 0)); await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'child-editor-' + width + '.png'), fullPage: true });
  203 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  204 |   await expect(page.locator('.wb-current-sentence')).toContainText('先核对观察'); expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  205 |   await page.getByRole('button', { name: '关闭白板', exact: true }).click();
  206 | });
  207 | 
```