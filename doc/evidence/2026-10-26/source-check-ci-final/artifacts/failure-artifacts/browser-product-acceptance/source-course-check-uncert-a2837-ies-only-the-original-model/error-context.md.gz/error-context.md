# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-check.spec.ts >> uncertain review requires an explicit acknowledgement and cancellation retries only the original model
- Location: tests/e2e/source-course-check.spec.ts:36:5

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "已取消"
Received string:    "INDEPENDENT CHECK换一个情境，看看理解到了哪里。逐题保留首答、帮助和反馈；AI生成题仍待内容审核。＋ 准备独立核查题组或任务已更新，请读取原操作状态后继续取消准备 · 服务端拒绝了原参数原请求与版本已保留。核对会重用原参数，不自动换成最新版本。按原参数核对操作保留稿件，释放已拒绝操作这门资料课程尚未设置独立核查。确认用于练习可保留未看答案的自测路径。“审阅答案并编辑”会记录当前版本的答案曝光。管理题组候选与版本（1）待确认用于练习 · 已保存从新情境核查理解Synthetic source check · not a real model · 2个目标 · 4题v1AI复核：仍有待核查问题 · 1项 · 针对当前稿确认用于练习审阅答案并编辑"

Call Log:
- Timeout 30000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - link "Home" [ref=f1e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f1e13]: 首页
        - link "Courses" [ref=f1e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f1e17]: 课程
        - link "Calendar" [ref=f1e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f1e21]: 学习动态
        - link "History" [ref=f1e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f1e25]: 历史
        - link "Materials" [ref=f1e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e29]: 资料
      - generic [ref=f1e30]:
        - heading "继续学习" [level=2] [ref=f1e31]
        - link "讲座社会学想象力 社会学概论" [ref=f1e32] [cursor=pointer]:
          - /url: /studio/classroom
          - text: 讲座社会学想象力
          - generic [ref=f1e33]: 社会学概论
      - generic [ref=f1e34]:
        - heading "近期活动" [level=2] [ref=f1e35]
        - paragraph [ref=f1e36]: 开始学习后，活动会出现在这里。
      - link "返回学习首页 →" [ref=f1e38] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f1e39]:
      - generic [ref=f1e40]:
        - generic [ref=f1e41]:
          - link "‹ 返回我的课程" [ref=f1e42] [cursor=pointer]:
            - /url: /studio?view=courses
          - text: SOURCE TO COURSE
          - heading "看懂资源与条件" [level=1] [ref=f1e43]
          - paragraph [ref=f1e44]: 保留来源和适用条件，比较替代解释。[check-pause-once][check-uncertain]
        - button "＋ 从资料创建课程" [ref=f1e45] [cursor=pointer]
      - generic [ref=f1e46]:
        - generic [ref=f1e47]: 可以开始学习
        - generic [ref=f1e48]: Browser fixture · not a real model · 中文讲解 · 每次预算 15 分钟
        - generic [ref=f1e49]: 内容待核查 · 不作为正式能力测量
      - region "课程版本与变更" [ref=f1e50]:
        - generic [ref=f1e51]:
          - generic [ref=f1e52]:
            - text: COURSE VERSIONS
            - heading "第 1 版 正在使用" [level=2] [ref=f1e53]
          - generic [ref=f1e54]:
            - button "创建修订稿" [ref=f1e55] [cursor=pointer]
            - button "归档课程" [ref=f1e56] [cursor=pointer]
            - button "撤回此版本" [ref=f1e57] [cursor=pointer]
      - region "资料课程项目" [ref=f1e58]:
        - text: COURSE PROJECT
        - heading "把资料应用到自己的新情境" [level=3] [ref=f1e59]
        - paragraph [ref=f1e60]: 保留来源、产物、替代解释与验证计划。自评、AI建议和人工复核分别记录，不直接改变知识掌握结论。
        - link "打开资料应用项目 →" [ref=f1e62] [cursor=pointer]:
          - /url: /studio/projects?sourceCourseId=source_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d
      - region "资料课程独立核查" [ref=f1e63]:
        - generic [ref=f1e64]:
          - generic [ref=f1e65]:
            - text: INDEPENDENT CHECK
            - heading "换一个情境，看看理解到了哪里。" [level=2] [ref=f1e66]
            - paragraph [ref=f1e67]: 逐题保留首答、帮助和反馈；AI生成题仍待内容审核。
          - button "＋ 准备独立核查" [disabled] [ref=f1e68]
        - alert [ref=f1e69]: 题组或任务已更新，请读取原操作状态后继续
        - article [ref=f1e70]:
          - generic [ref=f1e71]: 取消准备 · 服务端拒绝了原参数
          - paragraph [ref=f1e72]: 原请求与版本已保留。核对会重用原参数，不自动换成最新版本。
          - button "按原参数核对操作" [ref=f1e73] [cursor=pointer]
          - button "保留稿件，释放已拒绝操作" [ref=f1e74] [cursor=pointer]
        - paragraph [ref=f1e75]: 这门资料课程尚未设置独立核查。
        - paragraph [ref=f1e76]: 确认用于练习可保留未看答案的自测路径。“审阅答案并编辑”会记录当前版本的答案曝光。
        - group [ref=f1e77]:
          - generic "管理题组候选与版本（1）" [ref=f1e78] [cursor=pointer]
      - group [ref=f1e79]:
        - generic "查看原始生成目标与模型" [ref=f1e80] [cursor=pointer]
      - region "生成稿复核概况" [ref=f1e81]:
        - generic [ref=f1e82]:
          - text: CONTENT CHECKS
          - heading "保留复核问题，逐项核对。" [level=2] [ref=f1e83]
        - paragraph [ref=f1e84]: 下面记录这次模型复核的结果。模型复核不能代替教师内容审核。
        - list [ref=f1e85]:
          - listitem [ref=f1e86]:
            - generic [ref=f1e87]: 区分事实与解释
            - generic [ref=f1e88]: 模型未报告问题
          - listitem [ref=f1e89]:
            - generic [ref=f1e90]: 比较替代解释
            - generic [ref=f1e91]: 模型未报告问题
        - paragraph [ref=f1e92]: 本次教学范围：依据本次选定的原文比较观察、解释与可验证条件，不能据此宣称全教材覆盖。
      - generic [ref=f1e93]:
        - generic [ref=f1e94]:
          - generic [ref=f1e96]:
            - text: COURSE OUTLINE
            - heading "从原文走向理解" [level=2] [ref=f1e97]
          - paragraph [ref=f1e98]: 从匿名观察出发，比较条件并寻找可区分的证据。
          - article [ref=f1e99]:
            - generic [ref=f1e100]: LESSON 01
            - heading "区分事实与解释" [level=3] [ref=f1e101]
            - paragraph [ref=f1e102]: 把观察、推断与待验证条件分开。
            - button "↗ 核查合成原文 · 段 1" [ref=f1e104] [cursor=pointer]
            - group [ref=f1e105]:
              - generic "预览讲解与提炼板书" [ref=f1e106] [cursor=pointer]
            - generic [ref=f1e107]: 2 道生成练习 · 两级提示
            - generic "讲解与练习记录" [ref=f1e108]:
              - generic [ref=f1e109]: 讲解未开始
              - generic [ref=f1e110]: 练习未开始
            - generic [ref=f1e111]:
              - link "开始讲解 →" [ref=f1e112] [cursor=pointer]:
                - /url: /studio/classroom?sourceCourseId=source_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d&lesson=source%3Asource_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d%3A1&tab=history
              - link "进入课堂练习" [ref=f1e113] [cursor=pointer]:
                - /url: /studio/classroom?sourceCourseId=source_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d&lesson=source%3Asource_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d%3A1&tab=practice
          - article [ref=f1e114]:
            - generic [ref=f1e115]: LESSON 02
            - heading "比较替代解释" [level=3] [ref=f1e116]
            - paragraph [ref=f1e117]: 把观察、推断与待验证条件分开。
            - button "↗ 核查合成原文 · 段 1" [ref=f1e119] [cursor=pointer]
            - group [ref=f1e120]:
              - generic "预览讲解与提炼板书" [ref=f1e121] [cursor=pointer]
            - generic [ref=f1e122]: 2 道生成练习 · 两级提示
            - generic "讲解与练习记录" [ref=f1e123]:
              - generic [ref=f1e124]: 讲解未开始
              - generic [ref=f1e125]: 练习未开始
            - generic [ref=f1e126]:
              - link "开始讲解 →" [ref=f1e127] [cursor=pointer]:
                - /url: /studio/classroom?sourceCourseId=source_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d&lesson=source%3Asource_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d%3A2&tab=history
              - link "进入课堂练习" [ref=f1e128] [cursor=pointer]:
                - /url: /studio/classroom?sourceCourseId=source_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d&lesson=source%3Asource_course_6a71f3e1-bdd1-4a42-930f-c55dbba87d4d%3A2&tab=practice
        - complementary [ref=f1e129]:
          - generic [ref=f1e130]:
            - text: LEARN WITH THE SOURCE
            - heading "回到原文核查" [level=2] [ref=f1e131]
          - generic [ref=f1e132]:
            - text: 课程引用的页或段
            - combobox "课程引用来源" [ref=f1e133]:
              - option "核查合成原文 · 第1段" [selected]
          - article [ref=f1e134]:
            - generic [ref=f1e135]:
              - text: FROZEN SOURCE
              - heading "核查合成原文 · 第1段" [level=3] [ref=f1e136]
              - paragraph [ref=f1e137]: 课程保存的正文版本 4a1c8b71c1fe · 正文来源已保留
            - generic [ref=f1e138]: 匿名阅览室在两个周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {browserEvidence} from './evidence';
  3  | const api='http://localhost:'+(process.env.E2E_API_PORT??4107)+'/api',evidence=browserEvidence('source-check');let address=0;
  4  | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok,method+' '+path+' -> '+response.status).toBe(true);return(await response.json()).data;}
  5  | async function enter(page:Page,extra=''){
  6  |   page.on('dialog',dialog=>void dialog.accept());const suffix=crypto.randomUUID(),principal='source-check-'+suffix+'@local.test',credential='Source-check-'+suffix,response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.36.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  7  |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  8  |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'核查合成原文',sections:['匿名阅览室在两个周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'合成资料独立核查 '+suffix,goal:'保留来源和适用条件，比较替代解释。'+extra,language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');row=await call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});await page.goto('/studio/source-courses?course='+row.id);await expect(page.getByRole('region',{name:'资料课程独立核查',exact:true})).toBeVisible();return{actor,row,principal,credential};
  9  | }
  10 | const panel=(page:Page)=>page.getByRole('region',{name:'资料课程独立核查',exact:true});
  11 | async function prepareUI(page:Page){await panel(page).getByRole('button',{name:'＋ 准备独立核查',exact:true}).click();const dialog=page.getByRole('dialog',{name:'选择这次要核查的目标',exact:true});await dialog.locator('input[type=checkbox]').nth(0).check();await dialog.locator('input[type=checkbox]').nth(1).check();await expect(dialog.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');await dialog.getByRole('button',{name:'预览核查范围',exact:true}).click();await expect(dialog).toContainText('完整输入已核对');await dialog.getByRole('button',{name:'准备这份题组',exact:true}).click();}
  12 | async function candidate(page:Page){const button=panel(page).getByRole('button',{name:'确认用于练习',exact:true});await expect.poll(async()=>panel(page).textContent(),{timeout:30000}).toContain('待确认用于练习');if(!await button.isVisible())await panel(page).locator('summary').filter({hasText:'管理题组候选与版本'}).click();await expect(button).toBeVisible();return button;}
  13 | async function confirmUI(page:Page){await(await candidate(page)).click();const dialog=page.getByRole('dialog',{name:'将题组用于练习',exact:true});await dialog.getByLabel('同意将这份待审核题组用于练习').check();await dialog.getByRole('button',{name:'确认用于练习',exact:true}).click();}
  14 | async function readyByApi(actor:any,row:any){const candidate=await call(actor,'POST','/learning/source-courses/'+row.id+'/checks/prepare',{expectedRevision:row.revision,courseFingerprint:row.fingerprint,lessonIds:row.lessons.map((lesson:any)=>lesson.id),modelId:'deepseek-v4-flash',requestKey:crypto.randomUUID()});let view:any;await expect.poll(async()=>{view=await call(actor,'GET','/learning/source-courses/'+row.id+'/checks/'+candidate.id);return view.status;},{timeout:30000}).toBe('ready');return view;}
  15 | 
  16 | for(const width of [390,768,1440])test('source check keeps independent first answers, frozen sources and exact course return at '+width,async({page})=>{
  17 |   test.setTimeout(150000);await page.setViewportSize({width,height:960});const{actor,row}=await enter(page);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await prepareUI(page);await candidate(page);await page.screenshot({path:evidence+'/candidates-'+width+'.png',fullPage:true});await confirmUI(page);await expect(panel(page).getByRole('link',{name:'开始独立核查 →',exact:true})).toBeVisible();await panel(page).getByRole('link',{name:'开始独立核查 →',exact:true}).click();
  18 |   await expect(page.getByRole('region',{name:'课堂练习题目',exact:true})).toBeVisible();const sessionId=new URL(page.url()).searchParams.get('session')!,session=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(session.sourceCheckId).toBe(new URL(page.url()).searchParams.get('sourceCheckId'));expect(session.authoringAnswerExposure).toBeUndefined();expect(JSON.stringify(session)).not.toContain('correctIndices');await expect(page.locator('.cl-unit-check-note')).toContainText('4个新情境');
  19 |   await page.locator('.cl-practice-options label').nth(0).click();await page.locator('.cl-practice-options label').nth(2).click();await page.getByRole('button',{name:'Check →',exact:true}).click();await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');const original=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(original.answers[0].answerExposure).toBeUndefined();
  20 |   await page.getByRole('button',{name:'核对本题原文 1 ↗',exact:true}).click();const source=page.getByRole('dialog',{name:'核查合成原文',exact:true});await expect(source).toContainText('没有记录晚间');await page.screenshot({path:evidence+'/frozen-source-'+width+'.png'});await page.keyboard.press('Escape');await expect(source).toHaveCount(0);await expect(page.getByRole('button',{name:'核对本题原文 1 ↗',exact:true})).toBeFocused();
  21 |   await page.reload();await expect(page.locator('.cl-practice-prompt small')).toContainText('2 / 4');await page.locator('.cl-practice-options label').first().click();await page.getByRole('button',{name:'Check →',exact:true}).click();await page.getByRole('button',{name:'下一题 →',exact:true}).click();await page.getByRole('button',{name:'这题我不会',exact:true}).click();await page.getByRole('button',{name:'下一题 →',exact:true}).click();await page.getByRole('button',{name:'Skip',exact:true}).click();await expect(page.getByRole('region',{name:'课堂练习复盘',exact:true})).toBeVisible();await page.screenshot({path:evidence+'/review-'+width+'.png'});
  22 |   const final=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(final.answers[0]).toEqual(original.answers[0]);expect(final.answers).toHaveLength(4);await page.getByRole('button',{name:'返回课程，安排下一步',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await expect(page).toHaveURL(new RegExp('/studio/source-courses\\?.*course='+row.id));await expect(panel(page).getByRole('link',{name:'复盘本次核查 →',exact:true})).toBeVisible();const course=await call(actor,'GET','/learning/source-courses/'+row.id);expect(course.journey.unitCheck.current.activity.practice.summary).toMatchObject({answered:4,independentCorrect:2,dontKnow:1,skipped:1});expect(course.lastSessionId).toBeNull();expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(width===1440){await call(actor,'POST','/learning/source-courses/'+row.id+'/archive',{expectedRevision:course.revision,requestKey:crypto.randomUUID()});await panel(page).getByRole('link',{name:'复盘本次核查 →',exact:true}).click();await expect(page.getByRole('region',{name:'课堂练习复盘',exact:true})).toBeVisible();await page.getByRole('button',{name:'回到相关微课',exact:true}).first().click();await expect(page.getByRole('alert',{name:'课堂切换未完成',exact:true})).toContainText('已归档课程只能查看已有课堂记录');await page.getByRole('button',{name:'关闭课堂切换提示',exact:true}).click();await expect(page.getByRole('region',{name:'课堂练习复盘',exact:true})).toBeVisible();}
  23 | });
  24 | 
  25 | test('recovery: lost prepare and confirmation replies replay exact original commands after refresh without exposing answers',async({page})=>{
  26 |   test.setTimeout(150000);const{actor,row}=await enter(page),prepareKeys:string[]=[],confirmKeys:string[]=[];let dropped=false;
  27 |   await page.route('**/checks/prepare',async route=>{prepareKeys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await prepareUI(page);await expect(page.getByRole('dialog',{name:'选择这次要核查的目标'}).getByRole('alert')).toBeVisible();await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();await candidate(page);expect(prepareKeys).toHaveLength(2);expect(prepareKeys[1]).toBe(prepareKeys[0]);expect(await call(actor,'GET','/learning/source-courses/'+row.id+'/checks')).toHaveLength(1);
  28 |   dropped=false;await page.route('**/checks/*/confirm',async route=>{confirmKeys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await confirmUI(page);await expect(page.getByRole('dialog',{name:'将题组用于练习'}).getByRole('alert')).toBeVisible();await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();await expect(panel(page).getByRole('link',{name:'开始独立核查 →',exact:true})).toBeVisible();expect(confirmKeys).toHaveLength(2);expect(confirmKeys[1]).toBe(confirmKeys[0]);const checks=await call(actor,'GET','/learning/source-courses/'+row.id+'/checks');expect(checks[0].publication.revision).toBe(1);await panel(page).getByRole('link',{name:'开始独立核查 →',exact:true}).click();await expect(page.getByRole('region',{name:'课堂练习题目',exact:true})).toBeVisible();const session=await call(actor,'GET','/learning/classroom/sessions/'+new URL(page.url()).searchParams.get('session'));expect(session.authoringAnswerExposure).toBeUndefined();
  29 | });
  30 | 
  31 | test('recovery: explicit authoring keeps a dirty local copy and replays a lost edit without replacing the original request or review',async({page})=>{
  32 |   test.setTimeout(150000);const{actor,row}=await enter(page);await readyByApi(actor,row);await page.reload();await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();const editor=page.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await editor.getByLabel('题组名称',{exact:true}).fill('保留本机题组修改');await expect(editor).toContainText('有未保存修改');const keys:string[]=[];let dropped=false;await page.route('**/checks/*/content',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await editor.getByRole('button',{name:'保存题组修改',exact:true}).click();await expect(editor.getByRole('alert')).toBeVisible();await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();await expect(panel(page)).toContainText('保留本机题组修改');expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);await expect(panel(page).getByText(/本机未保存题组稿/)).toHaveCount(0);
  33 |   await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue('保留本机题组修改');await editor.getByLabel('题组名称',{exact:true}).fill('还未保存的另一稿');await editor.getByRole('button',{name:'关闭题组编辑',exact:true}).click();await page.getByRole('button',{name:'保留本机稿并关闭',exact:true}).click();await page.reload();await panel(page).locator('summary').filter({hasText:'本机未保存题组稿'}).click();await panel(page).getByRole('button',{name:'打开并比较本机稿',exact:true}).click();await editor.getByRole('button',{name:'恢复这份本机稿',exact:true}).click();await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue('还未保存的另一稿');await expect(editor).toContainText('原AI复核不适用于当前修改');
  34 | });
  35 | 
  36 | test('uncertain review requires an explicit acknowledgement and cancellation retries only the original model',async({page})=>{
> 37 |   test.setTimeout(180000);const{actor,row}=await enter(page,'[check-pause-once][check-uncertain]');await prepareUI(page);await expect(panel(page).getByRole('button',{name:'取消这次准备',exact:true})).toBeVisible();await panel(page).getByRole('button',{name:'取消这次准备',exact:true}).click();await expect.poll(async()=>panel(page).textContent(),{timeout:30000}).toContain('已取消');if(!await panel(page).getByRole('button',{name:'使用原模型重试',exact:true}).isVisible())await panel(page).locator('summary').filter({hasText:'管理题组候选与版本'}).click();await panel(page).getByRole('button',{name:'使用原模型重试',exact:true}).click();await candidate(page);await(await candidate(page)).click();const dialog=page.getByRole('dialog',{name:'将题组用于练习',exact:true});await dialog.getByLabel('同意将这份待审核题组用于练习').check();await expect(dialog.getByRole('button',{name:'确认用于练习',exact:true})).toBeDisabled();await dialog.getByLabel('我已了解AI仍有待核查问题或原审稿已过期，不把本次练习当作正式测量').check();await dialog.getByRole('button',{name:'确认用于练习',exact:true}).click();await expect(panel(page).getByRole('link',{name:'开始独立核查 →',exact:true})).toBeVisible();const checks=await call(actor,'GET','/learning/source-courses/'+row.id+'/checks');expect(checks).toHaveLength(1);expect(checks[0].modelId).toBe('deepseek-v4-flash');expect(checks[0].review.decision).toBe('uncertain');expect(checks[0].task.generation).toBe(2);
     |                                                                                                                                                                                                                                                                                                                                                                ^ Error: expect(received).toContain(expected) // indexOf
  38 | });
  39 | 
  40 | test('recovery: shared tabs block unknown commands while another device can edit before historical replay',async({page,context,browser})=>{
  41 |   test.setTimeout(150000);const{actor,row,principal,credential}=await enter(page),view=await readyByApi(actor,row);await page.reload();await candidate(page);let dropped=false;const keys:string[]=[];await page.route('**/checks/*/authoring',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();await expect(panel(page).getByRole('alert')).toBeVisible();
  42 |   const shared=await context.newPage();await shared.goto('/studio/source-courses?course='+row.id);await candidate(shared);await expect(panel(shared).getByRole('button',{name:'审阅答案并编辑',exact:true})).toBeDisabled();await shared.close();const device=await browser.newContext({baseURL:'http://localhost:'+(process.env.E2E_WEB_PORT??3107)}),other=await device.newPage();await other.goto('/parent/login');await other.getByLabel('登录账号').fill(principal);await other.getByLabel('密码').fill(credential);await other.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(other).toHaveURL(/\/learn(?:\?|$)/);await other.goto('/studio/source-courses?course='+row.id);await candidate(other);await panel(other).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();const second=other.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await second.getByLabel('题组名称',{exact:true}).fill('另一个标签保存的当前稿');await second.getByRole('button',{name:'保存题组修改',exact:true}).click();await expect(second).toContainText('已读取服务端稿件');await second.getByRole('button',{name:'关闭题组编辑',exact:true}).click();
  43 |   await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();const editor=page.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await expect(editor).toContainText('这是原操作保存的旧版本');await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue(view.title);await expect(editor.getByRole('button',{name:'保存题组修改',exact:true})).toHaveCount(0);expect(keys[0]).toBe(keys[1]);await editor.getByRole('button',{name:'关闭题组编辑',exact:true}).click();await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue('另一个标签保存的当前稿');await expect(editor.getByLabel('引用1来源',{exact:true})).toContainText('核查合成原文');await editor.locator('summary').filter({hasText:'对照原始AI稿与审稿'}).click();await expect(editor.locator('.sc-check-manuscript').getByRole('heading',{name:'从新情境核查理解',exact:true})).toBeVisible();await expect(editor.locator('.sc-check-manuscript')).not.toContainText('correctIndices');await page.screenshot({path:evidence+'/authoring-readable-original.png'});await editor.locator('summary').filter({hasText:'对照引用1冻结原文'}).click();await expect(editor).toContainText('没有记录晚间');const close=editor.getByRole('button',{name:'关闭题组编辑',exact:true});await close.focus();await page.keyboard.press('Shift+Tab');await expect(editor.getByRole('button',{name:'导出本机题组稿',exact:true})).toBeFocused();await page.keyboard.press('Tab');await expect(close).toBeFocused();await page.keyboard.press('Escape');await expect(editor).toHaveCount(0);await expect(panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true})).toBeFocused();await device.close();
  44 | });
  45 | 
  46 | test('an unavailable local draft store keeps the editor open and never promises a saved recoverable copy',async({page})=>{
  47 |   test.setTimeout(120000);const{actor,row}=await enter(page);await readyByApi(actor,row);await page.reload();await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();await page.evaluate(()=>{const original=Storage.prototype.setItem;Storage.prototype.setItem=function(key,value){if(key.startsWith('studyagent.sourcecheck.draft.'))throw new DOMException('Synthetic quota limit','QuotaExceededError');return original.call(this,key,value);};});const editor=page.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await editor.getByLabel('题组名称',{exact:true}).fill('仅在当前页的未保存稿');await expect(panel(page)).toContainText('本机存储不可用');await editor.getByRole('button',{name:'关闭题组编辑',exact:true}).click();const leave=page.getByRole('dialog',{name:'保留这份未保存稿',exact:true});await expect(leave.getByRole('button',{name:'保留本机稿并关闭',exact:true})).toBeDisabled();await leave.getByRole('button',{name:'继续编辑',exact:true}).click();await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue('仅在当前页的未保存稿');await expect(editor.getByRole('button',{name:'导出本机题组稿',exact:true})).toBeEnabled();
  48 | });
  49 | 
  50 | test('recovery: a rejected concurrent edit keeps both drafts until the user explicitly compares and rebases',async({page,context})=>{
  51 |   test.setTimeout(150000);const{actor,row}=await enter(page);await readyByApi(actor,row);await page.reload();await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();const first=page.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await first.getByLabel('题组名称',{exact:true}).fill('第一标签的本机修改');
  52 |   const other=await context.newPage();await other.goto('/studio/source-courses?course='+row.id);await candidate(other);await panel(other).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();const second=other.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await second.getByLabel('题组名称',{exact:true}).fill('第二标签先保存的版本');await second.getByRole('button',{name:'保存题组修改',exact:true}).click();await expect(second).toContainText('已读取服务端稿件');
  53 |   await first.getByRole('button',{name:'保存题组修改',exact:true}).click();await expect(first.getByRole('alert')).toBeVisible();await expect(first.getByLabel('题组名称',{exact:true})).toHaveValue('第一标签的本机修改');await first.getByRole('button',{name:'保留稿件，释放已拒绝操作',exact:true}).click();await first.getByRole('button',{name:'读取当前版本并比较本机稿',exact:true}).click();await expect(first.getByLabel('题组名称',{exact:true})).toHaveValue('第二标签先保存的版本');await expect(first).toContainText('本机稿基于另一个内容版本');await expect(first.getByRole('button',{name:'恢复这份本机稿',exact:true})).toBeDisabled();await first.getByLabel('我已比较版本，明确将这份本机稿作为当前候选的新修改').check();await first.getByRole('button',{name:'恢复这份本机稿',exact:true}).click();await expect(first.getByLabel('题组名称',{exact:true})).toHaveValue('第一标签的本机修改');await first.getByRole('button',{name:'保存题组修改',exact:true}).click();await expect(first).toContainText('已读取服务端稿件');const latest=(await call(actor,'GET','/learning/source-courses/'+row.id+'/checks'))[0];expect(latest.title).toBe('第一标签的本机修改');expect(latest.contentVersion).toBe(3);expect(latest.review.current).toBe(false);await other.close();
  54 | });
  55 | 
```