# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-media.spec.ts >> actual WebM has a decoded audio track and the same complete SRT timeline at the selected speed
- Location: tests\e2e\whiteboard-media.spec.ts:95:5

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 0.6
Received:   NaN
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - button "Home" [ref=f1e10] [cursor=pointer]:
          - generic [ref=f1e13]: 首页
        - button "Courses" [ref=f1e14] [cursor=pointer]:
          - generic [ref=f1e17]: 课程
        - button "Calendar" [ref=f1e18] [cursor=pointer]:
          - generic [ref=f1e21]: 学习动态
        - button "History" [ref=f1e22] [cursor=pointer]:
          - generic [ref=f1e25]: 历史
        - button "Materials" [ref=f1e26] [cursor=pointer]:
          - generic [ref=f1e29]: 资料
      - button "＋ 创建课程" [ref=f1e30] [cursor=pointer]
      - generic [ref=f1e31]:
        - heading "继续学习" [level=2] [ref=f1e32]
        - link "讲座社会学想象力 社会学概论" [ref=f1e33] [cursor=pointer]:
          - /url: /studio/classroom?lesson=soc-1-1-1
          - text: 讲座社会学想象力
          - generic [ref=f1e34]: 社会学概论
      - generic [ref=f1e35]:
        - heading "近期活动" [level=2] [ref=f1e36]
        - link "白板视频「异分母分数加法」" [ref=f1e37] [cursor=pointer]:
          - /url: /studio?whiteboard=studio_whiteboard_0f700747-f2df-43e3-9bbe-a4f4febecc7c
      - link "返回学习首页 →" [ref=f1e39] [cursor=pointer]:
        - /url: /learn?subject=math&student=student_b93eaa49-7b1f-462e-b638-0ff2ab143243
    - generic [ref=f1e40]:
      - generic [ref=f1e41]:
        - generic [ref=f1e42]:
          - combobox "学习档案" [ref=f1e43]:
            - option "匿名白板验证" [selected]
          - combobox "学科" [ref=f1e44]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e45]:
          - link "教学课堂 ↗" [ref=f1e46] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e47] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e48]:
        - generic [ref=f1e49]:
          - button "Craft Courses" [ref=f1e50] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e51] [cursor=pointer]
        - generic [ref=f1e52]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f1e53]
          - paragraph [ref=f1e54]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f1e55]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f1e56]
          - generic [ref=f1e57]:
            - generic [ref=f1e58]: ＋
            - generic [ref=f1e59]: 资料
            - button "Concept Explanation" [ref=f1e60] [cursor=pointer]
            - generic [ref=f1e61]: 语音
            - generic [ref=f1e64]:
              - generic [ref=f1e65]: 模型
              - combobox "选择大模型" [ref=f1e66] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - button "↑" [ref=f1e67] [cursor=pointer]
        - generic [ref=f1e68]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f1e69] [cursor=pointer]:
            - generic [ref=f1e70]: 可视化
            - generic [ref=f1e71]: 用图形解释异分母加法
            - generic [ref=f1e72]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f1e73] [cursor=pointer]:
            - generic [ref=f1e74]: 个性化练习
            - generic [ref=f1e75]: 从我的已知点生成练习
            - generic [ref=f1e76]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f1e77] [cursor=pointer]:
            - generic [ref=f1e78]: 主动学习
            - generic [ref=f1e79]: 看看今天最值得做什么
            - generic [ref=f1e80]: 按教育优先级排序
        - generic [ref=f1e81]:
          - heading "你的学习路径" [level=2] [ref=f1e82]
          - button "创建课程" [ref=f1e83] [cursor=pointer]
        - generic [ref=f1e84]:
          - heading "还没有课程" [level=3] [ref=f1e85]
          - paragraph [ref=f1e86]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f1e87] [cursor=pointer]
        - complementary [ref=f1e88]:
          - article [ref=f1e89]:
            - generic [ref=f1e90]:
              - generic [ref=f1e91]:
                - text: LEARNER SNAPSHOT
                - heading "匿名白板验证" [level=2] [ref=f1e92]
              - generic [ref=f1e93]: 5 年级
            - generic [ref=f1e94]:
              - strong [ref=f1e95]: "0"
              - generic [ref=f1e96]: / 1
              - generic [ref=f1e97]: 已有点有稳定证据
            - generic [ref=f1e98]:
              - generic [ref=f1e99]:
                - generic [ref=f1e100]: "1"
                - text: 已确认知识点
              - generic [ref=f1e101]:
                - generic [ref=f1e102]: "0"
                - text: 日历安排
          - article [ref=f1e103]:
            - generic [ref=f1e104]:
              - generic [ref=f1e105]: NEXT BEST ACTION
              - button "全部 →" [ref=f1e106] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f1e107] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_b93eaa49-7b1f-462e-b638-0ff2ab143243&subject=math
              - generic [ref=f1e108]: 1个已学点仍需补充证据
              - paragraph [ref=f1e109]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f1e110]:
            - generic [ref=f1e111]:
              - generic [ref=f1e112]: RECENT WHITEBOARDS
              - button "新建" [ref=f1e113] [cursor=pointer]
            - button "▶ 匿名逐句白板 2 幕 · 1 秒" [ref=f1e114] [cursor=pointer]:
              - generic [ref=f1e115]: ▶
              - generic [ref=f1e116]:
                - generic [ref=f1e117]: 匿名逐句白板
                - generic [ref=f1e118]: 2 幕 · 1 秒
          - article [ref=f1e119]:
            - generic [ref=f1e120]:
              - generic [ref=f1e121]: SYNC STATUS
              - button "日历 →" [ref=f1e122] [cursor=pointer]
            - paragraph [ref=f1e123]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f1e124]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f1e125]:
      - generic [ref=f1e126]:
        - generic [ref=f1e127]:
          - generic [ref=f1e128]: WHITEBOARD SESSION / 原白板
          - heading "匿名逐句白板" [level=2] [ref=f1e129]
          - paragraph [ref=f1e130]: 逐句云语音 · 实际音轨结束后继续 · 板书按完整要点呈现
        - button "关闭白板" [ref=f1e131] [cursor=pointer]: ×
      - generic [ref=f1e132]:
        - generic [ref=f1e133]:
          - generic "统一单位" [ref=f1e135]
          - paragraph [ref=f1e136]: "[whiteboard-fixture] 先统一单位。"
          - generic [ref=f1e137]:
            - generic [ref=f1e138]: 播放进度（实际音轨）
            - slider "播放进度（实际音轨）" [ref=f1e139] [cursor=pointer]: "0"
          - generic [ref=f1e140]:
            - button "上一句" [disabled] [ref=f1e141]: ←
            - button "播放" [ref=f1e142] [cursor=pointer]: ▶
            - button "下一句" [ref=f1e143] [cursor=pointer]: →
            - generic [ref=f1e144]: 1 / 4 句
            - combobox "阅读方式" [ref=f1e145] [cursor=pointer]:
              - option "文字阅读（估计时长）"
              - option "云语音逐句播放" [selected]
            - combobox "旁白音色" [ref=f1e146] [cursor=pointer]:
              - option "合成音轨 A" [selected]
              - option "受控延迟音轨"
              - option "受控失败音轨"
            - combobox "播放速度" [ref=f1e147] [cursor=pointer]:
              - option "0.75×"
              - option "1×"
              - option "1.25×" [selected]
            - button "导出视频" [ref=f1e148] [cursor=pointer]
            - button "导出字幕" [ref=f1e149] [cursor=pointer]
          - status [ref=f1e150]: 带云语音的 WebM 已生成；导出字幕将使用相同音轨时间表。
          - generic [ref=f1e151]:
            - button "01 统一单位" [ref=f1e152] [cursor=pointer]:
              - generic [ref=f1e153]: "01"
              - text: 统一单位
            - button "02 保留证据" [ref=f1e154] [cursor=pointer]:
              - generic [ref=f1e155]: "02"
              - text: 保留证据
        - complementary "完整讲稿与要点" [ref=f1e156]:
          - heading "逐句讲稿" [level=3] [ref=f1e157]
          - paragraph [ref=f1e158]: 点击一句定位。观看与续播不计作掌握。
          - list [ref=f1e159]:
            - listitem [ref=f1e160]:
              - button "[whiteboard-fixture] 先统一单位。" [ref=f1e161] [cursor=pointer]
            - listitem [ref=f1e162]:
              - button "[whiteboard-fixture] 再合并份数。" [ref=f1e163] [cursor=pointer]
            - listitem [ref=f1e164]:
              - button "[whiteboard-fixture] 最后验证。" [ref=f1e165] [cursor=pointer]
            - listitem [ref=f1e166]:
              - button "[whiteboard-fixture] 保留新的独立观察。" [ref=f1e167] [cursor=pointer]
          - heading "完整笔记与来源" [level=3] [ref=f1e168]
          - group [ref=f1e169]:
            - generic "统一单位" [ref=f1e170] [cursor=pointer]
            - paragraph [ref=f1e171]: 完整正文首行。完整正文末行。
            - list [ref=f1e172]:
              - listitem [ref=f1e173]: 先统一单位
              - listitem [ref=f1e174]: 再合并份数
              - listitem [ref=f1e175]: 最后验证
          - group [ref=f1e176]:
            - generic "保留证据" [ref=f1e177] [cursor=pointer]
          - button "下载续播位置" [ref=f1e178] [cursor=pointer]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { readFileSync } from 'node:fs';
  3   | import { execFileSync } from 'node:child_process';
  4   | 
  5   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107');
  6   | const credential = 'Synthetic-whiteboard-only-20261026';
  7   | async function fixture(page: Page) {
  8   |   const principal = 'whiteboard-' + crypto.randomUUID() + '@local.test';
  9   |   async function call(path: string, body?: unknown, actor?: string, method = 'POST') {
  10  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(actor ? { Authorization: 'Bearer ' + actor } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  11  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
  12  |   }
  13  |   const actor = await call('/auth/register', { principal, credential });
  14  |   const child = await call('/students', { nickname: '匿名白板验证', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token);
  15  |   const studentId = child.profile.id;
  16  |   await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, actor.token, 'PUT');
  17  |   const draft = { studentId, subject: 'math', prompt: '解释异分母分数加法', atomId: 'core:math:fractionadd' };
  18  |   const preview = await call('/learning/studio/whiteboards/preview', draft, actor.token);
  19  |   const saved = await call('/learning/studio/whiteboards', { ...draft, fingerprint: preview.fingerprint, requestKey: crypto.randomUUID() }, actor.token);
  20  |   const board = await call('/qa/whiteboard-media', { boardId: saved.id }, actor.token);
  21  |   await page.route('**/api/learning/studio/overview?*', async route => {
  22  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
  23  |     const payload = await response.json(); payload.data.narrationAvailable = true;
  24  |     payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [
  25  |       { id: 'fixture-a', label: '合成音轨 A' }, { id: 'fixture-delay', label: '受控延迟音轨' }, { id: 'fixture-fail', label: '受控失败音轨' },
  26  |     ] }; await route.fulfill({ response, json: payload });
  27  |   });
  28  |   await page.addInitScript(() => {
  29  |     const NativeAudio = window.Audio; (window as any).__whiteboardAudio = [];
  30  |     (window as any).Audio = function (src?: string) { const audio = new NativeAudio(src); (window as any).__whiteboardAudio.push(audio); return audio; };
  31  |   });
  32  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  33  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  34  |   const href = '/studio?' + new URLSearchParams({ student: studentId, subject: 'math', whiteboard: board.id });
  35  |   await page.goto(href); await expect(page.locator('.wb-current-sentence')).toContainText('先统一单位');
  36  |   return { actor, board, studentId, href, call, current: page.locator('.wb-current-sentence') };
  37  | }
  38  | 
  39  | test('complete sentence, complete notes, paused text reading and explicit sentence navigation', async ({ page }) => {
  40  |   const f = await fixture(page); await page.getByLabel('阅读方式').selectOption('text');
  41  |   await expect(f.current).not.toContainText('最后验证'); await expect(page.locator('.wb-reading-notes ol li')).toHaveCount(4);
  42  |   await expect(page.getByLabel('完整讲稿与要点')).toContainText('完整正文末行');
  43  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  44  |   await expect.poll(() => page.getByRole('slider').inputValue()).not.toBe('0');
  45  |   await page.getByRole('button', { name: '暂停', exact: true }).click(); const at = await page.getByRole('slider').inputValue();
  46  |   await page.waitForTimeout(250); expect(await page.getByRole('slider').inputValue()).toBe(at);
  47  |   await page.getByRole('button', { name: '下一句' }).click(); await expect(f.current).toContainText('再合并份数');
  48  |   await expect(page.locator('.wb-reading-notes [aria-current=step]')).toHaveText('[whiteboard-fixture] 再合并份数。');
  49  |   await page.getByRole('button', { name: '上一句' }).click(); await expect(f.current).toContainText('先统一单位');
  50  |   await page.getByRole('button', { name: '关闭白板' }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toHaveCount(0);
  51  | });
  52  | 
  53  | test('real WAV ended drives cloud playback, pause retains audio time and late ended cannot move a new sentence', async ({ page }) => {
  54  |   const f = await fixture(page); await page.getByRole('button', { name: '播放', exact: true }).click();
  55  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(.15);
  56  |   await expect(f.current).toContainText('先统一单位'); // Original nominal scene duration is only 10ms.
  57  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  58  |   const before = await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime);
  59  |   await page.waitForTimeout(250); expect(await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeCloseTo(before, 1);
  60  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  61  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeGreaterThan(before);
  62  |   await expect(f.current).toContainText('再合并份数', { timeout: 5000 });
  63  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  64  |   await page.evaluate(() => (window as any).__whiteboardAudio[0].dispatchEvent(new Event('ended')));
  65  |   await expect(f.current).toContainText('再合并份数');
  66  |   await page.getByRole('button', { name: '关闭白板' }).click();
  67  |   expect(await page.evaluate(() => (window as any).__whiteboardAudio.every((audio: HTMLAudioElement) => audio.paused && !audio.getAttribute('src')))).toBe(true);
  68  | });
  69  | 
  70  | test('voice switch fences delayed requests and an audio failure offers explicit retry or text reading', async ({ page }) => {
  71  |   const f = await fixture(page); await page.getByLabel('旁白音色').selectOption('fixture-delay');
  72  |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect(page.getByRole('status').last()).toContainText('正在准备当前句');
  73  |   await page.getByLabel('旁白音色').selectOption('fixture-fail'); await page.waitForTimeout(2100);
  74  |   expect(await page.evaluate(() => (window as any).__whiteboardAudio.length)).toBe(0);
  75  |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect(page.locator('.sa-whiteboard-notice')).toContainText('重试或选择文字');
  76  |   await expect(f.current).toContainText('先统一单位'); await page.getByLabel('阅读方式').selectOption('text');
  77  |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => page.getByRole('slider').inputValue()).not.toBe('0');
  78  | });
  79  | 
  80  | test('scoped local resume and complete accessible notes fit phone, tablet and desktop', async ({ page }) => {
  81  |   const f = await fixture(page); await page.getByRole('button', { name: '下一句' }).click();
  82  |   await expect(f.current).toContainText('再合并份数'); await page.waitForTimeout(1700); await page.reload();
  83  |   await expect(f.current).toContainText('再合并份数'); await expect(page.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  84  |   const stored = await page.evaluate(() => Object.entries(localStorage).filter(([key]) => key.startsWith('studyagent.whiteboard.location.v1.')));
  85  |   expect(stored).toHaveLength(1); expect(stored[0][1]).not.toContain('再合并份数');
  86  |   for (const width of [390, 768, 1440]) {
  87  |     await page.setViewportSize({ width, height: 1000 }); await expect(f.current).toBeVisible();
  88  |     expect(await page.locator('.wb-sentence-player').evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
  89  |   }
  90  |   await page.getByRole('button', { name: '关闭白板' }).click();
  91  |   await page.evaluate(([key, value]) => localStorage.setItem(key, JSON.stringify({ ...JSON.parse(value), fingerprint: 'b'.repeat(64) })), stored[0]);
  92  |   await page.reload(); await expect(f.current).toContainText('先统一单位'); await expect(page.locator('.sa-whiteboard-notice')).toContainText('版本不符');
  93  | });
  94  | 
  95  | test('actual WebM has a decoded audio track and the same complete SRT timeline at the selected speed', async ({ page }) => {
  96  |   const f = await fixture(page); await page.getByLabel('播放速度').selectOption('1.25');
  97  |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '导出视频' }).click(); const video = await download;
  98  |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', (await video.path())!], { encoding: 'utf8', windowsHide: true }));
  99  |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true);
  100 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'video')).toBe(true);
> 101 |   expect(Math.abs(Number(probe.format.duration) - 6.4)).toBeLessThan(.6);
      |                                                         ^ Error: expect(received).toBeLessThan(expected)
  102 |   const subtitles = page.waitForEvent('download'); await page.getByRole('button', { name: '导出字幕' }).click(); const srt = readFileSync((await (await subtitles).path())!, 'utf8');
  103 |   expect(srt).toContain('00:00:00,000 --> 00:00:01,600'); expect(srt).toContain('00:00:04,800 --> 00:00:06,400');
  104 |   expect(srt).toContain('先统一单位'); expect(srt).toContain('保留新的独立观察');
  105 |   await expect(f.current).toContainText('先统一单位');
  106 | });
  107 | 
  108 | test('cancelling a recording releases it and never downloads a partial video', async ({ page }) => {
  109 |   await fixture(page); const downloads: string[] = []; page.on('download', download => downloads.push(download.suggestedFilename()));
  110 |   await page.getByRole('button', { name: '导出视频' }).click(); await expect(page.locator('.sa-whiteboard-notice')).toContainText('实时录制');
  111 |   await page.getByRole('button', { name: '取消导出' }).click(); await page.waitForTimeout(400); expect(downloads).toEqual([]);
  112 |   await expect(page.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  113 |   await page.getByRole('button', { name: '关闭白板' }).click(); expect(downloads).toEqual([]);
  114 | });
  115 | 
```