# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> uncached original topic cannot disappear on a scope change until its complete input is downloaded
- Location: tests\e2e\topic-whiteboard.spec.ts:129:5

# Error details

```
Error: apiResponse.json: Response has been disposed
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - link "Home" [ref=f1e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f1e13]: 首页
        - link "Courses" [ref=f1e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f1e17]: 课程
        - link "Calendar" [ref=f1e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f1e21]: 学习动态
        - link "History" [ref=f1e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f1e25]: 历史
        - link "Materials" [ref=f1e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e29]: 资料
        - link "AI Whiteboards" [ref=f1e30] [cursor=pointer]:
          - /url: /studio/whiteboards
          - generic [ref=f1e33]: AI白板
      - generic [ref=f1e34]:
        - heading "继续学习" [level=2] [ref=f1e35]
        - link "讲座社会学想象力 社会学概论" [ref=f1e36] [cursor=pointer]:
          - /url: /studio/classroom
          - text: 讲座社会学想象力
          - generic [ref=f1e37]: 社会学概论
      - generic [ref=f1e38]:
        - heading "近期活动" [level=2] [ref=f1e39]
        - paragraph [ref=f1e40]: 开始学习后，活动会出现在这里。
      - link "返回学习首页 →" [ref=f1e42] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f1e43]:
      - generic [ref=f1e44]:
        - generic [ref=f1e45]:
          - text: WHITEBOARD STUDIO
          - heading "从一个问题开始，讲清每一步。" [level=1] [ref=f1e46]
          - paragraph [ref=f1e47]: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
        - link "返回学习工作台 →" [ref=f1e48] [cursor=pointer]:
          - /url: /studio
      - generic [ref=f1e49]:
        - complementary [ref=f1e50]:
          - generic [ref=f1e51]:
            - text: NEW BOARD
            - heading "这次想弄懂什么？" [level=2] [ref=f1e52]
          - generic [ref=f1e53]:
            - text: 学习对象
            - combobox "白板学习对象" [ref=f1e54]:
              - option "我自己 · 成人主题"
              - option "匿名AI白板学习者 · 5年级" [selected]
          - generic [ref=f1e55]:
            - text: 学科
            - combobox "学科" [ref=f1e56]:
              - option "数学" [selected]
              - option "语文"
              - option "英语"
          - region "新建AI白板" [ref=f1e57]:
            - group [ref=f1e58]:
              - generic [ref=f1e59]:
                - text: 讲解主题
                - textbox "讲解主题" [ref=f1e60]:
                  - /placeholder: 例如：为什么先统一单位，才能比较和合并？
              - generic [ref=f1e61]:
                - text: 希望弄懂什么
                - textbox "希望弄懂什么" [ref=f1e62]:
                  - /placeholder: 想理解的区别、步骤，或一个具体困惑
              - group "明确选择这次要讲的知识点（最多6个）" [ref=f1e63]:
                - paragraph [ref=f1e65]: 尚未取得当前已确认知识点。请先确认学习范围。
              - generic [ref=f1e67]:
                - generic [ref=f1e68]: 模型
                - combobox "选择大模型" [ref=f1e69] [cursor=pointer]:
                  - option "Auto · 当前默认模型"
                  - option "GPT-6.1 Sol"
                  - option "GPT-6 Astra"
                  - option "GPT-6 Luna"
                  - option "Grok-4.7"
                  - option "GLM-5.3 Flash"
                  - option "DeepSeek V4.1 Flash · 默认" [selected]
                  - option "Claude Opus 5.5"
                  - option "Claude Sonnet 5"
                  - option "GPT-6 Sol"
                  - option "GPT-5.6 Sol"
                  - option "GPT-5.6 Terra"
                  - option "GPT-5.6 Luna"
                  - option "GPT-5.5"
                  - option "Grok-4.6"
                  - option "GLM-5.2"
                  - option "GLM-5.3"
                  - option "Claude Opus 5"
                  - option "Claude Fable 5.1"
                  - option "MiMo V2.6 Pro"
                  - option "MiMo V2.6 Flash"
                  - option "MiMo V2.6 Pro Ultraspeed"
                  - option "Qwen3.8 Max"
            - alert [ref=f1e70]: 本机存储暂不可用，请下载原主题和请求后再离开。
            - generic [ref=f1e71]:
              - button "预检主题与范围" [ref=f1e72] [cursor=pointer]
              - button "生成教学稿" [disabled] [ref=f1e73]
            - button "下载原主题与请求" [ref=f1e74] [cursor=pointer]
            - group [ref=f1e75]:
              - generic "查看其他本机主题" [ref=f1e76] [cursor=pointer]
        - region "白板工作区" [ref=f1e77]:
          - generic [ref=f1e78]:
            - generic [aria-hidden] [ref=f1e79]:
              - text: Aa
              - generic [ref=f1e80]: ＋
              - text: ∑
            - heading "让知识有条理地展开。" [level=2] [ref=f1e81]
            - paragraph [ref=f1e82]: 概念、步骤、对照表与公式，保留完整讲稿。生成后你可以修改和核对，再开始逐句播放。
            - generic [ref=f1e83]: 成人主题无需建立孩子档案。孩子白板只使用明确选择的已学知识点。
        - complementary "白板与候选历史" [ref=f1e84]:
          - generic [ref=f1e85]:
            - heading "我的白板" [level=2] [ref=f1e86]
            - button "＋ 新白板" [ref=f1e87] [cursor=pointer]
          - generic [ref=f1e88]:
            - button "教学草稿" [pressed] [ref=f1e89] [cursor=pointer]
            - button "已保存" [ref=f1e90] [cursor=pointer]
          - generic [ref=f1e91]:
            - generic [ref=f1e92]: 搜索我的白板
            - textbox "搜索我的白板" [ref=f1e93]:
              - /placeholder: 搜索主题或标题
          - paragraph [ref=f1e94]: 这里还没有匹配的白板。
          - generic [ref=f1e95]:
            - button "上一页" [disabled] [ref=f1e96]
            - generic [ref=f1e97]: 1 / 1
            - button "下一页" [disabled] [ref=f1e98]
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { createHash, randomUUID } from 'node:crypto';
  3   | import { readFileSync } from 'node:fs';
  4   | import { browserEvidence } from './evidence';
  5   | import { join } from 'node:path';
  6   | 
  7   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107'), base = '/learning/studio/topic-whiteboards';
  8   | async function fixture(page: Page, child = false) {
  9   |   const hash = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + hash[0] + '.' + hash[1];
  10  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  11  |   const principal = 'topic-browser-' + randomUUID() + '@local.test', credential = 'Topic-Browser-Only-20261026';
  12  |   let token = '';
  13  |   async function call(path: string, body?: unknown, method = 'POST') {
  14  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) },
  15  |       ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  16  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
  17  |   }
  18  |   const actor = await call('/auth/register', { principal, credential }); token = actor.token;
  19  |   let studentId: string | null = null;
  20  |   if (child) {
  21  |     const created = await call('/students', { nickname: '匿名AI白板学习者', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }); studentId = created.profile.id;
  22  |     await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null,
  23  |       textbookVersion: '匿名已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  24  |   }
  25  |   await page.route('**/api/learning/studio/overview?*', async route => {
  26  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
> 27  |     const payload = await response.json(); payload.data.narrationAvailable = true; payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [{ id: 'fixture-a', label: '合成音轨 A' }] };
      |                                    ^ Error: apiResponse.json: Response has been disposed
  28  |     await route.fulfill({ response, json: payload });
  29  |   });
  30  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  31  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  32  |   await page.goto('/studio/whiteboards'); await expect(page.getByLabel('讲解主题')).toBeVisible();
  33  |   await expect(page.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');
  34  |   return { actor, call, studentId };
  35  | }
  36  | async function generate(page: Page, topic = '用匿名观察解释条件与推断') {
  37  |   await page.getByLabel('讲解主题').fill(topic); await page.getByLabel('希望弄懂什么').fill('保留完整条件，说明观察、推断和替代解释的区别。');
  38  |   await page.getByRole('button', { name: '预检主题与范围', exact: true }).click(); await expect(page.getByRole('button', { name: '生成教学稿', exact: true })).toBeEnabled();
  39  |   await page.getByRole('button', { name: '生成教学稿', exact: true }).click();
  40  | }
  41  | async function ready(page: Page) { await expect(page.locator('.tw-generation-state')).toHaveText('待你核对', { timeout: 25000 }); await expect(page.getByLabel('白板标题')).toBeVisible(); }
  42  | 
  43  | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  44  |   const f = await fixture(page); let dropped = true;
  45  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  46  |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  47  |   });
  48  |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  49  |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  50  |   const id = new URL(page.url()).searchParams.get('draft')!;
  51  |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  52  |   let editDropped = true, editWrites = 0;
  53  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  54  |     editWrites++;
  55  |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  56  |   });
  57  |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  58  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  59  |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  60  |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  61  |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  62  |   expect(editWrites).toBe(1);
  63  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  64  |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  65  |   let confirmationDropped = true, confirmationWrites = 0;
  66  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  67  |     confirmationWrites++;
  68  |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  69  |   });
  70  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  71  |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
  72  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  73  |   expect(confirmationWrites).toBe(1);
  74  |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
  75  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
  76  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  77  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  78  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  79  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  80  | });
  81  | 
  82  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  83  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  84  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  85  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  86  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  87  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  88  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  89  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  90  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  91  | });
  92  | 
  93  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  94  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  95  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  96  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  97  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  98  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  99  |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  100 |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  101 |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  102 | });
  103 | 
  104 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  105 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  106 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  107 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  108 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  109 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  110 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  111 | });
  112 | 
  113 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  114 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  115 |   try {
  116 |     await second.goto(href); await ready(second);
  117 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  118 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  119 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  120 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  121 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
  122 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  123 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  124 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  125 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  126 |   } finally { await second.close(); }
  127 | });
```