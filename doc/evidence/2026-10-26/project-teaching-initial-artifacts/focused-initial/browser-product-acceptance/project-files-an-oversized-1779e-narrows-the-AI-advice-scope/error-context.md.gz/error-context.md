# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: project-files.spec.ts >> an oversized saved project keeps its full text while the learner explicitly narrows the AI advice scope
- Location: tests\e2e\project-files.spec.ts:44:5

# Error details

```
TimeoutError: page.waitForRequest: Timeout 15000ms exceeded while waiting for event "request"
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - generic [ref=f1e4]:
      - link "‹ 返回课程" [ref=f1e5] [cursor=pointer]:
        - /url: /studio/classroom?unit=3
      - generic [ref=f1e6]: LEARNING STUDIO / PROJECT
      - button "导出项目" [ref=f1e7] [cursor=pointer]
    - generic [ref=f1e8]:
      - complementary [ref=f1e9]:
        - text: COURSE PROJECT
        - heading "制度影响分析" [level=1] [ref=f1e10]
        - paragraph [ref=f1e11]: 选择一个制度，分析它怎样支持或限制社区成员，并提出证据与可行改进。
        - generic [ref=f1e12]:
          - text: 分阶段完成作品
          - generic [ref=f1e13]: 0/3
        - navigation "项目阶段" [ref=f1e14]:
          - button "01 追踪制度中的具体过程 草稿已保存" [ref=f1e15] [cursor=pointer]:
            - generic [ref=f1e16]: "01"
            - generic [ref=f1e17]:
              - text: 追踪制度中的具体过程
              - generic [ref=f1e18]: 草稿已保存
          - button "02 比较支持与限制 等待开始" [ref=f1e19] [cursor=pointer]:
            - generic [ref=f1e20]: "02"
            - generic [ref=f1e21]:
              - text: 比较支持与限制
              - generic [ref=f1e22]: 等待开始
          - button "03 提出可核查的改进 等待开始" [ref=f1e23] [cursor=pointer]:
            - generic [ref=f1e24]: "03"
            - generic [ref=f1e25]:
              - text: 提出可核查的改进
              - generic [ref=f1e26]: 等待开始
        - paragraph [ref=f1e27]: 提交与自评记录本次作品。AI 建议帮助修改，知识掌握仍需独立核查。
        - group [ref=f1e28]:
          - generic "项目版本与内容来源" [ref=f1e29] [cursor=pointer]
        - group [ref=f1e30]:
          - generic "可查看的项目记录" [ref=f1e31] [cursor=pointer]
      - generic [ref=f1e32]:
        - button "逐步学习这个项目 →" [ref=f1e33] [cursor=pointer]
        - alert [ref=f1e34]:
          - text: 这次操作没有确认成功
          - paragraph [ref=f1e35]: 请先核对原操作或选择要继续的草稿版本。
          - button "读取已保存版本" [ref=f1e36] [cursor=pointer]
        - region "项目原操作恢复" [ref=f1e37]:
          - heading "原操作未获确认，副本仍保留" [level=3] [ref=f1e38]
          - paragraph [ref=f1e39]: 追踪制度中的具体过程 · 请求建议。先读取原结果，再决定下一步。
          - button "读取并恢复原操作" [ref=f1e40] [cursor=pointer]
          - button "下载原操作与草稿副本" [ref=f1e41] [cursor=pointer]
          - button "下载副本并继续编辑" [ref=f1e42] [cursor=pointer]
        - generic [ref=f1e43]:
          - generic [ref=f1e44]:
            - generic [ref=f1e45]: STAGE 1 / 3
            - heading "追踪制度中的具体过程" [level=2] [ref=f1e46]
            - paragraph [ref=f1e47]: 选择家庭、教育、工作等制度中的一项流程。
          - status [ref=f1e48]: 已保存至服务器
        - group "阶段产物" [ref=f1e49]:
          - generic [ref=f1e51]:
            - generic [ref=f1e52]: 制度与过程链条
            - generic [ref=f1e53]: 谁提出要求、谁能进入、资源如何分配、产生什么结果？
            - textbox "制度与过程链条" [ref=f1e54]: first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence first saved evidence
          - generic [ref=f1e55]:
            - generic [ref=f1e56]: 过程证据与前期联系
            - generic [ref=f1e57]: 使用此前观察或地图，指出每个环节的依据和缺口。
            - textbox "过程证据与前期联系" [ref=f1e58]: second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence second saved evidence
        - generic [ref=f1e59]:
          - region "项目文件附件" [ref=f1e60]:
            - generic [ref=f1e61]:
              - generic [ref=f1e62]:
                - text: FILES & ARTIFACTS
                - heading "保留作品的真实文件" [level=3] [ref=f1e63]
              - button "＋ 添加文件" [ref=f1e64] [cursor=pointer]
            - paragraph [ref=f1e65]: 图片、PDF、UTF-8文字/代码、录音与Office原件，每份最多20MiB。文件就绪后，选择加入当前阶段，再保存或提交。
            - button "选择项目文件" [ref=f1e66]
            - generic [ref=f1e67]: 将一份文件拖到这里，或使用“添加文件”选择。
            - generic [ref=f1e68]: 还没有项目文件。文字草稿可以随时保存。
          - region "项目证据" [ref=f1e69]:
            - generic [ref=f1e70]:
              - generic [ref=f1e71]:
                - text: EVIDENCE
                - heading "保留可以核查的依据" [level=3] [ref=f1e72]
              - button "＋ 添加证据" [ref=f1e73] [cursor=pointer]
            - paragraph [ref=f1e74]: 记录匿名观察、资料摘录或来源链接。链接用于引用，平台不会自动读取。
            - generic [ref=f1e75]: 还没有证据记录。可以先写草稿，再补充依据。
        - group [ref=f1e77]:
          - generic "RUBRIC 按量规检查自己的作品" [ref=f1e78] [cursor=pointer]
        - region "项目 AI 建议" [ref=f1e80]:
          - generic [ref=f1e82]:
            - text: AI FEEDBACK
            - heading "让助教帮你寻找证据缺口" [level=3] [ref=f1e83]
          - paragraph [ref=f1e84]: 建议针对已保存的阶段草稿，不替代你的判断和人工复核。
          - generic [ref=f1e85]:
            - generic [ref=f1e86]:
              - generic [ref=f1e87]: 模型
              - combobox "选择大模型" [ref=f1e88] [cursor=pointer]:
                - option "Auto · 当前默认模型"
                - option "GPT-6.1 Sol"
                - option "GPT-6 Astra"
                - option "GPT-6 Luna"
                - option "Grok-4.7"
                - option "GLM-5.3 Flash"
                - option "DeepSeek V4.1 Flash · 默认" [selected]
                - option "Claude Opus 5.5"
                - option "Claude Sonnet 5"
                - option "GPT-6 Sol"
                - option "GPT-5.6 Sol"
                - option "GPT-5.6 Terra"
                - option "GPT-5.6 Luna"
                - option "GPT-5.5"
                - option "Grok-4.6"
                - option "GLM-5.2"
                - option "GLM-5.3"
                - option "Claude Opus 5"
                - option "Claude Fable 5.1"
                - option "MiMo V2.6 Pro"
                - option "MiMo V2.6 Flash"
                - option "MiMo V2.6 Pro Ultraspeed"
                - option "Qwen3.8 Max"
            - paragraph [ref=f1e89]:
              - generic [ref=f1e90]: DeepSeek V4.1 Flash
              - generic [ref=f1e91]: DeepSeek V4 Flash
          - generic [ref=f1e92]:
            - paragraph [ref=f1e93]: 本次只分析已保存文字、证据和文件说明，尚未读取附件内容。
            - group [ref=f1e94]:
              - generic "选择建议范围" [ref=f1e95] [cursor=pointer]
              - group [ref=f1e96]:
                - generic [ref=f1e97]:
                  - checkbox "只分析我勾选的内容" [checked] [ref=f1e98]
                  - text: 只分析我勾选的内容
                - generic [ref=f1e99]:
                  - generic [ref=f1e100]:
                    - checkbox "制度与过程链条" [checked] [ref=f1e101]
                    - text: 制度与过程链条
                  - generic [ref=f1e102]:
                    - checkbox "过程证据与前期联系" [ref=f1e103]
                    - text: 过程证据与前期联系
            - button "分析已保存草稿" [active] [ref=f1e104] [cursor=pointer]
        - region "阶段提交历史" [ref=f1e105]:
          - generic [ref=f1e107]:
            - text: VERSIONS
            - heading "每次提交都有迹可循" [level=3] [ref=f1e108]
          - paragraph [ref=f1e109]: 尚未提交这一阶段。可以先保存未完成草稿。
        - generic [ref=f1e110]:
          - button "保存阶段草稿" [ref=f1e111] [cursor=pointer]
          - button "提交这个阶段 →" [ref=f1e112] [cursor=pointer]
      - complementary [ref=f1e113]:
        - text: PROJECT NOTEBOOK
        - heading "把学习连起来" [level=2] [ref=f1e114]
        - paragraph [ref=f1e115]: 参考此前提交的产物，说明它与当前问题的联系。
        - group [ref=f1e116]:
          - generic "01 研究问题与方法设计" [ref=f1e117] [cursor=pointer]:
            - generic [ref=f1e118]: "01"
            - text: 研究问题与方法设计
        - group [ref=f1e119]:
          - generic "02 文化与互动观察笔记" [ref=f1e120] [cursor=pointer]:
            - generic [ref=f1e121]: "02"
            - text: 文化与互动观察笔记
        - group [ref=f1e122]:
          - generic "03 社区资源与障碍地图" [ref=f1e123] [cursor=pointer]:
            - generic [ref=f1e124]: "03"
            - text: 社区资源与障碍地图
        - group [ref=f1e125]:
          - generic "04 制度影响分析" [ref=f1e126] [cursor=pointer]:
            - generic [ref=f1e127]: "04"
            - text: 制度影响分析
        - group [ref=f1e128]:
          - generic "05 变革提案与最终报告" [ref=f1e129] [cursor=pointer]:
            - generic [ref=f1e130]: "05"
            - text: 变革提案与最终报告
        - paragraph [ref=f1e131]: 只记录匿名情境；不上传真实姓名、联系方式或未经同意的个人资料。
```

# Test source

```ts
  1  | import {expect,test,type Page} from '@playwright/test';
  2  | import {mkdirSync,readFileSync} from 'node:fs';
  3  | import {createHash} from 'node:crypto';
  4  | import sharp from 'sharp';
  5  | import {execFileSync} from 'node:child_process';
  6  | import {resolve} from 'node:path';
  7  | const api=`http://localhost:${process.env.E2E_API_PORT??'4107'}/api`;
  8  | let registrationAddress=0;
  9  | async function login(page:Page){const suffix=Date.now()+'-'+Math.floor(Math.random()*100000),principal='files-'+suffix+'@local.test',credential='Files-only-'+suffix;const response=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json','X-Forwarded-For':'198.19.11.'+(++registrationAddress)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);return actor;}
  10 | async function start(page:Page,unit='soc-u1'){await page.goto('/studio/projects?unitId='+unit);await page.getByRole('button',{name:'开始这个项目 →'}).click();await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.getByLabel('项目文件附件',{exact:true})).toBeVisible();}
  11 | async function upload(page:Page,name:string,buffer:Buffer,mimeType='text/plain'){await page.getByLabel('选择项目文件',{exact:true}).setInputFiles({name,mimeType,buffer});const card=page.locator('.pj-file-card').filter({has:page.getByText(name,{exact:true})});await expect(card).toContainText('文件已就绪',{timeout:30000});return card;}
  12 | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  13 | test('actual file versions remain frozen through submission, download, nested preview, editing and responsive layouts',async({page})=>{
  14 |   test.setTimeout(120000);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await login(page);await start(page);
  15 |   const first=Buffer.from('original evidence: 12 divided by 3 = 4\n<script>unsafe()</script>'),card=await upload(page,'evidence-v1.txt',first);await card.getByRole('button',{name:'加入阶段作品'}).click();await card.getByLabel('文件说明').fill('第一次提交的完整原件');
  16 |   for(const field of await page.locator('.pj-artifact textarea').all())await field.fill('说明条件，保留自己的观察和核查方法。');
  17 |   const reflection=page.locator('.pj-reflection');await reflection.locator('summary').click();for(const field of await reflection.locator('.pj-ratings fieldset').all()){await field.getByRole('radio').nth(1).check();await field.getByRole('textbox').fill('文件中的原始记录支持当前解释。');await field.getByRole('checkbox').check();}
  18 |   await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.locator('.pj-notice')).toContainText('提交快照');
  19 |   await page.locator('.pj-history-row').click();const history=page.getByRole('dialog',{name:'项目提交版本'});await history.getByRole('button',{name:'查看本次提交文件'}).click();const preview=page.getByRole('dialog',{name:'项目文件预览'});await expect(preview.locator('pre')).toHaveText(first.toString());expect(await page.evaluate(()=>typeof (window as any).unsafe)).toBe('undefined');
  20 |   const download=page.waitForEvent('download');await preview.getByRole('button',{name:'下载原件',exact:true}).click();const received=await download;expect(received.suggestedFilename()).toBe('evidence-v1.txt');expect(createHash('sha256').update(readFileSync((await received.path())!)).digest('hex')).toBe(createHash('sha256').update(first).digest('hex'));
  21 |   await page.keyboard.press('Escape');await expect(preview).toHaveCount(0);await expect(history).toBeVisible();await expect(history.getByRole('button',{name:'查看本次提交文件'})).toBeFocused();await history.getByRole('button',{name:'关闭提交版本'}).click();
  22 |   await card.getByRole('button',{name:'从本次草稿移除'}).click();const second=await upload(page,'evidence-v2.txt',Buffer.from('revised evidence with a counterexample'));await second.getByRole('button',{name:'加入阶段作品'}).click();
  23 |   await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.locator('.pj-notice')).toContainText('已保存');await page.reload();await page.locator('.pj-history-row').click();await history.getByRole('button',{name:'查看本次提交文件'}).click();await expect(preview.locator('pre')).toHaveText(first.toString());await page.keyboard.press('Escape');await history.getByRole('button',{name:'关闭提交版本'}).click();
  24 |   mkdirSync('data/qa/project-files',{recursive:true});for(const width of [1440,768,390]){await page.setViewportSize({width,height:960});await page.locator('.pj-files').scrollIntoViewIfNeeded();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await page.screenshot({path:'data/qa/project-files/files-'+width+'.png',fullPage:true});await page.locator('.pj-files').screenshot({path:'data/qa/project-files/files-section-'+width+'.png'});}
  25 |   expect(errors).toEqual([]);
  26 | });
  27 | test('a dropped second chunk resumes the exact selected image after refresh and lost complete acknowledgments do not duplicate it',async({page})=>{
  28 |   test.setTimeout(120000);await login(page);await start(page,'soc-u2');const pixels=Buffer.alloc(800*800*3);for(let index=0;index<pixels.length;index++)pixels[index]=(index*73+Math.floor(index/17)*41)%256;
  29 |   // Noise bytes make a real decodable file exceed a chunk, with a deterministic seed.
  30 |   let seed=19;for(let index=0;index<pixels.length;index++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;pixels[index]=seed>>>24;}
  31 |   const image=await sharp(pixels,{raw:{width:800,height:800,channels:3}}).png().toBuffer();expect(image.length).toBeGreaterThan(1024*1024);
  32 |   let failed=false;await page.route('**/api/learning/project-files/uploads/*/chunks/1',async route=>{if(!failed){failed=true;await route.abort('failed');}else await route.continue();});
  33 |   await page.getByLabel('选择项目文件',{exact:true}).setInputFiles({name:'anonymous.png',mimeType:'image/png',buffer:image});await expect(page.locator('.pj-files [role="alert"]')).toContainText('暂时无法连接');await page.reload();await expect(page.locator('.pj-files')).toContainText('已保存 1/2 块');
  34 |   let dropped=false;await page.route('**/api/learning/project-files/uploads/*/complete',async route=>{if(!dropped){dropped=true;const response=await route.fetch();expect(response.status()).toBe(201);await route.abort('failed');}else await route.continue();});
  35 |   const chooser=page.waitForEvent('filechooser');await page.getByRole('button',{name:'选择同一文件续传'}).click();await(await chooser).setFiles({name:'anonymous.png',mimeType:'image/png',buffer:image});await expect(page.locator('.pj-files [role="alert"]')).toContainText('暂时无法连接');await page.reload();const card=page.locator('.pj-file-card').filter({has:page.getByText('anonymous.png',{exact:true})});await expect(card).toContainText('文件已就绪',{timeout:30000});await expect(page.locator('.pj-file-card')).toHaveCount(1);await card.getByRole('button',{name:'查看文件'}).click();const preview=page.getByRole('dialog',{name:'项目文件预览'});await expect(preview.locator('img')).toBeVisible();await page.keyboard.press('Escape');await expect(card.getByRole('button',{name:'查看文件'})).toBeFocused();
  36 | });
  37 | test('real PDF previews turn individual pages and closing a playing recording releases its actual audio element',async({page})=>{
  38 |   test.setTimeout(120000);await login(page);await start(page,'soc-u3');const directory=resolve('data/qa/project-files');mkdirSync(directory,{recursive:true});const pdf=resolve(directory,'anonymous-two-pages.pdf');
  39 |   execFileSync(process.env.STUDY_PYTHON??(process.platform==='win32'?'python':'python3'),['-X','utf8','-c','import fitz,sys\nd=fitz.open()\nfor label in ["First synthetic project page","Second synthetic project page"]:\n p=d.new_page();p.insert_text((40,70),label)\nd.save(sys.argv[1]);d.close()',pdf],{windowsHide:true,timeout:30000});
  40 |   const document=await upload(page,'anonymous-two-pages.pdf',readFileSync(pdf),'application/pdf');await document.getByRole('button',{name:'查看文件'}).click();const preview=page.getByRole('dialog',{name:'项目文件预览'});await expect(preview.getByRole('navigation',{name:'PDF页码'})).toContainText('第1页 / 2页');await expect(preview.locator('img')).toBeVisible();const original=await preview.locator('img').getAttribute('src');await preview.getByRole('button',{name:'下一页',exact:true}).click();await expect(preview.getByRole('navigation',{name:'PDF页码'})).toContainText('第2页 / 2页');await expect(preview.locator('img')).toBeVisible();await expect(preview.locator('img')).not.toHaveAttribute('src',original!);await expect(preview.getByRole('button',{name:'下一页',exact:true})).toBeDisabled();await page.keyboard.press('Escape');
  41 |   const pcm=Buffer.alloc(32000),wav=Buffer.alloc(44+pcm.length);wav.write('RIFF',0);wav.writeUInt32LE(wav.length-8,4);wav.write('WAVEfmt ',8);wav.writeUInt32LE(16,16);wav.writeUInt16LE(1,20);wav.writeUInt16LE(1,22);wav.writeUInt32LE(16000,24);wav.writeUInt32LE(32000,28);wav.writeUInt16LE(2,32);wav.writeUInt16LE(16,34);wav.write('data',36);wav.writeUInt32LE(pcm.length,40);pcm.copy(wav,44);
  42 |   const recording=await upload(page,'anonymous.wav',wav,'audio/wav');await recording.getByRole('button',{name:'查看文件'}).click();await expect(preview.locator('audio')).toBeVisible();const player=await preview.locator('audio').elementHandle();await expect.poll(()=>player!.evaluate(element=>(element as HTMLAudioElement).readyState)).toBeGreaterThanOrEqual(1);await player!.evaluate(element=>{const audio=element as HTMLAudioElement;audio.muted=true;return audio.play();});await expect.poll(()=>player!.evaluate(element=>(element as HTMLAudioElement).currentTime)).toBeGreaterThan(0);await page.keyboard.press('Escape');expect(await player!.evaluate(element=>({paused:(element as HTMLAudioElement).paused,source:element.getAttribute('src')}))).toEqual({paused:true,source:null});
  43 | });
  44 | test('an oversized saved project keeps its full text while the learner explicitly narrows the AI advice scope',async({page})=>{
  45 |   await login(page);await start(page,'soc-u4');const fields=page.locator('.pj-artifact textarea'),first='first saved evidence '.repeat(500),second='second saved evidence '.repeat(500);await fields.nth(0).fill(first);await fields.nth(1).fill(second);await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.locator('.pj-notice')).toContainText('已保存');const assistant=page.getByLabel('项目 AI 建议',{exact:true});
  46 |   await assistant.getByRole('button',{name:'分析已保存草稿'}).click();await expect(page.locator('main .pj-error').last()).toContainText('选择建议范围');await expect(fields.nth(0)).toHaveValue(first);await expect(fields.nth(1)).toHaveValue(second);
  47 |   await assistant.getByText('选择建议范围',{exact:true}).click();await assistant.getByLabel('只分析我勾选的内容').check();const selected=assistant.locator('.pj-advice-scope fieldset input[type=checkbox]');await expect(selected).toHaveCount(3);await selected.nth(2).uncheck();
> 48 |   const sent=page.waitForRequest(request=>request.method()==='POST'&&/\/learning\/projects\/[^/]+\/advice$/.test(request.url()));await assistant.getByRole('button',{name:'分析已保存草稿'}).click();const command=(await sent).postDataJSON();expect(command.scope.fieldIds).toHaveLength(1);expect(command.scope.evidenceIds).toEqual([]);expect(command.scope.attachmentIds).toEqual([]);await expect(page.locator('.pj-save-state')).toContainText('已保存');await expect(fields.nth(0)).toHaveValue(first);await expect(fields.nth(1)).toHaveValue(second);
     |                   ^ TimeoutError: page.waitForRequest: Timeout 15000ms exceeded while waiting for event "request"
  49 | });
  50 | 
```