import { test,expect,type Page } from '@playwright/test';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { browserEvidence } from './evidence';
const api='http://localhost:'+(process.env.E2E_API_PORT??'4107')+'/api',evidence=browserEvidence('project-teaching'),manifest=JSON.parse(readFileSync('apps/web/public/classroom-voice-samples/manifest.json','utf8'));let address=0;
async function enter(page:Page){
  page.on('dialog',dialog=>void dialog.accept());const suffix=crypto.randomUUID(),principal='guided-project-'+suffix+'@local.test',credential='Guided-QA-'+suffix;
  const response=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json','X-Forwarded-For':'198.18.15.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  await page.goto('/studio/projects?unitId=soc-u1');await page.getByRole('button',{name:'开始这个项目 →',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('STEP 1 OF 5');
  const id=new URL(page.url()).searchParams.get('project')!;
  async function current(){const r=await fetch(api+'/learning/projects/'+id,{headers:{authorization:'Bearer '+actor.token}});expect(r.status).toBe(200);return(await r.json()).data;}
  return{actor,id,current};
}
test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});

test('guided original fields save before moving, keep the full work and submit one frozen stage',async({page})=>{
  const f=await enter(page);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByLabel('匿名情境与已知观察')).toBeVisible();
  await page.getByRole('button',{name:'下一步 ›',exact:true}).click();const confirm=page.getByRole('dialog',{name:'当前步骤尚未完成'});await expect(confirm).toBeVisible();await confirm.getByRole('button',{name:'留在这一步'}).click();
  await page.getByLabel('匿名情境与已知观察').fill('匿名图书馆观察：两次排队的规则不同，事实和解释分开。');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();
  await page.getByLabel('可以研究的问题').fill('比较两个时间段的排队规则，核查资源与进入条件。');await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('整理证据与附件');
  await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('自评与提交');
  const criteria=page.locator('.pj-reflection .pj-ratings fieldset');for(let i=0;i<await criteria.count();i++){await criteria.nth(i).locator('.pj-levels label').nth(1).click();await criteria.nth(i).locator('textarea').fill('依据是当前匿名观察，仍需在新条件下验证。');}
  await page.getByRole('button',{name:'提交这个阶段 →',exact:true}).click();await expect(page.getByRole('button',{name:/已提交 1\/3/})).toContainText('人工复核 0/3');
  const saved=await f.current();expect(saved.submissions).toHaveLength(1);expect(saved.reviews).toHaveLength(0);await page.getByRole('button',{name:'完整作品',exact:true}).click();await expect(page.getByLabel('匿名情境与已知观察')).toHaveValue(/图书馆/);await expect(page.getByLabel('可以研究的问题')).toHaveValue(/两个时间段/);
  await page.getByRole('button',{name:'逐步学习这个项目 →',exact:true}).click();await page.reload();await expect(page.getByRole('region',{name:'当前项目步骤'})).toContainText('STEP 5 OF 5');expect((await f.current()).submissions).toHaveLength(1);
});

test('an unsaved local field survives reload and a different tab requires an explicit comparison before saving',async({page,context})=>{
  const f=await enter(page);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByLabel('匿名情境与已知观察').fill('本机尚未保存的完整观察');await page.reload();await expect(page.getByLabel('匿名情境与已知观察')).toHaveValue('本机尚未保存的完整观察');
  const other=await context.newPage();other.on('dialog',dialog=>void dialog.accept());await other.goto(page.url());await other.getByLabel('匿名情境与已知观察').fill('另一个页面明确保存的新观察');await other.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(other.getByText('草稿和自评准备已保存。',{exact:true})).toBeVisible();
  // Restore the first tab's own buffer after the other tab's shared local-storage write.
  await page.getByLabel('匿名情境与已知观察').fill('本机保留的完整观察与新补充');await page.reload();const comparison=page.getByRole('region',{name:'项目草稿版本对照'});await expect(comparison).toBeVisible();await expect(comparison.getByRole('region',{name:'本机项目稿'})).toContainText('本机保留的完整观察与新补充');await expect(comparison.getByRole('region',{name:'服务器项目稿'})).toContainText('另一个页面明确保存的新观察');
  const download=page.waitForEvent('download');await page.getByRole('button',{name:'下载副本并继续本机稿',exact:true}).click();expect((await download).suggestedFilename()).toContain('草稿');await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.getByText('草稿和自评准备已保存。',{exact:true})).toBeVisible();expect((await f.current()).drafts.question.values.scene).toBe('本机保留的完整观察与新补充');await other.close();
});

test('a lost save reply survives reload, reads the same actor receipt and preserves later local edits',async({page})=>{
  const f=await enter(page);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await page.getByLabel('匿名情境与已知观察').fill('第一次保存的原观察');
  await page.route('**/api/learning/projects/'+f.id,async route=>{if(route.request().method()!=='PATCH')return route.continue();await route.fetch();await route.abort('failed');});await page.route('**/api/learning/projects/'+f.id+'/requests/*',route=>route.abort('failed'));
  await page.getByRole('button',{name:'保存阶段草稿',exact:true}).click();await expect(page.getByRole('region',{name:'项目原操作恢复'})).toContainText('原操作仍待核对');await page.getByLabel('匿名情境与已知观察').fill('保存之后仍在本机继续编辑的内容');await page.reload();await expect(page.getByRole('region',{name:'项目原操作恢复'})).toBeVisible();
  await page.unroute('**/api/learning/projects/'+f.id);await page.unroute('**/api/learning/projects/'+f.id+'/requests/*');let writes=0;page.on('request',request=>{if(request.method()==='PATCH'&&request.url()===api+'/learning/projects/'+f.id)writes++;});
  await page.getByRole('button',{name:'读取并恢复原操作',exact:true}).click();await expect(page.getByRole('region',{name:'项目原操作恢复'})).toHaveCount(0);await expect(page.getByLabel('匿名情境与已知观察')).toHaveValue('保存之后仍在本机继续编辑的内容');expect(writes).toBe(0);expect((await f.current()).revision).toBe(1);
});

for(const width of [390,768,1440])test('project teaching, original fields and controls fit at '+width,async({page})=>{
  await page.setViewportSize({width,height:1000});await enter(page);await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByLabel('匿名情境与已知观察')).toBeVisible();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await expect(page.getByRole('button',{name:'下一步 ›',exact:true})).toBeInViewport();if(!process.env.CI)await page.screenshot({path:evidence+'/field-'+width+'.png',fullPage:true});
});

test('project audio decodes original samples, does not save progress and stops when the selected step changes',async({page})=>{
  await page.addInitScript(()=>{const NativeAudio=window.Audio;(window as any).__projectAudio=[];window.Audio=class extends NativeAudio{constructor(src?:string){super(src);(window as any).__projectAudio.push(this);}};});
  await page.route('**/api/learning/projects/*/teaching',async route=>{const response=await route.fetch(),body=await response.json();body.data.speech={available:true,provider:'minimax',defaultVoice:manifest.voices[0].voiceId,voices:manifest.voices.map((voice:any)=>({id:voice.voiceId,label:voice.providerName}))};await route.fulfill({response,json:body});});
  let command:any;await page.route('**/api/learning/projects/*/narration',async route=>{command=route.request().postDataJSON();await route.fulfill({contentType:'audio/mpeg',path:resolve('apps/web/public/classroom-voice-samples',manifest.voices[0].file)});});
  const f=await enter(page),before=await f.current();await page.getByRole('button',{name:'▷ 朗读本步骤',exact:true}).click();await expect.poll(()=>page.evaluate(()=>(window as any).__projectAudio.some((audio:HTMLAudioElement)=>!audio.paused))).toBe(true);expect(command).not.toHaveProperty('text');expect(command).toMatchObject({stageId:'question',stepId:'intro',sentenceIndex:0,version:'project-teaching-v1'});
  await page.getByRole('button',{name:'下一步 ›',exact:true}).click();await expect(page.getByLabel('匿名情境与已知观察')).toBeVisible();await expect.poll(()=>page.evaluate(()=>(window as any).__projectAudio.every((audio:HTMLAudioElement)=>audio.paused))).toBe(true);expect(await f.current()).toEqual(before);
});
