# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save
- Location: tests\e2e\topic-whiteboard.spec.ts:109:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.tw-conflict')
Expected substring: "服务器稿已变化"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('.tw-conflict') with timeout 15000ms
  - waiting for locator('.tw-conflict')

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent":
      - /url: /studio
    - navigation:
      - link "Home":
        - /url: /studio?view=home
        - text: 首页
      - link "Courses":
        - /url: /studio?view=courses
        - text: 课程
      - link "Calendar":
        - /url: /studio?view=calendar
        - text: 学习动态
      - link "History":
        - /url: /studio?view=history
        - text: 历史
      - link "Materials":
        - /url: /studio?view=materials
        - text: 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - heading "继续学习" [level=2]
    - link "讲座社会学想象力 社会学概论":
      - /url: /studio/classroom
    - heading "近期活动" [level=2]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页 →":
      - /url: /learn?subject=math
  - text: WHITEBOARD STUDIO
  - heading "从一个问题开始，讲清每一步。" [level=1]
  - paragraph: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
  - link "返回学习工作台 →":
    - /url: /studio
  - complementary:
    - text: NEW BOARD
    - heading "这次想弄懂什么？" [level=2]
    - text: 学习对象
    - combobox "白板学习对象":
      - option "我自己 · 成人主题" [selected]
    - region "新建AI白板":
      - group:
        - text: 讲解主题
        - textbox "讲解主题":
          - /placeholder: 例如：为什么先统一单位，才能比较和合并？
          - text: 用匿名观察解释条件与推断
        - text: 希望弄懂什么
        - textbox "希望弄懂什么":
          - /placeholder: 想理解的区别、步骤，或一个具体困惑
          - text: 保留完整条件，说明观察、推断和替代解释的区别。
        - text: 模型
        - combobox "选择大模型":
          - option "Auto · 当前默认模型"
      - button "预检主题与范围"
      - button "生成教学稿" [disabled]
      - button "下载原主题与请求"
  - region "白板工作区":
    - article:
      - text: 待你核对
      - heading "把条件讲清楚" [level=2]
      - paragraph: Browser fixture · not a real model · 本人成人主题
      - status: 待你核对
      - button "下载原稿与请求"
      - heading "AI 复核 · 未提出修改" [level=3]
      - paragraph: 这不是教师审核，也不代表孩子已掌握。
      - region "完整白板改稿":
        - heading "完整教学稿" [level=2]
        - paragraph: 有本机修改 · 本机草稿已保留
        - button "下载完整改稿"
        - status: 只能修改当前未确认候选，请先比较最新稿 本机全文仍保留。
        - group:
          - text: 白板标题
          - textbox "白板标题": 把条件讲清楚
          - text: 讲解概要
          - textbox "讲解概要": 本机持有的冲突原稿。
          - group:
            - text: 1. 先核对观察 这一幕的结构
            - combobox "这一幕的结构":
              - option "开场" [selected]
              - option "概念"
              - option "步骤"
              - option "自我检验"
            - text: 分幕标题
            - textbox "分幕标题": 先核对观察
            - text: 完整旁白
            - textbox "完整旁白": "[whiteboard-fixture] 先核对观察。 保留未知条件，不把一次观察当成完整能力证明。"
            - text: 板书正文
            - textbox "板书正文": 完整说明首行。完整说明尾行。
            - heading "完整要点" [level=3]
            - paragraph: 每条要点应逐字出现在本幕旁白中。
            - text: 要点 1
            - textbox "要点 1": 先核对观察
            - button "移除此要点"
            - button "添加要点"
            - text: 对照展示
            - combobox "对照展示":
              - option "文字讲解" [selected]
              - option "对照表"
              - option "公式"
          - group: 2. 再比较条件
          - group: 3. 最后保留反例
        - button "保存完整改稿"
      - group: 阅读AI最初原稿
      - button "查看完整修改历史"
      - paragraph: 保存后保持AI生成、待内容核对；不会写入能力或评测结果。
      - paragraph: 请先保存完整改稿，并比较服务器版本后再确认。
      - button "确认并保存这份白板" [disabled]
  - complementary "白板与候选历史":
    - heading "我的白板" [level=2]
    - button "＋ 新白板"
    - button "教学草稿" [pressed]
    - button "已保存"
    - text: 搜索我的白板
    - textbox "搜索我的白板":
      - /placeholder: 搜索主题或标题
    - button "待你核对 · 本人主题 把条件讲清楚 Browser fixture · not a real model"
    - button "上一页" [disabled]
    - text: 1 / 1
    - button "下一页" [disabled]
```

# Test source

```ts
  17  |   }
  18  |   const actor = await call('/auth/register', { principal, credential }); token = actor.token;
  19  |   let studentId: string | null = null;
  20  |   if (child) {
  21  |     const created = await call('/students', { nickname: '匿名AI白板学习者', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }); studentId = created.profile.id;
  22  |     await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null,
  23  |       textbookVersion: '匿名已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  24  |   }
  25  |   await page.route('**/api/learning/studio/overview?*', async route => {
  26  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
  27  |     const payload = await response.json(); payload.data.narrationAvailable = true; payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [{ id: 'fixture-a', label: '合成音轨 A' }] };
  28  |     await route.fulfill({ response, json: payload });
  29  |   });
  30  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  31  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  32  |   await page.goto('/studio/whiteboards'); await expect(page.getByLabel('讲解主题')).toBeVisible();
  33  |   await expect(page.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');
  34  |   return { actor, call, studentId };
  35  | }
  36  | async function generate(page: Page, topic = '用匿名观察解释条件与推断') {
  37  |   await page.getByLabel('讲解主题').fill(topic); await page.getByLabel('希望弄懂什么').fill('保留完整条件，说明观察、推断和替代解释的区别。');
  38  |   await page.getByRole('button', { name: '预检主题与范围', exact: true }).click(); await expect(page.getByRole('button', { name: '生成教学稿', exact: true })).toBeEnabled();
  39  |   await page.getByRole('button', { name: '生成教学稿', exact: true }).click();
  40  | }
  41  | async function ready(page: Page) { await expect(page.locator('.tw-generation-state')).toHaveText('待你核对', { timeout: 25000 }); await expect(page.getByLabel('白板标题')).toBeVisible(); }
  42  | 
  43  | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  44  |   const f = await fixture(page); let dropped = true;
  45  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  46  |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  47  |   });
  48  |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  49  |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  50  |   const id = new URL(page.url()).searchParams.get('draft')!;
  51  |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  52  |   let editDropped = true;
  53  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  54  |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  55  |   });
  56  |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  57  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  58  |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  59  |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  60  |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  61  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  62  |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  63  |   let confirmationDropped = true;
  64  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  65  |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  66  |   });
  67  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  68  |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
  69  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  70  |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
  71  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
  72  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  73  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  74  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  75  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  76  | });
  77  | 
  78  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  79  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  80  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  81  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  82  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  83  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  84  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  85  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  86  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  87  | });
  88  | 
  89  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  90  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  91  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  92  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  93  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  94  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  95  |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  96  |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  97  |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  98  | });
  99  | 
  100 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  101 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  102 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  103 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  104 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  105 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  106 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  107 | });
  108 | 
  109 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  110 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  111 |   try {
  112 |     await second.goto(href); await ready(second);
  113 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  114 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  115 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  116 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
> 117 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
      |                                                ^ Error: expect(locator).toContainText(expected) failed
  118 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  119 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  120 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  121 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  122 |   } finally { await second.close(); }
  123 | });
  124 | 
  125 | for (const width of [390, 768, 1440]) test('explicit child goals, adult separation and complete edit controls fit at ' + width, async ({ page }) => {
  126 |   const f = await fixture(page, true); await page.setViewportSize({ width, height: 1000 }); await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  127 |   await expect(page.locator('.tw-goals input')).toHaveCount(1); await page.locator('.tw-goals input').check(); await generate(page, '在相同整体下解释分数单位'); await ready(page);
  128 |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view.studentId).toBe(f.studentId); expect(view.audience.atomIds).toEqual(['core:math:fractionadd']);
  129 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  130 |   await page.evaluate(() => window.scrollTo(0, 0)); await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'child-editor-' + width + '.png'), fullPage: true });
  131 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  132 |   await expect(page.locator('.wb-current-sentence')).toContainText('先核对观察'); expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  133 |   await page.getByRole('button', { name: '关闭白板', exact: true }).click();
  134 | });
  135 | 
```