# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> topic-slot: two real tabs keep their own complete incomplete edits after either tab reloads
- Location: tests\e2e\topic-whiteboard.spec.ts:125:5

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  getByLabel('讲解概要')
Expected: "第一标签页尚未保存的完整稿。"
Received: "第二标签页的另一份完整稿。"
Timeout:  15000ms

Call log:
  - Expect "toHaveValue" getByLabel('讲解概要') with timeout 15000ms
  - waiting for getByLabel('讲解概要')
    33 × locator resolved to <textarea maxlength="600">第二标签页的另一份完整稿。</textarea>
       - unexpected value "第二标签页的另一份完整稿。"

```

```yaml
- textbox "讲解概要": 第二标签页的另一份完整稿。
```

# Test source

```ts
  33  |   await expect(page.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');
  34  |   return { actor, call, studentId };
  35  | }
  36  | async function generate(page: Page, topic = '用匿名观察解释条件与推断') {
  37  |   await page.getByLabel('讲解主题').fill(topic); await page.getByLabel('希望弄懂什么').fill('保留完整条件，说明观察、推断和替代解释的区别。');
  38  |   await page.getByRole('button', { name: '预检主题与范围', exact: true }).click(); await expect(page.getByRole('button', { name: '生成教学稿', exact: true })).toBeEnabled();
  39  |   await page.getByRole('button', { name: '生成教学稿', exact: true }).click();
  40  | }
  41  | async function ready(page: Page) { await expect(page.locator('.tw-generation-state')).toHaveText('待你核对', { timeout: 25000 }); await expect(page.getByLabel('白板标题')).toBeVisible(); }
  42  | 
  43  | test('adult original generation, lost edit and confirmation replies recover without duplicates and reach a complete table/formula player', async ({ page }) => {
  44  |   const f = await fixture(page); let dropped = true;
  45  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts', async route => {
  46  |     if (route.request().method() === 'POST' && dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  47  |   });
  48  |   await generate(page); await expect(page.getByRole('button', { name: '恢复原生成请求', exact: true })).toBeEnabled(); await page.reload();
  49  |   await page.getByRole('button', { name: '恢复原生成请求', exact: true }).click(); await ready(page);
  50  |   const id = new URL(page.url()).searchParams.get('draft')!;
  51  |   expect((await f.call(base + '/drafts', undefined, 'GET')).total).toBe(1);
  52  |   let editDropped = true;
  53  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/content', async route => {
  54  |     if (editDropped) { editDropped = false; expect((await route.fetch()).status()).toBe(200); await route.abort('failed'); } else await route.continue();
  55  |   });
  56  |   await page.getByLabel('讲解概要').fill('保留这段完整的本机修订说明。');
  57  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  58  |   await page.getByRole('button', { name: '保存完整改稿', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原修改请求', exact: true })).toBeEnabled();
  59  |   await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('保留这段完整的本机修订说明。');
  60  |   await page.getByRole('button', { name: '恢复原修改请求', exact: true }).click(); await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  61  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  62  |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  63  |   let confirmationDropped = true;
  64  |   await page.route('**/api/learning/studio/topic-whiteboards/drafts/*/confirm', async route => {
  65  |     if (confirmationDropped) { confirmationDropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  66  |   });
  67  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await expect(page.getByRole('button', { name: '恢复原确认请求', exact: true })).toBeEnabled();
  68  |   await page.reload(); await page.getByRole('button', { name: '恢复原确认请求', exact: true }).click();
  69  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  70  |   await expect(page.locator('.wb-ai-origin')).toContainText('AI生成');
  71  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(1).locator('summary').click(); await expect(page.getByRole('table')).toContainText('完整尾行条件');
  72  |   await page.getByLabel('完整讲稿与要点').locator('details').nth(2).locator(':scope > summary').click(); await expect(page.locator('math')).toBeVisible(); await expect(page.locator('.wb-complete-formula')).toContainText('计数单位相同');
  73  |   const view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view).toMatchObject({ status: 'confirmed', modelId: 'deepseek-v4-flash', studentId: null, subject: null });
  74  |   expect((await f.call(base, undefined, 'GET')).total).toBe(1);
  75  |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'adult-complete-player.png'), fullPage: true });
  76  | });
  77  | 
  78  | test('cancelled and failed review generations retain the original selected model through refresh and explicit retry', async ({ page }) => {
  79  |   const f = await fixture(page); await generate(page, '匿名观察 [topic-pause-once] [topic-review-fail-once]');
  80  |   await expect(page.getByRole('button', { name: '取消生成', exact: true })).toBeVisible(); await page.getByRole('button', { name: '取消生成', exact: true }).click();
  81  |   await expect(page.locator('.tw-generation-state')).toHaveText('已取消', { timeout: 15000 }); await page.reload();
  82  |   await page.getByLabel('选择大模型').selectOption('gpt-6-astra'); await page.getByRole('button', { name: '用原模型重试', exact: true }).click();
  83  |   await expect(page.locator('.tw-generation-state')).toHaveText('生成未完成', { timeout: 25000 });
  84  |   await page.getByRole('button', { name: '用原模型重试', exact: true }).click(); await ready(page);
  85  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  86  |   expect(view.modelId).toBe('deepseek-v4-flash'); expect(view.originalContent).not.toBeNull(); expect(view.generation).toBe(3);
  87  | });
  88  | 
  89  | test('incomplete local teaching edits survive reload and another saved draft cannot silently replace them', async ({ page }) => {
  90  |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('白板标题').fill('');
  91  |   await page.getByLabel('讲解概要').fill('尚未保存的完整说明，保留结尾空格。  ');
  92  |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.title))).toEqual(['']);
  93  |   await page.reload(); await ready(page); await expect(page.getByLabel('白板标题')).toHaveValue(''); await expect(page.getByLabel('讲解概要')).toHaveValue('尚未保存的完整说明，保留结尾空格。  ');
  94  |   await expect(page.getByRole('button', { name: '确认并保存这份白板', exact: true })).toBeDisabled();
  95  |   await page.getByLabel('白板标题').fill('补全后仍需核对'); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  96  |   await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存'); await page.getByRole('button', { name: '查看完整修改历史', exact: true }).click();
  97  |   await expect(page.locator('.tw-history')).toContainText('1个旧版本');
  98  | });
  99  | 
  100 | test('unavailable local storage keeps the full editable draft and requires a real downloaded copy before leaving', async ({ page }) => {
  101 |   await page.addInitScript(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) { if (key.startsWith('studyagent.topic-whiteboard')) throw new DOMException('Synthetic unavailable storage', 'QuotaExceededError'); return original.call(this, key, value); }; });
  102 |   await fixture(page); await generate(page); await ready(page); await page.getByLabel('讲解概要').fill('存储不可用时仍保留的完整改稿。');
  103 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('讲解概要')).toHaveValue('存储不可用时仍保留的完整改稿。');
  104 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '下载完整改稿', exact: true }).click();
  105 |   const copy = JSON.parse(readFileSync((await (await download).path())!, 'utf8')); expect(copy.content.description).toBe('存储不可用时仍保留的完整改稿。');
  106 |   await page.getByRole('button', { name: '＋ 新白板', exact: true }).click(); await expect(page.getByLabel('完整白板改稿')).toHaveCount(0);
  107 | });
  108 | 
  109 | test('stale-topic: another real tab keeps the local manuscript and opens a comparison before any replacement save', async ({ page }) => {
  110 |   await fixture(page); await generate(page); await ready(page); const href = page.url(), second = await page.context().newPage();
  111 |   try {
  112 |     await second.goto(href); await ready(second);
  113 |     await page.getByLabel('讲解概要').fill('本机持有的冲突原稿。');
  114 |     await second.getByLabel('讲解概要').fill('其他页已经保存的完整稿。'); await second.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  115 |     await expect(second.locator('.tw-editor')).toContainText('完整改稿已保存');
  116 |     await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  117 |     await expect(page.locator('.tw-conflict')).toContainText('服务器稿已变化');
  118 |     await expect(page.getByLabel('讲解概要')).toHaveValue('本机持有的冲突原稿。');
  119 |     await page.getByText('阅读当前服务器完整稿', { exact: true }).click(); await expect(page.locator('.tw-conflict')).toContainText('其他页已经保存的完整稿。');
  120 |     await page.getByRole('button', { name: '以服务器为基线继续我的改稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  121 |     await expect(page.locator('.tw-editor')).toContainText('完整改稿已保存');
  122 |   } finally { await second.close(); }
  123 | });
  124 | 
  125 | test('topic-slot: two real tabs keep their own complete incomplete edits after either tab reloads', async ({ page }) => {
  126 |   await fixture(page); await generate(page); await ready(page); const second = await page.context().newPage();
  127 |   try {
  128 |     await second.goto(page.url()); await ready(second);
  129 |     await page.getByLabel('讲解概要').fill('第一标签页尚未保存的完整稿。');
  130 |     const copies = () => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.editor.v1.')).map(key => JSON.parse(localStorage.getItem(key)!).content.description));
  131 |     await expect.poll(copies).toContain('第一标签页尚未保存的完整稿。');
  132 |     await second.getByLabel('讲解概要').fill('第二标签页的另一份完整稿。'); await expect.poll(copies).toContain('第二标签页的另一份完整稿。');
> 133 |     await page.reload(); await ready(page); await expect(page.getByLabel('讲解概要')).toHaveValue('第一标签页尚未保存的完整稿。');
      |                                                                                   ^ Error: expect(locator).toHaveValue(expected) failed
  134 |     await second.reload(); await ready(second); await expect(second.getByLabel('讲解概要')).toHaveValue('第二标签页的另一份完整稿。');
  135 |   } finally { await second.close(); }
  136 | });
  137 | 
  138 | for (const width of [390, 768, 1440]) test('explicit child goals, adult separation and complete edit controls fit at ' + width, async ({ page }) => {
  139 |   const f = await fixture(page, true); await page.setViewportSize({ width, height: 1000 }); await page.getByLabel('白板学习对象').selectOption(f.studentId!);
  140 |   await expect(page.locator('.tw-goals input')).toHaveCount(1); await page.locator('.tw-goals input').check(); await generate(page, '在相同整体下解释分数单位'); await ready(page);
  141 |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(view.studentId).toBe(f.studentId); expect(view.audience.atomIds).toEqual(['core:math:fractionadd']);
  142 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  143 |   await page.evaluate(() => window.scrollTo(0, 0)); await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'child-editor-' + width + '.png'), fullPage: true });
  144 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  145 |   await expect(page.locator('.wb-current-sentence')).toContainText('先核对观察'); expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  146 |   await page.getByRole('button', { name: '关闭白板', exact: true }).click();
  147 | });
  148 | 
```