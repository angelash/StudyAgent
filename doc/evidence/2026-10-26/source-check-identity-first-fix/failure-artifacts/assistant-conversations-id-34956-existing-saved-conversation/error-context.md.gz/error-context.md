# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: assistant-conversations.spec.ts >> identity recovery: a persistent connection failure offers a bounded manual retry and reuses the existing saved conversation
- Location: tests\e2e\assistant-conversations.spec.ts:100:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('alert', { name: '身份确认未完成', exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('alert', { name: '身份确认未完成', exact: true }) with timeout 15000ms
  - waiting for getByRole('alert', { name: '身份确认未完成', exact: true })

```

```yaml
- main:
  - link "学习观察室":
    - /url: /
  - navigation "主要导航":
    - link "学习首页":
      - /url: /learn?subject=math&student=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23
    - link "学习工作台":
      - /url: /studio?subject=math&student=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23
    - link "家长空间":
      - /url: /parent/dashboard?subject=math&studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23
    - link "知识诊断":
      - /url: /student/assessment?subject=math&studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23
    - link "今日学习":
      - /url: /student/today?subject=math&studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23
    - link "题卷资料":
      - /url: /library?subject=math&studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23
  - link "资料管理":
    - /url: /parent/data
  - button "退出"
  - complementary:
    - text: DAILY PRACTICE / 每日一小步
    - heading "把学会的， 慢慢变稳。" [level=1]:
      - text: 把学会的，
      - emphasis: 慢慢变稳。
    - paragraph: 先理解，再练习。用之后的独立新题，看看这一步有没有留下来。
    - text: 正在陪伴
    - combobox "选择学生":
      - option "匿名助教验收" [selected]
    - button "数学" [pressed]
    - button "语文"
    - button "英语"
    - paragraph: 匿名助教验收 · 3年级 · 数学
    - link "查看知识诊断与计划 ↗":
      - /url: /student/assessment?studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23&subject=math
  - alert:
    - text: 暂时无法连接学习服务，请检查网络后重试。已保存的数据会保留。
    - button "关闭提示": ×
  - text: 2026-10-26 / 数学
  - heading "今天，往前走一小步。" [level=2]
  - paragraph: 训练可以看提示、订正与重试。训练完成不直接证明掌握，之后用独立新题和间隔复测验证。
  - button "今日安排" [pressed]
  - button "错题与思路"
  - strong: 有一组小测还没完成
  - paragraph: 已保存 0 / 4 道
  - link "继续作答 →":
    - /url: /student/assessment?studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23&subject=math&session=diagnostic_4c424d35-55f5-440f-bddb-72858526c91b
  - heading "从了解孩子开始" [level=3]
  - paragraph: 确认学习进度，做一组知识点小测，再安排有针对性的练习。
  - link "开始知识诊断 ↗":
    - /url: /student/assessment?studentId=student_ab8c48df-86dc-44fc-be62-8fc1171fdb23&subject=math&view=plan
  - button "打开学习小助教"
- alert
```

# Test source

```ts
  2   | import { mkdirSync,readFileSync } from 'node:fs';
  3   | import { browserEvidence } from './evidence';
  4   | const api='http://localhost:'+(process.env.E2E_API_PORT??'4107')+'/api',evidence=browserEvidence('assistant-conversations');let address=0;
  5   | async function call(actor:any,path:string,body?:unknown){const response=await fetch(api+path,{method:body===undefined?'GET':'POST',headers:{'content-type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});const x=await response.json();expect(response.ok,JSON.stringify(x.error)).toBe(true);return x.data;}
  6   | async function setup(page:Page,kind:'practice'|'diagnostic'='practice'){
  7   |   const id=crypto.randomUUID(),principal='answer-assistant-browser-'+id+'@local.test',credential='Assistant-only-'+id;
  8   |   const registered=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json','X-Forwarded-For':'198.18.9.'+(++address)},body:JSON.stringify({principal,credential})});expect(registered.status).toBe(201);const actor=(await registered.json()).data;
  9   |   const child=(await call(actor,'/students',{nickname:'匿名助教验收',grade:3,preferredSessionMinutes:15,defaultVersionMap:{math:'',chinese:'',english:''}})).profile;
  10  |   const fixture=await call(actor,'/qa/answer-journeys',{studentId:child.id,mode:'numeric_blank',kind});
  11  |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  12  |   await page.goto(fixture.href);await expect(page.getByLabel('数字或分数答案')).toBeVisible();await open(page);
  13  |   const assistantId=await page.evaluate(()=>Object.keys(localStorage).filter(k=>k.startsWith('studyagent.assistant.v1.')).map(k=>JSON.parse(localStorage.getItem(k)!)).find(v=>v.sessionId)?.sessionId);
  14  |   expect(assistantId).toBeTruthy();return {actor,child,...fixture,assistantId};
  15  | }
  16  | async function open(page:Page){await page.getByRole('button',{name:/^打开学习(?:小助教|观察助教)$/}).click();await expect(page.getByLabel('想一起看看什么')).toBeEnabled();}
  17  | const panel=(page:Page)=>page.locator('.learning-assistant'),task=(page:Page)=>page.getByRole('region',{name:'提问任务'});
  18  | async function send(page:Page,message:string){await page.getByLabel('想一起看看什么').fill(message);await panel(page).getByRole('button',{name:'一起想一想 →',exact:true}).click();}
  19  | async function shot(page:Page,name:string){if(!process.env.CI){mkdirSync(evidence,{recursive:true});await page.screenshot({path:evidence+'/'+name+'.png'});}}
  20  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  21  | 
  22  | test('a saved question survives collapse and refresh without duplicate creation or retroactive first-answer evidence',async({page})=>{
  23  |   const f=await setup(page),posts:any[]=[];page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(r.url()))posts.push(r.postDataJSON());});
  24  |   const message='[assistant-pause-once] '+crypto.randomUUID()+' 请围绕条件给下一步提示。';await send(page,message);await expect(task(page)).toContainText(message);await expect(task(page)).toHaveAttribute('data-status',/queued|running/);
  25  |   await page.getByRole('button',{name:'收起学习小助教',exact:true}).click();await page.reload();await page.getByRole('button',{name:'打开学习小助教',exact:true}).click();await expect(task(page)).toContainText(message);
  26  |   await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:25000});expect(posts).toHaveLength(1);expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(2);
  27  |   await expect(panel(page).locator('.assistant-message').first()).toHaveClass(/from-user/);await expect(panel(page).locator('.assistant-message').last()).toHaveClass(/from-assistant/);
  28  |   for(const width of [1440,768,390]){await page.setViewportSize({width,height:width===390?844:1000});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await shot(page,'saved-conversation-'+width);}
  29  |   await page.getByRole('button',{name:'收起学习小助教',exact:true}).click();await page.getByLabel('数字或分数答案').fill('6');await page.getByRole('button',{name:'完成这一题 →',exact:true}).click();await expect(page.locator('.daily-feedback')).toContainText('使用了 1 级提示');
  30  | });
  31  | test('a lost creation receipt restores the same original command from server state without sending it again',async({page})=>{
  32  |   const f=await setup(page),commands:any[]=[];let release!:()=>void;const gate=new Promise<void>(r=>release=r);
  33  |   await page.route('**/api/ai/assistant/sessions/*/turns',async route=>{if(route.request().method()!=='POST')return route.continue();commands.push(route.request().postDataJSON());const response=await route.fetch();await gate;try{await route.fulfill({response});}catch{/* Page reloaded with its unacknowledged command retained. */}});
  34  |   try{const text='[assistant-pause-once] '+crypto.randomUUID()+' 我的问题需要保留完整原文。';await send(page,text);await expect(page.getByLabel('待确认提问')).toContainText(text);await expect.poll(()=>commands.length).toBe(1);
  35  |     await page.reload();await page.getByRole('button',{name:'打开学习小助教',exact:true}).click();await expect(task(page)).toContainText(text);release();
  36  |     await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:25000});expect(commands).toHaveLength(1);
  37  |     const turns=await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns');expect(turns.turns).toHaveLength(1);expect(turns.turns[0].requestKey).toBe(commands[0].requestKey);
  38  |     await expect(page.getByLabel('想一起看看什么')).toHaveValue('');
  39  |   }finally{release();}
  40  | });
  41  | test('running cancellation settles after refresh and retry retains the original model despite a new composer selection',async({page})=>{
  42  |   const f=await setup(page);await send(page,'[assistant-pause-once] '+crypto.randomUUID()+' 暂停后再核对这个条件。');
  43  |   await expect(task(page)).toHaveAttribute('data-status','running');await task(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','cancelled',{timeout:10000});
  44  |   expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(0);await page.reload();await open(page);
  45  |   await page.getByRole('combobox',{name:'选择大模型',exact:true}).selectOption('glm-5.3-flash');await task(page).getByRole('button',{name:'重试原任务',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:20000});
  46  |   const turns=(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns;expect(turns).toHaveLength(1);expect(turns[0].task.generation).toBe(2);expect(turns[0].modelId).toBe('deepseek-v4-flash');
  47  |   await expect(page.getByRole('combobox',{name:'选择大模型',exact:true})).toHaveValue('glm-5.3-flash');await shot(page,'retry-original-model');
  48  | });
  49  | test('invalid model evidence remains a visible failure and an explicit retry publishes one validated answer',async({page})=>{
  50  |   const f=await setup(page);await send(page,'[assistant-invalid-once] '+crypto.randomUUID()+' 请按证据解释。');await expect(task(page)).toHaveAttribute('data-status','failed',{timeout:15000});
  51  |   expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(0);await expect(panel(page)).not.toContainText('synthetic-unsupported-evidence');
  52  |   await task(page).getByRole('button',{name:'重试原任务',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:15000});expect(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/messages')).toHaveLength(2);
  53  | });
  54  | test('history reads beyond fifty messages, locates an old search match and returns to its actual practice question',async({page})=>{
  55  |   const f=await setup(page),marker='HISTORY_'+crypto.randomUUID(),seed=await call(f.actor,'/qa/assistant/seed-history',{sessionId:f.assistantId,count:75,marker});
  56  |   await page.reload();await open(page);await expect(panel(page).locator('.assistant-message')).toHaveCount(25);
  57  |   await panel(page).getByRole('button',{name:'更早的消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(50);
  58  |   await panel(page).getByRole('button',{name:'更早的消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(75);
  59  |   await panel(page).getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill(marker+' · 匿名历史第0条');await panel(page).getByRole('button',{name:'搜索历史',exact:true}).click();
  60  |   await expect(page.getByLabel('助教历史检索')).toContainText('找到 1 段对话');await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  61  |   await expect(page.locator('[data-message-id="'+seed.ids[0]+'"]')).toBeInViewport();await expect(page.getByRole('button',{name:'返回当前学习对话',exact:true})).toBeVisible();
  62  |   await page.setViewportSize({width:768,height:1000});await shot(page,'history-old-message-768');
  63  |   await page.getByRole('button',{name:'回到相关学习位置',exact:true}).click();await expect(page).toHaveURL(new RegExp('question='+encodeURIComponent(f.itemId)));await expect(page.getByLabel('数字或分数答案')).toBeVisible();
  64  | });
  65  | test('unavailable local storage keeps the full question editable, exportable and recoverable once the server accepts it',async({page})=>{
  66  |   const f=await setup(page);await page.evaluate(()=>{Storage.prototype.setItem=()=>{throw new DOMException('QA storage unavailable','QuotaExceededError');};});
  67  |   const text='[assistant-pause-once] '+crypto.randomUUID()+' '+('完整问题需要保留。'.repeat(20));await page.getByLabel('想一起看看什么').fill(text);await expect(panel(page)).toContainText('本机未能暂存提问');
  68  |   await page.getByRole('button',{name:'收起学习小助教',exact:true}).click();await open(page);await expect(page.getByLabel('想一起看看什么')).toHaveValue(text);
  69  |   const copy=page.waitForEvent('download');await panel(page).getByRole('button',{name:'下载提问副本',exact:true}).click();const json=JSON.parse(readFileSync((await (await copy).path())!,'utf8'));expect(json.input).toBe(text);expect(JSON.stringify(json)).not.toMatch(/token|gradingConfig|standardAnswer/);
  70  |   await panel(page).getByRole('button',{name:'一起想一想 →',exact:true}).click();await expect(task(page)).toContainText(text);await page.reload();await page.getByRole('button',{name:'打开学习小助教',exact:true}).click();await expect(task(page)).toContainText(text);
  71  |   await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:25000});expect((await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns).toHaveLength(1);
  72  | });
  73  | test('a forged cache owned by another account is ignored without exposing or sending its text',async({page})=>{
  74  |   await setup(page);await page.evaluate(()=>{const key=Object.keys(localStorage).find(k=>k.startsWith('studyagent.assistant.v1.'))!,value=JSON.parse(localStorage.getItem(key)!);value.ownerId='another-owner';value.input='FOREIGN_PRIVATE_DRAFT';value.pending={requestKey:crypto.randomUUID(),message:'FOREIGN_PRIVATE_PENDING',modelId:'deepseek-v4-flash',contextVersion:'a'.repeat(64)};localStorage.setItem(key,JSON.stringify(value));});
  75  |   let posts=0;page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(r.url()))posts++;});await page.reload();await open(page);
  76  |   await expect(panel(page)).not.toContainText('FOREIGN_PRIVATE');await expect(page.getByLabel('想一起看看什么')).toHaveValue('');expect(posts).toBe(0);
  77  | });
  78  | 
  79  | test('stopping local waiting leaves the real server task running until explicit cancellation',async({page})=>{
  80  |   const f=await setup(page);let cancels=0;page.on('request',r=>{if(r.method()==='POST'&&r.url().endsWith('/cancel'))cancels++;});
  81  |   await send(page,'[assistant-hold] '+crypto.randomUUID()+' 先保留原任务。');await expect(task(page)).toHaveAttribute('data-status','running');
  82  |   await panel(page).getByRole('button',{name:'停止等待',exact:true}).click();await expect(panel(page)).toContainText('已停止本次等待');
  83  |   const original=(await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns[0];expect(original.status).toBe('running');expect(cancels).toBe(0);
  84  |   await panel(page).getByRole('button',{name:'读取最新状态',exact:true}).click();await task(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','cancelled');expect(cancels).toBe(1);
  85  | });
  86  | 
  87  | test('conversation search pages beyond the first results and recovers from an empty result',async({page})=>{
  88  |   const f=await setup(page);await call(f.actor,'/qa/assistant/seed-history',{sessionId:f.assistantId,count:75});await page.reload();await open(page);
  89  |   await page.getByLabel('检索当前对话', {exact:true}).fill('合成历史');await panel(page).getByRole('button',{name:'查找这段对话',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(25);
  90  |   await panel(page).getByRole('button',{name:'更早的消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(50);
  91  |   await page.getByLabel('检索当前对话', {exact:true}).fill('NO_MATCH_'+crypto.randomUUID());await panel(page).getByRole('button',{name:'查找这段对话',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(0);
  92  |   await panel(page).getByRole('button',{name:'恢复最近消息',exact:true}).click();await expect(panel(page).locator('.assistant-message')).toHaveCount(25);
  93  | });
  94  | 
  95  | test('identity recovery: one failed identity request retries without asking the signed-in learner to log in again',async({page})=>{
  96  |   await setup(page);let reads=0;await page.route('**/api/auth/me',async route=>{if(route.request().method()!=='GET'){await route.continue();return;}reads++;if(reads===1)await route.abort('failed');else await route.continue();});
  97  |   await page.reload();await open(page);expect(reads).toBe(2);await expect(panel(page)).not.toContainText('请先进入学习或登录家长账号');await expect(page.getByRole('alert',{name:'身份确认未完成',exact:true})).toHaveCount(0);
  98  | });
  99  | 
  100 | test('identity recovery: a persistent connection failure offers a bounded manual retry and reuses the existing saved conversation',async({page})=>{
  101 |   const f=await setup(page);let reads=0,signIns=0;page.on('request',request=>{if(request.method()==='POST'&&new URL(request.url()).pathname==='/api/auth/login')signIns++;});await page.route('**/api/auth/me',async route=>{if(route.request().method()!=='GET'){await route.continue();return;}reads++;if(reads<=2)await route.abort('failed');else await route.continue();});
> 102 |   await page.reload();const warning=page.getByRole('alert',{name:'身份确认未完成',exact:true});await expect(warning).toBeVisible();expect(reads).toBe(2);await page.getByRole('button',{name:/^打开学习(?:小助教|观察助教)$/}).click();await expect(panel(page)).not.toContainText('请先进入学习或登录家长账号');await warning.getByRole('button',{name:'重新确认登录',exact:true}).click();await expect(page.getByLabel('想一起看看什么')).toBeEnabled();await expect(warning).toHaveCount(0);expect(reads).toBe(3);expect(signIns).toBe(0);
      |                                                                                                               ^ Error: expect(locator).toBeVisible() failed
  103 |   const cached=await page.evaluate(()=>Object.keys(localStorage).filter(key=>key.startsWith('studyagent.assistant.v1.')).map(key=>JSON.parse(localStorage.getItem(key)!)).find(value=>value.sessionId)?.sessionId);expect(cached).toBe(f.assistantId);
  104 | });
  105 | 
  106 | test('identity recovery: an explicit unauthenticated response clears private identity without retrying or calling it a connection failure',async({page})=>{
  107 |   await setup(page);let reads=0;await page.route('**/api/auth/me',async route=>{if(route.request().method()!=='GET'){await route.continue();return;}reads++;await route.fulfill({status:401,json:{data:null,error:{code:'unauthorized',message:'合成登录已失效'}}});});await page.reload();await page.getByRole('button',{name:/^打开学习(?:小助教|观察助教)$/}).click();await expect(panel(page)).toContainText('请先进入学习或登录家长账号');await expect(page.getByRole('alert',{name:'身份确认未完成',exact:true})).toHaveCount(0);expect(reads).toBe(1);await expect(page.getByLabel('想一起看看什么')).toHaveCount(0);
  108 | });
  109 | 
  110 | test('reviewing an earlier task preserves selection while the new task finishes in the background',async({page})=>{
  111 |   const f=await setup(page);const original='EARLIER_'+crypto.randomUUID();await send(page,original);await expect(task(page)).toHaveAttribute('data-status','completed');
  112 |   await send(page,'[assistant-pause-once] '+crypto.randomUUID()+' 保留后台提问状态。');await expect(task(page)).toHaveAttribute('data-status','running');
  113 |   await panel(page).locator('.assistant-task-history summary').click();await panel(page).locator('.assistant-task-history').getByRole('button',{name:new RegExp(original)}).click();await expect(task(page)).toContainText(original);
  114 |   await expect(page.getByLabel('想一起看看什么')).toBeEnabled({timeout:20000});await expect(task(page)).toContainText(original);expect((await call(f.actor,'/ai/assistant/sessions/'+f.assistantId+'/turns')).turns.every((t:any)=>t.status==='completed')).toBe(true);await expect(panel(page).locator('.assistant-message')).toHaveCount(4);
  115 | });
  116 | 
  117 | test('diagnostic rules stay deterministic and history locates an answered frozen question without opening a future one',async({page})=>{
  118 |   const f=await setup(page,'diagnostic'),message='DIAGNOSTIC_'+crypto.randomUUID();await send(page,message);await expect(task(page)).toHaveAttribute('data-status','completed');await expect(task(page)).toContainText('规则');
  119 |   await page.getByRole('button',{name:'收起学习观察助教',exact:true}).click();await page.getByLabel('数字或分数答案').fill('6');await page.getByRole('button',{name:'提交，下一步',exact:false}).click();
  120 |   await expect.poll(async()=>(await call(f.actor,'/diagnostics/sessions/'+f.sessionId)).answeredCount).toBe(1);await expect(page.getByLabel('数字或分数答案')).toBeVisible();
  121 |   await open(page);await panel(page).getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill(message);await panel(page).getByRole('button',{name:'搜索历史',exact:true}).click();await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  122 |   await page.getByRole('button',{name:'回到相关学习位置',exact:true}).click();await expect(page).toHaveURL(new RegExp('item='+encodeURIComponent(f.itemId)));await expect(page.getByRole('region',{name:'从历史对话定位的题目'})).toContainText('合成题型验收 numeric_blank');await expect(page.getByLabel('数字或分数答案')).toHaveCount(0);await shot(page,'diagnostic-history-readonly');
  123 |   await page.getByRole('button',{name:'回到当前核查进度',exact:true}).click();await expect(page.getByLabel('数字或分数答案')).toBeVisible();
  124 |   const state=await call(f.actor,'/diagnostics/sessions/'+f.sessionId),future=state.items[2].id;await page.goto(f.href+'&item='+encodeURIComponent(future));await expect(page.getByRole('region',{name:'从历史对话定位的题目'})).toHaveCount(0);await expect(page.getByText('这道题尚未开放或不属于原评测，请按当前核查顺序继续。')).toBeVisible();expect((await call(f.actor,'/diagnostics/sessions/'+f.sessionId)).answeredCount).toBe(1);
  125 | });
  126 | 
```