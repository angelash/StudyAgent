const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),{createHash}=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=process.cwd(),branch=path.resolve(root,'../StudyAgent-narration-continuity'),head='9e75de1dba37b0af0e74a4380697cbe84c89450f',core='560a89bffe8a50dbe4d05494ba2f402a4c97c58f',run=40323444646;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
function assertReport(bytes){const report=JSON.parse(bytes),cases=[];function walk(s){for(const spec of s.specs||[])for(const test of spec.tests||[])cases.push(test);for(const child of s.suites||[])walk(child);}report.suites.forEach(walk);if(report.stats.expected!==277||report.stats.unexpected||report.stats.flaky||report.stats.skipped||report.errors.length||cases.length!==277||cases.some(test=>test.results.length!==1||test.results[0].status!=='passed'))throw Error('Required263 original zero-retry cases not complete');return report;}
const localBytes=fs.readFileSync(path.join(branch,'data/qa/source-course-full-browser.json'));assertReport(localBytes);
const ci=JSON.parse(execFileSync('gh',['run','view',String(run),'--json','status,conclusion,headSha,jobs'],{encoding:'utf8',windowsHide:true}));
if(ci.status!=='completed'||ci.conclusion!=='success'||ci.headSha!==head||ci.jobs.length!==3||ci.jobs.some(job=>job.status!=='completed'||job.conclusion!=='success'))throw Error('Exact new candidate CI incomplete');
const downloaded=path.join(root,'data/qa/knowledge-report-release-ci-'+run+'-'+Date.now());
execFileSync('gh',['run','download',String(run),'--name','browser-verification-evidence','--dir',downloaded],{stdio:'inherit',windowsHide:true});
const bytes=fs.readFileSync(path.join(downloaded,'data/qa/source-course-full-browser.json'));assertReport(bytes);
const relative='data/qa/knowledge-report-ci-'+run+'-browser-original.json.gz',compressed=zlib.gzipSync(bytes),target=path.join(root,relative);
fs.writeFileSync(target,compressed,{flag:'wx'});
const latest=JSON.parse(fs.readFileSync('data/qa/knowledge-report-release-latest.json')),release=path.resolve(root,latest.folder),before=JSON.parse(fs.readFileSync(path.join(release,'deployment-before.json')));
if(!release.startsWith(path.join(root,'output/daemon/release-backups')+path.sep)||fs.realpathSync(release).toLowerCase()!==release.toLowerCase()||before.revision!=='f9eee1a0aca9395efd3c5593c6fb2e3ce8d9f85c')throw Error('Unexpected prepared125 rollback');
const names=[
 'infrastructure/domain-database','modules/ai/classroom-image.service',
 ...['topic-whiteboard.service','topic-whiteboard-worker.service','topic-whiteboard-content','topic-whiteboard-access','topic-whiteboard-projection','topic-whiteboard-narration.service','topic-whiteboard-visual.controller','topic-whiteboard-visual.service','topic-whiteboard-visual-worker.service','topic-whiteboard-visual-access','topic-whiteboard-visual-storage','topic-whiteboard-visual-retention','topic-whiteboard-figures','teaching-visual-storage'].map(name=>'modules/learning/'+name)
].map(name=>'apps/api/dist/apps/api/src/'+name+'.js');
const compiledSha256={};for(const file of names)compiledSha256[file]=sha(fs.readFileSync(path.join(branch,file)));
for(const file of Object.keys(before.protectedFiles))if(sha(fs.readFileSync(file))!==before.protectedFiles[file])throw Error('Protected local config changed');
if(sha(fs.readFileSync('.env'))!==sha(fs.readFileSync(path.join(release,'config/.env'))))throw Error('Private environment changed');
const candidate={status:'ready-for-release',at:new Date().toISOString(),head,applicationRevision:core,ciRun:run,verifiedZeroRetries:true,browserArtifact:relative,browserArtifactSha256:sha(compressed),originalBrowserSha256:sha(bytes),localBrowserSha256:sha(localBytes),localBrowserCases:277,remoteBrowserCases:277,compiledSha256};
fs.writeFileSync(path.join(release,'candidate.json'),JSON.stringify(candidate,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:candidate.status,head,ciRun:run,localBrowserCases:277,remoteBrowserCases:277,compiledFiles:names.length}));
