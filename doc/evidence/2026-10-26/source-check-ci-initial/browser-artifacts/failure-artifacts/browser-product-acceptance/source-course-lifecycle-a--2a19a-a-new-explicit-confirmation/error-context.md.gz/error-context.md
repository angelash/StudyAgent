# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-lifecycle.spec.ts >> a stale publication preview reads the actual saved version before a new explicit confirmation
- Location: tests/e2e/source-course-lifecycle.spec.ts:50:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '保存教学内容', exact: true })
    - locator resolved to <button class="sc-primary">保存教学内容</button>
  - attempting click action
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div tabindex="-1" class="ws-dialog-layer">…</div> from <section class="sc-lifecycle" aria-label="课程版本与变更">…</section> subtree intercepts pointer events
    - retrying click action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <div tabindex="-1" class="ws-dialog-layer">…</div> from <section class="sc-lifecycle" aria-label="课程版本与变更">…</section> subtree intercepts pointer events
    - retrying click action
      - waiting 100ms
    29 × waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <div tabindex="-1" class="ws-dialog-layer">…</div> from <section class="sc-lifecycle" aria-label="课程版本与变更">…</section> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - link "StudyAgent" [ref=f1e5] [cursor=pointer]:
        - /url: /studio
      - navigation [ref=f1e9]:
        - link "Home" [ref=f1e10] [cursor=pointer]:
          - /url: /studio?view=home
          - generic [ref=f1e13]: 首页
        - link "Courses" [ref=f1e14] [cursor=pointer]:
          - /url: /studio?view=courses
          - generic [ref=f1e17]: 课程
        - link "Calendar" [ref=f1e18] [cursor=pointer]:
          - /url: /studio?view=calendar
          - generic [ref=f1e21]: 学习动态
        - link "History" [ref=f1e22] [cursor=pointer]:
          - /url: /studio?view=history
          - generic [ref=f1e25]: 历史
        - link "Materials" [ref=f1e26] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e29]: 资料
      - generic [ref=f1e30]:
        - heading "继续学习" [level=2] [ref=f1e31]
        - link "讲座社会学想象力 社会学概论" [ref=f1e32] [cursor=pointer]:
          - /url: /studio/classroom
          - text: 讲座社会学想象力
          - generic [ref=f1e33]: 社会学概论
      - generic [ref=f1e34]:
        - heading "近期活动" [level=2] [ref=f1e35]
        - paragraph [ref=f1e36]: 开始学习后，活动会出现在这里。
      - link "返回学习首页 →" [ref=f1e38] [cursor=pointer]:
        - /url: /learn?subject=math
    - generic [ref=f1e39]:
      - generic [ref=f1e40]:
        - generic [ref=f1e41]:
          - link "‹ 返回我的课程" [ref=f1e42] [cursor=pointer]:
            - /url: /studio?view=courses
          - text: SOURCE TO COURSE
          - heading "看懂资源与条件" [level=1] [ref=f1e43]
          - paragraph [ref=f1e44]: 用相同条件比较观察与替代解释。
        - button "＋ 从资料创建课程" [disabled] [ref=f1e45]
      - generic [ref=f1e46]:
        - generic [ref=f1e47]: 等待你审阅
        - generic [ref=f1e48]: Browser fixture · not a real model · 中文讲解 · 每次预算 15 分钟
        - generic [ref=f1e49]: 内容待核查 · 不作为正式能力测量
      - region "课程版本与变更" [ref=f1e50]:
        - generic [ref=f1e51]:
          - generic [ref=f1e52]:
            - text: COURSE VERSIONS
            - heading "第 1 版 正在使用" [level=2] [ref=f1e53]
          - generic [ref=f1e54]:
            - button "创建修订稿" [disabled] [ref=f1e55]
            - button "归档课程" [disabled] [ref=f1e56]
            - button "撤回此版本" [disabled] [ref=f1e57]
        - dialog "创建课程修订稿" [ref=f1e59]:
          - generic [ref=f1e60]:
            - heading "从第 1 版创建修订稿" [level=2] [ref=f1e61]
            - button "关闭修订确认" [disabled] [ref=f1e62]: ×
          - paragraph [ref=f1e63]: 复制现有教学稿、题目和来源，进入完整编辑。原课程继续保留；发布修订时会再次展示对旧版的影响。
          - paragraph [ref=f1e64]: 教学稿包含题目答案，将保留作者接触事实。此操作不会重新调用模型。
          - generic [ref=f1e65]:
            - button "停止等待" [ref=f1e66] [cursor=pointer]
            - button "继续使用原版" [disabled] [ref=f1e67]
            - button "创建并编辑修订稿" [disabled] [ref=f1e68]
      - region "课程版本与变更" [ref=f1e69]:
        - generic [ref=f1e70]:
          - generic [ref=f1e71]:
            - text: COURSE VERSIONS
            - heading "第 2 版 待审修订" [level=2] [ref=f1e72]
          - generic [ref=f1e73]:
            - button "发布此修订" [disabled] [ref=f1e74]
            - button "放弃此修订稿" [disabled] [ref=f1e75]
        - paragraph [ref=f1e76]: 从已发布课程复制教学稿；保留原生成来历 · 2026/10/25 20:04:10
        - paragraph [ref=f1e77]: 此修订来自现有教学稿，已有生成与复核来历随稿保留；复制没有重新调用模型，内容仍待人工核查。
        - group [ref=f1e78]:
          - generic "版本历史 · 2 个版本" [ref=f1e79] [cursor=pointer]
      - group [ref=f1e80]:
        - generic "查看原始生成目标与模型" [ref=f1e81] [cursor=pointer]
      - generic [ref=f1e82]:
        - form "完整教学稿编辑器" [ref=f1e84]:
          - generic [ref=f1e85]:
            - generic [ref=f1e86]:
              - text: TEACHING MANUSCRIPT
              - heading "逐段核对，再交给课堂。" [level=2] [ref=f1e87]
              - paragraph [ref=f1e88]: 这里显示练习答案，供你编写与核查。修改和确认不会替代教师审核。
            - status [ref=f1e89]: 与打开时的稿件一致
          - group [ref=f1e90]:
            - generic "查看生成稿复核记录（2课）" [ref=f1e91] [cursor=pointer]
          - group [ref=f1e92]:
            - generic [ref=f1e93]:
              - generic [ref=f1e94]:
                - text: 教学稿课程名称
                - generic [ref=f1e95]: 7/180
              - textbox "教学稿课程名称" [ref=f1e96]: 看懂资源与条件
            - generic [ref=f1e97]:
              - generic [ref=f1e98]:
                - text: 课程概览
                - generic [ref=f1e99]: 22/700
              - textbox "课程概览" [ref=f1e100]: 从匿名观察出发，比较条件并寻找可区分的证据。
          - generic [ref=f1e101]:
            - generic [ref=f1e102]:
              - text: 正在编辑的课时
              - combobox "教学稿课时" [ref=f1e103]:
                - option "1. 区分事实与解释" [selected]
                - option "2. 比较替代解释"
            - tablist "教学稿环节" [ref=f1e104]:
              - tab "讲解与板书" [selected] [ref=f1e105] [cursor=pointer]
              - tab "例子与误区" [ref=f1e106] [cursor=pointer]
              - tab "练习与答案" [ref=f1e107] [cursor=pointer]
              - tab "来源引用" [ref=f1e108] [cursor=pointer]
          - tabpanel "讲解与板书" [ref=f1e109]:
            - generic [ref=f1e110]:
              - generic [ref=f1e111]:
                - text: 教学稿课时标题
                - generic [ref=f1e112]: 7/100
              - textbox "教学稿课时标题" [ref=f1e113]: 区分事实与解释
            - generic [ref=f1e114]:
              - generic [ref=f1e115]:
                - text: 教学稿课时目标
                - generic [ref=f1e116]: 15/350
              - textbox "教学稿课时目标" [ref=f1e117]: 把观察、推断与待验证条件分开。
            - generic [ref=f1e118]:
              - generic [ref=f1e119]:
                - text: 开场讲解
                - generic [ref=f1e120]: 24/400
              - textbox "开场讲解" [ref=f1e121]: 今天从匿名记录开始，保留事实和还不能判断的问题。
            - generic [ref=f1e122]:
              - generic [ref=f1e123]:
                - text: 概念讲解
                - generic [ref=f1e124]: 32/900
              - textbox "概念讲解" [ref=f1e125]: 观察描述具体发生的事情。解释提出可能的机制，还要与其他解释比较。
            - generic [ref=f1e126]:
              - generic [ref=f1e127]:
                - text: 概念板书
                - generic [ref=f1e128]: 2 条
              - textbox "概念板书" [ref=f1e129]: 先记录实际观察 再比较可能机制
              - generic [ref=f1e130]: 每行一条，共2～5条，每条最多80字。
            - generic [ref=f1e131]:
              - generic [ref=f1e132]:
                - text: 迁移讲解
                - generic [ref=f1e133]: 21/500
              - textbox "迁移讲解" [ref=f1e134]: 换一个新场景，写出可以区分两种解释的观察。
            - generic [ref=f1e135]:
              - generic [ref=f1e136]:
                - text: 总结讲解
                - generic [ref=f1e137]: 13/300
              - textbox "总结讲解" [ref=f1e138]: 保留依据、替代解释与局限。
            - generic [ref=f1e139]:
              - generic [ref=f1e140]:
                - text: 总结板书
                - generic [ref=f1e141]: 2 条
              - textbox "总结板书" [ref=f1e142]: 保留观察 核查替代解释
              - generic [ref=f1e143]: 每行一条，共2～4条，每条最多80字。
          - generic [ref=f1e144]:
            - generic [ref=f1e145]:
              - generic [ref=f1e146]: 保存后重新审阅，确认仍是独立一步。
              - generic [ref=f1e147]: 内容核查中 · 不作为正式能力测量
            - generic [ref=f1e148]:
              - button "导出本地编辑稿" [ref=f1e149] [cursor=pointer]
              - button "返回蓝图" [ref=f1e150] [cursor=pointer]
              - button "保存教学内容" [ref=f1e151] [cursor=pointer]
        - complementary [ref=f1e152]:
          - generic [ref=f1e153]:
            - text: LEARN WITH THE SOURCE
            - heading "回到原文核查" [level=2] [ref=f1e154]
          - generic [ref=f1e155]:
            - text: 课程引用的页或段
            - combobox "课程引用来源" [ref=f1e156]:
              - option "匿名记录 · 第1段" [selected]
          - article [ref=f1e157]:
            - generic [ref=f1e158]:
              - text: FROZEN SOURCE
              - heading "匿名记录 · 第1段" [level=3] [ref=f1e159]
              - paragraph [ref=f1e160]: 课程保存的正文版本 ad2e0a504e91 · 正文来源已保留
            - generic [ref=f1e161]: 匿名阅览室在周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {browserEvidence} from './evidence';
  3  | const api=`http://localhost:${process.env.E2E_API_PORT??4107}/api`,evidence=browserEvidence('course-lifecycle');let address=0;
  4  | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok).toBe(true);return(await response.json()).data;}
  5  | async function enter(page:Page){const id=Date.now()+'-'+Math.floor(Math.random()*100000),principal='versions-'+id+'@local.test',credential='Versions-'+id;
  6  |   const response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.3.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  7  |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  8  |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'匿名记录',sections:['匿名阅览室在周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'从观察到验证',goal:'用相同条件比较观察与替代解释。',language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});
  9  |   let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');row=await call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});await page.goto('/studio/source-courses?course='+row.id);await expect(page.getByRole('button',{name:'创建修订稿',exact:true})).toBeVisible();return{actor,row};
  10 | }
  11 | async function fork(page:Page){await page.getByRole('button',{name:'创建修订稿',exact:true}).click();const dialog=page.getByRole('dialog',{name:'创建课程修订稿'});await dialog.getByRole('button',{name:'创建并编辑修订稿',exact:true}).click();await expect(page.getByLabel('概念讲解',{exact:true})).toBeVisible();}
> 12 | async function save(page:Page){await page.getByRole('button',{name:'保存教学内容',exact:true}).click();await expect(page.getByLabel('概念讲解',{exact:true})).toHaveCount(0);}
     |                                                                                          ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  13 | const modal=(page:Page)=>page.getByRole('dialog',{name:'课程变更影响预览'});
  14 | 
  15 | test('edit and publish a revision, then explicitly resume the old version at its frozen line',async({page})=>{
  16 |   test.setTimeout(90000);const{actor,row}=await enter(page),old=await call(actor,'POST','/learning/classroom/sessions',{sourceCourseId:row.id,lessonId:row.lessons[0].id}),units=old.presentation.tracks[old.lesson.steps[1].id].units;
  17 |   await call(actor,'PATCH','/learning/classroom/sessions/'+old.id,{expectedRevision:old.revision,cursor:1,revealed:2,sentenceCursor:0,presentationVersion:old.presentation.version,unitId:units[0].id,projectDraft:'原版课堂草稿'});await page.reload();
  18 |   await fork(page);const newId=new URL(page.url()).searchParams.get('course')!;expect(newId).not.toBe(row.id);await page.getByLabel('概念讲解',{exact:true}).fill('修订后新增的概念说明。'+await page.getByLabel('概念讲解',{exact:true}).inputValue());await save(page);
  19 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await expect(modal(page)).toContainText('1 份课堂记录');await modal(page).getByRole('button',{name:'取消变更',exact:true}).click();expect((await call(actor,'GET','/learning/source-courses/'+row.id)).status).toBe('active');
  20 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('补充具体概念说明');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');
  21 |   await page.getByText('版本历史 · 2 个版本',{exact:true}).click();await page.getByRole('button',{name:'查看第 1 版',exact:true}).click();await expect(page.locator('.sc-course-meta')).toContainText('已归档');await page.getByRole('link',{name:'继续第 1 版的原课堂 →',exact:true}).click();await expect(page.locator('.cl-subtitle')).toHaveText(units[0].text);await expect(page).toHaveURL(new RegExp('session='+old.id));
  22 |   const historical=await call(actor,'GET','/learning/classroom/sessions/'+old.id);expect(historical.projectDraft).toBe('原版课堂草稿');expect(historical.lesson.steps[1].narration).not.toContain('修订后新增');
  23 | });
  24 | 
  25 | test('lost revision creation receipts survive refresh and recover the same draft with the original command',async({page})=>{
  26 |   test.setTimeout(90000);const{actor,row}=await enter(page),keys:string[]=[];let lost=false;
  27 |   await page.route('**/api/learning/source-courses/*/revisions',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!lost){lost=true;await route.fetch();await route.abort('connectionreset');}else await route.continue();});
  28 |   await page.getByRole('button',{name:'创建修订稿',exact:true}).click();await page.getByRole('button',{name:'创建并编辑修订稿',exact:true}).click();await expect(page.getByRole('dialog',{name:'创建课程修订稿'}).getByRole('button',{name:'找回上次课程操作',exact:true})).toBeVisible();
  29 |   await page.reload();await page.getByRole('button',{name:'找回上次课程操作',exact:true}).click();await expect(page.getByLabel('概念讲解',{exact:true})).toBeVisible();expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);const rows=await call(actor,'GET','/learning/source-courses');expect(rows.filter((item:any)=>item.versioning?.parentCourseId===row.id)).toHaveLength(1);
  30 | });
  31 | 
  32 | test('archive, withdrawal reasons, restore, keyboard cancellation and responsive impact previews use real saved states',async({page})=>{
  33 |   test.setTimeout(90000);const{actor,row}=await enter(page),errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  34 |   const archive=page.getByRole('button',{name:'归档课程',exact:true});await archive.focus();await page.keyboard.press('Enter');await expect(modal(page)).toBeVisible();
  35 |   for(let index=0;index<10;index++){await page.keyboard.press('Tab');expect(await page.evaluate(()=>Boolean(document.activeElement?.closest('[role="dialog"][aria-label="课程变更影响预览"]')))).toBe(true);}
  36 |   for(const width of [1440,768,390]){await page.setViewportSize({width,height:960});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(!process.env.CI)await page.screenshot({path:evidence+'/impact-'+width+'.png',fullPage:true});}
  37 |   await page.keyboard.press('Escape');await expect(modal(page)).toHaveCount(0);await expect(archive).toBeFocused();expect((await call(actor,'GET','/learning/source-courses/'+row.id)).status).toBe('active');
  38 |   await page.getByRole('button',{name:'撤回此版本',exact:true}).click();await expect(modal(page).getByRole('button',{name:'确认撤回此版本',exact:true})).toBeDisabled();await modal(page).getByLabel('课程版本变更原因').fill('需要核查例子条件');await modal(page).getByRole('button',{name:'确认撤回此版本',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-version-reason')).toContainText('需要核查例子条件');await page.reload();await expect(page.locator('.sc-lifecycle h2')).toContainText('已撤回');
  39 |   await page.getByRole('button',{name:'恢复使用此版本',exact:true}).click();await modal(page).getByRole('button',{name:'确认恢复使用此版本',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');expect(errors).toEqual([]);
  40 | });
  41 | 
  42 | test('a lost publication reply recovers after refresh without another publication or another lesson version',async({page})=>{
  43 |   test.setTimeout(90000);const{actor}=await enter(page);await fork(page);await save(page);const id=new URL(page.url()).searchParams.get('course')!,keys:string[]=[];let lost=false;
  44 |   await page.route('**/api/learning/source-courses/*/lifecycle',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!lost){lost=true;await route.fetch();await route.abort('connectionreset');}else await route.continue();});
  45 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('已核对当前讲解内容');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page).getByRole('button',{name:'找回上次课程操作',exact:true})).toBeVisible();
  46 |   await page.reload();await page.getByRole('button',{name:'找回上次课程操作',exact:true}).click();await expect(page.locator('.sc-lifecycle-pending')).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);
  47 |   const row=await call(actor,'GET','/learning/source-courses/'+id);expect(row.versioning.events.filter((event:any)=>event.action==='publish'&&event.toStatus==='active')).toHaveLength(1);
  48 | });
  49 | 
  50 | test('a stale publication preview reads the actual saved version before a new explicit confirmation',async({page})=>{
  51 |   test.setTimeout(90000);const{actor}=await enter(page);await fork(page);await save(page);const id=new URL(page.url()).searchParams.get('course')!;
  52 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();const current=await call(actor,'GET','/learning/source-courses/'+id);await call(actor,'PATCH','/learning/source-courses/'+id,{expectedRevision:current.revision,requestKey:crypto.randomUUID(),title:'另一页保存的修订标题',goal:current.input.goal,lessons:current.lessons.map((lesson:any)=>({id:lesson.id,title:lesson.title,objective:lesson.objective}))});
  53 |   await modal(page).getByLabel('课程版本变更原因').fill('发布已核对的内容');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page).getByRole('alert')).toContainText('重新预览');await modal(page).getByRole('button',{name:'读取已保存的课程版本',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.getByRole('heading',{name:'另一页保存的修订标题',exact:true})).toBeVisible();
  54 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('重新预览后确认发布');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await expect(modal(page)).toHaveCount(0);await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');
  55 | });
  56 | 
  57 | test('stopping a lost publication wait preserves the committed command and ignores its late reply',async({page})=>{
  58 |   test.setTimeout(90000);const{actor}=await enter(page);await fork(page);await save(page);const id=new URL(page.url()).searchParams.get('course')!;let release!:()=>void,arrived!:()=>void,heldOnce=false;
  59 |   const held=new Promise<void>(resolve=>{release=resolve;}),arrival=new Promise<void>(resolve=>{arrived=resolve;});
  60 |   await page.route('**/api/learning/source-courses/*/lifecycle',async route=>{const response=await route.fetch();if(!heldOnce){heldOnce=true;arrived();await held;}try{await route.fulfill({response});}catch{/* Client explicitly stopped waiting. */}});
  61 |   await page.getByRole('button',{name:'发布此修订',exact:true}).click();await modal(page).getByLabel('课程版本变更原因').fill('保留有界的恢复行为');await modal(page).getByRole('button',{name:'确认发布此修订',exact:true}).click();await arrival;
  62 |   await modal(page).getByRole('button',{name:'停止等待',exact:true}).click();await expect(modal(page).getByRole('alert')).toContainText('可能已经保存');release();await modal(page).getByRole('button',{name:'找回上次课程操作',exact:true}).click();await expect(modal(page)).toHaveCount(0);
  63 |   await expect(page.locator('.sc-course-meta')).toContainText('可以开始学习');const row=await call(actor,'GET','/learning/source-courses/'+id);expect(row.versioning.events.filter((event:any)=>event.action==='publish'&&event.toStatus==='active')).toHaveLength(1);
  64 | });
  65 | 
```