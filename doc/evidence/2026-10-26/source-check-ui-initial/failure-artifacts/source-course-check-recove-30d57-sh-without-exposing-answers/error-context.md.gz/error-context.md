# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: source-course-check.spec.ts >> recovery: lost prepare and confirmation replies replay exact original commands after refresh without exposing answers
- Location: tests\e2e\source-course-check.spec.ts:25:5

# Error details

```
Error: GET /learning/classroom/sessions/null -> 404

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [active]:
  - alert [ref=f3e1]: 教学课堂 · StudyAgent
  - main [ref=f3e2]:
    - region "课堂练习题目" [ref=f3e3]:
      - generic [ref=f3e4]:
        - button "关闭独立练习" [ref=f3e5] [cursor=pointer]: ×
        - navigation "题目进度" [ref=f3e6]:
          - button "第1题" [ref=f3e7] [cursor=pointer]
          - button "第2题" [ref=f3e8] [cursor=pointer]
          - button "第3题" [ref=f3e9] [cursor=pointer]
          - button "第4题" [ref=f3e10] [cursor=pointer]
        - generic [ref=f3e11]: 已答 0/4
        - button "☏ Assistant" [ref=f3e12] [cursor=pointer]
      - generic [ref=f3e13]:
        - paragraph [ref=f3e14]: 4个新情境 · 核查所选目标 · 首次作答、提示与跳过分别记录
        - generic "题目作答区域，数字键选择，回车提交" [ref=f3e15]:
          - generic [ref=f3e16]:
            - generic [ref=f3e17]: MULTIPLE CHOICE · 1 / 4 · 区分事实与解释
            - heading "匿名场馆情境1：周末排队而工作日空闲，哪些判断保留了证据边界？" [level=2] [ref=f3e18]
            - paragraph [ref=f3e19]: 选择所有符合项。本题须选全且不多选。
            - status [ref=f3e20]: 当前选择：未选 · 再次选择可取消
          - group "选择所有符合项" [ref=f3e21]:
            - generic [ref=f3e23] [cursor=pointer]:
              - checkbox "比较开放时间和活动安排" [ref=f3e24]
              - generic [aria-hidden] [ref=f3e25]: ▲
              - generic [ref=f3e26]: 比较开放时间和活动安排
              - generic [aria-hidden] [ref=f3e27]: "1"
            - generic [ref=f3e28] [cursor=pointer]:
              - checkbox "一次排队就证明唯一原因" [ref=f3e29]
              - generic [aria-hidden] [ref=f3e30]: ◆
              - generic [ref=f3e31]: 一次排队就证明唯一原因
              - generic [aria-hidden] [ref=f3e32]: "2"
            - generic [ref=f3e33] [cursor=pointer]:
              - checkbox "保留尚未观察的时段" [ref=f3e34]
              - generic [aria-hidden] [ref=f3e35]: ●
              - generic [ref=f3e36]: 保留尚未观察的时段
              - generic [aria-hidden] [ref=f3e37]: "3"
            - generic [ref=f3e38] [cursor=pointer]:
              - checkbox "没有数据也可断定普遍规律" [ref=f3e39]
              - generic [aria-hidden] [ref=f3e40]: ■
              - generic [ref=f3e41]: 没有数据也可断定普遍规律
              - generic [aria-hidden] [ref=f3e42]: "4"
        - button "先给我一个提示" [ref=f3e44] [cursor=pointer]
        - generic [ref=f3e45]:
          - button "Check →" [disabled] [ref=f3e46]
          - button "Skip" [ref=f3e47] [cursor=pointer]
          - button "这题我不会" [ref=f3e48] [cursor=pointer]
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {browserEvidence} from './evidence';
  3  | const api='http://localhost:'+(process.env.E2E_API_PORT??4107)+'/api',evidence=browserEvidence('source-check');let address=0;
> 4  | async function call(actor:any,method:string,path:string,body?:unknown){const response=await fetch(api+path,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},...(body===undefined?{}:{body:JSON.stringify(body)})});expect(response.ok,method+' '+path+' -> '+response.status).toBe(true);return(await response.json()).data;}
     |                                                                                                                                                                                                                                                                                                                      ^ Error: GET /learning/classroom/sessions/null -> 404
  5  | async function enter(page:Page,extra=''){
  6  |   page.on('dialog',dialog=>void dialog.accept());const suffix=crypto.randomUUID(),principal='source-check-'+suffix+'@local.test',credential='Source-check-'+suffix,response=await fetch(api+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':'198.18.36.'+(++address)},body:JSON.stringify({principal,credential})});expect(response.status).toBe(201);const actor=(await response.json()).data;
  7  |   await page.addInitScript(()=>localStorage.setItem('studyagent.classroom.tour','done'));await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  8  |   const source=await call(actor,'POST','/learning/source-courses/materials/text',{title:'核查合成原文',sections:['匿名阅览室在两个周末有排队，工作日有空位；没有记录晚间，也不知道当天是否有活动。比较时应保持其他条件相同，不把一次观察当作唯一原因。'],requestKey:crypto.randomUUID()}),draft=await call(actor,'POST','/learning/source-courses',{title:'合成资料独立核查 '+suffix,goal:'保留来源和适用条件，比较替代解释。'+extra,language:'zh-CN',minutesPerSession:15,modelId:'deepseek-v4-flash',selections:[{materialId:source.material.id,version:source.version,pages:[1]}],requestKey:crypto.randomUUID()});let row:any;await expect.poll(async()=>{row=await call(actor,'GET','/learning/source-courses/'+draft.id);return row.status;},{timeout:30000}).toBe('ready');row=await call(actor,'POST','/learning/source-courses/'+row.id+'/confirm',{expectedRevision:row.revision,fingerprint:row.fingerprint,requestKey:crypto.randomUUID()});await page.goto('/studio/source-courses?course='+row.id);await expect(page.getByRole('region',{name:'资料课程独立核查',exact:true})).toBeVisible();return{actor,row};
  9  | }
  10 | const panel=(page:Page)=>page.getByRole('region',{name:'资料课程独立核查',exact:true});
  11 | async function prepareUI(page:Page){await panel(page).getByRole('button',{name:'＋ 准备独立核查',exact:true}).click();const dialog=page.getByRole('dialog',{name:'选择这次要核查的目标',exact:true});await dialog.locator('input[type=checkbox]').nth(0).check();await dialog.locator('input[type=checkbox]').nth(1).check();await expect(dialog.getByLabel('选择大模型')).toHaveValue('deepseek-v4-flash');await dialog.getByRole('button',{name:'预览核查范围',exact:true}).click();await expect(dialog).toContainText('完整输入已核对');await dialog.getByRole('button',{name:'准备这份题组',exact:true}).click();}
  12 | async function candidate(page:Page){const button=panel(page).getByRole('button',{name:'确认用于练习',exact:true});await expect.poll(async()=>panel(page).textContent(),{timeout:30000}).toContain('待确认用于练习');if(!await button.isVisible())await panel(page).locator('summary').filter({hasText:'管理题组候选与版本'}).click();await expect(button).toBeVisible();return button;}
  13 | async function confirmUI(page:Page){await(await candidate(page)).click();const dialog=page.getByRole('dialog',{name:'将题组用于练习',exact:true});await dialog.getByLabel('同意将这份待审核题组用于练习').check();await dialog.getByRole('button',{name:'确认用于练习',exact:true}).click();}
  14 | async function readyByApi(actor:any,row:any){const candidate=await call(actor,'POST','/learning/source-courses/'+row.id+'/checks/prepare',{expectedRevision:row.revision,courseFingerprint:row.fingerprint,lessonIds:row.lessons.map((lesson:any)=>lesson.id),modelId:'deepseek-v4-flash',requestKey:crypto.randomUUID()});let view:any;await expect.poll(async()=>{view=await call(actor,'GET','/learning/source-courses/'+row.id+'/checks/'+candidate.id);return view.status;},{timeout:30000}).toBe('ready');return view;}
  15 | 
  16 | for(const width of [390,768,1440])test('source check keeps independent first answers, frozen sources and exact course return at '+width,async({page})=>{
  17 |   test.setTimeout(150000);await page.setViewportSize({width,height:960});const{actor,row}=await enter(page);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));await prepareUI(page);await candidate(page);await page.screenshot({path:evidence+'/candidates-'+width+'.png',fullPage:true});await confirmUI(page);await expect(panel(page).getByRole('link',{name:'开始独立核查 →',exact:true})).toBeVisible();await panel(page).getByRole('link',{name:'开始独立核查 →',exact:true}).click();
  18 |   await expect(page.getByRole('region',{name:'课堂练习题目',exact:true})).toBeVisible();const sessionId=new URL(page.url()).searchParams.get('session')!,session=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(session.sourceCheckId).toBe(new URL(page.url()).searchParams.get('sourceCheckId'));expect(session.authoringAnswerExposure).toBeUndefined();expect(JSON.stringify(session)).not.toContain('correctIndices');await expect(page.locator('.cl-unit-check-note')).toContainText('4个新情境');
  19 |   await page.locator('.cl-practice-options label').nth(0).click();await page.locator('.cl-practice-options label').nth(2).click();await page.getByRole('button',{name:'Check →',exact:true}).click();await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');const original=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(original.answers[0].answerExposure).toBeUndefined();
  20 |   await page.getByRole('button',{name:'核对本题原文 1 ↗',exact:true}).click();const source=page.getByRole('dialog',{name:'核查合成原文',exact:true});await expect(source).toContainText('没有记录晚间');await page.screenshot({path:evidence+'/frozen-source-'+width+'.png'});await page.keyboard.press('Escape');await expect(source).toHaveCount(0);await expect(page.getByRole('button',{name:'核对本题原文 1 ↗',exact:true})).toBeFocused();
  21 |   await page.reload();await expect(page.locator('.cl-practice-prompt small')).toContainText('2 / 4');await page.locator('.cl-practice-options label').first().click();await page.getByRole('button',{name:'Check →',exact:true}).click();await page.getByRole('button',{name:'下一题 →',exact:true}).click();await page.getByRole('button',{name:'这题我不会',exact:true}).click();await page.getByRole('button',{name:'下一题 →',exact:true}).click();await page.getByRole('button',{name:'Skip',exact:true}).click();await expect(page.getByRole('region',{name:'课堂练习复盘',exact:true})).toBeVisible();await page.screenshot({path:evidence+'/review-'+width+'.png'});
  22 |   const final=await call(actor,'GET','/learning/classroom/sessions/'+sessionId);expect(final.answers[0]).toEqual(original.answers[0]);expect(final.answers).toHaveLength(4);await page.getByRole('button',{name:'返回课程，安排下一步',exact:true}).click();await page.getByRole('button',{name:'保存并离开',exact:true}).click();await expect(page).toHaveURL(new RegExp('/studio/source-courses\\?.*course='+row.id));await expect(panel(page).getByRole('link',{name:'复盘本次核查 →',exact:true})).toBeVisible();const course=await call(actor,'GET','/learning/source-courses/'+row.id);expect(course.journey.unitCheck.current.activity.practice.summary).toMatchObject({answered:4,independentCorrect:2,dontKnow:1,skipped:1});expect(course.lastSessionId).toBeNull();expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);
  23 | });
  24 | 
  25 | test('recovery: lost prepare and confirmation replies replay exact original commands after refresh without exposing answers',async({page})=>{
  26 |   test.setTimeout(150000);const{actor,row}=await enter(page),prepareKeys:string[]=[],confirmKeys:string[]=[];let dropped=false;
  27 |   await page.route('**/checks/prepare',async route=>{prepareKeys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await prepareUI(page);await expect(page.getByRole('dialog',{name:'选择这次要核查的目标'}).getByRole('alert')).toBeVisible();await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();await candidate(page);expect(prepareKeys).toHaveLength(2);expect(prepareKeys[1]).toBe(prepareKeys[0]);expect(await call(actor,'GET','/learning/source-courses/'+row.id+'/checks')).toHaveLength(1);
  28 |   dropped=false;await page.route('**/checks/*/confirm',async route=>{confirmKeys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await confirmUI(page);await expect(page.getByRole('dialog',{name:'将题组用于练习'}).getByRole('alert')).toBeVisible();await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();await expect(panel(page).getByRole('link',{name:'开始独立核查 →',exact:true})).toBeVisible();expect(confirmKeys).toHaveLength(2);expect(confirmKeys[1]).toBe(confirmKeys[0]);const checks=await call(actor,'GET','/learning/source-courses/'+row.id+'/checks');expect(checks[0].publication.revision).toBe(1);await panel(page).getByRole('link',{name:'开始独立核查 →',exact:true}).click();const session=await call(actor,'GET','/learning/classroom/sessions/'+new URL(page.url()).searchParams.get('session'));expect(session.authoringAnswerExposure).toBeUndefined();
  29 | });
  30 | 
  31 | test('recovery: explicit authoring keeps a dirty local copy and replays a lost edit without replacing the original request or review',async({page})=>{
  32 |   test.setTimeout(150000);const{actor,row}=await enter(page);await readyByApi(actor,row);await page.reload();await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();const editor=page.getByRole('dialog',{name:'核查题组完整审阅',exact:true});await editor.getByLabel('题组名称',{exact:true}).fill('保留本机题组修改');await expect(editor).toContainText('有未保存修改');const keys:string[]=[];let dropped=false;await page.route('**/checks/*/content',async route=>{keys.push(route.request().postDataJSON().requestKey);if(!dropped){dropped=true;await route.fetch();await route.abort('failed');}else await route.continue();});await editor.getByRole('button',{name:'保存题组修改',exact:true}).click();await expect(editor.getByRole('alert')).toBeVisible();await page.reload();await panel(page).getByRole('button',{name:'按原参数核对操作',exact:true}).click();await expect(panel(page)).toContainText('保留本机题组修改');expect(keys).toHaveLength(2);expect(keys[0]).toBe(keys[1]);await expect(panel(page).getByText(/本机未保存题组稿/)).toHaveCount(0);
  33 |   await candidate(page);await panel(page).getByRole('button',{name:'审阅答案并编辑',exact:true}).click();await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue('保留本机题组修改');await editor.getByLabel('题组名称',{exact:true}).fill('还未保存的另一稿');await editor.getByRole('button',{name:'关闭题组编辑',exact:true}).click();await page.getByRole('button',{name:'保留本机稿并关闭',exact:true}).click();await page.reload();await panel(page).locator('summary').filter({hasText:'本机未保存题组稿'}).click();await panel(page).getByRole('button',{name:'打开并比较本机稿',exact:true}).click();await editor.getByRole('button',{name:'恢复这份本机稿',exact:true}).click();await expect(editor.getByLabel('题组名称',{exact:true})).toHaveValue('还未保存的另一稿');await expect(editor).toContainText('原AI复核不适用于当前修改');
  34 | });
  35 | 
  36 | test('uncertain review requires an explicit acknowledgement and cancellation retries only the original model',async({page})=>{
  37 |   test.setTimeout(180000);const{actor,row}=await enter(page,'[check-pause-once][check-uncertain]');await prepareUI(page);await expect(panel(page).getByRole('button',{name:'取消这次准备',exact:true})).toBeVisible();await panel(page).getByRole('button',{name:'取消这次准备',exact:true}).click();await expect.poll(async()=>panel(page).textContent(),{timeout:30000}).toContain('已取消');if(!await panel(page).getByRole('button',{name:'使用原模型重试',exact:true}).isVisible())await panel(page).locator('summary').filter({hasText:'管理题组候选与版本'}).click();await panel(page).getByRole('button',{name:'使用原模型重试',exact:true}).click();await candidate(page);await(await candidate(page)).click();const dialog=page.getByRole('dialog',{name:'将题组用于练习',exact:true});await dialog.getByLabel('同意将这份待审核题组用于练习').check();await expect(dialog.getByRole('button',{name:'确认用于练习',exact:true})).toBeDisabled();await dialog.getByLabel('我已了解AI仍有待核查问题或原审稿已过期，不把本次练习当作正式测量').check();await dialog.getByRole('button',{name:'确认用于练习',exact:true}).click();await expect(panel(page).getByRole('link',{name:'开始独立核查 →',exact:true})).toBeVisible();const checks=await call(actor,'GET','/learning/source-courses/'+row.id+'/checks');expect(checks).toHaveLength(1);expect(checks[0].modelId).toBe('deepseek-v4-flash');expect(checks[0].review.decision).toBe('uncertain');expect(checks[0].task.generation).toBe(2);
  38 | });
  39 | 
```