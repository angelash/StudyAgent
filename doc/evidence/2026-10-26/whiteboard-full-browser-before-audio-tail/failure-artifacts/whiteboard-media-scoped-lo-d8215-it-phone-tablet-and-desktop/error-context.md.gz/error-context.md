# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: whiteboard-media.spec.ts >> scoped local resume and complete accessible notes fit phone, tablet and desktop
- Location: tests\e2e\whiteboard-media.spec.ts:93:5

# Error details

```
Error: /auth/register: 429

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { copyFileSync, readFileSync } from 'node:fs';
  3   | import { execFileSync } from 'node:child_process';
  4   | import { browserEvidence } from './evidence';
  5   | import { join } from 'node:path';
  6   | 
  7   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107');
  8   | const credential = 'Synthetic-whiteboard-only-20261026';
  9   | async function fixture(page: Page) {
  10  |   const principal = 'whiteboard-' + crypto.randomUUID() + '@local.test';
  11  |   async function call(path: string, body?: unknown, actor?: string, method = 'POST') {
  12  |     const response = await fetch(api + '/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(actor ? { Authorization: 'Bearer ' + actor } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
> 13  |     expect(response.ok, path + ': ' + response.status).toBe(true); return (await response.json()).data;
      |                                                        ^ Error: /auth/register: 429
  14  |   }
  15  |   const actor = await call('/auth/register', { principal, credential });
  16  |   const child = await call('/students', { nickname: '匿名白板验证', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token);
  17  |   const studentId = child.profile.id;
  18  |   await call('/students/' + studentId + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }, actor.token, 'PUT');
  19  |   const draft = { studentId, subject: 'math', prompt: '解释异分母分数加法', atomId: 'core:math:fractionadd' };
  20  |   const preview = await call('/learning/studio/whiteboards/preview', draft, actor.token);
  21  |   const saved = await call('/learning/studio/whiteboards', { ...draft, fingerprint: preview.fingerprint, requestKey: crypto.randomUUID() }, actor.token);
  22  |   const board = await call('/qa/whiteboard-media', { boardId: saved.id }, actor.token);
  23  |   await page.route('**/api/learning/studio/overview?*', async route => {
  24  |     const response = await route.fetch(); if (!response.ok()) { await route.fulfill({ response }); return; }
  25  |     const payload = await response.json(); payload.data.narrationAvailable = true;
  26  |     payload.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture-a', voices: [
  27  |       { id: 'fixture-a', label: '合成音轨 A' }, { id: 'fixture-delay', label: '受控延迟音轨' }, { id: 'fixture-fail', label: '受控失败音轨' },
  28  |     ] }; await route.fulfill({ response, json: payload });
  29  |   });
  30  |   await page.addInitScript(() => {
  31  |     const NativeAudio = window.Audio; (window as any).__whiteboardAudio = [];
  32  |     (window as any).Audio = function (src?: string) { const audio = new NativeAudio(src); (window as any).__whiteboardAudio.push(audio); return audio; };
  33  |   });
  34  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  35  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  36  |   const href = '/studio?' + new URLSearchParams({ student: studentId, subject: 'math', whiteboard: board.id });
  37  |   await page.goto(href); await expect(page.locator('.wb-current-sentence')).toContainText('先统一单位');
  38  |   return { actor, board, studentId, href, call, current: page.locator('.wb-current-sentence') };
  39  | }
  40  | 
  41  | test('complete sentence, complete notes, paused text reading and explicit sentence navigation', async ({ page }) => {
  42  |   const f = await fixture(page); await page.getByLabel('阅读方式').selectOption('text');
  43  |   await expect(f.current).not.toContainText('最后验证'); await expect(page.locator('.wb-reading-notes ol li')).toHaveCount(4);
  44  |   await expect(page.getByLabel('完整讲稿与要点')).toContainText('完整正文末行');
  45  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  46  |   await expect.poll(() => page.getByRole('slider').inputValue()).not.toBe('0');
  47  |   await page.getByRole('button', { name: '暂停', exact: true }).click(); const at = await page.getByRole('slider').inputValue();
  48  |   await page.waitForTimeout(250); expect(await page.getByRole('slider').inputValue()).toBe(at);
  49  |   await page.getByRole('button', { name: '下一句' }).click(); await expect(f.current).toContainText('再合并份数');
  50  |   await expect(page.locator('.wb-reading-notes [aria-current=step]')).toHaveText('[whiteboard-fixture] 再合并份数。');
  51  |   await page.getByRole('button', { name: '上一句' }).click(); await expect(f.current).toContainText('先统一单位');
  52  |   await page.getByRole('button', { name: '关闭白板' }).click(); await expect(page.getByRole('dialog', { name: '白板视频' })).toHaveCount(0);
  53  | });
  54  | 
  55  | test('real WAV ended drives cloud playback, pause retains audio time and late ended cannot move a new sentence', async ({ page }) => {
  56  |   const f = await fixture(page); await page.getByRole('button', { name: '播放', exact: true }).click();
  57  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(.15);
  58  |   await expect(f.current).toContainText('先统一单位'); // Original nominal scene duration is only 10ms.
  59  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  60  |   const before = await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime);
  61  |   await page.waitForTimeout(250); expect(await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeCloseTo(before, 1);
  62  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  63  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeGreaterThan(before);
  64  |   await expect(f.current).toContainText('再合并份数', { timeout: 5000 });
  65  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  66  |   await page.evaluate(() => (window as any).__whiteboardAudio[0].dispatchEvent(new Event('ended')));
  67  |   await expect(f.current).toContainText('再合并份数');
  68  |   await page.getByRole('button', { name: '关闭白板' }).click();
  69  |   expect(await page.evaluate(() => (window as any).__whiteboardAudio.every((audio: HTMLAudioElement) => audio.paused && !audio.getAttribute('src')))).toBe(true);
  70  | });
  71  | 
  72  | test('voice switch fences delayed requests and an audio failure offers explicit retry or text reading', async ({ page }) => {
  73  |   const f = await fixture(page); await page.getByLabel('旁白音色').selectOption('fixture-delay');
  74  |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect(page.getByRole('status').last()).toContainText('正在准备当前句');
  75  |   await page.getByLabel('旁白音色').selectOption('fixture-fail'); await page.waitForTimeout(2100);
  76  |   expect(await page.evaluate(() => (window as any).__whiteboardAudio.length)).toBe(0);
  77  |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect(page.locator('.sa-whiteboard-notice')).toContainText('重试或选择文字');
  78  |   await expect(f.current).toContainText('先统一单位'); await page.getByLabel('阅读方式').selectOption('text');
  79  |   await page.getByRole('button', { name: '播放', exact: true }).click(); await expect.poll(() => page.getByRole('slider').inputValue()).not.toBe('0');
  80  | });
  81  | 
  82  | test('reopening a paused cloud sentence restores its known audio time in the verified original board', async ({ page }) => {
  83  |   const f = await fixture(page); await page.getByRole('button', { name: '播放', exact: true }).click();
  84  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(.35);
  85  |   await page.getByRole('button', { name: '暂停', exact: true }).click();
  86  |   const at = await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime);
  87  |   await page.waitForTimeout(1700); await page.reload(); await expect(f.current).toContainText('先统一单位');
  88  |   await page.getByRole('button', { name: '播放', exact: true }).click();
  89  |   await expect.poll(() => page.evaluate(() => (window as any).__whiteboardAudio[0]?.currentTime ?? 0)).toBeGreaterThan(at - .05);
  90  |   expect(await page.evaluate(() => (window as any).__whiteboardAudio[0].currentTime)).toBeLessThan(at + .6);
  91  | });
  92  | 
  93  | test('scoped local resume and complete accessible notes fit phone, tablet and desktop', async ({ page }) => {
  94  |   const f = await fixture(page); await page.getByRole('button', { name: '下一句' }).click();
  95  |   await expect(f.current).toContainText('再合并份数'); await page.waitForTimeout(1700); await page.reload();
  96  |   await expect(f.current).toContainText('再合并份数'); await expect(page.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  97  |   const stored = await page.evaluate(() => Object.entries(localStorage).filter(([key]) => key.startsWith('studyagent.whiteboard.location.v1.')));
  98  |   expect(stored).toHaveLength(1); expect(stored[0][1]).not.toContain('再合并份数');
  99  |   for (const width of [390, 768, 1440]) {
  100 |     await page.setViewportSize({ width, height: 1000 }); await expect(f.current).toBeVisible();
  101 |     expect(await page.locator('.wb-sentence-player').evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
  102 |   }
  103 |   await page.getByRole('button', { name: '关闭白板' }).click();
  104 |   await page.evaluate(([key, value]) => localStorage.setItem(key, JSON.stringify({ ...JSON.parse(value), fingerprint: 'b'.repeat(64) })), stored[0]);
  105 |   await page.reload(); await expect(f.current).toContainText('先统一单位'); await expect(page.locator('.sa-whiteboard-notice')).toContainText('版本不符');
  106 | });
  107 | 
  108 | test('actual WebM has a decoded audio track and the same complete SRT timeline at the selected speed', async ({ page }) => {
  109 |   const f = await fixture(page); await page.getByLabel('播放速度').selectOption('1.25');
  110 |   const download = page.waitForEvent('download'); await page.getByRole('button', { name: '导出视频' }).click(); const video = await download;
  111 |   const directory = browserEvidence('whiteboard-media'); copyFileSync((await video.path())!, join(directory, 'decoded-fixture.webm'));
  112 |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', (await video.path())!], { encoding: 'utf8', windowsHide: true }));
  113 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true);
```