# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: knowledge-report.spec.ts >> knowledge report: late proposed-plan reviews cannot erase the real schedule after activation and refresh
- Location: tests\e2e\knowledge-report.spec.ts:124:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: '本点指导与复测' })
Expected substring: "正在指导"
Received string:    "指导之后，怎样再验证指导记录暂时未能读取，还不能判断是否已有对应计划。重新读取指导安排"
Timeout: 15000ms

Call log:
  - Expect "toContainText" getByRole('region', { name: '本点指导与复测' }) with timeout 15000ms
  - waiting for getByRole('region', { name: '本点指导与复测' })
    9 × locator resolved to <section class="kr-plan" aria-label="本点指导与复测">…</section>
      - unexpected value "指导之后，怎样再验证正在核对这份报告的指导记录…"
    24 × locator resolved to <section class="kr-plan" aria-label="本点指导与复测">…</section>
       - unexpected value "指导之后，怎样再验证指导记录暂时未能读取，还不能判断是否已有对应计划。重新读取指导安排"

```

```yaml
- region "本点指导与复测":
  - heading "指导之后，怎样再验证" [level=4]
  - alert:
    - paragraph: 指导记录暂时未能读取，还不能判断是否已有对应计划。
    - button "重新读取指导安排"
```

# Test source

```ts
  38  |   const directory = browserEvidence('knowledge-report');
  39  |   writeFileSync(join(directory, 'actual-report-original.json'), JSON.stringify(f.report, null, 2) + '\n');
  40  |   await page.screenshot({ path: join(directory, 'report-current.png'), fullPage: true });
  41  |   const workspace = page.getByRole('region', { name: '知识点工作区' }); await expect(workspace).toBeVisible();
  42  |   for (const atomId of f.atomIds) {
  43  |     const estimate = f.report.estimates.find((row: any) => row.atomId === atomId), definition = f.report.definitionContext.atoms.find((row: any) => row.id === atomId);
  44  |     await workspace.getByRole('button', { name: '查看知识点：' + estimate.atomName, exact: true }).click();
  45  |     await expect(workspace.getByRole('heading', { name: estimate.atomName, exact: true, level: 3 })).toBeVisible();
  46  |     await expect(workspace).toContainText(definition.objective); await expect(workspace).toContainText(definition.successCriterion);
  47  |     expect(estimate).toMatchObject({ mastery: null, lower: null, upper: null, status: 'unknown', scoredCount: 0, independentFamilies: 0, algorithmVersion: 'rule-estimate-v3' });
  48  |     const quantification = workspace.getByRole('region', { name: '本点量化与未知项' });
  49  |     await expect(quantification).toContainText('尚未形成有效估计');
  50  |     await expect(quantification).toContainText('不计入能力估计或独立样本');
  51  |     await expect(quantification.getByRole('img')).toHaveCount(0);
  52  |     await expect(workspace.getByRole('region', { name: '本点量化与未知项' })).toContainText('仍需真实间隔复测');
  53  |     await expect(workspace.getByRole('region', { name: '本点表面表现' })).toContainText('选择暂时不会');
  54  |     expect(new URL(page.url()).searchParams.get('reportAtom')).toBe(atomId);
  55  |   }
  56  |   const countBefore = (await f.call('/diagnostics/sessions?' + new URLSearchParams({ studentId: f.studentId, subject: 'math' }))).length;
  57  |   await workspace.getByRole('button', { name: '做一组题验证原因 ↗', exact: true }).click();
  58  |   await expect(page.getByRole('region', { name: '本次评测范围与题组' })).toBeVisible();
  59  |   expect((await f.call('/diagnostics/sessions?' + new URLSearchParams({ studentId: f.studentId, subject: 'math' }))).length).toBe(countBefore);
  60  | });
  61  | 
  62  | test('knowledge report: skipped evidence stays unknown and a point survives reload, back and forward', async ({ page }) => {
  63  |   const f = await fixture(page, 'skip'), workspace = page.getByRole('region', { name: '知识点工作区' });
  64  |   const first = f.report.estimates.find((row: any) => row.atomId === f.atomIds[0]), second = f.report.estimates.find((row: any) => row.atomId === f.atomIds[1]);
  65  |   await workspace.getByRole('button', { name: '查看知识点：' + first.atomName, exact: true }).click();
  66  |   await expect(workspace.getByRole('region', { name: '本点量化与未知项' })).toContainText('尚未形成有效估计');
  67  |   await expect(workspace.getByRole('region', { name: '本点量化与未知项' }).getByText('0%', { exact: true })).toHaveCount(0);
  68  |   await workspace.getByRole('button', { name: '查看知识点：' + second.atomName, exact: true }).click();
  69  |   await page.goBack(); await expect(workspace.getByRole('heading', { name: first.atomName, exact: true, level: 3 })).toBeVisible();
  70  |   await page.goForward(); await expect(workspace.getByRole('heading', { name: second.atomName, exact: true, level: 3 })).toBeVisible();
  71  |   await page.reload(); await expect(workspace.getByRole('heading', { name: second.atomName, exact: true, level: 3 })).toBeVisible();
  72  |   expect(new URL(page.url()).searchParams.get('reportAtom')).toBe(f.atomIds[1]);
  73  |   await workspace.getByRole('searchbox', { name: '查找知识点' }).fill('不存在的合成目标');
  74  |   await expect(workspace).toContainText('没有匹配的知识点'); await expect(workspace.getByRole('heading', { name: second.atomName, exact: true, level: 3 })).toBeVisible();
  75  |   await workspace.getByRole('button', { name: '清空搜索', exact: true }).click();
  76  |   await page.screenshot({ path: join(browserEvidence('knowledge-report'), 'report-first-workspace.png'), fullPage: true });
  77  | });
  78  | 
  79  | async function guidance(f: Awaited<ReturnType<typeof fixture>>) {
  80  |   return f.call('/diagnostics/students/' + f.studentId + '/plans', { baselineSessionId: f.session.id,
  81  |     minutesPerDay: 10, useAi: false, expectedReportVersion: f.report.version ?? 1, requestKey: randomUUID() });
  82  | }
  83  | 
  84  | test('knowledge report: an older matching plan is found behind a newer unrelated report and opens its durable plan route', async ({ page }) => {
  85  |   const f = await fixture(page), original = await guidance(f);
  86  |   const other = await f.call('/diagnostics/sessions', { studentId: f.studentId, subject: 'math', intent: 'baseline',
  87  |     targetAtomIds: [f.atomIds[0]], includePrerequisites: false, adaptive: false, maxItems: 3 });
  88  |   for (const item of other.items) await f.call('/diagnostics/sessions/' + other.id + '/responses', { itemId: item.id, disposition: 'skip', elapsedMs: 1000 });
  89  |   const otherReport = await f.call('/diagnostics/sessions/' + other.id + '/complete', {});
  90  |   const newer = await f.call('/diagnostics/students/' + f.studentId + '/plans', { baselineSessionId: other.id,
  91  |     minutesPerDay: 10, useAi: false, expectedReportVersion: otherReport.version ?? 1, requestKey: randomUUID() });
  92  |   expect(newer.id).not.toBe(original.id); await page.reload();
  93  |   const workspace = page.getByRole('region', { name: '知识点工作区' }), target = f.report.estimates.find((row: any) => row.atomId === original.actions[0].atomId);
  94  |   await workspace.getByRole('button', { name: '查看知识点：' + target.atomName, exact: true }).click();
  95  |   const path = workspace.getByRole('region', { name: '本点指导与复测' }); await expect(path).toHaveAttribute('data-plan-id', original.id);
  96  |   await expect(path).toContainText(original.actions[0].successCriterion);
  97  |   await path.getByRole('button', { name: '查看指导与复测 ↗', exact: true }).click();
  98  |   await expect(page).toHaveURL(new RegExp('planId=' + original.id)); await expect(page.getByRole('button', { name: '确认并开始计划', exact: true })).toBeVisible();
  99  |   await page.reload(); await expect(page.getByRole('button', { name: '确认并开始计划', exact: true })).toBeVisible();
  100 |   await page.goBack(); await expect(workspace.getByRole('heading', { name: target.atomName, exact: true, level: 3 })).toBeVisible();
  101 | });
  102 | 
  103 | test('knowledge report: failed plan reads remain unknown until explicit retry returns the actual matching plan', async ({ page }) => {
  104 |   const f = await fixture(page), plan = await guidance(f); let fail = true;
  105 |   await page.route('**/api/diagnostics/students/*/plans?*', route => fail ? route.fulfill({ status: 503, json: { error: { message: 'Synthetic plan read failure' } } }) : route.continue());
  106 |   await page.reload(); const path = page.getByRole('region', { name: '本点指导与复测' });
  107 |   await expect(path).toContainText('还不能判断是否已有对应计划');
  108 |   await expect(path.getByText(/这份报告尚无对应的指导计划/)).toHaveCount(0);
  109 |   fail = false; await path.getByRole('button', { name: '重新读取指导安排', exact: true }).click();
  110 |   await expect(path).toHaveAttribute('data-plan-id', plan.id); await expect(path.getByRole('button', { name: '查看指导与复测 ↗', exact: true })).toBeVisible();
  111 | });
  112 | 
  113 | test('knowledge report: a controlled missing plan hides its stale actions while the report remains readable and retry can recover', async ({ page }) => {
  114 |   const f = await fixture(page), plan = await guidance(f); let unavailable = true;
  115 |   await page.route('**/api/diagnostics/plans/*/reviews', route => unavailable ? route.fulfill({ status: 404, json: { error: { message: 'Synthetic missing plan' } } }) : route.continue());
  116 |   await page.reload(); const path = page.getByRole('region', { name: '本点指导与复测' });
  117 |   await expect(path).toContainText('这份计划当前无法读取');
  118 |   await expect(path.getByRole('button', { name: '查看指导与复测 ↗', exact: true })).toHaveCount(0);
  119 |   await expect(page.getByRole('region', { name: '本点量化与未知项' })).toBeVisible();
  120 |   unavailable = false; await path.getByRole('button', { name: '重新读取指导安排', exact: true }).click();
  121 |   await expect(path).toHaveAttribute('data-plan-id', plan.id); await expect(path.getByRole('button', { name: '查看指导与复测 ↗', exact: true })).toBeVisible();
  122 | });
  123 | 
  124 | test('knowledge report: late proposed-plan reviews cannot erase the real schedule after activation and refresh', async ({ page }) => {
  125 |   const f = await fixture(page), plan = await guidance(f); let hold = true, blocked = 0, release!: () => void;
  126 |   const gate = new Promise<void>(resolve => { release = resolve; });
  127 |   await page.route('**/api/diagnostics/plans/' + plan.id + '/reviews', async route => {
  128 |     if (!hold) return route.continue(); const response = await route.fetch(); blocked++; await gate;
  129 |     if (page.isClosed() || route.request().failure()) return route.abort('aborted'); return route.fulfill({ response });
  130 |   });
  131 |   try {
  132 |     await page.reload(); await expect.poll(() => blocked).toBeGreaterThan(0);
  133 |     await f.call('/diagnostics/plans/' + plan.id, { status: 'active', expectedRevision: plan.revision ?? 1, requestKey: randomUUID() }, 'PATCH');
  134 |     const schedule = await f.call('/diagnostics/plans/' + plan.id + '/reviews');
  135 |     const first = f.report.estimates[0], expected = schedule.filter((row: any) => row.atomId === first.atomId);
  136 |     expect(expected.length).toBeGreaterThan(0); hold = false;
  137 |     const path = page.getByRole('region', { name: '本点指导与复测' }); await path.getByRole('button', { name: '刷新指导记录', exact: true }).click();
> 138 |     await expect(path).toContainText('正在指导'); await expect(path.locator('.kr-review-list li')).toHaveCount(expected.length);
      |                        ^ Error: expect(locator).toContainText(expected) failed
  139 |     release(); await page.unrouteAll({ behavior: 'wait' });
  140 |     await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  141 |     await expect(path.locator('.kr-review-list li')).toHaveCount(expected.length);
  142 |     await page.screenshot({ path: join(browserEvidence('knowledge-report'), 'actual-active-guidance-schedule.png'), fullPage: true });
  143 |   } finally { release(); }
  144 | });
  145 | 
  146 | test('knowledge report: a controlled legacy definition and foreign point never create a current verification', async ({ page }) => {
  147 |   const f = await fixture(page); let starts = 0;
  148 |   await page.route('**/api/diagnostics/sessions/' + f.session.id + '/report', async route => {
  149 |     const response = await route.fetch(), payload = await response.json(); payload.data.definitionContext.origin = 'unavailable';
  150 |     await route.fulfill({ response, json: payload });
  151 |   });
  152 |   page.on('request', request => { if (request.method() === 'POST' && /\/diagnostics\/(?:blueprints|sessions)$/.test(new URL(request.url()).pathname)) starts++; });
  153 |   await page.goto(f.href + '&reportAtom=foreign-unavailable-point'); const workspace = page.getByRole('region', { name: '知识点工作区' });
  154 |   await expect(workspace).toContainText('链接中的知识点不在这份报告中');
  155 |   await expect(workspace.getByRole('region', { name: '本点冻结目标' })).toContainText('未保留可核对的目标定义');
  156 |   await expect(workspace.getByRole('button', { name: /做一组题验证原因|预览本点的独立题组/ })).toHaveCount(0);
  157 |   expect(new URL(page.url()).searchParams.has('reportAtom')).toBe(false); expect(starts).toBe(0);
  158 | });
  159 | 
  160 | test('knowledge report: the actual student role reads its report without management actions and grant revocation ends the private view', async ({ page }) => {
  161 |   const f = await fixture(page); await guidance(f);
  162 |   await f.call('/students/' + f.studentId + '/learning-access', { enabled: true, expectedVersion: 0, requestKey: randomUUID(), reason: '合成报告权限测试' });
  163 |   const issued = await f.call('/students/' + f.studentId + '/learning-access/codes', { expectedVersion: 1, requestKey: randomUUID() });
  164 |   await page.goto('/student/login'); await page.getByLabel('一次性学习码').fill(issued.code); await page.getByRole('button', { name: '进入我的学习 →', exact: true }).click();
  165 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/); await page.goto(f.href);
  166 |   const workspace = page.getByRole('region', { name: '知识点工作区' }); await expect(workspace).toBeVisible();
  167 |   await expect(workspace.getByRole('button', { name: '查看指导与复测 ↗', exact: true })).toHaveCount(0);
  168 |   await expect(page.getByRole('button', { name: /制定指导计划|确认并开始计划/ })).toHaveCount(0);
  169 |   await f.call('/students/' + f.studentId + '/learning-access', { enabled: false, expectedVersion: 1, requestKey: randomUUID(), reason: '合成报告撤权测试' });
  170 |   await workspace.getByRole('button', { name: '刷新指导记录', exact: true }).click(); await expect(workspace).toHaveCount(0);
  171 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  172 | });
  173 | 
  174 | test('knowledge report: invalidating the actual browser login session ends the private report on its next read', async ({ page }) => {
  175 |   await fixture(page); const workspace = page.getByRole('region', { name: '知识点工作区' });
  176 |   expect(await page.evaluate(async base => (await fetch(base + '/auth/logout', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status, api)).toBe(201);
  177 |   await workspace.getByRole('button', { name: '刷新指导记录', exact: true }).click(); await expect(workspace).toHaveCount(0);
  178 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  179 | });
  180 | 
  181 | test('knowledge report: actual submitted short-answer expressions awaiting review do not become scored failure or a zero estimate', async ({ page }) => {
  182 |   const f = await fixture(page), atomId = 'core:chinese:evidence-explanation';
  183 |   await f.call('/students/' + f.studentId + '/learning-scope', { subject: 'chinese', grade: 4, term: 'upper', textbookVolumeId: null,
  184 |     textbookVersion: '合成已学语文范围', learnedAtomIds: [atomId], currentAtomId: atomId, minutesPerSession: 10,
  185 |     progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  186 |   const session = await f.call('/diagnostics/sessions', { studentId: f.studentId, subject: 'chinese', intent: 'baseline',
  187 |     targetAtomIds: [atomId], includePrerequisites: false, adaptive: false, maxItems: 6 }); let expressions = 0;
  188 |   for (const item of session.items) {
  189 |     const question = await f.call('/diagnostics/sessions/' + session.id + '/items/' + item.id);
  190 |     if (question.payload.answerSchema.mode === 'short_answer') {
  191 |       expressions++; await f.call('/diagnostics/sessions/' + session.id + '/responses', { itemId: item.id, disposition: 'answered', elapsedMs: 2000,
  192 |         answer: { questionId: question.payload.question.id, mode: 'short_answer', response: { value: '我先提出判断，再用材料中的具体事实说明依据。' } } });
  193 |     } else await f.call('/diagnostics/sessions/' + session.id + '/responses', { itemId: item.id, disposition: 'skip', elapsedMs: 1000 });
  194 |   }
  195 |   expect(expressions).toBeGreaterThan(0); const report = await f.call('/diagnostics/sessions/' + session.id + '/complete', {});
  196 |   expect(report.pendingReviewCount).toBe(expressions); expect(report.estimates[0].mastery).toBeNull();
  197 |   writeFileSync(join(browserEvidence('knowledge-report'), 'actual-pending-review-report.json'), JSON.stringify(report, null, 2) + '\n');
  198 |   await page.goto('/student/assessment?' + new URLSearchParams({ studentId: f.studentId, subject: 'chinese', session: session.id }));
  199 |   const quant = page.getByRole('region', { name: '本点量化与未知项' }), surface = page.getByRole('region', { name: '本点表面表现' });
  200 |   await expect(quant).toContainText('尚未形成有效估计'); await expect(quant.getByText('0%', { exact: true })).toHaveCount(0);
  201 |   await expect(surface).toContainText('表达待复核 ' + expressions + ' 次'); await surface.locator(':scope > details > summary').click();
  202 |   await expect(surface.getByText('表达待复核', { exact: true })).toHaveCount(expressions);
  203 |   await expect(surface.getByText('本题需要核查', { exact: true })).toHaveCount(0);
  204 | });
  205 | 
  206 | test('knowledge report: a controlled cause timeline remains complete and terminal versus reopened actions stay with their point', async ({ page }) => {
  207 |   const f = await fixture(page);
  208 |   await page.route('**/api/diagnostics/sessions/' + f.session.id + '/report', async route => {
  209 |     const response = await route.fetch(), payload = await response.json();
  210 |     payload.data.hypotheses = f.atomIds.map((atomId, index) => {
  211 |       const original = payload.data.hypotheses.find((row: any) => row.atomId === atomId);
  212 |       return { ...original, status: index ? 'reopened' : 'contradicted', history: Array.from({ length: 9 }, (_, position) => ({
  213 |         at: new Date(Date.UTC(2026, 9, position + 1)).toISOString(), status: position === 8 ? index ? 'reopened' : 'contradicted' : 'testing',
  214 |         reason: '合成状态展示 ' + (position + 1) + ' · 目标' + index,
  215 |       })) };
  216 |     });
  217 |     writeFileSync(join(browserEvidence('knowledge-report'), 'controlled-cause-history-projection.json'), JSON.stringify(payload.data, null, 2) + '\n');
  218 |     await route.fulfill({ response, json: payload });
  219 |   });
  220 |   await page.reload(); const workspace = page.getByRole('region', { name: '知识点工作区' }), cause = workspace.getByRole('region', { name: '本点原因与验证' });
  221 |   await expect(cause).toContainText('已有反证'); await expect(cause.getByRole('button', { name: '做一组题验证原因 ↗', exact: true })).toHaveCount(0);
  222 |   await cause.locator('summary').filter({ hasText: '这条判断怎样变化' }).click(); await expect(cause.locator('.kr-cause-history li')).toHaveCount(9);
  223 |   await expect(cause).toContainText('合成状态展示 1 · 目标0'); await expect(cause).toContainText('合成状态展示 9 · 目标0');
  224 |   const second = f.report.estimates.find((row: any) => row.atomId === f.atomIds[1]);
  225 |   await workspace.getByRole('button', { name: '查看知识点：' + second.atomName, exact: true }).click();
  226 |   await expect(cause).toContainText('需要再次核查'); await expect(cause.getByRole('button', { name: '做一组题验证原因 ↗', exact: true })).toBeEnabled();
  227 |   await expect(cause.getByText('合成状态展示 9 · 目标0', { exact: true })).toHaveCount(0);
  228 | });
  229 | 
  230 | for (const width of [390, 768, 1280, 1440]) test('knowledge report: complete point reading and keyboard controls fit ' + width, async ({ page }) => {
  231 |   await page.setViewportSize({ width, height: 1000 }); const f = await fixture(page), workspace = page.getByRole('region', { name: '知识点工作区' });
  232 |   const target = f.report.estimates[1], button = workspace.getByRole('button', { name: '查看知识点：' + target.atomName, exact: true });
  233 |   await button.focus(); await page.keyboard.press('Enter'); await expect(button).toHaveAttribute('aria-pressed', 'true');
  234 |   expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  235 |   await expect(workspace.getByRole('heading', { name: target.atomName, level: 3, exact: true })).toBeVisible();
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  237 |   const detail = workspace.getByRole('region', { name: '本点表面表现' }); await detail.locator(':scope > details > summary').click();
  238 |   const response = f.report.evidence.find((row: any) => row.atomId === target.atomId), original = await f.call('/diagnostics/students/' + f.studentId + '/evidence/' + response.id);
```