# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: knowledge-report.spec.ts >> knowledge report: complete point reading and keyboard controls fit 768
- Location: tests\e2e\knowledge-report.spec.ts:230:49

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: '知识点工作区' }).getByRole('region', { name: '本点表面表现' }).locator('.diagnostic-evidence').first()
Expected substring: "表中是连续各天的完整跳绳记录，每一天都参与统计，0次表示当天没有跳成。求平均每天跳成几次，有人说“总次数应平均分成6份”。这个分母选择正确吗？"
Received string:    "展开当时题目与作答尝试次数过多，请稍后重试重新读取"
Timeout: 15000ms

Call log:
  - Expect "toContainText" getByRole('region', { name: '知识点工作区' }).getByRole('region', { name: '本点表面表现' }).locator('.diagnostic-evidence').first() with timeout 15000ms
  - waiting for getByRole('region', { name: '知识点工作区' }).getByRole('region', { name: '本点表面表现' }).locator('.diagnostic-evidence').first()
    33 × locator resolved to <details open="" class="diagnostic-evidence">…</details>
       - unexpected value "展开当时题目与作答尝试次数过多，请稍后重试重新读取"

```

```yaml
- group:
  - text: 展开当时题目与作答
  - alert:
    - paragraph: 尝试次数过多，请稍后重试
    - button "重新读取"
```

# Test source

```ts
  140 |     await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  141 |     await expect(path.locator('.kr-review-list li')).toHaveCount(expected.length);
  142 |     await page.screenshot({ path: join(browserEvidence('knowledge-report'), 'actual-active-guidance-schedule.png'), fullPage: true });
  143 |   } finally { release(); }
  144 | });
  145 | 
  146 | test('knowledge report: a controlled legacy definition and foreign point never create a current verification', async ({ page }) => {
  147 |   const f = await fixture(page); let starts = 0;
  148 |   await page.route('**/api/diagnostics/sessions/' + f.session.id + '/report', async route => {
  149 |     const response = await route.fetch(), payload = await response.json(); payload.data.definitionContext.origin = 'unavailable';
  150 |     await route.fulfill({ response, json: payload });
  151 |   });
  152 |   page.on('request', request => { if (request.method() === 'POST' && /\/diagnostics\/(?:blueprints|sessions)$/.test(new URL(request.url()).pathname)) starts++; });
  153 |   await page.goto(f.href + '&reportAtom=foreign-unavailable-point'); const workspace = page.getByRole('region', { name: '知识点工作区' });
  154 |   await expect(workspace).toContainText('链接中的知识点不在这份报告中');
  155 |   await expect(workspace.getByRole('region', { name: '本点冻结目标' })).toContainText('未保留可核对的目标定义');
  156 |   await expect(workspace.getByRole('button', { name: /做一组题验证原因|预览本点的独立题组/ })).toHaveCount(0);
  157 |   expect(new URL(page.url()).searchParams.has('reportAtom')).toBe(false); expect(starts).toBe(0);
  158 | });
  159 | 
  160 | test('knowledge report: the actual student role reads its report without management actions and grant revocation ends the private view', async ({ page }) => {
  161 |   const f = await fixture(page); await guidance(f);
  162 |   await f.call('/students/' + f.studentId + '/learning-access', { enabled: true, expectedVersion: 0, requestKey: randomUUID(), reason: '合成报告权限测试' });
  163 |   const issued = await f.call('/students/' + f.studentId + '/learning-access/codes', { expectedVersion: 1, requestKey: randomUUID() });
  164 |   await page.goto('/student/login'); await page.getByLabel('一次性学习码').fill(issued.code); await page.getByRole('button', { name: '进入我的学习 →', exact: true }).click();
  165 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/); await page.goto(f.href);
  166 |   const workspace = page.getByRole('region', { name: '知识点工作区' }); await expect(workspace).toBeVisible();
  167 |   await expect(workspace.getByRole('button', { name: '查看指导与复测 ↗', exact: true })).toHaveCount(0);
  168 |   await expect(page.getByRole('button', { name: /制定指导计划|确认并开始计划/ })).toHaveCount(0);
  169 |   await f.call('/students/' + f.studentId + '/learning-access', { enabled: false, expectedVersion: 1, requestKey: randomUUID(), reason: '合成报告撤权测试' });
  170 |   await workspace.getByRole('button', { name: '刷新指导记录', exact: true }).click(); await expect(workspace).toHaveCount(0);
  171 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  172 | });
  173 | 
  174 | test('knowledge report: invalidating the actual browser login session ends the private report on its next read', async ({ page }) => {
  175 |   await fixture(page); const workspace = page.getByRole('region', { name: '知识点工作区' });
  176 |   expect(await page.evaluate(async base => (await fetch(base + '/auth/logout', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status, api)).toBe(201);
  177 |   await workspace.getByRole('button', { name: '刷新指导记录', exact: true }).click(); await expect(workspace).toHaveCount(0);
  178 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  179 | });
  180 | 
  181 | test('knowledge report: actual submitted short-answer expressions awaiting review do not become scored failure or a zero estimate', async ({ page }) => {
  182 |   const f = await fixture(page), atomId = 'core:chinese:evidence-explanation';
  183 |   await f.call('/students/' + f.studentId + '/learning-scope', { subject: 'chinese', grade: 4, term: 'upper', textbookVolumeId: null,
  184 |     textbookVersion: '合成已学语文范围', learnedAtomIds: [atomId], currentAtomId: atomId, minutesPerSession: 10,
  185 |     progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  186 |   const session = await f.call('/diagnostics/sessions', { studentId: f.studentId, subject: 'chinese', intent: 'baseline',
  187 |     targetAtomIds: [atomId], includePrerequisites: false, adaptive: false, maxItems: 6 }); let expressions = 0;
  188 |   for (const item of session.items) {
  189 |     const question = await f.call('/diagnostics/sessions/' + session.id + '/items/' + item.id);
  190 |     if (question.payload.answerSchema.mode === 'short_answer') {
  191 |       expressions++; await f.call('/diagnostics/sessions/' + session.id + '/responses', { itemId: item.id, disposition: 'answered', elapsedMs: 2000,
  192 |         answer: { questionId: question.payload.question.id, mode: 'short_answer', response: { value: '我先提出判断，再用材料中的具体事实说明依据。' } } });
  193 |     } else await f.call('/diagnostics/sessions/' + session.id + '/responses', { itemId: item.id, disposition: 'skip', elapsedMs: 1000 });
  194 |   }
  195 |   expect(expressions).toBeGreaterThan(0); const report = await f.call('/diagnostics/sessions/' + session.id + '/complete', {});
  196 |   expect(report.pendingReviewCount).toBe(expressions); expect(report.estimates[0].mastery).toBeNull();
  197 |   writeFileSync(join(browserEvidence('knowledge-report'), 'actual-pending-review-report.json'), JSON.stringify(report, null, 2) + '\n');
  198 |   await page.goto('/student/assessment?' + new URLSearchParams({ studentId: f.studentId, subject: 'chinese', session: session.id }));
  199 |   const quant = page.getByRole('region', { name: '本点量化与未知项' }), surface = page.getByRole('region', { name: '本点表面表现' });
  200 |   await expect(quant).toContainText('尚未形成有效估计'); await expect(quant.getByText('0%', { exact: true })).toHaveCount(0);
  201 |   await expect(surface).toContainText('表达待复核 ' + expressions + ' 次'); await surface.locator(':scope > details > summary').click();
  202 |   await expect(surface.getByText('表达待复核', { exact: true })).toHaveCount(expressions);
  203 |   await expect(surface.getByText('本题需要核查', { exact: true })).toHaveCount(0);
  204 | });
  205 | 
  206 | test('knowledge report: a controlled cause timeline remains complete and terminal versus reopened actions stay with their point', async ({ page }) => {
  207 |   const f = await fixture(page);
  208 |   await page.route('**/api/diagnostics/sessions/' + f.session.id + '/report', async route => {
  209 |     const response = await route.fetch(), payload = await response.json();
  210 |     payload.data.hypotheses = f.atomIds.map((atomId, index) => {
  211 |       const original = payload.data.hypotheses.find((row: any) => row.atomId === atomId);
  212 |       return { ...original, status: index ? 'reopened' : 'contradicted', history: Array.from({ length: 9 }, (_, position) => ({
  213 |         at: new Date(Date.UTC(2026, 9, position + 1)).toISOString(), status: position === 8 ? index ? 'reopened' : 'contradicted' : 'testing',
  214 |         reason: '合成状态展示 ' + (position + 1) + ' · 目标' + index,
  215 |       })) };
  216 |     });
  217 |     writeFileSync(join(browserEvidence('knowledge-report'), 'controlled-cause-history-projection.json'), JSON.stringify(payload.data, null, 2) + '\n');
  218 |     await route.fulfill({ response, json: payload });
  219 |   });
  220 |   await page.reload(); const workspace = page.getByRole('region', { name: '知识点工作区' }), cause = workspace.getByRole('region', { name: '本点原因与验证' });
  221 |   await expect(cause).toContainText('已有反证'); await expect(cause.getByRole('button', { name: '做一组题验证原因 ↗', exact: true })).toHaveCount(0);
  222 |   await cause.locator('summary').filter({ hasText: '这条判断怎样变化' }).click(); await expect(cause.locator('.kr-cause-history li')).toHaveCount(9);
  223 |   await expect(cause).toContainText('合成状态展示 1 · 目标0'); await expect(cause).toContainText('合成状态展示 9 · 目标0');
  224 |   const second = f.report.estimates.find((row: any) => row.atomId === f.atomIds[1]);
  225 |   await workspace.getByRole('button', { name: '查看知识点：' + second.atomName, exact: true }).click();
  226 |   await expect(cause).toContainText('需要再次核查'); await expect(cause.getByRole('button', { name: '做一组题验证原因 ↗', exact: true })).toBeEnabled();
  227 |   await expect(cause.getByText('合成状态展示 9 · 目标0', { exact: true })).toHaveCount(0);
  228 | });
  229 | 
  230 | for (const width of [390, 768, 1280, 1440]) test('knowledge report: complete point reading and keyboard controls fit ' + width, async ({ page }) => {
  231 |   await page.setViewportSize({ width, height: 1000 }); const f = await fixture(page), workspace = page.getByRole('region', { name: '知识点工作区' });
  232 |   const target = f.report.estimates[1], button = workspace.getByRole('button', { name: '查看知识点：' + target.atomName, exact: true });
  233 |   await button.focus(); await page.keyboard.press('Enter'); await expect(button).toHaveAttribute('aria-pressed', 'true');
  234 |   expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  235 |   await expect(workspace.getByRole('heading', { name: target.atomName, level: 3, exact: true })).toBeVisible();
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  237 |   const detail = workspace.getByRole('region', { name: '本点表面表现' }); await detail.locator(':scope > details > summary').click();
  238 |   const response = f.report.evidence.find((row: any) => row.atomId === target.atomId), original = await f.call('/diagnostics/students/' + f.studentId + '/evidence/' + response.id);
  239 |   const source = detail.locator('.diagnostic-evidence').first(); await source.locator(':scope > summary').click();
> 240 |   await expect(source).toContainText(original.stem); await expect(source.getByRole('heading', { name: '孩子提交的回答', exact: true })).toBeVisible();
      |                        ^ Error: expect(locator).toContainText(expected) failed
  241 |   await page.screenshot({ path: join(browserEvidence('knowledge-report'), 'point-' + width + '.png'), fullPage: true });
  242 | });
  243 | 
  244 | test('knowledge report: a lost reanalysis receipt survives reload with the exact original command', async ({ page }) => {
  245 |   const f = await fixture(page); const requests: unknown[] = [];
  246 |   // Controlled compatibility projection exercises the browser protocol. Real version appends are tested through HTTP.
  247 |   await page.route('**/api/diagnostics/sessions/*/analysis-status', async route => {
  248 |     const response = await route.fetch(), payload = await response.json();
  249 |     payload.data.requiresReanalysis = requests.length < 2; payload.data.canReanalyze = true;
  250 |     payload.data.reasons = ['合成旧方法状态，仅核查浏览器原命令恢复'];
  251 |     await route.fulfill({ response, json: payload });
  252 |   });
  253 |   await page.route('**/api/diagnostics/sessions/*/reanalyze', async route => {
  254 |     requests.push(route.request().postDataJSON());
  255 |     if (requests.length === 1) { await route.fetch(); await route.abort('failed'); }
  256 |     else await route.continue();
  257 |   });
  258 |   const before = await f.call('/diagnostics/sessions/' + f.session.id + '/report-history');
  259 |   await page.reload(); await page.getByRole('button', { name: '按原作答重新分析', exact: true }).click();
  260 |   await expect(page.getByRole('button', { name: '恢复原核对结果', exact: true })).toBeVisible();
  261 |   await page.reload(); await page.getByRole('button', { name: '恢复原核对结果', exact: true }).click();
  262 |   await expect.poll(() => requests.length).toBe(2); expect(requests[1]).toEqual(requests[0]);
  263 |   await expect(page.getByRole('region', { name: '重新核对报告依据' })).toHaveCount(0);
  264 |   expect(await f.call('/diagnostics/sessions/' + f.session.id + '/report-history')).toEqual(before);
  265 | });
  266 | 
  267 | test('knowledge report: a version conflict archives its original command before a read-only latest-report check', async ({ page }) => {
  268 |   const f = await fixture(page); let creates = 0, submitted: unknown;
  269 |   await page.route('**/api/diagnostics/sessions/*/analysis-status', async route => {
  270 |     const response = await route.fetch(), payload = await response.json(); payload.data.requiresReanalysis = true; payload.data.canReanalyze = true;
  271 |     await route.fulfill({ response, json: payload });
  272 |   });
  273 |   await page.route('**/api/diagnostics/sessions/*/reanalyze', async route => {
  274 |     creates++; submitted = route.request().postDataJSON();
  275 |     await route.fulfill({ status: 409, json: { error: { message: '合成并发版本冲突，原命令尚未执行' } } });
  276 |   });
  277 |   await page.reload(); await page.getByRole('button', { name: '按原作答重新分析', exact: true }).click();
  278 |   await page.getByRole('button', { name: '保留原操作副本，查看最新报告', exact: true }).click();
  279 |   await expect(page.getByText('本机原核对操作副本（1）', { exact: true })).toBeVisible();
  280 |   expect(creates).toBe(1);
  281 |   await page.getByText('本机原核对操作副本（1）', { exact: true }).click();
  282 |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '下载原操作副本 1', exact: true }).click();
  283 |   const download = await downloaded, path = await download.path();
  284 |   const raw = JSON.parse(require('node:fs').readFileSync(path!, 'utf8'));
  285 |   expect({ requestKey: raw.requestKey, expectedReportVersion: raw.expectedReportVersion, reason: raw.reason }).toEqual(submitted);
  286 |   await page.reload(); await expect(page.getByText('本机原核对操作副本（1）', { exact: true })).toBeVisible();
  287 |   expect(creates).toBe(1);
  288 | });
  289 | 
  290 | test('knowledge report: unavailable command storage prevents a new mutation while preserving the report', async ({ page }) => {
  291 |   await fixture(page); let creates = 0;
  292 |   await page.addInitScript(() => {
  293 |     const write = Storage.prototype.setItem;
  294 |     Storage.prototype.setItem = function (key, value) {
  295 |       if (key.startsWith('studyagent.report-analysis-command.v1:')) throw new DOMException('Synthetic storage quota', 'QuotaExceededError');
  296 |       return write.call(this, key, value);
  297 |     };
  298 |   });
  299 |   await page.route('**/api/diagnostics/sessions/*/analysis-status', async route => {
  300 |     const response = await route.fetch(), payload = await response.json(); payload.data.requiresReanalysis = true; payload.data.canReanalyze = true;
  301 |     await route.fulfill({ response, json: payload });
  302 |   });
  303 |   await page.route('**/api/diagnostics/sessions/*/reanalyze', route => { creates++; return route.continue(); });
  304 |   await page.reload(); await page.getByRole('button', { name: '按原作答重新分析', exact: true }).click();
  305 |   await expect(page.getByRole('alert').filter({ hasText: 'Synthetic storage quota' })).toBeVisible();
  306 |   await expect(page.getByRole('region', { name: '本点量化与未知项' })).toContainText('尚未形成有效估计');
  307 |   expect(creates).toBe(0);
  308 | });
  309 | 
```