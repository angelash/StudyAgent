const cp=require('node:child_process'),original=cp.spawn;
cp.spawn=(command,args,options)=>original(command,Array.isArray(args)&&args.includes('../../node_modules/vitest/vitest.mjs')?[...args,'--maxWorkers=1','-t','postgres original guidance plans native recovery']:args,options);
require('../../scripts/qa/run-guidance-models-postgres.cjs');
