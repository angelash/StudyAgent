const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),root=process.cwd();
const source=n=>require(path.join(root,'apps/api/dist/apps/api/src',n+'.js'));
const definitions=source('modules/diagnostics/chemistry-curriculum').buildChemistryCurriculum();
const course=source('modules/learning/chemistry-course').buildChemistryCourse('anonymous-tutorial-source',definitions.map(d=>d.atom));
const {primaryUnitTeachingCatalog}=source('modules/ai/assistant-teaching-content'),{curriculumClassroomLesson}=source('modules/learning/classroom-curriculum');
const old=structuredClone(course);delete old.teachingVersion;const rows=[];
for(const unit of course.units){const catalog=primaryUnitTeachingCatalog(course,unit.id),text=JSON.stringify(catalog);
 for(const learn of unit.lessons.filter(l=>l.kind==='learn')){const actual=curriculumClassroomLesson(course,learn),blocks=actual.steps.flatMap(s=>s.blocks),figure=blocks.find(b=>b.kind==='image'),model=blocks.find(b=>b.kind==='experiment');
 rows.push({lessonId:learn.id,actualFigure:!!figure,catalogContainsFigureCaption:figure?text.includes(figure.image.caption):null,actualExperiment:model?.experiment.kind??null,catalogContainsExperimentObservation:model?text.includes(model.experiment.observation):null});}}
const current=primaryUnitTeachingCatalog(course,course.units[0].id),legacy=primaryUnitTeachingCatalog(old,old.units[0].id);
const result={scope:'Pure actual authored course and the same classroom builder; no learner records, HTTP model calls or production writes.',passed:false,teachingVersion:course.teachingVersion,lessons:rows.length,missingFigures:rows.filter(r=>r.actualFigure&&!r.catalogContainsFigureCaption).length,experiments:rows.filter(r=>r.actualExperiment).length,missingExperimentObservations:rows.filter(r=>r.actualExperiment&&!r.catalogContainsExperimentObservation).length,oldAndNewCatalogsIdentical:JSON.stringify(current)===JSON.stringify(legacy),rows};
const out=path.join(root,'data/qa/chemistry-v2-assistant-gap-before.json');if(fs.existsSync(out))throw Error('Original gap receipt exists');fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,rows:undefined}));
