const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');require('reflect-metadata');
const root=process.cwd(),out=path.join(root,'data/qa/artifact143-preflight-before.json');if(fs.existsSync(out))throw Error('Original before receipt exists');
const dir=fs.mkdtempSync(path.join(root,'data/qa/artifact143-before-'));
Object.assign(process.env,{NODE_ENV:'development',STUDY_STORAGE:'sqlite',STUDY_DATA_DIR:dir,STUDY_WORKER_ENABLED:'false',STUDY_SEED_FOUNDATION:'false',XIAOJIU_CHAT_ENABLED:'false',OPENAI_API_KEY:'',MINIMAX_API_KEY:''});
const src=n=>require(path.join(root,'apps/api/dist/apps/api/src',n+'.js'));const {NestFactory}=require('@nestjs/core');
(async()=>{let app;const evidence={scope:'Owned anonymous before-implementation HTTP scenario. No production records or real model calls.',passed:false};try{
 app=await NestFactory.create(src('app.module').AppModule,{logger:false});app.setGlobalPrefix('api');await app.listen(0,'127.0.0.1');const base='http://127.0.0.1:'+app.getHttpServer().address().port+'/api';
 const store=app.get(src('infrastructure/in-memory-store.service').InMemoryStoreService);
 const register=await fetch(base+'/auth/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({principal:'artifact-before-'+crypto.randomUUID()+'@local.test',credential:'Artifact-QA-'+crypto.randomUUID()})});if(register.status!==201)throw Error('Synthetic register failed');const actor=(await register.json()).data;
 const headers={'Content-Type':'application/json',Authorization:'Bearer '+actor.token};
 const opened=await fetch(base+'/ai/assistant/sessions',{method:'POST',headers,body:JSON.stringify({userRole:'parent',studentId:null,subject:null,pageContext:'studio'})});if(opened.status!==201)throw Error('Independent session did not open');const session=(await opened.json()).data;
 let id;await store.transaction(()=>{id=store.nextId('assistant_message');store.append('assistantMessages',{id,sessionId:session.id,sender:'assistant',content:'匿名完整讲解：先核对比较单位，再比较数量。',createdAt:new Date().toISOString(),source:'rules',modelId:null,modelName:null});});
 const before=await store.requestContext(()=>crypto.createHash('sha256').update(JSON.stringify(store.inspect('assistantMessages'))).digest('hex'));
 const response=await fetch(base+'/ai/assistant/sessions/'+session.id+'/artifacts/preflight',{method:'POST',headers,body:JSON.stringify({kind:'verbatim_note',selection:{messageIds:[id],includeLinkedQuestions:false},objective:'保留这条完整解释'})});
 const body=await response.json();if(response.status!==404)throw Error('Expected original missing route404');
 const after=await store.requestContext(()=>crypto.createHash('sha256').update(JSON.stringify(store.inspect('assistantMessages'))).digest('hex'));
 Object.assign(evidence,{passed:true,missingCapabilityConfirmed:true,httpStatus:response.status,message:body.error?.message??null,originalMessageUnchanged:before===after,sourceRevision:require('node:child_process').execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),modelCalls:0});
} catch(error){evidence.error=error.stack;process.exitCode=1;} finally{await app?.close();fs.writeFileSync(out,JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence));}})();
