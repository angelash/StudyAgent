import { test, expect, type Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { syntheticFamilyHeaders } from './synthetic-family';
import { browserEvidence } from './evidence';
const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api', evidence = browserEvidence('assistant-notes');
async function call(actor: any, path: string, body?: unknown) {
  const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'content-type': 'application/json', Authorization: 'Bearer ' + actor.token }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
}
async function fixture(page: Page) {
  const principal = 'note-ui-' + crypto.randomUUID() + '@local.test', credential = 'Synthetic-note-ui-' + crypto.randomUUID();
  const response = await fetch(api + '/auth/register', { method: 'POST', headers: await syntheticFamilyHeaders(page), body: JSON.stringify({ principal, credential }) }); expect(response.status).toBe(201); const actor = (await response.json()).data;
  await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请保留具体条件和反例。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  const history = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = history.messages.find((m: any) => m.sender === 'assistant');
  const href = '/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + d.fingerprint;
  await page.goto(href); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  const base = '/ai/assistant/sessions/' + session.id + '/artifacts/notes'; return { actor, session, message, question: history.messages.find((m: any) => m.sender === 'user'), href, base };
}
const panel = (page: Page) => page.getByRole('dialog', { name: '私人学习笔记', exact: true });
async function enter(page: Page, message: any) { await page.locator('[data-message-id="' + message.id + '"]').getByRole('button', { name: '整理为笔记', exact: true }).click(); await expect(panel(page)).toBeVisible(); }
async function create(page: Page) {
  const dialog = panel(page); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByText(/完整来源 \d+ \/ 18000 字符/)).toBeVisible();
  await dialog.getByRole('button', { name: '保存逐字候选', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toBeEnabled();
}
for (const width of [390, 768, 880, 1440]) test('assistant notes: original source, explicit editing/adoption/export and original-message return at' + width, async ({ page }) => {
  test.setTimeout(120000); await page.setViewportSize({ width, height: 960 }); const f = await fixture(page), composer = page.getByLabel('想一起看看什么', { exact: true }); await composer.fill('原助教的完整未发送草稿。');
  const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:$|\/[^/]+\/turns$)/.test(new URL(r.url()).pathname)) posts.push(r.url()); });
  await enter(page, f.message); const dialog = panel(page); await dialog.getByLabel('同时包含回答关联的原问题').check(); await dialog.getByLabel('笔记标题').fill('条件、证据与反例'); await create(page);
  await expect(dialog.locator('.assistant-notes-original')).toContainText(f.message.content); await expect(dialog.locator('.assistant-notes-original article')).toHaveCount(2);
  const edited = '  完整编辑稿\n|条件|证据|\n|---|---|\n|匿名观察|保持完整|\n公式 $a+b$\n```js\nconsole.log("不执行");\n```\n<script>window.noteInjected=true</script>\n  ';
  await dialog.getByLabel('笔记编辑稿').fill(edited); await expect(dialog.getByRole('button', { name: '采用这份笔记', exact: true })).toBeDisabled();
  await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click(); await expect(dialog.getByLabel('我已核对原文和编辑稿')).toBeEnabled(); await dialog.getByLabel('我已核对原文和编辑稿').check();
  await dialog.getByRole('button', { name: '采用这份笔记', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toHaveAttribute('readonly', ''); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(edited);
  const reading = dialog.getByRole('region', { name: '笔记阅读稿', exact: true }); await expect(reading.getByRole('columnheader')).toHaveCount(2); await expect(reading.getByRole('cell', { name: '匿名观察', exact: true })).toBeVisible(); await expect(reading.locator('math')).toHaveCount(1); await expect(reading.getByLabel('笔记代码原文')).toContainText('console.log("不执行");');
  const saved = await call(f.actor, f.base); expect(saved.items).toHaveLength(1); expect(saved.items[0].status).toBe('confirmed');
  const original = await call(f.actor, f.base + '/' + saved.items[0].id); expect(original.origin.messages.some((m: any) => m.content === f.message.content)).toBe(true);
  const jsonDownload = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载完整JSON', exact: true }).click(); const jsonFile = await jsonDownload, json = JSON.parse(await readFile((await jsonFile.path())!, 'utf8')); expect(json.markdown).toBe(edited); expect(json.origin).toEqual(original.origin); expect(JSON.stringify(json)).not.toMatch(/requestKey|commands|tokenHash/);
  const mdDownload = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载完整Markdown', exact: true }).click(); const mdFile = await mdDownload; expect(await readFile((await mdFile.path())!, 'utf8')).toContain(edited);
  expect(await page.evaluate(() => (window as any).noteInjected)).toBeUndefined(); expect(await dialog.evaluate(node => node.getBoundingClientRect().right <= innerWidth && node.getBoundingClientRect().left >= 0)).toBe(true);
  await page.screenshot({ path: evidence + '/confirmed-' + width + '.png' }); await dialog.getByRole('button', { name: '返回原消息', exact: true }).click();
  await expect(dialog).toHaveCount(0); await expect(composer).toHaveValue('原助教的完整未发送草稿。'); await expect(page.locator('[data-message-id="' + f.message.id + '"]')).toBeFocused(); expect(posts).toEqual([]);
});

test('assistant notes: a committed create with a lost HTTP reply survives refresh and recovers without another create', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); let count = 0;
  await page.route('**/api/ai/assistant/sessions/*/artifacts/notes', async route => { if (route.request().method() !== 'POST') return route.continue(); count++; const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed'); });
  await enter(page, f.message); const dialog = panel(page); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '保存逐字候选', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '保存逐字候选', exact: true }).click();
  await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toBeVisible(); await expect(dialog.getByRole('alert')).toContainText('原操作仍保留');
  await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(page, f.message); await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toBeVisible();
  await dialog.getByRole('button', { name: '核对原操作', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toBeEnabled(); await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toHaveCount(0);
  expect(count).toBe(1); expect((await call(f.actor, f.base)).items).toHaveLength(1); await page.screenshot({ path: evidence + '/original-request-recovered.png' });
});

test('assistant notes: offline local editing, independent draft and Escape focus survive leaving and reopening', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = '本机尚未提交的完整笔记\n一行一行保留。';
  await dialog.getByLabel('笔记编辑稿').fill(text); await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(page.locator('[data-message-id="' + f.message.id + '"]').getByRole('button', { name: '整理为笔记', exact: true })).toBeFocused();
  await page.context().setOffline(true); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await expect(dialog.getByRole('alert')).toContainText('无法连接'); await expect(dialog.getByRole('button', { name: '保存编辑稿', exact: true })).toBeDisabled();
  await page.context().setOffline(false); await page.keyboard.press('Escape'); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await expect(dialog.getByRole('button', { name: '保存编辑稿', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click();
  const row = (await call(f.actor, f.base)).items[0]; expect((await call(f.actor, f.base + '/' + row.id)).markdown).toBe(text);
});

test('assistant notes: corrupt or different-account cached content stays hidden and its original bytes are preserved', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page), key = 'studyagent.assistant.notes.v1.' + encodeURIComponent(f.actor.user.id) + '.' + encodeURIComponent(f.session.id), raw = JSON.stringify({ version: 1, ownerId: 'another-account', sessionId: f.session.id, active: 'new', drafts: { new: { title: 'PRIVATE_FORGED_CONTENT' } } });
  await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), { key, raw }); await enter(page, f.message); const dialog = panel(page); await expect(dialog).not.toContainText('PRIVATE_FORGED_CONTENT'); await expect(dialog.getByRole('status').filter({ hasText: '原笔记缓存尚未核对' })).toBeVisible();
  await dialog.getByLabel('笔记标题').fill('本次页面里仍能编辑'); expect(await page.evaluate(key => localStorage.getItem(key), key)).toBe(raw);
  const download = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载本机稿', exact: true }).last().click(); const file = await download; expect(JSON.parse(await readFile((await file.path())!, 'utf8')).title).toBe('本次页面里仍能编辑');
});

test('assistant notes: a source outside70 later messages returns by a read-only anchor without opening another conversation', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); await page.keyboard.press('Escape');
  await call(f.actor, '/qa/assistant/seed-history', { sessionId: f.session.id, count: 70, makeSourceOld: true }); await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await expect(page.locator('[data-message-id="' + f.message.id + '"]')).toHaveCount(0);
  const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:$|\/[^/]+\/turns$)/.test(new URL(r.url()).pathname)) posts.push(r.url()); });
  await page.getByRole('button', { name: '我的笔记', exact: true }).click(); const dialog = panel(page); await dialog.getByRole('region', { name: '服务端已保存笔记' }).getByRole('button', { name: /我的学习笔记/ }).click();
  await expect(dialog.getByRole('button', { name: '返回原消息', exact: true })).toBeVisible(); await dialog.getByRole('button', { name: '返回原消息', exact: true }).click(); await expect(page.locator('[data-message-id="' + f.message.id + '"]')).toBeFocused(); expect(posts).toEqual([]);
});

test('assistant notes: a request that never reached the server retries only its preserved original command', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page), commands: unknown[] = [];
  await page.route('**/api/ai/assistant/sessions/*/artifacts/notes', async route => {
    if (route.request().method() !== 'POST') return route.continue(); commands.push(route.request().postDataJSON());
    if (commands.length === 1) return route.abort('failed'); await route.continue();
  });
  await enter(page, f.message); const dialog = panel(page); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '保存逐字候选', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '保存逐字候选', exact: true }).click();
  await expect(dialog.getByRole('alert')).toContainText('原操作仍保留'); expect((await call(f.actor, f.base)).items).toEqual([]); await dialog.getByRole('button', { name: '核对原操作', exact: true }).click();
  await expect(dialog.getByRole('button', { name: '用原请求重试', exact: true })).toBeVisible(); await dialog.getByRole('button', { name: '用原请求重试', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toBeEnabled();
  expect(commands).toHaveLength(2); expect(commands[1]).toEqual(commands[0]); expect((await call(f.actor, f.base)).items).toHaveLength(1);
});

test('assistant notes: lost edit and adoption replies recover their original results without publishing another command', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = '已提交但回执暂时丢失的完整编辑稿。'; let edits = 0, confirmations = 0;
  await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/*/content', async route => { edits++; const response = await route.fetch(); expect(response.status()).toBe(200); await route.abort('failed'); });
  await dialog.getByLabel('笔记编辑稿').fill(text); await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click(); await expect(dialog.getByRole('alert')).toContainText('原操作仍保留');
  await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await dialog.getByRole('button', { name: '核对原操作', exact: true }).click(); await expect(dialog.getByLabel('我已核对原文和编辑稿')).toBeEnabled();
  await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/*/confirm', async route => { confirmations++; const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed'); });
  await dialog.getByLabel('我已核对原文和编辑稿').check(); await dialog.getByRole('button', { name: '采用这份笔记', exact: true }).click(); await expect(dialog.getByRole('alert')).toContainText('原操作仍保留');
  await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(page, f.message); await dialog.getByRole('button', { name: '核对原操作', exact: true }).click(); await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toHaveCount(0);
  await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); expect(edits).toBe(1); expect(confirmations).toBe(1); expect((await call(f.actor, f.base)).items[0].status).toBe('confirmed');
});

test('assistant notes: another selected message keeps the first unsubmitted editing draft intact', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = '第一份笔记尚未提交的独立草稿。'; await dialog.getByLabel('笔记编辑稿').fill(text); await page.keyboard.press('Escape');
  await enter(page, f.question); await expect(dialog.getByLabel('笔记复习目标')).toBeVisible(); await create(page); await page.keyboard.press('Escape');
  expect((await call(f.actor, f.base)).items).toHaveLength(2); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await expect(dialog.getByRole('button', { name: '保存编辑稿', exact: true })).toBeEnabled();
});

test('assistant notes: an export read failure preserves the full saved note and a retry only downloads it', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page); let reads = 0;
  await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/*/export?format=json', route => { reads++; return reads === 1 ? route.abort('failed') : route.continue(); });
  const before = await call(f.actor, f.base); await dialog.getByRole('button', { name: '下载完整JSON', exact: true }).click(); await expect(dialog.getByRole('alert')).toContainText('笔记和本机稿仍保留'); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(new RegExp(f.message.content.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  const download = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载完整JSON', exact: true }).click(); const file = await download; const note = JSON.parse(await readFile((await file.path())!, 'utf8')); expect(note.origin.messages[0].content).toBe(f.message.content); expect(await call(f.actor, f.base)).toEqual(before); expect(reads).toBe(2);
});

test('assistant notes: closing a pending private read and switching accounts hides its late response', async ({ page }) => {
  test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = 'PRIVATE_ONLY_FIRST_ACCOUNT_' + crypto.randomUUID(); await dialog.getByLabel('笔记编辑稿').fill(text); await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click(); await expect(dialog.getByLabel('我已核对原文和编辑稿')).toBeEnabled(); await page.keyboard.press('Escape');
  const id = (await call(f.actor, f.base)).items[0].id; let release!: () => void, entered!: () => void;
  const held = new Promise<void>(r => { release = r; }), ready = new Promise<void>(r => { entered = r; });
  await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/' + id, async route => { const response = await route.fetch(); entered(); await held; try { await route.fulfill({ response }); } catch { /* The old identity's client request was aborted when its modal closed. */ } });
  try { await enter(page, f.message); await ready; await page.keyboard.press('Escape'); await page.context().clearCookies(); const second = await fixture(page); release(); await enter(page, second.message); await expect(panel(page)).not.toContainText(text); expect(await panel(page).getByLabel('笔记标题').inputValue()).toBe('我的学习笔记'); }
  finally { release?.(); }
});
