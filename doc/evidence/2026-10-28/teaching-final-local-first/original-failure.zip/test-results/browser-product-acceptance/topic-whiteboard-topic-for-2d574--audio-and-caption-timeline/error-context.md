# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: topic-whiteboard.spec.ts >> topic-formula: actual shared image and fraction/root/alignment vector video decodes with full audio and caption timeline
- Location: tests\e2e\topic-whiteboard.spec.ts:121:5

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 100
Received:   20
```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - complementary "学习工作台导航" [ref=f3e4]:
      - generic [ref=f3e5]:
        - generic [ref=f3e6]:
          - link "StudyAgent 学习工作台" [ref=f3e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f3e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f3e11] [cursor=pointer]
        - generic [ref=f3e14]:
          - navigation "工作台主要入口" [ref=f3e15]:
            - link "Home" [ref=f3e16] [cursor=pointer]:
              - /url: /studio?view=home
              - generic [ref=f3e19]: 首页
            - link "Courses" [ref=f3e20] [cursor=pointer]:
              - /url: /studio?view=courses
              - generic [ref=f3e23]: 课程
            - link "Calendar" [ref=f3e24] [cursor=pointer]:
              - /url: /studio?view=calendar
              - generic [ref=f3e27]: 学习动态
            - link "History" [ref=f3e28] [cursor=pointer]:
              - /url: /studio?view=history
              - generic [ref=f3e31]: 历史
            - link "Materials" [ref=f3e32] [cursor=pointer]:
              - /url: /studio?view=materials
              - generic [ref=f3e35]: 资料
            - link "AI Whiteboards" [ref=f3e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f3e39]: AI白板
          - generic [ref=f3e40]:
            - region "开始学习" [ref=f3e41]:
              - heading "开始学习" [level=3] [ref=f3e43]
              - link "打开课程 从一节适合自己的课开始。" [ref=f3e44] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f3e45]: 打开课程
                - generic [ref=f3e46]: 从一节适合自己的课开始。
            - generic [ref=f3e47]:
              - heading "近期活动" [level=3] [ref=f3e49]
              - paragraph [ref=f3e51]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f3e53] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f3e54]:
      - generic [ref=f3e55]:
        - generic [ref=f3e56]:
          - text: WHITEBOARD STUDIO
          - heading "从一个问题开始，讲清每一步。" [level=1] [ref=f3e57]
          - paragraph [ref=f3e58]: 先生成教学稿，完整核对后再保存。AI 讲解需要内容核对。
        - link "返回学习工作台 →" [ref=f3e59] [cursor=pointer]:
          - /url: /studio
      - generic [ref=f3e60]:
        - complementary [ref=f3e61]:
          - generic [ref=f3e62]:
            - text: NEW BOARD
            - heading "这次想弄懂什么？" [level=2] [ref=f3e63]
          - generic [ref=f3e64]:
            - text: 学习对象
            - combobox "白板学习对象" [ref=f3e65]:
              - option "我自己 · 成人主题" [selected]
          - region "新建AI白板" [ref=f3e66]:
            - group [ref=f3e67]:
              - generic [ref=f3e68]:
                - text: 讲解主题
                - textbox "讲解主题" [ref=f3e69]:
                  - /placeholder: 例如：为什么先统一单位，才能比较和合并？
                  - text: 用匿名观察解释条件与推断
              - generic [ref=f3e70]:
                - text: 希望弄懂什么
                - textbox "希望弄懂什么" [ref=f3e71]:
                  - /placeholder: 想理解的区别、步骤，或一个具体困惑
                  - text: 保留完整条件，说明观察、推断和替代解释的区别。
              - generic [ref=f3e72]:
                - generic [ref=f3e73]:
                  - generic [ref=f3e74]: 模型
                  - combobox "选择大模型" [ref=f3e75] [cursor=pointer]:
                    - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                    - option "GPT-6.1 Sol"
                    - option "GPT-6 Astra"
                    - option "GPT-6 Luna"
                    - option "Grok-4.7"
                    - option "GLM-5.3 Flash"
                    - option "DeepSeek V4.1 Flash · 默认" [selected]
                    - option "Claude Opus 5.5"
                    - option "Claude Sonnet 5"
                    - option "GPT-6 Sol"
                    - option "GPT-5.6 Sol"
                    - option "GPT-5.6 Terra"
                    - option "GPT-5.6 Luna"
                    - option "GPT-5.5"
                    - option "Grok-4.6"
                    - option "GLM-5.2"
                    - option "GLM-5.3"
                    - option "Claude Opus 5"
                    - option "Claude Fable 5.1"
                    - option "MiMo V2.6 Pro"
                    - option "MiMo V2.6 Flash"
                    - option "MiMo V2.6 Pro Ultraspeed"
                    - option "Qwen3.8 Max"
                - generic [ref=f3e76]: 尚未进行文字检查
            - status [ref=f3e78]: 已恢复此标签页的原主题与模型选择。
            - generic [ref=f3e79]:
              - button "预检主题与范围" [ref=f3e80] [cursor=pointer]
              - button "生成教学稿" [disabled] [ref=f3e81]
            - button "下载原主题与请求" [ref=f3e82] [cursor=pointer]
            - group [ref=f3e83]:
              - generic "查看其他本机主题" [ref=f3e84] [cursor=pointer]
        - region "白板工作区" [ref=f3e85]:
          - generic [ref=f3e86]:
            - text: SAVED BOARD
            - heading "把条件讲清楚" [level=2] [ref=f3e87]
            - paragraph [ref=f3e88]: AI生成 · 待内容核对 · Browser fixture · not a real model
            - button "继续阅读" [ref=f3e89] [cursor=pointer]
            - button "查看自己的原稿" [ref=f3e90] [cursor=pointer]
          - dialog "白板视频" [ref=f3e91]:
            - generic:
              - button "关闭白板" [ref=f3e92] [cursor=pointer]: ×
              - heading "把条件讲清楚" [level=2] [ref=f3e94]
            - navigation "白板视图" [ref=f3e95]:
              - generic [ref=f3e96]:
                - button "缩小白板" [ref=f3e97] [cursor=pointer]: −
                - button "重置白板视图" [ref=f3e98] [cursor=pointer]: 100%
                - button "放大白板" [ref=f3e99] [cursor=pointer]: +
              - group "白板页码" [ref=f3e100]:
                - button "上一页白板" [disabled] [ref=f3e101]: ‹
                - generic [ref=f3e102]:
                  - generic [ref=f3e103]: "1"
                  - generic [ref=f3e104]: /
                  - generic [ref=f3e105]: "1"
                - button "下一页白板" [disabled] [ref=f3e106]: ›
              - group "白板工具" [ref=f3e107]:
                - button "分享与导出" [ref=f3e109] [cursor=pointer]
                - button "白板设置" [ref=f3e112] [cursor=pointer]
              - button "收起讲稿与笔记" [expanded] [ref=f3e115] [cursor=pointer]
            - button "静音" [ref=f3e117] [cursor=pointer]
            - generic [ref=f3e120]:
              - main [ref=f3e121]:
                - generic [ref=f3e122]:
                  - generic "公式示例 1" [ref=f3e123]
                  - figure "AI参考图，标签和关系待核对。" [ref=f3e124]:
                    - button "放大参考图：公式示例 1" [ref=f3e125]:
                      - generic [aria-hidden] [ref=f3e126]: ↗
                - paragraph [ref=f3e127]: "[whiteboard-fixture] 核对完整表达。"
                - generic [ref=f3e128]:
                  - generic [ref=f3e129]: 播放进度（实际音轨）
                  - slider "播放进度（实际音轨）" [ref=f3e130] [cursor=pointer]: "0"
                - generic [ref=f3e131]:
                  - button "上一句" [disabled] [ref=f3e132]: ←
                  - button "播放" [ref=f3e133] [cursor=pointer]: ▶
                  - button "下一句" [ref=f3e134] [cursor=pointer]: →
                  - generic [ref=f3e135]: 1 / 6 句
                  - combobox "阅读方式" [ref=f3e136] [cursor=pointer]:
                    - option "文字阅读（估计时长）"
                    - option "云语音逐句播放" [selected]
                  - combobox "旁白音色" [ref=f3e137] [cursor=pointer]:
                    - option "合成音轨 A" [selected]
                  - combobox "播放速度" [ref=f3e138] [cursor=pointer]:
                    - option "0.5×"
                    - option "0.75×"
                    - option "1×" [selected]
                    - option "1.25×"
                    - option "1.5×"
                    - option "2×"
                  - generic [ref=f3e139]:
                    - generic [ref=f3e140]: 板书字体
                    - combobox "板书字体" [ref=f3e141] [cursor=pointer]:
                      - option "手写板书" [selected]
                      - option "标准板书"
                  - generic [ref=f3e142]:
                    - checkbox "点阵" [checked] [ref=f3e143]
                    - text: 点阵
                  - button "导出视频" [ref=f3e144] [cursor=pointer]
                  - button "导出字幕" [ref=f3e145] [cursor=pointer]
                - status [ref=f3e146]: 带云语音的 WebM 已生成；导出字幕将使用相同音轨时间表。
                - generic [ref=f3e147]:
                  - button "01 公式示例 1" [ref=f3e148] [cursor=pointer]:
                    - generic [ref=f3e149]: "01"
                    - text: 公式示例 1
                  - button "02 公式示例 2" [ref=f3e150] [cursor=pointer]:
                    - generic [ref=f3e151]: "02"
                    - text: 公式示例 2
                  - button "03 公式示例 3" [ref=f3e152] [cursor=pointer]:
                    - generic [ref=f3e153]: "03"
                    - text: 公式示例 3
              - generic [ref=f3e156]:
                - separator "调整讲稿面板宽度" [ref=f3e157]
                - complementary "完整讲稿与要点" [ref=f3e159]:
                  - button "收起讲稿与笔记" [ref=f3e160] [cursor=pointer]
                  - region "原句提问" [ref=f3e163]:
                    - generic [ref=f3e164]:
                      - heading "一起想清楚" [level=3] [ref=f3e165]
                      - generic [ref=f3e166]: AI补充讲解
                    - group [ref=f3e167]:
                      - generic "带走完整教学笔记" [ref=f3e168] [cursor=pointer]
                    - paragraph [ref=f3e170]: 哪里没听懂，就从那一句问起。
                    - generic [ref=f3e171]:
                      - generic [ref=f3e172]: 向老师提问
                      - textbox "向老师提问" [ref=f3e173]:
                        - /placeholder: 对这句有疑问？
                      - generic [ref=f3e174]:
                        - combobox "讲解方式" [ref=f3e175]:
                          - option "问一个问题" [selected]
                          - option "换个例子"
                          - option "讲简单些"
                          - option "补补基础"
                          - option "对比理解"
                        - generic [ref=f3e176]:
                          - combobox "选择大模型" [ref=f3e178] [cursor=pointer]:
                            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                            - option "GPT-6.1 Sol"
                            - option "GPT-6 Astra"
                            - option "GPT-6 Luna"
                            - option "Grok-4.7"
                            - option "GLM-5.3 Flash"
                            - option "DeepSeek V4.1 Flash · 默认" [selected]
                            - option "Claude Opus 5.5"
                            - option "Claude Sonnet 5"
                            - option "GPT-6 Sol"
                            - option "GPT-5.6 Sol"
                            - option "GPT-5.6 Terra"
                            - option "GPT-5.6 Luna"
                            - option "GPT-5.5"
                            - option "Grok-4.6"
                            - option "GLM-5.2"
                            - option "GLM-5.3"
                            - option "Claude Opus 5"
                            - option "Claude Fable 5.1"
                            - option "MiMo V2.6 Pro"
                            - option "MiMo V2.6 Flash"
                            - option "MiMo V2.6 Pro Ultraspeed"
                            - option "Qwen3.8 Max"
                          - generic [ref=f3e179]: 尚未进行文字检查
                        - button "发送" [disabled] [ref=f3e181]
                      - group [ref=f3e182]:
                        - generic "保留与恢复提问" [ref=f3e183] [cursor=pointer]
                  - heading "逐句讲稿" [level=3] [ref=f3e184]
                  - paragraph [ref=f3e185]: 点击一句定位。观看与续播不计作掌握。
                  - list [ref=f3e186]:
                    - listitem [ref=f3e187]:
                      - button "[whiteboard-fixture] 核对完整表达。" [ref=f3e188] [cursor=pointer]
                    - listitem [ref=f3e189]:
                      - button "[whiteboard-fixture] 保留最后一项。" [ref=f3e190] [cursor=pointer]
                    - listitem [ref=f3e191]:
                      - button "[whiteboard-fixture] 核对完整表达。" [ref=f3e192] [cursor=pointer]
                    - listitem [ref=f3e193]:
                      - button "[whiteboard-fixture] 保留最后一项。" [ref=f3e194] [cursor=pointer]
                    - listitem [ref=f3e195]:
                      - button "[whiteboard-fixture] 核对完整表达。" [ref=f3e196] [cursor=pointer]
                    - listitem [ref=f3e197]:
                      - button "[whiteboard-fixture] 保留最后一项。" [ref=f3e198] [cursor=pointer]
                  - heading "完整笔记与来源" [level=3] [ref=f3e199]
                  - group [ref=f3e200]:
                    - generic "公式示例 1" [ref=f3e201] [cursor=pointer]
                    - paragraph [ref=f3e202]: 完整说明首行。完整说明尾行。
                    - list [ref=f3e203]:
                      - listitem [ref=f3e204]: 核对完整表达
                      - listitem [ref=f3e205]: 保留最后一项
                    - figure "分式、根号与对齐关系需要完整保留，最后一项不能省略。" [ref=f3e206]:
                      - region "完整公式，可横向滚动" [ref=f3e208]
                      - math [ref=f3e237]:
                        - generic [ref=f3e239]:
                          - generic [ref=f3e240]:
                            - generic [ref=f3e241]: "1"
                            - generic [ref=f3e242]: "2"
                          - generic [ref=f3e243]: +
                          - generic [ref=f3e245]:
                            - generic [ref=f3e246]:
                              - generic [ref=f3e247]: x
                              - generic [ref=f3e248]: "2"
                            - generic [ref=f3e249]: +
                            - generic [ref=f3e250]: "1"
                      - group [ref=f3e251]:
                        - generic "可复制的公式原文" [ref=f3e252] [cursor=pointer]
                    - figure "AI参考图，标签和关系待核对。" [ref=f3e253]:
                      - button "放大参考图：公式示例 1" [ref=f3e254]:
                        - img "公式示例 1，图中概念和关系待核对。" [ref=f3e255]
                        - generic [aria-hidden] [ref=f3e256]: ↗
                  - group [ref=f3e258]:
                    - generic "公式示例 2" [ref=f3e259] [cursor=pointer]
                  - group [ref=f3e260]:
                    - generic "公式示例 3" [ref=f3e261] [cursor=pointer]
                  - paragraph [ref=f3e262]: AI生成 · 待内容核对 · Browser fixture · not a real model
                  - button "下载续播位置" [ref=f3e263] [cursor=pointer]
        - complementary "白板与候选历史" [ref=f3e264]:
          - generic [ref=f3e265]:
            - heading "我的白板" [level=2] [ref=f3e266]
            - button "＋ 新白板" [ref=f3e267] [cursor=pointer]
          - generic [ref=f3e268]:
            - button "教学草稿" [pressed] [ref=f3e269] [cursor=pointer]
            - button "已保存" [ref=f3e270] [cursor=pointer]
          - generic [ref=f3e271]:
            - generic [ref=f3e272]: 搜索我的白板
            - textbox "搜索我的白板" [ref=f3e273]:
              - /placeholder: 搜索主题或标题
          - button "已保存白板 · 本人主题 把条件讲清楚 Browser fixture · not a real model" [ref=f3e274] [cursor=pointer]:
            - generic [ref=f3e275]: 已保存白板 · 本人主题
            - generic [ref=f3e276]: 把条件讲清楚
            - generic [ref=f3e277]: Browser fixture · not a real model
          - generic [ref=f3e278]:
            - button "上一页" [disabled] [ref=f3e279]
            - generic [ref=f3e280]: 1 / 1
            - button "下一页" [disabled] [ref=f3e281]
```

# Test source

```ts
  58  |   const timing = await installNarrationTiming(page); await fixture(page); await generate(page); await ready(page);
  59  |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click();
  60  |   await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  61  |   const player = page.getByRole('dialog', { name: '白板视频' });
  62  |   try {
  63  |     await player.getByRole('button', { name: '播放', exact: true }).click();
  64  |     await expect.poll(async () => (await timing.read()).audio.some(row => row.index === 1 && row.event === 'playing'), { timeout: 10000 }).toBe(true);
  65  |     await player.getByRole('button', { name: '暂停', exact: true }).click(); const result = await timing.save('adult-topic-transfer');
  66  |     const ended = result.audio.find(row => row.index === 0 && row.event === 'ended')!, next = result.audio.find(row => row.index === 1 && row.event === 'playing')!;
  67  |     expect(result.requests[1].startedAt).toBeLessThan(ended.at - 100);
  68  |     expect(next.at - ended.at).toBeLessThan(result.delayMs * .75); expect(next.currentTime).toBeLessThan(.15);
  69  |     expect(result.requests.filter(row => row.unitId === result.requests[1].unitId)).toHaveLength(1);
  70  |     await expect(player.locator('.wb-current-sentence')).toContainText('保留未知条件');
  71  |   } finally { await page.unrouteAll({ behavior: 'wait' }); }
  72  | });
  73  | 
  74  | async function formulaBoard(page: Page, expressions: string[], withFigure = false) {
  75  |   const f = await fixture(page); await generate(page); await ready(page);
  76  |   const id = new URL(page.url()).searchParams.get('draft')!, view = await f.call(base + '/drafts/' + id, undefined, 'GET');
  77  |   const content = { ...view.content, scenes: expressions.map((latex, index) => ({ ...view.content.scenes[index % 3], title: '公式示例 ' + (index + 1),
  78  |     narration: '[whiteboard-fixture] 核对完整表达。 [whiteboard-fixture] 保留最后一项。',
  79  |     bullets: ['核对完整表达', '保留最后一项'], figure: undefined, exhibit: { kind: 'formula', latex, explanation: '分式、根号与对齐关系需要完整保留，最后一项不能省略。' } })) };
  80  |   const edited = await f.call(base + '/drafts/' + id + '/content', { expectedRevision: view.revision, contentFingerprint: view.contentFingerprint, content, requestKey: randomUUID() }, 'PATCH');
  81  |   let current = edited;
  82  |   if (withFigure) {
  83  |     await page.reload(); await ready(page);
  84  |     await page.getByRole('button', { name: '采用服务器稿', exact: true }).click();
  85  |     await expect(page.getByRole('region', { name: '白板配图工作区' }).getByRole('button', { name: '预检配图范围', exact: true })).toBeEnabled();
  86  |     const pane = await figure(page); await pane.getByRole('checkbox', { name: '我已阅读图片，并核对本次要使用的标签和关系。' }).check();
  87  |     await pane.getByRole('button', { name: '选入当前完整稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  88  |     await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  89  |     current = await f.call(base + '/drafts/' + id, undefined, 'GET');
  90  |   }
  91  |   await f.call(base + '/drafts/' + id + '/confirm', { expectedRevision: current.revision, contentFingerprint: current.contentFingerprint,
  92  |     acknowledgeAiGeneratedContent: true, acknowledgeUnreviewedChanges: true, requestKey: randomUUID() });
  93  |   await page.reload(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  94  |   const player = page.getByRole('dialog', { name: '白板视频' }); await expect(player).toBeVisible();
  95  |   return { ...f, player };
  96  | }
  97  | 
  98  | test('topic-formula: complete vector fractions, aligned roots and Unicode fit narrow notes and preserve copyable source and safe fallback', async ({ page }) => {
  99  |   const expressions = ['\\frac{1}{2}+\\sqrt{x^2+1}', '\\begin{aligned}a&=b+c\\\\d&=\\frac{e}{f}\\end{aligned}', '\\frac{1}{2}\\text{个整体}', '\\unknownprivate{最后一项}', 'a+'.repeat(280) + 'z'];
  100 |   const { player } = await formulaBoard(page, expressions);
  101 |   for (const width of [390, 768, 1440]) {
  102 |     await page.setViewportSize({ width, height: 1000 });
  103 |     if (width <= 900) await player.getByRole('button', { name: '讲稿与笔记', exact: true }).click();
  104 |     for (const [index, latex] of expressions.entries()) {
  105 |       const detail = player.locator('.wb-reading-notes > details').nth(index);
  106 |       if (!(await detail.getAttribute('open') !== null)) await detail.locator(':scope > summary').click();
  107 |       const formula = detail.locator('.wb-complete-formula');
  108 |       if (index !== 3) { await expect(formula.locator('.wb-formula-vector svg')).toHaveCount(1); await expect(formula.locator('math')).toHaveCount(1); }
  109 |       else await expect(formula.getByRole('status')).toContainText('分页保留原式');
  110 |       const raw = formula.locator('details'); if (await raw.getAttribute('open') === null) await raw.locator('summary').click();
  111 |       expect(await raw.locator('pre').textContent()).toBe(latex);
  112 |       expect(await formula.evaluate(node => node.scrollWidth <= node.clientWidth + 1)).toBe(true);
  113 |     }
  114 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  115 |     await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'topic-formula-reader-' + width + '.png'), fullPage: false });
  116 |     if (width <= 900) await page.getByRole('button', { name: '返回白板画面', exact: true }).click();
  117 |   }
  118 |   expect(await page.locator('[href^="javascript:"],script[src*="mathjax"],image[href^="http"]').count()).toBe(0);
  119 | });
  120 | 
  121 | test('topic-formula: actual shared image and fraction/root/alignment vector video decodes with full audio and caption timeline', async ({ page }) => {
  122 |   await page.addInitScript(() => {
  123 |     const original = CanvasRenderingContext2D.prototype.drawImage;
  124 |     const start = MediaRecorder.prototype.start;
  125 |     MediaRecorder.prototype.start = function (...args) { (window as any).formulaVideoStart = performance.now(); return start.apply(this, args); };
  126 |     (window as any).formulaVideoCrops = [];
  127 |     CanvasRenderingContext2D.prototype.drawImage = function (...args: any[]) {
  128 |       const image = args[0];
  129 |       if (!this.canvas.isConnected && args.length === 9 && image instanceof HTMLImageElement) {
  130 |         const transform = this.getTransform();
  131 |         (window as any).formulaVideoCrops.push({ time: (performance.now() - ((window as any).formulaVideoStart ?? performance.now())) / 1000, naturalWidth: image.naturalWidth, sourceRight: args[1] + args[3],
  132 |           scale: args[7] / args[3], left: transform.a * args[5] + transform.e, top: transform.d * args[6] + transform.f,
  133 |           right: transform.a * (args[5] + args[7]) + transform.e, bottom: transform.d * (args[6] + args[8]) + transform.f });
  134 |       }
  135 |       return original.apply(this, args as any);
  136 |     };
  137 |   });
  138 |   const { player } = await formulaBoard(page, ['\\frac{1}{2}+\\sqrt{x^2+1}', '\\begin{aligned}a&=b+c\\\\d&=\\frac{e}{f}\\end{aligned}', 'a+'.repeat(280) + 'z'], true);
  139 |   await expect(player.locator('.sa-whiteboard-notice')).not.toContainText('无法解码');
  140 |   await expect(player.locator('.wb-formula-vector svg').first()).toBeVisible();
  141 |   const download = page.waitForEvent('download', { timeout: 30000 }); await player.getByRole('button', { name: '导出视频', exact: true }).click();
  142 |   const video = (await (await download).path())!, directory = browserEvidence('topic-whiteboard'); copyFileSync(video, join(directory, 'topic-formula-video.webm'));
  143 |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', video], { windowsHide: true, encoding: 'utf8' }));
  144 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true); expect(probe.streams.some((stream: any) => stream.codec_type === 'video')).toBe(true);
  145 |   const crops = await page.evaluate(() => (window as any).formulaVideoCrops as Array<{ time: number; naturalWidth: number; sourceRight: number; scale: number; left: number; top: number; right: number; bottom: number }>);
  146 |   writeFileSync(join(directory, 'topic-formula-readable-video-crops.json'), JSON.stringify({ crops }, null, 2) + '\n');
  147 |   const widths = [...new Set(crops.map(crop => crop.naturalWidth))]; expect(widths).toHaveLength(3);
  148 |   const receipts: unknown[] = [];
  149 |   for (const [name, time, source] of [['first', .2, 0], ['aligned', 4.2, 1], ['last', 11.9, 2]] as const) {
  150 |     const frame = spawnSync(process.env.STUDY_FFMPEG ?? 'ffmpeg', ['-v', 'error', '-ss', String(time), '-i', video, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'], { windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
  151 |     expect(frame.status).toBe(0); const decoded = await sharp(frame.stdout).removeAlpha().raw().toBuffer({ resolveWithObject: true }); let ink = 0;
  152 |     // Measure actual vector source crops, then independently decode glyph ink
  153 |     // inside that image's complete visible bounds; notes cannot satisfy this.
  154 |     const region = crops.filter(crop => crop.naturalWidth === widths[source] && Math.abs(crop.time - time) < .2 && crop.left >= 0 && crop.right <= 1280 && crop.top >= 0 && crop.bottom <= 610 && (name !== 'last' || crop.sourceRight >= crop.naturalWidth - 1)).sort((a,b) => Math.abs(a.time-time)-Math.abs(b.time-time))[0];
  155 |     expect(region, name + ' complete vector bounds').toBeTruthy();
  156 |     for (let y = Math.ceil(region.top); y < Math.floor(region.bottom); y++) for (let x = Math.ceil(region.left); x < Math.floor(region.right); x++) { const offset = (y * 1280 + x) * 3;
  157 |       if (decoded.data[offset] < 120 && decoded.data[offset + 1] < 130 && decoded.data[offset + 2] < 120) ink++; }
> 158 |     expect(ink).toBeGreaterThan(100); receipts.push({ name, time, ink }); writeFileSync(join(directory, 'topic-formula-video-' + name + '.png'), frame.stdout);
      |                 ^ Error: expect(received).toBeGreaterThan(expected)
  159 |   }
  160 |   writeFileSync(join(directory, 'topic-formula-video-probe.json'), JSON.stringify({ probe, frames: receipts }, null, 2) + '\n');
  161 |   const long = crops.filter(crop => crop.naturalWidth > 1500); expect(long.length).toBeGreaterThan(0);
  162 |   expect(Math.min(...long.map(crop => crop.scale))).toBeGreaterThanOrEqual(.79);
  163 |   expect(long.some(crop => crop.sourceRight >= crop.naturalWidth - 1 && crop.left >= 0 && crop.right <= 1280 && crop.top >= 0 && crop.bottom <= 610)).toBe(true);
  164 |   writeFileSync(join(directory, 'topic-formula-readable-video-crops.json'), JSON.stringify({ minimumScale: Math.min(...long.map(crop => crop.scale)), crops }, null, 2) + '\n');
  165 |   const captions = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); const srt = readFileSync((await (await captions).path())!, 'utf8');
  166 |   expect(srt).toContain('00:00:00,000 --> 00:00:02,000'); expect(srt).toContain('00:00:10,000 --> 00:00:12,000'); expect(srt).toContain('保留最后一项');
  167 |   writeFileSync(join(directory, 'topic-formula-video.srt'), srt);
  168 |   const later: string[] = []; page.on('download', item => later.push(item.suggestedFilename()));
  169 |   await player.getByRole('button', { name: '导出视频', exact: true }).click(); await player.getByRole('button', { name: '取消导出', exact: true }).click();
  170 |   await expect(player.locator('.sa-whiteboard-notice')).toContainText('没有下载半成品'); expect(later).toEqual([]);
  171 |   const retained = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); expect(readFileSync((await (await retained).path())!, 'utf8')).toBe(srt);
  172 | });
  173 | 
  174 | test('login forms cannot submit before their client handlers are ready', async ({ browser }) => {
  175 |   const context = await browser.newContext({ javaScriptEnabled: false, baseURL: test.info().project.use.baseURL });
  176 |   try {
  177 |     const page = await context.newPage();
  178 |     for (const path of ['/parent/login', '/student/login']) {
  179 |       await page.goto(path);
  180 |       for (const input of await page.locator('form input, form button').all()) await expect(input).toBeDisabled();
  181 |     }
  182 |   } finally { await context.close(); }
  183 | });
  184 | 
  185 | test('topic-figure: restores a lost original image prepare without duplicate writes, edits its PNG and publishes an image with pause/read/resume', async ({ page }) => {
  186 |   const f = await fixture(page); await generate(page); await ready(page); const id = new URL(page.url()).searchParams.get('draft')!;
  187 |   let dropped = true, writes = 0;
  188 |   await page.route('**/api/learning/studio/topic-whiteboard-visuals', async route => {
  189 |     if (route.request().method() !== 'POST') return route.continue(); writes++;
  190 |     if (dropped) { dropped = false; expect((await route.fetch()).status()).toBe(201); await route.abort('failed'); } else await route.continue();
  191 |   });
  192 |   await figure(page); const pane = page.getByRole('region', { name: '白板配图工作区' });
  193 |   await expect(pane.getByRole('button', { name: '恢复原配图请求', exact: true })).toBeEnabled(); await page.reload(); await ready(page);
  194 |   await pane.getByRole('button', { name: '恢复原配图请求', exact: true }).click();
  195 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible(); expect(writes).toBe(1);
  196 |   expect((await f.call(figureBase + '?draftId=' + id + '&sceneIndex=0', undefined, 'GET')).total).toBe(1);
  197 |   await pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).click();
  198 |   await expect(page.locator('.cl-figure-reader-sheet img')).toBeVisible(); await page.keyboard.press('Escape');
  199 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeFocused();
  200 |   await pane.getByRole('button', { name: '以原图继续修订', exact: true }).click();
  201 |   await pane.getByLabel('具体修改').fill('只去掉顶端标题，保留圆、交集和其他标签。');
  202 |   await pane.getByRole('button', { name: '预检配图范围', exact: true }).click(); await expect(pane.getByRole('button', { name: '生成修订图片', exact: true })).toBeEnabled();
  203 |   await pane.getByRole('button', { name: '生成修订图片', exact: true }).click();
  204 |   await expect(pane.getByRole('button', { name: '放大参考图：先核对观察', exact: true })).toBeVisible();
  205 |   await pane.getByRole('textbox', { name: '图片替代说明', exact: true }).fill('两个概念圆及其交集，说明观察和条件的关系。');
  206 |   await pane.getByRole('textbox', { name: '图注', exact: true }).fill('比较观察与条件，保留这条完整图注。');
  207 |   await expect(pane.locator('.tw-figure-list .tw-figure-thumbnail img').first()).toBeVisible();
  208 |   await pane.getByRole('button', { name: '加入对照', exact: true }).last().click(); await expect(pane.getByRole('region', { name: '两个图片候选对照' })).toBeVisible();
  209 |   await expect(pane.getByRole('region', { name: '两个图片候选对照' }).locator('img').first()).toBeVisible();
  210 |   await expect.poll(() => page.evaluate(() => Object.keys(localStorage).filter(key => key.startsWith('studyagent.topic-whiteboard.figures.')).map(key => JSON.parse(localStorage.getItem(key)!).caption))).toContain('比较观察与条件，保留这条完整图注。');
  211 |   await page.reload(); await ready(page); await expect(pane.getByRole('textbox', { name: '图片替代说明', exact: true })).toHaveValue('两个概念圆及其交集，说明观察和条件的关系。');
  212 |   await expect(pane.getByRole('textbox', { name: '图注', exact: true })).toHaveValue('比较观察与条件，保留这条完整图注。');
  213 |   await pane.getByRole('checkbox', { name: '我已阅读图片，并核对本次要使用的标签和关系。' }).check();
  214 |   await pane.getByRole('button', { name: '选入当前完整稿', exact: true }).click(); await page.getByRole('button', { name: '保存完整改稿', exact: true }).click();
  215 |   await expect(page.locator('.tw-review')).toContainText('针对旧稿');
  216 |   const draft = await f.call(base + '/drafts/' + id, undefined, 'GET'); expect(draft.content.scenes[0].figure).toBeTruthy();
  217 |   const candidate = await f.call(figureBase + '/' + draft.content.scenes[0].figure.visualId, undefined, 'GET'); expect(candidate.operation).toBe('edit'); expect(candidate.parentVisualId).toBeTruthy();
  218 |   await page.getByRole('checkbox', { name: '我已阅读未确定问题或手工改稿，知晓仍需内容核对' }).check();
  219 |   await page.getByRole('button', { name: '确认并保存这份白板', exact: true }).click(); await page.getByRole('button', { name: '打开已保存白板', exact: true }).click();
  220 |   const player = page.getByRole('dialog', { name: '白板视频' }); await expect(player).toBeVisible();
  221 |   await expect(player.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).first()).toBeVisible();
  222 |   await player.getByRole('button', { name: '播放', exact: true }).click();
  223 |   await player.getByRole('button', { name: '放大参考图：先核对观察', exact: true }).first().click();
  224 |   const unit = await page.locator('.wb-current-sentence').getAttribute('data-unit-id');
  225 |   await expect(page.locator('.cl-figure-reader-sheet')).toBeVisible(); await expect(player.getByRole('button', { name: '播放', exact: true })).toBeVisible();
  226 |   await page.keyboard.press('Escape'); await expect(player).toBeVisible(); await expect(page.locator('.cl-figure-reader-sheet')).toHaveCount(0);
  227 |   await expect(page.locator('.wb-current-sentence')).toHaveAttribute('data-unit-id', unit!);
  228 |   await page.screenshot({ path: join(browserEvidence('topic-whiteboard'), 'topic-figure-saved-player.png'), fullPage: false });
  229 |   const board = await f.call(base + '/' + (await f.call(base + '/drafts/' + id, undefined, 'GET')).whiteboardId, undefined, 'GET');
  230 |   expect(JSON.stringify(board)).not.toContain(candidate.id); expect(board.scenes[0].figure.sha256).toBe(candidate.sha256);
  231 |   const downloaded = page.waitForEvent('download', { timeout: 30000 }); await player.getByRole('button', { name: '导出视频', exact: true }).click();
  232 |   const video = await downloaded, videoPath = (await video.path())!, directory = browserEvidence('topic-whiteboard'); copyFileSync(videoPath, join(directory, 'topic-figure-video.webm'));
  233 |   const probe = JSON.parse(execFileSync(process.env.STUDY_FFPROBE ?? 'ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', videoPath], { encoding: 'utf8', windowsHide: true }));
  234 |   expect(probe.streams.some((stream: any) => stream.codec_type === 'audio')).toBe(true); expect(probe.streams.some((stream: any) => stream.codec_type === 'video')).toBe(true);
  235 |   const frame = spawnSync(process.env.STUDY_FFMPEG ?? 'ffmpeg', ['-v', 'error', '-ss', '0.2', '-i', videoPath, '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'], { windowsHide: true, maxBuffer: 8 * 1024 * 1024 });
  236 |   expect(frame.status).toBe(0); const decoded = await sharp(frame.stdout).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  237 |   expect([decoded.info.width, decoded.info.height, decoded.info.channels]).toEqual([1280, 720, 3]);
  238 |   let blue = 0, warm = 0;
  239 |   for (let y = 206; y < 566; y++) for (let x = 88; x < 698; x++) {
  240 |     const offset = (y * 1280 + x) * 3, r = decoded.data[offset], g = decoded.data[offset + 1], b = decoded.data[offset + 2];
  241 |     if (b > r + 5 && b > g) blue++; if (r > b + 10 && g > b + 5) warm++;
  242 |   }
  243 |   expect(blue).toBeGreaterThan(9000); expect(warm).toBeGreaterThan(9000);
  244 |   writeFileSync(join(directory, 'topic-figure-video-first-frame.png'), frame.stdout); writeFileSync(join(directory, 'topic-figure-video-probe.json'), JSON.stringify({ probe, decodedImageRegion: { blue, warm } }, null, 2) + '\n');
  245 |   const captions = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); const srt = readFileSync((await (await captions).path())!, 'utf8');
  246 |   expect(srt).toContain('00:00:00,000 --> 00:00:02,000'); expect(srt).toContain('00:00:10,000 --> 00:00:12,000'); writeFileSync(join(directory, 'topic-figure-video.srt'), srt);
  247 |   const later: string[] = []; page.on('download', value => later.push(value.suggestedFilename()));
  248 |   await page.route('**/api/learning/studio/topic-whiteboards/*/figures/*/image', route => route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.from('Changed frozen image fixture') }));
  249 |   await player.getByRole('button', { name: '导出视频', exact: true }).click(); await expect(player.locator('.sa-whiteboard-notice')).toContainText('字节与已保存版本不一致'); expect(later).toEqual([]);
  250 |   const retained = page.waitForEvent('download'); await player.getByRole('button', { name: '导出字幕', exact: true }).click(); expect(readFileSync((await (await retained).path())!, 'utf8')).toBe(srt);
  251 | });
  252 | 
  253 | test('topic-figure: uncached complete image commands block leaving until their exact complete download', async ({ page }) => {
  254 |   await fixture(page); await generate(page); await ready(page);
  255 |   await page.evaluate(() => { const original = Storage.prototype.setItem; Storage.prototype.setItem = function (key, value) {
  256 |     if (key.startsWith('studyagent.topic-whiteboard.figures.')) throw new DOMException('Synthetic unavailable image storage', 'QuotaExceededError'); return original.call(this, key, value);
  257 |   }; });
  258 |   let writes = 0;
```