# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chemistry.spec.ts >> chemistry assistant: actual course teaching and cited sources return to its original unit at 1440
- Location: tests\e2e\chemistry.spec.ts:204:38

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: '返回本课', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f4e1]:
  - alert [ref=f4e2]
  - main [ref=f4e3]:
    - complementary "学习工作台导航" [ref=f4e4]:
      - generic [ref=f4e5]:
        - generic [ref=f4e6]:
          - link "StudyAgent 学习工作台" [ref=f4e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f4e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f4e11] [cursor=pointer]
        - generic [ref=f4e14]:
          - navigation "工作台主要入口" [ref=f4e15]:
            - button "Home" [ref=f4e16] [cursor=pointer]:
              - generic [ref=f4e19]: 首页
            - button "Courses" [ref=f4e20] [cursor=pointer]:
              - generic [ref=f4e23]: 课程
            - button "Calendar" [ref=f4e24] [cursor=pointer]:
              - generic [ref=f4e27]: 学习动态
            - button "History" [ref=f4e28] [cursor=pointer]:
              - generic [ref=f4e31]: 历史
            - button "Materials" [ref=f4e32] [cursor=pointer]:
              - generic [ref=f4e35]: 资料
            - link "AI Whiteboards" [ref=f4e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f4e39]: AI白板
          - button "＋ 创建课程" [ref=f4e40] [cursor=pointer]
          - generic [ref=f4e41]:
            - region "继续学习" [ref=f4e42]:
              - heading "继续学习" [level=3] [ref=f4e44]
              - link "建立广州人教版九上化学课程 七个单元、28个知识目标；诊断、独立考核与间隔复测分别保留证据。" [ref=f4e45] [cursor=pointer]:
                - /url: /studio?view=courses&student=student_5278ff82-48d6-4d7d-9836-6873e5306c4b&subject=chemistry&course=chemistry-course%3Astudent_5278ff82-48d6-4d7d-9836-6873e5306c4b%3Aguangzhou-pep-chemistry-9-upper-v1
                - generic [ref=f4e46]: 建立广州人教版九上化学课程
                - generic [ref=f4e48]: 七个单元、28个知识目标；诊断、独立考核与间隔复测分别保留证据。
            - heading "近期活动" [level=3] [ref=f4e51]
        - link "返回学习首页" [ref=f4e53] [cursor=pointer]:
          - /url: /learn?subject=chemistry&student=student_5278ff82-48d6-4d7d-9836-6873e5306c4b
          - text: 返回学习首页 →
    - generic [ref=f4e54]:
      - generic [ref=f4e55]:
        - generic [ref=f4e56]:
          - combobox "学习档案" [ref=f4e57]:
            - option "九上化学验收" [selected]
          - combobox "学科" [ref=f4e58]:
            - option "数学"
            - option "语文"
            - option "英语"
            - option "化学" [selected]
        - generic [ref=f4e59]:
          - link "教学课堂 ↗" [ref=f4e60] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f4e61] [cursor=pointer]:
            - /url: /
      - generic [ref=f4e62]:
        - generic [ref=f4e63]:
          - button "Craft Courses" [ref=f4e64] [cursor=pointer]
          - button "Instant Assistance" [ref=f4e65] [cursor=pointer]
        - generic [ref=f4e66]:
          - heading "Time for flashcards?" [level=1] [ref=f4e68]
          - region "课程学习助教" [ref=f4e69]:
            - generic [ref=f4e70]:
              - generic [ref=f4e71]:
                - generic [ref=f4e72]: 当前学习对话
                - button "查找历史" [ref=f4e73] [cursor=pointer]
              - generic [ref=f4e74]:
                - generic [ref=f4e75]:
                  - text: 当前会话关键词
                  - textbox "检索当前对话" [ref=f4e76]
                - button "查找这段对话" [disabled] [ref=f4e77]
                - button "恢复最近消息" [ref=f4e78] [cursor=pointer]
              - log "当前学习对话" [ref=f4e79]:
                - article [ref=f4e80]:
                  - strong [ref=f4e81]: 我
                  - paragraph [ref=f4e82]: "[cite-course] 请解释这一单元的化学概念和判断证据。"
                - article [active] [ref=f4e83]:
                  - strong [ref=f4e84]: 学习助教
                  - paragraph [ref=f4e85]: 先列出已有条件，再说明卡住的一步。用一个独立新例子核查，不凭一次表现确定原因。
                  - navigation "本次回答的教学出处" [ref=f4e86]:
                    - link "燃烧条件与充分燃烧" [ref=f4e87] [cursor=pointer]:
                      - /url: /studio?view=home&mode=instant&assistantSourceSession=assistant_session_3d9789dc-8213-4e3a-9c11-16b719964ddf&assistantSourceKey=atom-1&audience=course&courseKind=primary_unit&courseId=chemistry-course%3Astudent_5278ff82-48d6-4d7d-9836-6873e5306c4b%3Aguangzhou-pep-chemistry-9-upper-v1&courseItem=unit%3A7%3A%E7%87%83%E6%96%99%E3%80%81%E8%83%BD%E6%BA%90%E4%B8%8E%E7%8E%AF%E5%A2%83&courseVersion=5273afe684258047b30fb97587bffdd725a0ac847866a6423c1f253a2d059bb6&assistantSourceMessage=assistant_message_2bb980c8-54c7-4c11-ad6c-dbbbce4719fb
                      - text: ↗ 燃烧条件与充分燃烧
                  - generic [ref=f4e88]: Synthetic assistant · deepseek-v4-flash · 小九AI建议
              - region "提问任务" [ref=f4e89]:
                - generic [ref=f4e90]:
                  - status [ref=f4e91]: 回答已保存
                  - generic [ref=f4e92]: DeepSeek V4.1 Flash
                - group [ref=f4e93]:
                  - generic "原问题与记录" [ref=f4e94] [cursor=pointer]
              - group [ref=f4e95]:
                - generic "提问记录（已读取 1 条）" [ref=f4e96] [cursor=pointer]
              - generic [ref=f4e97]:
                - generic [ref=f4e98]:
                  - region "当前课程上下文" [ref=f4e99]:
                    - generic [aria-hidden] [ref=f4e100]: ▣
                    - generic [ref=f4e101]:
                      - strong [ref=f4e102]: "Unit 7: 燃料、能源与环境"
                      - generic [ref=f4e103]:
                        - generic [ref=f4e104]: 小学单元 · 已确认课程
                        - generic [ref=f4e105]: 广州人教版九上化学 · 学习与验证
                    - button "移除课程上下文" [ref=f4e106] [cursor=pointer]: ×
                  - link "返回本课 ↗" [ref=f4e107] [cursor=pointer]:
                    - /url: /studio?course=chemistry-course%3Astudent_5278ff82-48d6-4d7d-9836-6873e5306c4b%3Aguangzhou-pep-chemistry-9-upper-v1&student=student_5278ff82-48d6-4d7d-9836-6873e5306c4b&subject=chemistry&view=courses&unit=unit%3A7%3A%E7%87%83%E6%96%99%E3%80%81%E8%83%BD%E6%BA%90%E4%B8%8E%E7%8E%AF%E5%A2%83
                  - generic [ref=f4e108]:
                    - generic [ref=f4e109]: 完整正文 · 4/4 知识目标 · 28/28 教学条目
                    - generic [ref=f4e110]:
                      - button "重新核对课程" [ref=f4e111] [cursor=pointer]
                      - button "选择教学范围" [ref=f4e112] [cursor=pointer]
                  - generic [ref=f4e113]:
                    - generic [ref=f4e114]: 想一起看看什么
                    - textbox "想一起看看什么" [ref=f4e115]:
                      - /placeholder: 问一个概念，或告诉我想理清的问题…
                      - text: 保留原化学单元的问题草稿。
                  - generic [ref=f4e116]:
                    - generic [ref=f4e117]:
                      - button "打开学习资料" [ref=f4e118] [cursor=pointer]: ＋
                      - button "学习计划" [ref=f4e119] [cursor=pointer]
                    - generic [ref=f4e120]:
                      - generic [ref=f4e121]:
                        - generic [ref=f4e122]:
                          - generic [ref=f4e123]: 模型
                          - combobox "选择大模型" [ref=f4e124] [cursor=pointer]:
                            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                            - option "GPT-6.1 Sol"
                            - option "GPT-6 Astra"
                            - option "GPT-6 Luna"
                            - option "Grok-4.7"
                            - option "GLM-5.3 Flash"
                            - option "DeepSeek V4.1 Flash · 默认" [selected]
                            - option "Claude Opus 5.5"
                            - option "Claude Sonnet 5"
                            - option "GPT-6 Sol"
                            - option "GPT-5.6 Sol"
                            - option "GPT-5.6 Terra"
                            - option "GPT-5.6 Luna"
                            - option "GPT-5.5"
                            - option "Grok-4.6"
                            - option "GLM-5.2"
                            - option "GLM-5.3"
                            - option "Claude Opus 5"
                            - option "Claude Fable 5.1"
                            - option "MiMo V2.6 Pro"
                            - option "MiMo V2.6 Flash"
                            - option "MiMo V2.6 Pro Ultraspeed"
                            - option "Qwen3.8 Max"
                        - group [ref=f4e125]:
                          - generic "模型文字检查说明" [ref=f4e126] [cursor=pointer]: ⓘ
                      - button "发送学习问题" [ref=f4e127] [cursor=pointer]: ↑
                - paragraph [ref=f4e128]: 模型解释与课堂练习分别保留，不作为独立能力评测。
              - button "下载提问副本" [ref=f4e129] [cursor=pointer]
```

# Test source

```ts
  126 |   const selected = page.getByLabel('选择学生', { exact: true }); await expect(selected.locator('option:checked')).toContainText('新建九上化学档案');
  127 |   const createdId = await selected.inputValue(); expect(createdId).not.toBe(studentId);
  128 |   await page.getByRole('link', { name: '学习工作台', exact: true }).click();
  129 |   await expect(page.getByLabel('学习档案', { exact: true })).toHaveValue(createdId);
  130 |   await page.locator('.ws-navigation').getByRole('button', { name: 'Courses', exact: true }).click(); await enroll(page);
  131 |   await page.goto('/chemistry?' + new URLSearchParams({ studentId: createdId, unit: 'u7' }));
  132 |   await expect(page).toHaveURL(/\/studio\?/); await expect(page.getByLabel('学习档案', { exact: true })).toHaveValue(createdId);
  133 |   await expect(page.locator('.cl-unit-heading')).toContainText('燃料、能源与环境');
  134 |   await expect(page.getByRole('button', { name: '添加课程并开始学习', exact: true })).toHaveCount(0);
  135 | });
  136 | 
  137 | test('chemistry: viewing a course preserves an explicit primary profile until the parent changes it', async ({ page }) => {
  138 |   const { studentId, headers, call } = await fixture(page);
  139 |   const result = await fetch(api + '/students', { method: 'POST', headers, body: JSON.stringify({ nickname: '原有小学档案', grade: 3, preferredSessionMinutes: 15,
  140 |     defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }) });
  141 |   expect(result.status).toBe(201); const primaryId = (await result.json()).data.profile.id;
  142 |   await page.goto('/studio?' + new URLSearchParams({ view: 'courses', student: primaryId, subject: 'chemistry' })); await open(page);
  143 |   await expect(page.getByLabel('学习档案', { exact: true })).toHaveValue(primaryId);
  144 |   await expect(page.getByRole('button', { name: '添加课程并开始学习', exact: true })).toBeDisabled();
  145 |   expect((await call('/chemistry/catalog?studentId=' + primaryId)).studentId).toBe(primaryId);
  146 |   expect((await call('/learning/studio/overview?' + new URLSearchParams({ studentId, subject: 'chemistry' }))).courses).toHaveLength(0);
  147 |   await page.getByLabel('学习档案', { exact: true }).selectOption(studentId); await enroll(page);
  148 |   expect((await call('/learning/studio/overview?' + new URLSearchParams({ studentId, subject: 'chemistry' }))).courses).toHaveLength(1);
  149 | });
  150 | 
  151 | test('chemistry: a chemical course request cannot reuse mathematics and old subject parameters cannot override course content', async ({ page }) => {
  152 |   const { studentId, headers, call } = await fixture(page);
  153 |   const child = await fetch(api + '/students', { method: 'POST', headers, body: JSON.stringify({ nickname: '旧数学范围验收', grade: 4, preferredSessionMinutes: 15,
  154 |     defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }) });
  155 |   expect(child.status).toBe(201); const primaryId = (await child.json()).data.profile.id;
  156 |   const scope = await fetch(api + `/students/${primaryId}/learning-scope`, { method: 'PUT', headers, body: JSON.stringify({ subject: 'math', grade: 4, term: 'upper',
  157 |     textbookVolumeId: null, textbookVersion: '四年级数学范围', learnedAtomIds: ['foundation:math:multiplytwo', 'foundation:math:remainder', 'foundation:math:rectanglearea'],
  158 |     currentAtomId: 'foundation:math:multiplytwo', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }) });
  159 |   expect(scope.status).toBe(200);
  160 |   await page.goto('/studio?' + new URLSearchParams({ student: primaryId, subject: 'math', view: 'home' }));
  161 |   await page.locator('.sa-composer textarea').fill('广东初三化学上学期'); await page.locator('.sa-composer').getByRole('button', { name: '↑', exact: true }).click();
  162 |   const dialog = page.getByRole('dialog', { name: '课程蓝图', exact: true });
  163 |   await expect(dialog).toContainText('课程名称要求化学，当前选择的是数学范围');
  164 |   await expect(dialog.getByRole('button', { name: '预览课程蓝图', exact: true })).toBeDisabled();
  165 |   await screenshot(page, 'reject-math-scope');
  166 |   expect((await call('/learning/studio/overview?' + new URLSearchParams({ studentId: primaryId, subject: 'math' }))).courses).toHaveLength(0);
  167 |   await dialog.getByRole('link', { name: '打开九上化学课程与考核 →', exact: true }).click();
  168 |   await expect(page.getByRole('heading', { name: courseTitle, exact: true })).toBeVisible();
  169 |   await expect(page.locator('.cl-microlessons')).toContainText('物理变化与化学变化');
  170 |   await expect(page.locator('.cl-outline')).not.toContainText('两位数乘两位数');
  171 |   await page.getByLabel('学习档案', { exact: true }).selectOption(studentId); await enroll(page);
  172 |   const catalog = await call('/chemistry/catalog?studentId=' + studentId);
  173 |   await page.goto('/studio?' + new URLSearchParams({ view: 'courses', student: studentId, subject: 'math', course: catalog.courseId }));
  174 |   await expect(page.getByLabel('学科', { exact: true })).toHaveValue('chemistry');
  175 |   await expect(page.getByRole('heading', { name: courseTitle, exact: true })).toBeVisible();
  176 |   await expect(page.locator('.cl-microlessons')).not.toContainText('两位数乘两位数');
  177 | });
  178 | 
  179 | test('chemistry: each unit opens actual chemical concepts and worked examples in the rendered classroom', async ({ page }) => {
  180 |   test.setTimeout(120000);
  181 |   const { studentId, call } = await fixture(page); await enroll(page);
  182 |   const catalog = await call('/chemistry/catalog?studentId=' + studentId);
  183 |   for (let index = 0; index < catalog.units.length; index++) {
  184 |     const expected = catalog.units[index].lessons[0];
  185 |     await page.getByRole('navigation', { name: '课程单元' }).getByRole('button').nth(index).click();
  186 |     await page.locator('.cl-learn').first().click(); await expect(page.locator('.cl-room')).toBeVisible();
  187 |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  188 |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  189 |     await expect(page.locator('.cl-board-paper')).toContainText(expected.teaching.explanation);
  190 |     await expect(page.locator('.cl-board-paper')).toContainText(expected.teaching.example.prompt);
  191 |     await expect(page.locator('.cl-board-paper')).toContainText(expected.teaching.example.conclusion);
  192 |     await expect(page.locator('.cl-room')).not.toContainText(/两位数乘两位数|余数与除数|长方形面积|异分母|通分/);
  193 |     const sessionId = new URL(page.url()).searchParams.get('session')!;
  194 |     const session = await call('/learning/classroom/sessions/' + sessionId);
  195 |     expect(session.lessonId).toBe('learn:' + expected.id);
  196 |     if ([0, 4, 6].includes(index)) await screenshot(page, 'actual-chemistry-body-unit-' + (index + 1));
  197 |     await page.getByRole('button', { name: '离开课堂', exact: true }).click();
  198 |     await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  199 |     await expect(page.getByRole('heading', { name: courseTitle, exact: true })).toBeVisible();
  200 |     await expect(page.getByRole('navigation', { name: '课程单元' }).getByRole('button').nth(index)).toHaveAttribute('data-active', 'true');
  201 |   }
  202 | });
  203 | 
  204 | for (const width of [390, 1440]) test('chemistry assistant: actual course teaching and cited sources return to its original unit at ' + width, async ({ page }) => {
  205 |   test.setTimeout(120000); await page.setViewportSize({ width, height: 960 });
  206 |   const { studentId, call } = await fixture(page); await open(page);
  207 |   await expect(page.getByRole('link', { name: '获取单元帮助', exact: true })).toHaveCount(0);
  208 |   await page.getByRole('button', { name: '添加课程并开始学习', exact: true }).click();
  209 |   const unit = page.getByRole('navigation', { name: '课程单元' }).getByRole('button').last(); await unit.click();
  210 |   const catalog = await call('/chemistry/catalog?studentId=' + studentId), actualUnit = catalog.course.units.at(-1);
  211 |   await expect(page.getByRole('link', { name: '获取单元帮助', exact: true })).toBeVisible();
  212 |   await page.getByRole('link', { name: '获取单元帮助', exact: true }).click();
  213 |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText(actualUnit.title);
  214 |   const question = '[cite-course] 请解释这一单元的化学概念和判断证据。';
  215 |   await page.getByLabel('想一起看看什么', { exact: true }).fill(question);
  216 |   await page.getByRole('button', { name: '发送学习问题', exact: true }).click();
  217 |   await expect(page.getByRole('region', { name: '提问任务', exact: true }).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 });
  218 |   const composer = page.getByLabel('想一起看看什么', { exact: true }); await composer.fill('保留原化学单元的问题草稿。');
  219 |   await page.getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first().click();
  220 |   await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  221 |   await expect(page.locator('.assistant-source-content')).toContainText(actualUnit.lessons.find((l: any) => l.kind === 'learn').teaching.teaching.explanation);
  222 |   await expect(page.locator('.assistant-source-panel')).not.toContainText(/两位数乘两位数|异分母|通分/);
  223 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  224 |   await screenshot(page, 'assistant-source-' + width);
  225 |   await page.getByRole('link', { name: '返回原对话', exact: true }).click(); await expect(composer).toHaveValue('保留原化学单元的问题草稿。');
> 226 |   await page.getByRole('link', { name: '返回本课', exact: true }).click();
      |                                                               ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  227 |   await expect(page.getByRole('heading', { name: courseTitle, exact: true })).toBeVisible();
  228 |   await expect(page.locator('.cl-unit-heading')).toContainText(actualUnit.title);
  229 |   await expect(page.getByRole('navigation', { name: '课程单元' }).getByRole('button').last()).toHaveAttribute('data-active', 'true');
  230 |   await page.reload(); await expect(page.locator('.cl-unit-heading')).toContainText(actualUnit.title);
  231 | });
  232 | 
```