# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: original-teaching-fonts.spec.ts >> original fonts: assistant and board register the captured faces once and the assistant prepares its real UI fonts
- Location: tests\e2e\original-teaching-fonts.spec.ts:132:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 815
Received: 2207
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - generic [ref=f1e5]:
        - generic [ref=f1e6]:
          - link "StudyAgent 学习工作台" [ref=f1e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f1e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f1e11] [cursor=pointer]
        - generic [ref=f1e14]:
          - navigation "工作台主要入口" [ref=f1e15]:
            - button "Home" [ref=f1e16] [cursor=pointer]:
              - generic [ref=f1e19]: 首页
            - button "Courses" [ref=f1e20] [cursor=pointer]:
              - generic [ref=f1e23]: 课程
            - button "Calendar" [ref=f1e24] [cursor=pointer]:
              - generic [ref=f1e27]: 学习动态
            - button "History" [ref=f1e28] [cursor=pointer]:
              - generic [ref=f1e31]: 历史
            - button "Materials" [ref=f1e32] [cursor=pointer]:
              - generic [ref=f1e35]: 资料
            - link "AI Whiteboards" [ref=f1e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f1e39]: AI白板
          - button "＋ 创建课程" [ref=f1e40] [cursor=pointer]
          - generic [ref=f1e41]:
            - region "继续学习" [ref=f1e42]:
              - heading "继续学习" [level=3] [ref=f1e44]
              - link "白板视频「异分母分数加法」 5 幕 · 27 秒" [ref=f1e45] [cursor=pointer]:
                - /url: /studio?whiteboard=studio_whiteboard_7e288ef6-1174-44b0-9e14-39d1fb8f385a
                - generic [ref=f1e46]: 白板视频「异分母分数加法」
                - generic [ref=f1e48]: 5 幕 · 27 秒
            - heading "近期活动" [level=3] [ref=f1e51]
        - link "返回学习首页" [ref=f1e53] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_f41d86e8-1904-4e3f-9db4-143e7570c2c3
          - text: 返回学习首页 →
    - generic [ref=f1e54]:
      - generic [ref=f1e55]:
        - generic [ref=f1e56]:
          - combobox "学习档案" [ref=f1e57]:
            - option "匿名字体白板" [selected]
          - combobox "学科" [ref=f1e58]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e59]:
          - link "教学课堂 ↗" [ref=f1e60] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e61] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e62]:
        - generic [ref=f1e63]:
          - button "Craft Courses" [ref=f1e64] [cursor=pointer]
          - button "Instant Assistance" [ref=f1e65] [cursor=pointer]
        - generic [ref=f1e66]:
          - heading "把下一步，做成一条走得通的路。" [level=1] [ref=f1e67]
          - paragraph [ref=f1e68]: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
        - generic [ref=f1e69]:
          - textbox "围绕哪段学习内容设计课程？" [ref=f1e70]
          - generic [ref=f1e71]:
            - generic [ref=f1e72]: ＋
            - generic [ref=f1e73]: 资料
            - button "Concept Explanation" [ref=f1e74] [cursor=pointer]
            - generic [ref=f1e75]: 语音
            - generic [ref=f1e77]:
              - generic [ref=f1e78]:
                - generic [ref=f1e79]: 模型
                - combobox "选择大模型" [ref=f1e80] [cursor=pointer]:
                  - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                  - option "GPT-6.1 Sol"
                  - option "GPT-6 Astra"
                  - option "GPT-6 Luna"
                  - option "Grok-4.7"
                  - option "GLM-5.3 Flash"
                  - option "DeepSeek V4.1 Flash · 默认" [selected]
                  - option "Claude Opus 5.5"
                  - option "Claude Sonnet 5"
                  - option "GPT-6 Sol"
                  - option "GPT-5.6 Sol"
                  - option "GPT-5.6 Terra"
                  - option "GPT-5.6 Luna"
                  - option "GPT-5.5"
                  - option "Grok-4.6"
                  - option "GLM-5.2"
                  - option "GLM-5.3"
                  - option "Claude Opus 5"
                  - option "Claude Fable 5.1"
                  - option "MiMo V2.6 Pro"
                  - option "MiMo V2.6 Flash"
                  - option "MiMo V2.6 Pro Ultraspeed"
                  - option "Qwen3.8 Max"
              - generic [ref=f1e81]: 尚未进行文字检查
            - button "↑" [ref=f1e83] [cursor=pointer]
        - generic [ref=f1e84]:
          - button "可视化 用图形解释异分母加法 通分、合并与验算" [ref=f1e85] [cursor=pointer]:
            - generic [ref=f1e86]: 可视化
            - generic [ref=f1e87]: 用图形解释异分母加法
            - generic [ref=f1e88]: 通分、合并与验算
          - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围" [ref=f1e89] [cursor=pointer]:
            - generic [ref=f1e90]: 个性化练习
            - generic [ref=f1e91]: 从我的已知点生成练习
            - generic [ref=f1e92]: 只覆盖已确认范围
          - button "主动学习 看看今天最值得做什么 按教育优先级排序" [ref=f1e93] [cursor=pointer]:
            - generic [ref=f1e94]: 主动学习
            - generic [ref=f1e95]: 看看今天最值得做什么
            - generic [ref=f1e96]: 按教育优先级排序
        - generic [ref=f1e97]:
          - heading "你的学习路径" [level=2] [ref=f1e98]
          - button "创建课程" [ref=f1e99] [cursor=pointer]
        - generic [ref=f1e100]:
          - heading "还没有课程" [level=3] [ref=f1e101]
          - paragraph [ref=f1e102]: 先确认学习范围，再从已学知识生成可审核蓝图。
          - button "生成第一门课程" [ref=f1e103] [cursor=pointer]
        - complementary [ref=f1e104]:
          - article [ref=f1e105]:
            - generic [ref=f1e106]:
              - generic [ref=f1e107]:
                - text: LEARNER SNAPSHOT
                - heading "匿名字体白板" [level=2] [ref=f1e108]
              - generic [ref=f1e109]: 5 年级
            - generic [ref=f1e110]:
              - strong [ref=f1e111]: "0"
              - generic [ref=f1e112]: / 1
              - generic [ref=f1e113]: 已有点有稳定证据
            - generic [ref=f1e114]:
              - generic [ref=f1e115]:
                - generic [ref=f1e116]: "1"
                - text: 已确认知识点
              - generic [ref=f1e117]:
                - generic [ref=f1e118]: "0"
                - text: 日历安排
          - article [ref=f1e119]:
            - generic [ref=f1e120]:
              - generic [ref=f1e121]: NEXT BEST ACTION
              - button "全部 →" [ref=f1e122] [cursor=pointer]
            - link "1个已学点仍需补充证据 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。" [ref=f1e123] [cursor=pointer]:
              - /url: /student/assessment?studentId=student_f41d86e8-1904-4e3f-9db4-143e7570c2c3&subject=math
              - generic [ref=f1e124]: 1个已学点仍需补充证据
              - paragraph [ref=f1e125]: 未知或样本不足不是低能力；下一组评测会优先补齐可用的独立题族。
          - article [ref=f1e126]:
            - generic [ref=f1e127]:
              - generic [ref=f1e128]: RECENT WHITEBOARDS
              - button "新建" [ref=f1e129] [cursor=pointer]
            - button "▶ 异分母分数加法 5 幕 · 27 秒" [ref=f1e130] [cursor=pointer]:
              - generic [ref=f1e131]: ▶
              - generic [ref=f1e132]:
                - generic [ref=f1e133]: 异分母分数加法
                - generic [ref=f1e134]: 5 幕 · 27 秒
          - article [ref=f1e135]:
            - generic [ref=f1e136]:
              - generic [ref=f1e137]: SYNC STATUS
              - button "日历 →" [ref=f1e138] [cursor=pointer]
            - paragraph [ref=f1e139]: 0 个 LMS / 日历来源 · 0 个安排
            - generic [ref=f1e140]: 同步只读取课程日期；学习掌握仍由独立测量形成。
    - dialog "白板视频" [ref=f1e141]:
      - generic:
        - button "关闭白板" [active] [ref=f1e142] [cursor=pointer]: ×
        - heading "异分母分数加法" [level=2] [ref=f1e144]
      - navigation "白板视图" [ref=f1e145]:
        - generic [ref=f1e146]:
          - button "缩小白板" [ref=f1e147] [cursor=pointer]: −
          - button "重置白板视图" [ref=f1e148] [cursor=pointer]: 100%
          - button "放大白板" [ref=f1e149] [cursor=pointer]: +
        - group "白板页码" [ref=f1e150]:
          - button "上一页白板" [disabled] [ref=f1e151]: ‹
          - generic [ref=f1e152]:
            - generic [ref=f1e153]: "1"
            - generic [ref=f1e154]: /
            - generic [ref=f1e155]: "1"
          - button "下一页白板" [disabled] [ref=f1e156]: ›
        - group "白板工具" [ref=f1e157]:
          - button "分享与导出" [ref=f1e159] [cursor=pointer]
          - button "白板设置" [ref=f1e162] [cursor=pointer]
        - button "收起讲稿与笔记" [expanded] [ref=f1e165] [cursor=pointer]
      - button "静音" [ref=f1e167] [cursor=pointer]
      - generic [ref=f1e170]:
        - main [ref=f1e171]:
          - generic "异分母分数加法" [ref=f1e173]
          - paragraph [ref=f1e174]: 这次我们从“异分母分数加法”开始，把关键关系拆成看得见的步骤。
          - generic [ref=f1e175]:
            - generic [ref=f1e176]: 播放进度（估计阅读）
            - slider "播放进度（估计阅读）" [ref=f1e177] [cursor=pointer]: "0"
          - generic [ref=f1e178]:
            - button "上一句" [disabled] [ref=f1e179]: ←
            - button "播放" [ref=f1e180] [cursor=pointer]: ▶
            - button "下一句" [ref=f1e181] [cursor=pointer]: →
            - generic [ref=f1e182]: 1 / 10 句
            - combobox "阅读方式" [ref=f1e183] [cursor=pointer]:
              - option "文字阅读（估计时长）" [selected]
            - combobox "播放速度" [ref=f1e184] [cursor=pointer]:
              - option "0.5×"
              - option "0.75×"
              - option "1×" [selected]
              - option "1.25×"
              - option "1.5×"
              - option "2×"
            - generic [ref=f1e185]:
              - generic [ref=f1e186]: 板书字体
              - combobox "板书字体" [ref=f1e187] [cursor=pointer]:
                - option "手写板书" [selected]
                - option "标准板书"
            - generic [ref=f1e188]:
              - checkbox "点阵" [checked] [ref=f1e189]
              - text: 点阵
            - button "导出视频" [ref=f1e190] [cursor=pointer]
            - button "导出字幕" [ref=f1e191] [cursor=pointer]
          - status [ref=f1e192]
          - generic [ref=f1e193]:
            - button "01 异分母分数加法" [ref=f1e194] [cursor=pointer]:
              - generic [ref=f1e195]: "01"
              - text: 异分母分数加法
            - button "02 先建立概念" [ref=f1e196] [cursor=pointer]:
              - generic [ref=f1e197]: "02"
              - text: 先建立概念
            - button "03 跟着步骤走" [ref=f1e198] [cursor=pointer]:
              - generic [ref=f1e199]: "03"
              - text: 跟着步骤走
            - button "04 先统一切法，再合并份数" [ref=f1e200] [cursor=pointer]:
              - generic [ref=f1e201]: "04"
              - text: 先统一切法，再合并份数
            - button "05 换一道新题验证" [ref=f1e202] [cursor=pointer]:
              - generic [ref=f1e203]: "05"
              - text: 换一道新题验证
        - generic [ref=f1e206]:
          - separator "调整讲稿面板宽度" [ref=f1e207]
          - complementary "完整讲稿与要点" [ref=f1e209]:
            - button "收起讲稿与笔记" [ref=f1e210] [cursor=pointer]
            - region "原句提问" [ref=f1e213]:
              - generic [ref=f1e214]:
                - heading "一起想清楚" [level=3] [ref=f1e215]
                - generic [ref=f1e216]: AI补充讲解
              - group [ref=f1e217]:
                - generic "带走完整教学笔记" [ref=f1e218] [cursor=pointer]
              - paragraph [ref=f1e220]: 哪里没听懂，就从那一句问起。
              - generic [ref=f1e221]:
                - generic [ref=f1e222]: 向老师提问
                - textbox "向老师提问" [ref=f1e223]:
                  - /placeholder: 对这句有疑问？
                - generic [ref=f1e224]:
                  - combobox "讲解方式" [ref=f1e225]:
                    - option "问一个问题" [selected]
                    - option "换个例子"
                    - option "讲简单些"
                    - option "补补基础"
                    - option "对比理解"
                  - generic [ref=f1e226]:
                    - combobox "选择大模型" [ref=f1e228] [cursor=pointer]:
                      - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                      - option "GPT-6.1 Sol"
                      - option "GPT-6 Astra"
                      - option "GPT-6 Luna"
                      - option "Grok-4.7"
                      - option "GLM-5.3 Flash"
                      - option "DeepSeek V4.1 Flash · 默认" [selected]
                      - option "Claude Opus 5.5"
                      - option "Claude Sonnet 5"
                      - option "GPT-6 Sol"
                      - option "GPT-5.6 Sol"
                      - option "GPT-5.6 Terra"
                      - option "GPT-5.6 Luna"
                      - option "GPT-5.5"
                      - option "Grok-4.6"
                      - option "GLM-5.2"
                      - option "GLM-5.3"
                      - option "Claude Opus 5"
                      - option "Claude Fable 5.1"
                      - option "MiMo V2.6 Pro"
                      - option "MiMo V2.6 Flash"
                      - option "MiMo V2.6 Pro Ultraspeed"
                      - option "Qwen3.8 Max"
                    - generic [ref=f1e229]: 尚未进行文字检查
                  - button "发送" [disabled] [ref=f1e231]
                - group [ref=f1e232]:
                  - generic "保留与恢复提问" [ref=f1e233] [cursor=pointer]
            - heading "逐句讲稿" [level=3] [ref=f1e234]
            - paragraph [ref=f1e235]: 点击一句定位。观看与续播不计作掌握。
            - list [ref=f1e236]:
              - listitem [ref=f1e237]:
                - button "这次我们从“异分母分数加法”开始，把关键关系拆成看得见的步骤。" [ref=f1e238] [cursor=pointer]
              - listitem [ref=f1e239]:
                - button "异分母分数的份大小不同，先通分成同一分数单位，再相加份数；分母代表单位，不随份数相加。" [ref=f1e240] [cursor=pointer]
              - listitem [ref=f1e241]:
                - button "现在用“计算2/3+1/4。”" [ref=f1e242] [cursor=pointer]
              - listitem [ref=f1e243]:
                - button "做一次示范。" [ref=f1e244] [cursor=pointer]
              - listitem [ref=f1e245]:
                - button "共同分母取12，2/3=8/12，1/4=3/12。" [ref=f1e246] [cursor=pointer]
              - listitem [ref=f1e247]:
                - button "8个十二分之一加3个十二分之一，得11/12。" [ref=f1e248] [cursor=pointer]
              - listitem [ref=f1e249]:
                - button "和11/12。" [ref=f1e250] [cursor=pointer]
              - listitem [ref=f1e251]:
                - button "三段中的两段不能直接和四段中的一段相加；都改写成十二分之一后，才能数总份数。" [ref=f1e252] [cursor=pointer]
              - listitem [ref=f1e253]:
                - button "看懂演示不等于掌握。" [ref=f1e254] [cursor=pointer]
              - listitem [ref=f1e255]:
                - button "收起画面后，要用不同数值的独立新题和延迟复测再核查。" [ref=f1e256] [cursor=pointer]
            - heading "完整笔记与来源" [level=3] [ref=f1e257]
            - group [ref=f1e258]:
              - generic "异分母分数加法" [ref=f1e259] [cursor=pointer]
              - paragraph [ref=f1e260]: 异分母分数加法：先理解单位，再通分。
            - group [ref=f1e261]:
              - generic "先建立概念" [ref=f1e262] [cursor=pointer]
            - group [ref=f1e263]:
              - generic "跟着步骤走" [ref=f1e264] [cursor=pointer]
            - group [ref=f1e265]:
              - generic "先统一切法，再合并份数" [ref=f1e266] [cursor=pointer]
            - group [ref=f1e267]:
              - generic "换一道新题验证" [ref=f1e268] [cursor=pointer]
            - button "下载续播位置" [ref=f1e269] [cursor=pointer]
```

# Test source

```ts
  36  |   const loaded = await page.evaluate(() => [...new Set(Array.from(document.fonts).filter(face => face.status === 'loaded').map(face => face.family.replace(/^['"]|['"]$/g, '')))]);
  37  |   for (const family of ['Virgil', 'Xiaolai', 'Satoshi-Regular', 'Satoshi-Medium', 'Satoshi-Bold', 'MiSans']) expect(loaded).toContain(family);
  38  |   await expect.poll(() => page.evaluate(() => (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.some(font => /Virgil/.test(font) && /Xiaolai/.test(font)))).toBe(true);
  39  |   expect(requests.length).toBeGreaterThan(4); for (const request of requests) expect(new URL(request).pathname).toMatch(/^\/reference\/hyperknow\//);
  40  |   const manifest = JSON.parse(readFileSync(join(process.cwd(), 'apps/web/public/reference/hyperknow/asset-manifest.json'), 'utf8'));
  41  |   for (const request of [...new Set(requests)].slice(0, 8)) {
  42  |     const entry = manifest.files.find((entry: { publicPath: string }) => entry.publicPath === new URL(request).pathname); expect(entry).toBeTruthy();
  43  |     const response = await page.request.get(request), bytes = await response.body(); expect(response.status()).toBe(200); expect(createHash('sha256').update(bytes).digest('hex')).toBe(entry.sha256);
  44  |   }
  45  |   writeFileSync(join(browserEvidence('original-teaching-fonts'), 'actual-loaded-fonts.json'), JSON.stringify({ loaded, requests, originalFontManifest: manifest.captureFingerprint }, null, 2) + '\n');
  46  |   await page.screenshot({ path: join(browserEvidence('original-teaching-fonts'), 'actual-board-fonts.png'), fullPage: true });
  47  | });
  48  | 
  49  | test('original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board', async ({ page }) => {
  50  |   const url = await board(page); let blocked = false;
  51  |   await page.route('**/reference/hyperknow/assets/woff2/Xiaolai-*.woff2*', async route => { if (!blocked) { blocked = true; await route.abort('failed'); } else await route.continue(); });
  52  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  53  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'error'); expect(blocked).toBe(true); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeDisabled(); await expect(dialog.getByRole('button', { name: '导出视频', exact: true })).toBeDisabled();
  54  |   await page.unrouteAll({ behavior: 'wait' }); await dialog.getByRole('button', { name: '重新准备板书字体' }).click();
  55  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  56  |   expect(page.url()).toContain(new URL(url, 'http://fixture').searchParams.get('whiteboard')!);
  57  | });
  58  | 
  59  | test('teaching frame: moving to another scene retains already taught notes, excludes future scenes and keeps one full caption', async ({ page }) => {
  60  |   const url = await board(page);
  61  |   await page.addInitScript(() => {
  62  |     const clear = CanvasRenderingContext2D.prototype.clearRect, fill = CanvasRenderingContext2D.prototype.fillText;
  63  |     const state = window as unknown as { latestTeachingFrame: string[] }; state.latestTeachingFrame = [];
  64  |     CanvasRenderingContext2D.prototype.clearRect = function (...args: Parameters<CanvasRenderingContext2D['clearRect']>) { state.latestTeachingFrame = []; return clear.apply(this, args); };
  65  |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) { state.latestTeachingFrame.push(args[0]); return fill.apply(this, args); };
  66  |   });
  67  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  68  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  69  |   const scenes = dialog.locator('.sa-scene-strip button'), title = async (index: number) => (await scenes.nth(index).innerText()).replace(/^\d+\s*/u, '').trim();
  70  |   const first = await title(0), second = await title(1), third = await title(2);
  71  |   await scenes.nth(1).click();
  72  |   await expect.poll(() => page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).toEqual(expect.arrayContaining([first, second]));
  73  |   expect(await page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).not.toContain(third);
  74  |   const sentence = dialog.locator('.wb-current-sentence'); await expect(sentence).toHaveCount(1);
  75  |   const unit = await sentence.getAttribute('data-unit-id'); await dialog.getByRole('button', { name: '缩小白板', exact: true }).click();
  76  |   await expect(sentence).toHaveAttribute('data-unit-id', unit!); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  77  |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'cumulative-second-scene.png') });
  78  | });
  79  | 
  80  | for (const width of [390, 768, 1280]) test('teaching shell: actual original chrome, font switch and return fit ' + width, async ({ page }) => {
  81  |   await page.setViewportSize({ width, height: 800 }); const url = await board(page);
  82  |   const styles = () => page.evaluate(() => { const style = getComputedStyle(document.body); return { font: style.fontFamily, color: style.color, background: style.backgroundColor }; });
  83  |   const before = await styles(); await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  84  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  85  |   expect(await dialog.evaluate(element => { const bounds = element.getBoundingClientRect(); return { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height }; })).toEqual({ x: 0, y: 0, width, height: 800 });
  86  |   const sentence = dialog.locator('.wb-current-sentence'), unit = await sentence.getAttribute('data-unit-id');
  87  |   await dialog.getByRole('combobox', { name: '板书字体', exact: true }).selectOption('standard');
  88  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(sentence).toHaveAttribute('data-unit-id', unit!);
  89  |   await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  90  |   const overflow = await dialog.evaluate(element => element.scrollWidth - element.clientWidth); expect(overflow).toBeLessThanOrEqual(1);
  91  |   await dialog.getByRole('combobox', { name: '板书字体', exact: true }).selectOption('handwriting'); await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  92  |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'original-shell-' + width + '.png') });
  93  |   await dialog.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(dialog).toHaveCount(0);
  94  |   await page.goto('/learn'); expect(await styles()).toEqual(before);
  95  | });
  96  | 
  97  | test('original fonts: captured math faces stay isolated and the real formula editor decodes its own local font bytes after a board closes', async ({ page }) => {
  98  |   const oldFile='apps/web/public/reference/hyperknow/font-faces-873aea85d4e2b6ae.css',legacySha=createHash('sha256').update(readFileSync(join(process.cwd(),oldFile))).digest('hex');
  99  |   await page.addInitScript(({legacySha})=>document.addEventListener('DOMContentLoaded',()=>{if(!new URL(location.href).searchParams.has('whiteboard'))return;const link=document.createElement('link');link.rel='stylesheet';link.href='/reference/hyperknow/font-faces-873aea85d4e2b6ae.css';link.dataset.originalTeachingFonts=legacySha;document.head.append(link);}),{legacySha});
  100 |   await page.goto(await board(page)); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  101 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  102 |   const captured = await page.evaluate(() => {
  103 |     const link = document.querySelector<HTMLLinkElement>('link[data-original-teaching-fonts]');
  104 |     return Array.from(link!.sheet!.cssRules).filter(rule => rule instanceof CSSFontFaceRule).map(rule => (rule as CSSFontFaceRule).style.getPropertyValue('font-family').replace(/^['"]|['"]$/g,''));
  105 |   });
  106 |   expect(captured.filter(family => family.startsWith('HKOriginal-KaTeX_')).length).toBeGreaterThan(0);
  107 |   expect(captured.filter(family => family.startsWith('KaTeX_'))).toEqual([]);
  108 |   await expect(page.locator('link[data-original-teaching-fonts="'+legacySha+'"]')).toHaveCount(0);
  109 |   await dialog.getByRole('button', { name: '关闭白板', exact: true }).click();
  110 |   const principal='answer-font-'+randomUUID()+'@local.test',credential='Synthetic-math-font-only-20261027',address='198.19.223.131';
  111 |   async function call(path:string,body:object,token?:string) { const response=await fetch(api+path,{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':address,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});expect(response.ok,path+' '+response.status).toBe(true);return(await response.json()).data; }
  112 |   const actor=await call('/auth/register',{principal,credential}),student=(await call('/students',{nickname:'匿名字体输入',grade:3,preferredSessionMinutes:15,defaultVersionMap:{math:'',chinese:'',english:''}},actor.token)).profile;
  113 |   const fixture=await call('/qa/answer-journeys',{studentId:student.id,mode:'formula_blank',kind:'diagnostic'},actor.token);
  114 |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  115 |   const requests:Array<{url:string;status:number}>=[];
  116 |   page.on('response',response=>{const path=new URL(response.url()).pathname;if(path.startsWith('/vendor/mathlive/fonts/')||/\/_next\/static\/media\/KaTeX_.*\.woff2$/.test(path))requests.push({url:response.url(),status:response.status()});});
  117 |   await page.goto(fixture.href);const field=page.locator('math-field').first();await expect(field).toBeVisible();await field.click();
  118 |   await field.evaluate(element=>(element as any).setValue('\\left(\\frac{1+\\sqrt{x^2+1}}{y^3}\\right)'));
  119 |   await expect.poll(()=>requests.length).toBeGreaterThan(0);await page.evaluate(()=>document.fonts.ready);
  120 |   expect(requests.every(request=>request.status===200)).toBe(true);
  121 |   await expect.poll(()=>page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded'&&/KaTeX_/.test(face.family)&&!face.family.includes('HKOriginal-')).length)).toBeGreaterThan(0);
  122 |   const loaded=await page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded'&&/KaTeX_/.test(face.family)&&!face.family.includes('HKOriginal-')).map(face=>face.family));
  123 |   expect(loaded.length).toBeGreaterThan(0);
  124 |   const actualFontDigests=[];
  125 |   for(const request of requests){const match=new URL(request.url).pathname.match(/\/(KaTeX_[A-Za-z0-9_-]+)\.[a-f0-9]+\.woff2$/i);if(!match)continue;const response=await page.request.get(request.url),bytes=await response.body(),file=match[1]+'.woff2',expected=readFileSync(join(process.cwd(),'node_modules/katex/dist/fonts',file));expect(createHash('sha256').update(bytes).digest('hex')).toBe(createHash('sha256').update(expected).digest('hex'));actualFontDigests.push({file,sha256:createHash('sha256').update(bytes).digest('hex')});}
  126 |   expect(actualFontDigests.length).toBeGreaterThan(0);
  127 |   const response=await page.request.get('/vendor/mathlive/manifest.json');expect(response.status()).toBe(200);const manifest=await response.json();expect(manifest.files).toHaveLength(20);
  128 |   for(const file of manifest.files){const font=await page.request.get('/vendor/mathlive/'+file.path),bytes=await font.body();expect(font.status()).toBe(200);expect(bytes.length).toBe(file.size);expect(createHash('sha256').update(bytes).digest('hex')).toBe(file.sha256);}
  129 |   const directory=browserEvidence('original-math-font-isolation');writeFileSync(join(directory,'actual-math-editor-fonts.json'),JSON.stringify({capturedMathAliases:captured.filter(family=>family.startsWith('HKOriginal-KaTeX_')),requests,loaded,actualFontDigests,manifest},null,2)+'\n');await field.screenshot({path:join(directory,'actual-tall-formula.png')});
  130 | });
  131 | 
  132 | test('original fonts: assistant and board register the captured faces once and the assistant prepares its real UI fonts',async({page})=>{
  133 |   const registry=JSON.parse(readFileSync(join(process.cwd(),'apps/web/lib/original-teaching-fonts.json'),'utf8')),families=registry.families.map((row:{family:string})=>row.family);
  134 |   const count=()=>page.evaluate(names=>Array.from(document.fonts).filter(face=>names.includes(face.family.replace(/^['"]|['"]$/g,''))).length,families);
  135 |   await page.goto(await board(page));const dialog=page.getByRole('dialog',{name:'白板视频',exact:true});await expect(dialog).toHaveAttribute('data-original-font-status','ready');
> 136 |   const declared=await count();writeFileSync(join(browserEvidence('original-teaching-fonts'),'single-registry-before-assistant.json'),JSON.stringify({expected:registry.faceCount,declared},null,2)+'\n');expect(declared).toBe(registry.faceCount);
      |                                                                                                                                                                                                                            ^ Error: expect(received).toBe(expected) // Object.is equality
  137 |   await page.goto('/studio?view=home&mode=instant&audience=independent');await expect(page.locator('.sa-instant-workspace')).toHaveAttribute('data-original-font-status','ready');await expect(page.getByLabel('想一起看看什么',{exact:true})).toBeEnabled();
  138 |   expect(await count()).toBe(registry.faceCount);const loaded=await page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded').map(face=>face.family.replace(/^['"]|['"]$/g,'')));
  139 |   for(const family of ['Satoshi-Regular','Satoshi-Medium','Satoshi-Bold','MiSans'])expect(loaded).toContain(family);
  140 |   await expect(page.locator('link[data-original-teaching-fonts]')).toHaveCount(1);
  141 | });
  142 | 
```