# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: original-teaching-fonts.spec.ts >> original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board
- Location: tests\e2e\original-teaching-fonts.spec.ts:49:5

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByRole('dialog', { name: '白板视频', exact: true })
Expected: "ready"
Received: "error"
Timeout:  15000ms

Call log:
  - Expect "toHaveAttribute" getByRole('dialog', { name: '白板视频', exact: true }) with timeout 15000ms
  - waiting for getByRole('dialog', { name: '白板视频', exact: true })
    33 × locator resolved to <div role="dialog" aria-modal="true" aria-label="白板视频" data-original-font-status="error" class="sa-whiteboard-modal wb-sentence-player hk-teaching whiteboard-root">…</div>
       - unexpected value "error"

```

```yaml
- dialog "白板视频":
  - button "关闭白板": ×
  - heading "异分母分数加法" [level=2]
  - navigation "白板视图"
  - button "静音"
  - alert
  - main
  - separator "调整讲稿面板宽度"
  - complementary "完整讲稿与要点"
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { createHash, randomUUID } from 'node:crypto';
  3   | import { readFileSync, writeFileSync } from 'node:fs';
  4   | import { join } from 'node:path';
  5   | import { browserEvidence } from './evidence';
  6   | 
  7   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4168') + '/api';
  8   | test.afterEach(async ({ page }) => { await page.unrouteAll({ behavior: 'wait' }); });
  9   | async function board(page: Page) {
  10  |   const key = createHash('sha256').update(test.info().testId).digest(), address = '198.19.' + key[0] + '.' + key[1], principal = 'font-fixture-' + randomUUID(), credential = 'Synthetic-fonts-only-20261027';
  11  |   await page.setExtraHTTPHeaders({ 'X-Forwarded-For': address });
  12  |   async function call(path: string, body: object, token?: string, method = 'POST') {
  13  |     const response = await fetch(api + path, { method, headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': address, ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: JSON.stringify(body) });
  14  |     expect(response.ok, path + ' ' + response.status).toBe(true); return (await response.json()).data;
  15  |   }
  16  |   const actor = await call('/auth/register', { principal, credential }), child = (await call('/students', { nickname: '匿名字体白板', grade: 5, preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }, actor.token)).profile.id;
  17  |   await call('/students/' + child + '/learning-scope', { subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null, textbookVersion: '合成已学范围', learnedAtomIds: ['core:math:fractionadd'], currentAtomId: 'core:math:fractionadd', minutesPerSession: 15 }, actor.token, 'PUT');
  18  |   const command = { studentId: child, subject: 'math', prompt: '异分母分数加法：先理解单位，再通分。', atomId: 'core:math:fractionadd' }, preview = await call('/learning/studio/whiteboards/preview', command, actor.token);
  19  |   const saved = await call('/learning/studio/whiteboards', { ...command, fingerprint: preview.fingerprint, requestKey: randomUUID() }, actor.token);
  20  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  21  |   return '/studio?student=' + child + '&subject=math&whiteboard=' + saved.id;
  22  | }
  23  | 
  24  | test('original fonts: real captured Latin and Chinese faces decode before a board is measured, played or exported', async ({ page }) => {
  25  |   const url = await board(page), requests: string[] = [];
  26  |   page.on('request', request => { if (request.resourceType() === 'font') requests.push(request.url()); });
  27  |   await page.addInitScript(() => {
  28  |     const original = CanvasRenderingContext2D.prototype.fillText;
  29  |     (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts = [];
  30  |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) {
  31  |       (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.push(this.font); return original.apply(this, args);
  32  |     };
  33  |   });
  34  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  35  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  36  |   const loaded = await page.evaluate(() => [...new Set(Array.from(document.fonts).filter(face => face.status === 'loaded').map(face => face.family.replace(/^['"]|['"]$/g, '')))]);
  37  |   for (const family of ['Virgil', 'Xiaolai', 'Satoshi-Regular', 'Satoshi-Medium', 'Satoshi-Bold', 'MiSans']) expect(loaded).toContain(family);
  38  |   await expect.poll(() => page.evaluate(() => (window as unknown as { originalBoardFonts: string[] }).originalBoardFonts.some(font => /Virgil/.test(font) && /Xiaolai/.test(font)))).toBe(true);
  39  |   expect(requests.length).toBeGreaterThan(4); for (const request of requests) expect(new URL(request).pathname).toMatch(/^\/reference\/hyperknow\//);
  40  |   const manifest = JSON.parse(readFileSync(join(process.cwd(), 'apps/web/public/reference/hyperknow/asset-manifest.json'), 'utf8'));
  41  |   for (const request of [...new Set(requests)].slice(0, 8)) {
  42  |     const entry = manifest.files.find((entry: { publicPath: string }) => entry.publicPath === new URL(request).pathname); expect(entry).toBeTruthy();
  43  |     const response = await page.request.get(request), bytes = await response.body(); expect(response.status()).toBe(200); expect(createHash('sha256').update(bytes).digest('hex')).toBe(entry.sha256);
  44  |   }
  45  |   writeFileSync(join(browserEvidence('original-teaching-fonts'), 'actual-loaded-fonts.json'), JSON.stringify({ loaded, requests, originalFontManifest: manifest.captureFingerprint }, null, 2) + '\n');
  46  |   await page.screenshot({ path: join(browserEvidence('original-teaching-fonts'), 'actual-board-fonts.png'), fullPage: true });
  47  | });
  48  | 
  49  | test('original fonts: a failed captured glyph never starts playback and an explicit retry recovers the same board', async ({ page }) => {
  50  |   const url = await board(page); let blocked = false;
  51  |   await page.route('**/reference/hyperknow/assets/woff2/Xiaolai-*.woff2*', async route => { if (!blocked) { blocked = true; await route.abort('failed'); } else await route.continue(); });
  52  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  53  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'error'); expect(blocked).toBe(true); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeDisabled(); await expect(dialog.getByRole('button', { name: '导出视频', exact: true })).toBeDisabled();
  54  |   await page.unrouteAll({ behavior: 'wait' }); await dialog.getByRole('button', { name: '重新准备板书字体' }).click();
> 55  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
      |                        ^ Error: expect(locator).toHaveAttribute(expected) failed
  56  |   expect(page.url()).toContain(new URL(url, 'http://fixture').searchParams.get('whiteboard')!);
  57  | });
  58  | 
  59  | test('teaching frame: moving to another scene retains already taught notes, excludes future scenes and keeps one full caption', async ({ page }) => {
  60  |   const url = await board(page);
  61  |   await page.addInitScript(() => {
  62  |     const clear = CanvasRenderingContext2D.prototype.clearRect, fill = CanvasRenderingContext2D.prototype.fillText;
  63  |     const state = window as unknown as { latestTeachingFrame: string[] }; state.latestTeachingFrame = [];
  64  |     CanvasRenderingContext2D.prototype.clearRect = function (...args: Parameters<CanvasRenderingContext2D['clearRect']>) { state.latestTeachingFrame = []; return clear.apply(this, args); };
  65  |     CanvasRenderingContext2D.prototype.fillText = function (...args: Parameters<CanvasRenderingContext2D['fillText']>) { state.latestTeachingFrame.push(args[0]); return fill.apply(this, args); };
  66  |   });
  67  |   await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  68  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  69  |   const scenes = dialog.locator('.sa-scene-strip button'), title = async (index: number) => (await scenes.nth(index).innerText()).replace(/^\d+\s*/u, '').trim();
  70  |   const first = await title(0), second = await title(1), third = await title(2);
  71  |   await scenes.nth(1).click();
  72  |   await expect.poll(() => page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).toEqual(expect.arrayContaining([first, second]));
  73  |   expect(await page.evaluate(() => (window as unknown as { latestTeachingFrame: string[] }).latestTeachingFrame)).not.toContain(third);
  74  |   const sentence = dialog.locator('.wb-current-sentence'); await expect(sentence).toHaveCount(1);
  75  |   const unit = await sentence.getAttribute('data-unit-id'); await dialog.getByRole('button', { name: '缩小白板', exact: true }).click();
  76  |   await expect(sentence).toHaveAttribute('data-unit-id', unit!); await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  77  |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'cumulative-second-scene.png') });
  78  | });
  79  | 
  80  | for (const width of [390, 768, 1280]) test('teaching shell: actual original chrome, font switch and return fit ' + width, async ({ page }) => {
  81  |   await page.setViewportSize({ width, height: 800 }); const url = await board(page);
  82  |   const styles = () => page.evaluate(() => { const style = getComputedStyle(document.body); return { font: style.fontFamily, color: style.color, background: style.backgroundColor }; });
  83  |   const before = await styles(); await page.goto(url); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  84  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  85  |   expect(await dialog.evaluate(element => { const bounds = element.getBoundingClientRect(); return { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height }; })).toEqual({ x: 0, y: 0, width, height: 800 });
  86  |   const sentence = dialog.locator('.wb-current-sentence'), unit = await sentence.getAttribute('data-unit-id');
  87  |   await dialog.getByRole('combobox', { name: '板书字体', exact: true }).selectOption('standard');
  88  |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready'); await expect(sentence).toHaveAttribute('data-unit-id', unit!);
  89  |   await expect(dialog.getByRole('button', { name: '播放', exact: true })).toBeEnabled();
  90  |   const overflow = await dialog.evaluate(element => element.scrollWidth - element.clientWidth); expect(overflow).toBeLessThanOrEqual(1);
  91  |   await dialog.getByRole('combobox', { name: '板书字体', exact: true }).selectOption('handwriting'); await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  92  |   await page.screenshot({ path: join(browserEvidence('original-teaching-frames'), 'original-shell-' + width + '.png') });
  93  |   await dialog.getByRole('button', { name: '关闭白板', exact: true }).click(); await expect(dialog).toHaveCount(0);
  94  |   await page.goto('/learn'); expect(await styles()).toEqual(before);
  95  | });
  96  | 
  97  | test('original fonts: captured math faces stay isolated and the real formula editor decodes its own local font bytes after a board closes', async ({ page }) => {
  98  |   const oldFile='apps/web/public/reference/hyperknow/font-faces-873aea85d4e2b6ae.css',legacySha=createHash('sha256').update(readFileSync(join(process.cwd(),oldFile))).digest('hex');
  99  |   await page.addInitScript(({legacySha})=>document.addEventListener('DOMContentLoaded',()=>{if(!new URL(location.href).searchParams.has('whiteboard'))return;const link=document.createElement('link');link.rel='stylesheet';link.href='/reference/hyperknow/font-faces-873aea85d4e2b6ae.css';link.dataset.originalTeachingFonts=legacySha;document.head.append(link);}),{legacySha});
  100 |   await page.goto(await board(page)); const dialog = page.getByRole('dialog', { name: '白板视频', exact: true });
  101 |   await expect(dialog).toHaveAttribute('data-original-font-status', 'ready');
  102 |   const captured = await page.evaluate(() => {
  103 |     const link = document.querySelector<HTMLLinkElement>('link[data-original-teaching-fonts]');
  104 |     return Array.from(link!.sheet!.cssRules).filter(rule => rule instanceof CSSFontFaceRule).map(rule => (rule as CSSFontFaceRule).style.getPropertyValue('font-family').replace(/^['"]|['"]$/g,''));
  105 |   });
  106 |   expect(captured.filter(family => family.startsWith('HKOriginal-KaTeX_')).length).toBeGreaterThan(0);
  107 |   expect(captured.filter(family => family.startsWith('KaTeX_'))).toEqual([]);
  108 |   await expect(page.locator('link[data-original-teaching-fonts="'+legacySha+'"]')).toHaveCount(0);
  109 |   await dialog.getByRole('button', { name: '关闭白板', exact: true }).click();
  110 |   const principal='answer-font-'+randomUUID()+'@local.test',credential='Synthetic-math-font-only-20261027',address='198.19.223.131';
  111 |   async function call(path:string,body:object,token?:string) { const response=await fetch(api+path,{method:'POST',headers:{'Content-Type':'application/json','X-Forwarded-For':address,...(token?{Authorization:'Bearer '+token}:{})},body:JSON.stringify(body)});expect(response.ok,path+' '+response.status).toBe(true);return(await response.json()).data; }
  112 |   const actor=await call('/auth/register',{principal,credential}),student=(await call('/students',{nickname:'匿名字体输入',grade:3,preferredSessionMinutes:15,defaultVersionMap:{math:'',chinese:'',english:''}},actor.token)).profile;
  113 |   const fixture=await call('/qa/answer-journeys',{studentId:student.id,mode:'formula_blank',kind:'diagnostic'},actor.token);
  114 |   await page.goto('/parent/login');await page.getByLabel('登录账号').fill(principal);await page.getByLabel('密码').fill(credential);await page.getByRole('button',{name:'登录，查看学习记录 →'}).click();await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  115 |   const requests:Array<{url:string;status:number}>=[];
  116 |   page.on('response',response=>{const path=new URL(response.url()).pathname;if(path.startsWith('/vendor/mathlive/fonts/')||/\/_next\/static\/media\/KaTeX_.*\.woff2$/.test(path))requests.push({url:response.url(),status:response.status()});});
  117 |   await page.goto(fixture.href);const field=page.locator('math-field').first();await expect(field).toBeVisible();await field.click();
  118 |   await field.evaluate(element=>(element as any).setValue('\\left(\\frac{1+\\sqrt{x^2+1}}{y^3}\\right)'));
  119 |   await expect.poll(()=>requests.length).toBeGreaterThan(0);await page.evaluate(()=>document.fonts.ready);
  120 |   expect(requests.every(request=>request.status===200)).toBe(true);
  121 |   await expect.poll(()=>page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded'&&/KaTeX_/.test(face.family)&&!face.family.includes('HKOriginal-')).length)).toBeGreaterThan(0);
  122 |   const loaded=await page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded'&&/KaTeX_/.test(face.family)&&!face.family.includes('HKOriginal-')).map(face=>face.family));
  123 |   expect(loaded.length).toBeGreaterThan(0);
  124 |   const actualFontDigests=[];
  125 |   for(const request of requests){const match=new URL(request.url).pathname.match(/\/(KaTeX_[A-Za-z0-9_-]+)\.[a-f0-9]+\.woff2$/i);if(!match)continue;const response=await page.request.get(request.url),bytes=await response.body(),file=match[1]+'.woff2',expected=readFileSync(join(process.cwd(),'node_modules/katex/dist/fonts',file));expect(createHash('sha256').update(bytes).digest('hex')).toBe(createHash('sha256').update(expected).digest('hex'));actualFontDigests.push({file,sha256:createHash('sha256').update(bytes).digest('hex')});}
  126 |   expect(actualFontDigests.length).toBeGreaterThan(0);
  127 |   const response=await page.request.get('/vendor/mathlive/manifest.json');expect(response.status()).toBe(200);const manifest=await response.json();expect(manifest.files).toHaveLength(20);
  128 |   for(const file of manifest.files){const font=await page.request.get('/vendor/mathlive/'+file.path),bytes=await font.body();expect(font.status()).toBe(200);expect(bytes.length).toBe(file.size);expect(createHash('sha256').update(bytes).digest('hex')).toBe(file.sha256);}
  129 |   const directory=browserEvidence('original-math-font-isolation');writeFileSync(join(directory,'actual-math-editor-fonts.json'),JSON.stringify({capturedMathAliases:captured.filter(family=>family.startsWith('HKOriginal-KaTeX_')),requests,loaded,actualFontDigests,manifest},null,2)+'\n');await field.screenshot({path:join(directory,'actual-tall-formula.png')});
  130 | });
  131 | 
  132 | test('original fonts: assistant and board register the captured faces once and the assistant prepares its real UI fonts',async({page})=>{
  133 |   const registry=JSON.parse(readFileSync(join(process.cwd(),'apps/web/lib/original-teaching-fonts.json'),'utf8')),families=registry.families.map((row:{family:string})=>row.family);
  134 |   const count=()=>page.evaluate(names=>Array.from(document.fonts).filter(face=>names.includes(face.family.replace(/^['"]|['"]$/g,''))).length,families);
  135 |   await page.goto(await board(page));const dialog=page.getByRole('dialog',{name:'白板视频',exact:true});await expect(dialog).toHaveAttribute('data-original-font-status','ready');
  136 |   const declared=await count();writeFileSync(join(browserEvidence('original-teaching-fonts'),'single-registry-before-assistant.json'),JSON.stringify({expected:registry.faceCount,declared},null,2)+'\n');expect(declared).toBe(registry.faceCount);
  137 |   await page.goto('/studio?view=home&mode=instant&audience=independent');await expect(page.locator('.sa-instant-workspace')).toHaveAttribute('data-original-font-status','ready');await expect(page.getByLabel('想一起看看什么',{exact:true})).toBeEnabled();
  138 |   expect(await count()).toBe(registry.faceCount);const loaded=await page.evaluate(()=>Array.from(document.fonts).filter(face=>face.status==='loaded').map(face=>face.family.replace(/^['"]|['"]$/g,'')));
  139 |   for(const family of ['Satoshi-Regular','Satoshi-Medium','Satoshi-Bold','MiSans'])expect(loaded).toContain(family);
  140 |   await expect(page.locator('link[data-original-teaching-fonts]')).toHaveCount(1);
  141 | });
  142 | 
```