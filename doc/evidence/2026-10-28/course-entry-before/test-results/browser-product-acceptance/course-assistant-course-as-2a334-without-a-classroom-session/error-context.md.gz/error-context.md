# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-assistant.spec.ts >> course assistant: primary unit entry opens its authorized teaching context without a classroom session
- Location: tests\e2e\course-assistant.spec.ts:93:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: '获取单元帮助', exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - generic [ref=f1e5]:
        - generic [ref=f1e6]:
          - link "StudyAgent 学习工作台" [ref=f1e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f1e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f1e11] [cursor=pointer]
        - generic [ref=f1e14]:
          - navigation "工作台主要入口" [ref=f1e15]:
            - button "Home" [ref=f1e16] [cursor=pointer]:
              - generic [ref=f1e19]: 首页
            - button "Courses" [ref=f1e20] [cursor=pointer]:
              - generic [ref=f1e23]: 课程
            - button "Calendar" [ref=f1e24] [cursor=pointer]:
              - generic [ref=f1e27]: 学习动态
            - button "History" [ref=f1e28] [cursor=pointer]:
              - generic [ref=f1e31]: 历史
            - button "Materials" [ref=f1e32] [cursor=pointer]:
              - generic [ref=f1e35]: 资料
            - link "AI Whiteboards" [ref=f1e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f1e39]: AI白板
          - button "＋ 创建课程" [ref=f1e40] [cursor=pointer]
          - generic [ref=f1e41]:
            - region "开始学习" [ref=f1e42]:
              - heading "开始学习" [level=3] [ref=f1e44]
              - link "打开课程 从一节适合自己的课开始。" [ref=f1e45] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f1e46]: 打开课程
                - generic [ref=f1e47]: 从一节适合自己的课开始。
            - generic [ref=f1e48]:
              - heading "近期活动" [level=3] [ref=f1e50]
              - paragraph [ref=f1e52]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f1e54] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_19a85345-d313-4bbf-b14a-6ebe1da347a3
          - text: 返回学习首页 →
    - generic [ref=f1e55]:
      - generic [ref=f1e56]:
        - generic [ref=f1e57]:
          - combobox "学习档案" [ref=f1e58]:
            - option "匿名课程学习者" [selected]
          - combobox "学科" [ref=f1e59]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f1e60]:
          - link "教学课堂 ↗" [ref=f1e61] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f1e62] [cursor=pointer]:
            - /url: /
      - generic [ref=f1e64]:
        - complementary [ref=f1e65]:
          - button "× 退出课程" [ref=f1e66] [cursor=pointer]:
            - text: ×
            - generic [ref=f1e67]: 退出课程
          - img "由阶梯与拱门构成的课程封面" [ref=f1e68]
          - generic [ref=f1e88]:
            - generic [ref=f1e89]: S
            - generic [ref=f1e90]:
              - generic [ref=f1e91]: 策划自
              - generic [ref=f1e92]: StudyAgent Learning Studio
          - heading "匿名数量比较课程" [level=1] [ref=f1e93]
          - paragraph [ref=f1e94]: 由隔离验收提供的匿名已确认教学。
          - group [ref=f1e95]:
            - generic "显示更多" [ref=f1e96] [cursor=pointer]
          - generic [ref=f1e97]: 面板
          - tablist "课程面板" [ref=f1e98]:
            - tab "单元" [selected] [ref=f1e99] [cursor=pointer]
            - tab "资料" [ref=f1e100] [cursor=pointer]
            - tab "练习" [ref=f1e101] [cursor=pointer]
          - navigation "课程单元" [ref=f1e102]:
            - button "1 同一整体与相同单位" [ref=f1e103] [cursor=pointer]:
              - generic [ref=f1e104]: "1"
              - text: 同一整体与相同单位
        - generic [ref=f1e105]:
          - generic [ref=f1e106]:
            - generic [ref=f1e107]: 第 1 单元，共 1 单元
            - heading "同一整体与相同单位" [level=2] [ref=f1e108]
            - paragraph [ref=f1e109]: 说明比较前的条件
          - link "▤ 上传材料，扩展这门课程 阅读PDF、核对结构并生成学案 ↗" [ref=f1e110] [cursor=pointer]:
            - /url: /studio?view=materials
            - generic [ref=f1e111]: ▤
            - generic [ref=f1e112]:
              - generic [ref=f1e113]: 上传材料，扩展这门课程
              - generic [ref=f1e114]: 阅读PDF、核对结构并生成学案
            - generic [ref=f1e115]: ↗
          - generic [ref=f1e116]:
            - generic [ref=f1e117]:
              - generic [ref=f1e118]: ✓
              - text: 讲解已读
            - generic [ref=f1e119]: 已接触
            - generic [ref=f1e121]: 未开始
          - article [ref=f1e124]:
            - generic [ref=f1e125]: ▧
            - strong [ref=f1e127]: 本单元讲座
            - paragraph [ref=f1e128]: 说明比较前的条件
            - generic [ref=f1e130]:
              - generic [ref=f1e131]: 统一单位
              - link "▶ 学习" [ref=f1e132] [cursor=pointer]:
                - /url: /studio/classroom?studioCourseId=qa-course-7df552ef-e403-4354-b702-32f0d78d68a8&lesson=learn%3Aqa-0&returnUnit=unit-1&returnPanel=outline&returnStudent=student_19a85345-d313-4bbf-b14a-6ebe1da347a3&returnSubject=math
          - paragraph [ref=f1e134]: 阅读进度只表示讲解已读。知识掌握由独立题目、迁移和延迟复测核查。
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { browserEvidence } from './evidence';
  3   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  4   | const evidence = browserEvidence('course-assistant');
  5   | async function sourceFonts(page: Page) { await expect(page.getByRole('region', { name: '当时的教学出处', exact: true })).toHaveAttribute('data-original-font-status', 'ready'); }
  6   | let address = 0;
  7   | async function login(page: Page) {
  8   |   const principal = 'course-ui-' + crypto.randomUUID() + '@local.test', credential = 'Course-ui-20261028-only';
  9   |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.17.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  10  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  11  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/); return actor;
  13  | }
  14  | async function call(actor: any, path: string, body?: unknown) {
  15  |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token },
  16  |     ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  17  |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  18  | }
  19  | async function cited(actor: any) {
  20  |   const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  21  |   const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  22  |   const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  23  |   const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请解释本讲所选概念。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  24  |   await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  25  |   const page = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = page.messages.find((m: any) => m.sender === 'assistant');
  26  |   expect(message.sourceReferences).toHaveLength(1); return { d, session, message, ref: message.sourceReferences[0] };
  27  | }
  28  | test('course assistant: opens the actual frozen source directly without creating a conversation or sending a question', async ({ page }) => {
  29  |   test.setTimeout(100000); await page.setViewportSize({ width: 880, height: 887 }); const actor = await login(page), data = await cited(actor), posts: string[] = [];
  30  |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  31  |   await page.goto(data.ref.href); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); await sourceFonts(page);
  32  |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toContainText('社会学'); expect(posts).toEqual([]);
  33  |   await page.reload(); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); await sourceFonts(page); expect(posts).toEqual([]);
  34  |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-direct.png', fullPage: true });
  35  | });
  36  | test('course assistant: a cited answer exposes its source and returns to its complete draft and original message', async ({ page }) => {
  37  |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  38  |   await page.goto('/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + data.d.fingerprint);
  39  |   const input = page.getByLabel('想一起看看什么', { exact: true }); await expect(input).toBeEnabled();
  40  |   await input.fill('完整保留的原讲座匿名草稿。');
  41  |   const source = page.getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first(); await expect(source).toBeVisible(); await source.click();
  42  |   await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  43  |   await page.getByRole('link', { name: '返回原对话', exact: true }).click(); await expect(input).toHaveValue('完整保留的原讲座匿名草稿。');
  44  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  45  | });
  46  | 
  47  | test('course assistant: narrow source views retain every table cell and original teaching code without running it', async ({ page }) => {
  48  |   test.setTimeout(100000); await page.setViewportSize({ width: 390, height: 844 }); const actor = await login(page), data = await cited(actor);
  49  |   const table = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-6');
  50  |   await page.goto(table.reference.href); await expect(page.getByRole('table')).toBeVisible(); await sourceFonts(page);
  51  |   const expected = table.sections.flatMap((s: any) => s.blocks).find((b: any) => b.table).table;
  52  |   for (const header of expected.headers) await expect(page.getByRole('columnheader', { name: header, exact: true })).toBeVisible();
  53  |   for (const row of expected.rows) for (const cell of row) await expect(page.getByRole('cell', { name: cell, exact: true })).toBeVisible();
  54  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  55  |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-table-390.png', fullPage: true });
  56  |   const source = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-3'), originalCode = source.sections.flatMap((s: any) => s.blocks).find((b: any) => b.code !== undefined).code;
  57  |   const runs: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /(?:code|run|execute)/.test(r.url())) runs.push(r.url()); });
  58  |   await page.goto(source.reference.href); await expect(page.getByLabel('原教学代码')).toBeVisible(); await sourceFonts(page); expect(await page.getByLabel('原教学代码').textContent()).toBe(originalCode);
  59  |   await expect(page.getByRole('list', { name: '图形完整标注' })).toContainText('行业岗位变化'); expect(runs).toEqual([]);
  60  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  61  |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-code-390.png', fullPage: true });
  62  | });
  63  | 
  64  | test('course assistant: a different account cannot retain source content or cause a conversation post', async ({ page }) => {
  65  |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor); await page.goto(data.ref.href);
  66  |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toBeVisible();
  67  |   await page.context().clearCookies(); await login(page); const posts: string[] = [];
  68  |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  69  |   const denied = page.waitForResponse(r => r.url().includes('/ai/assistant/sessions/' + data.session.id + '/sources/'));
  70  |   await page.goto(data.ref.href); expect((await denied).status()).toBe(404); await expect(page.getByRole('alert', { name: '出处读取失败' })).toContainText('无法读取'); await sourceFonts(page);
  71  |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toHaveCount(0); await expect(page.getByRole('link', { name: '返回原对话', exact: true })).toHaveCount(0); expect(posts).toEqual([]);
  72  | });
  73  | 
  74  | test('course assistant: source return locates an original answer outside the newest25 messages', async ({ page }) => {
  75  |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  76  |   await call(actor, '/qa/assistant/seed-history', { sessionId: data.session.id, count: 70, makeSourceOld: true });
  77  |   const recent = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/messages/page?pageSize=25');
  78  |   expect(recent.messages.some((m: any) => m.id === data.message.id)).toBe(false);
  79  |   const href = new URL(data.ref.href, 'https://local.invalid'); href.searchParams.set('assistantSourceMessage', data.message.id);
  80  |   await page.goto(href.pathname + href.search); await sourceFonts(page); await page.getByRole('link', { name: '返回原对话', exact: true }).click();
  81  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  82  |   await expect(page.getByRole('navigation', { name: '本次回答的教学出处' })).toBeVisible();
  83  |   await page.getByRole('button', { name: '恢复最近消息', exact: true }).click(); await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toHaveCount(0);
  84  |   expect(new URL(page.url()).hash).toBe(''); await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  85  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toHaveCount(0);
  86  | });
  87  | 
  88  | async function courseFixture(actor: any, kind: 'primary_unit' | 'material_lesson', options: { studentId?: string; long?: boolean; draft?: boolean } = {}) {
  89  |   return call(actor, '/qa/assistant/course', { kind, ...options });
  90  | }
  91  | async function child(actor: any) { return (await call(actor, '/students', { nickname: '匿名课程学习者', grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile; }
  92  | 
  93  | test('course assistant: primary unit entry opens its authorized teaching context without a classroom session', async ({ page }) => {
  94  |   test.setTimeout(100000); const actor = await login(page), student = await child(actor), row = await courseFixture(actor, 'primary_unit', { studentId: student.id });
  95  |   await page.goto('/studio?' + new URLSearchParams({ view: 'courses', student: student.id, subject: 'math', course: row.courseId }));
  96  |   await expect(page.getByRole('heading', { name: '匿名数量比较课程', exact: true })).toBeVisible();
  97  |   const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(r.url())) posts.push(r.url()); });
> 98  |   await page.getByRole('link', { name: '获取单元帮助', exact: true }).click();
      |                                                                 ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  99  |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText('同一整体与相同单位');
  100 |   await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); expect(posts).toEqual([]);
  101 | });
  102 | 
  103 | test('course assistant: material lesson entry opens actual safe teaching and its authoring or published scope', async ({ page }) => {
  104 |   test.setTimeout(100000); const actor = await login(page), row = await courseFixture(actor, 'material_lesson');
  105 |   await page.goto('/studio/source-courses?' + new URLSearchParams({ course: row.courseId }));
  106 |   await expect(page.getByRole('heading', { name: '匿名资料比较课程', exact: true })).toBeVisible();
  107 |   await page.getByRole('link', { name: '获取课时帮助', exact: true }).click();
  108 |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText('资料中的比较条件');
  109 |   await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  110 | });
  111 | 
```