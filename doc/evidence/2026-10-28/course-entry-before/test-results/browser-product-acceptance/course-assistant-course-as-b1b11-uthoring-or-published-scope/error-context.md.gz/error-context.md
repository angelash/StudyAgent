# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-assistant.spec.ts >> course assistant: material lesson entry opens actual safe teaching and its authoring or published scope
- Location: tests\e2e\course-assistant.spec.ts:103:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: '获取课时帮助', exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - complementary "学习工作台导航" [ref=f1e4]:
      - generic [ref=f1e5]:
        - generic [ref=f1e6]:
          - link "StudyAgent 学习工作台" [ref=f1e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f1e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f1e11] [cursor=pointer]
        - generic [ref=f1e14]:
          - navigation "工作台主要入口" [ref=f1e15]:
            - link "Home" [ref=f1e16] [cursor=pointer]:
              - /url: /studio?view=home
              - generic [ref=f1e19]: 首页
            - link "Courses" [ref=f1e20] [cursor=pointer]:
              - /url: /studio?view=courses
              - generic [ref=f1e23]: 课程
            - link "Calendar" [ref=f1e24] [cursor=pointer]:
              - /url: /studio?view=calendar
              - generic [ref=f1e27]: 学习动态
            - link "History" [ref=f1e28] [cursor=pointer]:
              - /url: /studio?view=history
              - generic [ref=f1e31]: 历史
            - link "Materials" [ref=f1e32] [cursor=pointer]:
              - /url: /studio?view=materials
              - generic [ref=f1e35]: 资料
            - link "AI Whiteboards" [ref=f1e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f1e39]: AI白板
          - generic [ref=f1e40]:
            - region "开始学习" [ref=f1e41]:
              - heading "开始学习" [level=3] [ref=f1e43]
              - link "打开课程 从一节适合自己的课开始。" [ref=f1e44] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f1e45]: 打开课程
                - generic [ref=f1e46]: 从一节适合自己的课开始。
            - generic [ref=f1e47]:
              - heading "近期活动" [level=3] [ref=f1e49]
              - paragraph [ref=f1e51]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f1e53] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f1e54]:
      - generic [ref=f1e55]:
        - generic [ref=f1e56]:
          - link "‹ 返回我的课程" [ref=f1e57] [cursor=pointer]:
            - /url: /studio?view=courses
          - text: SOURCE TO COURSE
          - heading "匿名资料比较课程" [level=1] [ref=f1e58]
          - paragraph [ref=f1e59]: PRIVATE_GENERATION_GOAL
        - button "＋ 从资料创建课程" [ref=f1e60] [cursor=pointer]
      - generic [ref=f1e61]:
        - generic [ref=f1e62]: 可以开始学习
        - generic [ref=f1e63]: Synthetic browser fixture · 中文讲解 · 每次预算 15 分钟
        - generic [ref=f1e64]: 内容待核查 · 不作为正式能力测量
      - region "课程版本与变更" [ref=f1e65]:
        - generic [ref=f1e66]:
          - generic [ref=f1e67]:
            - text: COURSE VERSIONS
            - heading "第 1 版 正在使用" [level=2] [ref=f1e68]
          - generic [ref=f1e69]:
            - button "创建修订稿" [disabled] [ref=f1e70]
            - button "归档课程" [ref=f1e71] [cursor=pointer]
            - button "撤回此版本" [ref=f1e72] [cursor=pointer]
      - region "资料课程项目" [ref=f1e73]:
        - text: COURSE PROJECT
        - heading "把资料应用到自己的新情境" [level=3] [ref=f1e74]
        - paragraph [ref=f1e75]: 保留来源、产物、替代解释与验证计划。自评、AI建议和人工复核分别记录，不直接改变知识掌握结论。
        - link "打开资料应用项目 →" [ref=f1e77] [cursor=pointer]:
          - /url: /studio/projects?sourceCourseId=qa-course-b5f88c2b-1155-48f0-a594-d44bf9030116
      - region "资料课程独立核查" [ref=f1e78]:
        - generic [ref=f1e79]:
          - generic [ref=f1e80]:
            - text: INDEPENDENT CHECK
            - heading "换一个情境，看看理解到了哪里。" [level=2] [ref=f1e81]
            - paragraph [ref=f1e82]: 逐题保留首答、帮助和反馈；AI生成题仍待内容审核。
          - button "＋ 准备独立核查" [ref=f1e83] [cursor=pointer]
        - paragraph [ref=f1e84]: 这门资料课程尚未设置独立核查。
        - paragraph [ref=f1e85]: 确认用于练习可保留未看答案的自测路径。“审阅答案并编辑”会记录当前版本的答案曝光。
      - group [ref=f1e86]:
        - generic "查看原始生成目标与模型" [ref=f1e87] [cursor=pointer]
      - paragraph [ref=f1e88]: 当前资料已不可用。下面保留生成时的原文快照；等待审阅的旧预览不能直接确认。
      - generic [ref=f1e89]:
        - generic [ref=f1e90]:
          - generic [ref=f1e92]:
            - text: COURSE OUTLINE
            - heading "从原文走向理解" [level=2] [ref=f1e93]
          - paragraph [ref=f1e94]: 从整体与单位核查比较条件。
          - article [ref=f1e95]:
            - generic [ref=f1e96]: LESSON 01
            - heading "资料中的比较条件" [level=3] [ref=f1e97]
            - paragraph [ref=f1e98]: 说明比较数量的依据
            - button "↗ 匿名比较资料 · 段 3" [ref=f1e100] [cursor=pointer]
            - group [ref=f1e101]:
              - generic "预览讲解与提炼板书" [ref=f1e102] [cursor=pointer]
            - generic [ref=f1e103]: 2 道生成练习 · 两级提示
            - generic "讲解与练习记录" [ref=f1e104]:
              - generic [ref=f1e105]: 讲解未开始
              - generic [ref=f1e106]: 练习未开始
            - generic [ref=f1e107]:
              - link "开始讲解 →" [ref=f1e108] [cursor=pointer]:
                - /url: /studio/classroom?sourceCourseId=qa-course-b5f88c2b-1155-48f0-a594-d44bf9030116&lesson=source%3Aqa-course-b5f88c2b-1155-48f0-a594-d44bf9030116%3A1&tab=history
              - link "进入课堂练习" [ref=f1e109] [cursor=pointer]:
                - /url: /studio/classroom?sourceCourseId=qa-course-b5f88c2b-1155-48f0-a594-d44bf9030116&lesson=source%3Aqa-course-b5f88c2b-1155-48f0-a594-d44bf9030116%3A1&tab=practice
        - complementary [ref=f1e110]:
          - generic [ref=f1e111]:
            - text: LEARN WITH THE SOURCE
            - heading "回到原文核查" [level=2] [ref=f1e112]
          - generic [ref=f1e113]:
            - text: 课程引用的页或段
            - combobox "课程引用来源" [ref=f1e114]:
              - option "匿名比较资料 · 第3段" [selected]
          - article [ref=f1e115]:
            - generic [ref=f1e116]:
              - text: FROZEN SOURCE
              - heading "匿名比较资料 · 第3段" [level=3] [ref=f1e117]
              - paragraph [ref=f1e118]: 课程保存的正文版本 source-v1 · 正文来源已保留
            - generic [ref=f1e119]: 这是只用于隔离验收的完整资料。比较数量之前，先检查是否来自同一个整体，并统一单位。
```

# Test source

```ts
  7   | async function login(page: Page) {
  8   |   const principal = 'course-ui-' + crypto.randomUUID() + '@local.test', credential = 'Course-ui-20261028-only';
  9   |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.17.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  10  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  11  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/); return actor;
  13  | }
  14  | async function call(actor: any, path: string, body?: unknown) {
  15  |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token },
  16  |     ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  17  |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  18  | }
  19  | async function cited(actor: any) {
  20  |   const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  21  |   const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  22  |   const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  23  |   const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请解释本讲所选概念。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  24  |   await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  25  |   const page = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = page.messages.find((m: any) => m.sender === 'assistant');
  26  |   expect(message.sourceReferences).toHaveLength(1); return { d, session, message, ref: message.sourceReferences[0] };
  27  | }
  28  | test('course assistant: opens the actual frozen source directly without creating a conversation or sending a question', async ({ page }) => {
  29  |   test.setTimeout(100000); await page.setViewportSize({ width: 880, height: 887 }); const actor = await login(page), data = await cited(actor), posts: string[] = [];
  30  |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  31  |   await page.goto(data.ref.href); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); await sourceFonts(page);
  32  |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toContainText('社会学'); expect(posts).toEqual([]);
  33  |   await page.reload(); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); await sourceFonts(page); expect(posts).toEqual([]);
  34  |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-direct.png', fullPage: true });
  35  | });
  36  | test('course assistant: a cited answer exposes its source and returns to its complete draft and original message', async ({ page }) => {
  37  |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  38  |   await page.goto('/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + data.d.fingerprint);
  39  |   const input = page.getByLabel('想一起看看什么', { exact: true }); await expect(input).toBeEnabled();
  40  |   await input.fill('完整保留的原讲座匿名草稿。');
  41  |   const source = page.getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first(); await expect(source).toBeVisible(); await source.click();
  42  |   await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  43  |   await page.getByRole('link', { name: '返回原对话', exact: true }).click(); await expect(input).toHaveValue('完整保留的原讲座匿名草稿。');
  44  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  45  | });
  46  | 
  47  | test('course assistant: narrow source views retain every table cell and original teaching code without running it', async ({ page }) => {
  48  |   test.setTimeout(100000); await page.setViewportSize({ width: 390, height: 844 }); const actor = await login(page), data = await cited(actor);
  49  |   const table = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-6');
  50  |   await page.goto(table.reference.href); await expect(page.getByRole('table')).toBeVisible(); await sourceFonts(page);
  51  |   const expected = table.sections.flatMap((s: any) => s.blocks).find((b: any) => b.table).table;
  52  |   for (const header of expected.headers) await expect(page.getByRole('columnheader', { name: header, exact: true })).toBeVisible();
  53  |   for (const row of expected.rows) for (const cell of row) await expect(page.getByRole('cell', { name: cell, exact: true })).toBeVisible();
  54  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  55  |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-table-390.png', fullPage: true });
  56  |   const source = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-3'), originalCode = source.sections.flatMap((s: any) => s.blocks).find((b: any) => b.code !== undefined).code;
  57  |   const runs: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /(?:code|run|execute)/.test(r.url())) runs.push(r.url()); });
  58  |   await page.goto(source.reference.href); await expect(page.getByLabel('原教学代码')).toBeVisible(); await sourceFonts(page); expect(await page.getByLabel('原教学代码').textContent()).toBe(originalCode);
  59  |   await expect(page.getByRole('list', { name: '图形完整标注' })).toContainText('行业岗位变化'); expect(runs).toEqual([]);
  60  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  61  |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-code-390.png', fullPage: true });
  62  | });
  63  | 
  64  | test('course assistant: a different account cannot retain source content or cause a conversation post', async ({ page }) => {
  65  |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor); await page.goto(data.ref.href);
  66  |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toBeVisible();
  67  |   await page.context().clearCookies(); await login(page); const posts: string[] = [];
  68  |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  69  |   const denied = page.waitForResponse(r => r.url().includes('/ai/assistant/sessions/' + data.session.id + '/sources/'));
  70  |   await page.goto(data.ref.href); expect((await denied).status()).toBe(404); await expect(page.getByRole('alert', { name: '出处读取失败' })).toContainText('无法读取'); await sourceFonts(page);
  71  |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toHaveCount(0); await expect(page.getByRole('link', { name: '返回原对话', exact: true })).toHaveCount(0); expect(posts).toEqual([]);
  72  | });
  73  | 
  74  | test('course assistant: source return locates an original answer outside the newest25 messages', async ({ page }) => {
  75  |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  76  |   await call(actor, '/qa/assistant/seed-history', { sessionId: data.session.id, count: 70, makeSourceOld: true });
  77  |   const recent = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/messages/page?pageSize=25');
  78  |   expect(recent.messages.some((m: any) => m.id === data.message.id)).toBe(false);
  79  |   const href = new URL(data.ref.href, 'https://local.invalid'); href.searchParams.set('assistantSourceMessage', data.message.id);
  80  |   await page.goto(href.pathname + href.search); await sourceFonts(page); await page.getByRole('link', { name: '返回原对话', exact: true }).click();
  81  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  82  |   await expect(page.getByRole('navigation', { name: '本次回答的教学出处' })).toBeVisible();
  83  |   await page.getByRole('button', { name: '恢复最近消息', exact: true }).click(); await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toHaveCount(0);
  84  |   expect(new URL(page.url()).hash).toBe(''); await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  85  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toHaveCount(0);
  86  | });
  87  | 
  88  | async function courseFixture(actor: any, kind: 'primary_unit' | 'material_lesson', options: { studentId?: string; long?: boolean; draft?: boolean } = {}) {
  89  |   return call(actor, '/qa/assistant/course', { kind, ...options });
  90  | }
  91  | async function child(actor: any) { return (await call(actor, '/students', { nickname: '匿名课程学习者', grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile; }
  92  | 
  93  | test('course assistant: primary unit entry opens its authorized teaching context without a classroom session', async ({ page }) => {
  94  |   test.setTimeout(100000); const actor = await login(page), student = await child(actor), row = await courseFixture(actor, 'primary_unit', { studentId: student.id });
  95  |   await page.goto('/studio?' + new URLSearchParams({ view: 'courses', student: student.id, subject: 'math', course: row.courseId }));
  96  |   await expect(page.getByRole('heading', { name: '匿名数量比较课程', exact: true })).toBeVisible();
  97  |   const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(r.url())) posts.push(r.url()); });
  98  |   await page.getByRole('link', { name: '获取单元帮助', exact: true }).click();
  99  |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText('同一整体与相同单位');
  100 |   await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); expect(posts).toEqual([]);
  101 | });
  102 | 
  103 | test('course assistant: material lesson entry opens actual safe teaching and its authoring or published scope', async ({ page }) => {
  104 |   test.setTimeout(100000); const actor = await login(page), row = await courseFixture(actor, 'material_lesson');
  105 |   await page.goto('/studio/source-courses?' + new URLSearchParams({ course: row.courseId }));
  106 |   await expect(page.getByRole('heading', { name: '匿名资料比较课程', exact: true })).toBeVisible();
> 107 |   await page.getByRole('link', { name: '获取课时帮助', exact: true }).click();
      |                                                                 ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  108 |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText('资料中的比较条件');
  109 |   await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  110 | });
  111 | 
```