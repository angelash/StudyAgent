# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio-assistant.spec.ts >> lecture-navigation: lecture tools retain the original scope and draft through material refresh and planner return
- Location: tests\e2e\studio-assistant.spec.ts:185:49

# Error details

```
Error: preserved mode

expect(received).toBe(expected) // Object.is equality

Expected: "instant"
Received: null
```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - alert [ref=f2e2]
  - main [ref=f2e3]:
    - complementary "学习工作台导航" [ref=f2e4]:
      - generic [ref=f2e5]:
        - generic [ref=f2e6]:
          - link "StudyAgent 学习工作台" [ref=f2e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f2e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f2e11] [cursor=pointer]
        - generic [ref=f2e14]:
          - navigation "工作台主要入口" [ref=f2e15]:
            - button "Home" [ref=f2e16] [cursor=pointer]:
              - generic [ref=f2e19]: 首页
            - button "Courses" [ref=f2e20] [cursor=pointer]:
              - generic [ref=f2e23]: 课程
            - button "Calendar" [ref=f2e24] [cursor=pointer]:
              - generic [ref=f2e27]: 学习动态
            - button "History" [ref=f2e28] [cursor=pointer]:
              - generic [ref=f2e31]: 历史
            - button "Materials" [ref=f2e32] [cursor=pointer]:
              - generic [ref=f2e35]: 资料
            - link "AI Whiteboards" [ref=f2e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f2e39]: AI白板
          - button "＋ 创建课程" [ref=f2e40] [cursor=pointer]
          - generic [ref=f2e41]:
            - region "开始学习" [ref=f2e42]:
              - heading "开始学习" [level=3] [ref=f2e44]
              - link "打开课程 从一节适合自己的课开始。" [ref=f2e45] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f2e46]: 打开课程
                - generic [ref=f2e47]: 从一节适合自己的课开始。
            - generic [ref=f2e48]:
              - heading "近期活动" [level=3] [ref=f2e50]
              - paragraph [ref=f2e52]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f2e54] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f2e55]:
      - generic [ref=f2e56]:
        - generic [ref=f2e57]:
          - generic [ref=f2e58]: 独立学习
          - link "创建学习档案" [ref=f2e59] [cursor=pointer]:
            - /url: /parent/dashboard
        - generic [ref=f2e60]:
          - link "教学课堂 ↗" [ref=f2e61] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f2e62] [cursor=pointer]:
            - /url: /
      - generic [ref=f2e63]:
        - heading "把资料加入学习档案" [level=2] [ref=f2e64]
        - paragraph [ref=f2e65]: 先创建学习档案，再上传PDF、恢复表格公式，生成学习讲义与练习。
        - link "创建学习档案 →" [ref=f2e66] [cursor=pointer]:
          - /url: /parent/dashboard
```

# Test source

```ts
  89  |   await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/, async route => {
  90  |     if (route.request().method() === 'POST') { count++; submitted = route.request().postDataJSON();sessionId=new URL(route.request().url()).pathname.split('/').at(-2)!; await route.fetch(); await route.abort('failed'); } else await route.continue();
  91  |   });
  92  |   await input(page).fill('只发送一次的匿名讲座问题。'); await page.getByRole('button', { name: '发送学习问题' }).click();
  93  |   await expect(page.getByRole('complementary', { name: '待确认提问' })).toBeVisible();
  94  |   expect(submitted.requestKey).toBeTruthy(); await page.unrouteAll({ behavior: 'wait' });
  95  |   await expect.poll(async()=> (await call(actor,'/ai/assistant/sessions/'+sessionId+'/turns?requestKey='+submitted.requestKey)).turns[0]?.status).toBe('completed');
  96  |   let stalePages=0;await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/messages\/page\?/,async route=>{const response=await route.fetch();if(stalePages++===0){const body=await response.json();body.data.messages=[];await route.fulfill({response,json:body});}else await route.fulfill({response});});
  97  |   await page.reload();
  98  |   await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 }); expect(count).toBe(1);expect(allPosts).toHaveLength(1);expect(allPosts[0].requestKey).toBe(submitted.requestKey);
  99  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2);expect(stalePages).toBeGreaterThanOrEqual(2); await shot(page, 'recovered-original-request');
  100 | });
  101 | 
  102 | test('lecture-assistant: a retained original version opens from the server without creating or resending a session', async ({ page }) => {
  103 |   test.setTimeout(120000); await page.setViewportSize({ width: 880, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  104 |   const original = await call(actor, '/qa/assistant/lecture-history', {}), posts: string[] = [];
  105 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(request.url())) posts.push(request.url()); });
  106 |   await page.goto(original.href); await expect(page.getByRole('log', { name: '当前学习对话' })).toContainText('LECTURE_OLD_HISTORY_MARKER');
  107 |   await expect(input(page)).toBeDisabled(); await expect(page.getByRole('button', { name: '发送学习问题' })).toBeDisabled(); expect(posts).toEqual([]);
  108 |   await shot(page, 'retained-original-readonly');
  109 |   await page.getByRole('button', { name: '打开当前讲座版本', exact: true }).click(); await expect(input(page)).toBeEnabled();
  110 |   await expect(page.locator('.assistant-message').filter({hasText:'LECTURE_OLD_HISTORY_MARKER'})).toHaveCount(0);
  111 |   expect(posts.some(url => /\/sessions$/.test(url))).toBe(true); expect(posts.some(url => /\/turns$/.test(url))).toBe(false);
  112 |   expect((await call(actor, '/ai/assistant/sessions/' + original.sessionId + '/messages/page')).messages).toHaveLength(2);
  113 | });
  114 | 
  115 | test('lecture-assistant: failed initialization after a child change cannot retain the previous active session', async ({ page }) => {
  116 |   test.setTimeout(120000); const actor = await login(page), children:Array<{id:string}> = [];
  117 |   for (const nickname of ['匿名档案甲', '匿名档案乙']) children.push((await call(actor, '/students', { nickname, grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile);
  118 |   await page.goto('/studio'); await expect(page.getByRole('combobox', { name: '学习档案', exact: true }).locator('option')).toHaveCount(2);await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[0].id);await expect(page.getByRole('combobox', { name: '学习档案', exact: true })).toHaveValue(children[0].id); await page.getByRole('button', { name: 'Instant Assistance', exact: true }).click();
  119 |   await expect(input(page)).toBeEnabled(); await input(page).fill('只属于匿名档案甲的未发送草稿。'); const posts: string[] = [];
  120 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.url()); });
  121 |   await page.route(/\/ai\/assistant\/sessions$/, async route => {
  122 |     if (route.request().method() === 'POST' && route.request().postDataJSON().studentId === children[1].id) await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ data: null, error: { code: 'synthetic_unavailable', message: '匿名上下文初始化暂不可用' }, meta: {} }) });
  123 |     else await route.continue();
  124 |   });
  125 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[1].id); await expect(page.getByText('匿名上下文初始化暂不可用', { exact: true })).toBeVisible();
  126 |   await expect(input(page)).toBeDisabled(); expect(posts).toEqual([]);
  127 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[0].id); await expect(input(page)).toHaveValue('只属于匿名档案甲的未发送草稿。');
  128 |   await page.unrouteAll({ behavior: 'wait' });
  129 | });
  130 | 
  131 | test('lecture-assistant: read-only recovery preserves a cached pending command and identifies separately selected history', async ({ page }) => {
  132 |   test.setTimeout(120000);const actor=await login(page),old=await call(actor,'/qa/assistant/lecture-history',{}),owner=(await call(actor,'/auth/me')).id;
  133 |   const scope=JSON.stringify({userRole:'parent',studentId:null,subject:null,pageContext:'classroom',contextRefType:'classroom_lecture',contextRefId:old.referenceId,contextItemId:old.lectureId});
  134 |   const key='studyagent.assistant.v1.'+encodeURIComponent(owner)+'.'+encodeURIComponent(scope);
  135 |   const raw=JSON.stringify({version:1,ownerId:owner,scope,sessionId:old.sessionId,input:'原版本未发送草稿，不可自动发出。',pending:{requestKey:crypto.randomUUID(),message:'原版本待确认命令。',modelId:'deepseek-v4-flash',contextVersion:'a'.repeat(64)},lastTurnId:null});
  136 |   await page.evaluate(({key,raw})=>localStorage.setItem(key,raw),{key,raw});
  137 |   const generic=await call(actor,'/ai/assistant/sessions',{userRole:'parent',studentId:null,subject:null,pageContext:'studio'});
  138 |   await call(actor,'/qa/assistant/seed-history',{sessionId:generic.id,count:4,marker:'OWN_INDEPENDENT_HISTORY'});
  139 |   const posts:string[]=[];page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions(?:\/|$)/.test(request.url()))posts.push(request.url());});
  140 |   await page.goto(old.href);await expect(input(page)).toHaveValue('原版本未发送草稿，不可自动发出。');await expect(input(page)).toBeDisabled();await expect(page.getByRole('button',{name:'核对原请求',exact:true})).toBeDisabled();
  141 |   await page.getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill('OWN_INDEPENDENT_HISTORY');await page.getByRole('button',{name:'搜索历史',exact:true}).click();await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  142 |   await expect(page.getByRole('log',{name:'当前学习对话'})).toContainText('OWN_INDEPENDENT_HISTORY');await expect(page.getByRole('region',{name:'当前讲座上下文'})).toHaveCount(0);await expect(page.getByText('正在只读原讲座版本。原问题与草稿保留，请打开当前版本后再提问。',{exact:true})).toHaveCount(0);
  143 |   await page.getByRole('button',{name:'返回当前学习对话',exact:true}).click();await expect(input(page)).toHaveValue('原版本未发送草稿，不可自动发出。');await expect(input(page)).toBeDisabled();expect(await page.evaluate(key=>localStorage.getItem(key),key)).toBe(raw);expect(posts).toEqual([]);await shot(page,'readonly-pending-and-history');
  144 | });
  145 | 
  146 | test('lecture-assistant: an unavailable original still allows owner-only history reads without a session post',async({page})=>{
  147 |   test.setTimeout(90000);const actor=await login(page),old=await call(actor,'/qa/assistant/lecture-history',{}),generic=await call(actor,'/ai/assistant/sessions',{userRole:'parent',studentId:null,subject:null,pageContext:'studio'});
  148 |   await call(actor,'/qa/assistant/seed-history',{sessionId:generic.id,count:4,marker:'READABLE_WITHOUT_BASE'});
  149 |   const url=new URL(old.href,'http://local.test');url.searchParams.set('lectureVersion','0'.repeat(64));const posts:string[]=[];
  150 |   page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions(?:\/|$)/.test(request.url()))posts.push(request.url());});
  151 |   await page.goto(url.pathname+url.search);await expect(input(page)).toBeDisabled();await expect(page.getByRole('alert').filter({hasText:'当前账号没有保留这个讲座原版本'})).toBeVisible();
  152 |   await page.getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill('READABLE_WITHOUT_BASE');await page.getByRole('button',{name:'搜索历史',exact:true}).click();await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  153 |   await expect(page.getByRole('log',{name:'当前学习对话'})).toContainText('READABLE_WITHOUT_BASE');await expect(page.getByRole('button',{name:'返回当前学习对话',exact:true})).toBeVisible();expect(posts).toEqual([]);
  154 | });
  155 | 
  156 | test('lecture-assistant: another account cannot open a retained version or find its private messages',async({page,browser})=>{
  157 |   test.setTimeout(90000);const actor=await login(page),old=await call(actor,'/qa/assistant/lecture-history',{}),stranger=await browser.newContext({baseURL:new URL(page.url()).origin});
  158 |   try{const other=await stranger.newPage();await login(other);const posts:string[]=[];other.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions(?:\/|$)/.test(request.url()))posts.push(request.url());});
  159 |     await other.goto(old.href);await expect(input(other)).toBeDisabled();await expect(other.getByRole('alert').filter({hasText:'当前账号没有保留这个讲座原版本'})).toBeVisible();await expect(other.locator('.assistant-message')).toHaveCount(0);
  160 |     await other.getByRole('button',{name:'查找历史',exact:true}).click();await other.getByLabel('检索历史关键词').fill('LECTURE_OLD_HISTORY_MARKER');await other.getByRole('button',{name:'搜索历史',exact:true}).click();await expect(other.getByLabel('助教历史检索')).toContainText('找到 0 段对话');expect(posts).toEqual([]);
  161 |   }finally{await stranger.close();}
  162 | });
  163 | 
  164 | test('lecture-assistant: explicit cancellation and retry preserve one lecture request and the original model',async({page})=>{
  165 |   test.setTimeout(120000);const actor=await lecture(page),posts:any[]=[];page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url()))posts.push({url:request.url(),command:request.postDataJSON()});});
  166 |   await input(page).fill('[assistant-pause-once] '+crypto.randomUUID()+' 取消后按原模型重试。');await page.getByRole('button',{name:'发送学习问题',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','running');await task(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','cancelled');
  167 |   await page.reload();await expect(task(page)).toHaveAttribute('data-status','cancelled');await page.getByRole('combobox',{name:'选择大模型',exact:true}).selectOption('glm-5.3-flash');await task(page).getByRole('button',{name:'重试原任务',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:45000});
  168 |   expect(posts).toHaveLength(1);const id=new URL(posts[0].url).pathname.split('/').at(-2),turns=(await call(actor,'/ai/assistant/sessions/'+id+'/turns')).turns;expect(turns).toHaveLength(1);expect(turns[0]).toMatchObject({requestKey:posts[0].command.requestKey,modelId:'deepseek-v4-flash'});expect(turns[0].task.generation).toBe(2);await expect(page.locator('.assistant-message')).toHaveCount(2);await expect(page.getByRole('combobox',{name:'选择大模型',exact:true})).toHaveValue('glm-5.3-flash');await shot(page,'cancel-retry-original-lecture');
  169 | });
  170 | 
  171 | test('lecture-assistant: changing the selected learner fences a late whiteboard preview and releases the new composer',async({page})=>{
  172 |   test.setTimeout(120000);const actor=await login(page),children:Array<{id:string}>=[];
  173 |   for(const nickname of ['白板匿名档案甲','白板匿名档案乙'])children.push((await call(actor,'/students',{nickname,grade:5,preferredSessionMinutes:15,defaultVersionMap:{math:'common',chinese:'common',english:'common'}})).profile);
  174 |   const scope=await fetch(api+'/students/'+children[0].id+'/learning-scope?subject=math',{method:'PUT',headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},body:JSON.stringify({subject:'math',grade:5,term:'upper',textbookVolumeId:null,textbookVersion:'按已学知识点确认',learnedAtomIds:['core:math:fractionadd','core:math:fractionsubtract'],currentAtomId:'core:math:fractionadd',minutesPerSession:15,progressMode:'knowledge',selectedLessonIds:[]})});expect(scope.status).toBe(200);
  175 |   await page.goto('/studio?mode=instant&student='+children[0].id);await expect(input(page)).toBeEnabled();await page.getByRole('button',{name:'Tools',exact:true}).click();await page.getByRole('menuitem',{name:/Whiteboard session/}).click();await input(page).fill('解释异分母分数加法');
  176 |   let release!:()=>void;const gate=new Promise<void>(resolve=>release=resolve);let captured=false,returned=false;const saves:string[]=[];
  177 |   page.on('request',request=>{if(request.method()==='POST'&&/\/learning\/studio\/whiteboards$/.test(request.url()))saves.push(request.url());});
  178 |   await page.route('**/api/learning/studio/whiteboards/preview',async route=>{const response=await route.fetch();expect(response.ok()).toBe(true);captured=true;await gate;try{await route.fulfill({response});}catch{/* The previous learner's client was aborted. */}finally{returned=true;}});
  179 |   try{await page.getByRole('button',{name:'预览白板主题',exact:true}).click();await expect.poll(()=>captured).toBe(true);await expect(input(page)).toBeDisabled();
  180 |     await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[1].id);await expect(input(page)).toBeEnabled();release();await expect.poll(()=>returned).toBe(true);
  181 |     await expect(page.locator('.sa-whiteboard-preview-modal')).toHaveCount(0);await expect(page.getByRole('combobox',{name:'学习档案',exact:true})).toHaveValue(children[1].id);await expect(input(page)).toHaveValue('');expect(saves).toEqual([]);
  182 |   }finally{release();}
  183 | });
  184 | 
  185 | for(const mode of ['lecture','independent'])test('lecture-navigation: '+mode+' tools retain the original scope and draft through material refresh and planner return',async({page})=>{
  186 |   test.setTimeout(90000);await lecture(page);if(mode==='independent')await page.getByRole('button',{name:'移除讲座上下文',exact:true}).click();await expect(input(page)).toBeEnabled();
  187 |   const original=new URL(page.url()),keys=mode==='lecture'?['mode','lectureCourse','lecture','lectureVersion']:['mode','audience'],draft='工具往返后仍属于原范围的匿名草稿 '+mode,posts:string[]=[];
  188 |   page.on('request',request=>{if(request.method()==='POST'&&(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())||/\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())))posts.push(request.url());});
> 189 |   const assertScope=()=>{const current=new URL(page.url());for(const key of keys)expect(current.searchParams.get(key),'preserved '+key).toBe(original.searchParams.get(key));};
      |                                                                                                                                         ^ Error: preserved mode
  190 |   await input(page).fill(draft);await page.getByRole('button',{name:'打开学习资料',exact:true}).click();await expect(page).toHaveURL(/view=materials/);assertScope();await page.reload();await expect(page.locator('.sa-top strong')).toHaveText('资料');
  191 |   await page.locator('.ws-navigation').getByRole('link',{name:'Home',exact:true}).click();await expect(input(page)).toHaveValue(draft);assertScope();
  192 |   await page.getByRole('button',{name:'Tools',exact:true}).click();await page.getByRole('menuitem',{name:/Study Planner/}).click();await expect(page).toHaveURL(/view=calendar/);assertScope();
  193 |   await page.locator('.ws-navigation').getByRole('link',{name:'Home',exact:true}).click();await expect(input(page)).toHaveValue(draft);assertScope();await expect(page.getByRole('region',{name:'当前讲座上下文'})).toHaveCount(mode==='lecture'?1:0);expect(posts).toEqual([]);await shot(page,'navigation-retained-'+mode);
  194 | });
  195 | 
```