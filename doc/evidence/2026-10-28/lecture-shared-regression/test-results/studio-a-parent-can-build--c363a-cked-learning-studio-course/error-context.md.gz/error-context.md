# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio.spec.ts >> a parent can build and reopen an evidence-backed learning studio course
- Location: tests\e2e\studio.spec.ts:35:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('.sa-tools-popover').getByRole('button', { name: /Whiteboard session/ })

```

# Page snapshot

```yaml
- generic [ref=f2e1]:
  - alert [ref=f2e2]
  - main [ref=f2e3]:
    - complementary "学习工作台导航" [ref=f2e4]:
      - generic [ref=f2e5]:
        - generic [ref=f2e6]:
          - link "StudyAgent 学习工作台" [ref=f2e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f2e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f2e11] [cursor=pointer]
        - generic [ref=f2e14]:
          - navigation "工作台主要入口" [ref=f2e15]:
            - button "Home" [ref=f2e16] [cursor=pointer]:
              - generic [ref=f2e19]: 首页
            - button "Courses" [ref=f2e20] [cursor=pointer]:
              - generic [ref=f2e23]: 课程
            - button "Calendar" [ref=f2e24] [cursor=pointer]:
              - generic [ref=f2e27]: 学习动态
            - button "History" [ref=f2e28] [cursor=pointer]:
              - generic [ref=f2e31]: 历史
            - button "Materials" [ref=f2e32] [cursor=pointer]:
              - generic [ref=f2e35]: 资料
            - link "AI Whiteboards" [ref=f2e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f2e39]: AI白板
          - button "＋ 创建课程" [ref=f2e40] [cursor=pointer]
          - generic [ref=f2e41]:
            - region "继续学习" [ref=f2e42]:
              - heading "继续学习" [level=3] [ref=f2e44]
              - link "创建课程「分数关系与证据」 1 个单元 · 2 个知识目标" [ref=f2e45] [cursor=pointer]:
                - /url: /studio?course=studio_course_ef8cce55-204e-47b4-80f7-88761f31f3e8
                - generic [ref=f2e46]: 创建课程「分数关系与证据」
                - generic [ref=f2e48]: 1 个单元 · 2 个知识目标
            - heading "近期活动" [level=3] [ref=f2e51]
        - link "返回学习首页" [ref=f2e53] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_f1b37aeb-d4be-4831-9997-69d70952e7d9
          - text: 返回学习首页 →
    - generic [ref=f2e54]:
      - generic [ref=f2e55]:
        - generic [ref=f2e56]:
          - combobox "学习档案" [ref=f2e57]:
            - option "工作台验收" [selected]
          - combobox "学科" [ref=f2e58]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f2e59]:
          - link "教学课堂 ↗" [ref=f2e60] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f2e61] [cursor=pointer]:
            - /url: /
      - generic [ref=f2e62]:
        - generic [ref=f2e63]:
          - button "Craft Courses" [ref=f2e64] [cursor=pointer]
          - button "Instant Assistance" [ref=f2e65] [cursor=pointer]
        - generic [ref=f2e66]:
          - heading "Time for flashcards?" [level=1] [ref=f2e68]
          - region "学习工作台助教" [ref=f2e69]:
            - generic [ref=f2e70]:
              - button "查找历史" [ref=f2e72] [cursor=pointer]
              - generic [ref=f2e73]:
                - generic [ref=f2e74]:
                  - generic [ref=f2e75]:
                    - generic [ref=f2e76]: 想一起看看什么
                    - textbox "想一起看看什么" [ref=f2e77]:
                      - /placeholder: 问一个概念，或告诉我你想理清的问题…
                      - text: 请讲清这个概念的定义、例子、反例和适用条件：
                  - generic [ref=f2e78]:
                    - generic [ref=f2e79]:
                      - button "打开学习资料" [ref=f2e80] [cursor=pointer]: ＋
                      - button "Tools" [ref=f2e81] [cursor=pointer]:
                        - generic [aria-hidden] [ref=f2e82]: ☷
                    - generic [ref=f2e84]:
                      - generic [ref=f2e85]:
                        - generic [ref=f2e86]:
                          - generic [ref=f2e87]: 模型
                          - combobox "选择大模型" [ref=f2e88] [cursor=pointer]:
                            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                            - option "GPT-6.1 Sol"
                            - option "GPT-6 Astra"
                            - option "GPT-6 Luna"
                            - option "Grok-4.7"
                            - option "GLM-5.3 Flash"
                            - option "DeepSeek V4.1 Flash · 默认" [selected]
                            - option "Claude Opus 5.5"
                            - option "Claude Sonnet 5"
                            - option "GPT-6 Sol"
                            - option "GPT-5.6 Sol"
                            - option "GPT-5.6 Terra"
                            - option "GPT-5.6 Luna"
                            - option "GPT-5.5"
                            - option "Grok-4.6"
                            - option "GLM-5.2"
                            - option "GLM-5.3"
                            - option "Claude Opus 5"
                            - option "Claude Fable 5.1"
                            - option "MiMo V2.6 Pro"
                            - option "MiMo V2.6 Flash"
                            - option "MiMo V2.6 Pro Ultraspeed"
                            - option "Qwen3.8 Max"
                        - group [ref=f2e89]:
                          - generic "模型文字检查说明" [ref=f2e90] [cursor=pointer]: ⓘ
                      - button "发送学习问题" [ref=f2e91] [cursor=pointer]: ↑
                - generic [ref=f2e93]:
                  - generic [ref=f2e94]:
                    - button "Concept Explanation" [active] [ref=f2e95] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f2e96]: ⌕
                      - text: Concept Explanation
                    - button "Personal Study Materials Generation" [ref=f2e97] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f2e98]: ▤
                      - text: Personal Study Materials Generation
                    - button "Long-files Digestion" [ref=f2e99] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f2e100]: ▱
                      - text: Long-files Digestion
                  - generic [ref=f2e101]:
                    - button "Problem Solving" [ref=f2e102] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f2e103]: ♧
                      - text: Problem Solving
                    - link "Visualization" [ref=f2e104] [cursor=pointer]:
                      - /url: /studio/whiteboards
                      - generic [aria-hidden] [ref=f2e105]: ▦
                      - text: Visualization
              - button "下载提问副本" [ref=f2e106] [cursor=pointer]
```

# Test source

```ts
  1   | import { browserEvidence } from './evidence';
  2   | import { expect, test } from '@playwright/test';
  3   | import { mkdtempSync, rmSync, statSync, writeFileSync } from 'node:fs';
  4   | import { tmpdir } from 'node:os';
  5   | import { join } from 'node:path';
  6   | 
  7   | const apiUrl = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`;
  8   | 
  9   | function writeTextPdf() {
  10  |   const directory = mkdtempSync(join(tmpdir(), 'studio-browser-pdf-'));
  11  |   const path = join(directory, '分数讲义.pdf');
  12  |   const stream = 'BT /F1 20 Tf 72 700 Td (Fractions: unify the unit, combine equal parts,) Tj 0 -30 Td ' +
  13  |     '(then check the result with another representation.) Tj 0 -30 Td (1/2 + 1/3 = 5/6) Tj ET';
  14  |   const objects = [
  15  |     '<< /Type /Catalog /Pages 2 0 R >>',
  16  |     '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
  17  |     '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
  18  |     '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
  19  |     '<< /Length ' + Buffer.byteLength(stream) + ' >>\nstream\n' + stream + '\nendstream',
  20  |   ];
  21  |   let body = '%PDF-1.4\n'; const offsets: number[] = [0];
  22  |   objects.forEach((object, index) => { offsets.push(Buffer.byteLength(body)); body += (index + 1) + ' 0 obj\n' + object + '\nendobj\n'; });
  23  |   const xref = Buffer.byteLength(body); body += 'xref\n0 ' + (objects.length + 1) + '\n0000000000 65535 f \n';
  24  |   offsets.slice(1).forEach(offset => { body += String(offset).padStart(10, '0') + ' 00000 n \n'; });
  25  |   body += 'trailer\n<< /Size ' + (objects.length + 1) + ' /Root 1 0 R >>\nstartxref\n' + xref + '\n%%EOF\n';
  26  |   writeFileSync(path, body, 'ascii');
  27  |   return { path, cleanup: () => rmSync(directory, { recursive: true, force: true }) };
  28  | }
  29  | 
  30  | async function selectWorkspaceView(page: import('@playwright/test').Page, name: 'Home' | 'Courses' | 'Calendar' | 'Materials') {
  31  |   if ((page.viewportSize()?.width ?? 1280) <= 1000) await page.getByRole('button', { name: '打开学习导航', exact: true }).click();
  32  |   await page.getByRole('button', { name, exact: true }).click();
  33  | }
  34  | 
  35  | test('a parent can build and reopen an evidence-backed learning studio course', async ({ page }) => {
  36  |   test.setTimeout(240_000);
  37  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  38  |   await page.setViewportSize({ width: 1440, height: 1000 });
  39  |   const suffix = `${Date.now()}${Math.floor(Math.random() * 10_000)}`;
  40  |   const principal = `studio-${suffix}@local.test`;
  41  |   const credential = `Studio-only-${suffix}`;
  42  |   const registration = await fetch(`${apiUrl}/api/auth/register`, { method: 'POST', headers: { 'content-type': 'application/json' },
  43  |     body: JSON.stringify({ principal, credential }) });
  44  |   expect(registration.status).toBe(201);
  45  |   const auth = await registration.json();
  46  |   const headers = { 'content-type': 'application/json', authorization: `Bearer ${auth.data.token}` };
  47  |   const studentResponse = await fetch(`${apiUrl}/api/students`, { method: 'POST', headers,
  48  |     body: JSON.stringify({ nickname: '工作台验收', grade: 5, preferredSessionMinutes: 15,
  49  |       defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }) });
  50  |   expect(studentResponse.status).toBe(201);
  51  |   const student = await studentResponse.json();
  52  |   const studentId = student.data.profile.id;
  53  |   const scope = await fetch(`${apiUrl}/api/students/${studentId}/learning-scope?subject=math`, { method: 'PUT', headers,
  54  |     body: JSON.stringify({ subject: 'math', grade: 5, term: 'upper', textbookVolumeId: null,
  55  |       textbookVersion: '按已学知识点确认', learnedAtomIds: ['core:math:fractionadd', 'core:math:fractionsubtract'],
  56  |       currentAtomId: 'core:math:fractionadd', minutesPerSession: 15, progressMode: 'knowledge', selectedLessonIds: [] }) });
  57  |   expect(scope.status).toBe(200);
  58  | 
  59  |   await page.goto('/parent/login');
  60  |   await page.getByLabel('登录账号').fill(principal);
  61  |   await page.getByLabel('密码').fill(credential);
  62  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click();
  63  |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  64  |   await page.goto('/studio');
  65  |   await expect(page.getByRole('button', { name: 'Craft Courses' })).toBeVisible();
  66  |   await expect(page.getByRole('button', { name: 'Instant Assistance' })).toBeVisible();
  67  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-home-polished.png', fullPage: true });
  68  |   await page.getByRole('button', { name: '生成第一门课程' }).click();
  69  |   await page.getByLabel('课程名称', {exact:true}).fill('分数关系与证据');
  70  |   await page.getByRole('button', { name: '预览课程蓝图' }).click();
  71  |   await expect(page.getByText('Unit 1:', { exact: false }).first()).toBeVisible();
  72  |   await page.getByRole('button', { name: '确认并创建' }).click();
  73  |   await expect(page.getByRole('heading', { name: '分数关系与证据' })).toBeVisible();
  74  |   await expect(page.getByText('Unit 1:', { exact: false }).first()).toBeVisible();
  75  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-course-polished.png', fullPage: true });
  76  | 
  77  |   await selectWorkspaceView(page, 'Courses');
  78  |   const ticket = page.locator('.ws-course-ticket').filter({ has: page.getByRole('button', { name: '打开课程：分数关系与证据', exact: true }) });
  79  |   await page.evaluate(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  80  |   await ticket.locator('.ws-ticket-next').click();
  81  |   await expect(page.locator('.cl-room')).toBeVisible();
  82  |   await page.getByRole('button', { name: '离开课堂', exact: true }).click();
  83  |   await page.getByRole('button', { name: '保存并离开' }).click();
  84  |   await expect(page.getByRole('heading', { name: '分数关系与证据' })).toBeVisible();
  85  | 
  86  |   await selectWorkspaceView(page, 'Home');
  87  |   await page.getByRole('button', { name: 'Instant Assistance' }).click();
  88  |   await page.getByRole('button', { name: 'Concept Explanation' }).click();
> 89  |   await page.locator('.sa-tools-popover').getByRole('button', { name: /Whiteboard session/ }).click();
      |                                                                                               ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  90  |   await page.locator('.sa-composer textarea').fill('解释异分母分数加法');
  91  |   await page.locator('.sa-composer > div > button:last-child').click();
  92  |   await expect(page.getByText('WHITEBOARD SESSION', { exact: true })).toBeVisible();
  93  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-whiteboard-preview.png', fullPage: true });
  94  |   await page.getByRole('button', { name: '保存到学习工作台' }).click();
  95  |   await expect(page.getByRole('dialog', { name: '白板视频' })).toBeVisible();
  96  |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-whiteboard-player.png', fullPage: true });
  97  |   const videoDownload = page.waitForEvent('download', { timeout: 120_000 });
  98  |   await page.getByRole('button', { name: '导出视频' }).click();
  99  |   const video = await videoDownload;
  100 |   expect(video.suggestedFilename()).toMatch(/\.webm$/);
  101 |   expect(statSync(await video.path()).size).toBeGreaterThan(2_000);
  102 |   const subtitleDownload = page.waitForEvent('download');
  103 |   await page.getByRole('button', { name: '导出字幕' }).click();
  104 |   expect((await subtitleDownload).suggestedFilename()).toMatch(/\.srt$/);
  105 |   await page.getByRole('button', { name: '关闭白板' }).click();
  106 | 
  107 |   await selectWorkspaceView(page, 'Calendar');
  108 |   await page.getByRole('button', { name: '＋ 新建学习安排' }).click();
  109 |   await page.getByLabel('任务名称').fill('分数复习安排');
  110 |   await page.getByLabel('完成标准').fill('独立完成 5 道新题并说出关键步骤');
  111 |   await page.getByRole('button', { name: '加入学习日历' }).click();
  112 |   await expect(page.locator('.ws-month-grid').getByText('分数复习安排')).toBeVisible();
  113 |   await page.getByRole('button', { name: '连接 LMS / 日历' }).click();
  114 |   await page.getByLabel('来源类型').selectOption('lms_ics');
  115 |   await page.getByLabel('或粘贴 ICS 文件内容').fill('BEGIN:VCALENDAR\nBEGIN:VEVENT\nUID:school-1\nDTSTART:20261103T080000+0800\nDTEND:20261103T084500+0800\nSUMMARY:学校单元复习\nEND:VEVENT\nEND:VCALENDAR');
  116 |   await page.getByRole('button', { name: '连接并同步' }).click();
  117 |   await page.getByRole('button', {name:'下一个日期范围'}).click();
  118 |   await expect(page.locator('.ws-month-grid').getByText('学校单元复习')).toBeVisible();
  119 |   await expect(page.getByRole('button', { name: '连接并同步' })).toHaveCount(0);
  120 |   await page.locator('.ws-calendar-management > summary').click();
  121 |   await page.getByRole('button', { name: '＋ 生成诊断学习计划' }).click();
  122 |   await expect(page.getByLabel('计划目标')).toBeVisible();
  123 |   await page.getByRole('button', { name: '预览学习计划' }).click();
  124 |   await expect(page.getByText('审阅后再加入日历')).toBeVisible();
  125 |   await expect(page.getByText(/计划完成只表示执行过任务/)).toBeVisible();
  126 |   await page.getByRole('button', { name: '确认并加入日历' }).click();
  127 |   await expect(page.locator('.sa-plan-card')).toBeVisible();
  128 |   await page.locator('.sa-plan-actions').getByRole('button', { name: '完成', exact: true }).first().click();
  129 |   await expect(page.getByText('D+1 延迟复测', { exact: false }).first()).toBeVisible();
  130 |   await expect(page.getByText(/D\+14/).last()).toBeVisible();
  131 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-calendar-polished.png', fullPage: true });
  132 | 
  133 |   const pdf = writeTextPdf();
  134 |   await selectWorkspaceView(page, 'Materials');
  135 |   await expect(page.getByRole('tab', { name: 'PDF 页级资料' })).toHaveAttribute('aria-selected', 'true');
  136 |   await page.locator('input[type=file]').setInputFiles(pdf.path);
  137 |   await expect(page.getByText('分数讲义', { exact: true }).first()).toBeVisible({ timeout: 30_000 });
  138 |   await page.waitForFunction(() => Boolean(document.querySelector('.sa-pdf-paper img') || document.querySelector('.sa-pdf-failed')),
  139 |     undefined, { timeout: 30_000 });
  140 |   if (await page.locator('.sa-pdf-failed').count())
  141 |     throw new Error('PDF processing failed: ' + await page.locator('.sa-pdf-failed').innerText());
  142 |   await expect(page.locator('.sa-pdf-paper img')).toBeVisible({ timeout: 30_000 });
  143 |   await page.getByRole('button', { name: '结构恢复' }).click();
  144 |   await expect(page.getByText('公式结构', { exact: true })).toBeVisible();
  145 |   await expect(page.getByText(/候选 LaTeX/)).toBeVisible();
  146 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-pdf-structure-review.png', fullPage: true });
  147 |   await page.getByRole('button', { name: '已对照原页确认结构' }).click();
  148 |   await expect(page.getByText('结构已恢复')).toBeVisible();
  149 |   await page.getByRole('button', { name: '原版页面' }).click();
  150 |   const originalDownload = page.waitForEvent('download');
  151 |   await page.getByRole('button', { name: '下载原文件' }).click();
  152 |   expect((await originalDownload).suggestedFilename()).toMatch(/\.pdf$/);
  153 |   await page.getByRole('tab', { name: '个性化学案' }).click();
  154 |   await page.getByRole('button', { name: '生成学案预览' }).click();
  155 |   await expect(page.getByText('REVIEW BEFORE SAVING')).toBeVisible();
  156 |   await page.getByRole('button', { name: '保存到 Materials' }).click();
  157 |   await expect(page.locator('.sa-pack-library')).toContainText('个性化学案');
  158 |   if (!process.env.CI) await page.screenshot({ path: browserEvidence('studio') + '/studio-materials-and-pack.png', fullPage: true });
  159 |   pdf.cleanup();
  160 | 
  161 |   await page.setViewportSize({ width: 390, height: 844 });
  162 |   await page.goto('/studio');
  163 |   await selectWorkspaceView(page, 'Materials');
  164 |   await page.getByRole('tab', { name: '个性化学案' }).click();
  165 |   await expect(page.locator('.sa-pack-layout')).toBeVisible();
  166 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  167 |   await selectWorkspaceView(page, 'Calendar');
  168 |   await page.locator('.ws-calendar-management > summary').click();
  169 |   await expect(page.locator('.sa-plan-card')).toBeVisible();
  170 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  171 | 
  172 |   await selectWorkspaceView(page, 'Home');
  173 |   await page.reload();
  174 |   await expect(page.getByRole('button', { name: 'Craft Courses' })).toBeVisible();
  175 |   expect(errors).toEqual([]);
  176 | });
  177 | 
```