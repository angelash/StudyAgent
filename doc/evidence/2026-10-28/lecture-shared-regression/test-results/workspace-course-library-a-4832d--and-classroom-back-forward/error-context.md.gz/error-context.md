# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workspace.spec.ts >> course library and outline preserve navigation, panels, help and classroom back/forward
- Location: tests\e2e\workspace.spec.ts:25:5

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByLabel('向课堂老师提问')
Expected pattern: /我正在学习/
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveValue" getByLabel('向课堂老师提问') with timeout 15000ms
  - waiting for getByLabel('向课堂老师提问')
    - waiting for "http://localhost:3107/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u3-l1&lectureVersion=d1b70c0eaf4599b70bf84934693c71aebce78874a103b4f126ec3b254f784a37" navigation to finish...
    - navigated to "http://localhost:3107/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u3-l1&lectureVersion=d1b70c0eaf4599b70bf84934693c71aebce78874a103b4f126ec3b254f784a37"

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent 学习工作台":
      - /url: /studio
      - text: StudyAgent
    - button "收起学习导航" [expanded]
    - navigation "工作台主要入口":
      - button "Home": 首页
      - button "Courses": 课程
      - button "Calendar": 学习动态
      - button "History": 历史
      - button "Materials": 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - button "＋ 创建课程"
    - region "继续学习":
      - heading "继续学习" [level=3]
      - link "社会分层体系 社会学概论":
        - /url: /studio/classroom?lesson=soc-3-1-1&session=classroom_29f1625a-d5b3-4c33-b7e1-927780ce9a5b
    - heading "近期活动" [level=3]
    - link "返回学习首页":
      - /url: /learn?subject=math
      - text: 返回学习首页 →
  - text: 独立学习
  - link "创建学习档案":
    - /url: /parent/dashboard
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "Time for flashcards?" [level=1]
  - region "学习工作台助教":
    - button "查找历史"
    - region "当前讲座上下文":
      - strong: 阶级与分层
      - text: U3·L1 社会学概论
      - button "移除讲座上下文": ×
    - link "返回本讲 ↗":
      - /url: /studio/classroom?unit=2&panel=units&lecture=soc-u3-l1&lectureVersion=d1b70c0eaf4599b70bf84934693c71aebce78874a103b4f126ec3b254f784a37
    - text: 想一起看看什么
    - textbox "想一起看看什么":
      - /placeholder: 问一个概念，或告诉我你想理清的问题…
    - button "打开学习资料": ＋
    - button "Tools"
    - text: 模型
    - combobox "选择大模型":
      - option "Auto · 平台默认 DeepSeek V4.1 Flash"
    - group: ⓘ
    - button "发送学习问题" [disabled]: ↑
    - button "Concept Explanation"
    - button "Personal Study Materials Generation"
    - button "Long-files Digestion"
    - button "Problem Solving"
    - link "Visualization":
      - /url: /studio/whiteboards
```

# Test source

```ts
  1  | import { browserEvidence } from './evidence';
  2  | import { expect, test, type Page } from '@playwright/test';
  3  | import { mkdirSync } from 'node:fs';
  4  | 
  5  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  6  | const evidence = browserEvidence('workspace');
  7  | let fixtureAddress=0;
  8  | async function account(page: Page, child = false) {
  9  |   const key = `${Date.now()}-${Math.floor(Math.random() * 100000)}`, principal = `workspace-${key}@local.test`, credential = `Workspace-${key}`;
  10 |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json','x-forwarded-for':'127.22.0.'+(++fixtureAddress) }, body: JSON.stringify({principal, credential}) });
  11 |   expect(response.status).toBe(201); const {data} = await response.json();
  12 |   const headers = { 'content-type': 'application/json', authorization: 'Bearer ' + data.token };
  13 |   let studentId = '';
  14 |   if (child) {
  15 |     const result = await fetch(api + '/students', {method:'POST',headers,body:JSON.stringify({nickname:'日历整改验收',grade:5,preferredSessionMinutes:15,defaultVersionMap:{math:'common',chinese:'common',english:'common'}})});
  16 |     expect(result.status).toBe(201); studentId = (await result.json()).data.profile.id;
  17 |   }
  18 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  19 |   await page.getByRole('button', {name:'登录，查看学习记录 →'}).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  20 |   await page.evaluate(() => localStorage.setItem('studyagent.classroom.tour','done'));
  21 |   return {studentId, headers};
  22 | }
  23 | async function screenshot(page: Page, name: string) { if (!process.env.CI) { mkdirSync(evidence,{recursive:true}); await page.screenshot({path:`${evidence}/${name}.png`,fullPage:true}); } }
  24 | 
  25 | test('course library and outline preserve navigation, panels, help and classroom back/forward', async ({page}) => {
  26 |   test.setTimeout(100000); const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  27 |   await page.setViewportSize({width:1645,height:954}); await account(page); await page.goto('/studio?view=courses');
  28 |   await expect(page.getByRole('heading',{name:'我的课程'})).toBeVisible();
  29 |   await expect(page.getByRole('link',{name:'打开课程：社会学概论'})).toBeVisible();
  30 |   await screenshot(page,'workspace-courses-desktop');
  31 |   await page.getByLabel('搜索课程').fill('不存在的课程');await expect(page.getByText('没有匹配的课程')).toBeVisible();
  32 |   await page.getByRole('button',{name:'查看全部课程'}).click();await page.getByRole('tab',{name:'已完成',exact:true}).click();await expect(page.getByText('还没有完成的课程')).toBeVisible();
  33 |   await page.getByRole('button',{name:'查看全部课程'}).click();await page.getByRole('link',{name:'打开课程：社会学概论'}).click();
  34 |   await expect(page.locator('.cl-unit-nav button')).toHaveCount(5);await screenshot(page,'workspace-outline-desktop');
  35 |   await page.locator('.cl-unit-nav button').nth(2).click();await page.getByRole('tab',{name:'资料',exact:true}).click();
  36 |   await page.reload();await expect(page.getByRole('tab',{name:'资料',exact:true})).toHaveAttribute('aria-selected','true');
  37 |   await expect(page.locator('.cl-unit-nav button').nth(2)).toHaveAttribute('data-active','true');
  38 |   await page.getByRole('tab',{name:'单元',exact:true}).click();await page.getByRole('button',{name:/查看学习目标：/}).first().click();
  39 |   await expect(page.getByRole('dialog',{name:'微课学习目标'})).toBeVisible();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);
  40 |   await page.locator('.cl-learn').first().click();await expect(page.locator('.cl-room')).toBeVisible();await expect(page).toHaveURL(/lesson=/);
  41 |   await page.goBack();await expect(page.locator('.cl-unit-nav button').nth(2)).toHaveAttribute('data-active','true');
  42 |   await page.goForward();await expect(page.locator('.cl-room')).toBeVisible();
  43 |   await page.getByRole('button',{name:'离开课堂',exact:true}).click();await page.getByRole('button',{name:'保存并离开'}).click();
  44 |   await expect(page.locator('.cl-unit-nav button').nth(2)).toHaveAttribute('data-active','true');
> 45 |   await page.getByRole('button',{name:'获取帮助',exact:true}).first().click();await expect(page.getByLabel('向课堂老师提问')).toHaveValue(/我正在学习/);
     |                                                                                                                    ^ Error: expect(locator).toHaveValue(expected) failed
  46 |   await page.goBack();await page.setViewportSize({width:390,height:844});await expect(page.locator('.cl-unit-nav')).toBeVisible();
  47 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await screenshot(page,'workspace-outline-mobile');
  48 |   await page.getByRole('button',{name:'打开学习导航',exact:true}).click();
  49 |   await page.locator('.ws-navigation').getByRole('link',{name:'Courses',exact:true}).click();await expect(page.getByRole('heading',{name:'我的课程'})).toBeVisible();
  50 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await screenshot(page,'workspace-courses-mobile');
  51 |   expect(errors).toEqual([]);
  52 | });
  53 | 
  54 | test('calendar supports real date navigation, edit, confirmation, completion, export and batch lifecycle',async({page})=>{
  55 |   test.setTimeout(120000);const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  56 |   await page.setViewportSize({width:1645,height:954});const {studentId}=await account(page,true);
  57 |   await page.goto(`/studio?view=calendar&student=${studentId}&subject=math&date=2026-10-23`);
  58 |   await expect(page.locator('.ws-calendar-day')).toHaveCount(35);await screenshot(page,'workspace-calendar-empty-desktop');
  59 |   await page.getByRole('button',{name:'周视图',exact:true}).click();await expect(page.locator('.ws-calendar-day')).toHaveCount(7);
  60 |   await page.getByRole('button',{name:'下一个日期范围'}).click();await expect(page).toHaveURL(/date=2026-10-30/);
  61 |   await page.getByRole('button',{name:'上一个日期范围'}).click();await page.getByRole('button',{name:'月视图',exact:true}).click();await page.reload();
  62 |   await expect(page.getByRole('button',{name:'选择日期 2026-10-23'})).toHaveAttribute('aria-pressed','true');
  63 |   async function create(title:string){await page.getByRole('button',{name:'＋ 新建学习安排'}).click();await page.getByLabel('任务名称').fill(title);await page.getByLabel('开始时间').fill('2026-10-23T16:00');await page.getByRole('button',{name:'加入学习日历'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.ws-month-grid').getByText(title,{exact:false})).toBeVisible();}
  64 |   await create('整改任务甲');await create('整改任务乙');
  65 |   await page.locator('.ws-month-grid').getByRole('button',{name:/整改任务甲/}).click();await page.getByRole('button',{name:'编辑时间与内容'}).click();
  66 |   await page.getByLabel('任务名称').fill('跨月移动后的任务');await page.getByLabel('开始时间').fill('2026-11-03T10:00');await page.getByLabel('结束时间').fill('2026-11-03T10:40');await page.getByRole('button',{name:'保存修改'}).click();
  67 |   await expect(page.getByRole('dialog')).toContainText('跨月移动后的任务');await page.keyboard.press('Escape');
  68 |   await expect(page.locator('.ws-month-grid').getByText('整改任务甲',{exact:false})).toHaveCount(0);
  69 |   await page.getByRole('button',{name:'下一个日期范围'}).click();await page.locator('.ws-month-grid').getByRole('button',{name:/跨月移动后的任务/}).click();
  70 |   await page.getByRole('button',{name:'移至待处理'}).click();await expect(page.getByRole('dialog')).toContainText('待处理');await page.keyboard.press('Escape');
  71 |   await expect(page.locator('.ws-month-grid').getByText('跨月移动后的任务',{exact:false})).toHaveCount(0);
  72 |   await page.getByRole('tab',{name:'待处理任务'}).click();await page.locator('.ws-month-grid').getByRole('button',{name:/跨月移动后的任务/}).click();
  73 |   await page.getByRole('button',{name:'确认安排',exact:true}).click();await page.keyboard.press('Escape');await page.getByRole('tab',{name:'已确认任务'}).click();
  74 |   await page.locator('.ws-month-grid').getByRole('button',{name:/跨月移动后的任务/}).click();await page.getByRole('button',{name:'标记完成'}).click();
  75 |   await expect(page.getByRole('dialog')).toContainText('已完成');await page.getByRole('button',{name:'重新打开',exact:true}).click();await expect(page.getByRole('dialog')).toContainText('已确认');await page.keyboard.press('Escape');
  76 |   await page.reload();await expect(page.locator('.ws-month-grid').getByText('跨月移动后的任务',{exact:false})).toBeVisible();
  77 |   const download=page.waitForEvent('download');await page.getByRole('button',{name:'导出 ICS',exact:true}).click();expect((await download).suggestedFilename()).toMatch(/\.ics$/);
  78 |   await page.getByRole('button',{name:'上一个日期范围'}).click();await page.getByRole('button',{name:'批量删除日程'}).click();await page.getByLabel('选择当前范围的手动安排').check();
  79 |   await page.getByRole('button',{name:'下一个日期范围'}).click();await expect(page.getByRole('button',{name:'删除所选'})).toBeDisabled();
  80 |   await page.getByRole('button',{name:'上一个日期范围'}).click();await page.getByLabel('选择当前范围的手动安排').check();await page.getByRole('button',{name:'删除所选'}).click();
  81 |   await expect(page.getByRole('dialog',{name:'确认删除学习安排'})).toBeVisible();await page.getByRole('button',{name:'取消',exact:true}).click();await expect(page.locator('.ws-month-grid').getByText('整改任务乙',{exact:false})).toBeVisible();
  82 |   await page.getByRole('button',{name:'删除所选'}).click();await page.getByRole('button',{name:'确认删除',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
  83 |   await expect(page.locator('.ws-month-grid').getByText('整改任务乙',{exact:false})).toHaveCount(0);
  84 |   await page.getByRole('button',{name:'下一个日期范围'}).click();await expect(page.locator('.ws-month-grid').getByText('跨月移动后的任务',{exact:false})).toBeVisible();
  85 |   await screenshot(page,'workspace-calendar-tasks-desktop');
  86 |   await page.getByLabel('学科',{exact:true}).selectOption('english');await expect(page.locator('.ws-month-grid').getByText('跨月移动后的任务',{exact:false})).toHaveCount(0);await page.reload();await expect(page.getByLabel('学科',{exact:true})).toHaveValue('english');
  87 |   await page.getByLabel('学科',{exact:true}).selectOption('math');await page.getByRole('button',{name:'下一个日期范围'}).click();await expect(page.locator('.ws-month-grid').getByText('跨月移动后的任务',{exact:false})).toBeVisible();
  88 |   await page.setViewportSize({width:390,height:844});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await screenshot(page,'workspace-calendar-mobile');
  89 |   expect(errors).toEqual([]);
  90 | });
  91 | 
```