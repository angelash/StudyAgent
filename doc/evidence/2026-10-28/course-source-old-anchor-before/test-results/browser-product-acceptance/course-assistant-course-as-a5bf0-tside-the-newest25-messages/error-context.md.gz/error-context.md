# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-assistant.spec.ts >> course assistant: source return locates an original answer outside the newest25 messages
- Location: tests\e2e\course-assistant.spec.ts:74:5

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator: locator('[data-message-id="assistant_message_6f79cc45-807f-45e0-8eb0-fb9c55672f95"]')
Expected: focused
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeFocused" locator('[data-message-id="assistant_message_6f79cc45-807f-45e0-8eb0-fb9c55672f95"]') with timeout 15000ms
  - waiting for locator('[data-message-id="assistant_message_6f79cc45-807f-45e0-8eb0-fb9c55672f95"]')

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent 学习工作台":
      - /url: /studio
      - text: StudyAgent
    - button "收起学习导航" [expanded]
    - navigation "工作台主要入口":
      - button "Home": 首页
      - button "Courses": 课程
      - button "Calendar": 学习动态
      - button "History": 历史
      - button "Materials": 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - button "＋ 创建课程"
    - region "开始学习":
      - heading "开始学习" [level=3]
      - link "打开课程 从一节适合自己的课开始。":
        - /url: /studio?view=courses
    - heading "近期活动" [level=3]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页":
      - /url: /learn?subject=math
      - text: 返回学习首页 →
  - text: 独立学习
  - link "创建学习档案":
    - /url: /parent/dashboard
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "Time for flashcards?" [level=1]
  - region "学习工作台助教":
    - text: 当前学习对话
    - button "查找历史"
    - text: 当前会话关键词
    - textbox "检索当前对话"
    - button "查找这段对话" [disabled]
    - log "当前学习对话":
      - button "更早的消息"
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第45条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第46条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第47条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第48条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第49条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第50条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第51条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第52条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第53条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第54条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第55条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第56条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第57条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第58条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第59条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: EARLY_HISTORY_MARKER · 匿名历史第60条
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第61条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第62条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第63条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第64条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第65条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第66条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第67条，核对条件再解释。
        - text: 根据学习记录给出的引导
      - article:
        - strong: 我
        - paragraph: 合成历史第68条，核对条件再解释。
      - article:
        - strong: 学习助教
        - paragraph: 合成历史第69条，核对条件再解释。
        - text: 根据学习记录给出的引导
    - region "提问任务":
      - status: 回答已保存
      - text: DeepSeek V4.1 Flash
      - group: 原问题与记录
    - group: 提问记录（已读取 1 条）
    - region "当前讲座上下文":
      - strong: 社会学思考
      - text: U1·L1 社会学概论
      - button "移除讲座上下文": ×
    - link "返回本讲 ↗":
      - /url: /studio/classroom?unit=0&panel=units&lecture=soc-u1-l1&lectureVersion=6aa6d782f5a7241ac0783cc587f9e1301947df9005730b6a30d481adbe6b6091
    - text: 想一起看看什么
    - textbox "想一起看看什么":
      - /placeholder: 问一个概念，或告诉我你想理清的问题…
    - button "打开学习资料": ＋
    - button "Tools"
    - text: 模型
    - combobox "选择大模型":
      - option "Auto · 平台默认 DeepSeek V4.1 Flash"
    - group: ⓘ
    - button "发送学习问题" [disabled]: ↑
    - button "Concept Explanation"
    - button "Personal Study Materials Generation"
    - button "Long-files Digestion"
    - button "Problem Solving"
    - link "Visualization":
      - /url: /studio/whiteboards
    - button "下载提问副本"
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { browserEvidence } from './evidence';
  3  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  4  | const evidence = browserEvidence('course-assistant');
  5  | async function sourceFonts(page: Page) { await expect(page.getByRole('region', { name: '当时的教学出处', exact: true })).toHaveAttribute('data-original-font-status', 'ready'); }
  6  | let address = 0;
  7  | async function login(page: Page) {
  8  |   const principal = 'course-ui-' + crypto.randomUUID() + '@local.test', credential = 'Course-ui-20261028-only';
  9  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.17.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  10 |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  11 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/); return actor;
  13 | }
  14 | async function call(actor: any, path: string, body?: unknown) {
  15 |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token },
  16 |     ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  17 |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  18 | }
  19 | async function cited(actor: any) {
  20 |   const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  21 |   const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  22 |   const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  23 |   const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请解释本讲所选概念。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  24 |   await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  25 |   const page = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = page.messages.find((m: any) => m.sender === 'assistant');
  26 |   expect(message.sourceReferences).toHaveLength(1); return { d, session, message, ref: message.sourceReferences[0] };
  27 | }
  28 | test('course assistant: opens the actual frozen source directly without creating a conversation or sending a question', async ({ page }) => {
  29 |   test.setTimeout(100000); await page.setViewportSize({ width: 880, height: 887 }); const actor = await login(page), data = await cited(actor), posts: string[] = [];
  30 |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  31 |   await page.goto(data.ref.href); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); await sourceFonts(page);
  32 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toContainText('社会学'); expect(posts).toEqual([]);
  33 |   await page.reload(); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); await sourceFonts(page); expect(posts).toEqual([]);
  34 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-direct.png', fullPage: true });
  35 | });
  36 | test('course assistant: a cited answer exposes its source and returns to its complete draft and original message', async ({ page }) => {
  37 |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  38 |   await page.goto('/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + data.d.fingerprint);
  39 |   const input = page.getByLabel('想一起看看什么', { exact: true }); await expect(input).toBeEnabled();
  40 |   await input.fill('完整保留的原讲座匿名草稿。');
  41 |   const source = page.getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first(); await expect(source).toBeVisible(); await source.click();
  42 |   await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  43 |   await page.getByRole('link', { name: '返回原对话', exact: true }).click(); await expect(input).toHaveValue('完整保留的原讲座匿名草稿。');
  44 |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  45 | });
  46 | 
  47 | test('course assistant: narrow source views retain every table cell and original teaching code without running it', async ({ page }) => {
  48 |   test.setTimeout(100000); await page.setViewportSize({ width: 390, height: 844 }); const actor = await login(page), data = await cited(actor);
  49 |   const table = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-6');
  50 |   await page.goto(table.reference.href); await expect(page.getByRole('table')).toBeVisible(); await sourceFonts(page);
  51 |   const expected = table.sections.flatMap((s: any) => s.blocks).find((b: any) => b.table).table;
  52 |   for (const header of expected.headers) await expect(page.getByRole('columnheader', { name: header, exact: true })).toBeVisible();
  53 |   for (const row of expected.rows) for (const cell of row) await expect(page.getByRole('cell', { name: cell, exact: true })).toBeVisible();
  54 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  55 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-table-390.png', fullPage: true });
  56 |   const source = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-3'), originalCode = source.sections.flatMap((s: any) => s.blocks).find((b: any) => b.code !== undefined).code;
  57 |   const runs: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /(?:code|run|execute)/.test(r.url())) runs.push(r.url()); });
  58 |   await page.goto(source.reference.href); await expect(page.getByLabel('原教学代码')).toBeVisible(); await sourceFonts(page); expect(await page.getByLabel('原教学代码').textContent()).toBe(originalCode);
  59 |   await expect(page.getByRole('list', { name: '图形完整标注' })).toContainText('行业岗位变化'); expect(runs).toEqual([]);
  60 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  61 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-code-390.png', fullPage: true });
  62 | });
  63 | 
  64 | test('course assistant: a different account cannot retain source content or cause a conversation post', async ({ page }) => {
  65 |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor); await page.goto(data.ref.href);
  66 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toBeVisible();
  67 |   await page.context().clearCookies(); await login(page); const posts: string[] = [];
  68 |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  69 |   const denied = page.waitForResponse(r => r.url().includes('/ai/assistant/sessions/' + data.session.id + '/sources/'));
  70 |   await page.goto(data.ref.href); expect((await denied).status()).toBe(404); await expect(page.getByRole('alert', { name: '出处读取失败' })).toContainText('无法读取'); await sourceFonts(page);
  71 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toHaveCount(0); await expect(page.getByRole('link', { name: '返回原对话', exact: true })).toHaveCount(0); expect(posts).toEqual([]);
  72 | });
  73 | 
  74 | test('course assistant: source return locates an original answer outside the newest25 messages', async ({ page }) => {
  75 |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  76 |   await call(actor, '/qa/assistant/seed-history', { sessionId: data.session.id, count: 70, makeSourceOld: true });
  77 |   const recent = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/messages/page?pageSize=25');
  78 |   expect(recent.messages.some((m: any) => m.id === data.message.id)).toBe(false);
  79 |   const href = new URL(data.ref.href, 'https://local.invalid'); href.searchParams.set('assistantSourceMessage', data.message.id);
  80 |   await page.goto(href.pathname + href.search); await sourceFonts(page); await page.getByRole('link', { name: '返回原对话', exact: true }).click();
> 81 |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
     |                                                                             ^ Error: expect(locator).toBeFocused() failed
  82 |   await expect(page.getByRole('navigation', { name: '本次回答的教学出处' })).toBeVisible();
  83 | });
  84 | 
```