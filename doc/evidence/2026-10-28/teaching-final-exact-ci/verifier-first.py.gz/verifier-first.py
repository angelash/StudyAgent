from pathlib import Path
import json,gzip,hashlib,re
root=Path.cwd();src=root/'data/qa/teaching-ci-40546374381';r=json.loads((src/'run.json').read_text(encoding='utf-8-sig'))
assert r['databaseId']==40546374381 and r['headSha']=='64d8bce356cb62c4b361de112e9414761873229d'
assert r['status']=='completed' and r['conclusion']=='success' and len(r['jobs'])==3
assert all(j['status']=='completed' and j['conclusion']=='success' for j in r['jobs'])
browser=json.loads((src/'artifact/data/qa/source-course-full-browser.json').read_text(encoding='utf-8-sig'));tests=[]
def visit(s):
 for spec in s.get('specs',[]):tests.extend(spec.get('tests',[]))
 for child in s.get('suites',[]):visit(child)
for s in browser['suites']:visit(s)
attempts=[a for t in tests for a in t['results']]
assert len(tests)==len(attempts)==411 and all(a['status']=='passed' and a.get('retry',0)==0 for a in attempts)
assert browser['stats']['unexpected']==browser['stats']['skipped']==browser['stats']['flaky']==0
log=re.sub(r'\x1b\[[0-9;]*m','',(src/'jobs.log').read_text(encoding='utf8'))
assert re.search(r'Tests\s+1497 passed\s*\|\s*72 skipped',log)
pg=json.loads((src/'postgres-job-summary.json').read_text(encoding='utf8'));assert pg['conclusion']=='success' and pg['teachingPassed']==30 and pg['sqliteOnlySkipped']==1
dest=root/'doc/evidence/2026-10-28/teaching-final-exact-ci';dest.mkdir(parents=True,exist_ok=False)
for relative in ['run.json','jobs.log','postgres-job-summary.json','artifact/data/qa/source-course-full-browser.json']:
 p=src/relative
 with gzip.open(dest/(p.name+'.gz'),'wb') as out:out.write(p.read_bytes())
receipt={'headSha':r['headSha'],'runId':r['databaseId'],'conclusion':r['conclusion'],'jobs':[{k:j[k] for k in ['name','status','conclusion']} for j in r['jobs']],'api':{'passed':1497,'failed':0,'environmentSkipped':72},'postgresTeaching':{'passed':30,'failed':0,'sqliteOnlySkipped':1},'browser':{'tests':411,'attempts':411,'passed':411,'failed':0,'skipped':0,'flaky':0,'retryAttempts':0,'stats':browser['stats']},'scope':'Exact64d8bce three-job CI including complete browser with corrected decoded PTS and current sealed model resource. Teaching PG is an overlapping sub-suite, not a sum. No real teacher, physical device or long-term learning claim.','files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in dest.iterdir()}}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in receipt.items() if k!='files'},ensure_ascii=False))
