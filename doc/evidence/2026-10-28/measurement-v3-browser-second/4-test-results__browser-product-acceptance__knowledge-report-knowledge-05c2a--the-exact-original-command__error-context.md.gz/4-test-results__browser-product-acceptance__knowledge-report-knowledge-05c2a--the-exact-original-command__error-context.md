# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: knowledge-report.spec.ts >> knowledge report: a lost reanalysis receipt survives reload with the exact original command
- Location: tests\e2e\knowledge-report.spec.ts:244:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('region', { name: '重新核对报告依据' })
Expected: 0
Received: 1
Timeout:  15000ms

Call log:
  - Expect "toHaveCount" getByRole('region', { name: '重新核对报告依据' }) with timeout 15000ms
  - waiting for getByRole('region', { name: '重新核对报告依据' })
    33 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - main [ref=f3e2]:
    - generic [ref=f3e3]:
      - link "学习观察室" [ref=f3e4] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f3e5]: 学
        - text: 学习观察室
      - navigation "主要导航" [ref=f3e6]:
        - link "学习首页" [ref=f3e7] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_68b5082b-b672-4e11-bb98-41d0c22b74a4
        - link "学习工作台" [ref=f3e8] [cursor=pointer]:
          - /url: /studio?subject=math&student=student_68b5082b-b672-4e11-bb98-41d0c22b74a4
        - link "家长空间" [ref=f3e9] [cursor=pointer]:
          - /url: /parent/dashboard?subject=math&studentId=student_68b5082b-b672-4e11-bb98-41d0c22b74a4
        - link "知识诊断" [ref=f3e10] [cursor=pointer]:
          - /url: /student/assessment?subject=math&studentId=student_68b5082b-b672-4e11-bb98-41d0c22b74a4
        - link "今日学习" [ref=f3e11] [cursor=pointer]:
          - /url: /student/today?subject=math&studentId=student_68b5082b-b672-4e11-bb98-41d0c22b74a4
        - link "题卷资料" [ref=f3e12] [cursor=pointer]:
          - /url: /library?subject=math&studentId=student_68b5082b-b672-4e11-bb98-41d0c22b74a4
      - generic [ref=f3e13]:
        - link "资料管理" [ref=f3e14] [cursor=pointer]:
          - /url: /parent/data
        - button "退出" [ref=f3e15] [cursor=pointer]
    - generic [ref=f3e16]:
      - complementary [ref=f3e17]:
        - text: LEARNING / INSIGHT
        - heading [level=1] [ref=f3e18]:
          - text: 把知识
          - emphasis [ref=f3e19]: 学扎实。
        - paragraph [ref=f3e20]: 从学到了哪里开始，找到卡住的那一步，再用新题看看是否真的掌握。
        - list [ref=f3e21]:
          - listitem [ref=f3e22]:
            - generic [ref=f3e23]: "01"
            - text: 确认学习进度
          - listitem [ref=f3e24]:
            - generic [ref=f3e25]: "02"
            - text: 完成一组评测
          - listitem [ref=f3e26]:
            - generic [ref=f3e27]: "03"
            - text: 看懂知识与原因
          - listitem [ref=f3e28]:
            - generic [ref=f3e29]: "04"
            - text: 指导、复测与复盘
        - generic [ref=f3e30]:
          - generic [ref=f3e31]: 匿
          - generic [ref=f3e32]:
            - strong [ref=f3e33]: 匿名知识点观察
            - generic [ref=f3e34]: 4年级 · 数学
        - button "返回学习进度与历史" [ref=f3e35] [cursor=pointer]
      - generic [ref=f3e36]:
        - generic [ref=f3e37]:
          - text: 03 / 知道表现，也知道依据
          - heading "从知识点看清下一步。" [level=2] [ref=f3e38]
          - paragraph [ref=f3e39]: 本次已评分 7 题，0 题待复核；2 个知识点仍需补充证据。下一步优先核查具体知识与步骤。
        - group [ref=f3e40]:
          - generic "本次范围：4年级 · 上学期 · 合成已学知识范围" [ref=f3e41] [cursor=pointer]
        - status [ref=f3e42]: 正在核对报告依据…
        - region "重新核对报告依据" [ref=f3e43]:
          - strong [ref=f3e44]: 上次核对的结果还需确认。
          - paragraph [ref=f3e45]: 原请求、版本和原因已保留。恢复会读取同一次操作的结果。
          - button "正在核对…" [disabled] [ref=f3e46]
        - status [ref=f3e47]: 正在核对报告依据…
        - group [ref=f3e48]:
          - generic "报告版本与评分变更记录" [ref=f3e49] [cursor=pointer]
        - group [ref=f3e50]:
          - generic "测量时采用的知识目标与标准" [ref=f3e51] [cursor=pointer]
        - generic [ref=f3e52]:
          - generic [ref=f3e53]:
            - strong [ref=f3e54]:
              - text: "7"
              - generic [ref=f3e55]: / 7
            - generic [ref=f3e56]: 已评分题目
          - generic [ref=f3e57]:
            - strong [ref=f3e58]: 0%
            - generic [ref=f3e59]: 本次题目得分
          - generic [ref=f3e60]:
            - strong [ref=f3e61]: "2"
            - generic [ref=f3e62]: 尚未测到的点
        - region "知识点工作区" [ref=f3e63]:
          - generic [ref=f3e64]:
            - generic [ref=f3e65]:
              - text: KNOWLEDGE / 一点一点看清
              - heading "知识掌握与证据范围" [level=3] [ref=f3e66]
            - paragraph [ref=f3e67]: 选一个知识点，把表现、可能原因和下一步放在一起。
          - generic [ref=f3e68]:
            - complementary "本报告知识点目录" [ref=f3e69]:
              - generic [ref=f3e70]:
                - text: 查找知识点
                - searchbox "查找知识点" [ref=f3e71]
              - paragraph [ref=f3e72]: 2 / 2 个知识点
              - generic [ref=f3e73]:
                - button "查看知识点：平均数的总量等分" [pressed] [ref=f3e74] [cursor=pointer]:
                  - strong [ref=f3e75]: 平均数的总量等分
                  - generic [ref=f3e76]: 尚未测量
                - button "查看知识点：明确平均对象并把零数据计入份数" [ref=f3e77] [cursor=pointer]:
                  - strong [ref=f3e78]: 明确平均对象并把零数据计入份数
                  - generic [ref=f3e79]: 尚未测量
            - generic [ref=f3e80]:
              - generic [ref=f3e81]:
                - generic [ref=f3e82]: 尚未测量
                - heading "平均数的总量等分" [level=3] [ref=f3e83]
              - region "本点冻结目标" [ref=f3e84]:
                - heading "当时要测什么" [level=4] [ref=f3e85]
                - paragraph [ref=f3e86]:
                  - strong [ref=f3e87]: 目标：
                  - text: 先合计总量再按数据个数平均
                - paragraph [ref=f3e88]:
                  - strong [ref=f3e89]: 成功标准：
                  - text: 按题目条件独立完成平均数的总量等分；用另一个结构的新题核查，并在延迟复测时再次验证。
              - region "本点量化与未知项" [ref=f3e90]:
                - heading "目前的证据说明什么" [level=4] [ref=f3e91]
                - generic [ref=f3e92]:
                  - strong [ref=f3e93]: 尚未形成有效估计
                  - paragraph [ref=f3e94]: 未测不等于零分。需要新的独立作答来补充。
                - generic [ref=f3e95]:
                  - generic [ref=f3e96]:
                    - generic [ref=f3e97]: 理解
                    - strong [ref=f3e98]: 未测
                  - generic [ref=f3e99]:
                    - generic [ref=f3e100]: 操作
                    - strong [ref=f3e101]: 未测
                  - generic [ref=f3e102]:
                    - generic [ref=f3e103]: 迁移
                    - strong [ref=f3e104]: 未测
                  - generic [ref=f3e105]:
                    - generic [ref=f3e106]: 保持
                    - strong [ref=f3e107]: 未测
                - paragraph [ref=f3e108]: 0 条计入估计的记录 · 0 个题族；相同结构的变式合并考虑。
                - paragraph [ref=f3e109]: 本组有 3 次选择暂时不会。这是孩子的自述，不计入能力估计或独立样本；原任务记录保留，原因仍需新的实际作答验证。
                - paragraph [ref=f3e110]: 迁移：仍需独立新题验证 · 保持：仍需真实间隔复测
              - region "本点表面表现" [ref=f3e111]:
                - heading "这组题里，看到了什么" [level=4] [ref=f3e112]
                - paragraph [ref=f3e113]: 本组 3 条记录：选择暂时不会 3 次，跳过 0 次，表达待复核 0 次。具体过程按原题核对。
                - group [ref=f3e114]:
                  - generic "逐题核对本组 3 条记录" [ref=f3e115] [cursor=pointer]
              - region "本点原因与验证" [ref=f3e116]:
                - heading "可能卡在哪里，以及怎样验证" [level=4] [ref=f3e117]
                - article [ref=f3e118]:
                  - generic [ref=f3e119]: 待验证
                  - heading "当前知识点的理解或执行需要核查" [level=5] [ref=f3e120]
                  - paragraph [ref=f3e121]: 在“平均数的总量等分”的 0 道不同题目中观察到未达标作答。另有 3 次选择暂时不会，尚无过程可以核对。
                  - paragraph [ref=f3e122]: 基础题表现可以定位到当前行为，尚不能单独解释产生问题的原因。
                  - paragraph [ref=f3e123]: 支持方向 0 条 · 反证 0 条。条数不等于独立题族数。
                  - group [ref=f3e124]:
                    - generic "核对条件、其他解释和原始依据" [ref=f3e125] [cursor=pointer]
                  - group [ref=f3e126]:
                    - generic "这条判断怎样变化 · 1 条记录" [ref=f3e127] [cursor=pointer]
                  - button "做一组题验证原因 ↗" [ref=f3e128] [cursor=pointer]
              - region "本点指导与复测" [ref=f3e129]:
                - heading "指导之后，怎样再验证" [level=4] [ref=f3e130]
                - paragraph [ref=f3e131]: 这份报告尚无对应的指导计划。家长可在报告下方制定计划，再确认指导活动与复测安排。
                - button "刷新指导记录" [ref=f3e132] [cursor=pointer]
        - generic [ref=f3e133]:
          - generic [ref=f3e134]:
            - heading "让评测变成下一步行动。" [level=3] [ref=f3e135]
            - paragraph [ref=f3e136]: 计划包含指导活动、成功标准与间隔复测。
          - button "制定指导计划 ↗" [ref=f3e137] [cursor=pointer]
        - paragraph [ref=f3e138]: 掌握度为规则估计，区间表示现有证据的不确定性；尚未建立标准化常模。一次表现不能确定深层原因。
    - button "打开学习观察助教" [ref=f3e140] [cursor=pointer]: "?"
  - alert [ref=f3e141]
```

# Test source

```ts
  163 |   const issued = await f.call('/students/' + f.studentId + '/learning-access/codes', { expectedVersion: 1, requestKey: randomUUID() });
  164 |   await page.goto('/student/login'); await page.getByLabel('一次性学习码').fill(issued.code); await page.getByRole('button', { name: '进入我的学习 →', exact: true }).click();
  165 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/); await page.goto(f.href);
  166 |   const workspace = page.getByRole('region', { name: '知识点工作区' }); await expect(workspace).toBeVisible();
  167 |   await expect(workspace.getByRole('button', { name: '查看指导与复测 ↗', exact: true })).toHaveCount(0);
  168 |   await expect(page.getByRole('button', { name: /制定指导计划|确认并开始计划/ })).toHaveCount(0);
  169 |   await f.call('/students/' + f.studentId + '/learning-access', { enabled: false, expectedVersion: 1, requestKey: randomUUID(), reason: '合成报告撤权测试' });
  170 |   await workspace.getByRole('button', { name: '刷新指导记录', exact: true }).click(); await expect(workspace).toHaveCount(0);
  171 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  172 | });
  173 | 
  174 | test('knowledge report: invalidating the actual browser login session ends the private report on its next read', async ({ page }) => {
  175 |   await fixture(page); const workspace = page.getByRole('region', { name: '知识点工作区' });
  176 |   expect(await page.evaluate(async base => (await fetch(base + '/auth/logout', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status, api)).toBe(201);
  177 |   await workspace.getByRole('button', { name: '刷新指导记录', exact: true }).click(); await expect(workspace).toHaveCount(0);
  178 |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  179 | });
  180 | 
  181 | test('knowledge report: actual submitted short-answer expressions awaiting review do not become scored failure or a zero estimate', async ({ page }) => {
  182 |   const f = await fixture(page), atomId = 'core:chinese:evidence-explanation';
  183 |   await f.call('/students/' + f.studentId + '/learning-scope', { subject: 'chinese', grade: 4, term: 'upper', textbookVolumeId: null,
  184 |     textbookVersion: '合成已学语文范围', learnedAtomIds: [atomId], currentAtomId: atomId, minutesPerSession: 10,
  185 |     progressMode: 'knowledge', selectedLessonIds: [] }, 'PUT');
  186 |   const session = await f.call('/diagnostics/sessions', { studentId: f.studentId, subject: 'chinese', intent: 'baseline',
  187 |     targetAtomIds: [atomId], includePrerequisites: false, adaptive: false, maxItems: 6 }); let expressions = 0;
  188 |   for (const item of session.items) {
  189 |     const question = await f.call('/diagnostics/sessions/' + session.id + '/items/' + item.id);
  190 |     if (question.payload.answerSchema.mode === 'short_answer') {
  191 |       expressions++; await f.call('/diagnostics/sessions/' + session.id + '/responses', { itemId: item.id, disposition: 'answered', elapsedMs: 2000,
  192 |         answer: { questionId: question.payload.question.id, mode: 'short_answer', response: { value: '我先提出判断，再用材料中的具体事实说明依据。' } } });
  193 |     } else await f.call('/diagnostics/sessions/' + session.id + '/responses', { itemId: item.id, disposition: 'skip', elapsedMs: 1000 });
  194 |   }
  195 |   expect(expressions).toBeGreaterThan(0); const report = await f.call('/diagnostics/sessions/' + session.id + '/complete', {});
  196 |   expect(report.pendingReviewCount).toBe(expressions); expect(report.estimates[0].mastery).toBeNull();
  197 |   writeFileSync(join(browserEvidence('knowledge-report'), 'actual-pending-review-report.json'), JSON.stringify(report, null, 2) + '\n');
  198 |   await page.goto('/student/assessment?' + new URLSearchParams({ studentId: f.studentId, subject: 'chinese', session: session.id }));
  199 |   const quant = page.getByRole('region', { name: '本点量化与未知项' }), surface = page.getByRole('region', { name: '本点表面表现' });
  200 |   await expect(quant).toContainText('尚未形成有效估计'); await expect(quant.getByText('0%', { exact: true })).toHaveCount(0);
  201 |   await expect(surface).toContainText('表达待复核 ' + expressions + ' 次'); await surface.locator(':scope > details > summary').click();
  202 |   await expect(surface.getByText('表达待复核', { exact: true })).toHaveCount(expressions);
  203 |   await expect(surface.getByText('本题需要核查', { exact: true })).toHaveCount(0);
  204 | });
  205 | 
  206 | test('knowledge report: a controlled cause timeline remains complete and terminal versus reopened actions stay with their point', async ({ page }) => {
  207 |   const f = await fixture(page);
  208 |   await page.route('**/api/diagnostics/sessions/' + f.session.id + '/report', async route => {
  209 |     const response = await route.fetch(), payload = await response.json();
  210 |     payload.data.hypotheses = f.atomIds.map((atomId, index) => {
  211 |       const original = payload.data.hypotheses.find((row: any) => row.atomId === atomId);
  212 |       return { ...original, status: index ? 'reopened' : 'contradicted', history: Array.from({ length: 9 }, (_, position) => ({
  213 |         at: new Date(Date.UTC(2026, 9, position + 1)).toISOString(), status: position === 8 ? index ? 'reopened' : 'contradicted' : 'testing',
  214 |         reason: '合成状态展示 ' + (position + 1) + ' · 目标' + index,
  215 |       })) };
  216 |     });
  217 |     writeFileSync(join(browserEvidence('knowledge-report'), 'controlled-cause-history-projection.json'), JSON.stringify(payload.data, null, 2) + '\n');
  218 |     await route.fulfill({ response, json: payload });
  219 |   });
  220 |   await page.reload(); const workspace = page.getByRole('region', { name: '知识点工作区' }), cause = workspace.getByRole('region', { name: '本点原因与验证' });
  221 |   await expect(cause).toContainText('已有反证'); await expect(cause.getByRole('button', { name: '做一组题验证原因 ↗', exact: true })).toHaveCount(0);
  222 |   await cause.locator('summary').filter({ hasText: '这条判断怎样变化' }).click(); await expect(cause.locator('.kr-cause-history li')).toHaveCount(9);
  223 |   await expect(cause).toContainText('合成状态展示 1 · 目标0'); await expect(cause).toContainText('合成状态展示 9 · 目标0');
  224 |   const second = f.report.estimates.find((row: any) => row.atomId === f.atomIds[1]);
  225 |   await workspace.getByRole('button', { name: '查看知识点：' + second.atomName, exact: true }).click();
  226 |   await expect(cause).toContainText('需要再次核查'); await expect(cause.getByRole('button', { name: '做一组题验证原因 ↗', exact: true })).toBeEnabled();
  227 |   await expect(cause.getByText('合成状态展示 9 · 目标0', { exact: true })).toHaveCount(0);
  228 | });
  229 | 
  230 | for (const width of [390, 768, 1280, 1440]) test('knowledge report: complete point reading and keyboard controls fit ' + width, async ({ page }) => {
  231 |   await page.setViewportSize({ width, height: 1000 }); const f = await fixture(page), workspace = page.getByRole('region', { name: '知识点工作区' });
  232 |   const target = f.report.estimates[1], button = workspace.getByRole('button', { name: '查看知识点：' + target.atomName, exact: true });
  233 |   await button.focus(); await page.keyboard.press('Enter'); await expect(button).toHaveAttribute('aria-pressed', 'true');
  234 |   expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44);
  235 |   await expect(workspace.getByRole('heading', { name: target.atomName, level: 3, exact: true })).toBeVisible();
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  237 |   const detail = workspace.getByRole('region', { name: '本点表面表现' }); await detail.locator(':scope > details > summary').click();
  238 |   const response = f.report.evidence.find((row: any) => row.atomId === target.atomId), original = await f.call('/diagnostics/students/' + f.studentId + '/evidence/' + response.id);
  239 |   const source = detail.locator('.diagnostic-evidence').first(); await source.locator(':scope > summary').click();
  240 |   await expect(source).toContainText(original.stem); await expect(source.getByRole('heading', { name: '孩子提交的回答', exact: true })).toBeVisible();
  241 |   await page.screenshot({ path: join(browserEvidence('knowledge-report'), 'point-' + width + '.png'), fullPage: true });
  242 | });
  243 | 
  244 | test('knowledge report: a lost reanalysis receipt survives reload with the exact original command', async ({ page }) => {
  245 |   const f = await fixture(page); const requests: unknown[] = [];
  246 |   // Controlled compatibility projection exercises the browser protocol. Real version appends are tested through HTTP.
  247 |   await page.route('**/api/diagnostics/sessions/*/analysis-status', async route => {
  248 |     const response = await route.fetch(), payload = await response.json();
  249 |     payload.data.requiresReanalysis = requests.length < 2; payload.data.canReanalyze = true;
  250 |     payload.data.reasons = ['合成旧方法状态，仅核查浏览器原命令恢复'];
  251 |     await route.fulfill({ response, json: payload });
  252 |   });
  253 |   await page.route('**/api/diagnostics/sessions/*/reanalyze', async route => {
  254 |     requests.push(route.request().postDataJSON());
  255 |     if (requests.length === 1) { await route.fetch(); await route.abort('failed'); }
  256 |     else await route.continue();
  257 |   });
  258 |   const before = await f.call('/diagnostics/sessions/' + f.session.id + '/report-history');
  259 |   await page.reload(); await page.getByRole('button', { name: '按原作答重新分析', exact: true }).click();
  260 |   await expect(page.getByRole('button', { name: '恢复原核对结果', exact: true })).toBeVisible();
  261 |   await page.reload(); await page.getByRole('button', { name: '恢复原核对结果', exact: true }).click();
  262 |   await expect.poll(() => requests.length).toBe(2); expect(requests[1]).toEqual(requests[0]);
> 263 |   await expect(page.getByRole('region', { name: '重新核对报告依据' })).toHaveCount(0);
      |                                                                ^ Error: expect(locator).toHaveCount(expected) failed
  264 |   expect(await f.call('/diagnostics/sessions/' + f.session.id + '/report-history')).toEqual(before);
  265 | });
  266 | 
  267 | test('knowledge report: a version conflict archives its original command before a read-only latest-report check', async ({ page }) => {
  268 |   const f = await fixture(page); let creates = 0, submitted: unknown;
  269 |   await page.route('**/api/diagnostics/sessions/*/analysis-status', async route => {
  270 |     const response = await route.fetch(), payload = await response.json(); payload.data.requiresReanalysis = true; payload.data.canReanalyze = true;
  271 |     await route.fulfill({ response, json: payload });
  272 |   });
  273 |   await page.route('**/api/diagnostics/sessions/*/reanalyze', async route => {
  274 |     creates++; submitted = route.request().postDataJSON();
  275 |     await route.fulfill({ status: 409, json: { error: { message: '合成并发版本冲突，原命令尚未执行' } } });
  276 |   });
  277 |   await page.reload(); await page.getByRole('button', { name: '按原作答重新分析', exact: true }).click();
  278 |   await page.getByRole('button', { name: '保留原操作副本，查看最新报告', exact: true }).click();
  279 |   await expect(page.getByText('本机原核对操作副本（1）', { exact: true })).toBeVisible();
  280 |   expect(creates).toBe(1);
  281 |   await page.getByText('本机原核对操作副本（1）', { exact: true }).click();
  282 |   const downloaded = page.waitForEvent('download'); await page.getByRole('button', { name: '下载原操作副本 1', exact: true }).click();
  283 |   const download = await downloaded, path = await download.path();
  284 |   const raw = JSON.parse(require('node:fs').readFileSync(path!, 'utf8'));
  285 |   expect({ requestKey: raw.requestKey, expectedReportVersion: raw.expectedReportVersion, reason: raw.reason }).toEqual(submitted);
  286 |   await page.reload(); await expect(page.getByText('本机原核对操作副本（1）', { exact: true })).toBeVisible();
  287 |   expect(creates).toBe(1);
  288 | });
  289 | 
  290 | test('knowledge report: unavailable command storage prevents a new mutation while preserving the report', async ({ page }) => {
  291 |   await fixture(page); let creates = 0;
  292 |   await page.addInitScript(() => {
  293 |     const write = Storage.prototype.setItem;
  294 |     Storage.prototype.setItem = function (key, value) {
  295 |       if (key.startsWith('studyagent.report-analysis-command.v1:')) throw new DOMException('Synthetic storage quota', 'QuotaExceededError');
  296 |       return write.call(this, key, value);
  297 |     };
  298 |   });
  299 |   await page.route('**/api/diagnostics/sessions/*/analysis-status', async route => {
  300 |     const response = await route.fetch(), payload = await response.json(); payload.data.requiresReanalysis = true; payload.data.canReanalyze = true;
  301 |     await route.fulfill({ response, json: payload });
  302 |   });
  303 |   await page.route('**/api/diagnostics/sessions/*/reanalyze', route => { creates++; return route.continue(); });
  304 |   await page.reload(); await page.getByRole('button', { name: '按原作答重新分析', exact: true }).click();
  305 |   await expect(page.getByRole('alert').filter({ hasText: 'Synthetic storage quota' })).toBeVisible();
  306 |   await expect(page.getByRole('region', { name: '本点量化与未知项' })).toContainText('尚未形成有效估计');
  307 |   expect(creates).toBe(0);
  308 | });
  309 | 
```