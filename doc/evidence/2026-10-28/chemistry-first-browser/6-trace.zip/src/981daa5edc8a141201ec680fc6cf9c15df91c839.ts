import { expect, test, type Page } from '@playwright/test';
import { mkdirSync } from 'node:fs';

const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
async function fixture(page: Page) {
  const key = `${Date.now()}-${Math.floor(Math.random() * 100000)}`, principal = `chemistry-${key}@local.test`, credential = `Chemistry-${key}`;
  const registration = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
  expect(registration.status).toBe(201); const account = (await registration.json()).data;
  const headers = { 'content-type': 'application/json', authorization: 'Bearer ' + account.token };
  const child = await fetch(api + '/students', { method: 'POST', headers, body: JSON.stringify({ nickname: '九上化学验收', grade: 9, preferredSessionMinutes: 25,
    defaultVersionMap: { math: '', chinese: '', english: '', chemistry: 'guangzhou-pep-chemistry-9-upper-v1' } }) });
  expect(child.status).toBe(201); const studentId = (await child.json()).data.profile.id;
  await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  await page.goto('/chemistry?studentId=' + studentId); await expect(page.getByLabel('化学学习档案', { exact: true })).toHaveValue(studentId);
  const call = async (path: string) => { const response = await fetch(api + path, { headers }); expect(response.status).toBe(200); return (await response.json()).data; };
  return { studentId, call };
}
async function screenshot(page: Page, label: string) {
  const directory = 'data/qa/browser-evidence/chemistry-' + (process.env.E2E_EVIDENCE_RUN ?? 'local'); mkdirSync(directory, { recursive: true });
  await page.screenshot({ path: directory + '/' + label + '.png', fullPage: true });
}

test('chemistry: enrollment, all seven readable units and actual native classroom work on three viewports', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  const { studentId, call } = await fixture(page);
  await expect(page.getByRole('navigation', { name: '化学单元' }).getByRole('button')).toHaveCount(7);
  await expect(page.getByRole('button', { name: '开始课前诊断', exact: true })).toBeDisabled();
  await page.getByText('先看本课讲义', { exact: true }).first().click(); await expect(page.getByText('比较蜡烛熔化与蜡烛燃烧。', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '确认本学期范围并建立课程', exact: true }).click();
  await expect(page.getByText('本学期课程已建立', { exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: '开始课前诊断', exact: true })).toBeEnabled();
  await expect(page.getByRole('button', { name: '开始独立考核', exact: true }).first()).toBeDisabled();
  for (const width of [1440, 768, 390]) {
    await page.setViewportSize({ width, height: 960 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    await screenshot(page, 'course-' + width);
  }
  await page.setViewportSize({ width: 1440, height: 960 });
  await page.getByRole('navigation', { name: '化学单元' }).getByRole('button').last().click();
  await expect(page.getByRole('heading', { name: '燃料、能源与环境', exact: true })).toBeVisible();
  await expect(page.getByRole('heading', { name: '氢能源的反应与定量验证', exact: true })).toBeVisible();
  await page.getByRole('navigation', { name: '化学单元' }).getByRole('button').first().click();
  const before = await call('/chemistry/catalog?studentId=' + studentId);
  await page.reload(); const after = await call('/chemistry/catalog?studentId=' + studentId); expect(after.courseId).toBe(before.courseId);
  await page.getByRole('link', { name: '进入讲解课堂 ↗', exact: true }).first().click(); await expect(page).toHaveURL(/lesson=learn/);
  await expect(page.getByRole('heading', { name: '物理变化与化学变化', exact: true }).first()).toBeVisible();
  await expect(page.getByText('本节课导航', { exact: true }).first()).toBeVisible();
  expect(errors).toEqual([]);
});

test('chemistry: a completed baseline unlocks an independent check and keeps original answers after reopening', async ({ page }) => {
  const { studentId, call } = await fixture(page);
  await page.getByRole('button', { name: '确认本学期范围并建立课程', exact: true }).click();
  await expect(page.getByText('本学期课程已建立', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '开始课前诊断', exact: true }).click();
  await expect(page).toHaveURL(/\/student\/assessment\?.*session=/);
  const baselineId = new URL(page.url()).searchParams.get('session')!;
  const baseline = await call('/diagnostics/sessions/' + baselineId); expect(baseline.items.length).toBe(8);
  for (let index = 0; index < baseline.items.length; index++) {
    await page.getByRole('radio').first().check();
    await page.getByRole('button', { name: '提交，下一步 →', exact: true }).click();
    await expect.poll(async () => (await call('/diagnostics/sessions/' + baselineId)).answeredCount).toBe(index + 1);
  }
  await expect(page.getByRole('heading', { name: '从知识点看清下一步。', exact: true })).toBeVisible();
  const original = await call('/diagnostics/sessions/' + baselineId + '/report'); expect(original.answeredCount).toBe(8);
  await page.goto('/chemistry?studentId=' + studentId);
  await expect(page.getByRole('button', { name: '开始独立考核', exact: true }).first()).toBeEnabled();
  await page.getByRole('button', { name: '开始独立考核', exact: true }).first().click();
  await expect(page).toHaveURL(/\/student\/assessment\?.*session=/);
  const independentId = new URL(page.url()).searchParams.get('session')!;
  const independent = await call('/diagnostics/sessions/' + independentId), exposed = new Set(baseline.items.map((item: any) => item.questionId));
  expect(independent.items.every((item: any) => !exposed.has(item.questionId))).toBe(true);
  await page.goto('/chemistry?studentId=' + studentId); await page.reload();
  const check = (await call('/chemistry/catalog?studentId=' + studentId)).checkpoints.find((check: any) => check.id === 'u1:unit');
  expect(check).toMatchObject({ status: 'in_progress', lastSessionId: independentId });
  expect((await call('/diagnostics/sessions/' + baselineId + '/report')).evidence).toEqual(original.evidence);
});
