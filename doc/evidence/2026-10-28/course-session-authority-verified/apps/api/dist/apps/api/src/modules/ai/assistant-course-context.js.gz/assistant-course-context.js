"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assistantCourseReference = void 0;
exports.courseAssessmentBlock = courseAssessmentBlock;
exports.assertCourseAssessmentAvailable = assertCourseAssessmentAvailable;
exports.resolveCourseTeachingSource = resolveCourseTeachingSource;
exports.courseAssistantContext = courseAssistantContext;
exports.previewAssistantCourse = previewAssistantCourse;
exports.freezeAssistantCourse = freezeAssistantCourse;
exports.readAssistantCourse = readAssistantCourse;
exports.assistantCourseSummary = assistantCourseSummary;
exports.assistantCourseDescriptor = assistantCourseDescriptor;
const common_1 = require("@nestjs/common");
const zod_1 = require("zod");
const source_course_service_1 = require("../learning/source-course.service");
const assistant_turn_record_1 = require("./assistant-turn-record");
const assistant_teaching_content_1 = require("./assistant-teaching-content");
const id = zod_1.z.string().min(1).max(180), kindSchema = zod_1.z.enum(['primary_unit', 'material_lesson']);
const subjectSchema = zod_1.z.enum(['math', 'chinese', 'english']).nullable();
const snapshotSchema = zod_1.z.object({ protocol: zod_1.z.literal('assistant-course-v1'), kind: kindSchema,
    studentId: id.nullable(), subject: subjectSchema, accessMode: zod_1.z.enum(['published', 'authoring']),
    teaching: assistant_teaching_content_1.teachingContentSnapshotSchema, fingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/),
}).strict();
function courseAssessmentBlock(store, studentId, userRole) {
    if (userRole !== 'student' || !studentId)
        return undefined;
    const active = store.select('diagnosticSessions', { studentId, status: ['in_progress', 'paused'] }).at(-1);
    return active ? { code: 'assessment_in_progress', message: '请先保留问题并完成当前评测，再继续课程助教。当前题目仍可使用原题提示。',
        href: '/student/assessment?' + new URLSearchParams({ session: active.id }) } : undefined;
}
function assertCourseAssessmentAvailable(store, studentId, userRole) {
    const block = courseAssessmentBlock(store, studentId, userRole);
    if (block)
        throw new common_1.ConflictException(block);
}
function resolveCourseTeachingSource(store, students, user, kind, courseId, itemId, allowReadOnly = false) {
    const fail = () => { if (!allowReadOnly)
        throw new common_1.ConflictException('这份课程尚未确认、已经归档或撤回，请核对当前教学版本'); return null; };
    if (kind === 'primary_unit') {
        const course = store.find('studioCourses', { id: courseId });
        if (!course)
            throw new common_1.NotFoundException('知识课程不存在');
        students.assertCanAccessStudent(user, course.studentId);
        if (!store.find('students', { id: course.studentId }))
            throw new common_1.NotFoundException('原学习档案已不可用');
        const current = course.status === 'active' || course.status === 'completed';
        let catalog = current ? null : fail();
        if (current)
            try {
                catalog = (0, assistant_teaching_content_1.primaryUnitTeachingCatalog)(course, itemId);
            }
            catch (error) {
                if (!allowReadOnly || !(error instanceof common_1.ConflictException || error instanceof common_1.NotFoundException))
                    throw error;
            }
        return { kind, studentId: course.studentId, subject: course.subject, accessMode: 'published', current: current && catalog !== null, catalog };
    }
    if (kind !== 'material_lesson')
        throw new common_1.BadRequestException('课程上下文类型不支持');
    const course = store.find('sourceCourses', { id: courseId });
    if (!course)
        throw new common_1.NotFoundException('资料课程不存在');
    (0, source_course_service_1.assertSourceCourseAccess)(user, course, students);
    if (course.studentId && !store.find('students', { id: course.studentId }))
        throw new common_1.NotFoundException('原学习档案已不可用');
    const authoring = course.status === 'ready' && !course.confirmedAt && (!course.versioning || course.versioning.state === 'draft');
    const published = course.status === 'active' && Boolean(course.confirmedAt) && (!course.versioning || course.versioning.state === 'published');
    if (authoring && (user.role === 'student' || user.id !== course.ownerUserId))
        throw new common_1.ForbiddenException('待核对教案只能由当前作者打开');
    const current = authoring || published;
    let catalog = current ? null : fail();
    if (current)
        try {
            catalog = (0, assistant_teaching_content_1.materialLessonTeachingCatalog)(course, itemId);
        }
        catch (error) {
            if (!allowReadOnly || !(error instanceof common_1.ConflictException || error instanceof common_1.NotFoundException))
                throw error;
        }
    return { kind, studentId: course.studentId, subject: course.subject, accessMode: authoring ? 'authoring' : 'published', current: current && catalog !== null, catalog };
}
function modelContext(kind, accessMode, teaching) {
    return { independentStudy: undefined, lecture: undefined, course: { kind, accessMode, teaching }, scope: null, report: null, plan: null,
        memory: null, definitionNotice: null, currentQuestion: null, evidenceIds: [], withheldAnswer: undefined, bound: null };
}
function courseAssistantContext(snapshot) { return modelContext(snapshot.kind, snapshot.accessMode, snapshot.teaching); }
function safeCharacters(context) {
    const { withheldAnswer: _answer, bound: _bound, ...safe } = context;
    return JSON.stringify(safe).length;
}
function previewAssistantCourse(source, selection = { mode: 'complete' }) {
    if (!source.current || !source.catalog)
        throw new common_1.ConflictException('原课程已不可继续提问，请核对当前版本');
    const teaching = (0, assistant_teaching_content_1.projectTeachingContent)(source.catalog, selection);
    const safe = { protocol: 'assistant-course-v1', kind: source.kind, studentId: source.studentId, subject: source.subject, accessMode: source.accessMode, teaching };
    const snapshot = snapshotSchema.parse({ ...safe, fingerprint: (0, assistant_turn_record_1.assistantDigest)(safe) });
    return readAssistantCourse(snapshot, (0, exports.assistantCourseReference)(snapshot), teaching.itemId);
}
function freezeAssistantCourse(source, selection = { mode: 'complete' }) {
    const snapshot = previewAssistantCourse(source, selection), size = safeCharacters(courseAssistantContext(snapshot));
    if (size > 18_000)
        throw new common_1.ConflictException({ code: 'teaching_context_over_budget', message: '所选课程上下文过长，请保留问题并选择较少的教学条目',
            maximumCharacters: 18_000, selectedCharacters: size });
    return snapshot;
}
const assistantCourseReference = (snapshot) => snapshot.teaching.courseId + '@' + snapshot.fingerprint;
exports.assistantCourseReference = assistantCourseReference;
function readAssistantCourse(value, referenceId, itemId) {
    const parsed = snapshotSchema.safeParse(value);
    if (!parsed.success)
        throw new common_1.ConflictException('原课程快照缺失或损坏，请保留对话并返回课程');
    const snapshot = parsed.data, { fingerprint, ...safe } = snapshot;
    if ((0, assistant_turn_record_1.assistantDigest)(safe) !== fingerprint || (0, exports.assistantCourseReference)(snapshot) !== referenceId || snapshot.teaching.itemId !== itemId ||
        snapshot.kind === 'primary_unit' && (snapshot.teaching.protocol !== 'primary-unit-v1' || !snapshot.studentId) ||
        snapshot.kind === 'material_lesson' && snapshot.teaching.protocol !== 'material-lesson-v1' ||
        (snapshot.teaching.subject ?? null) !== snapshot.subject || Boolean(snapshot.studentId) !== Boolean(snapshot.subject))
        throw new common_1.ConflictException('原课程身份与教学快照不一致，请保留原对话');
    (0, assistant_teaching_content_1.readTeachingContent)(snapshot.teaching, (0, assistant_teaching_content_1.teachingContentReference)(snapshot.teaching), itemId, null, false);
    return snapshot;
}
function assistantCourseSummary(snapshot, current) {
    const t = snapshot.teaching, params = new URLSearchParams({ course: t.courseId });
    if (snapshot.studentId)
        params.set(snapshot.kind === 'primary_unit' ? 'student' : 'studentId', snapshot.studentId);
    if (snapshot.subject)
        params.set('subject', snapshot.subject);
    if (snapshot.kind === 'primary_unit') {
        params.set('view', 'courses');
        params.set('unit', t.itemId);
    }
    else
        params.set('lesson', t.itemId);
    return { kind: snapshot.kind, courseId: t.courseId, courseTitle: t.courseTitle, itemId: t.itemId, itemTitle: t.itemTitle,
        studentId: snapshot.studentId, subject: snapshot.subject, accessMode: snapshot.accessMode, fingerprint: snapshot.fingerprint,
        referenceId: (0, exports.assistantCourseReference)(snapshot), current, href: (snapshot.kind === 'primary_unit' ? '/studio?' : '/studio/source-courses?') + params,
        selection: t.selection, coverage: t.coverage };
}
function assistantCourseDescriptor(snapshot, source, current) {
    const t = snapshot.teaching, summary = assistantCourseSummary(snapshot, current);
    if (!current || !source?.catalog)
        return { ...summary, targets: t.targets, parts: t.parts.map(({ key, title, targetId }) => ({ key, title, targetId })) };
    const info = (0, assistant_teaching_content_1.describeTeachingContent)(source.catalog), overview = (0, assistant_teaching_content_1.projectTeachingContent)(source.catalog, { mode: 'overview' });
    const overhead = safeCharacters(modelContext(source.kind, source.accessMode, overview)) - JSON.stringify(overview).length;
    const selectedCharacters = safeCharacters(courseAssistantContext(snapshot));
    return { ...summary, targets: info.targets, parts: info.parts.map(p => ({ ...p, selectedCharacters: p.selectedCharacters + overhead })),
        maximumCharacters: 18_000, completeCharacters: info.completeCharacters + overhead, overviewCharacters: info.overviewCharacters + overhead,
        completeFits: info.completeCharacters + overhead <= 18_000, overviewFits: info.overviewCharacters + overhead <= 18_000,
        selectedCharacters, selectionFits: selectedCharacters <= 18_000 };
}
