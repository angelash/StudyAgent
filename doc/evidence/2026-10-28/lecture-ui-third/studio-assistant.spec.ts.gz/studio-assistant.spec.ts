import { test, expect, type Page } from '@playwright/test';
import { mkdirSync, writeFileSync } from 'node:fs';
import { browserEvidence } from './evidence';

const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
const evidence = browserEvidence('studio-assistant');
let address = 0;
async function login(page: Page) {
  const id = crypto.randomUUID(), principal = 'lecture-browser-' + id + '@local.test', credential = 'Lecture-browser-only-' + id;
  const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.15.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  expect(response.status).toBe(201); const actor = (await response.json()).data;
  await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  return actor;
}
async function call(actor: any, path: string, body?: unknown) {
  const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
}
const input = (page: Page) => page.getByLabel('想一起看看什么', { exact: true });
const task = (page: Page) => page.getByRole('region', { name: '提问任务', exact: true });
async function lecture(page: Page, width = 1280) {
  await page.setViewportSize({ width, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  await page.goto('/studio/classroom'); await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/); await expect(input(page)).toBeEnabled(); return actor;
}
async function shot(page: Page, name: string) { if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); await page.evaluate(async () => { await document.fonts.ready; }); await page.screenshot({ path: evidence + '/' + name + '.png', fullPage: true }); } }
test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});

test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  test.setTimeout(90000); await page.setViewportSize({ width: 1280, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); await login(page);
  const classroomPosts: string[] = [], errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  try {
    await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
    await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
    await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
    await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
    await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
    await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
    expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
    await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考'); await expect(input(page)).toBeEnabled();
  } finally {
    if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  }
});

for (const width of [390, 768, 880, 1440]) test(`lecture-assistant: usable course entry, composer and complete model selection at${width}`, async ({ page }) => {
  test.setTimeout(90000); await lecture(page, width);
  await expect(page.getByRole('region', { name: '当前讲座上下文' })).toBeVisible();
  const picker = page.getByRole('combobox', { name: '选择大模型', exact: true }); await expect(picker.locator('option')).toHaveCount(23); await expect(picker).toHaveValue('deepseek-v4-flash');
  await page.getByLabel('模型文字检查说明').click(); await expect(page.getByText('尚未进行文字检查', { exact: true })).toBeVisible();
  await page.getByLabel('模型文字检查说明').click();
  await page.getByRole('button', { name: 'Tools', exact: true }).click(); await expect(page.getByRole('menuitem', { name: /Whiteboard session/ })).toBeVisible();
  await page.keyboard.press('Escape'); await expect(page.getByRole('menu', { name: '' })).toHaveCount(0);
  const layout=await page.evaluate(()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('.input-box,.button-row,.composer-right-group,select[aria-label="选择大模型"],button[aria-label="发送学习问题"]')].map(element=>{const box=element.getBoundingClientRect(),style=getComputedStyle(element);return{selector:element.className,left:box.left,right:box.right,width:box.width,minWidth:style.minWidth,cssWidth:style.width};})}));
  if(!process.env.CI){mkdirSync(evidence,{recursive:true});writeFileSync(evidence+'/entry-'+width+'-layout.json',JSON.stringify(layout,null,2));}
  expect(layout.documentWidth).toBeLessThanOrEqual(width);for(const control of layout.controls){expect(control.left).toBeGreaterThanOrEqual(0);expect(control.right).toBeLessThanOrEqual(width);}
  await shot(page, 'entry-' + width);
});

test('lecture-assistant: lecture removal, back and reload preserve separate unsent drafts without sending', async ({ page }) => {
  test.setTimeout(90000); await lecture(page); const posts: unknown[] = [];
  page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  await input(page).fill('原讲座中尚未发送的匿名草稿。'); const original = page.url();
  await page.getByRole('button', { name: '移除讲座上下文' }).click(); await expect(page).toHaveURL(/audience=independent/);
  await expect(page.getByRole('region', { name: '当前讲座上下文' })).toHaveCount(0); await expect(input(page)).toBeEnabled(); await expect(input(page)).toHaveValue('');
  await input(page).fill('普通独立学习中尚未发送的匿名草稿。');
  await page.goBack(); await expect(page).toHaveURL(original); await expect(input(page)).toHaveValue('原讲座中尚未发送的匿名草稿。');
  await page.goForward(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。'); await page.reload(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。');
  expect(posts).toEqual([]); await shot(page, 'separate-drafts');
});

test('lecture-assistant: durable pending turn resumes after refresh with its original model', async ({ page }) => {
  test.setTimeout(120000); await lecture(page); const posts: any[] = [];
  page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  await input(page).fill('[assistant-pause-once] 请用匿名例子比较本讲的概念。'); await page.getByRole('button', { name: '发送学习问题' }).click(); await expect(task(page)).toBeVisible();
  await page.reload(); await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 });
  expect(posts).toHaveLength(1); expect(posts[0].modelId).toBe('deepseek-v4-flash');
  await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2);
  await page.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6.1-sol'); await expect(task(page)).toContainText('DeepSeek V4.1 Flash');
  await shot(page, 'saved-original-model');
});

test('lecture-assistant: a lost receipt is recovered with the original request and no duplicate post', async ({ page }) => {
  test.setTimeout(120000); await lecture(page); let submitted: any = null, count = 0;const allPosts:any[]=[];
  page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url()))allPosts.push(request.postDataJSON());});
  await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/, async route => {
    if (route.request().method() === 'POST') { count++; submitted = route.request().postDataJSON(); await route.fetch(); await route.abort('failed'); } else await route.continue();
  });
  await input(page).fill('只发送一次的匿名讲座问题。'); await page.getByRole('button', { name: '发送学习问题' }).click();
  await expect(page.getByRole('complementary', { name: '待确认提问' })).toBeVisible();
  expect(submitted.requestKey).toBeTruthy(); await page.unrouteAll({ behavior: 'wait' }); await page.reload();
  await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 }); expect(count).toBe(1);expect(allPosts).toHaveLength(1);expect(allPosts[0].requestKey).toBe(submitted.requestKey);
  await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2); await shot(page, 'recovered-original-request');
});

test('lecture-assistant: a retained original version opens from the server without creating or resending a session', async ({ page }) => {
  test.setTimeout(120000); await page.setViewportSize({ width: 880, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  const original = await call(actor, '/qa/assistant/lecture-history', {}), posts: string[] = [];
  page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(request.url())) posts.push(request.url()); });
  await page.goto(original.href); await expect(page.getByRole('log', { name: '当前学习对话' })).toContainText('LECTURE_OLD_HISTORY_MARKER');
  await expect(input(page)).toBeDisabled(); await expect(page.getByRole('button', { name: '发送学习问题' })).toBeDisabled(); expect(posts).toEqual([]);
  await shot(page, 'retained-original-readonly');
  await page.getByRole('button', { name: '打开当前讲座版本', exact: true }).click(); await expect(input(page)).toBeEnabled();
  await expect(page.locator('.assistant-message').filter({hasText:'LECTURE_OLD_HISTORY_MARKER'})).toHaveCount(0);
  expect(posts.some(url => /\/sessions$/.test(url))).toBe(true); expect(posts.some(url => /\/turns$/.test(url))).toBe(false);
  expect((await call(actor, '/ai/assistant/sessions/' + original.sessionId + '/messages/page')).messages).toHaveLength(2);
});

test('lecture-assistant: failed initialization after a child change cannot retain the previous active session', async ({ page }) => {
  test.setTimeout(120000); const actor = await login(page), children:Array<{id:string}> = [];
  for (const nickname of ['匿名档案甲', '匿名档案乙']) children.push((await call(actor, '/students', { nickname, grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile);
  await page.goto('/studio'); await expect(page.getByRole('combobox', { name: '学习档案', exact: true }).locator('option')).toHaveCount(2);await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[0].id);await expect(page.getByRole('combobox', { name: '学习档案', exact: true })).toHaveValue(children[0].id); await page.getByRole('button', { name: 'Instant Assistance', exact: true }).click();
  await expect(input(page)).toBeEnabled(); await input(page).fill('只属于匿名档案甲的未发送草稿。'); const posts: string[] = [];
  page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.url()); });
  await page.route(/\/ai\/assistant\/sessions$/, async route => {
    if (route.request().method() === 'POST' && route.request().postDataJSON().studentId === children[1].id) await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ data: null, error: { code: 'synthetic_unavailable', message: '匿名上下文初始化暂不可用' }, meta: {} }) });
    else await route.continue();
  });
  await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[1].id); await expect(page.getByText('匿名上下文初始化暂不可用', { exact: true })).toBeVisible();
  await expect(input(page)).toBeDisabled(); expect(posts).toEqual([]);
  await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[0].id); await expect(input(page)).toHaveValue('只属于匿名档案甲的未发送草稿。');
  await page.unrouteAll({ behavior: 'wait' });
});
