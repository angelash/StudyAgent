# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-choice.spec.ts >> an undelivered command survives refresh and reuses its exact request key and choices
- Location: tests\e2e\classroom-choice.spec.ts:50:5

# Error details

```
TimeoutError: locator.fill: Timeout 15000ms exceeded.
Call log:
  - waiting for getByLabel('登录账号')
    - locator resolved to <input disabled value="" required="" minlength="3" maxlength="254" placeholder="账号或邮箱" autocomplete="username"/>
    - fill("classroom-choice-d58288da-e785-4f89-bc2c-3bf35cfbc912@local.test")
  - attempting fill action
    2 × waiting for element to be visible, enabled and editable
      - element is not enabled
    - retrying fill action
    - waiting 20ms
    2 × waiting for element to be visible, enabled and editable
      - element is not enabled
    - retrying fill action
      - waiting 100ms
    29 × waiting for element to be visible, enabled and editable
       - element is not enabled
     - retrying fill action
       - waiting 500ms

```

# Page snapshot

```yaml
- main [ref=e2]:
  - complementary [ref=e3]:
    - link "学 学习观察室" [ref=e4] [cursor=pointer]:
      - /url: /
      - generic [ref=e5]: 学
      - text: 学习观察室
    - generic [ref=e6]:
      - generic [ref=e7]: FAMILY / 每一步，都看得见
      - heading [level=1] [ref=e8]:
        - text: 先看见孩子，
        - emphasis [ref=e9]: 怎样学会。
      - paragraph [ref=e10]: 从一个具体知识点开始，找到卡住的一步，再通过新题和时间，看看是否真的留下来。
    - link "孩子自己来学习？使用学习码进入 ↗" [ref=e11] [cursor=pointer]:
      - /url: /student/login
  - generic [ref=e12]:
    - generic [ref=e13]: 家长与教师入口
    - heading "继续孩子的学习旅程。" [level=2] [ref=e14]
    - paragraph [ref=e15]: 登录后查看孩子的知识证据、指导计划和复测记录。
    - generic [ref=e16]:
      - generic [ref=e17]:
        - text: 登录账号
        - textbox "登录账号" [disabled] [ref=e18]:
          - /placeholder: 账号或邮箱
      - generic [ref=e19]:
        - text: 密码
        - textbox "密码" [disabled] [ref=e20]:
          - /placeholder: 至少 10 个字符
      - button "登录，查看学习记录 →" [disabled] [ref=e21]
    - button "首次使用，创建家长账号" [disabled] [ref=e22]
    - paragraph [ref=e23]: 教师与教研权限由管理员配置。孩子使用家长生成的一次性学习码。
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { browserEvidence } from './evidence';
  3   | 
  4   | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`, evidence = browserEvidence('classroom-choice');
  5   | let address = 0;
  6   | async function login(page: Page) {
  7   |   const suffix = crypto.randomUUID(), principal = 'classroom-choice-' + suffix + '@local.test', credential = 'Choice-QA-' + suffix;
  8   |   const response = await fetch(api + '/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json', 'X-Forwarded-For': '198.18.9.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  9   |   expect(response.status).toBe(201);
  10  |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
> 11  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
      |                                                                   ^ TimeoutError: locator.fill: Timeout 15000ms exceeded.
  12  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  13  | }
  14  | async function open(page: Page, lesson = 'soc-1-1-2') {
  15  |   await page.goto('/studio/classroom?lesson=' + lesson + '&tab=practice');
  16  |   await expect(page.getByRole('button', { name: 'Check →' })).toBeVisible();
  17  | }
  18  | async function multiple(page: Page) {
  19  |   await page.getByRole('button', { name: '第4题', exact: true }).click();
  20  |   await expect(page.getByText('选择所有符合项。本题须选全且不多选。', { exact: true })).toBeVisible();
  21  |   await expect(page.locator('.cl-practice-options input[type=checkbox]')).toHaveCount(5);
  22  | }
  23  | 
  24  | test('single and multiple choices retain drafts, lock original feedback and separate submitted option states', async ({ page }) => {
  25  |   await login(page); await open(page); const url = page.url();
  26  |   const single = page.locator('.cl-practice-options input[type=radio]'); await single.nth(1).check(); await single.nth(2).check(); await expect(single.nth(1)).not.toBeChecked();
  27  |   await multiple(page); const boxes = page.locator('.cl-practice-options input[type=checkbox]');
  28  |   await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled(); await boxes.nth(0).check(); await boxes.nth(2).check(); await boxes.nth(0).uncheck();
  29  |   await expect(page.locator('.cl-choice-selection')).toContainText('3'); await page.reload();
  30  |   await multiple(page); await expect(boxes.nth(2)).toBeChecked(); await expect(boxes.nth(0)).not.toBeChecked();
  31  |   await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(single.nth(2)).toBeChecked();
  32  |   await multiple(page); await page.getByRole('button', { name: 'Check →' }).click();
  33  |   await expect(page.locator('.cl-answer-feedback')).toBeVisible(); await expect(boxes.first()).toBeDisabled();
  34  |   await expect(page.locator('.cl-option-feedback')).toHaveCount(5); await expect(page.locator('.cl-option-feedback').filter({ hasText: /选对|误选/ })).toHaveCount(1);
  35  |   const original = await page.locator('.cl-answer-feedback').innerText(); await page.goto(url); await multiple(page);
  36  |   await expect(boxes.nth(2)).toBeChecked(); await expect(page.locator('.cl-answer-feedback')).toHaveText(original, { useInnerText: true });
  37  | });
  38  | 
  39  | test('lost acknowledgement is resolved by reading the saved first answer without creating another request', async ({ page }) => {
  40  |   await login(page); await open(page); await multiple(page);
  41  |   let sent: Record<string, unknown> | undefined;
  42  |   await page.route('**/api/learning/classroom/sessions/*/answers', async route => { sent = route.request().postDataJSON(); await route.fetch(); await route.abort('failed'); });
  43  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  44  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeEnabled();
  45  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); let extra = 0; page.on('request', request => { if (request.url().endsWith('/answers') && request.method() === 'POST') extra++; });
  46  |   await page.getByRole('button', { name: '读取并恢复原提交' }).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  47  |   expect(extra).toBe(0); expect(sent?.protocol).toBe('classroom-choice-v2'); await page.reload(); await multiple(page); await expect(page.locator('.cl-practice-options input').first()).toBeDisabled();
  48  | });
  49  | 
  50  | test('an undelivered command survives refresh and reuses its exact request key and choices', async ({ page }) => {
  51  |   await login(page); await open(page); await multiple(page); const commands: unknown[] = [];
  52  |   await page.route('**/api/learning/classroom/sessions/*/answers', async route => { commands.push(route.request().postDataJSON()); await route.abort('failed'); });
  53  |   const boxes = page.locator('.cl-practice-options input'); await boxes.nth(0).check(); await boxes.nth(3).check(); await page.getByRole('button', { name: 'Check →' }).click();
  54  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible(); await page.reload();
  55  |   await expect(page.getByRole('button', { name: '读取并恢复原提交' })).toBeVisible(); await expect(page.getByRole('button', { name: 'Check →' })).toBeDisabled();
  56  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); await page.route('**/api/learning/classroom/sessions/*/answers', async route => { commands.push(route.request().postDataJSON()); await route.continue(); });
  57  |   await page.getByRole('button', { name: '读取并恢复原提交' }).click(); await multiple(page); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  58  |   expect(commands).toHaveLength(2); expect(commands[1]).toEqual(commands[0]); await expect(boxes.nth(0)).toBeChecked(); await expect(boxes.nth(3)).toBeChecked();
  59  | });
  60  | 
  61  | test('a definitive rejected submission retains its command copy and permits a new checked selection', async ({ page }) => {
  62  |   await login(page); await open(page); await multiple(page);
  63  |   await page.route('**/api/learning/classroom/sessions/*/answers', route => route.fulfill({status:400,contentType:'application/json',json:{data:null,error:{code:'bad_request',message:'合成明确拒绝'}}}));
  64  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button',{name:'Check →'}).click();
  65  |   await expect(page.getByText(/服务器已明确拒绝原提交/)).toBeVisible(); await expect(page.getByRole('button',{name:'读取并恢复原提交'})).toHaveCount(0);
  66  |   await expect(page.getByRole('button',{name:'下载选择与原提交副本'})).toBeVisible(); await expect(page.locator('.cl-practice-options input').first()).toBeEnabled();
  67  |   await page.unroute('**/api/learning/classroom/sessions/*/answers'); await page.locator('.cl-practice-options input').nth(2).check(); await page.getByRole('button',{name:'Check →'}).click(); await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  68  | });
  69  | 
  70  | test('another account cannot restore prior selections or open its frozen classroom', async ({ page }) => {
  71  |   await login(page); await open(page); const originalUrl=page.url(); await multiple(page); await page.locator('.cl-practice-options input').first().check();
  72  |   await login(page); await open(page); await multiple(page); await expect(page.locator('.cl-practice-options input:checked')).toHaveCount(0);
  73  |   await page.goto(originalUrl); await expect(page.locator('.cl-error')).toContainText('无法访问其他账号的课堂'); await expect(page.locator('.cl-practice-options')).toHaveCount(0);
  74  | });
  75  | 
  76  | test('unit checks expose the new selection mode and retain first feedback after reopening', async ({ page }) => {
  77  |   await login(page); await open(page,'unit-exam:soc-u1'); await expect(page.locator('.cl-practice-options input[type=checkbox]')).toHaveCount(5);
  78  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button',{name:'Check →'}).click(); await expect(page.locator('.cl-option-feedback')).toHaveCount(5);
  79  |   const feedback=await page.locator('.cl-answer-feedback').innerText();await page.reload(); await page.getByRole('button',{name:'第1题',exact:true}).click();await expect(page.locator('.cl-answer-feedback')).toHaveText(feedback,{useInnerText:true});
  80  | });
  81  | 
  82  | test('skip, unknown and actual hints remain separate immutable first-answer facts', async ({ page }) => {
  83  |   await login(page); await open(page);
  84  |   await page.getByRole('button', { name: 'Skip', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已跳过');
  85  |   await page.getByRole('button', { name: '第2题', exact: true }).click(); await page.getByRole('button', { name: '这题我不会' }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已记录不会');
  86  |   await multiple(page); await page.getByRole('button', { name: '先给我一个提示' }).click(); await expect(page.locator('.cl-hint')).toHaveCount(1);
  87  |   await expect(page.locator('.cl-option-feedback')).toHaveCount(0); await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  88  |   await expect(page.locator('.cl-answer-feedback')).toContainText('记为辅助作答'); await expect(page.locator('.cl-option-feedback')).toHaveCount(5);
  89  | });
  90  | 
  91  | test('a complete correct set, assisted wrong answer, skip and unknown produce a usable first-answer review', async ({ page }) => {
  92  |   await login(page); await open(page); await multiple(page);
  93  |   for (const text of ['现行末班车时间压缩','员工协商、组织','方案效果还受到']) await page.locator('.cl-practice-options label').filter({hasText:text}).locator('input').check();
  94  |   await page.getByRole('button', {name:'Check →'}).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');
  95  |   await expect(page.locator('.cl-option-feedback').filter({hasText:'✓ 选对'})).toHaveCount(3); await expect(page.locator('.cl-option-feedback').filter({hasText:'漏选'})).toHaveCount(0);
  96  |   await page.getByRole('button', {name:'第1题',exact:true}).click(); await page.getByRole('button', {name:'Skip',exact:true}).click();
  97  |   await page.getByRole('button', {name:'第2题',exact:true}).click(); await page.getByRole('button', {name:'这题我不会'}).click();
  98  |   await page.getByRole('button', {name:'第3题',exact:true}).click(); await page.getByRole('button', {name:'先给我一个提示'}).click();
  99  |   await page.locator('.cl-practice-options input').first().check(); await page.getByRole('button', {name:'Check →'}).click();
  100 |   await expect(page.getByRole('region', {name:'课堂练习复盘'})).toBeVisible(); await expect(page.locator('.cl-review-counts')).toContainText('独立答对');
  101 |   await expect(page.locator('.cl-review-items')).toContainText('跳过'); await expect(page.locator('.cl-review-items')).toContainText('不会');
  102 |   await page.getByRole('button', {name:'回看全部题目'}).click(); await multiple(page); await expect(page.locator('.cl-answer-feedback')).toContainText('这次区分正确');
  103 | });
  104 | 
  105 | test('keyboard selection stays in the question area and leaves assistant input isolated', async ({ page }) => {
  106 |   await login(page); await open(page); await multiple(page);
  107 |   const area = page.getByLabel('题目作答区域，数字键选择，回车提交'); await area.focus(); await page.keyboard.press('1'); await page.keyboard.press('3');
  108 |   const boxes = page.locator('.cl-practice-options input'); await expect(boxes.nth(0)).toBeChecked(); await expect(boxes.nth(2)).toBeChecked();
  109 |   await page.getByRole('button', { name: '☏ Assistant' }).click();
  110 |   // Actual assistant field is selected by its accessible textbox role, avoiding document shortcuts.
  111 |   const textbox = page.locator('.cl-chat-panel textarea'); await expect(textbox).toBeVisible(); await textbox.fill('1'); await textbox.press('3');
```