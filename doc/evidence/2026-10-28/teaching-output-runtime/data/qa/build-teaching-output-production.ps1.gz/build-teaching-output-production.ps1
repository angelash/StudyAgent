$ErrorActionPreference='Stop'
$qaLatest=Get-Content -Raw -LiteralPath 'data/qa/teaching-output-release-latest.json' | ConvertFrom-Json
$qaRelease=Join-Path (Get-Location).Path $qaLatest.folder
if(-not (Test-Path -LiteralPath (Join-Path $qaRelease 'backup-verified.json')) -or -not (Test-Path -LiteralPath (Join-Path $qaRelease 'deployment-target.json'))){throw 'Actual stopped consistent backup and delivery target required'}
$qaLog='data/qa/teaching-output-production-build.log'
if(Test-Path -LiteralPath $qaLog){throw 'Preserve original production build log'}
npm run build --workspace @study-agent/api *> $qaLog
if($LASTEXITCODE -ne 0){Get-Content -LiteralPath $qaLog -Tail 35;throw 'Actual API build failed'}
npm run build --workspace @study-agent/web *>> $qaLog
if($LASTEXITCODE -ne 0){Get-Content -LiteralPath $qaLog -Tail 35;throw 'Actual Web build failed'}
Get-Content -LiteralPath $qaLog -Tail 28
