// Reversible compiled-runtime rollback only. Keeps the current database and every protected configuration byte.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=process.cwd(),read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const latest=read(path.join(root,'data/qa/teaching-output-release-latest.json')),release=path.resolve(root,latest.folder),base=path.join(root,'output/daemon/release-backups');
if(!release.startsWith(base+path.sep)||fs.realpathSync(release).toLowerCase()!==release.toLowerCase())throw Error('Owned rollback folder required');
const before=read(path.join(release,'deployment-before.json')),files=read(path.join(release,'build-files.json'));
const names=['study-agent-health','study-agent-web','study-agent-api'],dirs=['apps/api/dist','apps/web/.next','packages/contracts/dist','packages/config/dist'];
const pm=args=>execFileSync(process.env.ComSpec||'cmd.exe',['/d','/s','/c','pm2 '+args],{encoding:'utf8',windowsHide:true,maxBuffer:10*1024*1024});
function configuration(){for(const [n,h] of Object.entries(before.protectedFiles))if(sha(path.join(root,n))!==h)throw Error('Configuration changed; preserve it and inspect '+n);if(sha(path.join(root,'.env'))!==sha(path.join(release,'config/.env')))throw Error('Private environment changed; preserve it and inspect');}
function guardians(){const rows=JSON.parse(pm('jlist')).filter(x=>names.includes(x.name));if(rows.length!==3||rows.some(x=>path.resolve(x.pm2_env.pm_cwd).toLowerCase()!==root.toLowerCase()))throw Error('Unexpected process ownership');return rows;}
function owned(p,parent){const q=path.resolve(p);if(!q.startsWith(parent+path.sep)||fs.existsSync(q)&&fs.realpathSync(q).toLowerCase()!==q.toLowerCase())throw Error('Unsafe or linked compiled target');return q;}
(async()=>{configuration();guardians();if(files.length!==1034||before.oldWebBuildId!=='NkfAGfS0FLw-vibTZyptB'||before.status!=='prepared-no-database-backup-yet')throw Error('Exact140 original rollback inventory required');
for(const row of files)if(sha(owned(path.join(release,'build',row.path),release))!==row.sha256)throw Error('Rollback original differs: '+row.path);
if(process.argv.includes('--verify-only')){console.log(JSON.stringify({passed:true,scope:'Rollback originals, private config and process ownership only; no runtime mutation',files:files.length}));return;}
if(!fs.existsSync(path.join(release,'backup-verified.json'))||!fs.existsSync(path.join(release,'deployment-target.json')))throw Error('No actual141 transition has occurred');
const held=owned(path.join(release,'failed-141-compiled-'+Date.now()),release);fs.mkdirSync(held,{recursive:false});const moves=[];
for(const name of names){pm('stop '+name);for(let i=0;i<4;i++){const row=guardians().find(x=>x.name===name);if(!row.pid&&row.pm2_env.status==='stopped')break;if(i===3)throw Error('Guardian did not stop');await new Promise(resolve=>setTimeout(resolve,250));pm('stop '+name);}}
if(guardians().some(x=>x.pid||x.pm2_env.status!=='stopped'))throw Error('Services still active');configuration();
for(const dir of dirs){const target=owned(path.join(root,dir),root),saved=owned(path.join(held,dir),held),from=owned(path.join(release,'build',dir),release);fs.mkdirSync(path.dirname(saved),{recursive:true});if(fs.existsSync(target))fs.renameSync(target,saved);fs.cpSync(from,target,{recursive:true,force:false,errorOnExist:true});moves.push({dir,failedCopy:path.relative(release,saved).replaceAll('\\','/')});}
for(const row of files)if(sha(path.join(root,row.path))!==row.sha256)throw Error('Restored compiled byte mismatch: '+row.path);configuration();
fs.writeFileSync(path.join(held,'receipt.json'),JSON.stringify({at:new Date().toISOString(),status:'compiled140-restored-services-stopped',oldBuildId:before.oldWebBuildId,files:files.length,moves,databaseRestored:false,configurationRestored:false,scope:'The failed compiled outputs are retained. Existing schema21 database and protected configuration remain intact; this is not a database downgrade or Git revision rollback.'},null,2)+'\n',{flag:'wx'});
pm('startOrReload ecosystem.config.cjs --update-env');pm('save');console.log(JSON.stringify({passed:true,status:'compiled140-restored-and-guardians-started',files:files.length,evidence:path.relative(root,held),databaseRestored:false,requiresFreshHttpAndStablePidVerification:true}));
})().catch(e=>{console.error(e.message);process.exitCode=1});
