const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const root=process.cwd(),source='F:\\workspace\\github\\StudyAgent-lecture-integration';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const latest=read(path.join(root,'data/qa/teaching-output-release-latest.json')),release=path.resolve(root,latest.folder),candidate=read(path.join(release,'candidate.json')),before=read(path.join(release,'deployment-before.json'));
if(!release.startsWith(path.join(root,'output/daemon/release-backups')+path.sep)||candidate.applicationRevision!=='ef7466b508847dd70320cf2bd8521574789b1cdb')throw Error('Exact141 owned release required');
execFileSync('git',['merge-base','--is-ancestor',candidate.head,'HEAD'],{cwd:root});
const protectedNames=new Set(Object.keys(before.protectedFiles));
for(const[file,expected]of Object.entries(before.protectedFiles))if(sha(fs.readFileSync(path.join(root,file)))!==expected)throw Error('Protected file changed: '+file);
if(sha(fs.readFileSync(path.join(root,'.env')))!==sha(fs.readFileSync(path.join(release,'config/.env'))))throw Error('Private environment changed');
const input=read(path.join(source,'data/qa/teaching-output-full-browser-inputs.json')),checks=[];
if(input.revision!==candidate.head||Object.keys(input.files).length!==4454)throw Error('Fixed141 source inputs required');
for(const[file,expected]of Object.entries(input.files)){
 if(file.includes('/dist/')||protectedNames.has(file)||!['apps/api/src/','apps/web/app/','apps/web/components/','apps/web/lib/','packages/contracts/src/','packages/config/src/','scripts/qa/','scripts/architecture/','scripts/operations/','scripts/processing/','tests/e2e/'].some(prefix=>file.startsWith(prefix)))continue;
 const from=path.resolve(source,file),to=path.resolve(root,file);
 if(!from.startsWith(source+path.sep)||!to.startsWith(root+path.sep)||fs.lstatSync(from).isSymbolicLink()||fs.lstatSync(to).isSymbolicLink())throw Error('Unsafe source path');
 const original=fs.readFileSync(from),actual=fs.readFileSync(to);
 if(sha(original)!==expected||original.toString('utf8').replace(/\r\n/g,'\n')!==actual.toString('utf8').replace(/\r\n/g,'\n'))throw Error('Source differs beyond line endings: '+file);
 checks.push({file,sha256:expected,rawAlreadyMatched:sha(actual)===expected});
}
// All files are proved equal after newline normalization before any copy occurs.
for(const row of checks){if(!row.rawAlreadyMatched)fs.copyFileSync(path.join(source,row.file),path.join(root,row.file));if(sha(fs.readFileSync(path.join(root,row.file)))!==row.sha256)throw Error('Raw source alignment failed');}
const target=path.join(root,'data/qa/teaching-output-production-source-alignment.json');
fs.writeFileSync(target,JSON.stringify({at:new Date().toISOString(),passed:true,head:candidate.head,sourceInputs:checks.length,protectedConfigurationExcluded:[...protectedNames],files:checks},null,2)+'\n',{flag:'wx'});
const paths=path.join(root,'data/qa/teaching-output-aligned-paths.nul');fs.writeFileSync(paths,checks.map(row=>row.file).join('\0')+'\0');
execFileSync('git',['add','--renormalize','--pathspec-from-file='+paths,'--pathspec-file-nul'],{cwd:root,env:{...process.env,GIT_LITERAL_PATHSPECS:'1'},windowsHide:true});
if(execFileSync('git',['diff','--cached','--name-only'],{cwd:root,encoding:'utf8'}).trim())throw Error('Unexpected staged source after newline-only refresh');
console.log(JSON.stringify({passed:true,files:checks.length,aligned:checks.filter(row=>!row.rawAlreadyMatched).length,protectedFilesPreserved:5}));
