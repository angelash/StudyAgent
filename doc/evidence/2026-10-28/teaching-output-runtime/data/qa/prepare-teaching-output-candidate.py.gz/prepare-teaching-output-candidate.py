import hashlib,json,subprocess,gzip
from pathlib import Path
from datetime import datetime,timezone
root=Path.cwd();source=Path(r'F:\workspace\github\StudyAgent-lecture-integration')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head='53520212ddf5ed96c4af3cc9bbc275356725d9a8'
latest=load(root/'data/qa/teaching-output-release-latest.json');release=root/latest['folder']
assert release.resolve().is_relative_to((root/'output/daemon/release-backups').resolve())
api=load(source/'doc/evidence/2026-10-28/teaching-output-full-api-second/receipt.json')
assert api['passed'] and api['passedTests']==1614 and api['failedTests']==0 and api['environmentSkipped']==65 and api['beforeAfterRawShaUnchanged']
local=load(source/'doc/evidence/2026-10-28/teaching-output-full-browser/receipt.json')
ci=load(source/'doc/evidence/2026-10-28/teaching-output-exact-ci/receipt.json')
assert local['passed'] and ci['passed'] and local['head']==ci['head']==head
assert local['originalAttempts']==433 and local['retries']==0 and local['beforeAfterShaUnchanged']
assert ci['browser']['originalAttempts']==433 and ci['browser']['retries']==0
terminal=json.loads(subprocess.check_output(['gh','run','view',str(ci['ciRun']),'--json','status,conclusion,headSha,jobs']))
assert terminal['headSha']==head and terminal['status']=='completed' and terminal['conclusion']=='success' and len(terminal['jobs'])==3 and all(j['status']=='completed' and j['conclusion']=='success' for j in terminal['jobs'])
old=load(root/load(root/'data/qa/lecture-assistant-release-latest.json')['folder']/'candidate.json')
inputs=load(source/'data/qa/teaching-output-full-browser-inputs.json');assert inputs['revision']==head and len(inputs['files'])==4454
compiled={f:h for f,h in inputs['files'].items() if f.startswith(('apps/api/dist/','packages/contracts/dist/','packages/config/dist/'))};assert len(compiled)==374
for f,h in compiled.items():assert sha(source/f)==h,f
artifact='doc/evidence/2026-10-28/teaching-output-exact-ci/source-course-full-browser.json.gz'
raw=gzip.decompress((source/artifact).read_bytes());remote=json.loads(raw);assert remote['stats']['expected']==433 and all(remote['stats'][key]==0 for key in ['unexpected','flaky','skipped'])
live_artifact='doc/evidence/2026-10-28/teaching-output-live/data/qa/teaching-output-live-first/receipt.json.gz'
live_raw=gzip.decompress((source/live_artifact).read_bytes());live=json.loads(live_raw);assert live['passed'] and len(live['cases'])==2 and all(case['status']=='passed' for case in live['cases'])
opus_artifact='doc/evidence/2026-10-28/lecture-opus-recheck-first/receipt.json.gz'
opus_raw=gzip.decompress((source/opus_artifact).read_bytes());opus=json.loads(opus_raw)
assert opus['status']=='complete' and not opus['passed'] and opus['modelCount']==1
assert opus['models'][0]['id']=='claude-opus-5' and opus['models'][0]['status']=='failed'
assert len([a for a in opus['models'][0]['attempts'] if a['status']=='started'])==2
public=root/'resources/ai/model-qualification.json';from_public=source/'resources/ai/model-qualification.json'
assert load(public)==load(from_public)
assert public.read_text(encoding='utf-8-sig').replace('\r\n','\n')==from_public.read_text(encoding='utf-8-sig').replace('\r\n','\n')
subprocess.check_call(['git','diff','--quiet','ab83ecd97d9e1a278190a8e3ee00d3a9f6684da2',head,'--','resources/ai/model-qualification.json'])
fingerprints=json.loads(subprocess.check_output(['node','-e',"const c=require('./apps/api/dist/apps/api/src/modules/learning/classroom-curriculum.js').classroomCourse(),h=require('./apps/api/dist/apps/api/src/modules/ai/assistant-lecture-context.js');console.log(JSON.stringify(Object.fromEntries(c.units.flatMap(u=>u.lectures.map(l=>[l.id,h.freezeAssistantLecture(c.id,l.id).fingerprint])))));"],cwd=source,text=True));assert len(fingerprints)==15
candidate={key:old[key] for key in ['realModelsPassed','realModelsFailed','allModelsPassed','modelArtifact','modelArtifactSha256','originalModelsSha256']}
candidate.update({'at':datetime.now(timezone.utc).isoformat(),'status':'ready-for-release','head':head,'ciHead':head,'ciRun':ci['ciRun'],'deliveryHead':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'applicationRevision':'ef7466b508847dd70320cf2bd8521574789b1cdb','apiRevision':subprocess.check_output(['git','-C',str(source),'rev-parse','ef7466b'],text=True).strip(),'schemaVersion':21,'previousSchemaVersion':21,'compiledCount':len(compiled),'compiledSha256':compiled,'formatOnlyCompiledDifferences':[],'apiLocalPassed':1614,'apiLocalFailed':0,'apiEnvironmentSkipped':65,'localBrowserCases':433,'remoteBrowserCases':433,'verifiedZeroRetries':True,'localZeroRetries':True,'browserArtifact':artifact,'browserArtifactSha256':sha(source/artifact),'originalBrowserSha256':hashlib.sha256(raw).hexdigest(),'inputReceipt':'doc/evidence/2026-10-28/teaching-output-full-browser/receipt.json','inputReceiptSha256':sha(source/'doc/evidence/2026-10-28/teaching-output-full-browser/receipt.json'),'newRealModelCalls':2,'lectureAssistantCliStarts':2,'failedOpusRecheckCliStarts':0,'inheritedFailedOpusRecheckCliStarts':2,'newRealDefaultSamples':2,'opusRecheckArtifact':opus_artifact,'opusRecheckArtifactSha256':sha(source/opus_artifact),'opusRecheckOriginalSha256':hashlib.sha256(opus_raw).hexdigest(),'realDefaultModelArtifact':live_artifact,'realDefaultModelArtifactSha256':sha(source/live_artifact),'realDefaultModelOriginalSha256':hashlib.sha256(live_raw).hexdigest(),'lectureFingerprints':fingerprints,'publicQualificationSha256':sha(public),'publicReceiptLineEndingScope':{'unchangedGitContent':True,'semanticEquality':True,'sourceRawSha256':sha(from_public),'currentProductionRawSha256':sha(public),'rawEqual':sha(from_public)==sha(public)},'realModelsScope':'Inherited original anonymous138 text matrix21/22.141 adds two fully verified default teaching-policy samples. Inherited140 Opus5 recheck failed through two CLI starts; original full matrix was not changed or requalified. Teacher/visual/upstream physical identity not claimed.'})
with (release/'candidate.json').open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(candidate,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:candidate[key] for key in ['status','head','deliveryHead','ciRun','compiledCount','schemaVersion','newRealDefaultSamples']}))
