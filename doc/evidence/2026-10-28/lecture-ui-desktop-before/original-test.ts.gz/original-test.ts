import { test, expect, type Page } from '@playwright/test';
import { mkdirSync, writeFileSync } from 'node:fs';
import { browserEvidence } from './evidence';

const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
const evidence = browserEvidence('studio-assistant');
async function login(page: Page) {
  const id = crypto.randomUUID(), principal = 'lecture-browser-' + id + '@local.test', credential = 'Lecture-browser-only-' + id;
  const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
  expect(response.status).toBe(201); const actor = (await response.json()).data;
  await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  return actor;
}

test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  test.setTimeout(90000); await page.setViewportSize({ width: 1280, height: 887 }); await login(page);
  const classroomPosts: string[] = [], errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  try {
    await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
    await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
    await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
    await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
    await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
    await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
    expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
    await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  } finally {
    if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  }
});
