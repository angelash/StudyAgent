# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio-assistant.spec.ts >> lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson
- Location: tests\e2e\studio-assistant.spec.ts:16:5

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/studio\?[^#]*mode=instant/
Received string:  "http://localhost:3107/studio/classroom?lesson=soc-1-1-1&session=classroom_9d5955f7-a9a9-42eb-9fc6-b7c4139b8b27&tab=history&help=1"
Timeout: 15000ms

Call log:
  - Expect "toHaveURL" with timeout 15000ms
    33 × locator resolved to <html lang="zh-CN">…</html>
       - unexpected value "http://localhost:3107/studio/classroom?lesson=soc-1-1-1&session=classroom_9d5955f7-a9a9-42eb-9fc6-b7c4139b8b27&tab=history&help=1"

```

```yaml
- alert
- main:
  - region "教学白板":
    - button "离开课堂"
    - button "社会学想象力 断点已同步": 社会学想象力
    - button "缩小白板": −
    - button "重置缩放": 100%
    - button "放大白板": ＋
    - button "上一页白板" [disabled]: ‹
    - text: 1 / 1
    - button "下一页白板" [disabled]: ›
    - button "补一张讲解图" [disabled]: 配图
    - button "导出课堂笔记"
    - button "课堂设置"
    - button "切换对话面板"
    - text: WELCOME TO YOUR WHITEBOARD
    - heading "社会学想象力" [level=1]
    - paragraph: 能在新情境中区分关于“社会学想象力”的解释，并指出需要进一步核查的证据。
    - button "▶ 开始学习"
    - text: 概念 · 生活案例 · 误区辨析 · 新情境检查
    - button "开启讲解声音" [disabled]
    - paragraph: 准备好后，点击 ▶ 开始。
  - separator "调整对话面板宽度"
  - complementary:
    - text: Chat history
    - button "隐藏对话面板"
    - tablist "课堂内容":
      - tab "讲解与插问" [selected]
      - tab "课堂练习"
      - tab "单元项目"
    - text: SESSION OUTLINE
    - heading "社会学想象力" [level=2]
    - paragraph: 能在新情境中区分关于“社会学想象力”的解释，并指出需要进一步核查的证据。
    - list:
      - listitem: 本节课导航
      - listitem: 社会学想象力
      - listitem: 先看问题的规模
      - listitem: 把概念放进生活
      - listitem: 行动仍然有位置
      - listitem: 一个常见的误区
      - listitem: 停下来，检查理解
      - listitem: 带到一个新情境
    - status: ••• Paused
    - button "‹ 上一步" [disabled]
    - text: 1 / 8
    - button "下一步 ›"
    - group "调整讲法":
      - button "提问" [pressed]
      - button "换个例子"
      - button "说简单点"
      - button "补先修"
      - button "比较讲法"
    - textbox "向课堂老师提问":
      - /placeholder: Ask a question…
      - text: 我正在学习“社会学想象力”，请围绕“能在新情境中区分关于“社会学想象力”的解释，并指出需要进一步核查的证据。”帮我梳理，并用一个新情境检查我的理解。
    - button "语音提问": ♩
    - button "继续讲解": ▷
    - button "发送课堂问题": ↑
    - combobox "选择大模型":
      - option "Auto · 平台默认 DeepSeek V4.1 Flash"
    - text: 尚未进行文字检查
  - dialog "课堂新手引导":
    - button "跳过": × 跳过
    - heading "欢迎来到白板课堂" [level=2]
    - paragraph: 用七个常用控件，按自己的节奏听讲、插问和回顾。随时可以从设置重新打开导览。
    - button "开始导览"
    - button "我已了解，跳过"
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { mkdirSync, writeFileSync } from 'node:fs';
  3  | import { browserEvidence } from './evidence';
  4  | 
  5  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  6  | const evidence = browserEvidence('studio-assistant');
  7  | async function login(page: Page) {
  8  |   const id = crypto.randomUUID(), principal = 'lecture-browser-' + id + '@local.test', credential = 'Lecture-browser-only-' + id;
  9  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
  10 |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  11 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  13 |   return actor;
  14 | }
  15 | 
  16 | test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  17 |   test.setTimeout(90000); await page.setViewportSize({ width: 1280, height: 887 }); await login(page);
  18 |   const classroomPosts: string[] = [], errors: string[] = [];
  19 |   page.on('pageerror', error => errors.push(error.message));
  20 |   page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  21 |   try {
  22 |     await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  23 |     await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
> 24 |     await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
     |                        ^ Error: expect(page).toHaveURL(expected) failed
  25 |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  26 |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
  27 |     await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
  28 |     expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
  29 |     await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  30 |   } finally {
  31 |     if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  32 |   }
  33 | });
  34 | 
```