# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: learning-home.spec.ts >> a student resumes the exact saved assessment and sees only their profile
- Location: tests\e2e\learning-home.spec.ts:118:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { mkdirSync } from 'node:fs';
  3   | 
  4   | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  5   | async function account(page: Page, children = 0) {
  6   |   const key = `${Date.now()}-${Math.floor(Math.random() * 100000)}`, principal = `home-${key}@local.test`, credential = `Home-browser-${key}`;
  7   |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
> 8   |   expect(response.status).toBe(201); const { data } = await response.json();
      |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  9   |   const headers = { 'content-type': 'application/json', authorization: 'Bearer ' + data.token };
  10  |   const profiles: Array<{ id: string; nickname: string }> = [];
  11  |   for (let i = 0; i < children; i++) {
  12  |     const created = await fetch(api + '/students', { method: 'POST', headers, body: JSON.stringify({ nickname: `首页孩子${i + 1}`, grade: 5,
  13  |       preferredSessionMinutes: 15, defaultVersionMap: { math: 'common', chinese: 'common', english: 'common' } }) });
  14  |     expect(created.status).toBe(201); profiles.push((await created.json()).data.profile);
  15  |   }
  16  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  17  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click();
  18  |   await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  19  |   await expect(page.getByRole('region', { name: '下一步学习' })).toBeVisible();
  20  |   return { headers, profiles };
  21  | }
  22  | 
  23  | test('learning home offers clear entry and works on phone, tablet and desktop', async ({ page }) => {
  24  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  25  |   for (const width of [390, 768, 1440]) {
  26  |     await page.setViewportSize({ width, height: 900 }); await page.goto('/learn');
  27  |     await expect(page.getByRole('link', { name: '孩子使用学习码进入 →' })).toBeVisible();
  28  |     await expect(page.getByRole('link', { name: '家长 / 教师登录 →' })).toBeVisible();
  29  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  30  |   }
  31  |   expect(errors).toEqual([]);
  32  | });
  33  | 
  34  | test('adult can enter a course without creating a child and restore its classroom', async ({ page }) => {
  35  |   await account(page);
  36  |   await expect(page.getByRole('heading', { name: '为孩子建立一份学习档案' })).toBeVisible();
  37  |   await page.locator('.learn-next').getByRole('link', { name: '浏览课程' }).click();
  38  |   await expect(page).toHaveURL(/view=courses/);
  39  |   await expect(page.getByRole('heading', { name: '我的课程', exact: true })).toBeVisible();
  40  |   await page.goto('/studio/classroom?lesson=soc-1-1-1');
  41  |   await expect(page.locator('.cl-room')).toBeVisible();
  42  |   await page.goto('/learn');
  43  |   await expect(page.locator('.learn-next').getByRole('heading')).toContainText('继续学习');
  44  |   await expect(page.locator('.learn-next a')).toHaveAttribute('href', /lesson=soc-1-1-1/);
  45  | });
  46  | 
  47  | test('parent selection, navigation, refresh, history and invalid profile recovery keep context', async ({ page }) => {
  48  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  49  |   const { profiles } = await account(page, 2);
  50  |   await page.getByLabel('当前学习档案').selectOption(profiles[1].id);
  51  |   await page.getByLabel('当前学习学科').selectOption('english');
  52  |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的英语');
  53  |   await expect(page).toHaveURL(new RegExp(`student=${profiles[1].id}`));
  54  |   await page.reload(); await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的英语');
  55  |   await page.getByLabel('当前学习学科').selectOption('chinese');
  56  |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的语文');
  57  |   await page.goBack(); await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的英语');
  58  |   await page.goForward(); await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的语文');
  59  |   await page.getByRole('navigation', { name: '主要导航' }).getByRole('link', { name: '今日学习', exact: true }).click();
  60  |   await expect(page).toHaveURL(new RegExp(`studentId=${profiles[1].id}.*subject=chinese|subject=chinese.*studentId=${profiles[1].id}`));
  61  |   await page.getByRole('navigation', { name: '主要导航' }).getByRole('link', { name: '学习首页', exact: true }).click();
  62  |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的语文');
  63  |   await page.goto('/learn?student=unavailable-profile&subject=english');
  64  |   await expect(page.locator('.learn-error[role="alert"]')).toContainText('这次没有取回学习安排');
  65  |   await expect(page.locator('.learn-next')).toHaveCount(0);
  66  |   await page.getByRole('button', { name: '重新选择可用档案' }).click();
  67  |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子1的数学');
  68  |   for (const width of [1440, 768, 390]) {
  69  |     await page.setViewportSize({ width, height: 900 });
  70  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  71  |   }
  72  |   if (process.env.E2E_HOME_SNAPSHOT === '1') {
  73  |     mkdirSync('data/qa/experience-home', { recursive: true });
  74  |     await page.screenshot({ path: 'data/qa/experience-home/phone.png', fullPage: true });
  75  |     await page.setViewportSize({ width: 1440, height: 900 }); await page.screenshot({ path: 'data/qa/experience-home/desktop.png', fullPage: true });
  76  |   }
  77  |   await page.getByRole('button', { name: '退出', exact: true }).click();
  78  |   await expect(page).toHaveURL(/\/parent\/login$/);
  79  |   expect(await page.evaluate(() => sessionStorage.getItem('study_agent_learning_context_v1'))).toBeNull();
  80  |   expect(errors).toEqual([]);
  81  | });
  82  | 
  83  | test('a delayed old selection and a failed request cannot replace the current child', async ({ page }) => {
  84  |   const { profiles } = await account(page, 2);
  85  |   let release!: () => void, captured!: () => void;
  86  |   const held = new Promise<void>(resolve => { release = resolve; });
  87  |   const started = new Promise<void>(resolve => { captured = resolve; });
  88  |   await page.route('**/api/learning/home?**', async route => {
  89  |     const url = new URL(route.request().url());
  90  |     if (url.searchParams.get('studentId') === profiles[0].id && url.searchParams.get('subject') === 'english') {
  91  |       const response = await route.fetch(); captured(); await held;
  92  |       await route.fulfill({ response }).catch(() => { /* Aborted old fetch is the expected safe outcome. */ });
  93  |     } else await route.continue();
  94  |   });
  95  |   await page.getByLabel('当前学习学科').selectOption('english'); await started;
  96  |   await page.getByLabel('当前学习档案').selectOption(profiles[1].id);
  97  |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的英语');
  98  |   release();
  99  |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的英语');
  100 |   await page.unroute('**/api/learning/home?**');
  101 |   await page.route('**/api/learning/home?**', route => route.abort('failed'));
  102 |   await page.getByLabel('当前学习学科').selectOption('chinese');
  103 |   await expect(page.locator('.learn-error')).toContainText('暂时无法连接学习服务');
  104 |   await expect(page.locator('.learn-next')).toHaveCount(0);
  105 |   await page.unroute('**/api/learning/home?**'); await page.getByRole('button', { name: '重新读取' }).click();
  106 |   await expect(page.locator('.learn-scope strong')).toHaveText('首页孩子2的语文');
  107 | });
  108 | 
```