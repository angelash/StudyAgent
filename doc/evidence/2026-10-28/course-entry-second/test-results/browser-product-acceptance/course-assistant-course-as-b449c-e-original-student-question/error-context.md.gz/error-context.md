# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-assistant.spec.ts >> course assistant: real assessment beginning after entry blocks a new model command and preserves the original student question
- Location: tests\e2e\course-assistant.spec.ts:173:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '重新核对课程', exact: true })
    - locator resolved to <button>重新核对课程</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
  - element was detached from the DOM, retrying

```

# Page snapshot

```yaml
- generic [active] [ref=f5e1]:
  - alert [ref=f5e2]
  - main [ref=f5e3]:
    - complementary "学习工作台导航" [ref=f5e4]:
      - generic [ref=f5e5]:
        - generic [ref=f5e6]:
          - link "StudyAgent 学习工作台" [ref=f5e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f5e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f5e11] [cursor=pointer]
        - generic [ref=f5e14]:
          - navigation "工作台主要入口" [ref=f5e15]:
            - button "Home" [ref=f5e16] [cursor=pointer]:
              - generic [ref=f5e19]: 首页
            - button "Courses" [ref=f5e20] [cursor=pointer]:
              - generic [ref=f5e23]: 课程
            - button "Calendar" [ref=f5e24] [cursor=pointer]:
              - generic [ref=f5e27]: 学习动态
            - button "History" [ref=f5e28] [cursor=pointer]:
              - generic [ref=f5e31]: 历史
            - button "Materials" [ref=f5e32] [cursor=pointer]:
              - generic [ref=f5e35]: 资料
            - link "AI Whiteboards" [ref=f5e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f5e39]: AI白板
          - button "＋ 创建课程" [ref=f5e40] [cursor=pointer]
          - generic [ref=f5e41]:
            - region "开始学习" [ref=f5e42]:
              - heading "开始学习" [level=3] [ref=f5e44]
              - link "打开课程 从一节适合自己的课开始。" [ref=f5e45] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f5e46]: 打开课程
                - generic [ref=f5e47]: 从一节适合自己的课开始。
            - generic [ref=f5e48]:
              - heading "近期活动" [level=3] [ref=f5e50]
              - paragraph [ref=f5e52]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f5e54] [cursor=pointer]:
          - /url: /learn?subject=math&student=student_4494ce3e-d9d9-47e0-b388-9e9173bde10a
          - text: 返回学习首页 →
    - generic [ref=f5e55]:
      - generic [ref=f5e56]:
        - generic [ref=f5e57]:
          - combobox "学习档案" [ref=f5e58]:
            - option "匿名课程学习者" [selected]
          - combobox "学科" [ref=f5e59]:
            - option "数学" [selected]
            - option "语文"
            - option "英语"
        - generic [ref=f5e60]:
          - link "教学课堂 ↗" [ref=f5e61] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f5e62] [cursor=pointer]:
            - /url: /
      - generic [ref=f5e63]:
        - generic [ref=f5e64]:
          - button "Craft Courses" [ref=f5e65] [cursor=pointer]
          - button "Instant Assistance" [ref=f5e66] [cursor=pointer]
        - generic [ref=f5e67]:
          - heading "Time for flashcards?" [level=1] [ref=f5e69]
          - region "课程学习助教" [ref=f5e70]:
            - generic [ref=f5e71]:
              - button "查找历史" [ref=f5e73] [cursor=pointer]
              - status [ref=f5e74]: 正在只读原课程版本。原问题与草稿保留，请打开当前版本后再提问。
              - generic [ref=f5e75]:
                - generic [ref=f5e76]:
                  - region "当前课程上下文" [ref=f5e77]:
                    - generic [aria-hidden] [ref=f5e78]: ▣
                    - generic [ref=f5e79]:
                      - strong [ref=f5e80]: 同一整体与相同单位
                      - generic [ref=f5e81]:
                        - generic [ref=f5e82]: 小学单元 · 已确认课程
                        - generic [ref=f5e83]: 匿名数量比较课程
                    - button "移除课程上下文" [ref=f5e84] [cursor=pointer]: ×
                  - link "返回本课 ↗" [ref=f5e85] [cursor=pointer]:
                    - /url: /studio?course=qa-course-c583784d-8829-4e95-9dee-2a74076a251d&student=student_4494ce3e-d9d9-47e0-b388-9e9173bde10a&subject=math&view=courses&unit=unit-1
                  - generic [ref=f5e86]:
                    - generic [ref=f5e87]: 完整正文 · 1/1 知识目标 · 7/7 教学条目
                    - button "选择教学范围" [ref=f5e88] [cursor=pointer]
                  - generic [ref=f5e89]:
                    - generic [ref=f5e90]: 想一起看看什么
                    - textbox "想一起看看什么" [ref=f5e91]:
                      - /placeholder: 问一个概念，或告诉我想理清的问题…
                      - text: 先保留这段课程问题，正式评测之后再问。
                  - generic [ref=f5e92]:
                    - button "打开学习资料" [ref=f5e94] [cursor=pointer]: ＋
                    - generic [ref=f5e95]:
                      - generic [ref=f5e96]:
                        - generic [ref=f5e97]:
                          - generic [ref=f5e98]: 模型
                          - combobox "选择大模型" [ref=f5e99] [cursor=pointer]:
                            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                            - option "GPT-6.1 Sol"
                            - option "GPT-6 Astra"
                            - option "GPT-6 Luna"
                            - option "Grok-4.7"
                            - option "GLM-5.3 Flash"
                            - option "DeepSeek V4.1 Flash · 默认" [selected]
                            - option "Claude Opus 5.5"
                            - option "Claude Sonnet 5"
                            - option "GPT-6 Sol"
                            - option "GPT-5.6 Sol"
                            - option "GPT-5.6 Terra"
                            - option "GPT-5.6 Luna"
                            - option "GPT-5.5"
                            - option "Grok-4.6"
                            - option "GLM-5.2"
                            - option "GLM-5.3"
                            - option "Claude Opus 5"
                            - option "Claude Fable 5.1"
                            - option "MiMo V2.6 Pro"
                            - option "MiMo V2.6 Flash"
                            - option "MiMo V2.6 Pro Ultraspeed"
                            - option "Qwen3.8 Max"
                        - group [ref=f5e100]:
                          - generic "模型文字检查说明" [ref=f5e101] [cursor=pointer]: ⓘ
                      - button "发送学习问题" [disabled] [ref=f5e102]: ↑
                - paragraph [ref=f5e103]: 模型解释与课堂练习分别保留，不作为独立能力评测。
              - button "下载提问副本" [ref=f5e104] [cursor=pointer]
```

# Test source

```ts
  83  |   await page.getByRole('button', { name: '恢复最近消息', exact: true }).click(); await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toHaveCount(0);
  84  |   expect(new URL(page.url()).hash).toBe(''); await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  85  |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toHaveCount(0);
  86  | });
  87  | 
  88  | async function courseFixture(actor: any, kind: 'primary_unit' | 'material_lesson', options: { studentId?: string; long?: boolean; draft?: boolean } = {}) {
  89  |   return call(actor, '/qa/assistant/course', { kind, ...options });
  90  | }
  91  | async function child(actor: any) { return (await call(actor, '/students', { nickname: '匿名课程学习者', grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile; }
  92  | 
  93  | for(const width of [390,768,880,1440]) test('course assistant: primary unit entry opens its authorized teaching context without a classroom session at'+width, async ({ page }) => {
  94  |   test.setTimeout(100000); await page.setViewportSize({width,height:887}); const actor = await login(page), student = await child(actor), row = await courseFixture(actor, 'primary_unit', { studentId: student.id });
  95  |   await page.goto('/studio?' + new URLSearchParams({ view: 'courses', student: student.id, subject: 'math', course: row.courseId }));
  96  |   await expect(page.getByRole('heading', { name: '匿名数量比较课程', exact: true })).toBeVisible();
  97  |   const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(r.url())) posts.push(r.url()); });
  98  |   await page.getByRole('link', { name: '获取单元帮助', exact: true }).click();
  99  |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText('同一整体与相同单位');
  100 |   await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); expect(posts).toEqual([]);
  101 |   await page.getByLabel('想一起看看什么',{exact:true}).fill('[cite-course] 请解释原单元的比较条件。');await page.getByRole('button',{name:'发送学习问题',exact:true}).click();
  102 |   await expect(page.getByRole('region',{name:'提问任务',exact:true}).getByRole('status')).toHaveText('回答已保存',{timeout:45000});
  103 |   await expect(page.getByRole('navigation',{name:'本次回答的教学出处'})).toContainText('统一单位');
  104 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);
  105 |   if(!process.env.CI)await page.screenshot({path:evidence+'/primary-entry-'+width+'.png',fullPage:true});
  106 | });
  107 | 
  108 | test('course assistant: material lesson entry opens actual safe teaching and its authoring or published scope', async ({ page }) => {
  109 |   test.setTimeout(100000); const actor = await login(page), row = await courseFixture(actor, 'material_lesson');
  110 |   await page.goto('/studio/source-courses?' + new URLSearchParams({ course: row.courseId }));
  111 |   await expect(page.getByRole('heading', { name: '匿名资料比较课程', exact: true })).toBeVisible();
  112 |   await page.getByRole('link', { name: '获取课时帮助', exact: true }).click();
  113 |   await expect(page.getByRole('region', { name: '当前课程上下文' })).toContainText('资料中的比较条件');
  114 |   await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  115 | });
  116 | 
  117 | test('course assistant: oversized full teaching preserves the complete question and copies it only into explicitly selected detail',async({page})=>{
  118 |   test.setTimeout(120000);const actor=await login(page),student=await child(actor),row=await courseFixture(actor,'primary_unit',{studentId:student.id,long:true});const posts:string[]=[];
  119 |   page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions$/.test(r.url()))posts.push(r.postData()??'');});
  120 |   await page.goto(row.href);const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await expect(page.getByText('所选教学原文超过当前模型输入范围。原问题仍可编辑、下载并在选择范围后继续。')).toBeVisible();
  121 |   const question='请保留完整比较条件。'.repeat(120);await input.fill(question);await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeDisabled();expect(posts).toEqual([]);
  122 |   await page.getByRole('button',{name:'选择教学范围',exact:true}).click();const dialog=page.getByRole('dialog',{name:'选择教学范围',exact:true});
  123 |   await dialog.getByRole('radio',{name:'自选教学条目',exact:true}).check();await expect(dialog.getByRole('checkbox')).toHaveCount(113);
  124 |   await dialog.getByRole('checkbox',{name:'概念 · 比较条件 16',exact:true}).check();await dialog.getByRole('button',{name:'核对所选范围',exact:true}).click();
  125 |   await expect(dialog.getByRole('button',{name:'应用所选范围',exact:true})).toBeEnabled();await dialog.getByRole('button',{name:'应用所选范围',exact:true}).click();
  126 |   await expect(input).toHaveValue(question);await expect(page.getByRole('region',{name:'当前课程上下文'})).toContainText('同一整体与相同单位');
  127 |   await expect(page.getByText('自选教学条目 · 1/16 知识目标 · 1/112 教学条目')).toBeVisible();
  128 |   expect(new URL(page.url()).searchParams.get('assistantCarry')).toMatch(/^[a-f0-9-]{36}$/);expect(page.url()).not.toContain(encodeURIComponent(question));
  129 |   await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeEnabled();await page.goBack();await expect(input).toHaveValue(question);
  130 |   await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeDisabled();await page.goForward();await expect(input).toHaveValue(question);await page.reload();await expect(input).toHaveValue(question);
  131 | });
  132 | 
  133 | test('course assistant: an existing range draft is preserved until the original question copy is explicitly adopted',async({page})=>{
  134 |  test.setTimeout(120000);const actor=await login(page),student=await child(actor),row=await courseFixture(actor,'primary_unit',{studentId:student.id});await page.goto(row.href);
  135 |  const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await input.fill('原完整范围的匿名问题。');
  136 |  async function overview(copy:boolean){await page.getByRole('button',{name:'选择教学范围',exact:true}).click();const d=page.getByRole('dialog',{name:'选择教学范围',exact:true});await d.getByRole('radio',{name:/课程目标概览/}).check();await d.getByRole('checkbox',{name:'保留当前问题并复制到新范围'}).setChecked(copy);await d.getByRole('button',{name:'核对所选范围',exact:true}).click();await expect(d.getByRole('button',{name:'应用所选范围',exact:true})).toBeEnabled();await d.getByRole('button',{name:'应用所选范围',exact:true}).click();}
  137 |  await overview(false);await expect(input).toHaveValue('');await input.fill('概览范围原有的另一份草稿。');await page.goBack();await expect(input).toHaveValue('原完整范围的匿名问题。');await overview(true);
  138 |  await expect(input).toHaveValue('概览范围原有的另一份草稿。');await expect(page.getByText('新范围已有草稿。待采用的原问题副本：')).toBeVisible();
  139 |  const download=page.waitForEvent('download');await page.getByRole('button',{name:'下载当前问题并采用副本',exact:true}).click();expect((await download).suggestedFilename()).toBe('学习提问副本.json');
  140 |  await expect(input).toHaveValue('原完整范围的匿名问题。');await page.reload();await expect(input).toHaveValue('原完整范围的匿名问题。');await expect(page.getByText('新范围已有草稿。待采用的原问题副本：')).toHaveCount(0);
  141 | });
  142 | 
  143 | test('course assistant: learner switching and source scope mismatch hide the original content until returning to its actual profile',async({page})=>{
  144 |  test.setTimeout(120000);const actor=await login(page),one=await child(actor),two=await child(actor),row=await courseFixture(actor,'primary_unit',{studentId:one.id});await page.goto(row.href);
  145 |  const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await input.fill('只属于第一个课程档案的草稿。');
  146 |  await page.getByLabel('学习档案',{exact:true}).selectOption(two.id);await expect(page.getByText('当前学习档案或学科与课程不一致。')).toBeVisible();await expect(input).toHaveCount(0);
  147 |  expect(new URL(page.url()).searchParams.get('courseId')).toBe(row.courseId);await page.getByRole('button',{name:'切回课程档案',exact:true}).click();await expect(input).toHaveValue('只属于第一个课程档案的草稿。');
  148 |  await input.fill('[cite-course] 请说明单位条件。');await page.getByRole('button',{name:'发送学习问题',exact:true}).click();await expect(page.getByRole('navigation',{name:'本次回答的教学出处'})).toBeVisible();
  149 |  const href=await page.getByRole('navigation',{name:'本次回答的教学出处'}).getByRole('link').first().getAttribute('href');const q=new URL(href!,'https://local.invalid');q.searchParams.set('student',two.id);q.searchParams.set('subject','math');
  150 |  await page.goto(q.pathname+q.search);await expect(page.getByRole('alert',{name:'出处读取失败'})).toContainText('不一致');await expect(page.getByRole('region',{name:'冻结教学内容'})).toHaveCount(0);
  151 |  await page.getByRole('link',{name:'切回课程档案',exact:true}).click();await expect(page.getByRole('region',{name:'冻结教学内容'})).toContainText('比较两个量');
  152 | });
  153 | 
  154 | test('course assistant: current author draft becomes an original read-only scope on publication and keeps its question',async({page})=>{
  155 |  test.setTimeout(120000);const actor=await login(page),row=await courseFixture(actor,'material_lesson',{draft:true});await page.goto(row.href);const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();
  156 |  await expect(page.getByRole('region',{name:'当前课程上下文'})).toContainText('待核对教案');await input.fill('作者教案中尚未发送的原问题。');await page.getByRole('button',{name:'发送学习问题',exact:true}).click();await expect(page.getByRole('region',{name:'提问任务',exact:true}).getByRole('status')).toHaveText('回答已保存',{timeout:45000});await input.fill('发布前保留的另一份草稿。');
  157 |  const original=page.url();await call(actor,'/qa/assistant/course-state',{courseId:row.courseId,action:'publish'});let posts=0;page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions$/.test(r.url()))posts++;});await page.reload();await expect(input).toHaveValue('发布前保留的另一份草稿。');
  158 |  await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeDisabled();expect(posts).toBe(0);await page.getByRole('button',{name:'打开当前课程版本',exact:true}).click();await expect(page.getByRole('region',{name:'当前课程上下文'})).toContainText('已确认课程');await expect(input).toHaveValue('');await page.goBack();await expect(page).toHaveURL(original);await expect(input).toHaveValue('发布前保留的另一份草稿。');
  159 | });
  160 | 
  161 | async function learningCode(page:Page,actor:any,studentId:string){const access=await call(actor,'/students/'+studentId+'/learning-access',{enabled:true,expectedVersion:0,requestKey:crypto.randomUUID(),reason:'匿名课程页面权限验收'});const code=await call(actor,'/students/'+studentId+'/learning-access/codes',{expectedVersion:access.version,requestKey:crypto.randomUUID()});
  162 |  await page.goto('/student/login');await page.getByLabel('一次性学习码').fill(code.code);const login=page.waitForResponse(r=>r.url().endsWith('/api/auth/learning-code')&&r.request().method()==='POST');await page.getByRole('button',{name:'进入我的学习 →',exact:true}).click();const user=(await(await login).json()).data;await expect(page).toHaveURL(/\/learn(?:\?|$)/);return user;
  163 | }
  164 | 
  165 | test('course assistant: actual learning-code student opens published courses and exits to own learning with its draft intact',async({page})=>{
  166 |  test.setTimeout(120000);const actor=await login(page),student=await child(actor),primary=await courseFixture(actor,'primary_unit',{studentId:student.id}),material=await courseFixture(actor,'material_lesson',{studentId:student.id}),privateDraft=await courseFixture(actor,'material_lesson',{studentId:student.id,draft:true});await learningCode(page,actor,student.id);await page.goto(primary.href);
  167 |  const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await input.fill('学生单元里未发送的完整问题。');await page.getByRole('button',{name:'移除课程上下文',exact:true}).click();await expect(page).toHaveURL(/\/studio\?[^#]*view=courses/);expect(page.url()).not.toContain('audience=independent');await page.goBack();await expect(input).toHaveValue('学生单元里未发送的完整问题。');
  168 |  await page.goto(material.href);await expect(input).toBeEnabled();await input.fill('[cite-course] 请解释资料中整体与单位的关系。');await page.getByRole('button',{name:'发送学习问题',exact:true}).click();await expect(page.getByRole('navigation',{name:'本次回答的教学出处'})).toContainText('匿名比较资料');
  169 |  await page.getByRole('navigation',{name:'本次回答的教学出处'}).getByRole('link').click();await expect(page.getByRole('region',{name:'冻结教学内容'})).toContainText('比较数量之前');
  170 |  const posts:string[]=[];page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions$/.test(r.url()))posts.push(r.url());});await page.goto(privateDraft.href);await expect(page.locator('.sa-context-error')).toContainText(/无法访问|只能由/);await expect(input).toHaveCount(0);expect(posts).toEqual([]);
  171 | });
  172 | 
  173 | test('course assistant: real assessment beginning after entry blocks a new model command and preserves the original student question',async({page})=>{
  174 |  test.setTimeout(150000);const actor=await login(page),student=await child(actor),row=await courseFixture(actor,'primary_unit',{studentId:student.id});
  175 |  await call(actor,'/students/'+student.id+'/learning-scope',{subject:'math',grade:4,term:'upper',textbookVolumeId:null,textbookVersion:'匿名已学范围',learnedAtomIds:['atomic:math:averagecount'],currentAtomId:'atomic:math:averagecount',minutesPerSession:10},'PUT');
  176 |  await learningCode(page,actor,student.id);await page.goto(row.href);const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await input.fill('先保留这段课程问题，正式评测之后再问。');
  177 |  const formal=await call(actor,'/diagnostics/sessions',{studentId:student.id,subject:'math',intent:'baseline',targetAtomIds:['atomic:math:averagecount'],includePrerequisites:false,maxItems:4});const posts:string[]=[];
  178 |  page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(r.url()))posts.push(r.postData()??'');});await page.getByRole('button',{name:'发送学习问题',exact:true}).click();await expect(page.getByRole('link',{name:'进入原评测',exact:true})).toHaveAttribute('href','/student/assessment?session='+formal.id);
  179 |  await expect(input).toHaveValue('先保留这段课程问题，正式评测之后再问。');expect(posts).toEqual([]);await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeDisabled();
  180 |  await page.reload();await expect(input).toHaveValue('先保留这段课程问题，正式评测之后再问。');await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeDisabled();
  181 |  await page.getByRole('link',{name:'进入原评测',exact:true}).click();await expect(page).toHaveURL(new RegExp('session='+formal.id));await expect(page.locator('.studio-question-top')).toBeVisible();await page.goBack();
  182 |  const view=await call(actor,'/diagnostics/sessions/'+formal.id);await call(actor,'/diagnostics/sessions/'+formal.id+'/state',{action:'abort',expectedRevision:view.revision,requestKey:crypto.randomUUID(),reason:'结束隔离课程边界验收，不形成评测结果'});
> 183 |  await page.getByRole('button',{name:'重新核对课程',exact:true}).click();await expect(input).toHaveValue('先保留这段课程问题，正式评测之后再问。');await expect(page.getByRole('button',{name:'发送学习问题',exact:true})).toBeEnabled();expect(posts).toEqual([]);
      |                                                            ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  184 | });
  185 | 
  186 | test('course assistant: no-fingerprint student entry during an existing assessment offers its exact return without opening a chat',async({page})=>{
  187 |  test.setTimeout(120000);const actor=await login(page),student=await child(actor),row=await courseFixture(actor,'primary_unit',{studentId:student.id});await call(actor,'/students/'+student.id+'/learning-scope',{subject:'math',grade:4,term:'upper',textbookVolumeId:null,textbookVersion:'匿名已学范围',learnedAtomIds:['atomic:math:averagecount'],currentAtomId:'atomic:math:averagecount',minutesPerSession:10},'PUT');const formal=await call(actor,'/diagnostics/sessions',{studentId:student.id,subject:'math',intent:'baseline',targetAtomIds:['atomic:math:averagecount'],includePrerequisites:false,maxItems:4});await learningCode(page,actor,student.id);const posts:string[]=[];page.on('request',r=>{if(r.method()==='POST'&&/\/ai\/assistant\/sessions$/.test(r.url()))posts.push(r.url());});await page.goto(row.href);await expect(page.getByRole('link',{name:'进入原评测',exact:true})).toHaveAttribute('href','/student/assessment?session='+formal.id);await expect(page.getByLabel('想一起看看什么',{exact:true})).toHaveCount(0);expect(posts).toEqual([]);
  188 | });
  189 | 
  190 | test('course assistant: material tools preserve the authoritative scope and draft through refresh and planner return',async({page})=>{
  191 |  test.setTimeout(120000);const actor=await login(page),student=await child(actor),row=await courseFixture(actor,'material_lesson',{studentId:student.id});await page.goto(row.href);const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await input.fill('资料课程中尚未发送的匿名草稿。');const original=new URL(page.url());
  192 |  await page.getByRole('button',{name:'打开学习资料',exact:true}).click();await expect(page).toHaveURL(/view=materials/);expect(new URL(page.url()).searchParams.get('courseVersion')).toBe(original.searchParams.get('courseVersion'));await page.reload();
  193 |  await page.locator('.ws-navigation').getByRole('link',{name:'Home',exact:true}).click();await expect(input).toHaveValue('资料课程中尚未发送的匿名草稿。');await page.getByRole('button',{name:'学习计划',exact:true}).click();await expect(page).toHaveURL(/view=calendar/);await page.reload();await page.locator('.ws-navigation').getByRole('link',{name:'Home',exact:true}).click();await expect(input).toHaveValue('资料课程中尚未发送的匿名草稿。');
  194 | });
  195 | 
  196 | test('course assistant: closing a pending range preflight ignores its late response and restores keyboard focus',async({page})=>{
  197 |  test.setTimeout(120000);const actor=await login(page),student=await child(actor),row=await courseFixture(actor,'primary_unit',{studentId:student.id});await page.goto(row.href);const input=page.getByLabel('想一起看看什么',{exact:true});await expect(input).toBeEnabled();await input.fill('范围预检取消后仍保留的原问题。');const original=page.url();let release!:()=>void,seen=false;const gate=new Promise<void>(resolve=>release=resolve);
  198 |  await page.route(/\/ai\/assistant\/course-context\?.*selection=/,async route=>{const response=await route.fetch();seen=true;await gate;await route.fulfill({response});});try{await page.getByRole('button',{name:'选择教学范围',exact:true}).click();const d=page.getByRole('dialog',{name:'选择教学范围',exact:true});await d.getByRole('radio',{name:/课程目标概览/}).check();await d.getByRole('button',{name:'核对所选范围',exact:true}).click();await expect.poll(()=>seen).toBe(true);await page.keyboard.press('Escape');await expect(d).toHaveCount(0);release();await page.unrouteAll({behavior:'wait'});await expect(page).toHaveURL(original);await expect(input).toHaveValue('范围预检取消后仍保留的原问题。');await expect(page.getByRole('button',{name:'选择教学范围',exact:true})).toBeFocused();}finally{release();await page.unrouteAll({behavior:'wait'});}
  199 | });
  200 | 
```