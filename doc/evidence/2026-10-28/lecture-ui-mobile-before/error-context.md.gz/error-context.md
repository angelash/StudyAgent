# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio-assistant.spec.ts >> lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson
- Location: tests\e2e\studio-assistant.spec.ts:16:5

# Error details

```
TimeoutError: locator.click: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: '获取帮助', exact: true }).first()

```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - alert [ref=f1e2]
  - main [ref=f1e3]:
    - button "打开学习导航" [ref=f1e4] [cursor=pointer]
    - generic [ref=f1e7]:
      - complementary [ref=f1e8]:
        - link "× 退出课程" [ref=f1e9] [cursor=pointer]:
          - /url: /studio?view=courses
          - text: ×
          - generic [ref=f1e10]: 退出课程
        - img "由阶梯与拱门构成的课程封面" [ref=f1e11]
        - generic [ref=f1e31]:
          - generic [ref=f1e32]: S
          - generic [ref=f1e33]:
            - generic [ref=f1e34]: 策划自
            - generic [ref=f1e35]: StudyAgent Learning Studio
        - heading "社会学概论" [level=1] [ref=f1e36]
        - paragraph [ref=f1e37]: 从自己的生活出发，看见文化、关系和制度如何共同塑造社会。五个单元串起概念、案例、练习与一个持续推进的社区研究。
        - group [ref=f1e38]:
          - generic "显示更多" [ref=f1e39] [cursor=pointer]
        - generic [ref=f1e40]:
          - generic [ref=f1e41]: 面板
          - tablist "课程面板" [ref=f1e42]:
            - tab "单元" [selected] [ref=f1e43] [cursor=pointer]
            - tab "资料" [ref=f1e44] [cursor=pointer]
            - tab "练习" [ref=f1e45] [cursor=pointer]
          - tabpanel "单元" [ref=f1e46]:
            - generic [ref=f1e47]:
              - button "1 社会学视角" [ref=f1e48] [cursor=pointer]:
                - generic [ref=f1e49]: "1"
                - generic [ref=f1e50]: 社会学视角
              - button "2 文化与自我" [ref=f1e51] [cursor=pointer]:
                - generic [ref=f1e52]: "2"
                - generic [ref=f1e53]: 文化与自我
              - button "3 不平等" [ref=f1e54] [cursor=pointer]:
                - generic [ref=f1e55]: "3"
                - generic [ref=f1e56]: 不平等
              - button "4 制度" [ref=f1e57] [cursor=pointer]:
                - generic [ref=f1e58]: "4"
                - generic [ref=f1e59]: 制度
              - button "5 越轨与社会变迁" [ref=f1e60] [cursor=pointer]:
                - generic [ref=f1e61]: "5"
                - generic [ref=f1e62]: 越轨与社会变迁
      - generic [ref=f1e63]:
        - generic [ref=f1e64]:
          - generic [ref=f1e65]: 第 1 单元，共 5 单元
          - heading "单元 1：社会学视角" [level=2] [ref=f1e66]
          - paragraph [ref=f1e67]: 把个人经验放回社会背景，比较理论解释并设计可检验的研究。
        - link "▤ 把自己的资料带进课堂 PDF、页级阅读、个性化学案与白板 ↗" [ref=f1e68] [cursor=pointer]:
          - /url: /studio?view=materials
          - generic [ref=f1e69]: ▤
          - generic [ref=f1e70]:
            - generic [ref=f1e71]: 把自己的资料带进课堂
            - generic [ref=f1e72]: PDF、页级阅读、个性化学案与白板
          - generic [ref=f1e73]: ↗
        - generic [ref=f1e74]:
          - generic [ref=f1e75]:
            - generic "讲解已读" [ref=f1e76]: ✓
            - text: 讲解已读
          - generic [ref=f1e77]:
            - generic "已接触" [ref=f1e78]
            - text: 已接触
          - generic [ref=f1e79]:
            - generic "未开始" [ref=f1e80]
            - text: 未开始
          - generic [ref=f1e81]: ▣ Project
          - generic [ref=f1e82]: ♙ Exam
        - generic [ref=f1e83]:
          - generic [ref=f1e84]:
            - button "未开始" [ref=f1e85] [cursor=pointer]
            - button "未开始" [ref=f1e87] [cursor=pointer]
            - button "未开始" [ref=f1e89] [cursor=pointer]
            - button "未开始" [ref=f1e91] [cursor=pointer]
            - button "未开始" [ref=f1e93] [cursor=pointer]
            - button "未开始" [ref=f1e95] [cursor=pointer]
            - button "未开始" [ref=f1e97] [cursor=pointer]
            - button "未开始" [ref=f1e99] [cursor=pointer]
            - button "未开始" [ref=f1e101] [cursor=pointer]
            - button "未开始" [ref=f1e103] [cursor=pointer]
            - button "未开始" [ref=f1e105] [cursor=pointer]
            - button "未开始" [ref=f1e107] [cursor=pointer]
            - link "▣" [ref=f1e109] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
            - button "♙" [ref=f1e110] [cursor=pointer]
          - button "▶ 下一步：社会学想象力 ›" [ref=f1e111] [cursor=pointer]:
            - text: ▶
            - generic [ref=f1e112]: 下一步：社会学想象力
            - text: ›
        - group "本单元学习进程" [ref=f1e113]:
          - generic "学习进程 · 本单元" [ref=f1e114] [cursor=pointer]
        - generic [ref=f1e115]:
          - article [ref=f1e116]:
            - button "讲次 1：社会学思考" [expanded] [ref=f1e118] [cursor=pointer]
            - paragraph [ref=f1e119]: 围绕社会学思考，通过四段微课完成概念辨析与情境应用。
            - generic [ref=f1e120]:
              - generic [ref=f1e121]:
                - generic [ref=f1e122]:
                  - text: 社会学想象力
                  - button "查看学习目标：社会学想象力" [ref=f1e123] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e124] [cursor=pointer]
                - button "♧ 练习" [ref=f1e125] [cursor=pointer]
                - generic "未开始" [ref=f1e126]
              - generic [ref=f1e127]:
                - generic [ref=f1e128]:
                  - text: 结构与能动性
                  - button "查看学习目标：结构与能动性" [ref=f1e129] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e130] [cursor=pointer]
                - button "♧ 练习" [ref=f1e131] [cursor=pointer]
                - generic "未开始" [ref=f1e132]
              - generic [ref=f1e133]:
                - generic [ref=f1e134]:
                  - text: 社会事实
                  - button "查看学习目标：社会事实" [ref=f1e135] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e136] [cursor=pointer]
                - button "♧ 练习" [ref=f1e137] [cursor=pointer]
                - generic "未开始" [ref=f1e138]
              - generic [ref=f1e139]:
                - generic [ref=f1e140]:
                  - text: 社会学与日常生活
                  - button "查看学习目标：社会学与日常生活" [ref=f1e141] [cursor=pointer]: ⊙
                - button "▶ 学习" [ref=f1e142] [cursor=pointer]
                - button "♧ 练习" [ref=f1e143] [cursor=pointer]
                - generic "未开始" [ref=f1e144]
          - article [ref=f1e145]:
            - button "讲次 2：理论传统" [ref=f1e147] [cursor=pointer]
            - paragraph [ref=f1e148]: 围绕理论传统，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e149]:
            - button "讲次 3：研究方法" [ref=f1e151] [cursor=pointer]
            - paragraph [ref=f1e152]: 围绕研究方法，通过四段微课完成概念辨析与情境应用。
          - article [ref=f1e153]:
            - generic [ref=f1e154]: PROJECT · 1 / 5
            - heading "研究问题与方法设计" [level=3] [ref=f1e155]
            - paragraph [ref=f1e156]: 选择一个社区现象，写出研究问题、调查对象、方法与保护参与者的办法。
            - link "开始项目 →" [ref=f1e157] [cursor=pointer]:
              - /url: /studio/projects?unitId=soc-u1&returnUnit=0&returnPanel=units
          - article [ref=f1e158]:
            - text: UNIT CHECK
            - heading "社会学视角综合核查" [level=3] [ref=f1e159]
            - paragraph [ref=f1e160]: 覆盖本单元的 12 个主题，12 道新情境题保留首次作答、跳过与提示记录。
            - button "Start →" [ref=f1e161] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { mkdirSync, writeFileSync } from 'node:fs';
  3  | import { browserEvidence } from './evidence';
  4  | 
  5  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  6  | const evidence = browserEvidence('studio-assistant');
  7  | async function login(page: Page) {
  8  |   const id = crypto.randomUUID(), principal = 'lecture-browser-' + id + '@local.test', credential = 'Lecture-browser-only-' + id;
  9  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
  10 |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  11 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  13 |   return actor;
  14 | }
  15 | 
  16 | test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  17 |   test.setTimeout(90000); await page.setViewportSize({ width: 880, height: 887 }); await login(page);
  18 |   const classroomPosts: string[] = [], errors: string[] = [];
  19 |   page.on('pageerror', error => errors.push(error.message));
  20 |   page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  21 |   try {
  22 |     await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
> 23 |     await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
     |                                                                           ^ TimeoutError: locator.click: Timeout 15000ms exceeded.
  24 |     await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
  25 |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  26 |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
  27 |     await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
  28 |     expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
  29 |     await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  30 |   } finally {
  31 |     if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  32 |   }
  33 | });
  34 | 
```