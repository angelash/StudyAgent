# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio-assistant.spec.ts >> lecture-assistant: a retained original version opens from the server without creating or resending a session
- Location: tests/e2e/studio-assistant.spec.ts:102:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('log', { name: '当前学习对话' })
Expected substring: "LECTURE_OLD_HISTORY_MARKER"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('log', { name: '当前学习对话' }) with timeout 15000ms
  - waiting for getByRole('log', { name: '当前学习对话' })

```

```yaml
- alert
- main:
  - button "打开学习导航"
  - text: 独立学习
  - link "创建学习档案":
    - /url: /parent/dashboard
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "Time for flashcards?" [level=1]
  - alert:
    - paragraph: 原讲座教学范围与快照不一致；请保留原对话并重新核对
    - button "重新核对讲座"
    - button "打开当前讲座版本"
    - link "返回课程":
      - /url: /studio/classroom
  - region "学习工作台助教":
    - button "查找历史"
    - status: 正在只读原讲座版本。原问题与草稿保留，请打开当前版本后再提问。
    - alert: 原讲座版本无法读取。本机草稿仍保留，可下载后打开当前版本。
    - button "读取最新状态"
    - region "当前讲座上下文":
      - strong: 原讲座上下文待核对
      - text: 原版本 请返回课程核对
      - button "移除讲座上下文": ×
    - text: 想一起看看什么
    - textbox "想一起看看什么" [disabled]:
      - /placeholder: 问一个概念，或告诉我你想理清的问题…
    - button "打开学习资料": ＋
    - button "Tools"
    - text: 模型
    - combobox "选择大模型" [disabled]:
      - option "Auto · 平台默认 DeepSeek V4.1 Flash"
    - group: ⓘ
    - button "发送学习问题" [disabled]: ↑
    - button "Concept Explanation" [disabled]
    - button "Personal Study Materials Generation"
    - button "Long-files Digestion"
    - button "Problem Solving" [disabled]
    - link "Visualization":
      - /url: /studio/whiteboards
```

# Test source

```ts
  6   | const evidence = browserEvidence('studio-assistant');
  7   | let address = 0;
  8   | async function login(page: Page) {
  9   |   const id = crypto.randomUUID(), principal = 'lecture-browser-' + id + '@local.test', credential = 'Lecture-browser-only-' + id;
  10  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.15.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  11  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  12  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  13  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  |   return actor;
  15  | }
  16  | async function call(actor: any, path: string, body?: unknown) {
  17  |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  18  |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  19  | }
  20  | const input = (page: Page) => page.getByLabel('想一起看看什么', { exact: true });
  21  | const task = (page: Page) => page.getByRole('region', { name: '提问任务', exact: true });
  22  | async function lecture(page: Page, width = 1280) {
  23  |   await page.setViewportSize({ width, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  24  |   await page.goto('/studio/classroom'); await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  25  |   await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/); await expect(input(page)).toBeEnabled(); return actor;
  26  | }
  27  | async function shot(page: Page, name: string) { if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); await page.evaluate(async () => { await document.fonts.ready; }); await page.screenshot({ path: evidence + '/' + name + '.png', fullPage: true }); } }
  28  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  29  | 
  30  | test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  31  |   test.setTimeout(90000); await page.setViewportSize({ width: 1280, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); await login(page);
  32  |   const classroomPosts: string[] = [], errors: string[] = [];
  33  |   page.on('pageerror', error => errors.push(error.message));
  34  |   page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  35  |   try {
  36  |     await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  37  |     await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  38  |     await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
  39  |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  40  |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
  41  |     await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
  42  |     expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
  43  |     await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考'); await expect(input(page)).toBeEnabled();
  44  |   } finally {
  45  |     if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  46  |   }
  47  | });
  48  | 
  49  | for (const width of [390, 768, 880, 1440]) test(`lecture-assistant: usable course entry, composer and complete model selection at${width}`, async ({ page }) => {
  50  |   test.setTimeout(90000); await lecture(page, width);
  51  |   await expect(page.getByRole('region', { name: '当前讲座上下文' })).toBeVisible();
  52  |   const picker = page.getByRole('combobox', { name: '选择大模型', exact: true }); await expect(picker.locator('option')).toHaveCount(23); await expect(picker).toHaveValue('deepseek-v4-flash');
  53  |   await page.getByLabel('模型文字检查说明').click(); await expect(page.getByText('尚未进行文字检查', { exact: true })).toBeVisible();
  54  |   await page.getByLabel('模型文字检查说明').click();
  55  |   await page.getByRole('button', { name: 'Tools', exact: true }).click(); await expect(page.getByRole('menuitem', { name: /Whiteboard session/ })).toBeVisible();
  56  |   await page.keyboard.press('Escape'); await expect(page.getByRole('menu', { name: '' })).toHaveCount(0);
  57  |   const layout=await page.evaluate(()=>({viewport:innerWidth,documentWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('.input-box,.button-row,.composer-right-group,select[aria-label="选择大模型"],button[aria-label="发送学习问题"]')].map(element=>{const box=element.getBoundingClientRect(),style=getComputedStyle(element);return{selector:element.className,left:box.left,right:box.right,width:box.width,minWidth:style.minWidth,cssWidth:style.width};})}));
  58  |   if(!process.env.CI){mkdirSync(evidence,{recursive:true});writeFileSync(evidence+'/entry-'+width+'-layout.json',JSON.stringify(layout,null,2));}
  59  |   expect(layout.documentWidth).toBeLessThanOrEqual(width);for(const control of layout.controls){expect(control.left).toBeGreaterThanOrEqual(0);expect(control.right).toBeLessThanOrEqual(width);}
  60  |   await shot(page, 'entry-' + width);
  61  | });
  62  | 
  63  | test('lecture-assistant: lecture removal, back and reload preserve separate unsent drafts without sending', async ({ page }) => {
  64  |   test.setTimeout(90000); await lecture(page); const posts: unknown[] = [];
  65  |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  66  |   await input(page).fill('原讲座中尚未发送的匿名草稿。'); const original = page.url();
  67  |   await page.getByRole('button', { name: '移除讲座上下文' }).click(); await expect(page).toHaveURL(/audience=independent/);
  68  |   await expect(page.getByRole('region', { name: '当前讲座上下文' })).toHaveCount(0); await expect(input(page)).toBeEnabled(); await expect(input(page)).toHaveValue('');
  69  |   await input(page).fill('普通独立学习中尚未发送的匿名草稿。');
  70  |   await page.goBack(); await expect(page).toHaveURL(original); await expect(input(page)).toHaveValue('原讲座中尚未发送的匿名草稿。');
  71  |   await page.goForward(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。'); await page.reload(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。');
  72  |   expect(posts).toEqual([]); await shot(page, 'separate-drafts');
  73  | });
  74  | 
  75  | test('lecture-assistant: durable pending turn resumes after refresh with its original model', async ({ page }) => {
  76  |   test.setTimeout(120000); await lecture(page); const posts: any[] = [];
  77  |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  78  |   await input(page).fill('[assistant-pause-once] 请用匿名例子比较本讲的概念。'); await page.getByRole('button', { name: '发送学习问题' }).click(); await expect(task(page)).toBeVisible();
  79  |   await page.reload(); await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 });
  80  |   expect(posts).toHaveLength(1); expect(posts[0].modelId).toBe('deepseek-v4-flash');
  81  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2);
  82  |   await page.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6.1-sol'); await expect(task(page)).toContainText('DeepSeek V4.1 Flash');
  83  |   await shot(page, 'saved-original-model');
  84  | });
  85  | 
  86  | test('lecture-assistant: a lost receipt is recovered with the original request and no duplicate post', async ({ page }) => {
  87  |   test.setTimeout(120000); const actor=await lecture(page); let submitted: any = null, count = 0,sessionId='';const allPosts:any[]=[];
  88  |   page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url()))allPosts.push(request.postDataJSON());});
  89  |   await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/, async route => {
  90  |     if (route.request().method() === 'POST') { count++; submitted = route.request().postDataJSON();sessionId=new URL(route.request().url()).pathname.split('/').at(-2)!; await route.fetch(); await route.abort('failed'); } else await route.continue();
  91  |   });
  92  |   await input(page).fill('只发送一次的匿名讲座问题。'); await page.getByRole('button', { name: '发送学习问题' }).click();
  93  |   await expect(page.getByRole('complementary', { name: '待确认提问' })).toBeVisible();
  94  |   expect(submitted.requestKey).toBeTruthy(); await page.unrouteAll({ behavior: 'wait' });
  95  |   await expect.poll(async()=> (await call(actor,'/ai/assistant/sessions/'+sessionId+'/turns?requestKey='+submitted.requestKey)).turns[0]?.status).toBe('completed');
  96  |   let stalePages=0;await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/messages\/page\?/,async route=>{const response=await route.fetch();if(stalePages++===0){const body=await response.json();body.data.messages=[];await route.fulfill({response,json:body});}else await route.fulfill({response});});
  97  |   await page.reload();
  98  |   await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 }); expect(count).toBe(1);expect(allPosts).toHaveLength(1);expect(allPosts[0].requestKey).toBe(submitted.requestKey);
  99  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2);expect(stalePages).toBeGreaterThanOrEqual(2); await shot(page, 'recovered-original-request');
  100 | });
  101 | 
  102 | test('lecture-assistant: a retained original version opens from the server without creating or resending a session', async ({ page }) => {
  103 |   test.setTimeout(120000); await page.setViewportSize({ width: 880, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  104 |   const original = await call(actor, '/qa/assistant/lecture-history', {}), posts: string[] = [];
  105 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(request.url())) posts.push(request.url()); });
> 106 |   await page.goto(original.href); await expect(page.getByRole('log', { name: '当前学习对话' })).toContainText('LECTURE_OLD_HISTORY_MARKER');
      |                                                                                           ^ Error: expect(locator).toContainText(expected) failed
  107 |   await expect(input(page)).toBeDisabled(); await expect(page.getByRole('button', { name: '发送学习问题' })).toBeDisabled(); expect(posts).toEqual([]);
  108 |   await shot(page, 'retained-original-readonly');
  109 |   await page.getByRole('button', { name: '打开当前讲座版本', exact: true }).click(); await expect(input(page)).toBeEnabled();
  110 |   await expect(page.locator('.assistant-message').filter({hasText:'LECTURE_OLD_HISTORY_MARKER'})).toHaveCount(0);
  111 |   expect(posts.some(url => /\/sessions$/.test(url))).toBe(true); expect(posts.some(url => /\/turns$/.test(url))).toBe(false);
  112 |   expect((await call(actor, '/ai/assistant/sessions/' + original.sessionId + '/messages/page')).messages).toHaveLength(2);
  113 | });
  114 | 
  115 | test('lecture-assistant: failed initialization after a child change cannot retain the previous active session', async ({ page }) => {
  116 |   test.setTimeout(120000); const actor = await login(page), children:Array<{id:string}> = [];
  117 |   for (const nickname of ['匿名档案甲', '匿名档案乙']) children.push((await call(actor, '/students', { nickname, grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile);
  118 |   await page.goto('/studio'); await expect(page.getByRole('combobox', { name: '学习档案', exact: true }).locator('option')).toHaveCount(2);await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[0].id);await expect(page.getByRole('combobox', { name: '学习档案', exact: true })).toHaveValue(children[0].id); await page.getByRole('button', { name: 'Instant Assistance', exact: true }).click();
  119 |   await expect(input(page)).toBeEnabled(); await input(page).fill('只属于匿名档案甲的未发送草稿。'); const posts: string[] = [];
  120 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.url()); });
  121 |   await page.route(/\/ai\/assistant\/sessions$/, async route => {
  122 |     if (route.request().method() === 'POST' && route.request().postDataJSON().studentId === children[1].id) await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ data: null, error: { code: 'synthetic_unavailable', message: '匿名上下文初始化暂不可用' }, meta: {} }) });
  123 |     else await route.continue();
  124 |   });
  125 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[1].id); await expect(page.getByText('匿名上下文初始化暂不可用', { exact: true })).toBeVisible();
  126 |   await expect(input(page)).toBeDisabled(); expect(posts).toEqual([]);
  127 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[0].id); await expect(input(page)).toHaveValue('只属于匿名档案甲的未发送草稿。');
  128 |   await page.unrouteAll({ behavior: 'wait' });
  129 | });
  130 | 
  131 | test('lecture-assistant: read-only recovery preserves a cached pending command and identifies separately selected history', async ({ page }) => {
  132 |   test.setTimeout(120000);const actor=await login(page),old=await call(actor,'/qa/assistant/lecture-history',{}),owner=(await call(actor,'/auth/me')).id;
  133 |   const scope=JSON.stringify({userRole:'parent',studentId:null,subject:null,pageContext:'classroom',contextRefType:'classroom_lecture',contextRefId:old.referenceId,contextItemId:old.lectureId});
  134 |   const key='studyagent.assistant.v1.'+encodeURIComponent(owner)+'.'+encodeURIComponent(scope);
  135 |   const raw=JSON.stringify({version:1,ownerId:owner,scope,sessionId:old.sessionId,input:'原版本未发送草稿，不可自动发出。',pending:{requestKey:crypto.randomUUID(),message:'原版本待确认命令。',modelId:'deepseek-v4-flash',contextVersion:'a'.repeat(64)},lastTurnId:null});
  136 |   await page.evaluate(({key,raw})=>localStorage.setItem(key,raw),{key,raw});
  137 |   const generic=await call(actor,'/ai/assistant/sessions',{userRole:'parent',studentId:null,subject:null,pageContext:'studio'});
  138 |   await call(actor,'/qa/assistant/seed-history',{sessionId:generic.id,count:4,marker:'OWN_INDEPENDENT_HISTORY'});
  139 |   const posts:string[]=[];page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions(?:\/|$)/.test(request.url()))posts.push(request.url());});
  140 |   await page.goto(old.href);await expect(input(page)).toHaveValue('原版本未发送草稿，不可自动发出。');await expect(input(page)).toBeDisabled();await expect(page.getByRole('button',{name:'核对原请求',exact:true})).toBeDisabled();
  141 |   await page.getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill('OWN_INDEPENDENT_HISTORY');await page.getByRole('button',{name:'搜索历史',exact:true}).click();await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  142 |   await expect(page.getByRole('log',{name:'当前学习对话'})).toContainText('OWN_INDEPENDENT_HISTORY');await expect(page.getByRole('region',{name:'当前讲座上下文'})).toHaveCount(0);await expect(page.getByText('正在只读原讲座版本。原问题与草稿保留，请打开当前版本后再提问。',{exact:true})).toHaveCount(0);
  143 |   await page.getByRole('button',{name:'返回当前学习对话',exact:true}).click();await expect(input(page)).toHaveValue('原版本未发送草稿，不可自动发出。');await expect(input(page)).toBeDisabled();expect(await page.evaluate(key=>localStorage.getItem(key),key)).toBe(raw);expect(posts).toEqual([]);await shot(page,'readonly-pending-and-history');
  144 | });
  145 | 
  146 | test('lecture-assistant: an unavailable original still allows owner-only history reads without a session post',async({page})=>{
  147 |   test.setTimeout(90000);const actor=await login(page),old=await call(actor,'/qa/assistant/lecture-history',{}),generic=await call(actor,'/ai/assistant/sessions',{userRole:'parent',studentId:null,subject:null,pageContext:'studio'});
  148 |   await call(actor,'/qa/assistant/seed-history',{sessionId:generic.id,count:4,marker:'READABLE_WITHOUT_BASE'});
  149 |   const url=new URL(old.href,'http://local.test');url.searchParams.set('lectureVersion','0'.repeat(64));const posts:string[]=[];
  150 |   page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions(?:\/|$)/.test(request.url()))posts.push(request.url());});
  151 |   await page.goto(url.pathname+url.search);await expect(input(page)).toBeDisabled();await expect(page.getByRole('alert').filter({hasText:'当前账号没有保留这个讲座原版本'})).toBeVisible();
  152 |   await page.getByRole('button',{name:'查找历史',exact:true}).click();await page.getByLabel('检索历史关键词').fill('READABLE_WITHOUT_BASE');await page.getByRole('button',{name:'搜索历史',exact:true}).click();await page.getByLabel('助教历史检索').getByRole('list').getByRole('button').click();
  153 |   await expect(page.getByRole('log',{name:'当前学习对话'})).toContainText('READABLE_WITHOUT_BASE');await expect(page.getByRole('button',{name:'返回当前学习对话',exact:true})).toBeVisible();expect(posts).toEqual([]);
  154 | });
  155 | 
  156 | test('lecture-assistant: another account cannot open a retained version or find its private messages',async({page,browser})=>{
  157 |   test.setTimeout(90000);const actor=await login(page),old=await call(actor,'/qa/assistant/lecture-history',{}),stranger=await browser.newContext({baseURL:new URL(page.url()).origin});
  158 |   try{const other=await stranger.newPage();await login(other);const posts:string[]=[];other.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions(?:\/|$)/.test(request.url()))posts.push(request.url());});
  159 |     await other.goto(old.href);await expect(input(other)).toBeDisabled();await expect(other.getByRole('alert').filter({hasText:'当前账号没有保留这个讲座原版本'})).toBeVisible();await expect(other.locator('.assistant-message')).toHaveCount(0);
  160 |     await other.getByRole('button',{name:'查找历史',exact:true}).click();await other.getByLabel('检索历史关键词').fill('LECTURE_OLD_HISTORY_MARKER');await other.getByRole('button',{name:'搜索历史',exact:true}).click();await expect(other.getByLabel('助教历史检索')).toContainText('找到 0 段对话');expect(posts).toEqual([]);
  161 |   }finally{await stranger.close();}
  162 | });
  163 | 
  164 | test('lecture-assistant: explicit cancellation and retry preserve one lecture request and the original model',async({page})=>{
  165 |   test.setTimeout(120000);const actor=await lecture(page),posts:any[]=[];page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url()))posts.push({url:request.url(),command:request.postDataJSON()});});
  166 |   await input(page).fill('[assistant-pause-once] '+crypto.randomUUID()+' 取消后按原模型重试。');await page.getByRole('button',{name:'发送学习问题',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','running');await task(page).getByRole('button',{name:'取消生成',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','cancelled');
  167 |   await page.reload();await expect(task(page)).toHaveAttribute('data-status','cancelled');await page.getByRole('combobox',{name:'选择大模型',exact:true}).selectOption('glm-5.3-flash');await task(page).getByRole('button',{name:'重试原任务',exact:true}).click();await expect(task(page)).toHaveAttribute('data-status','completed',{timeout:45000});
  168 |   expect(posts).toHaveLength(1);const id=new URL(posts[0].url).pathname.split('/').at(-2),turns=(await call(actor,'/ai/assistant/sessions/'+id+'/turns')).turns;expect(turns).toHaveLength(1);expect(turns[0]).toMatchObject({requestKey:posts[0].command.requestKey,modelId:'deepseek-v4-flash'});expect(turns[0].task.generation).toBe(2);await expect(page.locator('.assistant-message')).toHaveCount(2);await expect(page.getByRole('combobox',{name:'选择大模型',exact:true})).toHaveValue('glm-5.3-flash');await shot(page,'cancel-retry-original-lecture');
  169 | });
  170 | 
  171 | test('lecture-assistant: changing the selected learner fences a late whiteboard preview and releases the new composer',async({page})=>{
  172 |   test.setTimeout(120000);const actor=await login(page),children:Array<{id:string}>=[];
  173 |   for(const nickname of ['白板匿名档案甲','白板匿名档案乙'])children.push((await call(actor,'/students',{nickname,grade:5,preferredSessionMinutes:15,defaultVersionMap:{math:'common',chinese:'common',english:'common'}})).profile);
  174 |   const scope=await fetch(api+'/students/'+children[0].id+'/learning-scope?subject=math',{method:'PUT',headers:{'Content-Type':'application/json',Authorization:'Bearer '+actor.token},body:JSON.stringify({subject:'math',grade:5,term:'upper',textbookVolumeId:null,textbookVersion:'按已学知识点确认',learnedAtomIds:['core:math:fractionadd','core:math:fractionsubtract'],currentAtomId:'core:math:fractionadd',minutesPerSession:15,progressMode:'knowledge',selectedLessonIds:[]})});expect(scope.status).toBe(200);
  175 |   await page.goto('/studio?mode=instant&student='+children[0].id);await expect(input(page)).toBeEnabled();await page.getByRole('button',{name:'Tools',exact:true}).click();await page.getByRole('menuitem',{name:/Whiteboard session/}).click();await input(page).fill('解释异分母分数加法');
  176 |   let release!:()=>void;const gate=new Promise<void>(resolve=>release=resolve);let captured=false,returned=false;const saves:string[]=[];
  177 |   page.on('request',request=>{if(request.method()==='POST'&&/\/learning\/studio\/whiteboards$/.test(request.url()))saves.push(request.url());});
  178 |   await page.route('**/api/learning/studio/whiteboards/preview',async route=>{const response=await route.fetch();expect(response.ok()).toBe(true);captured=true;await gate;try{await route.fulfill({response});}catch{/* The previous learner's client was aborted. */}finally{returned=true;}});
  179 |   try{await page.getByRole('button',{name:'预览白板主题',exact:true}).click();await expect.poll(()=>captured).toBe(true);await expect(input(page)).toBeDisabled();
  180 |     await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[1].id);await expect(input(page)).toBeEnabled();release();await expect.poll(()=>returned).toBe(true);
  181 |     await expect(page.locator('.sa-whiteboard-preview-modal')).toHaveCount(0);await expect(page.getByRole('combobox',{name:'学习档案',exact:true})).toHaveValue(children[1].id);await expect(input(page)).toHaveValue('');expect(saves).toEqual([]);
  182 |   }finally{release();}
  183 | });
  184 | 
  185 | for(const mode of ['lecture','independent'])test('lecture-navigation: '+mode+' tools retain the original scope and draft through material refresh and planner return',async({page})=>{
  186 |   test.setTimeout(90000);await lecture(page);if(mode==='independent')await page.getByRole('button',{name:'移除讲座上下文',exact:true}).click();await expect(input(page)).toBeEnabled();
  187 |   const original=new URL(page.url()),keys=mode==='lecture'?['mode','lectureCourse','lecture','lectureVersion']:['mode','audience'],draft='工具往返后仍属于原范围的匿名草稿 '+mode,posts:string[]=[];
  188 |   page.on('request',request=>{if(request.method()==='POST'&&(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())||/\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())))posts.push(request.url());});
  189 |   const assertScope=()=>{const current=new URL(page.url());for(const key of keys)expect(current.searchParams.get(key),'preserved '+key).toBe(original.searchParams.get(key));};
  190 |   await input(page).fill(draft);await page.getByRole('button',{name:'打开学习资料',exact:true}).click();await expect(page).toHaveURL(/view=materials/);assertScope();await page.reload();await expect(page.locator('.sa-top strong')).toHaveText('资料');
  191 |   await page.locator('.ws-navigation').getByRole('button',{name:'Home',exact:true}).click();await expect(input(page)).toHaveValue(draft);assertScope();
  192 |   await page.getByRole('button',{name:'Tools',exact:true}).click();await page.getByRole('menuitem',{name:/Study Planner/}).click();await expect(page).toHaveURL(/view=calendar/);assertScope();
  193 |   await page.locator('.ws-navigation').getByRole('button',{name:'Home',exact:true}).click();await expect(input(page)).toHaveValue(draft);assertScope();await expect(page.getByRole('region',{name:'当前讲座上下文'})).toHaveCount(mode==='lecture'?1:0);expect(posts).toEqual([]);await shot(page,'navigation-retained-'+mode);
  194 | });
  195 | 
```