# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-assistant.spec.ts >> course assistant: a cited answer exposes its source and returns to its complete draft and original message
- Location: tests\e2e\course-assistant.spec.ts:35:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first()
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first() with timeout 15000ms
  - waiting for getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first()

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent 学习工作台":
      - /url: /studio
      - text: StudyAgent
    - button "收起学习导航" [expanded]
    - navigation "工作台主要入口":
      - button "Home": 首页
      - button "Courses": 课程
      - button "Calendar": 学习动态
      - button "History": 历史
      - button "Materials": 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - button "＋ 创建课程"
    - region "开始学习":
      - heading "开始学习" [level=3]
      - link "打开课程 从一节适合自己的课开始。":
        - /url: /studio?view=courses
    - heading "近期活动" [level=3]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页":
      - /url: /learn?subject=math
      - text: 返回学习首页 →
  - text: 独立学习
  - link "创建学习档案":
    - /url: /parent/dashboard
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "Time for flashcards?" [level=1]
  - region "学习工作台助教":
    - text: 当前学习对话
    - button "查找历史"
    - text: 当前会话关键词
    - textbox "检索当前对话"
    - button "查找这段对话" [disabled]
    - log "当前学习对话":
      - article:
        - strong: 我
        - paragraph: "[cite-course] 请解释本讲所选概念。"
      - article:
        - strong: 学习助教
        - paragraph: 先列出已有条件，再说明卡住的一步。用一个独立新例子核查，不凭一次表现确定原因。
        - text: Synthetic assistant · deepseek-v4-flash · 小九AI建议
    - region "提问任务":
      - status: 回答已保存
      - text: DeepSeek V4.1 Flash
      - group: 原问题与记录
    - group: 提问记录（已读取 1 条）
    - region "当前讲座上下文":
      - strong: 社会学思考
      - text: U1·L1 社会学概论
      - button "移除讲座上下文": ×
    - link "返回本讲 ↗":
      - /url: /studio/classroom?unit=0&panel=units&lecture=soc-u1-l1&lectureVersion=6aa6d782f5a7241ac0783cc587f9e1301947df9005730b6a30d481adbe6b6091
    - text: 想一起看看什么
    - textbox "想一起看看什么":
      - /placeholder: 问一个概念，或告诉我你想理清的问题…
      - text: 完整保留的原讲座匿名草稿。
    - button "打开学习资料": ＋
    - button "Tools"
    - text: 模型
    - combobox "选择大模型":
      - option "Auto · 平台默认 DeepSeek V4.1 Flash"
    - group: ⓘ
    - button "发送学习问题": ↑
    - button "Concept Explanation"
    - button "Personal Study Materials Generation"
    - button "Long-files Digestion"
    - button "Problem Solving"
    - link "Visualization":
      - /url: /studio/whiteboards
    - button "下载提问副本"
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { browserEvidence } from './evidence';
  3  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  4  | const evidence = browserEvidence('course-assistant');
  5  | let address = 0;
  6  | async function login(page: Page) {
  7  |   const principal = 'course-ui-' + crypto.randomUUID() + '@local.test', credential = 'Course-ui-20261028-only';
  8  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.17.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  9  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  10 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  11 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/); return actor;
  12 | }
  13 | async function call(actor: any, path: string, body?: unknown) {
  14 |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token },
  15 |     ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  16 |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  17 | }
  18 | async function cited(actor: any) {
  19 |   const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  20 |   const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  21 |   const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  22 |   const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请解释本讲所选概念。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  23 |   await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  24 |   const page = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = page.messages.find((m: any) => m.sender === 'assistant');
  25 |   expect(message.sourceReferences).toHaveLength(1); return { d, session, message, ref: message.sourceReferences[0] };
  26 | }
  27 | test('course assistant: opens the actual frozen source directly without creating a conversation or sending a question', async ({ page }) => {
  28 |   test.setTimeout(100000); await page.setViewportSize({ width: 880, height: 887 }); const actor = await login(page), data = await cited(actor), posts: string[] = [];
  29 |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  30 |   await page.goto(data.ref.href); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  31 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toContainText('社会学'); expect(posts).toEqual([]);
  32 |   await page.reload(); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); expect(posts).toEqual([]);
  33 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-direct.png', fullPage: true });
  34 | });
  35 | test('course assistant: a cited answer exposes its source and returns to its complete draft and original message', async ({ page }) => {
  36 |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  37 |   await page.goto('/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + data.d.fingerprint);
  38 |   const input = page.getByLabel('想一起看看什么', { exact: true }); await expect(input).toBeEnabled();
  39 |   await input.fill('完整保留的原讲座匿名草稿。');
> 40 |   const source = page.getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first(); await expect(source).toBeVisible(); await source.click();
     |                                                                                                                      ^ Error: expect(locator).toBeVisible() failed
  41 |   await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  42 |   await page.getByRole('link', { name: '返回原对话', exact: true }).click(); await expect(input).toHaveValue('完整保留的原讲座匿名草稿。');
  43 |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  44 | });
  45 | 
```