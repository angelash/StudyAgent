# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: course-assistant.spec.ts >> course assistant: a different account cannot retain source content or cause a conversation post
- Location: tests\e2e\course-assistant.spec.ts:63:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('alert')
Expected substring: "不存在"
Error: strict mode violation: getByRole('alert') resolved to 2 elements:
    1) <div role="alert" class="assistant-source-error">…</div> aka getByText('Assistant session not found重新读取出处')
    2) <div role="alert" aria-live="assertive" id="__next-route-announcer__"></div> aka locator('[id="__next-route-announcer__"]')

Call log:
  - Expect "toContainText" getByRole('alert') with timeout 15000ms
  - waiting for getByRole('alert')
    - locator resolved to <div role="alert" aria-live="assertive" id="__next-route-announcer__"></div>
    - unexpected value ""

```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - complementary "学习工作台导航" [ref=f3e4]:
      - generic [ref=f3e5]:
        - generic [ref=f3e6]:
          - link "StudyAgent 学习工作台" [ref=f3e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f3e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f3e11] [cursor=pointer]
        - generic [ref=f3e14]:
          - navigation "工作台主要入口" [ref=f3e15]:
            - button "Home" [ref=f3e16] [cursor=pointer]:
              - generic [ref=f3e19]: 首页
            - button "Courses" [ref=f3e20] [cursor=pointer]:
              - generic [ref=f3e23]: 课程
            - button "Calendar" [ref=f3e24] [cursor=pointer]:
              - generic [ref=f3e27]: 学习动态
            - button "History" [ref=f3e28] [cursor=pointer]:
              - generic [ref=f3e31]: 历史
            - button "Materials" [ref=f3e32] [cursor=pointer]:
              - generic [ref=f3e35]: 资料
            - link "AI Whiteboards" [ref=f3e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f3e39]: AI白板
          - button "＋ 创建课程" [ref=f3e40] [cursor=pointer]
          - generic [ref=f3e41]:
            - region "开始学习" [ref=f3e42]:
              - heading "开始学习" [level=3] [ref=f3e44]
              - link "打开课程 从一节适合自己的课开始。" [ref=f3e45] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f3e46]: 打开课程
                - generic [ref=f3e47]: 从一节适合自己的课开始。
            - generic [ref=f3e48]:
              - heading "近期活动" [level=3] [ref=f3e50]
              - paragraph [ref=f3e52]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f3e54] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f3e55]:
      - generic [ref=f3e56]:
        - generic [ref=f3e57]:
          - generic [ref=f3e58]: 独立学习
          - link "创建学习档案" [ref=f3e59] [cursor=pointer]:
            - /url: /parent/dashboard
        - generic [ref=f3e60]:
          - link "教学课堂 ↗" [ref=f3e61] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f3e62] [cursor=pointer]:
            - /url: /
      - generic [ref=f3e63]:
        - generic [ref=f3e64]:
          - button "Craft Courses" [ref=f3e65] [cursor=pointer]
          - button "Instant Assistance" [ref=f3e66] [cursor=pointer]
        - region [ref=f3e67]:
          - generic [ref=f3e68]:
            - text: TEACHING SOURCE
            - heading "当时的教学出处" [level=1] [ref=f3e69]
            - paragraph [ref=f3e70]: 保留本次回答使用的教学内容与范围。
          - navigation "出处返回" [ref=f3e71]:
            - link "返回原对话" [ref=f3e72] [cursor=pointer]:
              - /url: /studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=6aa6d782f5a7241ac0783cc587f9e1301947df9005730b6a30d481adbe6b6091
          - alert [ref=f3e73]:
            - paragraph [ref=f3e74]: Assistant session not found
            - button "重新读取出处" [ref=f3e75] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { browserEvidence } from './evidence';
  3  | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  4  | const evidence = browserEvidence('course-assistant');
  5  | let address = 0;
  6  | async function login(page: Page) {
  7  |   const principal = 'course-ui-' + crypto.randomUUID() + '@local.test', credential = 'Course-ui-20261028-only';
  8  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.17.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  9  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  10 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  11 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/); return actor;
  12 | }
  13 | async function call(actor: any, path: string, body?: unknown) {
  14 |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token },
  15 |     ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  16 |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  17 | }
  18 | async function cited(actor: any) {
  19 |   const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  20 |   const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  21 |   const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  22 |   const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请解释本讲所选概念。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  23 |   await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  24 |   const page = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = page.messages.find((m: any) => m.sender === 'assistant');
  25 |   expect(message.sourceReferences).toHaveLength(1); return { d, session, message, ref: message.sourceReferences[0] };
  26 | }
  27 | test('course assistant: opens the actual frozen source directly without creating a conversation or sending a question', async ({ page }) => {
  28 |   test.setTimeout(100000); await page.setViewportSize({ width: 880, height: 887 }); const actor = await login(page), data = await cited(actor), posts: string[] = [];
  29 |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
  30 |   await page.goto(data.ref.href); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  31 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toContainText('社会学'); expect(posts).toEqual([]);
  32 |   await page.reload(); await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible(); expect(posts).toEqual([]);
  33 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-direct.png', fullPage: true });
  34 | });
  35 | test('course assistant: a cited answer exposes its source and returns to its complete draft and original message', async ({ page }) => {
  36 |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor);
  37 |   await page.goto('/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + data.d.fingerprint);
  38 |   const input = page.getByLabel('想一起看看什么', { exact: true }); await expect(input).toBeEnabled();
  39 |   await input.fill('完整保留的原讲座匿名草稿。');
  40 |   const source = page.getByRole('navigation', { name: '本次回答的教学出处' }).getByRole('link').first(); await expect(source).toBeVisible(); await source.click();
  41 |   await expect(page.getByRole('heading', { name: '当时的教学出处', exact: true })).toBeVisible();
  42 |   await page.getByRole('link', { name: '返回原对话', exact: true }).click(); await expect(input).toHaveValue('完整保留的原讲座匿名草稿。');
  43 |   await expect(page.locator('[data-message-id="' + data.message.id + '"]')).toBeFocused();
  44 | });
  45 | 
  46 | test('course assistant: narrow source views retain every table cell and original teaching code without running it', async ({ page }) => {
  47 |   test.setTimeout(100000); await page.setViewportSize({ width: 390, height: 844 }); const actor = await login(page), data = await cited(actor);
  48 |   const table = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-6');
  49 |   await page.goto(table.reference.href); await expect(page.getByRole('table')).toBeVisible();
  50 |   const expected = table.sections.flatMap((s: any) => s.blocks).find((b: any) => b.table).table;
  51 |   for (const header of expected.headers) await expect(page.getByRole('columnheader', { name: header, exact: true })).toBeVisible();
  52 |   for (const row of expected.rows) for (const cell of row) await expect(page.getByRole('cell', { name: cell, exact: true })).toBeVisible();
  53 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  54 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-table-390.png', fullPage: true });
  55 |   const source = await call(actor, '/ai/assistant/sessions/' + data.session.id + '/sources/lecture-1-3'), originalCode = source.sections.flatMap((s: any) => s.blocks).find((b: any) => b.code !== undefined).code;
  56 |   const runs: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /(?:code|run|execute)/.test(r.url())) runs.push(r.url()); });
  57 |   await page.goto(source.reference.href); await expect(page.getByLabel('原教学代码')).toHaveText(originalCode);
  58 |   await expect(page.getByRole('list', { name: '图形完整标注' })).toContainText('行业岗位变化'); expect(runs).toEqual([]);
  59 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  60 |   if (!process.env.CI) await page.screenshot({ path: evidence + '/source-code-390.png', fullPage: true });
  61 | });
  62 | 
  63 | test('course assistant: a different account cannot retain source content or cause a conversation post', async ({ page }) => {
  64 |   test.setTimeout(100000); const actor = await login(page), data = await cited(actor); await page.goto(data.ref.href);
  65 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toBeVisible();
  66 |   await page.context().clearCookies(); await login(page); const posts: string[] = [];
  67 |   page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(r.url())) posts.push(r.url()); });
> 68 |   await page.goto(data.ref.href); await expect(page.getByRole('alert')).toContainText('不存在');
     |                                                                         ^ Error: expect(locator).toContainText(expected) failed
  69 |   await expect(page.getByRole('region', { name: '冻结教学内容' })).toHaveCount(0); expect(posts).toEqual([]);
  70 | });
  71 | 
```