# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio-assistant.spec.ts >> lecture-assistant: a lost receipt is recovered with the original request and no duplicate post
- Location: tests\e2e\studio-assistant.spec.ts:84:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')
Expected: 2
Received: 0
Timeout:  15000ms

Call log:
  - Expect "toHaveCount" getByRole('log', { name: '当前学习对话' }).locator('.assistant-message') with timeout 15000ms
  - waiting for getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')
    33 × locator resolved to 0 elements
       - unexpected value "0"

```

# Page snapshot

```yaml
- generic [active] [ref=f3e1]:
  - alert [ref=f3e2]
  - main [ref=f3e3]:
    - complementary "学习工作台导航" [ref=f3e4]:
      - generic [ref=f3e5]:
        - generic [ref=f3e6]:
          - link "StudyAgent 学习工作台" [ref=f3e7] [cursor=pointer]:
            - /url: /studio
            - generic [ref=f3e10]: StudyAgent
          - button "收起学习导航" [expanded] [ref=f3e11] [cursor=pointer]
        - generic [ref=f3e14]:
          - navigation "工作台主要入口" [ref=f3e15]:
            - button "Home" [ref=f3e16] [cursor=pointer]:
              - generic [ref=f3e19]: 首页
            - button "Courses" [ref=f3e20] [cursor=pointer]:
              - generic [ref=f3e23]: 课程
            - button "Calendar" [ref=f3e24] [cursor=pointer]:
              - generic [ref=f3e27]: 学习动态
            - button "History" [ref=f3e28] [cursor=pointer]:
              - generic [ref=f3e31]: 历史
            - button "Materials" [ref=f3e32] [cursor=pointer]:
              - generic [ref=f3e35]: 资料
            - link "AI Whiteboards" [ref=f3e36] [cursor=pointer]:
              - /url: /studio/whiteboards
              - generic [ref=f3e39]: AI白板
          - button "＋ 创建课程" [ref=f3e40] [cursor=pointer]
          - generic [ref=f3e41]:
            - region "开始学习" [ref=f3e42]:
              - heading "开始学习" [level=3] [ref=f3e44]
              - link "打开课程 从一节适合自己的课开始。" [ref=f3e45] [cursor=pointer]:
                - /url: /studio?view=courses
                - generic [ref=f3e46]: 打开课程
                - generic [ref=f3e47]: 从一节适合自己的课开始。
            - generic [ref=f3e48]:
              - heading "近期活动" [level=3] [ref=f3e50]
              - paragraph [ref=f3e52]: 开始学习后，活动会出现在这里。
        - link "返回学习首页" [ref=f3e54] [cursor=pointer]:
          - /url: /learn?subject=math
          - text: 返回学习首页 →
    - generic [ref=f3e55]:
      - generic [ref=f3e56]:
        - generic [ref=f3e57]:
          - generic [ref=f3e58]: 独立学习
          - link "创建学习档案" [ref=f3e59] [cursor=pointer]:
            - /url: /parent/dashboard
        - generic [ref=f3e60]:
          - link "教学课堂 ↗" [ref=f3e61] [cursor=pointer]:
            - /url: /studio/classroom
          - link "学习观察室" [ref=f3e62] [cursor=pointer]:
            - /url: /
      - generic [ref=f3e63]:
        - generic [ref=f3e64]:
          - button "Craft Courses" [ref=f3e65] [cursor=pointer]
          - button "Instant Assistance" [ref=f3e66] [cursor=pointer]
        - generic [ref=f3e67]:
          - heading "Time for flashcards?" [level=1] [ref=f3e69]
          - region "学习工作台助教" [ref=f3e70]:
            - generic [ref=f3e71]:
              - generic [ref=f3e72]:
                - generic [ref=f3e73]: 当前学习对话
                - button "查找历史" [ref=f3e74] [cursor=pointer]
              - region "提问任务" [ref=f3e75]:
                - generic [ref=f3e76]:
                  - status [ref=f3e77]: 回答已保存
                  - generic [ref=f3e78]: DeepSeek V4.1 Flash
                - group [ref=f3e79]:
                  - generic "原问题与记录" [ref=f3e80] [cursor=pointer]
              - group [ref=f3e81]:
                - generic "提问记录（已读取 1 条）" [ref=f3e82] [cursor=pointer]
              - generic [ref=f3e83]:
                - generic [ref=f3e84]:
                  - region "当前讲座上下文" [ref=f3e85]:
                    - generic [aria-hidden] [ref=f3e86]: ▣
                    - generic [ref=f3e87]:
                      - strong [ref=f3e88]: 社会学思考
                      - generic [ref=f3e89]:
                        - generic [ref=f3e90]: U1·L1
                        - generic [ref=f3e91]: 社会学概论
                    - button "移除讲座上下文" [ref=f3e92] [cursor=pointer]: ×
                  - link "返回本讲 ↗" [ref=f3e93] [cursor=pointer]:
                    - /url: /studio/classroom?unit=0&panel=units&lecture=soc-u1-l1&lectureVersion=2b8130e9feaaba13118b9007fbeffceafe9d6b914feee6cdd59a314f8e270251
                  - generic [ref=f3e94]:
                    - generic [ref=f3e95]: 想一起看看什么
                    - textbox "想一起看看什么" [ref=f3e96]:
                      - /placeholder: 问一个概念，或告诉我你想理清的问题…
                  - generic [ref=f3e97]:
                    - generic [ref=f3e98]:
                      - button "打开学习资料" [ref=f3e99] [cursor=pointer]: ＋
                      - button "Tools" [ref=f3e100] [cursor=pointer]:
                        - generic [aria-hidden] [ref=f3e101]: ☷
                    - generic [ref=f3e103]:
                      - generic [ref=f3e104]:
                        - generic [ref=f3e105]:
                          - generic [ref=f3e106]: 模型
                          - combobox "选择大模型" [ref=f3e107] [cursor=pointer]:
                            - option "Auto · 平台默认 DeepSeek V4.1 Flash"
                            - option "GPT-6.1 Sol"
                            - option "GPT-6 Astra"
                            - option "GPT-6 Luna"
                            - option "Grok-4.7"
                            - option "GLM-5.3 Flash"
                            - option "DeepSeek V4.1 Flash · 默认" [selected]
                            - option "Claude Opus 5.5"
                            - option "Claude Sonnet 5"
                            - option "GPT-6 Sol"
                            - option "GPT-5.6 Sol"
                            - option "GPT-5.6 Terra"
                            - option "GPT-5.6 Luna"
                            - option "GPT-5.5"
                            - option "Grok-4.6"
                            - option "GLM-5.2"
                            - option "GLM-5.3"
                            - option "Claude Opus 5"
                            - option "Claude Fable 5.1"
                            - option "MiMo V2.6 Pro"
                            - option "MiMo V2.6 Flash"
                            - option "MiMo V2.6 Pro Ultraspeed"
                            - option "Qwen3.8 Max"
                        - group [ref=f3e108]:
                          - generic "模型文字检查说明" [ref=f3e109] [cursor=pointer]: ⓘ
                      - button "发送学习问题" [disabled] [ref=f3e110]: ↑
                - generic [ref=f3e112]:
                  - generic [ref=f3e113]:
                    - button "Concept Explanation" [ref=f3e114] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f3e115]: ⌕
                      - text: Concept Explanation
                    - button "Personal Study Materials Generation" [ref=f3e116] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f3e117]: ▤
                      - text: Personal Study Materials Generation
                    - button "Long-files Digestion" [ref=f3e118] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f3e119]: ▱
                      - text: Long-files Digestion
                  - generic [ref=f3e120]:
                    - button "Problem Solving" [ref=f3e121] [cursor=pointer]:
                      - generic [aria-hidden] [ref=f3e122]: ♧
                      - text: Problem Solving
                    - link "Visualization" [ref=f3e123] [cursor=pointer]:
                      - /url: /studio/whiteboards
                      - generic [aria-hidden] [ref=f3e124]: ▦
                      - text: Visualization
              - button "下载提问副本" [ref=f3e125] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { mkdirSync, writeFileSync } from 'node:fs';
  3   | import { browserEvidence } from './evidence';
  4   | 
  5   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api';
  6   | const evidence = browserEvidence('studio-assistant');
  7   | let address = 0;
  8   | async function login(page: Page) {
  9   |   const id = crypto.randomUUID(), principal = 'lecture-browser-' + id + '@local.test', credential = 'Lecture-browser-only-' + id;
  10  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.18.15.' + (++address) }, body: JSON.stringify({ principal, credential }) });
  11  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
  12  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  13  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  |   return actor;
  15  | }
  16  | async function call(actor: any, path: string, body?: unknown) {
  17  |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  18  |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  19  | }
  20  | const input = (page: Page) => page.getByLabel('想一起看看什么', { exact: true });
  21  | const task = (page: Page) => page.getByRole('region', { name: '提问任务', exact: true });
  22  | async function lecture(page: Page, width = 1280) {
  23  |   await page.setViewportSize({ width, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  24  |   await page.goto('/studio/classroom'); await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  25  |   await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/); await expect(input(page)).toBeEnabled(); return actor;
  26  | }
  27  | async function shot(page: Page, name: string) { if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); await page.evaluate(async () => { await document.fonts.ready; }); await page.screenshot({ path: evidence + '/' + name + '.png', fullPage: true }); } }
  28  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  29  | 
  30  | test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  31  |   test.setTimeout(90000); await page.setViewportSize({ width: 1280, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); await login(page);
  32  |   const classroomPosts: string[] = [], errors: string[] = [];
  33  |   page.on('pageerror', error => errors.push(error.message));
  34  |   page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  35  |   try {
  36  |     await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  37  |     await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  38  |     await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
  39  |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  40  |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
  41  |     await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
  42  |     expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
  43  |     await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考'); await expect(input(page)).toBeEnabled();
  44  |   } finally {
  45  |     if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  46  |   }
  47  | });
  48  | 
  49  | for (const width of [390, 768, 880, 1440]) test(`lecture-assistant: usable course entry, composer and complete model selection at${width}`, async ({ page }) => {
  50  |   test.setTimeout(90000); await lecture(page, width);
  51  |   await expect(page.getByRole('region', { name: '当前讲座上下文' })).toBeVisible();
  52  |   const picker = page.getByRole('combobox', { name: '选择大模型', exact: true }); await expect(picker.locator('option')).toHaveCount(23); await expect(picker).toHaveValue('deepseek-v4-flash');
  53  |   await page.getByLabel('模型文字检查说明').click(); await expect(page.getByText('尚未进行文字检查', { exact: true })).toBeVisible();
  54  |   await page.getByLabel('模型文字检查说明').click();
  55  |   await page.getByRole('button', { name: 'Tools', exact: true }).click(); await expect(page.getByRole('menuitem', { name: /Whiteboard session/ })).toBeVisible();
  56  |   await page.keyboard.press('Escape'); await expect(page.getByRole('menu', { name: '' })).toHaveCount(0);
  57  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  58  |   await shot(page, 'entry-' + width);
  59  | });
  60  | 
  61  | test('lecture-assistant: lecture removal, back and reload preserve separate unsent drafts without sending', async ({ page }) => {
  62  |   test.setTimeout(90000); await lecture(page); const posts: unknown[] = [];
  63  |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  64  |   await input(page).fill('原讲座中尚未发送的匿名草稿。'); const original = page.url();
  65  |   await page.getByRole('button', { name: '移除讲座上下文' }).click(); await expect(page).toHaveURL(/audience=independent/);
  66  |   await expect(page.getByRole('region', { name: '当前讲座上下文' })).toHaveCount(0); await expect(input(page)).toBeEnabled(); await expect(input(page)).toHaveValue('');
  67  |   await input(page).fill('普通独立学习中尚未发送的匿名草稿。');
  68  |   await page.goBack(); await expect(page).toHaveURL(original); await expect(input(page)).toHaveValue('原讲座中尚未发送的匿名草稿。');
  69  |   await page.goForward(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。'); await page.reload(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。');
  70  |   expect(posts).toEqual([]); await shot(page, 'separate-drafts');
  71  | });
  72  | 
  73  | test('lecture-assistant: durable pending turn resumes after refresh with its original model', async ({ page }) => {
  74  |   test.setTimeout(120000); await lecture(page); const posts: any[] = [];
  75  |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  76  |   await input(page).fill('[assistant-pause-once] 请用匿名例子比较本讲的概念。'); await page.getByRole('button', { name: '发送学习问题' }).click(); await expect(task(page)).toBeVisible();
  77  |   await page.reload(); await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 });
  78  |   expect(posts).toHaveLength(1); expect(posts[0].modelId).toBe('deepseek-v4-flash');
  79  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2);
  80  |   await page.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6.1-sol'); await expect(task(page)).toContainText('DeepSeek V4.1 Flash');
  81  |   await shot(page, 'saved-original-model');
  82  | });
  83  | 
  84  | test('lecture-assistant: a lost receipt is recovered with the original request and no duplicate post', async ({ page }) => {
  85  |   test.setTimeout(120000); await lecture(page); let submitted: any = null, count = 0;const allPosts:any[]=[];
  86  |   page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url()))allPosts.push(request.postDataJSON());});
  87  |   await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/, async route => {
  88  |     if (route.request().method() === 'POST') { count++; submitted = route.request().postDataJSON(); await route.fetch(); await route.abort('failed'); } else await route.continue();
  89  |   });
  90  |   await input(page).fill('只发送一次的匿名讲座问题。'); await page.getByRole('button', { name: '发送学习问题' }).click();
  91  |   await expect(page.getByRole('complementary', { name: '待确认提问' })).toBeVisible();
  92  |   expect(submitted.requestKey).toBeTruthy(); await page.unrouteAll({ behavior: 'wait' }); await page.reload();
  93  |   await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 }); expect(count).toBe(1);expect(allPosts).toHaveLength(1);expect(allPosts[0].requestKey).toBe(submitted.requestKey);
> 94  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2); await shot(page, 'recovered-original-request');
      |                                                                                         ^ Error: expect(locator).toHaveCount(expected) failed
  95  | });
  96  | 
  97  | test('lecture-assistant: a retained original version opens from the server without creating or resending a session', async ({ page }) => {
  98  |   test.setTimeout(120000); await page.setViewportSize({ width: 880, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  99  |   const original = await call(actor, '/qa/assistant/lecture-history', {}), posts: string[] = [];
  100 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(request.url())) posts.push(request.url()); });
  101 |   await page.goto(original.href); await expect(page.getByRole('log', { name: '当前学习对话' })).toContainText('LECTURE_OLD_HISTORY_MARKER');
  102 |   await expect(input(page)).toBeDisabled(); await expect(page.getByRole('button', { name: '发送学习问题' })).toBeDisabled(); expect(posts).toEqual([]);
  103 |   await shot(page, 'retained-original-readonly');
  104 |   await page.getByRole('button', { name: '打开当前讲座版本', exact: true }).click(); await expect(input(page)).toBeEnabled();
  105 |   await expect(page.getByRole('log', { name: '当前学习对话' })).not.toContainText('LECTURE_OLD_HISTORY_MARKER');
  106 |   expect(posts.some(url => /\/sessions$/.test(url))).toBe(true); expect(posts.some(url => /\/turns$/.test(url))).toBe(false);
  107 |   expect((await call(actor, '/ai/assistant/sessions/' + original.sessionId + '/messages/page')).messages).toHaveLength(2);
  108 | });
  109 | 
  110 | test('lecture-assistant: failed initialization after a child change cannot retain the previous active session', async ({ page }) => {
  111 |   test.setTimeout(120000); const actor = await login(page), children:Array<{id:string}> = [];
  112 |   for (const nickname of ['匿名档案甲', '匿名档案乙']) children.push((await call(actor, '/students', { nickname, grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile);
  113 |   await page.goto('/studio'); await expect(page.getByRole('combobox', { name: '学习档案', exact: true }).locator('option')).toHaveCount(2);await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[0].id);await expect(page.getByRole('combobox', { name: '学习档案', exact: true })).toHaveValue(children[0].id); await page.getByRole('button', { name: 'Instant Assistance', exact: true }).click();
  114 |   await expect(input(page)).toBeEnabled(); await input(page).fill('只属于匿名档案甲的未发送草稿。'); const posts: string[] = [];
  115 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.url()); });
  116 |   await page.route(/\/ai\/assistant\/sessions$/, async route => {
  117 |     if (route.request().method() === 'POST' && route.request().postDataJSON().studentId === children[1].id) await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ data: null, error: { code: 'synthetic_unavailable', message: '匿名上下文初始化暂不可用' }, meta: {} }) });
  118 |     else await route.continue();
  119 |   });
  120 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[1].id); await expect(page.getByText('匿名上下文初始化暂不可用', { exact: true })).toBeVisible();
  121 |   await expect(input(page)).toBeDisabled(); expect(posts).toEqual([]);
  122 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[0].id); await expect(input(page)).toHaveValue('只属于匿名档案甲的未发送草稿。');
  123 |   await page.unrouteAll({ behavior: 'wait' });
  124 | });
  125 | 
```