# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: studio-assistant.spec.ts >> lecture-assistant: failed initialization after a child change cannot retain the previous active session
- Location: tests\e2e\studio-assistant.spec.ts:110:5

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator: getByRole('combobox', { name: '学习档案', exact: true })
Expected: "student_d0dffd09-b9b6-4cf3-b195-56e8fa52b24a"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toHaveValue" getByRole('combobox', { name: '学习档案', exact: true }) with timeout 15000ms
  - waiting for getByRole('combobox', { name: '学习档案', exact: true })

```

```yaml
- alert
- main:
  - complementary "学习工作台导航":
    - link "StudyAgent 学习工作台":
      - /url: /studio
      - text: StudyAgent
    - button "收起学习导航" [expanded]
    - navigation "工作台主要入口":
      - button "Home": 首页
      - button "Courses": 课程
      - button "Calendar": 学习动态
      - button "History": 历史
      - button "Materials": 资料
      - link "AI Whiteboards":
        - /url: /studio/whiteboards
        - text: AI白板
    - button "＋ 创建课程"
    - region "开始学习":
      - heading "开始学习" [level=3]
      - link "打开课程 从一节适合自己的课开始。":
        - /url: /studio?view=courses
    - heading "近期活动" [level=3]
    - paragraph: 开始学习后，活动会出现在这里。
    - link "返回学习首页":
      - /url: /learn?subject=math&student=student_d0dffd09-b9b6-4cf3-b195-56e8fa52b24a
      - text: 返回学习首页 →
  - link "创建学习档案":
    - /url: /parent/dashboard
  - combobox "学科":
    - option "数学" [selected]
    - option "语文"
    - option "英语"
  - link "教学课堂 ↗":
    - /url: /studio/classroom
  - link "学习观察室":
    - /url: /
  - button "Craft Courses"
  - button "Instant Assistance"
  - heading "把下一步，做成一条走得通的路。" [level=1]
  - paragraph: 从已确认学习范围生成课程蓝图，审阅结构和来源后再开始。
  - textbox "围绕哪段学习内容设计课程？"
  - text: ＋ 资料
  - button "Concept Explanation"
  - text: 语音 模型
  - combobox "选择大模型":
    - option "Auto · 平台默认 DeepSeek V4.1 Flash"
  - text: 尚未进行文字检查
  - button "↑"
  - button "可视化 用图形解释异分母加法 通分、合并与验算"
  - button "个性化练习 从我的已知点生成练习 只覆盖已确认范围"
  - button "主动学习 看看今天最值得做什么 按教育优先级排序"
  - heading "你的学习路径" [level=2]
  - button "创建课程"
  - heading "还没有课程" [level=3]
  - paragraph: 先确认学习范围，再从已学知识生成可审核蓝图。
  - button "生成第一门课程"
  - complementary:
    - article:
      - text: LEARNER SNAPSHOT
      - heading "学习档案" [level=2]
      - text: — 年级
      - strong: "0"
      - text: / 0 已有点有稳定证据 0 已确认知识点 0 日历安排
    - article:
      - text: NEXT BEST ACTION
      - button "全部 →"
    - article:
      - text: RECENT WHITEBOARDS
      - button "新建"
      - paragraph: 还没有白板。输入一个主题并选择 Whiteboard session。
    - article:
      - text: SYNC STATUS
      - button "日历 →"
      - paragraph: 0 个 LMS / 日历来源 · 0 个安排
      - text: 同步只读取课程日期；学习掌握仍由独立测量形成。
```

# Test source

```ts
  13  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  14  |   return actor;
  15  | }
  16  | async function call(actor: any, path: string, body?: unknown) {
  17  |   const response = await fetch(api + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + actor.token }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  18  |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  19  | }
  20  | const input = (page: Page) => page.getByLabel('想一起看看什么', { exact: true });
  21  | const task = (page: Page) => page.getByRole('region', { name: '提问任务', exact: true });
  22  | async function lecture(page: Page, width = 1280) {
  23  |   await page.setViewportSize({ width, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  24  |   await page.goto('/studio/classroom'); await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  25  |   await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/); await expect(input(page)).toBeEnabled(); return actor;
  26  | }
  27  | async function shot(page: Page, name: string) { if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); await page.evaluate(async () => { await document.fonts.ready; }); await page.screenshot({ path: evidence + '/' + name + '.png', fullPage: true }); } }
  28  | test.afterEach(async({page})=>{await page.unrouteAll({behavior:'wait'});});
  29  | 
  30  | test('lecture-assistant: directory opens a whole lecture in the independent assistant without starting a micro lesson', async ({ page }) => {
  31  |   test.setTimeout(90000); await page.setViewportSize({ width: 1280, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); await login(page);
  32  |   const classroomPosts: string[] = [], errors: string[] = [];
  33  |   page.on('pageerror', error => errors.push(error.message));
  34  |   page.on('request', request => { if (request.method() === 'POST' && /\/learning\/classroom\/sessions(?:\?|$)/.test(request.url())) classroomPosts.push(request.url()); });
  35  |   try {
  36  |     await page.goto('/studio/classroom'); await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  37  |     await page.getByRole('button', { name: '获取帮助', exact: true }).first().click();
  38  |     await expect(page).toHaveURL(/\/studio\?[^#]*mode=instant/);
  39  |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考');
  40  |     await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('U1·L1');
  41  |     await expect(page.getByLabel('想一起看看什么')).toBeEnabled();
  42  |     expect(classroomPosts).toEqual([]); expect(errors).toEqual([]);
  43  |     await page.reload(); await expect(page.getByRole('region', { name: '当前讲座上下文' })).toContainText('社会学思考'); await expect(input(page)).toBeEnabled();
  44  |   } finally {
  45  |     if (!process.env.CI) { mkdirSync(evidence, { recursive: true }); writeFileSync(evidence + '/directory-state.json', JSON.stringify({ url: page.url(), classroomPosts, errors }, null, 2)); await page.screenshot({ path: evidence + '/directory-state.png', fullPage: true }); }
  46  |   }
  47  | });
  48  | 
  49  | for (const width of [390, 768, 880, 1440]) test(`lecture-assistant: usable course entry, composer and complete model selection at${width}`, async ({ page }) => {
  50  |   test.setTimeout(90000); await lecture(page, width);
  51  |   await expect(page.getByRole('region', { name: '当前讲座上下文' })).toBeVisible();
  52  |   const picker = page.getByRole('combobox', { name: '选择大模型', exact: true }); await expect(picker.locator('option')).toHaveCount(23); await expect(picker).toHaveValue('deepseek-v4-flash');
  53  |   await page.getByLabel('模型文字检查说明').click(); await expect(page.getByText('尚未进行文字检查', { exact: true })).toBeVisible();
  54  |   await page.getByLabel('模型文字检查说明').click();
  55  |   await page.getByRole('button', { name: 'Tools', exact: true }).click(); await expect(page.getByRole('menuitem', { name: /Whiteboard session/ })).toBeVisible();
  56  |   await page.keyboard.press('Escape'); await expect(page.getByRole('menu', { name: '' })).toHaveCount(0);
  57  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  58  |   await shot(page, 'entry-' + width);
  59  | });
  60  | 
  61  | test('lecture-assistant: lecture removal, back and reload preserve separate unsent drafts without sending', async ({ page }) => {
  62  |   test.setTimeout(90000); await lecture(page); const posts: unknown[] = [];
  63  |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  64  |   await input(page).fill('原讲座中尚未发送的匿名草稿。'); const original = page.url();
  65  |   await page.getByRole('button', { name: '移除讲座上下文' }).click(); await expect(page).toHaveURL(/audience=independent/);
  66  |   await expect(page.getByRole('region', { name: '当前讲座上下文' })).toHaveCount(0); await expect(input(page)).toBeEnabled(); await expect(input(page)).toHaveValue('');
  67  |   await input(page).fill('普通独立学习中尚未发送的匿名草稿。');
  68  |   await page.goBack(); await expect(page).toHaveURL(original); await expect(input(page)).toHaveValue('原讲座中尚未发送的匿名草稿。');
  69  |   await page.goForward(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。'); await page.reload(); await expect(input(page)).toHaveValue('普通独立学习中尚未发送的匿名草稿。');
  70  |   expect(posts).toEqual([]); await shot(page, 'separate-drafts');
  71  | });
  72  | 
  73  | test('lecture-assistant: durable pending turn resumes after refresh with its original model', async ({ page }) => {
  74  |   test.setTimeout(120000); await lecture(page); const posts: any[] = [];
  75  |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.postDataJSON()); });
  76  |   await input(page).fill('[assistant-pause-once] 请用匿名例子比较本讲的概念。'); await page.getByRole('button', { name: '发送学习问题' }).click(); await expect(task(page)).toBeVisible();
  77  |   await page.reload(); await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 });
  78  |   expect(posts).toHaveLength(1); expect(posts[0].modelId).toBe('deepseek-v4-flash');
  79  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2);
  80  |   await page.getByRole('combobox', { name: '选择大模型', exact: true }).selectOption('gpt-6.1-sol'); await expect(task(page)).toContainText('DeepSeek V4.1 Flash');
  81  |   await shot(page, 'saved-original-model');
  82  | });
  83  | 
  84  | test('lecture-assistant: a lost receipt is recovered with the original request and no duplicate post', async ({ page }) => {
  85  |   test.setTimeout(120000); await lecture(page); let submitted: any = null, count = 0;const allPosts:any[]=[];
  86  |   page.on('request',request=>{if(request.method()==='POST'&&/\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url()))allPosts.push(request.postDataJSON());});
  87  |   await page.route(/\/ai\/assistant\/sessions\/[^/?]+\/turns$/, async route => {
  88  |     if (route.request().method() === 'POST') { count++; submitted = route.request().postDataJSON(); await route.fetch(); await route.abort('failed'); } else await route.continue();
  89  |   });
  90  |   await input(page).fill('只发送一次的匿名讲座问题。'); await page.getByRole('button', { name: '发送学习问题' }).click();
  91  |   await expect(page.getByRole('complementary', { name: '待确认提问' })).toBeVisible();
  92  |   expect(submitted.requestKey).toBeTruthy(); await page.unrouteAll({ behavior: 'wait' }); await page.reload();
  93  |   await expect(task(page).getByRole('status')).toHaveText('回答已保存', { timeout: 45000 }); expect(count).toBe(1);expect(allPosts).toHaveLength(1);expect(allPosts[0].requestKey).toBe(submitted.requestKey);
  94  |   await expect(page.getByRole('log', { name: '当前学习对话' }).locator('.assistant-message')).toHaveCount(2); await shot(page, 'recovered-original-request');
  95  | });
  96  | 
  97  | test('lecture-assistant: a retained original version opens from the server without creating or resending a session', async ({ page }) => {
  98  |   test.setTimeout(120000); await page.setViewportSize({ width: 880, height: 887 }); await page.emulateMedia({ reducedMotion: 'reduce' }); const actor = await login(page);
  99  |   const original = await call(actor, '/qa/assistant/lecture-history', {}), posts: string[] = [];
  100 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions(?:\/|$)/.test(request.url())) posts.push(request.url()); });
  101 |   await page.goto(original.href); await expect(page.getByRole('log', { name: '当前学习对话' })).toContainText('LECTURE_OLD_HISTORY_MARKER');
  102 |   await expect(input(page)).toBeDisabled(); await expect(page.getByRole('button', { name: '发送学习问题' })).toBeDisabled(); expect(posts).toEqual([]);
  103 |   await shot(page, 'retained-original-readonly');
  104 |   await page.getByRole('button', { name: '打开当前讲座版本', exact: true }).click(); await expect(input(page)).toBeEnabled();
  105 |   await expect(page.getByRole('log', { name: '当前学习对话' })).not.toContainText('LECTURE_OLD_HISTORY_MARKER');
  106 |   expect(posts.some(url => /\/sessions$/.test(url))).toBe(true); expect(posts.some(url => /\/turns$/.test(url))).toBe(false);
  107 |   expect((await call(actor, '/ai/assistant/sessions/' + original.sessionId + '/messages/page')).messages).toHaveLength(2);
  108 | });
  109 | 
  110 | test('lecture-assistant: failed initialization after a child change cannot retain the previous active session', async ({ page }) => {
  111 |   test.setTimeout(120000); const actor = await login(page), children:Array<{id:string}> = [];
  112 |   for (const nickname of ['匿名档案甲', '匿名档案乙']) children.push((await call(actor, '/students', { nickname, grade: 3, preferredSessionMinutes: 15, defaultVersionMap: { math: '', chinese: '', english: '' } })).profile);
> 113 |   await page.goto('/studio'); await expect(page.getByRole('combobox', { name: '学习档案', exact: true }).locator('option')).toHaveCount(2);await page.getByRole('combobox',{name:'学习档案',exact:true}).selectOption(children[0].id);await expect(page.getByRole('combobox', { name: '学习档案', exact: true })).toHaveValue(children[0].id); await page.getByRole('button', { name: 'Instant Assistance', exact: true }).click();
      |                                                                                                                                                                                                                                                                                                       ^ Error: expect(locator).toHaveValue(expected) failed
  114 |   await expect(input(page)).toBeEnabled(); await input(page).fill('只属于匿名档案甲的未发送草稿。'); const posts: string[] = [];
  115 |   page.on('request', request => { if (request.method() === 'POST' && /\/ai\/assistant\/sessions\/[^/?]+\/turns$/.test(request.url())) posts.push(request.url()); });
  116 |   await page.route(/\/ai\/assistant\/sessions$/, async route => {
  117 |     if (route.request().method() === 'POST' && route.request().postDataJSON().studentId === children[1].id) await route.fulfill({ status: 503, contentType: 'application/json', body: JSON.stringify({ data: null, error: { code: 'synthetic_unavailable', message: '匿名上下文初始化暂不可用' }, meta: {} }) });
  118 |     else await route.continue();
  119 |   });
  120 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[1].id); await expect(page.getByText('匿名上下文初始化暂不可用', { exact: true })).toBeVisible();
  121 |   await expect(input(page)).toBeDisabled(); expect(posts).toEqual([]);
  122 |   await page.getByRole('combobox', { name: '学习档案', exact: true }).selectOption(children[0].id); await expect(input(page)).toHaveValue('只属于匿名档案甲的未发送草稿。');
  123 |   await page.unrouteAll({ behavior: 'wait' });
  124 | });
  125 | 
```