import base from '../../playwright.config';
import path from 'node:path';
const root=path.resolve(__dirname,'../..');
export default {...base,testDir:path.join(root,'tests/e2e'),outputDir:path.join(root,'data/qa/registration-pressure-browser-output'),globalSetup:path.join(__dirname,'registration-pressure-setup.cjs'),webServer:(base.webServer as any[]).map(server=>({...server,cwd:root}))};
