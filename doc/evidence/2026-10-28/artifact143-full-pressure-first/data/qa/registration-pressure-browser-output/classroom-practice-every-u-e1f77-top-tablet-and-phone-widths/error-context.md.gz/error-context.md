# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-practice.spec.ts >> every unit has a readable data or diagram practice example at desktop, tablet and phone widths
- Location: tests\e2e\classroom-practice.spec.ts:59:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { mkdirSync } from 'node:fs';
  3  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  4  | const { classroomAnswerKey } = require('../../apps/api/dist/apps/api/src/modules/learning/classroom-curriculum.js');
  5  | async function login(page: Page) {
  6  |   const key = `${Date.now()}-${Math.floor(Math.random() * 100000)}`, principal = `practice-${key}@local.test`, credential = `Practice-${key}`;
  7  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({principal,credential}) });
> 8  |   expect(response.status).toBe(201); const actor = (await response.json()).data;
     |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  9  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  10 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  11 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  12 |   return actor;
  13 | }
  14 | async function capture(page: Page, name: string) {
  15 |   if (!process.env.E2E_PRACTICE_SNAPSHOT) return;
  16 |   mkdirSync('data/qa/classroom-practice', { recursive: true }); await page.screenshot({ path: `data/qa/classroom-practice/${name}.png`, fullPage: true });
  17 | }
  18 | 
  19 | test('practice records dont-know, skip, sequential help and replay after a lost hint response', async ({ page }) => {
  20 |   test.setTimeout(90000); const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  21 |   const actor = await login(page);
  22 |   await page.goto('/studio/classroom?lesson=soc-5-2-1&tab=practice'); await expect(page.locator('.cl-practice-progress button')).toHaveCount(3);
  23 |   const sessionId = new URL(page.url()).searchParams.get('session')!;
  24 |   const headers = { authorization: 'Bearer ' + actor.token };
  25 |   async function read() { const result = await fetch(api + '/learning/classroom/sessions/' + sessionId, { headers }); expect(result.status).toBe(200); return (await result.json()).data; }
  26 |   const initial = await read(); expect(initial.hintReceipts).toEqual([]); expect(initial).not.toHaveProperty('hintKeys');
  27 |   await page.getByRole('button', { name: '这题我不会', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toContainText('已记录不会');
  28 |   await page.getByRole('button', { name: '第2题', exact: true }).click(); await page.getByRole('button', { name: 'Skip', exact: true }).click();
  29 |   await page.getByRole('button', { name: '第3题', exact: true }).click(); await expect(page.locator('.cl-practice-data table')).toBeVisible();
  30 |   let lost = false; const levels: number[] = [];
  31 |   await page.route('**/api/learning/classroom/sessions/*/hints', async route => {
  32 |     levels.push(route.request().postDataJSON().level);
  33 |     if (!lost) { lost = true; const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed'); }
  34 |     else await route.continue();
  35 |   });
  36 |   await page.getByRole('button', { name: '先给我一个提示', exact: true }).click(); await expect(page.locator('.cl-practice-notice')).toContainText('暂时无法连接');
  37 |   expect((await read()).hintReceipts).toHaveLength(1);
  38 |   await page.getByRole('button', { name: '先给我一个提示', exact: true }).click(); await expect(page.locator('.cl-hint')).toHaveCount(1);
  39 |   await expect(page.locator('.cl-practice-notice')).toHaveCount(0);
  40 |   expect(levels).toEqual([1,1]); expect((await read()).hintReceipts).toHaveLength(1);
  41 |   await page.reload(); await expect(page.getByRole('button', { name: '第3题', exact: true })).toHaveAttribute('aria-current','step');
  42 |   await expect(page.locator('.cl-hint')).toHaveCount(1); await page.getByRole('button', { name: '再给我一个提示', exact: true }).click();
  43 |   await expect(page.locator('.cl-hint')).toHaveCount(2); await expect(page.getByRole('button', { name: '提示已读完', exact: true })).toBeDisabled();
  44 |   await page.reload(); await expect(page.locator('.cl-hint')).toHaveCount(2); expect((await read()).hintReceipts).toHaveLength(2);
  45 |   await capture(page, 'sequential-hints');
  46 |   const current = await read(), question = current.lesson.questions[2];
  47 |   await page.locator('.cl-practice-options label').nth(classroomAnswerKey(question.id).answer).click(); await page.getByRole('button', {name:'Check →',exact:true}).click();
  48 |   const review = page.getByRole('region',{name:'课堂练习复盘'}); await expect(review).toBeVisible();
  49 |   for (const [label,value] of [['已记录','3/3'],['独立答对','0'],['答错','0'],['跳过','1'],['不会','1'],['使用帮助','1']])
  50 |     await expect(review.locator('.cl-review-counts>div').filter({ has: page.getByText(label,{exact:true}) }).locator('dd')).toHaveText(value);
  51 |   await page.reload(); await expect(review).toBeVisible();
  52 |   for (const width of [1440,768,390]) { await page.setViewportSize({width,height:960}); expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true); await capture(page, 'review-'+width); }
  53 |   const final = await read(); expect(final.answers.map((answer:{disposition:string})=>answer.disposition)).toEqual(['dont_know','skip','answered']);
  54 |   expect(final.answers[2]).toMatchObject({hintUsed:true,hintLevel:2,correct:true});
  55 |   await review.getByRole('button',{name:'回看第3题',exact:true}).click(); await expect(page.locator('.cl-practice-options input').first()).toBeDisabled();
  56 |   await expect(page.locator('.cl-answer-feedback')).toContainText('已读2级提示'); expect(errors).toEqual([]);
  57 | });
  58 | 
  59 | test('every unit has a readable data or diagram practice example at desktop, tablet and phone widths', async ({ page }) => {
  60 |   test.setTimeout(90000); const errors:string[]=[]; page.on('pageerror',error=>errors.push(error.message)); await login(page);
  61 |   for (const [lesson, question, selector] of [
  62 |     ['soc-1-3-1',3,'.cl-practice-data'], ['soc-2-3-3',2,'.cl-figure'], ['soc-3-3-3',2,'.cl-practice-data'],
  63 |     ['soc-4-2-4',3,'.cl-practice-data'], ['soc-5-2-1',3,'.cl-practice-data'],
  64 |   ] as const) {
  65 |     await page.goto('/studio/classroom?'+new URLSearchParams({lesson,tab:'practice'}));
  66 |     await expect(page.locator('.cl-practice-progress button')).toHaveCount(lesson === 'soc-1-3-1' ? 4 : 3); await page.getByRole('button',{name:'第'+question+'题',exact:true}).click();
  67 |     for(const width of [1440,768,390]) {
  68 |       await page.setViewportSize({width,height:960}); await expect(page.locator(selector)).toBeVisible();
  69 |       expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1), lesson+' at '+width).toBe(true);
  70 |       await page.getByRole('button',{name:'这题我不会',exact:true}).scrollIntoViewIfNeeded(); await expect(page.getByRole('button',{name:'这题我不会',exact:true})).toBeVisible();
  71 |       await page.locator('.cl-practice-prompt').scrollIntoViewIfNeeded(); await capture(page,lesson+'-'+width);
  72 |     }
  73 |   }
  74 |   expect(errors).toEqual([]);
  75 | });
  76 | 
```