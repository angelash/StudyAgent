# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: chemistry.spec.ts >> chemistry: normal course cards, seven-unit outline and native classroom preserve the library on three viewports
- Location: tests\e2e\chemistry.spec.ts:38:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  1   | import { expect, test, type Page } from '@playwright/test';
  2   | import { mkdirSync } from 'node:fs';
  3   | 
  4   | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  5   | const courseTitle = '广州人教版九上化学 · 学习与验证';
  6   | async function fixture(page: Page) {
  7   |   const key = `${Date.now()}-${Math.floor(Math.random() * 100000)}`, principal = `chemistry-${key}@local.test`, credential = `Chemistry-${key}`;
  8   |   const registration = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
> 9   |   expect(registration.status).toBe(201); const account = (await registration.json()).data;
      |                               ^ Error: expect(received).toBe(expected) // Object.is equality
  10  |   const headers = { 'content-type': 'application/json', authorization: 'Bearer ' + account.token };
  11  |   const child = await fetch(api + '/students', { method: 'POST', headers, body: JSON.stringify({ nickname: '九上化学验收', grade: 9, preferredSessionMinutes: 25,
  12  |     defaultVersionMap: { math: '', chinese: '', english: '', chemistry: 'guangzhou-pep-chemistry-9-upper-v1' } }) });
  13  |   expect(child.status).toBe(201); const studentId = (await child.json()).data.profile.id;
  14  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  15  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  16  |   await page.evaluate(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  17  |   await expect(page.getByRole('navigation', { name: '主要导航' }).getByRole('link', { name: '化学课程', exact: true })).toHaveCount(0);
  18  |   const library = '/studio?' + new URLSearchParams({ view: 'courses', student: studentId, subject: 'chemistry' });
  19  |   await page.goto(library);
  20  |   await expect(page.getByRole('button', { name: '打开课程：' + courseTitle, exact: true })).toBeVisible();
  21  |   const call = async (path: string) => { const response = await fetch(api + path, { headers }); expect(response.status).toBe(200); return (await response.json()).data; };
  22  |   return { studentId, library, call, headers };
  23  | }
  24  | async function open(page: Page) {
  25  |   await page.getByRole('button', { name: '打开课程：' + courseTitle, exact: true }).click();
  26  |   await expect(page.getByRole('heading', { name: courseTitle, exact: true })).toBeVisible();
  27  | }
  28  | async function enroll(page: Page) {
  29  |   await open(page); await page.getByRole('button', { name: '添加课程并开始学习', exact: true }).click();
  30  |   await expect(page.getByRole('button', { name: '添加课程并开始学习', exact: true })).toHaveCount(0);
  31  |   await expect(page.getByRole('button', { name: '开始课前诊断', exact: true })).toBeEnabled();
  32  | }
  33  | async function screenshot(page: Page, label: string) {
  34  |   const directory = 'data/qa/browser-evidence/chemistry-' + (process.env.E2E_EVIDENCE_RUN ?? 'local'); mkdirSync(directory, { recursive: true });
  35  |   await page.screenshot({ path: directory + '/' + label + '.png', fullPage: true });
  36  | }
  37  | 
  38  | test('chemistry: normal course cards, seven-unit outline and native classroom preserve the library on three viewports', async ({ page }) => {
  39  |   const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  40  |   const { studentId, library, call } = await fixture(page);
  41  |   await expect(page.getByRole('link', { name: '打开课程：社会学概论', exact: true })).toBeVisible();
  42  |   await expect(page.locator('.ws-course-ticket')).toHaveCount(2);
  43  |   expect((await call('/learning/studio/overview?' + new URLSearchParams({ studentId, subject: 'chemistry' }))).courses).toHaveLength(0);
  44  |   for (const width of [1440, 768, 390]) {
  45  |     await page.setViewportSize({ width, height: 960 });
  46  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  47  |     await screenshot(page, 'library-' + width);
  48  |   }
  49  |   await page.setViewportSize({ width: 1440, height: 960 });
  50  |   await page.getByLabel('课程类型').selectOption('primary'); await expect(page.locator('.ws-course-ticket')).toHaveCount(1);
  51  |   await page.getByLabel('搜索课程').fill('九上化学'); await open(page);
  52  |   await expect(page.getByRole('navigation', { name: '课程单元' }).getByRole('button')).toHaveCount(7);
  53  |   await expect(page.getByRole('button', { name: '开始课前诊断', exact: true })).toBeDisabled();
  54  |   await expect(page.locator('.cl-learn')).toHaveCount(0);
  55  |   await page.getByRole('button', { name: '添加课程并开始学习', exact: true }).click();
  56  |   await expect(page.getByRole('button', { name: '开始课前诊断', exact: true })).toBeEnabled();
  57  |   await expect(page.getByRole('button', { name: '开始独立考核', exact: true })).toBeDisabled();
  58  |   for (const width of [1440, 768, 390]) {
  59  |     await page.setViewportSize({ width, height: 960 });
  60  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  61  |     await screenshot(page, 'outline-' + width);
  62  |   }
  63  |   await page.setViewportSize({ width: 1440, height: 960 });
  64  |   await page.getByRole('navigation', { name: '课程单元' }).getByRole('button').last().click();
  65  |   await expect(page.locator('.cl-unit-heading')).toContainText('燃料、能源与环境');
  66  |   await expect(page.locator('.cl-microlessons')).toContainText('氢能源的反应与定量验证');
  67  |   await page.getByRole('tab', { name: '考核', exact: true }).click();
  68  |   await expect(page.getByRole('heading', { name: '期中与期末考核', exact: true })).toBeVisible();
  69  |   await screenshot(page, 'checks-1440');
  70  |   await page.getByRole('tab', { name: '资料', exact: true }).click();
  71  |   await expect(page.getByRole('heading', { name: '教材与广州原卷', exact: true })).toBeVisible();
  72  |   await expect(page.locator('.cl-course-references li')).toHaveCount(10);
  73  |   await page.getByRole('navigation', { name: '课程单元' }).getByRole('button').first().click();
  74  |   await page.getByRole('tab', { name: '单元', exact: true }).click();
  75  |   await page.locator('.cl-learn').first().click(); await expect(page).toHaveURL(/lesson=learn/);
  76  |   await expect(page.getByRole('heading', { name: '物理变化与化学变化', exact: true }).first()).toBeVisible();
  77  |   await expect(page.getByText('本节课导航', { exact: true }).first()).toBeVisible();
  78  |   await page.getByRole('button', { name: '离开课堂', exact: true }).click();
  79  |   await page.getByRole('button', { name: '保存并离开', exact: true }).click();
  80  |   await expect(page.getByRole('heading', { name: courseTitle, exact: true })).toBeVisible();
  81  |   await page.getByRole('button', { name: '× 退出课程', exact: true }).click();
  82  |   await expect(page.getByLabel('课程类型')).toHaveValue('primary'); await expect(page.getByLabel('搜索课程')).toHaveValue('九上化学');
  83  |   await expect(page.locator('.ws-course-ticket')).toHaveCount(1); await page.reload();
  84  |   await expect(page.locator('.ws-course-ticket')).toHaveCount(1);
  85  |   expect((await call('/learning/studio/overview?' + new URLSearchParams({ studentId, subject: 'chemistry' }))).courses).toHaveLength(1);
  86  |   await page.goto(library); await open(page); await page.locator('.cl-practice').first().click();
  87  |   await expect(page.getByRole('button', { name: '化学', exact: true })).toHaveAttribute('aria-pressed', 'true');
  88  |   await expect(page.getByLabel('当前年级')).toHaveValue('9');
  89  |   await expect(page.locator('.studio-points input[type=checkbox]')).toHaveCount(28);
  90  |   expect(errors).toEqual([]);
  91  | });
  92  | 
  93  | test('chemistry: course assessments unlock independent checks and preserve first answers after reopening', async ({ page }) => {
  94  |   const { studentId, library, call } = await fixture(page); await enroll(page);
  95  |   await page.getByRole('button', { name: '开始课前诊断', exact: true }).click();
  96  |   await expect(page).toHaveURL(/\/student\/assessment\?.*session=/);
  97  |   const baselineId = new URL(page.url()).searchParams.get('session')!;
  98  |   const baseline = await call('/diagnostics/sessions/' + baselineId); expect(baseline.items.length).toBe(8);
  99  |   for (let index = 0; index < baseline.items.length; index++) {
  100 |     await page.getByRole('radio').first().check();
  101 |     await page.getByRole('button', { name: '提交，下一步 →', exact: true }).click();
  102 |     await expect.poll(async () => (await call('/diagnostics/sessions/' + baselineId)).answeredCount).toBe(index + 1);
  103 |   }
  104 |   await expect(page.getByRole('heading', { name: '从知识点看清下一步。', exact: true })).toBeVisible();
  105 |   const original = await call('/diagnostics/sessions/' + baselineId + '/report'); expect(original.answeredCount).toBe(8);
  106 |   await page.goto(library); await open(page); await page.getByRole('tab', { name: '考核', exact: true }).click();
  107 |   await expect(page.locator('[data-checkpoint="u1:unit"]').getByRole('button')).toBeEnabled();
  108 |   await page.locator('[data-checkpoint="u1:unit"]').getByRole('button').click();
  109 |   await expect(page).toHaveURL(/\/student\/assessment\?.*session=/);
```