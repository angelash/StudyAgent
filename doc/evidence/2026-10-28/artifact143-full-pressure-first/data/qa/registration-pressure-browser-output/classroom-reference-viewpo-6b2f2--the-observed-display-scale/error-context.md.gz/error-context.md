# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom.spec.ts >> reference viewport and display scaling >> practice geometry, whiteboard image and comparison table use the observed display scale
- Location: tests\e2e\classroom.spec.ts:226:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  1   | import { browserEvidence } from './evidence';
  2   | import { expect, test } from '@playwright/test';
  3   | import { mkdirSync } from 'node:fs';
  4   | 
  5   | const apiUrl = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}`;
  6   | const evidenceDirectory = browserEvidence('classroom');
  7   | async function login(page: import('@playwright/test').Page) {
  8   |   const suffix = Date.now() + '-' + Math.floor(Math.random() * 100000), principal = 'classroom-' + suffix + '@local.test', credential = 'Classroom-' + suffix;
  9   |   const registered = await fetch(apiUrl + '/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
> 10  |   expect(registered.status).toBe(201);
      |                             ^ Error: expect(received).toBe(expected) // Object.is equality
  11  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  12  |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  13  | }
  14  | 
  15  | function wav(seconds = 0.6) {
  16  |   const samples = Math.floor(seconds * 16000), bytes = Buffer.alloc(44 + samples * 2);
  17  |   bytes.write('RIFF'); bytes.writeUInt32LE(bytes.length - 8, 4); bytes.write('WAVE', 8); bytes.write('fmt ', 12);
  18  |   bytes.writeUInt32LE(16, 16); bytes.writeUInt16LE(1, 20); bytes.writeUInt16LE(1, 22); bytes.writeUInt32LE(16000, 24);
  19  |   bytes.writeUInt32LE(32000, 28); bytes.writeUInt16LE(2, 32); bytes.writeUInt16LE(16, 34); bytes.write('data', 36); bytes.writeUInt32LE(samples * 2, 40);
  20  |   for (let i = 0; i < samples; i++) bytes.writeInt16LE(Math.round(800 * Math.sin(i * 2 * Math.PI * 440 / 16000)), 44 + i * 2);
  21  |   return bytes;
  22  | }
  23  | 
  24  | test('course classroom supports teaching, executable examples, learning checks and durable resume', async ({ page }) => {
  25  |   test.setTimeout(120000); const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  26  |   await page.setViewportSize({ width: 1440, height: 1000 }); await login(page); await page.goto('/studio/classroom');
  27  |   await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  28  |   await expect(page.locator('.cl-unit-nav button')).toHaveCount(5); await expect(page.locator('.cl-lecture')).toHaveCount(5);
  29  |   if (!process.env.CI) { mkdirSync(evidenceDirectory, { recursive: true }); await page.screenshot({ path: evidenceDirectory + '/classroom-course.png', fullPage: true }); }
  30  |   await page.getByRole('button', { name: '▶ 学习', exact: true }).first().click();
  31  |   await expect(page.getByRole('dialog', { name: '课堂新手引导' })).toBeVisible(); await page.getByRole('button', { name: '跳过', exact: true }).click();
  32  |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  33  |   await expect(page.getByRole('img', { name: '个人处境与社会条件的交汇' })).toBeVisible();
  34  |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  35  |   await expect(page.getByLabel('实验代码')).toBeVisible(); await page.getByRole('button', { name: '▶ 运行代码' }).click();
  36  |   await expect(page.getByRole('log', { name: '代码运行结果' })).toContainText('甲地区: 20.0%');
  37  |   await page.getByLabel('实验代码').fill('console.log(typeof document); console.log(typeof window);');
  38  |   await page.getByRole('button', { name: '▶ 运行代码' }).click(); await expect(page.getByRole('log')).toContainText('undefined');
  39  |   await page.getByLabel('实验代码').fill('while (true) {}'); await page.getByRole('button', { name: '▶ 运行代码' }).click();
  40  |   await expect(page.getByRole('log')).toContainText('运行超过 2 秒');
  41  |   await page.getByLabel('实验代码').fill('fetch("https://example.com").catch(() => console.log("network-blocked"));');
  42  |   await page.getByRole('button', { name: '▶ 运行代码' }).click();
  43  |   await expect(page.getByRole('log')).toContainText(/运行完成|network-blocked/);
  44  |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-board.png', fullPage: true });
  45  |   await page.getByRole('button', { name: '课堂设置', exact: true }).click();
  46  |   await expect(page.getByRole('dialog', { name: '课堂设置' })).toBeVisible(); await page.getByRole('button', { name: '1.5×', exact: true }).click();
  47  |   await page.getByRole('switch', { name: /Background dots/ }).click();
  48  |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-settings.png', fullPage: true });
  49  |   await page.getByRole('button', { name: '关闭课堂设置' }).click();
  50  |   await page.getByRole('tab', { name: '课堂练习' }).click(); await page.locator('.cl-practice-options input[type=radio]').first().check();
  51  |   await page.getByRole('button', { name: '先给我一个提示' }).click(); await page.getByRole('button', { name: 'Check →' }).click();
  52  |   await expect(page.locator('.cl-answer-feedback')).toContainText('使用过提示');
  53  |   const receipt = await page.locator('.cl-answer-feedback').innerText();
  54  |   await page.getByRole('tab', { name: '单元项目' }).click(); await page.getByLabel('我的项目草稿').fill('匿名案例：社区图书馆如何组织排队。需要核查不同规则与资源条件。');
  55  |   await page.getByRole('button', { name: '保存项目草稿' }).click(); await expect(page.getByText('草稿已保存，重新打开仍可继续。')).toBeVisible();
  56  |   await page.reload(); await expect(page.getByText('2 / 8', { exact: true })).toHaveCount(0);
  57  |   await expect(page.locator('.cl-session-navigation')).toContainText('3 / 8');
  58  |   await page.getByRole('tab', { name: '课堂练习' }).click(); await page.getByRole('button', { name: '第1题', exact: true }).click(); await expect(page.locator('.cl-answer-feedback')).toHaveText(receipt, { useInnerText: true });
  59  |   await page.getByRole('tab', { name: '单元项目' }).click(); await expect(page.getByLabel('我的项目草稿')).toHaveValue(/社区图书馆/);
  60  |   const notes = page.waitForEvent('download'); await page.getByRole('button', { name: '导出课堂笔记' }).click(); expect((await notes).suggestedFilename()).toMatch(/\.md$/);
  61  |   await page.setViewportSize({ width: 390, height: 844 }); await page.getByRole('button', { name: '对话与练习', exact: true }).click();
  62  |   await expect(page.getByLabel('我的项目草稿')).toBeVisible();
  63  |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  64  |   await page.getByRole('button', { name: '白板', exact: true }).click();
  65  |   if (!process.env.CI) await page.screenshot({ path: evidenceDirectory + '/classroom-mobile.png', fullPage: true });
  66  |   await page.getByRole('button', { name: '离开课堂', exact: true }).click(); await page.getByRole('button', { name: '保存并离开' }).click();
  67  |   await expect(page.getByRole('heading', { name: '社会学概论', exact: true })).toBeVisible();
  68  |   expect(errors).toEqual([]);
  69  | });
  70  | 
  71  | test('audio playback ends drive teaching progress and pause prevents later automatic advancement', async ({ page }) => {
  72  |   test.setTimeout(90000); await login(page);
  73  |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  74  |   const withTestAudio = async (route: import('@playwright/test').Route) => {
  75  |     const response = await route.fetch(), body = await response.json();
  76  |     body.data.speech = { available: true, provider: 'minimax', defaultVoice: 'fixture', voices: [{ id: 'fixture', label: '合成测试音轨' }] };
  77  |     await route.fulfill({ response, json: body });
  78  |   };
  79  |   await page.route('**/api/learning/classroom/sessions', withTestAudio);
  80  |   await page.route('**/api/learning/classroom/sessions/*', withTestAudio);
  81  |   let audioRequests = 0;
  82  |   await page.route('**/api/learning/classroom/sessions/*/narration/*', async route => { audioRequests++; await route.fulfill({ contentType: 'audio/wav', body: wav() }); });
  83  |   await page.goto('/studio/classroom?lesson=soc-1-1-1'); await expect(page.getByRole('button', { name: '▶ 开始学习' })).toBeVisible();
  84  |   await page.getByRole('button', { name: '▶ 开始学习' }).click(); await expect(page.locator('.cl-session-navigation')).not.toContainText('1 / 8');
  85  |   await page.getByRole('button', { name: '暂停讲解' }).click();
  86  |   await expect(page.getByRole('button', { name: '继续讲解' })).toBeVisible();
  87  |   const cursor = await page.locator('.cl-session-navigation').innerText();
  88  |   await page.waitForTimeout(1200); expect(await page.locator('.cl-session-navigation').innerText()).toBe(cursor);
  89  |   expect(audioRequests).toBeGreaterThan(0);
  90  |   for (let step = 0; step < 8; step++) {
  91  |     const before = await page.locator('.cl-session-navigation').innerText(); if (before.includes('7 / 8')) break;
  92  |     await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  93  |     await expect(page.locator('.cl-session-navigation')).not.toHaveText(before, { useInnerText: true });
  94  |   }
  95  |   await page.getByRole('button', { name: '继续讲解' }).click();
  96  |   await expect(page.getByRole('tab', { name: '课堂练习' })).toHaveAttribute('aria-selected', 'true');
  97  |   await expect(page.getByRole('button', { name: '继续讲解' })).toBeVisible();
  98  |   await expect(page.locator('.cl-session-navigation')).toContainText('7 / 8');
  99  |   await page.locator('.cl-practice-options input[type=radio]').first().check(); await page.getByRole('button', { name: 'Check →' }).click();
  100 |   await expect(page.locator('.cl-answer-feedback')).toBeVisible();
  101 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  102 |   await page.getByRole('button', { name: '下一步 ›', exact: true }).click();
  103 |   await expect(page.getByRole('dialog', { name: '课堂学习里程碑' })).toBeVisible();
  104 | });
  105 | 
  106 | test('question replies add safe board notes with page links, export and restored session rendering', async ({ page }) => {
  107 |   test.setTimeout(90000); await page.setViewportSize({ width: 1552, height: 1199 }); await login(page);
  108 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  109 |   const board = { title: '把困惑拆成可核查的问题', points: ['比较不同条件，再找相同处境中的反例。', '<img src=x onerror="window.boardExecuted=true">'],
  110 |     page: 0, diagram: { kind: 'flow', title: '核查路线', labels: ['观察处境', '比较条件', '寻找反例'] } };
```