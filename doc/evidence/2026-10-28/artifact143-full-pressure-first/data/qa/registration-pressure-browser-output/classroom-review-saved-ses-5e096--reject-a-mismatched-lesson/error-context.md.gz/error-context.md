# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: classroom-review.spec.ts >> saved-session links restore the exact activity and reject a mismatched lesson
- Location: tests\e2e\classroom-review.spec.ts:76:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 201
Received: 429
```

# Test source

```ts
  1  | import { expect, test, type Page } from '@playwright/test';
  2  | import { mkdirSync } from 'node:fs';
  3  | const api = `http://localhost:${process.env.E2E_API_PORT ?? '4107'}/api`;
  4  | const { classroomAnswerKey } = require('../../apps/api/dist/apps/api/src/modules/learning/classroom-curriculum.js');
  5  | 
  6  | async function login(page: Page) {
  7  |   const key = `${Date.now()}-${Math.floor(Math.random() * 100000)}`, principal = `class-review-${key}@local.test`, credential = `ClassReview-${key}`;
  8  |   const registered = await fetch(api + '/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ principal, credential }) });
> 9  |   expect(registered.status).toBe(201); const actor = (await registered.json()).data;
     |                             ^ Error: expect(received).toBe(expected) // Object.is equality
  10 |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential);
  11 |   await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
  12 |   await page.addInitScript(() => localStorage.setItem('studyagent.classroom.tour', 'done'));
  13 |   return actor;
  14 | }
  15 | 
  16 | test('unit check resumes holes, persists help and provides a faithful review with topic return', async ({ page }) => {
  17 |   test.setTimeout(120000); const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  18 |   await page.setViewportSize({ width: 1440, height: 960 });
  19 |   const actor = await login(page);
  20 |   const response = await fetch(api + '/learning/classroom/sessions', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + actor.token }, body: JSON.stringify({ lessonId: 'unit-exam:soc-u1' }) });
  21 |   expect(response.status).toBe(201); const session = (await response.json()).data;
  22 |   expect(session.lesson.questions).toHaveLength(12);
  23 |   await page.goto('/studio/classroom?lesson=unit-exam:soc-u1&tab=practice');
  24 |   await expect(page.locator('.cl-unit-check-note')).toContainText('12个新情境');
  25 |   await expect(page.locator('.cl-practice-progress button')).toHaveCount(12);
  26 |   const select = async (questionIndex: number, correct: boolean) => {
  27 |     await page.getByRole('button', { name: `第${questionIndex + 1}题`, exact: true }).click();
  28 |     const key = classroomAnswerKey(session.lesson.questions[questionIndex].id).answer;
  29 |     const indices = Array.isArray(key) ? correct ? key : [session.lesson.questions[questionIndex].options.findIndex((_:unknown,index:number) => !key.includes(index))] : [correct ? key : (key + 1) % 4];
  30 |     for (const index of indices) await page.locator('.cl-practice-options label').nth(index).click();
  31 |     await page.getByRole('button', { name: 'Check →', exact: true }).click();
  32 |   };
  33 |   await select(0, true);
  34 |   await page.getByRole('button', { name: '第12题', exact: true }).click(); await page.getByRole('button', { name: 'Skip', exact: true }).click();
  35 |   await page.reload(); await expect(page.getByRole('button', { name: '第2题', exact: true })).toHaveAttribute('aria-current', 'step');
  36 |   await select(1, false);
  37 |   await page.getByRole('button', { name: '第3题', exact: true }).click();
  38 |   await page.getByRole('button', { name: '先给我一个提示', exact: true }).click();
  39 |   await expect(page.getByRole('button', { name: '再给我一个提示', exact: true })).toBeEnabled();
  40 |   await page.reload(); await expect(page.getByRole('button', { name: '第3题', exact: true })).toHaveAttribute('aria-current', 'step');
  41 |   await expect(page.locator('.cl-hint')).toBeVisible();
  42 |   await select(2, true); await expect(page.locator('.cl-answer-feedback')).toContainText('记为辅助作答');
  43 |   for (let index = 3; index < 11; index++) {
  44 |     await page.getByRole('button', { name: `第${index + 1}题`, exact: true }).click();
  45 |     await page.getByRole('button', { name: 'Skip', exact: true }).click();
  46 |   }
  47 |   const review = page.getByRole('region', { name: '课堂练习复盘' }); await expect(review).toBeVisible();
  48 |   await expect(review.getByRole('heading', { name: '先看清这次，再决定下一步。' })).toBeInViewport();
  49 |   for (const [label, count] of [['已记录', '12/12'], ['独立答对', '1'], ['答错', '1'], ['跳过', '9'], ['使用帮助', '1']])
  50 |     await expect(review.locator('.cl-review-counts>div').filter({ has: page.getByText(label, { exact: true }) }).locator('dd')).toHaveText(count);
  51 |   await expect(review).toContainText('不是标准化能力等级');
  52 |   await review.getByRole('button', { name: '回看第2题', exact: true }).click();
  53 |   await expect(page.locator('.cl-practice-options input').first()).toBeDisabled();
  54 |   await expect(page.locator('.cl-answer-feedback')).toContainText('对照概念，再看一次');
  55 |   await page.getByRole('button', { name: '查看本次复盘 →' }).click();
  56 |   await page.reload(); await expect(review).toBeVisible();
  57 |   for (const width of [1440, 768, 390]) {
  58 |     await page.setViewportSize({ width, height: 960 });
  59 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(true);
  60 |     await review.getByRole('button', { name: '返回课程，安排下一步' }).scrollIntoViewIfNeeded();
  61 |     await expect(review.getByRole('button', { name: '返回课程，安排下一步' })).toBeVisible();
  62 |   }
  63 |   if (process.env.E2E_REVIEW_SNAPSHOT === '1') {
  64 |     mkdirSync('data/qa/classroom-review', { recursive: true });
  65 |     await review.getByRole('heading', { name: '先看清这次，再决定下一步。' }).scrollIntoViewIfNeeded();
  66 |     await page.screenshot({ path: 'data/qa/classroom-review/mobile.png', fullPage: true });
  67 |     await page.setViewportSize({ width: 1440, height: 960 }); await review.getByRole('heading', { name: '先看清这次，再决定下一步。' }).scrollIntoViewIfNeeded();
  68 |     await page.screenshot({ path: 'data/qa/classroom-review/desktop.png', fullPage: true });
  69 |   }
  70 |   await review.locator('.cl-review-items>li').first().getByRole('button', { name: '回到相关微课' }).click();
  71 |   await expect(page).toHaveURL(/lesson=soc-1-1-2/);
  72 |   await page.goBack(); await expect(review).toBeVisible();
  73 |   expect(errors).toEqual([]);
  74 | });
  75 | 
  76 | test('saved-session links restore the exact activity and reject a mismatched lesson', async ({ page }) => {
  77 |   await login(page); await page.goto('/studio/classroom?lesson=soc-2-1-2&tab=practice');
  78 |   await expect(page.locator('.cl-practice-options')).toBeVisible();
  79 |   const saved = new URL(page.url()).searchParams.get('session'); expect(saved).toBeTruthy();
  80 |   for (let index = 0; index < 3; index++) {
  81 |     await page.getByRole('button', { name: `第${index + 1}题`, exact: true }).click();
  82 |     await page.getByRole('button', { name: 'Skip', exact: true }).click();
  83 |   }
  84 |   await expect(page.getByRole('region', { name: '课堂练习复盘' })).toBeVisible();
  85 |   await page.goto('/studio/classroom?session=' + encodeURIComponent(saved!) + '&tab=practice');
  86 |   await expect(page.getByRole('region', { name: '课堂练习复盘' }).locator('.cl-review-items')).toContainText('第1题 · 跳过');
  87 |   await page.goto('/studio/classroom?session=' + encodeURIComponent(saved!) + '&lesson=soc-1-1-1&tab=practice');
  88 |   await expect(page.locator('.cl-error')).toContainText('保存记录与当前课程入口不一致');
  89 |   await expect(page.locator('.cl-practice-layout')).toHaveCount(0);
  90 | });
  91 | 
```