const assert=require('node:assert/strict'),crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path');
module.exports=async()=>{const api='http://localhost:'+process.env.E2E_API_PORT+'/api',statuses=[];
for(let i=0;i<31;i++){const response=await fetch(api+'/auth/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({principal:'shared-pressure-'+crypto.randomUUID()+'@local.test',credential:'Synthetic-pressure-'+crypto.randomUUID()})});statuses.push(response.status);await response.arrayBuffer();}
assert(statuses.slice(0,30).every(status=>status===201));assert.equal(statuses[30],429);
const receipt={sameSharedAddressAccepted:statuses.slice(0,30).length,sameSharedAddress31st:statuses[30],actualProductionRegistrationLimitKept:true,scope:'Fresh owned loopback QA API, synthetic accounts; no production requests or weakened limiter.'};
const out=path.join(process.cwd(),'data/qa/chemistry-v2-pressure-setup-result.json');if(fs.existsSync(out))throw Error('Original pressure receipt exists');fs.writeFileSync(out,JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));};
