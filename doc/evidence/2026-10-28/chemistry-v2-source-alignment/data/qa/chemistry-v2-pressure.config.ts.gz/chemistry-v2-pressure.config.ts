import base from '../../playwright.config';
import path from 'node:path';
const root=path.resolve(__dirname,'../..');
export default {...base,testDir:path.join(root,'tests/e2e'),outputDir:path.join(root,'data/qa/chemistry-v2-pressure-output-first'),reporter:[['list'],['json',{outputFile:path.resolve(root,process.env.E2E_RESULT_FILE!)}]],globalSetup:path.join(__dirname,'chemistry-v2-pressure-setup.cjs'),webServer:(base.webServer as any[]).map(server=>({...server,cwd:root}))};
