# StudyAgent 当前功能与设计总册

2026-10-28当前结构：源码基线b62ef293b0001b6ddf743bc02846e5f2739ba031，14领域/128项功能/424个常规HTTP路由、103个领域集合、387个共享契约定义、30个Web页。140已接入成人讲座目标快照、独立持久助教、原上下文导航及统一字体注册；字体修复专项28项、完整本地433及精确40601241878远端433均零重试通过，应用/PG/浏览器三组success。140现已实际生产构建并守护交付，schema21、buildId NkfAGfS0FLw-vibTZyptB，1296运行检查及111163ms三次稳定观察通过；原子能力计量与版本化指导沿139保持，运行原件与静态设计分别记录。默认DeepSeek V4.1 Flash，历史模型文字资格21/22、旧Opus5失败；本批另有两条完整默认模型样本。完整产品、教师/设备/原声/像素与长期验证继续，见[140具体范围](../product/140-lecture-context-and-studio-assistant.md)、[139正式验收](../evidence/2026-10-28/measurement-v3-acceptance.json)及[完整计划105](../product/105-development-plan-status-and-next-milestones.md)。以下较早统计是分批历史。

整理日期：2026-10-26。当前课堂实现包含[107持久插问](../product/107-classroom-turns-and-reference-state-parity.md)、[108代码实验](../product/108-classroom-code-experiments-and-draft-recovery.md)、[110资料课程版本](../product/110-source-course-revisions-and-lifecycle.md)、[111真实项目文件](../product/111-project-attachments-and-frozen-file-evidence.md)、[112可恢复作答](../product/112-recoverable-answer-drafts-and-complete-input-journeys.md)和[109图表/公式/节奏](../product/109-classroom-comparison-formulas-and-reply-pacing.md)；原件恢复见[交付106](../product/106-original-repair-product-delivery.md)。源码基线、验证与守护运行版本分别以各批收据为准，开发接入不自动等于运行交付。完整范围与剩余里程碑见[计划105](../product/105-development-plan-status-and-next-milestones.md)。

这套文档回答“当前产品有什么、各能力怎样协作、每项功能具体怎样实现”。事实以当前接入代码、共享契约和测试为准；此前九十多份交付文档作为沿革与验证证据保留。

128原卷复习已完成精确CI fd519aa/40382195553与主目录schema18守护交付，315浏览器原始单次零重试通过；完整API本地1354通过/54环境跳过，Linux1346/62，PG及双库原生恢复23通过。整理/再练/独立新题/曝光隔离和本人/孩子日历已上线，见[128验收](../evidence/2026-10-27/paper-review-acceptance.json)。129在隔离工作区接入原字体、作用域CSS与累积画布；本地验证、完整参考状态、精确CI和正式交付分别留证，不能把开发界面当成已上线。当前设计仍14领域/125功能/378正常接口/100集合/355共享类型、29个Web页；129深化既有STUDIO-10，见[具体设计](../product/129-hyperknow-original-assets-and-teaching-shell.md)及[总计划](../product/105-development-plan-status-and-next-milestones.md)。

普通助教已支持持久任务、明确取消、完整原问题恢复、分页检索和原题定位，详见[具体规格](../product/113-durable-assistant-conversations-and-history.md)及[验收收据](../evidence/2026-10-25/assistant-turn-acceptance.json)。源码、精确CI与实际守护运行版本分别记录，当前运行及候选状态见本页末尾，不以设计生成代替发布。

## 阅读入口

- [功能框架](01-functional-framework.md)：14个领域、128项功能，包含角色、入口、能力和限制。
- [概要设计](02-high-level-design.md)：产品边界、角色、架构、模块依赖、业务闭环和关键设计决策。
- [核心详细设计](03-core-detailed-design.md)：范围、组题、评分、能力估计、原因验证、指导、AI、课堂和日历的处理细节。
- [数据与状态设计](04-data-and-state-design.md)：实体关系、103个领域集合、SQL结构、版本与状态机。
- [运行、资产与质量设计](05-runtime-assets-and-quality.md)：依赖、AI通道、处理链、部署、备份恢复、测试与当前证据。
- [完成边界与待完善项](06-boundaries-and-follow-ups.md)：已实现、历史保留、待验证和明确不做的范围。
- [离线功能浏览器](index.html)：按领域或关键词查找功能，展开输入、处理、输出、接口、数据与代码。

## 逐领域详细设计

1. [身份、家庭与学习权限](details/01-identity.md)
2. [知识、教材、范围与课程版本](details/02-curriculum.md)
3. [评测组题、作答与评分](details/03-assessment.md)
4. [掌握量化、原子观察与深层原因](details/04-measurement.md)
5. [指导计划、训练编排与间隔复盘](details/05-guidance.md)
6. [家庭首页、今日训练、学习记忆与错题](details/06-learning.md)
7. [题卷资产、内容编辑、导入与发布](details/07-content.md)
8. [大模型、证据助教、语音与文档模型](details/08-ai.md)
9. [学习工作台、实时课堂、白板、学案与日历](details/09-studio.md)
10. [GESP研究、C++试点与独立保持](details/10-gesp.md)
11. [主观复核、异常反馈与质量闭环](details/11-review.md)
12. [作答图片、录音与受控媒体](details/12-media.md)
13. [家庭资料下载、删除与恢复约束](details/13-privacy.md)
14. [持久化、后台处理、监控、部署与质量](details/14-operations.md)

每项功能均注明输入、处理步骤、输出、持久化集合、权限/失败/限制、接口和实际服务方法；内部算法与浏览器交互明确标识为非独立API能力。

## 开发查阅索引

- [全部接口](generated/api-reference.md)：399个源码路由声明中，当前正常接入378个、旧协议410拦截8个、未接入历史声明13个。正常接口数包含健康和运维接口。
- [页面职责](generated/page-reference.md)：29个页面和1个课堂runner处理器；部分页面是兼容重定向。
- [领域集合与355个共享类型](generated/data-reference.md)：逻辑集合不等于SQL表，Zod推导类型须继续查看源Schema。
- [功能目录JSON](feature-catalog.json)、[源码结构JSON](generated/source-inventory.json)、[接口覆盖检查](generated/coverage.json)、[整理验证收据](generated/design-validation.json)。

## 端到端产品结构

```mermaid
flowchart LR
    A[家长建档与授权] --> B[确认年级 教材 已学范围]
    B --> C[蓝图预览与独立评测]
    C --> D[作答事实 评分 复核]
    D --> E[知识点估计与原因假设]
    E --> F[对照验证]
    F --> G[家长确认指导计划]
    G --> H[讲解 训练 错题]
    H --> I[1/3/7/14日复测]
    I --> J[可比证据复盘]
    J --> E
    K[题卷 教材 PDF 教研审核] --> C
    K --> H
    L[工作台 课堂 白板 学案 日历] --> H
    M[AI证据助教 语音 文档复核] --> L
    M --> G
    N[GESP独立编程轨道] --> O[概念 跟踪 实现 保持]
```

## 使用口径

“实现”指存在接入的功能与相应代码，并明确依赖和限制。它不自动表示已完成真人教学验证、全教材映射、标准化测量效度、所有设备验收或HyperKnow逐像素一致。读取进度、课堂练习、排程完成与独立测量证据分别保存。

本册仅整理设计与查阅工具，不修改运行中的业务服务、真实家庭数据、模型配置或密钥。

## 更新方法

在仓库根目录执行：

```powershell
node scripts/architecture/project-design-inventory.cjs
node scripts/architecture/build-project-design.cjs
node scripts/qa/audit-authored-curriculum.cjs data/qa/project-design-authored-audit.json
node scripts/architecture/project-content-snapshot.cjs
node scripts/architecture/validate-project-design.cjs doc/evidence/2026-10-24/material-collection-acceptance.json
npm run qa:docs
```

第一步从TypeScript AST提取实际模块依赖、路由、服务签名、集合与契约；第二步生成详细设计与离线浏览器，将人工维护的功能解释与源码交叉核对，发现缺失文件、未接入接口或未覆盖的当前API时失败。内容审计需要当前API编译产物；仅重新生成结构和功能说明时，不必重建服务。验证脚本使用已安装的Playwright Chromium，不启动API或读取家庭数据库。

功能叙述维护于 [project-feature-definitions.cjs](../../scripts/architecture/project-feature-definitions.cjs)，查阅页模板维护于 [project-design-viewer.html](../../scripts/architecture/project-design-viewer.html)。概要与核心算法文档需随业务变化人工核对，自动提取不能代替设计审查。

115候选新增课堂单选/多选、提交后逐项反馈和按账号/冻结会话保存的原选择/提交恢复。当前245题含三个微课多选和一个单元多选，自动化与教师审核分开；详见[115规格](../product/115-classroom-multiple-choice-and-submitted-feedback.md)。113已完成精确CI与守护交付，115当前运行状态以其最终收据为准。

2026-10-26运行交付：118项目逐步教学、标签页独立完整草稿与本人原操作恢复已上线，应用代码944d93a；1178项API通过/39环境跳过、PG14项通过、真实配置MiniMax单句HTTP及解码通过。完整194项浏览器通过，精确CI 8b547d2/40213523846成功；实际构建e558ea4、28项HTTP检查与六音频SHA通过，三次守护观察跨201764毫秒稳定。静态设计当前14领域/118功能/325正常路由/93集合/307共享类型。完整范围及限制见[118规格](../product/118-guided-project-teaching-and-step-navigation.md)和[本批收据](../evidence/2026-10-26/project-teaching-acceptance.json)。


119开发候选：资料课程三阶段项目、逐课/单元学习旅程、准确会话断点、个人项目步骤/模式已接入。当前静态设计为14领域/119功能/325正常接口/93集合/310共享类型，完整API1194通过/40环境跳过、浏览器203通过/0失败/0重试，PG组合31通过/1跳过；精确CI与运行仍待完成，状态以[本批收据](../evidence/2026-10-26/course-journey-acceptance.json)为准。资料独立单元核查未设置，全课程和真人门禁继续保留。


119当前门禁：首个远端CI虽成功，但浏览器202常规通过/1重试通过；连续返回的真实竞态已修正3537dfa，受控六项全通过。固定Web的205本地全量与新精确CI并行核验中，尚未替换118守护运行版；详细证据以119本批收据为准。


119当前运行：资料课程三阶段项目、成人/资料课程学习旅程、准确原句/题目断点、个人项目步骤/模式和连续返回修正已交付。源码索引3537dfa，API/契约主增量466220d；本地与精确CI 9053f03/40221345190的205项浏览器均零失败/零重试。实际构建c1c6608、buildId hi7VwKIGYaHmzQtuQqKdz，51项运行检查/六音频SHA及跨181042毫秒守护观察通过。当前14领域/119功能/325正常接口/93集合/310共享类型，完整范围仍以[119最终收据](../evidence/2026-10-26/course-journey-acceptance.json)及[计划105](../product/105-development-plan-status-and-next-milestones.md)为准；独立资料核查和所有真人/全内容门禁未因此完成。


2026-10-26：120开发分支已接资料独立核查、完整编审、未曝光确认、冻结学生课堂与原文、原命令/本机稿恢复及版本旅程。源码设计更新为14领域/120功能/337正常接口/95集合/316共享类型，142 API测试文件和29浏览器测试文件。完整API1240通过/43环境跳过、PG24通过、九浏览器专项零重试通过，真实默认DS生成6题（首次提示条数校验失败后修正，实际3次模型调用、AI复核修订2处）。其后可读原稿和归档候选只读优化已通过Web类型检查，整站浏览器正在核对；精确CI和守护发布尚未完成，实际运行仍为119。设计验证包含435源码引用、2800 Markdown链接及10离线界面检查，不能替代业务验收。见[规格120](../product/120-source-course-independent-unit-checks.md)与[整合收据](../evidence/2026-10-26/source-check-acceptance.json)。

2026-10-26当前运行已交付120资料课程独立核查：源码核心da574a4、恢复00902a1与取消b3fb6fa，精确CI7d606a4/40234093187及生产构建01a07da/ j9rxRUAmWJpdihvwXHLj8已完成；69项运行检查、六音频SHA和90185毫秒守护稳定观察通过。两端217浏览器均零重试，本地API1241/43与PG25，原始失败保留。详见[最终验收](../evidence/2026-10-26/source-check-acceptance.json)和[运行收据](../evidence/2026-10-26/source-check-runtime.json)。设计数量保持14领域/120功能/337正常接口/95集合/316共享类型；完整产品、教师与实机门禁尚未满足，单课时121仍独立验收。

单课时独立候选121的设计源码另已支持显式1～6课时，输入配方与旧双目标黄金摘要保持；当前候选50项SQLite、26项PG、10项前端专项及真实DS5题/1目标两调用通过，218项整站、独立精确CI与运行发布仍待。实际守护保持上段120版本，详见[121规格](../product/121-single-lesson-source-course-checks.md)和[候选收据](../evidence/2026-10-26/source-check-single-acceptance.json)。

2026-10-26：当前运行是121（f747bb3、实际构建dd9194e/0Zhr-Oq70fmQyS671XuvN），完整收据见[121](../evidence/2026-10-26/source-check-single-acceptance.json)。122代码e0d61c8/dc4460e已接逐句自由白板、真实音轨推进、已知秒数续播、原请求关联与统一WebM/SRT时间表；24专项/PG2/11浏览器零重试，当前整批门禁待完成，未把开发候选当成上线。STUDIO-09/10按实现重写，原字体/CSS/DPR、任意主题AI、教师/设备/长期门禁保持，见[122](../evidence/2026-10-26/whiteboard-speech-acceptance.json)。


122收尾修复68202df已接120ms录制静音尾段/末尾音频保留、原登录与学生授权代次在合成前后新事务核对；28专项、PG4及11浏览器零重试通过。设计索引更新为68202df，449源码引用/2853链接/10离线检查通过，当前完整API和229整站尚在运行；生产仍121。


122收尾修复68202df后的完整本地回归已实际通过：API1258通过/47环境跳过、229浏览器零失败/零跳过/零重试（1100.69秒，原始压缩字节与SHA保留）。完整音频视频导出及SRT本轮也实测解码，独立FFmpeg对照与首末声音标记留证。接续精确候选远端CI及主目录可回退守护交付，当前运行仍121；123任意主题AI只在独立分支接入后端，未混入本批。72项与M1～M7完整门禁不变。


122精确候选a7c06df/40247643763三组远端CI全部终态success；下载原始报告实际229通过/零失败/零跳过/零重试，原始SHA 8b6bb8772ae6e52e9695a3b0dd8e0dd8cfb5424341ae1bdecb9f641312a29dfc。Linux完整API1250通过/55环境跳过，原始三组日志与压缩浏览器字节保留；本地1258/47与229零重试各自留证。开始主目录一致数据备份、真实构建和守护观察，当前仍未声称上线。新鲜121旧构建843文件/五配置与本地环境的私有回退副本已准备，尚不等于停服一致数据库备份或完整恢复演练。


2026-10-26：122逐句白板最终运行交付。核心68202df，精确CI a7c06df/40247643763三组success；本地API1258/47环境跳过、Linux1250/55，两端229浏览器零失败/零跳过/零重试。主目录203d8f0真实生产构建，buildId mSFyAwqNN3WmH4RE65D9V，schema15；73实际HTTP/权限/脚本检查、六MP3逐SHA、四个实际编译文件逐SHA通过，三次守护观察跨86599毫秒PID与重启计数不变。五处本地配置及真实环境原字节、一致数据库/引用文件、843份121旧编译文件回退均保留，assetsIncluded:false不是研究资产独立备份或完整恢复演练。最初运行检查把未声明的旧GET-by-id误期为401而得到404，已仅校正检查预期，原收据保留。逐句阅读/完整笔记、真实音频结束推进、暂停续播、原登录/授权代次及统一WebM/SRT时间表已可使用；任意主题AI仍在独立123工作区，未混入此运行版。72项仍11 implemented/48 in_progress/13 planned/0 verified，M1～M7及教师/实机/全内容/原CSS字体DPR声音/长期门禁保持，整体目标继续。见[运行收据](../evidence/2026-10-26/whiteboard-speech-runtime.json)与[最终验收](../evidence/2026-10-26/whiteboard-speech-acceptance.json)。

2026-10-26：独立AI主题白板按STUDIO-31归入总册，当前源码ed0ad2d：14领域/121功能/350正常接口/97集合/328共享类型。24浏览器专项原次通过，29项API和14项PG/2项SQLite专属跳过分开留证；完整API初轮的两项旧schema预期已修正并重跑，242项完整整站也在执行。466源码引用/2933链接/10查看器检查通过不等于业务门禁或当前生产交付；主目录仍122/schema15，123精确CI与真实守护升级待。AI写稿、复核、完整改稿历史、明确保存和逐句播放器已有接入；图片/复杂图形、完整像素/原声/实机/教师/全内容/长期效果及72项总门禁仍未完成。见[123](../product/123-ai-topic-whiteboards.md)及[当前收据](../evidence/2026-10-26/topic-whiteboard-acceptance.json)。

123完整本地门禁随后已通过：API1287/0失败/51环境跳过、242浏览器零失败/跳过/重试，原始媒体和报告见[当前验收](../evidence/2026-10-26/topic-whiteboard-acceptance.json)。精确远端CI及schema16实际交付继续单列；这些本地证据没有把真实教师、设备、原声与像素完整门槛标成完成。

123精确e1bd27c/40258543480随后三组success；原始远端浏览器实际242零重试，Linux API1279/59环境跳过，新白板PG14/2 SQLite专属跳过，各日志和原件见[精确CI](../evidence/2026-10-26/topic-whiteboard-exact-ci/receipt.json)。主目录真实schema16生产构建、停服一致备份及守护稳定观察继续独立记录，尚不据CI结果自动声明部署。

123运行也已交付：主目录453866d真实构建，buildId 7DPYUYWiUo1CUbaCcrd0R、schema16，100实际HTTP/权限/已提供JS检查、11编译逐SHA、6MP3逐SHA及跨119361毫秒三次守护稳定观察通过。五处本地配置与真实环境、新鲜122编译/停服一致数据库回退保持；assetsIncluded:false，不等于全资产独立备份或生产恢复演练。当前可访问`/studio/whiteboards`，见[运行原件](../evidence/2026-10-26/topic-whiteboard-runtime.json)。124图片/复杂公式与72项完整教学/像素/实机/教师门槛仍独立继续。


138当前设计快照为14领域/128功能/423正常接口/103集合/384契约/30页，七个教研接口完整映射。AI-04现在说明服务端题库快照、只读待核对结果、旧入口202/201/200、原请求与原操作恢复、有限JSON和本人资料隔离；不再将活跃admin入口描述为OPENAI SDK。583源码引用、3718链接和离线查看器10项检查通过，完整候选与实际交付继续按[138](../product/138-internal-teaching-tools-unified-models.md)记载。
