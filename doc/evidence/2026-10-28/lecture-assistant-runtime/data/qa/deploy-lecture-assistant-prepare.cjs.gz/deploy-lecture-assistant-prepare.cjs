// Private delivery helper. Refuse every mutation until the exact candidate and old runtime are verified.
const fs = require('node:fs'), path = require('node:path'), { createHash } = require('node:crypto'), { execFileSync } = require('node:child_process');
const root = process.cwd(), names = ['study-agent-api', 'study-agent-web', 'study-agent-health'];
const latest = JSON.parse(fs.readFileSync('data/qa/lecture-assistant-release-latest.json'));
const release = path.resolve(root, latest.folder), base = path.join(root, 'output/daemon/release-backups');
if (!release.startsWith(base + path.sep) || fs.realpathSync(release).toLowerCase() !== release.toLowerCase()) throw Error('Unexpected exact rollback directory');
const read = name => JSON.parse(fs.readFileSync(path.join(release, name), 'utf8'));
const before = read('deployment-before.json'), candidate = read('candidate.json');
const sha = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const git = args => execFileSync('git', args, { encoding: 'utf8', windowsHide: true }).trim();
function pm(args) { return execFileSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', 'pm2 ' + args], { encoding: 'utf8', windowsHide: true, maxBuffer: 10 * 1024 * 1024 }); }
async function main() {
  if (candidate.schemaVersion !== 21 || candidate.apiLocalPassed !== 1539 || candidate.apiLocalFailed !== 0 || candidate.apiEnvironmentSkipped !== 65 || Object.keys(candidate.compiledSha256).length !== candidate.compiledCount) throw Error('Complete schema21 and full local API gate required');
  if (candidate.status !== 'ready-for-release' || candidate.verifiedZeroRetries !== true || candidate.localBrowserCases !== 433 || candidate.remoteBrowserCases !== 433) throw Error('Complete candidate gate required');
  if(candidate.newRealDefaultSamples!==2)throw Error('Current two default lecture/independent real samples required');
  if(candidate.realModelsPassed!==21||candidate.realModelsFailed!==1||candidate.allModelsPassed!==false)throw Error('Explicit21of22 real-model boundary required; do not declare full model availability');
  const ci = JSON.parse(execFileSync('gh', ['run', 'view', String(candidate.ciRun), '--json', 'status,conclusion,headSha,jobs'], { encoding: 'utf8', windowsHide: true }));
  if (ci.status !== 'completed' || ci.conclusion !== 'success' || ci.headSha !== candidate.head || ci.jobs.length !== 3 || ci.jobs.some(row => row.status !== 'completed' || row.conclusion !== 'success')) throw Error('Exact candidate CI not complete');
  if (git(['rev-parse', 'HEAD']) !== before.revision || before.revision !== 'ab83ecd97d9e1a278190a8e3ee00d3a9f6684da2') throw Error('Expected original139 main revision');
  const changed = git(['diff', '--name-only']).split(/\r?\n/).sort();
  if (JSON.stringify(changed) !== JSON.stringify(Object.keys(before.protectedFiles).sort()) || git(['diff', '--cached', '--name-only'])) throw Error('Unexpected modified or staged main files');
  function verifyConfig() {
    for (const [file, expected] of Object.entries(before.protectedFiles)) if (sha(file) !== expected) throw Error('Protected configuration changed: ' + file);
    if (sha('.env') !== sha(path.join(release, 'config/.env'))) throw Error('Private environment changed');
  }
  verifyConfig();
  const services = JSON.parse(pm('jlist')).filter(row => names.includes(row.name));
  if (services.length !== 3 || services.some(row => row.pm2_env.status !== 'online' || path.resolve(row.pm2_env.pm_cwd).toLowerCase() !== root.toLowerCase())) throw Error('Unexpected guardian ownership/state');
  const buildFiles=read('build-files.json');
  if(!Number.isSafeInteger(before.oldBuildFiles)||before.oldBuildFiles<1||buildFiles.length!==before.oldBuildFiles)throw Error('Expected complete139 compiled rollback inventory');
  for(const row of buildFiles)if(sha(path.join(release,'build',row.path))!==row.sha256||sha(path.join(root,row.path))!==row.sha256)throw Error('Previous running build or rollback copy changed: '+row.path);
  const source=path.resolve('F:/workspace/github/StudyAgent-lecture-integration');
  if(fs.realpathSync(source).toLowerCase()!==source.toLowerCase())throw Error('Linked source worktree refused');
  if(execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8',windowsHide:true}).trim()!==candidate.deliveryHead)throw Error('Delivery source revision changed');
  const zlib=require('node:zlib');
  for(const [name,digest,original]of [[candidate.browserArtifact,candidate.browserArtifactSha256,candidate.originalBrowserSha256],[candidate.modelArtifact,candidate.modelArtifactSha256,candidate.originalModelsSha256],[candidate.realDefaultModelArtifact,candidate.realDefaultModelArtifactSha256,candidate.realDefaultModelOriginalSha256]]){
    const file=path.resolve(source,name);if(!file.startsWith(source+path.sep)||sha(file)!==digest||createHash('sha256').update(zlib.gunzipSync(fs.readFileSync(file))).digest('hex')!==original)throw Error('Fixed source acceptance artifact differs');
  }
  for(const[file,expected]of Object.entries(candidate.compiledSha256))if(sha(path.join(source,file))!==expected)throw Error('Current source compiled input changed: '+file);
  const delta=git(['diff','--name-only',before.revision,candidate.deliveryHead,'--',...Object.keys(before.protectedFiles)]);if(delta)throw Error('Delivery changes protected configuration');
  if(process.argv.includes('--verify-only')){console.log(JSON.stringify({passed:true,scope:'Before-stop verification only',ciHead:candidate.head,ciRun:candidate.ciRun,rollbackFiles:buildFiles.length,protectedFiles:5,servicesStopped:false}));return;}
  const stopTransitions=[];
  for(const name of ['study-agent-health','study-agent-web','study-agent-api']){
    pm('stop '+name);
    for(let attempt=0;attempt<4;attempt++){
      const row=JSON.parse(pm('jlist')).find(item=>item.name===name);
      if(!row)throw Error('Owned guardian missing while stopping');
      stopTransitions.push({name,pid:row.pid,status:row.pm2_env.status,attempt});
      if(!row.pid&&row.pm2_env.status==='stopped')break;
      if(!row.pid&&row.pm2_env.status==='waiting restart')pm('stop '+name);
      if(attempt===3)throw Error('Owned guardian failed to settle stopped');
      await new Promise(resolve=>setTimeout(resolve,250));
    }
  }
  fs.writeFileSync(path.join(release,'stop-transitions.json'),JSON.stringify({at:new Date().toISOString(),transitions:stopTransitions},null,2)+'\n',{flag:'wx'});

  const stopped = JSON.parse(pm('jlist')).filter(row => names.includes(row.name));
  if (stopped.length !== 3 || stopped.some(row => row.pm2_env.status !== 'stopped' || row.pid)) throw Error('Service did not stop');
  // PM2 status alone does not prove its child listeners stopped. Never back up a possibly writing orphan.
  for (const port of [3217,4217]) await new Promise((resolve,reject)=>{
    const socket=require('node:net').createConnection({host:'127.0.0.1',port});
    socket.setTimeout(1500);socket.once('connect',()=>{socket.destroy();reject(Error('Original production listener still active on '+port+'; preserve state and inspect its exact owner'));});
    socket.once('timeout',()=>{socket.destroy();reject(Error('Cannot prove original listener closed on '+port));});
    socket.once('error',error=>{socket.destroy();if(error.code==='ECONNREFUSED')resolve();else reject(error);});
  });
  const backup = require(path.join(root, 'scripts/operations/backup.cjs')), bundle = path.join(release, 'data-bundle-final');
  await backup.createBundle({ dataDir: path.join(root, 'data'), destination: bundle });
  const verified = await backup.verifyBundle({ bundle });
  if (verified.database.schemaVersions.at(-1) !== 21) throw Error('Fresh schema21 rollback required before140 schema21 delivery');
  const receipt = { at: new Date().toISOString(), bundle: 'data-bundle-final', verifiedFiles: verified.verifiedFiles, assetsIncluded: false, servicesStopped: names,
    scope: 'Fresh stopped-service consistent SQLite database and database-referenced runtime files. Original compiled build/configuration separately copied and hashed. No complete research-asset backup or full recovery rehearsal.' };
  fs.writeFileSync(path.join(release, 'backup-verified.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  git(['merge', '--ff-only', candidate.deliveryHead]); verifyConfig();
  fs.writeFileSync(path.join(release, 'deployment-target.json'), JSON.stringify({ ciHead: candidate.head, ciRun: candidate.ciRun, applicationRevision: candidate.applicationRevision }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ stopped: names, backup: receipt, head: git(['rev-parse', 'HEAD']), protectedFilesUnchanged: 5 }));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
