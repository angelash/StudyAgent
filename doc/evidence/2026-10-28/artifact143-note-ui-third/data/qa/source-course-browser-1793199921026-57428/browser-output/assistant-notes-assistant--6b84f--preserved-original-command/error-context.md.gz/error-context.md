# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: assistant-notes.spec.ts >> assistant notes: a request that never reached the server retries only its preserved original command
- Location: tests\e2e\assistant-notes.spec.ts:82:5

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/learn(?:\?|$)/
Received string:  "http://localhost:3127/parent/login"
Timeout: 15000ms

Call log:
  - Expect "toHaveURL" with timeout 15000ms
    33 × locator resolved to <html lang="zh-CN">…</html>
       - unexpected value "http://localhost:3127/parent/login"

```

```yaml
- alert "身份确认未完成":
  - paragraph:
    - strong: 暂时无法确认登录状态
    - text: 请检查网络后重试。已保存的学习记录会保留。
  - button "重新确认登录"
- main:
  - complementary:
    - link "学 学习观察室":
      - /url: /
    - text: FAMILY / 每一步，都看得见
    - heading "先看见孩子， 怎样学会。" [level=1]:
      - text: 先看见孩子，
      - emphasis: 怎样学会。
    - paragraph: 从一个具体知识点开始，找到卡住的一步，再通过新题和时间，看看是否真的留下来。
    - link "孩子自己来学习？使用学习码进入 ↗":
      - /url: /student/login
  - text: 家长与教师入口
  - heading "继续孩子的学习旅程。" [level=2]
  - paragraph: 登录后查看孩子的知识证据、指导计划和复测记录。
  - text: 登录账号
  - textbox "登录账号":
    - /placeholder: 账号或邮箱
    - text: note-ui-85c5fcb5-3626-4544-8fb8-afeb7e867499@local.test
  - text: 密码
  - textbox "密码":
    - /placeholder: 至少 10 个字符
    - text: [REDACTED-SYNTHETIC-CREDENTIAL]
  - alert: 暂时无法连接学习服务，请检查网络后重试。已保存的数据会保留。
  - button "登录，查看学习记录 →"
  - button "首次使用，创建家长账号"
  - paragraph: 教师与教研权限由管理员配置。孩子使用家长生成的一次性学习码。
- alert
```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test';
  2   | import { readFile } from 'node:fs/promises';
  3   | import { syntheticFamilyHeaders } from './synthetic-family';
  4   | import { browserEvidence } from './evidence';
  5   | const api = 'http://localhost:' + (process.env.E2E_API_PORT ?? '4107') + '/api', evidence = browserEvidence('assistant-notes');
  6   | async function call(actor: any, path: string, body?: unknown, method = body === undefined ? 'GET' : 'POST') {
  7   |   const response = await fetch(api + path, { method, headers: { 'content-type': 'application/json', Authorization: 'Bearer ' + actor.token }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  8   |   const value = await response.json(); expect(response.ok, JSON.stringify(value.error)).toBe(true); return value.data;
  9   | }
  10  | async function fixture(page: Page) {
  11  |   const principal = 'note-ui-' + crypto.randomUUID() + '@local.test', credential = 'Synthetic-note-ui-' + crypto.randomUUID();
  12  |   const response = await fetch(api + '/auth/register', { method: 'POST', headers: await syntheticFamilyHeaders(page), body: JSON.stringify({ principal, credential }) }); expect(response.status).toBe(201); const actor = (await response.json()).data;
> 13  |   await page.goto('/parent/login'); await page.getByLabel('登录账号').fill(principal); await page.getByLabel('密码').fill(credential); await page.getByRole('button', { name: '登录，查看学习记录 →' }).click(); await expect(page).toHaveURL(/\/learn(?:\?|$)/);
      |                                                                                                                                                                                                                      ^ Error: expect(page).toHaveURL(expected) failed
  14  |   const d = await call(actor, '/ai/assistant/lecture-context?courseId=sociology-foundations&lectureId=soc-u1-l1');
  15  |   const session = await call(actor, '/ai/assistant/sessions', { userRole: 'parent', studentId: null, subject: null, pageContext: 'classroom', contextRefType: 'classroom_lecture', contextRefId: d.referenceId, contextItemId: d.lectureId });
  16  |   const context = await call(actor, '/ai/assistant/sessions/' + session.id + '/context');
  17  |   const turn = await call(actor, '/ai/assistant/sessions/' + session.id + '/turns', { requestKey: crypto.randomUUID(), message: '[cite-course] 请保留具体条件和反例。', modelId: 'deepseek-v4-flash', contextVersion: context.contextVersion });
  18  |   await expect.poll(async () => (await call(actor, '/ai/assistant/sessions/' + session.id + '/turns/' + turn.id)).status, { timeout: 45000 }).toBe('completed');
  19  |   const history = await call(actor, '/ai/assistant/sessions/' + session.id + '/messages/page'), message = history.messages.find((m: any) => m.sender === 'assistant');
  20  |   const href = '/studio?view=home&mode=instant&lectureCourse=sociology-foundations&lecture=soc-u1-l1&lectureVersion=' + d.fingerprint;
  21  |   await page.goto(href); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled();
  22  |   const base = '/ai/assistant/sessions/' + session.id + '/artifacts/notes'; return { actor, session, message, question: history.messages.find((m: any) => m.sender === 'user'), href, base };
  23  | }
  24  | const panel = (page: Page) => page.getByRole('dialog', { name: '私人学习笔记', exact: true });
  25  | async function enter(page: Page, message: any) { await page.locator('[data-message-id="' + message.id + '"]').getByRole('button', { name: '整理为笔记', exact: true }).click(); await expect(panel(page)).toBeVisible(); }
  26  | async function create(page: Page) {
  27  |   const dialog = panel(page); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByText(/完整来源 \d+ \/ 18000 字符/)).toBeVisible();
  28  |   await dialog.getByRole('button', { name: '保存逐字候选', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toBeEnabled();
  29  | }
  30  | for (const width of [390, 768, 880, 1440]) test('assistant notes: original source, explicit editing/adoption/export and original-message return at' + width, async ({ page }) => {
  31  |   test.setTimeout(120000); await page.setViewportSize({ width, height: 960 }); const f = await fixture(page), composer = page.getByLabel('想一起看看什么', { exact: true }); await composer.fill('原助教的完整未发送草稿。');
  32  |   const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:$|\/[^/]+\/turns$)/.test(new URL(r.url()).pathname)) posts.push(r.url()); });
  33  |   await enter(page, f.message); const dialog = panel(page); await dialog.getByLabel('同时包含回答关联的原问题').check(); await dialog.getByLabel('笔记标题').fill('条件、证据与反例'); await create(page);
  34  |   await expect(dialog.locator('.assistant-notes-original')).toContainText(f.message.content); await expect(dialog.locator('.assistant-notes-original article')).toHaveCount(2);
  35  |   const edited = '  完整编辑稿\n|条件|证据|\n|---|---|\n|匿名观察|保持完整|\n公式 $a+b$\n```js\nconsole.log("不执行");\n```\n<script>window.noteInjected=true</script>\n  ';
  36  |   await dialog.getByLabel('笔记编辑稿').fill(edited); await expect(dialog.getByRole('button', { name: '采用这份笔记', exact: true })).toBeDisabled();
  37  |   await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click(); await expect(dialog.getByLabel('我已核对原文和编辑稿')).toBeEnabled(); await dialog.getByLabel('我已核对原文和编辑稿').check();
  38  |   await dialog.getByRole('button', { name: '采用这份笔记', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toHaveAttribute('readonly', ''); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(edited);
  39  |   const reading = dialog.getByRole('region', { name: '笔记阅读稿', exact: true }); await expect(reading.getByRole('columnheader')).toHaveCount(2); await expect(reading.getByRole('cell', { name: '匿名观察', exact: true })).toBeVisible(); await expect(reading.locator('math')).toHaveCount(1); await expect(reading.getByLabel('笔记代码原文')).toContainText('console.log("不执行");');
  40  |   const saved = await call(f.actor, f.base); expect(saved.items).toHaveLength(1); expect(saved.items[0].status).toBe('confirmed');
  41  |   const original = await call(f.actor, f.base + '/' + saved.items[0].id); expect(original.origin.messages.some((m: any) => m.content === f.message.content)).toBe(true);
  42  |   const jsonDownload = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载完整JSON', exact: true }).click(); const jsonFile = await jsonDownload, json = JSON.parse(await readFile((await jsonFile.path())!, 'utf8')); expect(json.markdown).toBe(edited); expect(json.origin).toEqual(original.origin); expect(JSON.stringify(json)).not.toMatch(/requestKey|commands|tokenHash/);
  43  |   const mdDownload = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载完整Markdown', exact: true }).click(); const mdFile = await mdDownload; expect(await readFile((await mdFile.path())!, 'utf8')).toContain(edited);
  44  |   expect(await page.evaluate(() => (window as any).noteInjected)).toBeUndefined(); expect(await dialog.evaluate(node => node.getBoundingClientRect().right <= innerWidth && node.getBoundingClientRect().left >= 0)).toBe(true);
  45  |   await page.screenshot({ path: evidence + '/confirmed-' + width + '.png' }); await dialog.getByRole('button', { name: '返回原消息', exact: true }).click();
  46  |   await expect(dialog).toHaveCount(0); await expect(composer).toHaveValue('原助教的完整未发送草稿。'); await expect(page.locator('[data-message-id="' + f.message.id + '"]')).toBeFocused(); expect(posts).toEqual([]);
  47  | });
  48  | 
  49  | test('assistant notes: a committed create with a lost HTTP reply survives refresh and recovers without another create', async ({ page }) => {
  50  |   test.setTimeout(120000); const f = await fixture(page); let count = 0;
  51  |   await page.route('**/api/ai/assistant/sessions/*/artifacts/notes', async route => { if (route.request().method() !== 'POST') return route.continue(); count++; const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed'); });
  52  |   await enter(page, f.message); const dialog = panel(page); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '保存逐字候选', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '保存逐字候选', exact: true }).click();
  53  |   await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toBeVisible(); await expect(dialog.getByRole('alert')).toContainText('原操作仍保留');
  54  |   await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(page, f.message); await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toBeVisible();
  55  |   await dialog.getByRole('button', { name: '核对原操作', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toBeEnabled(); await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toHaveCount(0);
  56  |   expect(count).toBe(1); expect((await call(f.actor, f.base)).items).toHaveLength(1); await page.screenshot({ path: evidence + '/original-request-recovered.png' });
  57  | });
  58  | 
  59  | test('assistant notes: offline local editing, independent draft and Escape focus survive leaving and reopening', async ({ page }) => {
  60  |   test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = '本机尚未提交的完整笔记\n一行一行保留。';
  61  |   await dialog.getByLabel('笔记编辑稿').fill(text); await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(page.locator('[data-message-id="' + f.message.id + '"]').getByRole('button', { name: '整理为笔记', exact: true })).toBeFocused();
  62  |   await page.context().setOffline(true); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await expect(dialog.getByRole('alert')).toContainText('无法连接'); await expect(dialog.getByRole('button', { name: '保存编辑稿', exact: true })).toBeDisabled();
  63  |   await page.context().setOffline(false); await page.keyboard.press('Escape'); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await expect(dialog.getByRole('button', { name: '保存编辑稿', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click();
  64  |   const row = (await call(f.actor, f.base)).items[0]; expect((await call(f.actor, f.base + '/' + row.id)).markdown).toBe(text);
  65  | });
  66  | 
  67  | test('assistant notes: corrupt or different-account cached content stays hidden and its original bytes are preserved', async ({ page }) => {
  68  |   test.setTimeout(120000); const f = await fixture(page), key = 'studyagent.assistant.notes.v1.' + encodeURIComponent(f.actor.user.id) + '.' + encodeURIComponent(f.session.id), raw = JSON.stringify({ version: 1, ownerId: 'another-account', sessionId: f.session.id, active: 'new', drafts: { new: { title: 'PRIVATE_FORGED_CONTENT' } } });
  69  |   await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), { key, raw }); await enter(page, f.message); const dialog = panel(page); await expect(dialog).not.toContainText('PRIVATE_FORGED_CONTENT'); await expect(dialog.getByRole('status').filter({ hasText: '原笔记缓存尚未核对' })).toBeVisible();
  70  |   await dialog.getByLabel('笔记标题').fill('本次页面里仍能编辑'); expect(await page.evaluate(key => localStorage.getItem(key), key)).toBe(raw);
  71  |   const download = page.waitForEvent('download'); await dialog.getByRole('button', { name: '下载本机稿', exact: true }).last().click(); const file = await download; expect(JSON.parse(await readFile((await file.path())!, 'utf8')).title).toBe('本次页面里仍能编辑');
  72  | });
  73  | 
  74  | test('assistant notes: a source outside70 later messages returns by a read-only anchor without opening another conversation', async ({ page }) => {
  75  |   test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); await page.keyboard.press('Escape');
  76  |   await call(f.actor, '/qa/assistant/seed-history', { sessionId: f.session.id, count: 70, makeSourceOld: true }); await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await expect(page.locator('[data-message-id="' + f.message.id + '"]')).toHaveCount(0);
  77  |   const posts: string[] = []; page.on('request', r => { if (r.method() === 'POST' && /\/ai\/assistant\/sessions(?:$|\/[^/]+\/turns$)/.test(new URL(r.url()).pathname)) posts.push(r.url()); });
  78  |   await page.getByRole('button', { name: '我的笔记', exact: true }).click(); const dialog = panel(page); await dialog.getByRole('region', { name: '服务端已保存笔记' }).getByRole('button', { name: /我的学习笔记/ }).click();
  79  |   await expect(dialog.getByRole('button', { name: '返回原消息', exact: true })).toBeVisible(); await dialog.getByRole('button', { name: '返回原消息', exact: true }).click(); await expect(page.locator('[data-message-id="' + f.message.id + '"]')).toBeFocused(); expect(posts).toEqual([]);
  80  | });
  81  | 
  82  | test('assistant notes: a request that never reached the server retries only its preserved original command', async ({ page }) => {
  83  |   test.setTimeout(120000); const f = await fixture(page), commands: unknown[] = [];
  84  |   await page.route('**/api/ai/assistant/sessions/*/artifacts/notes', async route => {
  85  |     if (route.request().method() !== 'POST') return route.continue(); commands.push(route.request().postDataJSON());
  86  |     if (commands.length === 1) return route.abort('failed'); await route.continue();
  87  |   });
  88  |   await enter(page, f.message); const dialog = panel(page); await dialog.getByRole('button', { name: '核对完整来源', exact: true }).click(); await expect(dialog.getByRole('button', { name: '保存逐字候选', exact: true })).toBeEnabled(); await dialog.getByRole('button', { name: '保存逐字候选', exact: true }).click();
  89  |   await expect(dialog.getByRole('alert')).toContainText('原操作仍保留'); expect((await call(f.actor, f.base)).items).toEqual([]); await dialog.getByRole('button', { name: '核对原操作', exact: true }).click();
  90  |   await expect(dialog.getByRole('button', { name: '用原请求重试', exact: true })).toBeVisible(); await dialog.getByRole('button', { name: '用原请求重试', exact: true }).click(); await expect(dialog.getByLabel('笔记编辑稿')).toBeEnabled();
  91  |   expect(commands).toHaveLength(2); expect(commands[1]).toEqual(commands[0]); expect((await call(f.actor, f.base)).items).toHaveLength(1);
  92  | });
  93  | 
  94  | test('assistant notes: lost edit and adoption replies recover their original results without publishing another command', async ({ page }) => {
  95  |   test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = '已提交但回执暂时丢失的完整编辑稿。'; let edits = 0, confirmations = 0;
  96  |   await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/*/content', async route => { edits++; const response = await route.fetch(); expect(response.status()).toBe(200); await route.abort('failed'); });
  97  |   await dialog.getByLabel('笔记编辑稿').fill(text); await dialog.getByRole('button', { name: '保存编辑稿', exact: true }).click(); await expect(dialog.getByRole('alert')).toContainText('原操作仍保留');
  98  |   await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await dialog.getByRole('button', { name: '核对原操作', exact: true }).click(); await expect(dialog.getByLabel('我已核对原文和编辑稿')).toBeEnabled();
  99  |   await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/*/confirm', async route => { confirmations++; const response = await route.fetch(); expect(response.status()).toBe(201); await route.abort('failed'); });
  100 |   await dialog.getByLabel('我已核对原文和编辑稿').check(); await dialog.getByRole('button', { name: '采用这份笔记', exact: true }).click(); await expect(dialog.getByRole('alert')).toContainText('原操作仍保留');
  101 |   await page.reload(); await expect(page.getByLabel('想一起看看什么', { exact: true })).toBeEnabled(); await enter(page, f.message); await dialog.getByRole('button', { name: '核对原操作', exact: true }).click(); await expect(dialog.getByRole('complementary', { name: '笔记原操作' })).toHaveCount(0);
  102 |   await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); expect(edits).toBe(1); expect(confirmations).toBe(1); expect((await call(f.actor, f.base)).items[0].status).toBe('confirmed');
  103 | });
  104 | 
  105 | test('assistant notes: another selected message keeps the first unsubmitted editing draft intact', async ({ page }) => {
  106 |   test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page), text = '第一份笔记尚未提交的独立草稿。'; await dialog.getByLabel('笔记编辑稿').fill(text); await page.keyboard.press('Escape');
  107 |   await enter(page, f.question); await expect(dialog.getByLabel('笔记复习目标')).toBeVisible(); await create(page); await page.keyboard.press('Escape');
  108 |   expect((await call(f.actor, f.base)).items).toHaveLength(2); await enter(page, f.message); await expect(dialog.getByLabel('笔记编辑稿')).toHaveValue(text); await expect(dialog.getByRole('button', { name: '保存编辑稿', exact: true })).toBeEnabled();
  109 | });
  110 | 
  111 | test('assistant notes: an export read failure preserves the full saved note and a retry only downloads it', async ({ page }) => {
  112 |   test.setTimeout(120000); const f = await fixture(page); await enter(page, f.message); await create(page); const dialog = panel(page); let reads = 0;
  113 |   await page.route('**/api/ai/assistant/sessions/*/artifacts/notes/*/export?format=json', route => { reads++; return reads === 1 ? route.abort('failed') : route.continue(); });
```